<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0056d098-86b6-4e93-a590-e5c258774f4a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>赤坂一丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">8.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6697449271022 139.74300300422578 0 35.66984794772266 139.7431147860302 0 35.66987559055164 139.74307565141285 0 35.66969526248083 139.74288431390073 0 35.669685334036494 139.7429866125791 0 35.66972538679078 139.74302898473823 0 35.6697449271022 139.74300300422578 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6697449271022 139.74300300422578 8.08 35.66972538679078 139.74302898473823 8.08 35.669685334036494 139.7429866125791 8.08 35.66969526248083 139.74288431390073 8.08 35.66987559055164 139.74307565141285 8.08 35.66984794772266 139.7431147860302 8.08 35.6697449271022 139.74300300422578 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6697449271022 139.74300300422578 8.08 35.66984794772266 139.7431147860302 8.08 35.66984794772266 139.7431147860302 16.16 35.6697449271022 139.74300300422578 16.16 35.6697449271022 139.74300300422578 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66984794772266 139.7431147860302 8.08 35.66987559055164 139.74307565141285 8.08 35.66987559055164 139.74307565141285 16.16 35.66984794772266 139.7431147860302 16.16 35.66984794772266 139.7431147860302 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66987559055164 139.74307565141285 8.08 35.66969526248083 139.74288431390073 8.08 35.66969526248083 139.74288431390073 16.16 35.66987559055164 139.74307565141285 16.16 35.66987559055164 139.74307565141285 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66969526248083 139.74288431390073 8.08 35.669685334036494 139.7429866125791 8.08 35.669685334036494 139.7429866125791 16.16 35.66969526248083 139.74288431390073 16.16 35.66969526248083 139.74288431390073 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669685334036494 139.7429866125791 8.08 35.66972538679078 139.74302898473823 8.08 35.66972538679078 139.74302898473823 16.16 35.669685334036494 139.7429866125791 16.16 35.669685334036494 139.7429866125791 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66972538679078 139.74302898473823 8.08 35.6697449271022 139.74300300422578 8.08 35.6697449271022 139.74300300422578 16.16 35.66972538679078 139.74302898473823 16.16 35.66972538679078 139.74302898473823 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6697449271022 139.74300300422578 16.16 35.66984794772266 139.7431147860302 16.16 35.66987559055164 139.74307565141285 16.16 35.66969526248083 139.74288431390073 16.16 35.669685334036494 139.7429866125791 16.16 35.66972538679078 139.74302898473823 16.16 35.6697449271022 139.74300300422578 16.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-839e7427-83d5-4ac2-b207-7bc07e553219"/>
							<gml:surfaceMember xlink:href="#poly-3483a44a-e19a-4987-9a80-34f94d0e99f3"/>
							<gml:surfaceMember xlink:href="#poly-17973553-466b-476d-bd4f-ebeb415f881e"/>
							<gml:surfaceMember xlink:href="#poly-bfdaadde-f38c-4778-a530-4d3937de532b"/>
							<gml:surfaceMember xlink:href="#poly-9b27e3c3-815d-46bb-9042-1002cf745444"/>
							<gml:surfaceMember xlink:href="#poly-b8597024-03aa-483b-a402-d7e3a196a4c8"/>
							<gml:surfaceMember xlink:href="#poly-fa1d41ec-1f1e-4b24-b83d-bc9882463417"/>
							<gml:surfaceMember xlink:href="#poly-e66de42a-7bb3-4054-9c70-fc0009240b41"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0056d098-86b6-4e93-a590-e5c258774f4a_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86eb5472-ec51-4516-a479-f7e4e12eee02">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66983002594749 139.74302730937325 15.898 35.66982076965513 139.74304040952507 15.898 35.66979228161483 139.74301017507688 15.898 35.66980153790395 139.74299707492625 15.898 35.66983002594749 139.74302730937325 15.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a123328e-cee0-4acc-b219-3371d0d5c43e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a123328e-cee0-4acc-b219-3371d0d5c43e_0">
											<gml:posList>35.66980153790395 139.74299707492625 18.437 35.66980153790395 139.74299707492625 15.898 35.66979228161483 139.74301017507688 15.898 35.66979228161483 139.74301017507688 18.437 35.66980153790395 139.74299707492625 18.437</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1649b4ff-50fe-4ccd-bffe-f1beb22a8e59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1649b4ff-50fe-4ccd-bffe-f1beb22a8e59_0">
											<gml:posList>35.66983002594749 139.74302730937325 18.437 35.66983002594749 139.74302730937325 15.898 35.66980153790395 139.74299707492625 15.898 35.66980153790395 139.74299707492625 18.437 35.66983002594749 139.74302730937325 18.437</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24940855-ea1d-4e5c-b9d0-6298586b52e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24940855-ea1d-4e5c-b9d0-6298586b52e5_0">
											<gml:posList>35.66980153790395 139.74299707492625 18.437 35.66979228161483 139.74301017507688 18.437 35.66982076965513 139.74304040952507 18.437 35.66983002594749 139.74302730937325 18.437 35.66980153790395 139.74299707492625 18.437</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a94cffa7-f05f-4308-a4ec-7d8eaaedff08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a94cffa7-f05f-4308-a4ec-7d8eaaedff08_0">
											<gml:posList>35.66979228161483 139.74301017507688 18.437 35.66979228161483 139.74301017507688 15.898 35.66982076965513 139.74304040952507 15.898 35.66982076965513 139.74304040952507 18.437 35.66979228161483 139.74301017507688 18.437</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4eff9ef-f8cf-478b-a07e-8b83ec1822b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4eff9ef-f8cf-478b-a07e-8b83ec1822b7_0">
											<gml:posList>35.66982076965513 139.74304040952507 18.437 35.66982076965513 139.74304040952507 15.898 35.66983002594749 139.74302730937325 15.898 35.66983002594749 139.74302730937325 18.437 35.66982076965513 139.74304040952507 18.437</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-839e7427-83d5-4ac2-b207-7bc07e553219">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-839e7427-83d5-4ac2-b207-7bc07e553219">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-839e7427-83d5-4ac2-b207-7bc07e553219">
											<gml:posList>35.6697449271022 139.74300300422578 8.08 35.669725386790766 139.74302898473823 8.08 35.669685334036444 139.74298661257907 8.08 35.669695262480815 139.7428843139007 8.08 35.66987559055161 139.74307565141285 8.08 35.66984794772264 139.7431147860302 8.08 35.6697449271022 139.74300300422578 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3483a44a-e19a-4987-9a80-34f94d0e99f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3483a44a-e19a-4987-9a80-34f94d0e99f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3483a44a-e19a-4987-9a80-34f94d0e99f3">
											<gml:posList>35.669695262480815 139.7428843139007 15.5 35.669685334036444 139.74298661257907 15.5 35.669725386790766 139.74302898473823 15.5 35.6697449271022 139.74300300422578 15.5 35.66984794772264 139.7431147860302 15.5 35.66987559055161 139.74307565141285 15.5 35.669695262480815 139.7428843139007 15.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17973553-466b-476d-bd4f-ebeb415f881e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17973553-466b-476d-bd4f-ebeb415f881e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17973553-466b-476d-bd4f-ebeb415f881e">
											<gml:posList>35.66987559055161 139.74307565141285 8.08 35.669695262480815 139.7428843139007 8.08 35.669695262480815 139.7428843139007 15.5 35.66987559055161 139.74307565141285 15.5 35.66987559055161 139.74307565141285 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfdaadde-f38c-4778-a530-4d3937de532b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfdaadde-f38c-4778-a530-4d3937de532b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfdaadde-f38c-4778-a530-4d3937de532b">
											<gml:posList>35.669695262480815 139.7428843139007 8.08 35.669685334036444 139.74298661257907 8.08 35.669685334036444 139.74298661257907 15.5 35.669695262480815 139.7428843139007 15.5 35.669695262480815 139.7428843139007 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b27e3c3-815d-46bb-9042-1002cf745444">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b27e3c3-815d-46bb-9042-1002cf745444">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b27e3c3-815d-46bb-9042-1002cf745444">
											<gml:posList>35.669685334036444 139.74298661257907 8.08 35.669725386790766 139.74302898473823 8.08 35.669725386790766 139.74302898473823 15.5 35.669685334036444 139.74298661257907 15.5 35.669685334036444 139.74298661257907 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8597024-03aa-483b-a402-d7e3a196a4c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8597024-03aa-483b-a402-d7e3a196a4c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8597024-03aa-483b-a402-d7e3a196a4c8">
											<gml:posList>35.669725386790766 139.74302898473823 8.08 35.6697449271022 139.74300300422578 8.08 35.6697449271022 139.74300300422578 15.5 35.669725386790766 139.74302898473823 15.5 35.669725386790766 139.74302898473823 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa1d41ec-1f1e-4b24-b83d-bc9882463417">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa1d41ec-1f1e-4b24-b83d-bc9882463417">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa1d41ec-1f1e-4b24-b83d-bc9882463417">
											<gml:posList>35.6697449271022 139.74300300422578 8.08 35.66984794772264 139.7431147860302 8.08 35.66984794772264 139.7431147860302 15.5 35.6697449271022 139.74300300422578 15.5 35.6697449271022 139.74300300422578 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e66de42a-7bb3-4054-9c70-fc0009240b41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e66de42a-7bb3-4054-9c70-fc0009240b41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e66de42a-7bb3-4054-9c70-fc0009240b41">
											<gml:posList>35.66984794772264 139.7431147860302 8.08 35.66987559055161 139.74307565141285 8.08 35.66987559055161 139.74307565141285 15.5 35.66984794772264 139.7431147860302 15.5 35.66984794772264 139.7431147860302 8.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1502</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.76</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>