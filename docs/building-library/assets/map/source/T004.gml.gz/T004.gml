<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_009dc493-0720-454f-9cf2-03064b30b373">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">20.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67227805569427 139.73863879594995 0 35.6722829032162 139.73863642626876 0 35.67229084545514 139.73866080760934 0 35.67229888260945 139.73865687660256 0 35.6723041232119 139.7386729541533 0 35.672324153015396 139.73866314328072 0 35.67232562579511 139.7386676485247 0 35.67234491675973 139.73865820305616 0 35.67233852862435 139.73863858091778 0 35.672375038192065 139.73862070868847 0 35.67230937676021 139.73841919822337 0 35.67227056059796 139.73843820000496 0 35.67224707710633 139.7383661382347 0 35.67221067568807 139.7383839441441 0 35.67226027198314 139.73853617270714 0 35.672252532172415 139.73853995976776 0 35.672258287815865 139.7385576163447 0 35.67225252125262 139.73856044002358 0 35.67227805569427 139.73863879594995 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67227805569427 139.73863879594995 9.644 35.67225252125262 139.73856044002358 9.644 35.672258287815865 139.7385576163447 9.644 35.672252532172415 139.73853995976776 9.644 35.67226027198314 139.73853617270714 9.644 35.67221067568807 139.7383839441441 9.644 35.67224707710633 139.7383661382347 9.644 35.67227056059796 139.73843820000496 9.644 35.67230937676021 139.73841919822337 9.644 35.672375038192065 139.73862070868847 9.644 35.67233852862435 139.73863858091778 9.644 35.67234491675973 139.73865820305616 9.644 35.67232562579511 139.7386676485247 9.644 35.672324153015396 139.73866314328072 9.644 35.6723041232119 139.7386729541533 9.644 35.67229888260945 139.73865687660256 9.644 35.67229084545514 139.73866080760934 9.644 35.6722829032162 139.73863642626876 9.644 35.67227805569427 139.73863879594995 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67227805569427 139.73863879594995 9.644 35.6722829032162 139.73863642626876 9.644 35.6722829032162 139.73863642626876 30.18 35.67227805569427 139.73863879594995 30.18 35.67227805569427 139.73863879594995 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6722829032162 139.73863642626876 9.644 35.67229084545514 139.73866080760934 9.644 35.67229084545514 139.73866080760934 30.18 35.6722829032162 139.73863642626876 30.18 35.6722829032162 139.73863642626876 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67229084545514 139.73866080760934 9.644 35.67229888260945 139.73865687660256 9.644 35.67229888260945 139.73865687660256 30.18 35.67229084545514 139.73866080760934 30.18 35.67229084545514 139.73866080760934 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67229888260945 139.73865687660256 9.644 35.6723041232119 139.7386729541533 9.644 35.6723041232119 139.7386729541533 30.18 35.67229888260945 139.73865687660256 30.18 35.67229888260945 139.73865687660256 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6723041232119 139.7386729541533 9.644 35.672324153015396 139.73866314328072 9.644 35.672324153015396 139.73866314328072 30.18 35.6723041232119 139.7386729541533 30.18 35.6723041232119 139.7386729541533 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672324153015396 139.73866314328072 9.644 35.67232562579511 139.7386676485247 9.644 35.67232562579511 139.7386676485247 30.18 35.672324153015396 139.73866314328072 30.18 35.672324153015396 139.73866314328072 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67232562579511 139.7386676485247 9.644 35.67234491675973 139.73865820305616 9.644 35.67234491675973 139.73865820305616 30.18 35.67232562579511 139.7386676485247 30.18 35.67232562579511 139.7386676485247 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234491675973 139.73865820305616 9.644 35.67233852862435 139.73863858091778 9.644 35.67233852862435 139.73863858091778 30.18 35.67234491675973 139.73865820305616 30.18 35.67234491675973 139.73865820305616 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67233852862435 139.73863858091778 9.644 35.672375038192065 139.73862070868847 9.644 35.672375038192065 139.73862070868847 30.18 35.67233852862435 139.73863858091778 30.18 35.67233852862435 139.73863858091778 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672375038192065 139.73862070868847 9.644 35.67230937676021 139.73841919822337 9.644 35.67230937676021 139.73841919822337 30.18 35.672375038192065 139.73862070868847 30.18 35.672375038192065 139.73862070868847 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67230937676021 139.73841919822337 9.644 35.67227056059796 139.73843820000496 9.644 35.67227056059796 139.73843820000496 30.18 35.67230937676021 139.73841919822337 30.18 35.67230937676021 139.73841919822337 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67227056059796 139.73843820000496 9.644 35.67224707710633 139.7383661382347 9.644 35.67224707710633 139.7383661382347 30.18 35.67227056059796 139.73843820000496 30.18 35.67227056059796 139.73843820000496 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67224707710633 139.7383661382347 9.644 35.67221067568807 139.7383839441441 9.644 35.67221067568807 139.7383839441441 30.18 35.67224707710633 139.7383661382347 30.18 35.67224707710633 139.7383661382347 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67221067568807 139.7383839441441 9.644 35.67226027198314 139.73853617270714 9.644 35.67226027198314 139.73853617270714 30.18 35.67221067568807 139.7383839441441 30.18 35.67221067568807 139.7383839441441 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67226027198314 139.73853617270714 9.644 35.672252532172415 139.73853995976776 9.644 35.672252532172415 139.73853995976776 30.18 35.67226027198314 139.73853617270714 30.18 35.67226027198314 139.73853617270714 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672252532172415 139.73853995976776 9.644 35.672258287815865 139.7385576163447 9.644 35.672258287815865 139.7385576163447 30.18 35.672252532172415 139.73853995976776 30.18 35.672252532172415 139.73853995976776 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672258287815865 139.7385576163447 9.644 35.67225252125262 139.73856044002358 9.644 35.67225252125262 139.73856044002358 30.18 35.672258287815865 139.7385576163447 30.18 35.672258287815865 139.7385576163447 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67225252125262 139.73856044002358 9.644 35.67227805569427 139.73863879594995 9.644 35.67227805569427 139.73863879594995 30.18 35.67225252125262 139.73856044002358 30.18 35.67225252125262 139.73856044002358 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67227805569427 139.73863879594995 30.18 35.6722829032162 139.73863642626876 30.18 35.67229084545514 139.73866080760934 30.18 35.67229888260945 139.73865687660256 30.18 35.6723041232119 139.7386729541533 30.18 35.672324153015396 139.73866314328072 30.18 35.67232562579511 139.7386676485247 30.18 35.67234491675973 139.73865820305616 30.18 35.67233852862435 139.73863858091778 30.18 35.672375038192065 139.73862070868847 30.18 35.67230937676021 139.73841919822337 30.18 35.67227056059796 139.73843820000496 30.18 35.67224707710633 139.7383661382347 30.18 35.67221067568807 139.7383839441441 30.18 35.67226027198314 139.73853617270714 30.18 35.672252532172415 139.73853995976776 30.18 35.672258287815865 139.7385576163447 30.18 35.67225252125262 139.73856044002358 30.18 35.67227805569427 139.73863879594995 30.18</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1d58e1fb-838e-41bd-9c2d-83010334a8da"/>
							<gml:surfaceMember xlink:href="#poly-0d2ff13a-67a8-4a2e-8d09-88a3dbad9dc5"/>
							<gml:surfaceMember xlink:href="#poly-d4e111ae-d002-48a5-a7fe-ebd149e57b39"/>
							<gml:surfaceMember xlink:href="#poly-6518ac42-d389-4e7a-bca5-8f76891d6145"/>
							<gml:surfaceMember xlink:href="#poly-e110e33a-2c97-45c1-a889-a3caaf091f2a"/>
							<gml:surfaceMember xlink:href="#poly-147f4328-9388-484c-9d7d-dbf4cefb2675"/>
							<gml:surfaceMember xlink:href="#poly-45cfd2d6-51dc-4e78-817a-91c5e2877c2c"/>
							<gml:surfaceMember xlink:href="#poly-24602fdf-2c56-48ba-9f75-5911fd1aff8c"/>
							<gml:surfaceMember xlink:href="#poly-0d4b5025-9009-4203-aebc-f126cc94989b"/>
							<gml:surfaceMember xlink:href="#poly-229a7816-ac68-4506-af22-2b2bf52a46f2"/>
							<gml:surfaceMember xlink:href="#poly-03e78625-3709-4a1f-b4af-438e96775b23"/>
							<gml:surfaceMember xlink:href="#poly-2bd59379-4a37-4f9c-8819-1dfa0ff9ee1d"/>
							<gml:surfaceMember xlink:href="#poly-677dbc64-280c-4364-8ec9-2a0a3e6f46b2"/>
							<gml:surfaceMember xlink:href="#poly-145cda94-cf8f-4687-94ef-923294cc3afe"/>
							<gml:surfaceMember xlink:href="#poly-76746b2b-bea3-49a1-8af5-897e96f850ad"/>
							<gml:surfaceMember xlink:href="#poly-fc5933d7-7d7f-49ac-ba3f-13df65139329"/>
							<gml:surfaceMember xlink:href="#poly-817ed34b-7599-46de-a36f-bf76a128b968"/>
							<gml:surfaceMember xlink:href="#poly-c25a4fff-e123-49a9-a70e-18c48c56c87c"/>
							<gml:surfaceMember xlink:href="#poly-b54b7d69-c1ad-4e07-ad97-19a6b013326b"/>
							<gml:surfaceMember xlink:href="#poly-201673e9-7540-4da5-abd4-0277ec757717"/>
							<gml:surfaceMember xlink:href="#poly-2e8c775e-17c4-4cd0-9543-b8250da3d9cb"/>
							<gml:surfaceMember xlink:href="#poly-f1e29515-f4b5-4312-9254-c51e7f7fe5dd"/>
							<gml:surfaceMember xlink:href="#poly-19667835-7291-4c83-a7f8-66d7a6ebd10a"/>
							<gml:surfaceMember xlink:href="#poly-afc3e34b-7049-4f2e-b7be-0809f10a5ab7"/>
							<gml:surfaceMember xlink:href="#poly-6222f9cc-e044-4073-9d1f-04783cc71145"/>
							<gml:surfaceMember xlink:href="#poly-2379a49e-5682-43e9-a394-cbb73fd888f4"/>
							<gml:surfaceMember xlink:href="#poly-ae30725f-f56a-4940-b20e-1738d7001144"/>
							<gml:surfaceMember xlink:href="#poly-7cb8d7f8-7fcb-491d-b969-6daceef81ce6"/>
							<gml:surfaceMember xlink:href="#poly-15192ea6-e43f-408f-9d15-3cf4b1fa976a"/>
							<gml:surfaceMember xlink:href="#poly-a51fc49c-c5ac-4cce-81db-a42a48591572"/>
							<gml:surfaceMember xlink:href="#poly-590c0a23-f02c-4893-ad66-3ea900e461ba"/>
							<gml:surfaceMember xlink:href="#poly-59b2e7cc-5365-48a6-a58f-707efe24c71d"/>
							<gml:surfaceMember xlink:href="#poly-220e2b7b-718c-49b2-92e8-50761356ac3f"/>
							<gml:surfaceMember xlink:href="#poly-19e8ee38-0ce1-49d5-89ad-d95e4666eb1d"/>
							<gml:surfaceMember xlink:href="#poly-08658b93-d31b-46fa-835a-3c58843fc010"/>
							<gml:surfaceMember xlink:href="#poly-b5ac38b8-8355-445d-9231-b1ce55f11e71"/>
							<gml:surfaceMember xlink:href="#poly-b87d8b76-36fb-4232-8b2b-e75c8aaf5c0b"/>
							<gml:surfaceMember xlink:href="#poly-d4060299-5edc-4c43-a972-3d4e77385256"/>
							<gml:surfaceMember xlink:href="#poly-05b4771f-5cda-42c5-b2d0-cce9330a666c"/>
							<gml:surfaceMember xlink:href="#poly-799bcdf6-6a2d-406d-bec5-200a8a75bf60"/>
							<gml:surfaceMember xlink:href="#poly-2f2b23db-e4a1-46aa-bb5a-8548fd9a81bc"/>
							<gml:surfaceMember xlink:href="#poly-a41c5ac7-9f9b-4cd4-b0f7-2e1791e1d48d"/>
							<gml:surfaceMember xlink:href="#poly-0ad1e485-669c-42a5-bd9c-65965d2fe504"/>
							<gml:surfaceMember xlink:href="#poly-383de4ac-2c5e-4cfe-af48-ba3cdf5b11f9"/>
							<gml:surfaceMember xlink:href="#poly-a915ec4f-2e36-494b-ad79-065b6f42a1c2"/>
							<gml:surfaceMember xlink:href="#poly-fca99737-1ce4-434e-9791-3cd12cbd331d"/>
							<gml:surfaceMember xlink:href="#poly-869e4470-7b4c-49a8-b8b3-3f519a4ae043"/>
							<gml:surfaceMember xlink:href="#poly-8145cca1-8629-4731-a957-2ff8362102ca"/>
							<gml:surfaceMember xlink:href="#poly-ccb44c40-1e0b-4a17-ae52-f6646a0f6df9"/>
							<gml:surfaceMember xlink:href="#poly-89458d5d-72f5-4520-8a5a-ea847de1bd98"/>
							<gml:surfaceMember xlink:href="#poly-47b8d3f5-669b-41ba-9dfb-3222afb93810"/>
							<gml:surfaceMember xlink:href="#poly-d052d800-84b2-48ec-b02a-c0f8b2d359b0"/>
							<gml:surfaceMember xlink:href="#poly-5fda736c-f084-4b61-8389-c344b97e5743"/>
							<gml:surfaceMember xlink:href="#poly-b9850f55-e418-4fb6-b671-4199cc77a90a"/>
							<gml:surfaceMember xlink:href="#poly-a57c6e86-14c1-4a6f-b4f0-6414e5292894"/>
							<gml:surfaceMember xlink:href="#poly-2f7f7bec-b20d-4915-94fd-0cf98aed2cce"/>
							<gml:surfaceMember xlink:href="#poly-adb09ff9-4405-40d5-99b4-15bac7548520"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_009dc493-0720-454f-9cf2-03064b30b373_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97fca206-6dba-41a9-9e92-6d78a72570bc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67223852796037 139.7383951896502 29.92 35.67224617781226 139.73839163465965 29.92 35.672252503544975 139.7384120853184 29.92 35.67224486270619 139.7384156402966 29.92 35.67223852796037 139.7383951896502 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40072269-98df-4468-932b-09e74b7d8a6f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67223175284708 139.7384221290751 29.92 35.672225624102815 139.73840001016404 29.92 35.67223247229125 139.73839716310076 29.92 35.67223859203102 139.73841929307065 29.92 35.67223175284708 139.7384221290751 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-089c2661-be06-441e-b696-e1cf51578584">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672242305185094 139.7384300921672 29.92 35.672243693010564 139.73842972598933 29.92 35.67224511717822 139.73842972430347 29.92 35.672246505578315 139.73843008719498 29.92 35.67224779509739 139.73843079264557 29.92 35.67224894965446 139.7384318075584 29.92 35.67224989711363 139.73843309887937 29.92 35.67225061039019 139.73843461140788 29.92 35.67225105335963 139.7384362568146 29.92 35.67225119894596 139.73843799094544 29.92 35.67225105609323 139.73843972541766 29.92 35.672250615718106 139.73844137186995 29.92 35.67224991384062 139.7384428860735 29.92 35.67224895940488 139.7384441796456 29.92 35.67224781546339 139.73844519727908 29.92 35.67224651805363 139.73844591683817 29.92 35.67224513021941 139.73844627196928 29.92 35.67224371506546 139.73844627364417 29.92 35.67224232667412 139.7384459217989 29.92 35.6722410281414 139.73844521635877 29.92 35.67223987357575 139.73844419039932 29.92 35.672238926116705 139.73844289907842 29.92 35.67223821284894 139.73844139759657 29.92 35.672237769870875 139.7384397411436 29.92 35.67223762428457 139.73843800701303 29.92 35.67223776714598 139.73843628358756 29.92 35.67223820751233 139.73843462608903 29.92 35.672238918412134 139.73843312292146 29.92 35.67223986383404 139.73843182936005 29.92 35.672241007766715 139.73843080068 29.92 35.672242305185094 139.7384300921672 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef389fe9-2264-4a27-8db2-108d963b5f54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67231963540249 139.73846624428103 30.33 35.67231531638274 139.73845297146764 30.33 35.67231824471863 139.73845154300017 30.33 35.672322563738526 139.73846481581398 30.33 35.67231963540249 139.73846624428103 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-938667e7-9fb4-4d3b-b3a8-bb1287253e68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672314499558084 139.7384687579196 29.92 35.67231017152491 139.73845548511758 29.92 35.67231531638274 139.73845297146764 29.92 35.67231963540249 139.73846624428103 29.92 35.672314499558084 139.7384687579196 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebbf8a2f-509b-4257-b93b-eda5f7703985">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67224989563815 139.7384655425011 29.92 35.6722509132746 139.73846438141265 29.92 35.67225211140301 139.73846349627348 29.92 35.672253426962165 139.73846293134437 29.92 35.67225481490958 139.73846271981813 29.92 35.67225620313551 139.73846286178014 29.92 35.67225753756633 139.73846336834086 29.92 35.67225875507119 139.73846419538899 29.92 35.672259810555396 139.73846530983838 29.92 35.67226064990178 139.73846666756694 29.92 35.67226124603439 139.73846822442061 29.92 35.67226156282 139.73846988102352 29.92 35.672261591210074 139.7384715932003 29.92 35.67226132212129 139.73847327258952 29.92 35.67226078253387 139.73847484183355 29.92 35.67225999043177 139.73847624567858 29.92 35.67225896379019 139.73847741782419 29.92 35.672257774675394 139.73847830295253 29.92 35.67225645910747 139.73847885683492 29.92 35.672255071160016 139.73847906836087 29.92 35.67225368293411 139.73847892639864 29.92 35.67225234851206 139.73847843088416 29.92 35.67225112199357 139.73847760384652 29.92 35.672250066509484 139.73847648939713 29.92 35.672249227154495 139.73847512062213 29.92 35.6722486400444 139.7384735748045 29.92 35.672248323250145 139.7384719071553 29.92 35.67224829486007 139.73847019497882 29.92 35.67224855494379 139.73846852664704 29.92 35.672249103536146 139.738466946346 29.92 35.67224989563815 139.7384655425011 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dadd486d-c6ad-401d-9f04-d062304533f3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6722871567637 139.7384749210931 29.92 35.67229171899483 139.73848799477787 29.92 35.67228213234769 139.73849302123978 29.92 35.67227757011709 139.73847994755627 29.92 35.6722871567637 139.7384749210931 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66155b84-3eb8-4fba-abfa-6659dda40e4f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6722649345627 139.73849353867746 29.92 35.67225760021408 139.73849712642547 29.92 35.67225405826579 139.7384862497956 29.92 35.67226751958506 139.7384796611913 29.92 35.67227178438036 139.73849275731803 29.92 35.67226565740905 139.7384957581727 29.92 35.6722649345627 139.73849353867746 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11ed46c8-eea1-403d-b0f0-5173e43ed48a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67230659758949 139.73851843244464 29.92 35.6722973341591 139.73848750208796 29.92 35.67230435336656 139.7384843455246 29.92 35.672313616789054 139.73851526483705 29.92 35.67230659758949 139.73851843244464 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be8d83ec-4d56-4b8e-b294-82a8c0fcb440">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67233109834853 139.7385202703321 29.92 35.67233508387062 139.73853356563913 29.92 35.67232753304379 139.73853696585167 29.92 35.67232354752207 139.73852367054567 29.92 35.67233109834853 139.7385202703321 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4c3cb72-9441-441d-87ac-b781333aeef8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67232147937259 139.7385414799925 29.92 35.67231447819109 139.73854463653026 29.92 35.67230773625811 139.73852216482337 29.92 35.67231473743903 139.73851900828393 29.92 35.67232147937259 139.7385414799925 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2aa48acc-095e-4476-9917-d9c962e1a0bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2aa48acc-095e-4476-9917-d9c962e1a0bf_0">
											<gml:posList>35.67230773625811 139.73852216482337 29.92 35.67230773625811 139.73852216482337 32.149 35.67231473743903 139.73851900828393 32.149 35.67231473743903 139.73851900828393 29.92 35.67230773625811 139.73852216482337 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a32dfab-8b49-4913-83fe-f61940eda040">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a32dfab-8b49-4913-83fe-f61940eda040_0">
											<gml:posList>35.672322563738526 139.73846481581398 30.33 35.67231824471863 139.73845154300017 30.33 35.67231824471863 139.73845154300017 31.28 35.672322563738526 139.73846481581398 31.28 35.672322563738526 139.73846481581398 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-414b97a6-b0ea-4236-a014-03edc588a2fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-414b97a6-b0ea-4236-a014-03edc588a2fd_0">
											<gml:posList>35.67232354752207 139.73852367054567 29.92 35.67232753304379 139.73853696585167 29.92 35.67232753304379 139.73853696585167 32.228 35.67232354752207 139.73852367054567 32.228 35.67232354752207 139.73852367054567 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ebedebd-ea88-4f4b-a630-ec68ec1121ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ebedebd-ea88-4f4b-a630-ec68ec1121ee_0">
											<gml:posList>35.67233109834853 139.7385202703321 29.92 35.67232354752207 139.73852367054567 29.92 35.67232354752207 139.73852367054567 32.228 35.67233109834853 139.7385202703321 32.228 35.67233109834853 139.7385202703321 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fe863a7-53b8-4619-832d-232c269db3b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fe863a7-53b8-4619-832d-232c269db3b0_0">
											<gml:posList>35.67232753304379 139.73853696585167 32.228 35.67233508387062 139.73853356563913 32.228 35.67233109834853 139.7385202703321 32.228 35.67232354752207 139.73852367054567 32.228 35.67232753304379 139.73853696585167 32.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c527b83-a4b8-426d-aefa-ac5ea648bc9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c527b83-a4b8-426d-aefa-ac5ea648bc9d_0">
											<gml:posList>35.67232753304379 139.73853696585167 29.92 35.67233508387062 139.73853356563913 29.92 35.67233508387062 139.73853356563913 32.228 35.67232753304379 139.73853696585167 32.228 35.67232753304379 139.73853696585167 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2c9ca9b-1c30-4510-9457-184be58c557e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2c9ca9b-1c30-4510-9457-184be58c557e_0">
											<gml:posList>35.67233508387062 139.73853356563913 29.92 35.67233109834853 139.7385202703321 29.92 35.67233109834853 139.7385202703321 32.228 35.67233508387062 139.73853356563913 32.228 35.67233508387062 139.73853356563913 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ddb9b7f-54d2-45c4-aa1b-c6338ece3192">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ddb9b7f-54d2-45c4-aa1b-c6338ece3192_0">
											<gml:posList>35.672225624102815 139.73840001016404 29.92 35.67223175284708 139.7384221290751 29.92 35.67223175284708 139.7384221290751 32.093 35.672225624102815 139.73840001016404 32.093 35.672225624102815 139.73840001016404 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a1b0996-5f3c-482a-b233-c811e07bec45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a1b0996-5f3c-482a-b233-c811e07bec45_0">
											<gml:posList>35.67223247229125 139.73839716310076 29.92 35.672225624102815 139.73840001016404 29.92 35.672225624102815 139.73840001016404 32.093 35.67223247229125 139.73839716310076 32.093 35.67223247229125 139.73839716310076 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dad15c0-65ee-4da7-835a-5be401f2bdce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dad15c0-65ee-4da7-835a-5be401f2bdce_0">
											<gml:posList>35.67223247229125 139.73839716310076 32.093 35.672225624102815 139.73840001016404 32.093 35.67223175284708 139.7384221290751 32.093 35.67223859203102 139.73841929307065 32.093 35.67223247229125 139.73839716310076 32.093</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d8c343c-69f2-43a6-a818-7cef09678bcd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d8c343c-69f2-43a6-a818-7cef09678bcd_0">
											<gml:posList>35.67223175284708 139.7384221290751 29.92 35.67223859203102 139.73841929307065 29.92 35.67223859203102 139.73841929307065 32.093 35.67223175284708 139.7384221290751 32.093 35.67223175284708 139.7384221290751 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da44bdad-5e7f-4a01-9502-d65f0fee7c38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da44bdad-5e7f-4a01-9502-d65f0fee7c38_0">
											<gml:posList>35.67223859203102 139.73841929307065 29.92 35.67223247229125 139.73839716310076 29.92 35.67223247229125 139.73839716310076 32.093 35.67223859203102 139.73841929307065 32.093 35.67223859203102 139.73841929307065 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd70897c-7dbf-4794-b482-fca754c83b38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd70897c-7dbf-4794-b482-fca754c83b38_0">
											<gml:posList>35.67223776714598 139.73843628358756 29.92 35.67223762428457 139.73843800701303 29.92 35.67223762428457 139.73843800701303 33.439 35.67223776714598 139.73843628358756 33.439 35.67223776714598 139.73843628358756 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ccdeb78-481f-4c70-9e05-05c746f47e80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ccdeb78-481f-4c70-9e05-05c746f47e80_0">
											<gml:posList>35.67223762428457 139.73843800701303 29.92 35.672237769870875 139.7384397411436 29.92 35.672237769870875 139.7384397411436 33.439 35.67223762428457 139.73843800701303 33.439 35.67223762428457 139.73843800701303 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eebb800a-a53a-4ab8-a56c-a69c4d3cfe29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eebb800a-a53a-4ab8-a56c-a69c4d3cfe29_0">
											<gml:posList>35.672237769870875 139.7384397411436 29.92 35.67223821284894 139.73844139759657 29.92 35.67223821284894 139.73844139759657 33.439 35.672237769870875 139.7384397411436 33.439 35.672237769870875 139.7384397411436 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eeed75a2-393c-498d-84d9-b790922a7c9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eeed75a2-393c-498d-84d9-b790922a7c9a_0">
											<gml:posList>35.67223820751233 139.73843462608903 29.92 35.67223776714598 139.73843628358756 29.92 35.67223776714598 139.73843628358756 33.439 35.67223820751233 139.73843462608903 33.439 35.67223820751233 139.73843462608903 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-988438a7-147f-4dc8-bf3c-28f504a669a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-988438a7-147f-4dc8-bf3c-28f504a669a6_0">
											<gml:posList>35.672238918412134 139.73843312292146 29.92 35.67223820751233 139.73843462608903 29.92 35.67223820751233 139.73843462608903 33.439 35.672238918412134 139.73843312292146 33.439 35.672238918412134 139.73843312292146 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-181620fa-f58c-4c8b-8f4e-e54f336cd23e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-181620fa-f58c-4c8b-8f4e-e54f336cd23e_0">
											<gml:posList>35.67223821284894 139.73844139759657 29.92 35.672238926116705 139.73844289907842 29.92 35.672238926116705 139.73844289907842 33.439 35.67223821284894 139.73844139759657 33.439 35.67223821284894 139.73844139759657 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62af7512-061b-4a5b-b465-4494d1b2c80c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62af7512-061b-4a5b-b465-4494d1b2c80c_0">
											<gml:posList>35.672238926116705 139.73844289907842 29.92 35.67223987357575 139.73844419039932 29.92 35.67223987357575 139.73844419039932 33.439 35.672238926116705 139.73844289907842 33.439 35.672238926116705 139.73844289907842 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d9d4c1d-04c8-467b-aa8a-e0bbb116d1cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d9d4c1d-04c8-467b-aa8a-e0bbb116d1cd_0">
											<gml:posList>35.67223986383404 139.73843182936005 29.92 35.672238918412134 139.73843312292146 29.92 35.672238918412134 139.73843312292146 33.439 35.67223986383404 139.73843182936005 33.439 35.67223986383404 139.73843182936005 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c63fa01c-1f7c-4368-80bc-d0a692f61dd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c63fa01c-1f7c-4368-80bc-d0a692f61dd6_0">
											<gml:posList>35.672241007766715 139.73843080068 29.92 35.67223986383404 139.73843182936005 29.92 35.67223986383404 139.73843182936005 33.439 35.672241007766715 139.73843080068 33.439 35.672241007766715 139.73843080068 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dac72ceb-6467-4262-89df-2f56eb8c8f0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dac72ceb-6467-4262-89df-2f56eb8c8f0a_0">
											<gml:posList>35.67223987357575 139.73844419039932 29.92 35.6722410281414 139.73844521635877 29.92 35.6722410281414 139.73844521635877 33.439 35.67223987357575 139.73844419039932 33.439 35.67223987357575 139.73844419039932 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e476dce-1c60-4019-adc9-87726b5922e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e476dce-1c60-4019-adc9-87726b5922e4_0">
											<gml:posList>35.672241007766715 139.73843080068 29.92 35.672241007766715 139.73843080068 33.439 35.672242305185094 139.7384300921672 33.439 35.672242305185094 139.7384300921672 29.92 35.672241007766715 139.73843080068 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc35b33c-f978-45d7-b734-1e97f4666bda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc35b33c-f978-45d7-b734-1e97f4666bda_0">
											<gml:posList>35.6722410281414 139.73844521635877 29.92 35.67224232667412 139.7384459217989 29.92 35.67224232667412 139.7384459217989 33.439 35.6722410281414 139.73844521635877 33.439 35.6722410281414 139.73844521635877 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6ee9582-57ed-4429-a496-581e7a0c2d4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6ee9582-57ed-4429-a496-581e7a0c2d4e_0">
											<gml:posList>35.67223852796037 139.7383951896502 29.92 35.67224486270619 139.7384156402966 29.92 35.67224486270619 139.7384156402966 32.093 35.67223852796037 139.7383951896502 32.093 35.67223852796037 139.7383951896502 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ffe2e90-675c-4771-8950-681729b34d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ffe2e90-675c-4771-8950-681729b34d9b_0">
											<gml:posList>35.67223852796037 139.7383951896502 29.92 35.67223852796037 139.7383951896502 32.093 35.67224617781226 139.73839163465965 32.093 35.67224617781226 139.73839163465965 29.92 35.67223852796037 139.7383951896502 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cecb3f79-2fb8-4038-adf6-4dec471bd3cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cecb3f79-2fb8-4038-adf6-4dec471bd3cc_0">
											<gml:posList>35.672243693010564 139.73842972598933 29.92 35.672242305185094 139.7384300921672 29.92 35.672242305185094 139.7384300921672 33.439 35.672243693010564 139.73842972598933 33.439 35.672243693010564 139.73842972598933 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7c9c533-b522-441b-8b65-de33ac474cd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7c9c533-b522-441b-8b65-de33ac474cd9_0">
											<gml:posList>35.67224371506546 139.73844627364417 29.92 35.67224371506546 139.73844627364417 33.439 35.67224232667412 139.7384459217989 33.439 35.67224232667412 139.7384459217989 29.92 35.67224371506546 139.73844627364417 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca409261-50b1-489e-864b-39e90ee79777">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca409261-50b1-489e-864b-39e90ee79777_0">
											<gml:posList>35.67224511717822 139.73842972430347 29.92 35.672243693010564 139.73842972598933 29.92 35.672243693010564 139.73842972598933 33.439 35.67224511717822 139.73842972430347 33.439 35.67224511717822 139.73842972430347 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c477efe4-9d37-414e-93ba-966fa43b82ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c477efe4-9d37-414e-93ba-966fa43b82ac_0">
											<gml:posList>35.67223986383404 139.73843182936005 33.439 35.672238918412134 139.73843312292146 33.439 35.67223820751233 139.73843462608903 33.439 35.67223776714598 139.73843628358756 33.439 35.67223762428457 139.73843800701303 33.439 35.672237769870875 139.7384397411436 33.439 35.67223821284894 139.73844139759657 33.439 35.672238926116705 139.73844289907842 33.439 35.67223987357575 139.73844419039932 33.439 35.6722410281414 139.73844521635877 33.439 35.67224232667412 139.7384459217989 33.439 35.67224371506546 139.73844627364417 33.439 35.67224513021941 139.73844627196928 33.439 35.67224651805363 139.73844591683817 33.439 35.67224781546339 139.73844519727908 33.439 35.67224895940488 139.7384441796456 33.439 35.67224991384062 139.7384428860735 33.439 35.672250615718106 139.73844137186995 33.439 35.67225105609323 139.73843972541766 33.439 35.67225119894596 139.73843799094544 33.439 35.67225105335963 139.7384362568146 33.439 35.67225061039019 139.73843461140788 33.439 35.67224989711363 139.73843309887937 33.439 35.67224894965446 139.7384318075584 33.439 35.67224779509739 139.73843079264557 33.439 35.672246505578315 139.73843008719498 33.439 35.67224511717822 139.73842972430347 33.439 35.672243693010564 139.73842972598933 33.439 35.672242305185094 139.7384300921672 33.439 35.672241007766715 139.73843080068 33.439 35.67223986383404 139.73843182936005 33.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22f96801-7f32-44b9-956d-0733bbbe957f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22f96801-7f32-44b9-956d-0733bbbe957f_0">
											<gml:posList>35.67224371506546 139.73844627364417 29.92 35.67224513021941 139.73844627196928 29.92 35.67224513021941 139.73844627196928 33.439 35.67224371506546 139.73844627364417 33.439 35.67224371506546 139.73844627364417 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d8278fb-c2d4-448e-bfd1-377da8f68d05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d8278fb-c2d4-448e-bfd1-377da8f68d05_0">
											<gml:posList>35.672252503544975 139.7384120853184 32.093 35.67224617781226 139.73839163465965 32.093 35.67223852796037 139.7383951896502 32.093 35.67224486270619 139.7384156402966 32.093 35.672252503544975 139.7384120853184 32.093</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fdfee393-0c05-48d1-a035-0ea3699e5ac7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fdfee393-0c05-48d1-a035-0ea3699e5ac7_0">
											<gml:posList>35.67224511717822 139.73842972430347 29.92 35.67224511717822 139.73842972430347 33.439 35.672246505578315 139.73843008719498 33.439 35.672246505578315 139.73843008719498 29.92 35.67224511717822 139.73842972430347 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30168aab-3f81-4298-9dba-d5cc14be6657">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30168aab-3f81-4298-9dba-d5cc14be6657_0">
											<gml:posList>35.67224513021941 139.73844627196928 29.92 35.67224651805363 139.73844591683817 29.92 35.67224651805363 139.73844591683817 33.439 35.67224513021941 139.73844627196928 33.439 35.67224513021941 139.73844627196928 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5592c9e6-a508-4363-bd6a-481ae31d02b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5592c9e6-a508-4363-bd6a-481ae31d02b9_0">
											<gml:posList>35.672246505578315 139.73843008719498 29.92 35.672246505578315 139.73843008719498 33.439 35.67224779509739 139.73843079264557 33.439 35.67224779509739 139.73843079264557 29.92 35.672246505578315 139.73843008719498 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88a2b191-17c4-4307-8877-107defc4de59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88a2b191-17c4-4307-8877-107defc4de59_0">
											<gml:posList>35.67224651805363 139.73844591683817 29.92 35.67224781546339 139.73844519727908 29.92 35.67224781546339 139.73844519727908 33.439 35.67224651805363 139.73844591683817 33.439 35.67224651805363 139.73844591683817 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b33e4757-b95b-4850-8091-bd9def71634f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b33e4757-b95b-4850-8091-bd9def71634f_0">
											<gml:posList>35.67224829486007 139.73847019497882 29.92 35.672248323250145 139.7384719071553 29.92 35.672248323250145 139.7384719071553 33.46 35.67224829486007 139.73847019497882 33.46 35.67224829486007 139.73847019497882 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab8e2874-2f31-4173-9639-a2ae72662a74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab8e2874-2f31-4173-9639-a2ae72662a74_0">
											<gml:posList>35.67224779509739 139.73843079264557 29.92 35.67224779509739 139.73843079264557 33.439 35.67224894965446 139.7384318075584 33.439 35.67224894965446 139.7384318075584 29.92 35.67224779509739 139.73843079264557 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6763e740-6b22-4af6-9f3b-f35e6067a944">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6763e740-6b22-4af6-9f3b-f35e6067a944_0">
											<gml:posList>35.67224781546339 139.73844519727908 29.92 35.67224895940488 139.7384441796456 29.92 35.67224895940488 139.7384441796456 33.439 35.67224781546339 139.73844519727908 33.439 35.67224781546339 139.73844519727908 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-866b68ef-03d8-4c05-aa01-4013f9bb3122">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-866b68ef-03d8-4c05-aa01-4013f9bb3122_0">
											<gml:posList>35.67224855494379 139.73846852664704 29.92 35.67224829486007 139.73847019497882 29.92 35.67224829486007 139.73847019497882 33.46 35.67224855494379 139.73846852664704 33.46 35.67224855494379 139.73846852664704 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0c040b8-cfcd-4fab-99b7-67b34fabc3fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0c040b8-cfcd-4fab-99b7-67b34fabc3fa_0">
											<gml:posList>35.6722486400444 139.7384735748045 29.92 35.6722486400444 139.7384735748045 33.46 35.672248323250145 139.7384719071553 33.46 35.672248323250145 139.7384719071553 29.92 35.6722486400444 139.7384735748045 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b54d232b-7f81-46be-93e8-f69d3ff33651">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b54d232b-7f81-46be-93e8-f69d3ff33651_0">
											<gml:posList>35.672252503544975 139.7384120853184 29.92 35.672252503544975 139.7384120853184 32.093 35.67224486270619 139.7384156402966 32.093 35.67224486270619 139.7384156402966 29.92 35.672252503544975 139.7384120853184 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13ed37ef-9d97-4c3d-8e07-2e17eeb41279">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13ed37ef-9d97-4c3d-8e07-2e17eeb41279_0">
											<gml:posList>35.672249103536146 139.738466946346 29.92 35.67224855494379 139.73846852664704 29.92 35.67224855494379 139.73846852664704 33.46 35.672249103536146 139.738466946346 33.46 35.672249103536146 139.738466946346 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-651bfdf4-161e-4c73-9fc9-4faa2167d7c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-651bfdf4-161e-4c73-9fc9-4faa2167d7c0_0">
											<gml:posList>35.672249227154495 139.73847512062213 29.92 35.672249227154495 139.73847512062213 33.46 35.6722486400444 139.7384735748045 33.46 35.6722486400444 139.7384735748045 29.92 35.672249227154495 139.73847512062213 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4619708-b20a-4426-aa05-50179c4ece04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4619708-b20a-4426-aa05-50179c4ece04_0">
											<gml:posList>35.672252503544975 139.7384120853184 29.92 35.67224617781226 139.73839163465965 29.92 35.67224617781226 139.73839163465965 32.093 35.672252503544975 139.7384120853184 32.093 35.672252503544975 139.7384120853184 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5921b883-4160-49e4-bd23-ca5d7adef717">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5921b883-4160-49e4-bd23-ca5d7adef717_0">
											<gml:posList>35.67224989711363 139.73843309887937 29.92 35.67224894965446 139.7384318075584 29.92 35.67224894965446 139.7384318075584 33.439 35.67224989711363 139.73843309887937 33.439 35.67224989711363 139.73843309887937 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9ceb0ab-95d6-4872-812f-8bf2acf433a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9ceb0ab-95d6-4872-812f-8bf2acf433a0_0">
											<gml:posList>35.67224895940488 139.7384441796456 29.92 35.67224991384062 139.7384428860735 29.92 35.67224991384062 139.7384428860735 33.439 35.67224895940488 139.7384441796456 33.439 35.67224895940488 139.7384441796456 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-083b49c9-0e5b-4556-8337-654b843727ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-083b49c9-0e5b-4556-8337-654b843727ee_0">
											<gml:posList>35.67224989563815 139.7384655425011 29.92 35.672249103536146 139.738466946346 29.92 35.672249103536146 139.738466946346 33.46 35.67224989563815 139.7384655425011 33.46 35.67224989563815 139.7384655425011 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1c3dbad-8882-4966-8680-bbfa6d4d0502">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1c3dbad-8882-4966-8680-bbfa6d4d0502_0">
											<gml:posList>35.672249227154495 139.73847512062213 29.92 35.672250066509484 139.73847648939713 29.92 35.672250066509484 139.73847648939713 33.46 35.672249227154495 139.73847512062213 33.46 35.672249227154495 139.73847512062213 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25a8a181-ccb0-47bd-83a6-411423a34013">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25a8a181-ccb0-47bd-83a6-411423a34013_0">
											<gml:posList>35.67224989711363 139.73843309887937 29.92 35.67224989711363 139.73843309887937 33.439 35.67225061039019 139.73843461140788 33.439 35.67225061039019 139.73843461140788 29.92 35.67224989711363 139.73843309887937 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07bca0d1-8913-48fc-8717-63710dc2c5d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07bca0d1-8913-48fc-8717-63710dc2c5d7_0">
											<gml:posList>35.672250615718106 139.73844137186995 29.92 35.672250615718106 139.73844137186995 33.439 35.67224991384062 139.7384428860735 33.439 35.67224991384062 139.7384428860735 29.92 35.672250615718106 139.73844137186995 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e410288-ef5d-4828-a995-defaf0ca1daf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e410288-ef5d-4828-a995-defaf0ca1daf_0">
											<gml:posList>35.6722509132746 139.73846438141265 29.92 35.67224989563815 139.7384655425011 29.92 35.67224989563815 139.7384655425011 33.46 35.6722509132746 139.73846438141265 33.46 35.6722509132746 139.73846438141265 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ff30b0b-da4d-449b-82b3-1e5c5f0c9a2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ff30b0b-da4d-449b-82b3-1e5c5f0c9a2e_0">
											<gml:posList>35.672250066509484 139.73847648939713 29.92 35.67225112199357 139.73847760384652 29.92 35.67225112199357 139.73847760384652 33.46 35.672250066509484 139.73847648939713 33.46 35.672250066509484 139.73847648939713 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d657d31c-2b10-4718-b5f9-36f796cb5cdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d657d31c-2b10-4718-b5f9-36f796cb5cdf_0">
											<gml:posList>35.67225105335963 139.7384362568146 29.92 35.67225061039019 139.73843461140788 29.92 35.67225061039019 139.73843461140788 33.439 35.67225105335963 139.7384362568146 33.439 35.67225105335963 139.7384362568146 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-989fc315-7318-4060-8904-0db7811a6066">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-989fc315-7318-4060-8904-0db7811a6066_0">
											<gml:posList>35.67225105609323 139.73843972541766 29.92 35.67225105609323 139.73843972541766 33.439 35.672250615718106 139.73844137186995 33.439 35.672250615718106 139.73844137186995 29.92 35.67225105609323 139.73843972541766 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ea6776d-44c4-4b8f-a55e-f3d98cdec4ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ea6776d-44c4-4b8f-a55e-f3d98cdec4ff_0">
											<gml:posList>35.67225119894596 139.73843799094544 29.92 35.67225105335963 139.7384362568146 29.92 35.67225105335963 139.7384362568146 33.439 35.67225119894596 139.73843799094544 33.439 35.67225119894596 139.73843799094544 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bb9f67f-1d8c-4f33-9317-6e0270b9be5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bb9f67f-1d8c-4f33-9317-6e0270b9be5c_0">
											<gml:posList>35.67225105609323 139.73843972541766 29.92 35.67225119894596 139.73843799094544 29.92 35.67225119894596 139.73843799094544 33.439 35.67225105609323 139.73843972541766 33.439 35.67225105609323 139.73843972541766 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24072957-92b1-4b86-b20e-32852e4ad04a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24072957-92b1-4b86-b20e-32852e4ad04a_0">
											<gml:posList>35.6722509132746 139.73846438141265 29.92 35.6722509132746 139.73846438141265 33.46 35.67225211140301 139.73846349627348 33.46 35.67225211140301 139.73846349627348 29.92 35.6722509132746 139.73846438141265 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7146ec3f-7ef0-4fc4-b121-98c187d78003">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7146ec3f-7ef0-4fc4-b121-98c187d78003_0">
											<gml:posList>35.67225112199357 139.73847760384652 29.92 35.67225234851206 139.73847843088416 29.92 35.67225234851206 139.73847843088416 33.46 35.67225112199357 139.73847760384652 33.46 35.67225112199357 139.73847760384652 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a86f4294-dee3-440a-9140-dde15702cebd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a86f4294-dee3-440a-9140-dde15702cebd_0">
											<gml:posList>35.672253426962165 139.73846293134437 29.92 35.67225211140301 139.73846349627348 29.92 35.67225211140301 139.73846349627348 33.46 35.672253426962165 139.73846293134437 33.46 35.672253426962165 139.73846293134437 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71bc865b-b2e4-4cca-9e2d-f5d73243b6b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71bc865b-b2e4-4cca-9e2d-f5d73243b6b2_0">
											<gml:posList>35.67225234851206 139.73847843088416 29.92 35.67225368293411 139.73847892639864 29.92 35.67225368293411 139.73847892639864 33.46 35.67225234851206 139.73847843088416 33.46 35.67225234851206 139.73847843088416 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-737e26c0-36ca-4a5c-b7f3-a1bfecf0881a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-737e26c0-36ca-4a5c-b7f3-a1bfecf0881a_0">
											<gml:posList>35.67225481490958 139.73846271981813 29.92 35.672253426962165 139.73846293134437 29.92 35.672253426962165 139.73846293134437 33.46 35.67225481490958 139.73846271981813 33.46 35.67225481490958 139.73846271981813 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3463a84f-c21d-480d-894a-61e4a8fa974f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3463a84f-c21d-480d-894a-61e4a8fa974f_0">
											<gml:posList>35.67225368293411 139.73847892639864 29.92 35.672255071160016 139.73847906836087 29.92 35.672255071160016 139.73847906836087 33.46 35.67225368293411 139.73847892639864 33.46 35.67225368293411 139.73847892639864 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c69097ca-4749-4c93-b699-a1fd65d43cda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c69097ca-4749-4c93-b699-a1fd65d43cda_0">
											<gml:posList>35.67224855494379 139.73846852664704 33.46 35.67224829486007 139.73847019497882 33.46 35.672248323250145 139.7384719071553 33.46 35.6722486400444 139.7384735748045 33.46 35.672249227154495 139.73847512062213 33.46 35.672250066509484 139.73847648939713 33.46 35.67225112199357 139.73847760384652 33.46 35.67225234851206 139.73847843088416 33.46 35.67225368293411 139.73847892639864 33.46 35.672255071160016 139.73847906836087 33.46 35.67225645910747 139.73847885683492 33.46 35.672257774675394 139.73847830295253 33.46 35.67225896379019 139.73847741782419 33.46 35.67225999043177 139.73847624567858 33.46 35.67226078253387 139.73847484183355 33.46 35.67226132212129 139.73847327258952 33.46 35.672261591210074 139.7384715932003 33.46 35.67226156282 139.73846988102352 33.46 35.67226124603439 139.73846822442061 33.46 35.67226064990178 139.73846666756694 33.46 35.672259810555396 139.73846530983838 33.46 35.67225875507119 139.73846419538899 33.46 35.67225753756633 139.73846336834086 33.46 35.67225620313551 139.73846286178014 33.46 35.67225481490958 139.73846271981813 33.46 35.672253426962165 139.73846293134437 33.46 35.67225211140301 139.73846349627348 33.46 35.6722509132746 139.73846438141265 33.46 35.67224989563815 139.7384655425011 33.46 35.672249103536146 139.738466946346 33.46 35.67224855494379 139.73846852664704 33.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fff50418-6ca0-481d-aa5a-1e856c5ae0bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fff50418-6ca0-481d-aa5a-1e856c5ae0bf_0">
											<gml:posList>35.67225620313551 139.73846286178014 29.92 35.67225481490958 139.73846271981813 29.92 35.67225481490958 139.73846271981813 33.46 35.67225620313551 139.73846286178014 33.46 35.67225620313551 139.73846286178014 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1c6fc76-6159-4f20-84a0-dde7000a9062">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1c6fc76-6159-4f20-84a0-dde7000a9062_0">
											<gml:posList>35.672255071160016 139.73847906836087 29.92 35.67225645910747 139.73847885683492 29.92 35.67225645910747 139.73847885683492 33.46 35.672255071160016 139.73847906836087 33.46 35.672255071160016 139.73847906836087 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3c8ea52-b659-4608-af6e-e3a93ff13496">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3c8ea52-b659-4608-af6e-e3a93ff13496_0">
											<gml:posList>35.67225405826579 139.7384862497956 29.92 35.67225760021408 139.73849712642547 29.92 35.67225760021408 139.73849712642547 30.985 35.67225405826579 139.7384862497956 30.985 35.67225405826579 139.7384862497956 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b114fc8e-5dea-4d4d-8149-6cba258e24f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b114fc8e-5dea-4d4d-8149-6cba258e24f4_0">
											<gml:posList>35.67225753756633 139.73846336834086 29.92 35.67225620313551 139.73846286178014 29.92 35.67225620313551 139.73846286178014 33.46 35.67225753756633 139.73846336834086 33.46 35.67225753756633 139.73846336834086 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1127da9c-de3a-4f3c-80f9-1f5a2a123e25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1127da9c-de3a-4f3c-80f9-1f5a2a123e25_0">
											<gml:posList>35.672257774675394 139.73847830295253 29.92 35.672257774675394 139.73847830295253 33.46 35.67225645910747 139.73847885683492 33.46 35.67225645910747 139.73847885683492 29.92 35.672257774675394 139.73847830295253 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2d6ebb8-2bd3-45d2-8ccf-508f0fd6d87a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2d6ebb8-2bd3-45d2-8ccf-508f0fd6d87a_0">
											<gml:posList>35.67225875507119 139.73846419538899 29.92 35.67225753756633 139.73846336834086 29.92 35.67225753756633 139.73846336834086 33.46 35.67225875507119 139.73846419538899 33.46 35.67225875507119 139.73846419538899 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffa215a5-f4fd-45aa-90f9-eec2dfe2af3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffa215a5-f4fd-45aa-90f9-eec2dfe2af3a_0">
											<gml:posList>35.672257774675394 139.73847830295253 29.92 35.67225896379019 139.73847741782419 29.92 35.67225896379019 139.73847741782419 33.46 35.672257774675394 139.73847830295253 33.46 35.672257774675394 139.73847830295253 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95e9d1ac-8740-4da0-a400-90b82824ae35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95e9d1ac-8740-4da0-a400-90b82824ae35_0">
											<gml:posList>35.672259810555396 139.73846530983838 29.92 35.67225875507119 139.73846419538899 29.92 35.67225875507119 139.73846419538899 33.46 35.672259810555396 139.73846530983838 33.46 35.672259810555396 139.73846530983838 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5eb96a06-99d1-4c95-9ef3-1221c955197e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5eb96a06-99d1-4c95-9ef3-1221c955197e_0">
											<gml:posList>35.67225896379019 139.73847741782419 29.92 35.67225999043177 139.73847624567858 29.92 35.67225999043177 139.73847624567858 33.46 35.67225896379019 139.73847741782419 33.46 35.67225896379019 139.73847741782419 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d49ba08-0329-4ded-b772-c48d4f3ea087">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d49ba08-0329-4ded-b772-c48d4f3ea087_0">
											<gml:posList>35.67226064990178 139.73846666756694 29.92 35.672259810555396 139.73846530983838 29.92 35.672259810555396 139.73846530983838 33.46 35.67226064990178 139.73846666756694 33.46 35.67226064990178 139.73846666756694 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9837ec81-0b2d-4569-a7a6-23d14e1810c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9837ec81-0b2d-4569-a7a6-23d14e1810c5_0">
											<gml:posList>35.67225999043177 139.73847624567858 29.92 35.67226078253387 139.73847484183355 29.92 35.67226078253387 139.73847484183355 33.46 35.67225999043177 139.73847624567858 33.46 35.67225999043177 139.73847624567858 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9406075e-892a-403b-b603-154c2485767f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9406075e-892a-403b-b603-154c2485767f_0">
											<gml:posList>35.67225405826579 139.7384862497956 29.92 35.67225405826579 139.7384862497956 30.985 35.67226751958506 139.7384796611913 30.985 35.67226751958506 139.7384796611913 29.92 35.67225405826579 139.7384862497956 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-665fbbf9-0ea6-4f98-a725-65e54592cd28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-665fbbf9-0ea6-4f98-a725-65e54592cd28_0">
											<gml:posList>35.67226124603439 139.73846822442061 29.92 35.67226064990178 139.73846666756694 29.92 35.67226064990178 139.73846666756694 33.46 35.67226124603439 139.73846822442061 33.46 35.67226124603439 139.73846822442061 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0de544f-80c8-4af5-9ef4-40550c0ad772">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0de544f-80c8-4af5-9ef4-40550c0ad772_0">
											<gml:posList>35.67226078253387 139.73847484183355 29.92 35.67226132212129 139.73847327258952 29.92 35.67226132212129 139.73847327258952 33.46 35.67226078253387 139.73847484183355 33.46 35.67226078253387 139.73847484183355 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47f75b45-a181-48e2-b3fa-870cb6f31cad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47f75b45-a181-48e2-b3fa-870cb6f31cad_0">
											<gml:posList>35.67225760021408 139.73849712642547 29.92 35.6722649345627 139.73849353867746 29.92 35.6722649345627 139.73849353867746 30.985 35.67225760021408 139.73849712642547 30.985 35.67225760021408 139.73849712642547 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0de2c307-b1f0-4f16-ae97-be4687519114">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0de2c307-b1f0-4f16-ae97-be4687519114_0">
											<gml:posList>35.67226156282 139.73846988102352 29.92 35.67226124603439 139.73846822442061 29.92 35.67226124603439 139.73846822442061 33.46 35.67226156282 139.73846988102352 33.46 35.67226156282 139.73846988102352 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52a60329-e59b-4558-8dca-17e566d29082">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52a60329-e59b-4558-8dca-17e566d29082_0">
											<gml:posList>35.67226132212129 139.73847327258952 29.92 35.672261591210074 139.7384715932003 29.92 35.672261591210074 139.7384715932003 33.46 35.67226132212129 139.73847327258952 33.46 35.67226132212129 139.73847327258952 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b881767a-ca2b-4c96-ba08-f5b5b1e62245">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b881767a-ca2b-4c96-ba08-f5b5b1e62245_0">
											<gml:posList>35.67226156282 139.73846988102352 29.92 35.67226156282 139.73846988102352 33.46 35.672261591210074 139.7384715932003 33.46 35.672261591210074 139.7384715932003 29.92 35.67226156282 139.73846988102352 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0305c36f-8593-4b82-8650-e50752e88ce5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0305c36f-8593-4b82-8650-e50752e88ce5_0">
											<gml:posList>35.67227178438036 139.73849275731803 30.985 35.67226751958506 139.7384796611913 30.985 35.67225405826579 139.7384862497956 30.985 35.67225760021408 139.73849712642547 30.985 35.6722649345627 139.73849353867746 30.985 35.67226565740905 139.7384957581727 30.985 35.67227178438036 139.73849275731803 30.985</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66a46241-4e99-49fa-a970-0ea0259008d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66a46241-4e99-49fa-a970-0ea0259008d5_0">
											<gml:posList>35.67226565740905 139.7384957581727 29.92 35.67226565740905 139.7384957581727 30.985 35.6722649345627 139.73849353867746 30.985 35.6722649345627 139.73849353867746 29.92 35.67226565740905 139.7384957581727 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61f9ca04-d0ba-4ae8-ad01-bfcec094a928">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61f9ca04-d0ba-4ae8-ad01-bfcec094a928_0">
											<gml:posList>35.67227178438036 139.73849275731803 29.92 35.67227178438036 139.73849275731803 30.985 35.67226565740905 139.7384957581727 30.985 35.67226565740905 139.7384957581727 29.92 35.67227178438036 139.73849275731803 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-896808b8-a052-4d7a-aa19-fd364269f1b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-896808b8-a052-4d7a-aa19-fd364269f1b0_0">
											<gml:posList>35.67227178438036 139.73849275731803 29.92 35.67226751958506 139.7384796611913 29.92 35.67226751958506 139.7384796611913 30.985 35.67227178438036 139.73849275731803 30.985 35.67227178438036 139.73849275731803 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efb15235-7c98-4150-b9a3-d759fbdbb0d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efb15235-7c98-4150-b9a3-d759fbdbb0d1_0">
											<gml:posList>35.67227757011709 139.73847994755627 29.92 35.67228213234769 139.73849302123978 29.92 35.67228213234769 139.73849302123978 31.28 35.67227757011709 139.73847994755627 31.28 35.67227757011709 139.73847994755627 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26e397bc-dbc3-493c-9ba1-f5047d5ef085">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26e397bc-dbc3-493c-9ba1-f5047d5ef085_0">
											<gml:posList>35.67227757011709 139.73847994755627 29.92 35.67227757011709 139.73847994755627 31.28 35.6722871567637 139.7384749210931 31.28 35.6722871567637 139.7384749210931 29.92 35.67227757011709 139.73847994755627 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b025cc43-4f66-4a00-a255-9dd6ecbf6da4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b025cc43-4f66-4a00-a255-9dd6ecbf6da4_0">
											<gml:posList>35.6722871567637 139.7384749210931 31.28 35.67227757011709 139.73847994755627 31.28 35.67228213234769 139.73849302123978 31.28 35.67229171899483 139.73848799477787 31.28 35.6722871567637 139.7384749210931 31.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7517d3fc-baef-41df-acaf-aa9a37778ac5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7517d3fc-baef-41df-acaf-aa9a37778ac5_0">
											<gml:posList>35.67228213234769 139.73849302123978 29.92 35.67229171899483 139.73848799477787 29.92 35.67229171899483 139.73848799477787 31.28 35.67228213234769 139.73849302123978 31.28 35.67228213234769 139.73849302123978 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a1ecfd3-b656-453d-8918-3dd5dd1cfe53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a1ecfd3-b656-453d-8918-3dd5dd1cfe53_0">
											<gml:posList>35.67229171899483 139.73848799477787 29.92 35.6722871567637 139.7384749210931 29.92 35.6722871567637 139.7384749210931 31.28 35.67229171899483 139.73848799477787 31.28 35.67229171899483 139.73848799477787 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a307a839-e370-4b7b-9c02-44af5dfc29a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a307a839-e370-4b7b-9c02-44af5dfc29a9_0">
											<gml:posList>35.67230435336656 139.7384843455246 29.92 35.6722973341591 139.73848750208796 29.92 35.6722973341591 139.73848750208796 32.149 35.67230435336656 139.7384843455246 32.149 35.67230435336656 139.7384843455246 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-206ed9aa-ca67-44be-90e5-e4923629f909">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-206ed9aa-ca67-44be-90e5-e4923629f909_0">
											<gml:posList>35.67230659758949 139.73851843244464 32.149 35.6722973341591 139.73848750208796 32.149 35.6722973341591 139.73848750208796 29.92 35.67230659758949 139.73851843244464 29.92 35.67230659758949 139.73851843244464 32.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7a50d37-fd3f-42db-a87e-9897ecadcb71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7a50d37-fd3f-42db-a87e-9897ecadcb71_0">
											<gml:posList>35.67230659758949 139.73851843244464 32.149 35.672313616789054 139.73851526483705 32.149 35.67230435336656 139.7384843455246 32.149 35.6722973341591 139.73848750208796 32.149 35.67230659758949 139.73851843244464 32.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21f142eb-9d10-4010-9d3c-093f4790f5ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21f142eb-9d10-4010-9d3c-093f4790f5ab_0">
											<gml:posList>35.672313616789054 139.73851526483705 29.92 35.67230435336656 139.7384843455246 29.92 35.67230435336656 139.7384843455246 32.149 35.672313616789054 139.73851526483705 32.149 35.672313616789054 139.73851526483705 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f2af564-2419-42bf-815f-cf7a16af9343">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f2af564-2419-42bf-815f-cf7a16af9343_0">
											<gml:posList>35.672313616789054 139.73851526483705 29.92 35.672313616789054 139.73851526483705 32.149 35.67230659758949 139.73851843244464 32.149 35.67230659758949 139.73851843244464 29.92 35.672313616789054 139.73851526483705 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25420eb5-050f-4f46-a0a5-da3ed1d9fec9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25420eb5-050f-4f46-a0a5-da3ed1d9fec9_0">
											<gml:posList>35.67230773625811 139.73852216482337 29.92 35.67231447819109 139.73854463653026 29.92 35.67231447819109 139.73854463653026 32.149 35.67230773625811 139.73852216482337 32.149 35.67230773625811 139.73852216482337 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44e68a04-8aca-4800-a2b3-b0dc7e621200">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44e68a04-8aca-4800-a2b3-b0dc7e621200_0">
											<gml:posList>35.672314499558084 139.7384687579196 29.92 35.672314499558084 139.7384687579196 31.28 35.67231017152491 139.73845548511758 31.28 35.67231017152491 139.73845548511758 29.92 35.672314499558084 139.7384687579196 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f740dcb5-6b4a-4327-b1be-eedf9d814eeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f740dcb5-6b4a-4327-b1be-eedf9d814eeb_0">
											<gml:posList>35.67231017152491 139.73845548511758 29.92 35.67231017152491 139.73845548511758 31.28 35.67231824471863 139.73845154300017 31.28 35.67231824471863 139.73845154300017 30.33 35.67231531638274 139.73845297146764 30.33 35.67231531638274 139.73845297146764 29.92 35.67231017152491 139.73845548511758 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00b237e3-b82d-437d-bb21-af600e580cf2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00b237e3-b82d-437d-bb21-af600e580cf2_0">
											<gml:posList>35.67230773625811 139.73852216482337 32.149 35.67231447819109 139.73854463653026 32.149 35.67232147937259 139.7385414799925 32.149 35.67231473743903 139.73851900828393 32.149 35.67230773625811 139.73852216482337 32.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58babf74-ad97-49ee-911e-e206dad62cb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58babf74-ad97-49ee-911e-e206dad62cb0_0">
											<gml:posList>35.67231824471863 139.73845154300017 31.28 35.67231017152491 139.73845548511758 31.28 35.672314499558084 139.7384687579196 31.28 35.672322563738526 139.73846481581398 31.28 35.67231824471863 139.73845154300017 31.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98b8a852-4c20-47d2-971d-4d1a7346982f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98b8a852-4c20-47d2-971d-4d1a7346982f_0">
											<gml:posList>35.67231531638274 139.73845297146764 30.33 35.67231963540249 139.73846624428103 30.33 35.67231963540249 139.73846624428103 29.92 35.67231531638274 139.73845297146764 29.92 35.67231531638274 139.73845297146764 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cdd016d-e9a5-40e2-aafe-9ce40bd39011">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cdd016d-e9a5-40e2-aafe-9ce40bd39011_0">
											<gml:posList>35.67231447819109 139.73854463653026 29.92 35.67232147937259 139.7385414799925 29.92 35.67232147937259 139.7385414799925 32.149 35.67231447819109 139.73854463653026 32.149 35.67231447819109 139.73854463653026 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dba110cd-b0f9-4ac3-af7f-7b33dd209004">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dba110cd-b0f9-4ac3-af7f-7b33dd209004_0">
											<gml:posList>35.67231473743903 139.73851900828393 29.92 35.67231473743903 139.73851900828393 32.149 35.67232147937259 139.7385414799925 32.149 35.67232147937259 139.7385414799925 29.92 35.67231473743903 139.73851900828393 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2efca4d-4337-472f-90cd-b70bf41be705">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2efca4d-4337-472f-90cd-b70bf41be705_0">
											<gml:posList>35.67231963540249 139.73846624428103 30.33 35.672322563738526 139.73846481581398 30.33 35.672322563738526 139.73846481581398 31.28 35.672314499558084 139.7384687579196 31.28 35.672314499558084 139.7384687579196 29.92 35.67231963540249 139.73846624428103 29.92 35.67231963540249 139.73846624428103 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_009dc493-0720-454f-9cf2-03064b30b373_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bd15b7d-2b13-4282-8f5d-b8664408a0f8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67233852862434 139.73863858091778 9.66 35.67237503819206 139.73862070868844 9.66 35.67238143534402 139.7386403308237 9.66 35.67234492577341 139.7386582030455 9.66 35.67233852862434 139.73863858091778 9.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19908f48-bcb6-4305-a019-f8ca8c4b626a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19908f48-bcb6-4305-a019-f8ca8c4b626a_0">
											<gml:posList>35.67233852862434 139.73863858091778 28.19 35.67233852862434 139.73863858091778 9.66 35.67234492577341 139.7386582030455 9.66 35.67234492577341 139.7386582030455 28.19 35.67233852862434 139.73863858091778 28.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5247e6e-8f64-4ccc-9e74-efbc34f53840">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5247e6e-8f64-4ccc-9e74-efbc34f53840_0">
											<gml:posList>35.67237503819206 139.73862070868844 28.19 35.67237503819206 139.73862070868844 9.66 35.67233852862434 139.73863858091778 9.66 35.67233852862434 139.73863858091778 28.19 35.67237503819206 139.73862070868844 28.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f057984-777e-4888-8d38-b0bff86ee220">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f057984-777e-4888-8d38-b0bff86ee220_0">
											<gml:posList>35.67234492577341 139.7386582030455 28.19 35.67238143534402 139.7386403308237 28.19 35.67237503819206 139.73862070868844 28.19 35.67233852862434 139.73863858091778 28.19 35.67234492577341 139.7386582030455 28.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ee29116-496a-4bb5-bfa4-4fe522dedb0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ee29116-496a-4bb5-bfa4-4fe522dedb0b_0">
											<gml:posList>35.67234492577341 139.7386582030455 28.19 35.67234492577341 139.7386582030455 9.66 35.67238143534402 139.7386403308237 9.66 35.67238143534402 139.7386403308237 28.19 35.67234492577341 139.7386582030455 28.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20b78193-0999-4d37-9407-0f972d755392">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20b78193-0999-4d37-9407-0f972d755392_0">
											<gml:posList>35.67238143534402 139.7386403308237 28.19 35.67238143534402 139.7386403308237 9.66 35.67237503819206 139.73862070868844 9.66 35.67237503819206 139.73862070868844 28.19 35.67238143534402 139.7386403308237 28.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1d58e1fb-838e-41bd-9c2d-83010334a8da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d58e1fb-838e-41bd-9c2d-83010334a8da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d58e1fb-838e-41bd-9c2d-83010334a8da">
											<gml:posList>35.672270560597944 139.73843820000494 9.644 35.672210675688085 139.7383839441441 9.644 35.67224707710629 139.7383661382347 9.644 35.672270560597944 139.73843820000494 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0d2ff13a-67a8-4a2e-8d09-88a3dbad9dc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d2ff13a-67a8-4a2e-8d09-88a3dbad9dc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d2ff13a-67a8-4a2e-8d09-88a3dbad9dc5">
											<gml:posList>35.67225828781586 139.7385576163447 9.644 35.672252532172394 139.73853995976776 9.644 35.67226027198313 139.73853617270711 9.644 35.672210675688085 139.7383839441441 9.644 35.672270560597944 139.73843820000494 9.644 35.6723093767602 139.73841919822337 9.644 35.67237503819206 139.73862070868844 9.644 35.67233852862434 139.73863858091778 9.644 35.67234491675969 139.73865820305616 9.644 35.672325625795075 139.7386676485247 9.644 35.672324153015396 139.7386631432807 9.644 35.67230412321191 139.7386729541533 9.644 35.67229888260945 139.7386568766026 9.644 35.672290845455116 139.7386608076093 9.644 35.672282903216185 139.73863642626876 9.644 35.672278055694264 139.73863879594995 9.644 35.67225252125258 139.73856044002358 9.644 35.67225828781586 139.7385576163447 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4e111ae-d002-48a5-a7fe-ebd149e57b39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4e111ae-d002-48a5-a7fe-ebd149e57b39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4e111ae-d002-48a5-a7fe-ebd149e57b39">
											<gml:posList>35.672210675688085 139.7383839441441 30.33 35.67221678051089 139.73838715144913 30.33 35.67224446002067 139.73837363087264 30.33 35.67224707710629 139.7383661382347 30.33 35.672210675688085 139.7383839441441 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6518ac42-d389-4e7a-bca5-8f76891d6145">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6518ac42-d389-4e7a-bca5-8f76891d6145">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6518ac42-d389-4e7a-bca5-8f76891d6145">
											<gml:posList>35.67225147131913 139.7385091301929 30.33 35.672254016129415 139.73850141671386 30.33 35.67221678051089 139.73838715144913 30.33 35.672210675688085 139.7383839441441 30.33 35.67225147131913 139.7385091301929 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e110e33a-2c97-45c1-a889-a3caaf091f2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e110e33a-2c97-45c1-a889-a3caaf091f2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e110e33a-2c97-45c1-a889-a3caaf091f2a">
											<gml:posList>35.67225639069598 139.7385064400707 30.33 35.67225907065098 139.73849864910557 30.33 35.672254016129415 139.73850141671386 30.33 35.67225147131913 139.7385091301929 30.33 35.67225639069598 139.7385064400707 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-147f4328-9388-484c-9d7d-dbf4cefb2675">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-147f4328-9388-484c-9d7d-dbf4cefb2675">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-147f4328-9388-484c-9d7d-dbf4cefb2675">
											<gml:posList>35.672270560597944 139.73843820000494 30.33 35.67224707710629 139.7383661382347 30.33 35.67224446002067 139.73837363087264 30.33 35.67226794350786 139.73844569264278 30.33 35.672270560597944 139.73843820000494 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45cfd2d6-51dc-4e78-817a-91c5e2877c2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45cfd2d6-51dc-4e78-817a-91c5e2877c2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45cfd2d6-51dc-4e78-817a-91c5e2877c2c">
											<gml:posList>35.67225639069598 139.7385064400707 30.33 35.67226100887612 139.73852188868756 30.33 35.67226380634102 139.73851451735123 30.33 35.67225907065098 139.73849864910557 30.33 35.67225639069598 139.7385064400707 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24602fdf-2c56-48ba-9f75-5911fd1aff8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24602fdf-2c56-48ba-9f75-5911fd1aff8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24602fdf-2c56-48ba-9f75-5911fd1aff8c">
											<gml:posList>35.67225828781586 139.7385576163447 16.315 35.67225252125258 139.73856044002358 16.315 35.672278055694264 139.73863879594995 16.315 35.672282903216185 139.73863642626876 16.315 35.672290845455116 139.7386608076093 16.315 35.67229888260945 139.7386568766026 16.315 35.67226027198313 139.73853617270711 16.315 35.672252532172394 139.73853995976776 16.315 35.67225828781586 139.7385576163447 16.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d4b5025-9009-4203-aebc-f126cc94989b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d4b5025-9009-4203-aebc-f126cc94989b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d4b5025-9009-4203-aebc-f126cc94989b">
											<gml:posList>35.67229469031136 139.73850680349145 30.33 35.67229743370171 139.73849944326201 30.33 35.67226380634102 139.73851451735123 30.33 35.67226100887612 139.73852188868756 30.33 35.67229469031136 139.73850680349145 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-229a7816-ac68-4506-af22-2b2bf52a46f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-229a7816-ac68-4506-af22-2b2bf52a46f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-229a7816-ac68-4506-af22-2b2bf52a46f2">
											<gml:posList>35.67226100887612 139.73852188868756 21.9 35.67225639069598 139.7385064400707 21.9 35.67225147131913 139.7385091301929 21.9 35.67230412321191 139.7386729541533 21.9 35.67230985374028 139.7386701526163 21.9 35.67226100887612 139.73852188868756 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03e78625-3709-4a1f-b4af-438e96775b23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03e78625-3709-4a1f-b4af-438e96775b23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03e78625-3709-4a1f-b4af-438e96775b23">
											<gml:posList>35.67230985374028 139.7386701526163 21.9 35.67231119457451 139.7386214910891 27.298 35.67226100887612 139.73852188868756 21.9 35.67230985374028 139.7386701526163 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2bd59379-4a37-4f9c-8819-1dfa0ff9ee1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bd59379-4a37-4f9c-8819-1dfa0ff9ee1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bd59379-4a37-4f9c-8819-1dfa0ff9ee1d">
											<gml:posList>35.67231119457451 139.7386214910891 27.298 35.672277849594 139.73851434609108 27.298 35.67226100887612 139.73852188868756 21.9 35.67231119457451 139.7386214910891 27.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-677dbc64-280c-4364-8ec9-2a0a3e6f46b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-677dbc64-280c-4364-8ec9-2a0a3e6f46b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-677dbc64-280c-4364-8ec9-2a0a3e6f46b2">
											<gml:posList>35.672270560597944 139.73843820000494 30.33 35.67226794350786 139.73844569264278 30.33 35.6723067506576 139.7384266908761 30.33 35.6723093767602 139.73841919822337 30.33 35.672270560597944 139.73843820000494 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-145cda94-cf8f-4687-94ef-923294cc3afe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-145cda94-cf8f-4687-94ef-923294cc3afe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-145cda94-cf8f-4687-94ef-923294cc3afe">
											<gml:posList>35.67224446002067 139.73837363087264 29.92 35.67221678051089 139.73838715144913 29.92 35.672254016129415 139.73850141671386 29.92 35.67225907065098 139.73849864910557 29.92 35.67226380634102 139.73851451735123 29.92 35.67229743370171 139.73849944326201 29.92 35.67233835254203 139.7386324503021 29.92 35.67236892435319 139.73861749032346 29.92 35.6723067506576 139.7384266908761 29.92 35.67226794350786 139.73844569264278 29.92 35.67224446002067 139.73837363087264 29.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76746b2b-bea3-49a1-8af5-897e96f850ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76746b2b-bea3-49a1-8af5-897e96f850ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76746b2b-bea3-49a1-8af5-897e96f850ad">
											<gml:posList>35.67229469031136 139.73850680349145 30.202 35.672277849594 139.73851434609108 27.298 35.67231119457451 139.7386214910891 27.298 35.672327602535724 139.73861381646176 30.202 35.67229469031136 139.73850680349145 30.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc5933d7-7d7f-49ac-ba3f-13df65139329">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc5933d7-7d7f-49ac-ba3f-13df65139329">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc5933d7-7d7f-49ac-ba3f-13df65139329">
											<gml:posList>35.67229469031136 139.73850680349145 30.33 35.67233565435117 139.73863998722186 30.33 35.67233835254203 139.7386324503021 30.33 35.67229743370171 139.73849944326201 30.33 35.67229469031136 139.73850680349145 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-817ed34b-7599-46de-a36f-bf76a128b968">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-817ed34b-7599-46de-a36f-bf76a128b968">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-817ed34b-7599-46de-a36f-bf76a128b968">
											<gml:posList>35.67230985374028 139.7386701526163 21.9 35.672324153015396 139.7386631432807 27.298 35.67231119457451 139.7386214910891 27.298 35.67230985374028 139.7386701526163 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c25a4fff-e123-49a9-a70e-18c48c56c87c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c25a4fff-e123-49a9-a70e-18c48c56c87c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c25a4fff-e123-49a9-a70e-18c48c56c87c">
											<gml:posList>35.672325625795075 139.7386676485247 27.298 35.67234491675969 139.73865820305616 27.298 35.67233852862434 139.73863858091778 27.298 35.67233565435117 139.73863998722186 27.298 35.672327602535724 139.73861381646176 27.298 35.67231119457451 139.7386214910891 27.298 35.672324153015396 139.7386631432807 27.298 35.672325625795075 139.7386676485247 27.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b54b7d69-c1ad-4e07-ad97-19a6b013326b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b54b7d69-c1ad-4e07-ad97-19a6b013326b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b54b7d69-c1ad-4e07-ad97-19a6b013326b">
											<gml:posList>35.6723093767602 139.73841919822337 30.33 35.6723067506576 139.7384266908761 30.33 35.67236892435319 139.73861749032346 30.33 35.67237503819206 139.73862070868844 30.33 35.6723093767602 139.73841919822337 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-201673e9-7540-4da5-abd4-0277ec757717">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-201673e9-7540-4da5-abd4-0277ec757717">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-201673e9-7540-4da5-abd4-0277ec757717">
											<gml:posList>35.67237503819206 139.73862070868844 30.33 35.67236892435319 139.73861749032346 30.33 35.67233835254203 139.7386324503021 30.33 35.67233565435117 139.73863998722186 30.33 35.67237503819206 139.73862070868844 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e8c775e-17c4-4cd0-9543-b8250da3d9cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e8c775e-17c4-4cd0-9543-b8250da3d9cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e8c775e-17c4-4cd0-9543-b8250da3d9cb">
											<gml:posList>35.67224446002067 139.73837363087264 30.33 35.67224446002067 139.73837363087264 29.92 35.67226794350786 139.73844569264278 29.92 35.67226794350786 139.73844569264278 30.33 35.67224446002067 139.73837363087264 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1e29515-f4b5-4312-9254-c51e7f7fe5dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1e29515-f4b5-4312-9254-c51e7f7fe5dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1e29515-f4b5-4312-9254-c51e7f7fe5dd">
											<gml:posList>35.67233835254203 139.7386324503021 30.33 35.67233835254203 139.7386324503021 29.92 35.67229743370171 139.73849944326201 29.92 35.67229743370171 139.73849944326201 30.33 35.67233835254203 139.7386324503021 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19667835-7291-4c83-a7f8-66d7a6ebd10a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19667835-7291-4c83-a7f8-66d7a6ebd10a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19667835-7291-4c83-a7f8-66d7a6ebd10a">
											<gml:posList>35.672210675688085 139.7383839441441 9.644 35.672210675688085 139.7383839441441 30.33 35.67224707710629 139.7383661382347 30.33 35.672210675688085 139.7383839441441 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afc3e34b-7049-4f2e-b7be-0809f10a5ab7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afc3e34b-7049-4f2e-b7be-0809f10a5ab7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afc3e34b-7049-4f2e-b7be-0809f10a5ab7">
											<gml:posList>35.672210675688085 139.7383839441441 9.644 35.67224707710629 139.7383661382347 30.33 35.67224707710629 139.7383661382347 9.644 35.672210675688085 139.7383839441441 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6222f9cc-e044-4073-9d1f-04783cc71145">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6222f9cc-e044-4073-9d1f-04783cc71145">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6222f9cc-e044-4073-9d1f-04783cc71145">
											<gml:posList>35.67221678051089 139.73838715144913 30.33 35.67221678051089 139.73838715144913 29.92 35.67224446002067 139.73837363087264 29.92 35.67224446002067 139.73837363087264 30.33 35.67221678051089 139.73838715144913 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2379a49e-5682-43e9-a394-cbb73fd888f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2379a49e-5682-43e9-a394-cbb73fd888f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2379a49e-5682-43e9-a394-cbb73fd888f4">
											<gml:posList>35.672210675688085 139.7383839441441 9.644 35.67225147131913 139.7385091301929 21.9 35.67225147131913 139.7385091301929 30.33 35.672210675688085 139.7383839441441 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae30725f-f56a-4940-b20e-1738d7001144">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae30725f-f56a-4940-b20e-1738d7001144">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae30725f-f56a-4940-b20e-1738d7001144">
											<gml:posList>35.672210675688085 139.7383839441441 9.644 35.67225147131913 139.7385091301929 30.33 35.672210675688085 139.7383839441441 30.33 35.672210675688085 139.7383839441441 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cb8d7f8-7fcb-491d-b969-6daceef81ce6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cb8d7f8-7fcb-491d-b969-6daceef81ce6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cb8d7f8-7fcb-491d-b969-6daceef81ce6">
											<gml:posList>35.672254016129415 139.73850141671386 30.33 35.672254016129415 139.73850141671386 29.92 35.67221678051089 139.73838715144913 29.92 35.67221678051089 139.73838715144913 30.33 35.672254016129415 139.73850141671386 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15192ea6-e43f-408f-9d15-3cf4b1fa976a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15192ea6-e43f-408f-9d15-3cf4b1fa976a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15192ea6-e43f-408f-9d15-3cf4b1fa976a">
											<gml:posList>35.672210675688085 139.7383839441441 9.644 35.67226027198313 139.73853617270711 9.644 35.67226027198313 139.73853617270711 16.315 35.672210675688085 139.7383839441441 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a51fc49c-c5ac-4cce-81db-a42a48591572">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a51fc49c-c5ac-4cce-81db-a42a48591572">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a51fc49c-c5ac-4cce-81db-a42a48591572">
											<gml:posList>35.672210675688085 139.7383839441441 9.644 35.67226027198313 139.73853617270711 16.315 35.67225147131913 139.7385091301929 21.9 35.672210675688085 139.7383839441441 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-590c0a23-f02c-4893-ad66-3ea900e461ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-590c0a23-f02c-4893-ad66-3ea900e461ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-590c0a23-f02c-4893-ad66-3ea900e461ba">
											<gml:posList>35.67225639069598 139.7385064400707 21.9 35.67225639069598 139.7385064400707 30.33 35.67225147131913 139.7385091301929 30.33 35.67225147131913 139.7385091301929 21.9 35.67225639069598 139.7385064400707 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59b2e7cc-5365-48a6-a58f-707efe24c71d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59b2e7cc-5365-48a6-a58f-707efe24c71d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59b2e7cc-5365-48a6-a58f-707efe24c71d">
											<gml:posList>35.67225828781586 139.7385576163447 9.644 35.67225252125258 139.73856044002358 9.644 35.67225252125258 139.73856044002358 16.315 35.67225828781586 139.7385576163447 16.315 35.67225828781586 139.7385576163447 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-220e2b7b-718c-49b2-92e8-50761356ac3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-220e2b7b-718c-49b2-92e8-50761356ac3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-220e2b7b-718c-49b2-92e8-50761356ac3f">
											<gml:posList>35.672252532172394 139.73853995976776 9.644 35.67225828781586 139.7385576163447 9.644 35.67225828781586 139.7385576163447 16.315 35.672252532172394 139.73853995976776 16.315 35.672252532172394 139.73853995976776 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19e8ee38-0ce1-49d5-89ad-d95e4666eb1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19e8ee38-0ce1-49d5-89ad-d95e4666eb1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19e8ee38-0ce1-49d5-89ad-d95e4666eb1d">
											<gml:posList>35.67226027198313 139.73853617270711 9.644 35.672252532172394 139.73853995976776 9.644 35.672252532172394 139.73853995976776 16.315 35.67226027198313 139.73853617270711 16.315 35.67226027198313 139.73853617270711 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08658b93-d31b-46fa-835a-3c58843fc010">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08658b93-d31b-46fa-835a-3c58843fc010">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08658b93-d31b-46fa-835a-3c58843fc010">
											<gml:posList>35.67225907065098 139.73849864910557 30.33 35.67225907065098 139.73849864910557 29.92 35.672254016129415 139.73850141671386 29.92 35.672254016129415 139.73850141671386 30.33 35.67225907065098 139.73849864910557 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5ac38b8-8355-445d-9231-b1ce55f11e71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5ac38b8-8355-445d-9231-b1ce55f11e71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5ac38b8-8355-445d-9231-b1ce55f11e71">
											<gml:posList>35.67226100887612 139.73852188868756 21.9 35.67226100887612 139.73852188868756 30.33 35.67225639069598 139.7385064400707 30.33 35.67225639069598 139.7385064400707 21.9 35.67226100887612 139.73852188868756 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b87d8b76-36fb-4232-8b2b-e75c8aaf5c0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b87d8b76-36fb-4232-8b2b-e75c8aaf5c0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b87d8b76-36fb-4232-8b2b-e75c8aaf5c0b">
											<gml:posList>35.672270560597944 139.73843820000494 9.644 35.67224707710629 139.7383661382347 9.644 35.67224707710629 139.7383661382347 30.33 35.672270560597944 139.73843820000494 30.33 35.672270560597944 139.73843820000494 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4060299-5edc-4c43-a972-3d4e77385256">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4060299-5edc-4c43-a972-3d4e77385256">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4060299-5edc-4c43-a972-3d4e77385256">
											<gml:posList>35.67226380634102 139.73851451735123 30.33 35.67226380634102 139.73851451735123 29.92 35.67225907065098 139.73849864910557 29.92 35.67225907065098 139.73849864910557 30.33 35.67226380634102 139.73851451735123 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05b4771f-5cda-42c5-b2d0-cce9330a666c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05b4771f-5cda-42c5-b2d0-cce9330a666c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05b4771f-5cda-42c5-b2d0-cce9330a666c">
											<gml:posList>35.67225252125258 139.73856044002358 9.644 35.672278055694264 139.73863879594995 9.644 35.672278055694264 139.73863879594995 16.315 35.67225252125258 139.73856044002358 16.315 35.67225252125258 139.73856044002358 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-799bcdf6-6a2d-406d-bec5-200a8a75bf60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-799bcdf6-6a2d-406d-bec5-200a8a75bf60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-799bcdf6-6a2d-406d-bec5-200a8a75bf60">
											<gml:posList>35.67229888260945 139.7386568766026 16.315 35.67229888260945 139.7386568766026 9.644 35.67230412321191 139.7386729541533 9.644 35.67230412321191 139.7386729541533 21.9 35.67225147131913 139.7385091301929 21.9 35.67226027198313 139.73853617270711 16.315 35.67229888260945 139.7386568766026 16.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f2b23db-e4a1-46aa-bb5a-8548fd9a81bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f2b23db-e4a1-46aa-bb5a-8548fd9a81bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f2b23db-e4a1-46aa-bb5a-8548fd9a81bc">
											<gml:posList>35.67226100887612 139.73852188868756 30.33 35.67226100887612 139.73852188868756 21.9 35.672277849594 139.73851434609108 27.298 35.67229469031136 139.73850680349145 30.202 35.67229469031136 139.73850680349145 30.33 35.67226100887612 139.73852188868756 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a41c5ac7-9f9b-4cd4-b0f7-2e1791e1d48d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a41c5ac7-9f9b-4cd4-b0f7-2e1791e1d48d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a41c5ac7-9f9b-4cd4-b0f7-2e1791e1d48d">
											<gml:posList>35.672278055694264 139.73863879594995 9.644 35.672282903216185 139.73863642626876 9.644 35.672282903216185 139.73863642626876 16.315 35.672278055694264 139.73863879594995 16.315 35.672278055694264 139.73863879594995 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ad1e485-669c-42a5-bd9c-65965d2fe504">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ad1e485-669c-42a5-bd9c-65965d2fe504">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ad1e485-669c-42a5-bd9c-65965d2fe504">
											<gml:posList>35.67229743370171 139.73849944326201 30.33 35.67229743370171 139.73849944326201 29.92 35.67226380634102 139.73851451735123 29.92 35.67226380634102 139.73851451735123 30.33 35.67229743370171 139.73849944326201 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-383de4ac-2c5e-4cfe-af48-ba3cdf5b11f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-383de4ac-2c5e-4cfe-af48-ba3cdf5b11f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-383de4ac-2c5e-4cfe-af48-ba3cdf5b11f9">
											<gml:posList>35.672282903216185 139.73863642626876 9.644 35.672290845455116 139.7386608076093 9.644 35.672290845455116 139.7386608076093 16.315 35.672282903216185 139.73863642626876 16.315 35.672282903216185 139.73863642626876 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a915ec4f-2e36-494b-ad79-065b6f42a1c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a915ec4f-2e36-494b-ad79-065b6f42a1c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a915ec4f-2e36-494b-ad79-065b6f42a1c2">
											<gml:posList>35.67226794350786 139.73844569264278 30.33 35.67226794350786 139.73844569264278 29.92 35.6723067506576 139.7384266908761 29.92 35.6723067506576 139.7384266908761 30.33 35.67226794350786 139.73844569264278 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fca99737-1ce4-434e-9791-3cd12cbd331d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fca99737-1ce4-434e-9791-3cd12cbd331d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fca99737-1ce4-434e-9791-3cd12cbd331d">
											<gml:posList>35.6723093767602 139.73841919822337 9.644 35.672270560597944 139.73843820000494 9.644 35.672270560597944 139.73843820000494 30.33 35.6723093767602 139.73841919822337 30.33 35.6723093767602 139.73841919822337 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-869e4470-7b4c-49a8-b8b3-3f519a4ae043">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-869e4470-7b4c-49a8-b8b3-3f519a4ae043">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-869e4470-7b4c-49a8-b8b3-3f519a4ae043">
											<gml:posList>35.672290845455116 139.7386608076093 9.644 35.67229888260945 139.7386568766026 9.644 35.67229888260945 139.7386568766026 16.315 35.672290845455116 139.7386608076093 16.315 35.672290845455116 139.7386608076093 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8145cca1-8629-4731-a957-2ff8362102ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8145cca1-8629-4731-a957-2ff8362102ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8145cca1-8629-4731-a957-2ff8362102ca">
											<gml:posList>35.67230412321191 139.7386729541533 9.644 35.672324153015396 139.7386631432807 9.644 35.672324153015396 139.7386631432807 27.298 35.67230985374028 139.7386701526163 21.9 35.67230412321191 139.7386729541533 21.9 35.67230412321191 139.7386729541533 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccb44c40-1e0b-4a17-ae52-f6646a0f6df9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccb44c40-1e0b-4a17-ae52-f6646a0f6df9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccb44c40-1e0b-4a17-ae52-f6646a0f6df9">
											<gml:posList>35.672327602535724 139.73861381646176 30.202 35.672327602535724 139.73861381646176 27.298 35.67233565435117 139.73863998722186 27.298 35.67233565435117 139.73863998722186 30.33 35.67229469031136 139.73850680349145 30.33 35.67229469031136 139.73850680349145 30.202 35.672327602535724 139.73861381646176 30.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89458d5d-72f5-4520-8a5a-ea847de1bd98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89458d5d-72f5-4520-8a5a-ea847de1bd98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89458d5d-72f5-4520-8a5a-ea847de1bd98">
											<gml:posList>35.67231119457451 139.7386214910891 27.298 35.672327602535724 139.73861381646176 27.298 35.672327602535724 139.73861381646176 30.202 35.67231119457451 139.7386214910891 27.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47b8d3f5-669b-41ba-9dfb-3222afb93810">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47b8d3f5-669b-41ba-9dfb-3222afb93810">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47b8d3f5-669b-41ba-9dfb-3222afb93810">
											<gml:posList>35.672324153015396 139.7386631432807 9.644 35.672325625795075 139.7386676485247 9.644 35.672325625795075 139.7386676485247 27.298 35.672324153015396 139.7386631432807 27.298 35.672324153015396 139.7386631432807 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d052d800-84b2-48ec-b02a-c0f8b2d359b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d052d800-84b2-48ec-b02a-c0f8b2d359b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d052d800-84b2-48ec-b02a-c0f8b2d359b0">
											<gml:posList>35.672325625795075 139.7386676485247 9.644 35.67234491675969 139.73865820305616 9.644 35.67234491675969 139.73865820305616 27.298 35.672325625795075 139.7386676485247 27.298 35.672325625795075 139.7386676485247 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fda736c-f084-4b61-8389-c344b97e5743">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fda736c-f084-4b61-8389-c344b97e5743">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fda736c-f084-4b61-8389-c344b97e5743">
											<gml:posList>35.6723067506576 139.7384266908761 30.33 35.6723067506576 139.7384266908761 29.92 35.67236892435319 139.73861749032346 29.92 35.67236892435319 139.73861749032346 30.33 35.6723067506576 139.7384266908761 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9850f55-e418-4fb6-b671-4199cc77a90a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9850f55-e418-4fb6-b671-4199cc77a90a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9850f55-e418-4fb6-b671-4199cc77a90a">
											<gml:posList>35.67234491675969 139.73865820305616 9.644 35.67233852862434 139.73863858091778 9.644 35.67233852862434 139.73863858091778 27.298 35.67234491675969 139.73865820305616 27.298 35.67234491675969 139.73865820305616 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a57c6e86-14c1-4a6f-b4f0-6414e5292894">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a57c6e86-14c1-4a6f-b4f0-6414e5292894">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a57c6e86-14c1-4a6f-b4f0-6414e5292894">
											<gml:posList>35.67237503819206 139.73862070868844 9.644 35.6723093767602 139.73841919822337 9.644 35.6723093767602 139.73841919822337 30.33 35.67237503819206 139.73862070868844 30.33 35.67237503819206 139.73862070868844 9.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f7f7bec-b20d-4915-94fd-0cf98aed2cce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f7f7bec-b20d-4915-94fd-0cf98aed2cce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f7f7bec-b20d-4915-94fd-0cf98aed2cce">
											<gml:posList>35.67236892435319 139.73861749032346 30.33 35.67236892435319 139.73861749032346 29.92 35.67233835254203 139.7386324503021 29.92 35.67233835254203 139.7386324503021 30.33 35.67236892435319 139.73861749032346 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adb09ff9-4405-40d5-99b4-15bac7548520">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adb09ff9-4405-40d5-99b4-15bac7548520">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adb09ff9-4405-40d5-99b4-15bac7548520">
											<gml:posList>35.67237503819206 139.73862070868844 30.33 35.67233565435117 139.73863998722186 30.33 35.67233565435117 139.73863998722186 27.298 35.67233852862434 139.73863858091778 27.298 35.67233852862434 139.73863858091778 9.644 35.67237503819206 139.73862070868844 9.644 35.67237503819206 139.73862070868844 30.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3689</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">288.66983</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>