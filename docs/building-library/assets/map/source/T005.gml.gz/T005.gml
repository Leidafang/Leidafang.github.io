<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_00b25a16-8b9b-4788-8b18-788a2315cfa3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">23.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670560832552596 139.73806794176429 0 35.67056246166411 139.73807633500468 0 35.67067591732605 139.7380419566796 0 35.670663700881946 139.73798143748462 0 35.67054988468831 139.73801581631864 0 35.67055115185564 139.7380224425818 0 35.67051843982668 139.73803231265606 0 35.67052767000861 139.73807803328197 0 35.670560832552596 139.73806794176429 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670560832552596 139.73806794176429 17 35.67052767000861 139.73807803328197 17 35.67051843982668 139.73803231265606 17 35.67055115185564 139.7380224425818 17 35.67054988468831 139.73801581631864 17 35.670663700881946 139.73798143748462 17 35.67067591732605 139.7380419566796 17 35.67056246166411 139.73807633500468 17 35.670560832552596 139.73806794176429 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670560832552596 139.73806794176429 17 35.67056246166411 139.73807633500468 17 35.67056246166411 139.73807633500468 40.85 35.670560832552596 139.73806794176429 40.85 35.670560832552596 139.73806794176429 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056246166411 139.73807633500468 17 35.67067591732605 139.7380419566796 17 35.67067591732605 139.7380419566796 40.85 35.67056246166411 139.73807633500468 40.85 35.67056246166411 139.73807633500468 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67067591732605 139.7380419566796 17 35.670663700881946 139.73798143748462 17 35.670663700881946 139.73798143748462 40.85 35.67067591732605 139.7380419566796 40.85 35.67067591732605 139.7380419566796 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670663700881946 139.73798143748462 17 35.67054988468831 139.73801581631864 17 35.67054988468831 139.73801581631864 40.85 35.670663700881946 139.73798143748462 40.85 35.670663700881946 139.73798143748462 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054988468831 139.73801581631864 17 35.67055115185564 139.7380224425818 17 35.67055115185564 139.7380224425818 40.85 35.67054988468831 139.73801581631864 40.85 35.67054988468831 139.73801581631864 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055115185564 139.7380224425818 17 35.67051843982668 139.73803231265606 17 35.67051843982668 139.73803231265606 40.85 35.67055115185564 139.7380224425818 40.85 35.67055115185564 139.7380224425818 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67051843982668 139.73803231265606 17 35.67052767000861 139.73807803328197 17 35.67052767000861 139.73807803328197 40.85 35.67051843982668 139.73803231265606 40.85 35.67051843982668 139.73803231265606 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67052767000861 139.73807803328197 17 35.670560832552596 139.73806794176429 17 35.670560832552596 139.73806794176429 40.85 35.67052767000861 139.73807803328197 40.85 35.67052767000861 139.73807803328197 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670560832552596 139.73806794176429 40.85 35.67056246166411 139.73807633500468 40.85 35.67067591732605 139.7380419566796 40.85 35.670663700881946 139.73798143748462 40.85 35.67054988468831 139.73801581631864 40.85 35.67055115185564 139.7380224425818 40.85 35.67051843982668 139.73803231265606 40.85 35.67052767000861 139.73807803328197 40.85 35.670560832552596 139.73806794176429 40.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-eaeed73b-780a-4113-bfd4-ae3733188122"/>
							<gml:surfaceMember xlink:href="#poly-963027be-ee07-4a5c-ad12-e85c4be583f9"/>
							<gml:surfaceMember xlink:href="#poly-c815abbd-0f41-4f8a-85c4-4785b07a5c88"/>
							<gml:surfaceMember xlink:href="#poly-41f23eba-74e2-4553-a954-22414e3000b9"/>
							<gml:surfaceMember xlink:href="#poly-b6033c61-da90-4613-8000-74347fcaed88"/>
							<gml:surfaceMember xlink:href="#poly-0fbbf05b-fbdb-4247-8987-2fb0cfdf19a3"/>
							<gml:surfaceMember xlink:href="#poly-ff116eb9-7a4f-4788-9609-a6d5481cf611"/>
							<gml:surfaceMember xlink:href="#poly-4b43fc87-1236-45bb-b94c-68655514b0e0"/>
							<gml:surfaceMember xlink:href="#poly-0d1f4316-f59b-499b-b2e7-7d20093d923b"/>
							<gml:surfaceMember xlink:href="#poly-21ae8fbc-a7e5-4e5d-b9c3-ad239a800bc3"/>
							<gml:surfaceMember xlink:href="#poly-370059fd-527d-4aa5-80d7-02570c8ec596"/>
							<gml:surfaceMember xlink:href="#poly-8f26faa2-c6fb-419c-a20b-562dc745acbd"/>
							<gml:surfaceMember xlink:href="#poly-e433afea-e9eb-42e7-b681-cc06ada8d770"/>
							<gml:surfaceMember xlink:href="#poly-318f8269-f164-43ab-af7c-2c0353377817"/>
							<gml:surfaceMember xlink:href="#poly-25afad02-8b2a-442b-8f59-7ba7d876fe32"/>
							<gml:surfaceMember xlink:href="#poly-b13fd323-68ff-4009-92f8-47d5570c4b9e"/>
							<gml:surfaceMember xlink:href="#poly-2cf8d9c8-2450-43c0-a33c-8b040a10ba07"/>
							<gml:surfaceMember xlink:href="#poly-5c58805e-1c8b-4c02-bea6-7a8abbb93662"/>
							<gml:surfaceMember xlink:href="#poly-c936a67b-18fe-48b8-83e7-bce95351ec54"/>
							<gml:surfaceMember xlink:href="#poly-041ede1e-3f65-433c-be6e-8bea4a21959d"/>
							<gml:surfaceMember xlink:href="#poly-eea3bafc-508d-43d3-b375-c9a9f083191d"/>
							<gml:surfaceMember xlink:href="#poly-8d759607-b37f-46e4-8098-fb2191131841"/>
							<gml:surfaceMember xlink:href="#poly-856cdab8-ae70-409c-b8c5-470c1b13458d"/>
							<gml:surfaceMember xlink:href="#poly-7f3b0590-7d6a-4cce-81df-d29d6a0785a7"/>
							<gml:surfaceMember xlink:href="#poly-f749c430-b8ad-4377-a975-6f9adcaa355b"/>
							<gml:surfaceMember xlink:href="#poly-ae6fa490-99dc-4bd1-be1f-b3072f674c2a"/>
							<gml:surfaceMember xlink:href="#poly-943dff0e-2ac6-405e-9b30-c11bf1f2995a"/>
							<gml:surfaceMember xlink:href="#poly-4c370dad-88a7-42bd-b8a8-52be145fc688"/>
							<gml:surfaceMember xlink:href="#poly-4c260b35-6751-45bb-a80a-ba7268786f39"/>
							<gml:surfaceMember xlink:href="#poly-033ba23d-7d9a-41c5-bba4-58649fad4713"/>
							<gml:surfaceMember xlink:href="#poly-4d992567-2db9-48c5-bcdf-1f47146d6eaa"/>
							<gml:surfaceMember xlink:href="#poly-881ad1fe-cf0c-40db-9811-b2d38e5d5b92"/>
							<gml:surfaceMember xlink:href="#poly-6309387a-6478-467e-9a4b-7b27c6f60bf7"/>
							<gml:surfaceMember xlink:href="#poly-8b6566d3-6039-4f8a-b459-273cdbadb726"/>
							<gml:surfaceMember xlink:href="#poly-67490ba1-7018-47e6-a982-3bdc1e9c00a1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_00b25a16-8b9b-4788-8b18-788a2315cfa3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d162d1c-ed85-4382-8f35-818b80b4af80">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670633396643346 139.73800410738116 40.926 35.67063489950599 139.73801242345385 40.926 35.6706227516062 139.73801571864522 40.926 35.670621248743785 139.7380074025737 40.926 35.670633396643346 139.73800410738116 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dfc9ea3-c21b-4877-bb71-7be2929b323f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061685120349 139.7380202546395 40.926 35.670616254155625 139.7380175490078 40.926 35.670612874893116 139.73801866870053 40.926 35.67061110181164 139.73801059596966 40.926 35.6706182207979 139.73800824569193 40.926 35.67062059092745 139.73801902405532 40.926 35.67061685120349 139.7380202546395 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7c760ec-3bf1-4bec-8b5e-c197e5e41183">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7c760ec-3bf1-4bec-8b5e-c197e5e41183_0">
											<gml:posList>35.670633396643346 139.73800410738116 40.926 35.670621248743785 139.7380074025737 40.926 35.670621248743785 139.7380074025737 42.978 35.670633396643346 139.73800410738116 42.978 35.670633396643346 139.73800410738116 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9583360c-2a3b-41c9-883d-043980c5a24f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9583360c-2a3b-41c9-883d-043980c5a24f_0">
											<gml:posList>35.67063489950599 139.73801242345385 40.926 35.670633396643346 139.73800410738116 40.926 35.670633396643346 139.73800410738116 42.978 35.67063489950599 139.73801242345385 42.978 35.67063489950599 139.73801242345385 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1057f43e-acc9-4c77-91b5-785a88d9babd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1057f43e-acc9-4c77-91b5-785a88d9babd_0">
											<gml:posList>35.6706182207979 139.73800824569193 40.926 35.67061110181164 139.73801059596966 40.926 35.67061110181164 139.73801059596966 43.796 35.6706182207979 139.73800824569193 43.796 35.6706182207979 139.73800824569193 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-331f973c-d977-44b7-8234-740ed62fe24a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-331f973c-d977-44b7-8234-740ed62fe24a_0">
											<gml:posList>35.670633396643346 139.73800410738116 42.978 35.670621248743785 139.7380074025737 42.978 35.6706227516062 139.73801571864522 42.978 35.67063489950599 139.73801242345385 42.978 35.670633396643346 139.73800410738116 42.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4d8ce5f-91b4-4e73-a9d4-202170c30e39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4d8ce5f-91b4-4e73-a9d4-202170c30e39_0">
											<gml:posList>35.670621248743785 139.7380074025737 40.926 35.6706227516062 139.73801571864522 40.926 35.6706227516062 139.73801571864522 42.978 35.670621248743785 139.7380074025737 42.978 35.670621248743785 139.7380074025737 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f4814ed-0437-415f-9bcb-ec35c4c5d1b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f4814ed-0437-415f-9bcb-ec35c4c5d1b9_0">
											<gml:posList>35.67062059092745 139.73801902405532 40.926 35.6706182207979 139.73800824569193 40.926 35.6706182207979 139.73800824569193 43.796 35.67062059092745 139.73801902405532 43.796 35.67062059092745 139.73801902405532 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00c21a8c-5d35-4f81-b638-99a7496b9594">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00c21a8c-5d35-4f81-b638-99a7496b9594_0">
											<gml:posList>35.6706227516062 139.73801571864522 40.926 35.67063489950599 139.73801242345385 40.926 35.67063489950599 139.73801242345385 42.978 35.6706227516062 139.73801571864522 42.978 35.6706227516062 139.73801571864522 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe5c7b0f-6deb-4f60-b233-5ad6add3cee0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe5c7b0f-6deb-4f60-b233-5ad6add3cee0_0">
											<gml:posList>35.6706182207979 139.73800824569193 43.796 35.67061110181164 139.73801059596966 43.796 35.670612874893116 139.73801866870053 43.796 35.670616254155625 139.7380175490078 43.796 35.67061685120349 139.7380202546395 43.796 35.67062059092745 139.73801902405532 43.796 35.6706182207979 139.73800824569193 43.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bff74808-b393-4364-8270-19656e4b5917">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bff74808-b393-4364-8270-19656e4b5917_0">
											<gml:posList>35.67061110181164 139.73801059596966 40.926 35.670612874893116 139.73801866870053 40.926 35.670612874893116 139.73801866870053 43.796 35.67061110181164 139.73801059596966 43.796 35.67061110181164 139.73801059596966 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3174da0-f397-4504-8d84-8fb88ce9146f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3174da0-f397-4504-8d84-8fb88ce9146f_0">
											<gml:posList>35.670612874893116 139.73801866870053 40.926 35.670616254155625 139.7380175490078 40.926 35.670616254155625 139.7380175490078 43.796 35.670612874893116 139.73801866870053 43.796 35.670612874893116 139.73801866870053 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cac48eaf-3096-4e57-b069-fdcba95baa36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cac48eaf-3096-4e57-b069-fdcba95baa36_0">
											<gml:posList>35.670616254155625 139.7380175490078 40.926 35.67061685120349 139.7380202546395 40.926 35.67061685120349 139.7380202546395 43.796 35.670616254155625 139.7380175490078 43.796 35.670616254155625 139.7380175490078 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-237202c4-f523-4df3-bc4b-c5d2ff4379ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-237202c4-f523-4df3-bc4b-c5d2ff4379ac_0">
											<gml:posList>35.67061685120349 139.7380202546395 40.926 35.67062059092745 139.73801902405532 40.926 35.67062059092745 139.73801902405532 43.796 35.67061685120349 139.7380202546395 43.796 35.67061685120349 139.7380202546395 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-eaeed73b-780a-4113-bfd4-ae3733188122">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eaeed73b-780a-4113-bfd4-ae3733188122">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eaeed73b-780a-4113-bfd4-ae3733188122">
											<gml:posList>35.67055115185563 139.7380224425818 17 35.6705498846883 139.73801581631864 17 35.670663700881946 139.73798143748462 17 35.670675917326044 139.7380419566796 17 35.6705624616641 139.73807633500465 17 35.67056083255258 139.73806794176429 17 35.6705276700086 139.73807803328197 17 35.67051843982667 139.73803231265606 17 35.67055115185563 139.7380224425818 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-963027be-ee07-4a5c-ad12-e85c4be583f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-963027be-ee07-4a5c-ad12-e85c4be583f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-963027be-ee07-4a5c-ad12-e85c4be583f9">
											<gml:posList>35.6705498846883 139.73801581631864 41.483 35.67055316764168 139.73801828678313 41.483 35.67066170304592 139.73798549385197 41.483 35.670663700881946 139.73798143748462 41.483 35.6705498846883 139.73801581631864 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c815abbd-0f41-4f8a-85c4-4785b07a5c88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c815abbd-0f41-4f8a-85c4-4785b07a5c88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c815abbd-0f41-4f8a-85c4-4785b07a5c88">
											<gml:posList>35.67055115185563 139.7380224425818 41.483 35.67055381932272 139.73802168826361 41.483 35.67055316764168 139.73801828678313 41.483 35.6705498846883 139.73801581631864 41.483 35.67055115185563 139.7380224425818 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41f23eba-74e2-4553-a954-22414e3000b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41f23eba-74e2-4553-a954-22414e3000b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41f23eba-74e2-4553-a954-22414e3000b9">
											<gml:posList>35.67055115185563 139.7380224425818 39.593 35.67051843982667 139.73803231265606 39.593 35.67052168666366 139.73803470583923 39.593 35.670551812340435 139.738025578941 39.593 35.67055115185563 139.7380224425818 39.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6033c61-da90-4613-8000-74347fcaed88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6033c61-da90-4613-8000-74347fcaed88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6033c61-da90-4613-8000-74347fcaed88">
											<gml:posList>35.670560189006366 139.73805203587997 40.926 35.6705271702725 139.73806160805813 40.926 35.67052966784779 139.73807397692374 40.926 35.67056285743258 139.738063885372 40.926 35.670564486544386 139.7380722786125 40.926 35.67067261637198 139.73803951937066 40.926 35.67066170304592 139.73798549385197 40.926 35.67055316764168 139.73801828678313 40.926 35.67055381932272 139.73802168826361 40.926 35.670560189006366 139.73805203587997 40.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fbbf05b-fbdb-4247-8987-2fb0cfdf19a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fbbf05b-fbdb-4247-8987-2fb0cfdf19a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fbbf05b-fbdb-4247-8987-2fb0cfdf19a3">
											<gml:posList>35.67055684295762 139.73804956548886 41.483 35.670560189006366 139.73805203587997 41.483 35.67055381932272 139.73802168826361 41.483 35.67055115185563 139.7380224425818 41.483 35.67055684295762 139.73804956548886 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff116eb9-7a4f-4788-9609-a6d5481cf611">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff116eb9-7a4f-4788-9609-a6d5481cf611">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff116eb9-7a4f-4788-9609-a6d5481cf611">
											<gml:posList>35.67052643760894 139.73805838341517 39.363 35.67055684295762 139.73804956548886 39.363 35.670551812340435 139.738025578941 39.363 35.67052168666366 139.73803470583923 39.363 35.67052643760894 139.73805838341517 39.363</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b43fc87-1236-45bb-b94c-68655514b0e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b43fc87-1236-45bb-b94c-68655514b0e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b43fc87-1236-45bb-b94c-68655514b0e0">
											<gml:posList>35.6705238512651 139.7380591376355 39.593 35.67052643760894 139.73805838341517 39.593 35.67052168666366 139.73803470583923 39.593 35.67051843982667 139.73803231265606 39.593 35.6705238512651 139.7380591376355 39.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d1f4316-f59b-499b-b2e7-7d20093d923b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d1f4316-f59b-499b-b2e7-7d20093d923b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d1f4316-f59b-499b-b2e7-7d20093d923b">
											<gml:posList>35.67055684295762 139.73804956548886 41.483 35.6705238512651 139.7380591376355 41.483 35.6705271702725 139.73806160805813 41.483 35.670560189006366 139.73805203587997 41.483 35.67055684295762 139.73804956548886 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21ae8fbc-a7e5-4e5d-b9c3-ad239a800bc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21ae8fbc-a7e5-4e5d-b9c3-ad239a800bc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21ae8fbc-a7e5-4e5d-b9c3-ad239a800bc3">
											<gml:posList>35.670675917326044 139.7380419566796 41.483 35.67067261637198 139.73803951937066 41.483 35.670564486544386 139.7380722786125 41.483 35.6705624616641 139.73807633500465 41.483 35.670675917326044 139.7380419566796 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-370059fd-527d-4aa5-80d7-02570c8ec596">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-370059fd-527d-4aa5-80d7-02570c8ec596">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-370059fd-527d-4aa5-80d7-02570c8ec596">
											<gml:posList>35.6705276700086 139.73807803328197 41.483 35.67052966784779 139.73807397692374 41.483 35.6705271702725 139.73806160805813 41.483 35.6705238512651 139.7380591376355 41.483 35.6705276700086 139.73807803328197 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f26faa2-c6fb-419c-a20b-562dc745acbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f26faa2-c6fb-419c-a20b-562dc745acbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f26faa2-c6fb-419c-a20b-562dc745acbd">
											<gml:posList>35.67056083255258 139.73806794176429 41.483 35.6705624616641 139.73807633500465 41.483 35.670564486544386 139.7380722786125 41.483 35.67056285743258 139.738063885372 41.483 35.67056083255258 139.73806794176429 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e433afea-e9eb-42e7-b681-cc06ada8d770">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e433afea-e9eb-42e7-b681-cc06ada8d770">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e433afea-e9eb-42e7-b681-cc06ada8d770">
											<gml:posList>35.67056083255258 139.73806794176429 41.483 35.67056285743258 139.738063885372 41.483 35.67052966784779 139.73807397692374 41.483 35.6705276700086 139.73807803328197 41.483 35.67056083255258 139.73806794176429 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-318f8269-f164-43ab-af7c-2c0353377817">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-318f8269-f164-43ab-af7c-2c0353377817">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-318f8269-f164-43ab-af7c-2c0353377817">
											<gml:posList>35.670663700881946 139.73798143748462 41.483 35.67066170304592 139.73798549385197 41.483 35.67067261637198 139.73803951937066 41.483 35.670675917326044 139.7380419566796 41.483 35.670663700881946 139.73798143748462 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25afad02-8b2a-442b-8f59-7ba7d876fe32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25afad02-8b2a-442b-8f59-7ba7d876fe32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25afad02-8b2a-442b-8f59-7ba7d876fe32">
											<gml:posList>35.6705276700086 139.73807803328197 17 35.6705276700086 139.73807803328197 41.483 35.6705238512651 139.7380591376355 41.483 35.6705238512651 139.7380591376355 39.593 35.67051843982667 139.73803231265606 39.593 35.67051843982667 139.73803231265606 17 35.6705276700086 139.73807803328197 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b13fd323-68ff-4009-92f8-47d5570c4b9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b13fd323-68ff-4009-92f8-47d5570c4b9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b13fd323-68ff-4009-92f8-47d5570c4b9e">
											<gml:posList>35.67052643760894 139.73805838341517 39.593 35.67052643760894 139.73805838341517 39.363 35.67052168666366 139.73803470583923 39.363 35.67052168666366 139.73803470583923 39.593 35.67052643760894 139.73805838341517 39.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2cf8d9c8-2450-43c0-a33c-8b040a10ba07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cf8d9c8-2450-43c0-a33c-8b040a10ba07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cf8d9c8-2450-43c0-a33c-8b040a10ba07">
											<gml:posList>35.67052966784779 139.73807397692374 41.483 35.67052966784779 139.73807397692374 40.926 35.6705271702725 139.73806160805813 40.926 35.6705271702725 139.73806160805813 41.483 35.67052966784779 139.73807397692374 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c58805e-1c8b-4c02-bea6-7a8abbb93662">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c58805e-1c8b-4c02-bea6-7a8abbb93662">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c58805e-1c8b-4c02-bea6-7a8abbb93662">
											<gml:posList>35.67055115185563 139.7380224425818 17 35.67051843982667 139.73803231265606 17 35.67051843982667 139.73803231265606 39.593 35.67055115185563 139.7380224425818 39.593 35.67055115185563 139.7380224425818 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c936a67b-18fe-48b8-83e7-bce95351ec54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c936a67b-18fe-48b8-83e7-bce95351ec54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c936a67b-18fe-48b8-83e7-bce95351ec54">
											<gml:posList>35.67052168666366 139.73803470583923 39.593 35.67052168666366 139.73803470583923 39.363 35.670551812340435 139.738025578941 39.363 35.670551812340435 139.738025578941 39.593 35.67052168666366 139.73803470583923 39.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-041ede1e-3f65-433c-be6e-8bea4a21959d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-041ede1e-3f65-433c-be6e-8bea4a21959d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-041ede1e-3f65-433c-be6e-8bea4a21959d">
											<gml:posList>35.67052643760894 139.73805838341517 39.593 35.6705238512651 139.7380591376355 39.593 35.6705238512651 139.7380591376355 41.483 35.67055684295762 139.73804956548886 41.483 35.67055684295762 139.73804956548886 39.363 35.67052643760894 139.73805838341517 39.363 35.67052643760894 139.73805838341517 39.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eea3bafc-508d-43d3-b375-c9a9f083191d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eea3bafc-508d-43d3-b375-c9a9f083191d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eea3bafc-508d-43d3-b375-c9a9f083191d">
											<gml:posList>35.6705271702725 139.73806160805813 41.483 35.6705271702725 139.73806160805813 40.926 35.670560189006366 139.73805203587997 40.926 35.670560189006366 139.73805203587997 41.483 35.6705271702725 139.73806160805813 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d759607-b37f-46e4-8098-fb2191131841">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d759607-b37f-46e4-8098-fb2191131841">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d759607-b37f-46e4-8098-fb2191131841">
											<gml:posList>35.6705276700086 139.73807803328197 17 35.67056083255258 139.73806794176429 17 35.67056083255258 139.73806794176429 41.483 35.6705276700086 139.73807803328197 41.483 35.6705276700086 139.73807803328197 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-856cdab8-ae70-409c-b8c5-470c1b13458d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-856cdab8-ae70-409c-b8c5-470c1b13458d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-856cdab8-ae70-409c-b8c5-470c1b13458d">
											<gml:posList>35.67056285743258 139.738063885372 41.483 35.67056285743258 139.738063885372 40.926 35.67052966784779 139.73807397692374 40.926 35.67052966784779 139.73807397692374 41.483 35.67056285743258 139.738063885372 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f3b0590-7d6a-4cce-81df-d29d6a0785a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f3b0590-7d6a-4cce-81df-d29d6a0785a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f3b0590-7d6a-4cce-81df-d29d6a0785a7">
											<gml:posList>35.6705498846883 139.73801581631864 41.483 35.6705498846883 139.73801581631864 17 35.67055115185563 139.7380224425818 17 35.67055115185563 139.7380224425818 39.593 35.67055115185563 139.7380224425818 41.483 35.6705498846883 139.73801581631864 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f749c430-b8ad-4377-a975-6f9adcaa355b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f749c430-b8ad-4377-a975-6f9adcaa355b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f749c430-b8ad-4377-a975-6f9adcaa355b">
											<gml:posList>35.67055381932272 139.73802168826361 41.483 35.67055381932272 139.73802168826361 40.926 35.67055316764168 139.73801828678313 40.926 35.67055316764168 139.73801828678313 41.483 35.67055381932272 139.73802168826361 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae6fa490-99dc-4bd1-be1f-b3072f674c2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae6fa490-99dc-4bd1-be1f-b3072f674c2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae6fa490-99dc-4bd1-be1f-b3072f674c2a">
											<gml:posList>35.67055115185563 139.7380224425818 41.483 35.67055115185563 139.7380224425818 39.593 35.670551812340435 139.738025578941 39.593 35.670551812340435 139.738025578941 39.363 35.67055684295762 139.73804956548886 39.363 35.67055684295762 139.73804956548886 41.483 35.67055115185563 139.7380224425818 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-943dff0e-2ac6-405e-9b30-c11bf1f2995a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-943dff0e-2ac6-405e-9b30-c11bf1f2995a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-943dff0e-2ac6-405e-9b30-c11bf1f2995a">
											<gml:posList>35.670560189006366 139.73805203587997 41.483 35.670560189006366 139.73805203587997 40.926 35.67055381932272 139.73802168826361 40.926 35.67055381932272 139.73802168826361 41.483 35.670560189006366 139.73805203587997 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c370dad-88a7-42bd-b8a8-52be145fc688">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c370dad-88a7-42bd-b8a8-52be145fc688">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c370dad-88a7-42bd-b8a8-52be145fc688">
											<gml:posList>35.67056083255258 139.73806794176429 17 35.6705624616641 139.73807633500465 17 35.6705624616641 139.73807633500465 41.483 35.67056083255258 139.73806794176429 41.483 35.67056083255258 139.73806794176429 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c260b35-6751-45bb-a80a-ba7268786f39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c260b35-6751-45bb-a80a-ba7268786f39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c260b35-6751-45bb-a80a-ba7268786f39">
											<gml:posList>35.670564486544386 139.7380722786125 41.483 35.670564486544386 139.7380722786125 40.926 35.67056285743258 139.738063885372 40.926 35.67056285743258 139.738063885372 41.483 35.670564486544386 139.7380722786125 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-033ba23d-7d9a-41c5-bba4-58649fad4713">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-033ba23d-7d9a-41c5-bba4-58649fad4713">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-033ba23d-7d9a-41c5-bba4-58649fad4713">
											<gml:posList>35.670663700881946 139.73798143748462 17 35.6705498846883 139.73801581631864 17 35.6705498846883 139.73801581631864 41.483 35.670663700881946 139.73798143748462 41.483 35.670663700881946 139.73798143748462 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d992567-2db9-48c5-bcdf-1f47146d6eaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d992567-2db9-48c5-bcdf-1f47146d6eaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d992567-2db9-48c5-bcdf-1f47146d6eaa">
											<gml:posList>35.67055316764168 139.73801828678313 41.483 35.67055316764168 139.73801828678313 40.926 35.67066170304592 139.73798549385197 40.926 35.67066170304592 139.73798549385197 41.483 35.67055316764168 139.73801828678313 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-881ad1fe-cf0c-40db-9811-b2d38e5d5b92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-881ad1fe-cf0c-40db-9811-b2d38e5d5b92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-881ad1fe-cf0c-40db-9811-b2d38e5d5b92">
											<gml:posList>35.67067261637198 139.73803951937066 41.483 35.67067261637198 139.73803951937066 40.926 35.670564486544386 139.7380722786125 40.926 35.670564486544386 139.7380722786125 41.483 35.67067261637198 139.73803951937066 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6309387a-6478-467e-9a4b-7b27c6f60bf7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6309387a-6478-467e-9a4b-7b27c6f60bf7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6309387a-6478-467e-9a4b-7b27c6f60bf7">
											<gml:posList>35.6705624616641 139.73807633500465 17 35.670675917326044 139.7380419566796 17 35.670675917326044 139.7380419566796 41.483 35.6705624616641 139.73807633500465 41.483 35.6705624616641 139.73807633500465 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b6566d3-6039-4f8a-b459-273cdbadb726">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b6566d3-6039-4f8a-b459-273cdbadb726">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b6566d3-6039-4f8a-b459-273cdbadb726">
											<gml:posList>35.67066170304592 139.73798549385197 41.483 35.67066170304592 139.73798549385197 40.926 35.67067261637198 139.73803951937066 40.926 35.67067261637198 139.73803951937066 41.483 35.67066170304592 139.73798549385197 41.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67490ba1-7018-47e6-a982-3bdc1e9c00a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67490ba1-7018-47e6-a982-3bdc1e9c00a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67490ba1-7018-47e6-a982-3bdc1e9c00a1">
											<gml:posList>35.670675917326044 139.7380419566796 17 35.670663700881946 139.73798143748462 17 35.670663700881946 139.73798143748462 41.483 35.670675917326044 139.7380419566796 41.483 35.670675917326044 139.7380419566796 17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8405</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">89.38305</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>