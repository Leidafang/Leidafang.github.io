<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_00f25bc6-d5fe-45a6-a1dd-aad5b0695b73">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">421</bldg:usage>
			<bldg:measuredHeight uom="m">5.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67407735572275 139.74657949642744 0 35.6740607260608 139.74649288567548 0 35.67404264867045 139.74639869844876 0 35.67377346461292 139.74647620698198 0 35.67379156003415 139.74657048226447 0 35.67380821682496 139.74665729155376 0 35.67385478106477 139.7466438415148 0 35.673857269094356 139.74665669722876 0 35.67402702554179 139.74660794107282 0 35.67402453730009 139.74659479811766 0 35.67407735572275 139.74657949642744 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67407735572275 139.74657949642744 19.87 35.67402453730009 139.74659479811766 19.87 35.67402702554179 139.74660794107282 19.87 35.673857269094356 139.74665669722876 19.87 35.67385478106477 139.7466438415148 19.87 35.67380821682496 139.74665729155376 19.87 35.67379156003415 139.74657048226447 19.87 35.67377346461292 139.74647620698198 19.87 35.67404264867045 139.74639869844876 19.87 35.6740607260608 139.74649288567548 19.87 35.67407735572275 139.74657949642744 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67407735572275 139.74657949642744 19.87 35.6740607260608 139.74649288567548 19.87 35.6740607260608 139.74649288567548 25.19 35.67407735572275 139.74657949642744 25.19 35.67407735572275 139.74657949642744 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6740607260608 139.74649288567548 19.87 35.67404264867045 139.74639869844876 19.87 35.67404264867045 139.74639869844876 25.19 35.6740607260608 139.74649288567548 25.19 35.6740607260608 139.74649288567548 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67404264867045 139.74639869844876 19.87 35.67377346461292 139.74647620698198 19.87 35.67377346461292 139.74647620698198 25.19 35.67404264867045 139.74639869844876 25.19 35.67404264867045 139.74639869844876 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67377346461292 139.74647620698198 19.87 35.67379156003415 139.74657048226447 19.87 35.67379156003415 139.74657048226447 25.19 35.67377346461292 139.74647620698198 25.19 35.67377346461292 139.74647620698198 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67379156003415 139.74657048226447 19.87 35.67380821682496 139.74665729155376 19.87 35.67380821682496 139.74665729155376 25.19 35.67379156003415 139.74657048226447 25.19 35.67379156003415 139.74657048226447 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67380821682496 139.74665729155376 19.87 35.67385478106477 139.7466438415148 19.87 35.67385478106477 139.7466438415148 25.19 35.67380821682496 139.74665729155376 25.19 35.67380821682496 139.74665729155376 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67385478106477 139.7466438415148 19.87 35.673857269094356 139.74665669722876 19.87 35.673857269094356 139.74665669722876 25.19 35.67385478106477 139.7466438415148 25.19 35.67385478106477 139.7466438415148 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673857269094356 139.74665669722876 19.87 35.67402702554179 139.74660794107282 19.87 35.67402702554179 139.74660794107282 25.19 35.673857269094356 139.74665669722876 25.19 35.673857269094356 139.74665669722876 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402702554179 139.74660794107282 19.87 35.67402453730009 139.74659479811766 19.87 35.67402453730009 139.74659479811766 25.19 35.67402702554179 139.74660794107282 25.19 35.67402702554179 139.74660794107282 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402453730009 139.74659479811766 19.87 35.67407735572275 139.74657949642744 19.87 35.67407735572275 139.74657949642744 25.19 35.67402453730009 139.74659479811766 25.19 35.67402453730009 139.74659479811766 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67407735572275 139.74657949642744 25.19 35.6740607260608 139.74649288567548 25.19 35.67404264867045 139.74639869844876 25.19 35.67377346461292 139.74647620698198 25.19 35.67379156003415 139.74657048226447 25.19 35.67380821682496 139.74665729155376 25.19 35.67385478106477 139.7466438415148 25.19 35.673857269094356 139.74665669722876 25.19 35.67402702554179 139.74660794107282 25.19 35.67402453730009 139.74659479811766 25.19 35.67407735572275 139.74657949642744 25.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-99dcbdfe-0bdc-4f46-b7e6-66a1b80d8205"/>
							<gml:surfaceMember xlink:href="#poly-5edbc2ac-795c-428b-80cd-9667e707ac6c"/>
							<gml:surfaceMember xlink:href="#poly-e75830b3-ab3c-4973-af58-a99c72208611"/>
							<gml:surfaceMember xlink:href="#poly-20e90221-9789-4256-a38e-81fe74bd21ac"/>
							<gml:surfaceMember xlink:href="#poly-19254790-08b4-49c9-863c-6cc64fdec092"/>
							<gml:surfaceMember xlink:href="#poly-2ce135ac-30ed-4c34-a784-8d44f8fbf17f"/>
							<gml:surfaceMember xlink:href="#poly-b36dee0c-2b48-4f8f-8afa-7a2c28119b2c"/>
							<gml:surfaceMember xlink:href="#poly-5dec0f58-a768-482f-9b3b-7855163517e4"/>
							<gml:surfaceMember xlink:href="#poly-a96f1093-c645-4f71-9b5b-54d864cdf7d5"/>
							<gml:surfaceMember xlink:href="#poly-c73c07fd-17ca-4eb9-9211-e856c0dda42e"/>
							<gml:surfaceMember xlink:href="#poly-74cc1dfe-5b89-48fd-9af2-27d0c92506b8"/>
							<gml:surfaceMember xlink:href="#poly-44ab0f64-1755-4a7b-9e7e-48182526d7e4"/>
							<gml:surfaceMember xlink:href="#poly-c8b67d0b-cf7d-4aa9-a01a-3fc5710ef6ef"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-99dcbdfe-0bdc-4f46-b7e6-66a1b80d8205">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99dcbdfe-0bdc-4f46-b7e6-66a1b80d8205">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99dcbdfe-0bdc-4f46-b7e6-66a1b80d8205">
											<gml:posList>35.67379156003416 139.74657048226447 19.87 35.67377346461292 139.74647620698198 19.87 35.67404264867043 139.74639869844876 19.87 35.67406072606079 139.74649288567545 19.87 35.67407735572274 139.74657949642744 19.87 35.6740245373001 139.74659479811766 19.87 35.674027025541776 139.74660794107282 19.87 35.673857269094356 139.74665669722873 19.87 35.673854781064755 139.7466438415148 19.87 35.67380821682494 139.74665729155373 19.87 35.67379156003416 139.74657048226447 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5edbc2ac-795c-428b-80cd-9667e707ac6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5edbc2ac-795c-428b-80cd-9667e707ac6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5edbc2ac-795c-428b-80cd-9667e707ac6c">
											<gml:posList>35.67406072606079 139.74649288567545 25.533 35.67404264867043 139.74639869844876 24.2 35.67377346461292 139.74647620698198 24.2 35.67379156003416 139.74657048226447 25.533 35.67406072606079 139.74649288567545 25.533</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e75830b3-ab3c-4973-af58-a99c72208611">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e75830b3-ab3c-4973-af58-a99c72208611">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e75830b3-ab3c-4973-af58-a99c72208611">
											<gml:posList>35.67380821682494 139.74665729155373 24.2 35.67407735572274 139.74657949642744 24.2 35.67406072606079 139.74649288567545 25.533 35.67379156003416 139.74657048226447 25.533 35.67380821682494 139.74665729155373 24.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20e90221-9789-4256-a38e-81fe74bd21ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20e90221-9789-4256-a38e-81fe74bd21ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20e90221-9789-4256-a38e-81fe74bd21ac">
											<gml:posList>35.673854781064755 139.7466438415148 22.2 35.673857269094356 139.74665669722873 22.2 35.674027025541776 139.74660794107282 22.2 35.674024528270465 139.7465947760339 22.2 35.673854781064755 139.7466438415148 22.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19254790-08b4-49c9-863c-6cc64fdec092">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19254790-08b4-49c9-863c-6cc64fdec092">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19254790-08b4-49c9-863c-6cc64fdec092">
											<gml:posList>35.67404264867043 139.74639869844876 24.2 35.67404264867043 139.74639869844876 19.87 35.67377346461292 139.74647620698198 19.87 35.67377346461292 139.74647620698198 24.2 35.67404264867043 139.74639869844876 24.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ce135ac-30ed-4c34-a784-8d44f8fbf17f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ce135ac-30ed-4c34-a784-8d44f8fbf17f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ce135ac-30ed-4c34-a784-8d44f8fbf17f">
											<gml:posList>35.67404264867043 139.74639869844876 24.2 35.67406072606079 139.74649288567545 25.533 35.67406072606079 139.74649288567545 19.87 35.67404264867043 139.74639869844876 19.87 35.67404264867043 139.74639869844876 24.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b36dee0c-2b48-4f8f-8afa-7a2c28119b2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b36dee0c-2b48-4f8f-8afa-7a2c28119b2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b36dee0c-2b48-4f8f-8afa-7a2c28119b2c">
											<gml:posList>35.67377346461292 139.74647620698198 24.2 35.67377346461292 139.74647620698198 19.87 35.67379156003416 139.74657048226447 19.87 35.67379156003416 139.74657048226447 25.533 35.67377346461292 139.74647620698198 24.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5dec0f58-a768-482f-9b3b-7855163517e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dec0f58-a768-482f-9b3b-7855163517e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dec0f58-a768-482f-9b3b-7855163517e4">
											<gml:posList>35.67406072606079 139.74649288567545 25.533 35.67407735572274 139.74657949642744 24.2 35.67407735572274 139.74657949642744 22.199 35.67407735572274 139.74657949642744 19.87 35.67406072606079 139.74649288567545 19.87 35.67406072606079 139.74649288567545 25.533</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a96f1093-c645-4f71-9b5b-54d864cdf7d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a96f1093-c645-4f71-9b5b-54d864cdf7d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a96f1093-c645-4f71-9b5b-54d864cdf7d5">
											<gml:posList>35.674027025541776 139.74660794107282 19.87 35.6740245373001 139.74659479811766 19.87 35.674024528270465 139.7465947760339 22.2 35.674027025541776 139.74660794107282 22.2 35.674027025541776 139.74660794107282 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c73c07fd-17ca-4eb9-9211-e856c0dda42e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c73c07fd-17ca-4eb9-9211-e856c0dda42e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c73c07fd-17ca-4eb9-9211-e856c0dda42e">
											<gml:posList>35.67380821682494 139.74665729155373 24.2 35.67379156003416 139.74657048226447 25.533 35.67379156003416 139.74657048226447 19.87 35.67380821682494 139.74665729155373 19.87 35.67380821682494 139.74665729155373 24.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74cc1dfe-5b89-48fd-9af2-27d0c92506b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74cc1dfe-5b89-48fd-9af2-27d0c92506b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74cc1dfe-5b89-48fd-9af2-27d0c92506b8">
											<gml:posList>35.674024528270465 139.7465947760339 22.2 35.6740245373001 139.74659479811766 19.87 35.67407735572274 139.74657949642744 19.87 35.67407735572274 139.74657949642744 22.199 35.67407735572274 139.74657949642744 24.2 35.67380821682494 139.74665729155373 24.2 35.67380821682494 139.74665729155373 19.87 35.673854781064755 139.7466438415148 19.87 35.673854781064755 139.7466438415148 22.2 35.674024528270465 139.7465947760339 22.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44ab0f64-1755-4a7b-9e7e-48182526d7e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44ab0f64-1755-4a7b-9e7e-48182526d7e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44ab0f64-1755-4a7b-9e7e-48182526d7e4">
											<gml:posList>35.673857269094356 139.74665669722873 19.87 35.674027025541776 139.74660794107282 19.87 35.674027025541776 139.74660794107282 22.2 35.673857269094356 139.74665669722873 22.2 35.673857269094356 139.74665669722873 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8b67d0b-cf7d-4aa9-a01a-3fc5710ef6ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8b67d0b-cf7d-4aa9-a01a-3fc5710ef6ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8b67d0b-cf7d-4aa9-a01a-3fc5710ef6ef">
											<gml:posList>35.673854781064755 139.7466438415148 19.87 35.673857269094356 139.74665669722873 19.87 35.673857269094356 139.74665669722873 22.2 35.673854781064755 139.7466438415148 22.2 35.673854781064755 139.7466438415148 19.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4561</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">535.1014</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1110</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>