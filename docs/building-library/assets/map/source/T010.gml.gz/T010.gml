<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_01a662bb-4c5d-43e7-a54a-98ecfdbb9cf7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671354033201034 139.73851515145384 0 35.671347148492835 139.73851741306004 0 35.6713435297907 139.7385006378702 0 35.671269401756035 139.73852464096709 0 35.67129446120533 139.73864081930617 0 35.6713630382447 139.73861864552202 0 35.67137221720642 139.73859952441347 0 35.671354033201034 139.73851515145384 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671354033201034 139.73851515145384 15.2 35.67137221720642 139.73859952441347 15.2 35.6713630382447 139.73861864552202 15.2 35.67129446120533 139.73864081930617 15.2 35.671269401756035 139.73852464096709 15.2 35.6713435297907 139.7385006378702 15.2 35.671347148492835 139.73851741306004 15.2 35.671354033201034 139.73851515145384 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671354033201034 139.73851515145384 15.2 35.671347148492835 139.73851741306004 15.2 35.671347148492835 139.73851741306004 29.2 35.671354033201034 139.73851515145384 29.2 35.671354033201034 139.73851515145384 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671347148492835 139.73851741306004 15.2 35.6713435297907 139.7385006378702 15.2 35.6713435297907 139.7385006378702 29.2 35.671347148492835 139.73851741306004 29.2 35.671347148492835 139.73851741306004 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6713435297907 139.7385006378702 15.2 35.671269401756035 139.73852464096709 15.2 35.671269401756035 139.73852464096709 29.2 35.6713435297907 139.7385006378702 29.2 35.6713435297907 139.7385006378702 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671269401756035 139.73852464096709 15.2 35.67129446120533 139.73864081930617 15.2 35.67129446120533 139.73864081930617 29.2 35.671269401756035 139.73852464096709 29.2 35.671269401756035 139.73852464096709 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129446120533 139.73864081930617 15.2 35.6713630382447 139.73861864552202 15.2 35.6713630382447 139.73861864552202 29.2 35.67129446120533 139.73864081930617 29.2 35.67129446120533 139.73864081930617 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6713630382447 139.73861864552202 15.2 35.67137221720642 139.73859952441347 15.2 35.67137221720642 139.73859952441347 29.2 35.6713630382447 139.73861864552202 29.2 35.6713630382447 139.73861864552202 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67137221720642 139.73859952441347 15.2 35.671354033201034 139.73851515145384 15.2 35.671354033201034 139.73851515145384 29.2 35.67137221720642 139.73859952441347 29.2 35.67137221720642 139.73859952441347 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671354033201034 139.73851515145384 29.2 35.671347148492835 139.73851741306004 29.2 35.6713435297907 139.7385006378702 29.2 35.671269401756035 139.73852464096709 29.2 35.67129446120533 139.73864081930617 29.2 35.6713630382447 139.73861864552202 29.2 35.67137221720642 139.73859952441347 29.2 35.671354033201034 139.73851515145384 29.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fc5bfc83-b85a-4b7e-9592-22dec3444f45"/>
							<gml:surfaceMember xlink:href="#poly-329ddc88-468b-4556-bc6d-7a2e424b8719"/>
							<gml:surfaceMember xlink:href="#poly-2dc1b68b-3adf-4319-9783-201354f4fab5"/>
							<gml:surfaceMember xlink:href="#poly-b9323220-b7e2-48fc-a798-f1a37f0bdb08"/>
							<gml:surfaceMember xlink:href="#poly-272e005f-3903-4c8c-832f-8d9d819f70c2"/>
							<gml:surfaceMember xlink:href="#poly-e71b5c1f-3cd7-4500-b48b-03b9d18a2994"/>
							<gml:surfaceMember xlink:href="#poly-f4aea957-2b7e-4197-b75a-ea7758856a50"/>
							<gml:surfaceMember xlink:href="#poly-4247cb58-6f6f-4005-994c-48e1830529f0"/>
							<gml:surfaceMember xlink:href="#poly-4c1024c7-dc5c-4c29-b29a-eb0bfc8fab1c"/>
							<gml:surfaceMember xlink:href="#poly-6613f2fd-7ac9-462f-a0ab-850424e94839"/>
							<gml:surfaceMember xlink:href="#poly-16791487-1abd-481e-a108-221b4ca4f736"/>
							<gml:surfaceMember xlink:href="#poly-60382d77-c3ac-41fd-8355-92eff0d8b890"/>
							<gml:surfaceMember xlink:href="#poly-6a726b0a-4a27-4f8f-976b-c218de8ddba3"/>
							<gml:surfaceMember xlink:href="#poly-dc3c54e6-5f6b-4c93-a54a-8d6d8b51c445"/>
							<gml:surfaceMember xlink:href="#poly-a91bc796-561a-427a-9348-f9032f17eec8"/>
							<gml:surfaceMember xlink:href="#poly-d4c50ea9-1c64-456f-9e43-dd33cc953a78"/>
							<gml:surfaceMember xlink:href="#poly-609f59c6-7d0a-4cb6-ad0b-3d5ad7895d65"/>
							<gml:surfaceMember xlink:href="#poly-7dacfc2d-8b1d-4f46-87c1-282627d00899"/>
							<gml:surfaceMember xlink:href="#poly-13491075-accc-4268-babd-e46fc904fe11"/>
							<gml:surfaceMember xlink:href="#poly-5cc7ea32-400f-4900-ae0b-1f8cba677a9d"/>
							<gml:surfaceMember xlink:href="#poly-9f85e4ce-401e-4e66-b62c-30bd561c4c01"/>
							<gml:surfaceMember xlink:href="#poly-f986823e-cb98-4259-b086-41002253b8d8"/>
							<gml:surfaceMember xlink:href="#poly-d857d8f5-db98-4282-9ff5-b7bfa84d20b1"/>
							<gml:surfaceMember xlink:href="#poly-ad8298f6-5d74-4cbb-bb03-a2e729c72cc9"/>
							<gml:surfaceMember xlink:href="#poly-9c5720ac-6d05-436f-88e9-483a3c281173"/>
							<gml:surfaceMember xlink:href="#poly-ac4df9f0-b830-4e02-b093-31d9cc325877"/>
							<gml:surfaceMember xlink:href="#poly-ca932f7d-93cf-4a85-9f57-2d9aced039cd"/>
							<gml:surfaceMember xlink:href="#poly-2d5af50e-3d28-430e-bc42-cfbdc97ba249"/>
							<gml:surfaceMember xlink:href="#poly-236f292a-a93d-4b58-9911-8c9fd8f2b6b7"/>
							<gml:surfaceMember xlink:href="#poly-489a82a2-0763-4275-9732-4110eab813ca"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_01a662bb-4c5d-43e7-a54a-98ecfdbb9cf7_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd26a6f1-a357-4d9e-8883-71813e2282b7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671287227023804 139.73856550255627 30.405 35.67128520012548 139.73855556320657 30.405 35.67129993402889 139.73855106095633 30.405 35.671301960927586 139.73856100030778 30.405 35.671287227023804 139.73856550255627 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-308e533d-65ef-431a-8be1-25633a0d7cb7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131258131781 139.738575270733 30.405 35.67130929468811 139.7385566614549 30.405 35.6713223258243 139.7385532106235 30.405 35.671325612445834 139.73857180885807 30.405 35.67131258131781 139.738575270733 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26b99077-119a-4830-913d-a85a0b23872e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26b99077-119a-4830-913d-a85a0b23872e_0">
											<gml:posList>35.67128520012548 139.73855556320657 30.405 35.671287227023804 139.73856550255627 30.405 35.671287227023804 139.73856550255627 33.048 35.67128520012548 139.73855556320657 33.048 35.67128520012548 139.73855556320657 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-933dd1fb-2fd0-4324-87b5-a9b82d6e6c29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-933dd1fb-2fd0-4324-87b5-a9b82d6e6c29_0">
											<gml:posList>35.67129993402889 139.73855106095633 30.405 35.67128520012548 139.73855556320657 30.405 35.67128520012548 139.73855556320657 33.048 35.67129993402889 139.73855106095633 33.048 35.67129993402889 139.73855106095633 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c009b4f-d5fb-48d4-aeba-7ac748c6cb6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c009b4f-d5fb-48d4-aeba-7ac748c6cb6c_0">
											<gml:posList>35.671287227023804 139.73856550255627 33.048 35.671301960927586 139.73856100030778 33.048 35.67129993402889 139.73855106095633 33.048 35.67128520012548 139.73855556320657 33.048 35.671287227023804 139.73856550255627 33.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbaaa59a-ca35-40cc-9adf-ebd1c30381ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbaaa59a-ca35-40cc-9adf-ebd1c30381ea_0">
											<gml:posList>35.671287227023804 139.73856550255627 30.405 35.671301960927586 139.73856100030778 30.405 35.671301960927586 139.73856100030778 33.048 35.671287227023804 139.73856550255627 33.048 35.671287227023804 139.73856550255627 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f90be6b3-248c-4f69-a5cc-55d790098e2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f90be6b3-248c-4f69-a5cc-55d790098e2d_0">
											<gml:posList>35.67129993402889 139.73855106095633 30.405 35.67129993402889 139.73855106095633 33.048 35.671301960927586 139.73856100030778 33.048 35.671301960927586 139.73856100030778 30.405 35.67129993402889 139.73855106095633 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3427424-cec1-4ef3-bb5f-34f18ad1a177">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3427424-cec1-4ef3-bb5f-34f18ad1a177_0">
											<gml:posList>35.67130929468811 139.7385566614549 30.405 35.67131258131781 139.738575270733 30.405 35.67131258131781 139.738575270733 32.77 35.67130929468811 139.7385566614549 32.77 35.67130929468811 139.7385566614549 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a690493-6c46-4357-9805-44e98ed799d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a690493-6c46-4357-9805-44e98ed799d9_0">
											<gml:posList>35.67130929468811 139.7385566614549 30.405 35.67130929468811 139.7385566614549 32.77 35.6713223258243 139.7385532106235 32.77 35.6713223258243 139.7385532106235 30.405 35.67130929468811 139.7385566614549 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e74de71f-6acb-4ea6-b023-c7f0fa3146c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e74de71f-6acb-4ea6-b023-c7f0fa3146c0_0">
											<gml:posList>35.67131258131781 139.738575270733 32.77 35.671325612445834 139.73857180885807 32.77 35.6713223258243 139.7385532106235 32.77 35.67130929468811 139.7385566614549 32.77 35.67131258131781 139.738575270733 32.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b02cf1a-166e-4c3b-b9ac-5a124fc2a263">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b02cf1a-166e-4c3b-b9ac-5a124fc2a263_0">
											<gml:posList>35.671325612445834 139.73857180885807 30.405 35.671325612445834 139.73857180885807 32.77 35.67131258131781 139.738575270733 32.77 35.67131258131781 139.738575270733 30.405 35.671325612445834 139.73857180885807 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f531c1f4-f37d-49e4-bc06-03465145bbd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f531c1f4-f37d-49e4-bc06-03465145bbd0_0">
											<gml:posList>35.671325612445834 139.73857180885807 30.405 35.6713223258243 139.7385532106235 30.405 35.6713223258243 139.7385532106235 32.77 35.671325612445834 139.73857180885807 32.77 35.671325612445834 139.73857180885807 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fc5bfc83-b85a-4b7e-9592-22dec3444f45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc5bfc83-b85a-4b7e-9592-22dec3444f45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc5bfc83-b85a-4b7e-9592-22dec3444f45">
											<gml:posList>35.6712944612053 139.73864081930617 15.2 35.671269401756035 139.7385246409671 15.2 35.671343529790704 139.73850063787017 15.2 35.67134714849282 139.73851741306004 15.2 35.671354033201 139.7385151514538 15.2 35.6713722172064 139.73859952441347 15.2 35.6713630382447 139.73861864552202 15.2 35.6712944612053 139.73864081930617 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-329ddc88-468b-4556-bc6d-7a2e424b8719">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-329ddc88-468b-4556-bc6d-7a2e424b8719">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-329ddc88-468b-4556-bc6d-7a2e424b8719">
											<gml:posList>35.671273243766784 139.738527386973 30.857 35.671269401756035 139.7385246409671 30.857 35.67128650008489 139.73860390064672 30.857 35.67128873178551 139.73859919225012 30.857 35.671273243766784 139.738527386973 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2dc1b68b-3adf-4319-9783-201354f4fab5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dc1b68b-3adf-4319-9783-201354f4fab5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dc1b68b-3adf-4319-9783-201354f4fab5">
											<gml:posList>35.671316453581284 139.73851339533584 30.857 35.67131869428336 139.73850867587797 30.857 35.671269401756035 139.7385246409671 30.857 35.671273243766784 139.738527386973 30.857 35.671316453581284 139.73851339533584 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9323220-b7e2-48fc-a798-f1a37f0bdb08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9323220-b7e2-48fc-a798-f1a37f0bdb08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9323220-b7e2-48fc-a798-f1a37f0bdb08">
											<gml:posList>35.67128873178551 139.73859919225012 30.405 35.671332923851786 139.73858487914282 30.405 35.671319276178025 139.73852649301458 30.405 35.671316453581284 139.73851339533584 30.405 35.671273243766784 139.738527386973 30.405 35.67128873178551 139.73859919225012 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-272e005f-3903-4c8c-832f-8d9d819f70c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-272e005f-3903-4c8c-832f-8d9d819f70c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-272e005f-3903-4c8c-832f-8d9d819f70c2">
											<gml:posList>35.67128873178551 139.73859919225012 30.857 35.67128650008489 139.73860390064672 30.857 35.67133683795352 139.7385876029758 30.857 35.671332923851786 139.73858487914282 30.857 35.67128873178551 139.73859919225012 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e71b5c1f-3cd7-4500-b48b-03b9d18a2994">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e71b5c1f-3cd7-4500-b48b-03b9d18a2994">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e71b5c1f-3cd7-4500-b48b-03b9d18a2994">
											<gml:posList>35.671316453581284 139.73851339533584 30.857 35.671319276178025 139.73852649301458 30.857 35.67132231299306 139.73852546210935 30.857 35.67131869428336 139.73850867587797 30.857 35.671316453581284 139.73851339533584 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4aea957-2b7e-4197-b75a-ea7758856a50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4aea957-2b7e-4197-b75a-ea7758856a50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4aea957-2b7e-4197-b75a-ea7758856a50">
											<gml:posList>35.67133683795352 139.7385876029758 30.857 35.67128650008489 139.73860390064672 30.857 35.6712944612053 139.73864081930617 26.192 35.6713630382447 139.73861864552202 26.192 35.67133683795352 139.7385876029758 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4247cb58-6f6f-4005-994c-48e1830529f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4247cb58-6f6f-4005-994c-48e1830529f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4247cb58-6f6f-4005-994c-48e1830529f0">
											<gml:posList>35.671332923851786 139.73858487914282 30.857 35.67133683795352 139.7385876029758 30.857 35.67132231299306 139.73852546210935 30.857 35.671319276178025 139.73852649301458 30.857 35.671332923851786 139.73858487914282 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c1024c7-dc5c-4c29-b29a-eb0bfc8fab1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c1024c7-dc5c-4c29-b29a-eb0bfc8fab1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c1024c7-dc5c-4c29-b29a-eb0bfc8fab1c">
											<gml:posList>35.67132231299306 139.73852546210935 30.857 35.67133683795352 139.7385876029758 30.857 35.67133978614438 139.73851978569465 28.288 35.67132231299306 139.73852546210935 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6613f2fd-7ac9-462f-a0ab-850424e94839">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6613f2fd-7ac9-462f-a0ab-850424e94839">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6613f2fd-7ac9-462f-a0ab-850424e94839">
											<gml:posList>35.671343529790704 139.73850063787017 28.288 35.67131869428336 139.73850867587797 28.288 35.67132231299306 139.73852546210935 28.288 35.67133978614438 139.73851978569465 28.288 35.67134714849282 139.73851741306004 28.288 35.671343529790704 139.73850063787017 28.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16791487-1abd-481e-a108-221b4ca4f736">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16791487-1abd-481e-a108-221b4ca4f736">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16791487-1abd-481e-a108-221b4ca4f736">
											<gml:posList>35.67134719354403 139.73851739091398 27.183 35.67133978614438 139.73851978569465 28.288 35.67133683795352 139.7385876029758 30.857 35.67134719354403 139.73851739091398 27.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60382d77-c3ac-41fd-8355-92eff0d8b890">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60382d77-c3ac-41fd-8355-92eff0d8b890">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60382d77-c3ac-41fd-8355-92eff0d8b890">
											<gml:posList>35.67134719354403 139.73851739091398 27.183 35.67133683795352 139.7385876029758 30.857 35.6713722172064 139.73859952441347 26.192 35.67134719354403 139.73851739091398 27.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a726b0a-4a27-4f8f-976b-c218de8ddba3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a726b0a-4a27-4f8f-976b-c218de8ddba3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a726b0a-4a27-4f8f-976b-c218de8ddba3">
											<gml:posList>35.6713630382447 139.73861864552202 26.192 35.6713722172064 139.73859952441347 26.192 35.67133683795352 139.7385876029758 30.857 35.6713630382447 139.73861864552202 26.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc3c54e6-5f6b-4c93-a54a-8d6d8b51c445">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc3c54e6-5f6b-4c93-a54a-8d6d8b51c445">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc3c54e6-5f6b-4c93-a54a-8d6d8b51c445">
											<gml:posList>35.67134719354403 139.73851739091398 27.183 35.6713722172064 139.73859952441347 26.192 35.671354033201 139.7385151514538 26.192 35.67134719354403 139.73851739091398 27.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a91bc796-561a-427a-9348-f9032f17eec8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a91bc796-561a-427a-9348-f9032f17eec8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a91bc796-561a-427a-9348-f9032f17eec8">
											<gml:posList>35.671273243766784 139.738527386973 30.405 35.671273243766784 139.738527386973 30.857 35.67128873178551 139.73859919225012 30.857 35.67128873178551 139.73859919225012 30.405 35.671273243766784 139.738527386973 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4c50ea9-1c64-456f-9e43-dd33cc953a78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4c50ea9-1c64-456f-9e43-dd33cc953a78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4c50ea9-1c64-456f-9e43-dd33cc953a78">
											<gml:posList>35.67128650008489 139.73860390064672 30.857 35.671269401756035 139.7385246409671 30.857 35.671269401756035 139.7385246409671 15.2 35.6712944612053 139.73864081930617 15.2 35.6712944612053 139.73864081930617 26.192 35.67128650008489 139.73860390064672 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-609f59c6-7d0a-4cb6-ad0b-3d5ad7895d65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-609f59c6-7d0a-4cb6-ad0b-3d5ad7895d65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-609f59c6-7d0a-4cb6-ad0b-3d5ad7895d65">
											<gml:posList>35.671316453581284 139.73851339533584 30.405 35.671316453581284 139.73851339533584 30.857 35.671273243766784 139.738527386973 30.857 35.671273243766784 139.738527386973 30.405 35.671316453581284 139.73851339533584 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7dacfc2d-8b1d-4f46-87c1-282627d00899">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dacfc2d-8b1d-4f46-87c1-282627d00899">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dacfc2d-8b1d-4f46-87c1-282627d00899">
											<gml:posList>35.671343529790704 139.73850063787017 15.2 35.671269401756035 139.7385246409671 15.2 35.671269401756035 139.7385246409671 30.857 35.67131869428336 139.73850867587797 30.857 35.67131869428336 139.73850867587797 28.288 35.671343529790704 139.73850063787017 28.288 35.671343529790704 139.73850063787017 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13491075-accc-4268-babd-e46fc904fe11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13491075-accc-4268-babd-e46fc904fe11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13491075-accc-4268-babd-e46fc904fe11">
											<gml:posList>35.67128873178551 139.73859919225012 30.405 35.67128873178551 139.73859919225012 30.857 35.671332923851786 139.73858487914282 30.857 35.671332923851786 139.73858487914282 30.405 35.67128873178551 139.73859919225012 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cc7ea32-400f-4900-ae0b-1f8cba677a9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cc7ea32-400f-4900-ae0b-1f8cba677a9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cc7ea32-400f-4900-ae0b-1f8cba677a9d">
											<gml:posList>35.671319276178025 139.73852649301458 30.405 35.671319276178025 139.73852649301458 30.857 35.671316453581284 139.73851339533584 30.857 35.671316453581284 139.73851339533584 30.405 35.671319276178025 139.73852649301458 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f85e4ce-401e-4e66-b62c-30bd561c4c01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f85e4ce-401e-4e66-b62c-30bd561c4c01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f85e4ce-401e-4e66-b62c-30bd561c4c01">
											<gml:posList>35.67132231299306 139.73852546210935 28.288 35.67131869428336 139.73850867587797 28.288 35.67131869428336 139.73850867587797 30.857 35.67132231299306 139.73852546210935 30.857 35.67132231299306 139.73852546210935 28.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f986823e-cb98-4259-b086-41002253b8d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f986823e-cb98-4259-b086-41002253b8d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f986823e-cb98-4259-b086-41002253b8d8">
											<gml:posList>35.671332923851786 139.73858487914282 30.405 35.671332923851786 139.73858487914282 30.857 35.671319276178025 139.73852649301458 30.857 35.671319276178025 139.73852649301458 30.405 35.671332923851786 139.73858487914282 30.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d857d8f5-db98-4282-9ff5-b7bfa84d20b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d857d8f5-db98-4282-9ff5-b7bfa84d20b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d857d8f5-db98-4282-9ff5-b7bfa84d20b1">
											<gml:posList>35.6713630382447 139.73861864552202 26.192 35.6712944612053 139.73864081930617 26.192 35.6712944612053 139.73864081930617 15.2 35.6713630382447 139.73861864552202 15.2 35.6713630382447 139.73861864552202 26.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad8298f6-5d74-4cbb-bb03-a2e729c72cc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad8298f6-5d74-4cbb-bb03-a2e729c72cc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad8298f6-5d74-4cbb-bb03-a2e729c72cc9">
											<gml:posList>35.67132231299306 139.73852546210935 30.857 35.67133978614438 139.73851978569465 28.288 35.67132231299306 139.73852546210935 28.288 35.67132231299306 139.73852546210935 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c5720ac-6d05-436f-88e9-483a3c281173">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c5720ac-6d05-436f-88e9-483a3c281173">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c5720ac-6d05-436f-88e9-483a3c281173">
											<gml:posList>35.67134719354403 139.73851739091398 27.183 35.67134714849282 139.73851741306004 28.288 35.67133978614438 139.73851978569465 28.288 35.67134719354403 139.73851739091398 27.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac4df9f0-b830-4e02-b093-31d9cc325877">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac4df9f0-b830-4e02-b093-31d9cc325877">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac4df9f0-b830-4e02-b093-31d9cc325877">
											<gml:posList>35.671343529790704 139.73850063787017 28.288 35.67134714849282 139.73851741306004 28.288 35.67134719354403 139.73851739091398 27.183 35.671343529790704 139.73850063787017 28.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca932f7d-93cf-4a85-9f57-2d9aced039cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca932f7d-93cf-4a85-9f57-2d9aced039cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca932f7d-93cf-4a85-9f57-2d9aced039cd">
											<gml:posList>35.671343529790704 139.73850063787017 15.2 35.671343529790704 139.73850063787017 28.288 35.67134719354403 139.73851739091398 27.183 35.67134714849282 139.73851741306004 15.2 35.671343529790704 139.73850063787017 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d5af50e-3d28-430e-bc42-cfbdc97ba249">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d5af50e-3d28-430e-bc42-cfbdc97ba249">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d5af50e-3d28-430e-bc42-cfbdc97ba249">
											<gml:posList>35.67134714849282 139.73851741306004 15.2 35.67134719354403 139.73851739091398 27.183 35.671354033201 139.7385151514538 26.192 35.671354033201 139.7385151514538 15.2 35.67134714849282 139.73851741306004 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-236f292a-a93d-4b58-9911-8c9fd8f2b6b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-236f292a-a93d-4b58-9911-8c9fd8f2b6b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-236f292a-a93d-4b58-9911-8c9fd8f2b6b7">
											<gml:posList>35.671354033201 139.7385151514538 26.192 35.6713722172064 139.73859952441347 26.192 35.6713722172064 139.73859952441347 15.2 35.671354033201 139.7385151514538 15.2 35.671354033201 139.7385151514538 26.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-489a82a2-0763-4275-9732-4110eab813ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-489a82a2-0763-4275-9732-4110eab813ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-489a82a2-0763-4275-9732-4110eab813ca">
											<gml:posList>35.6713722172064 139.73859952441347 26.192 35.6713630382447 139.73861864552202 26.192 35.6713630382447 139.73861864552202 15.2 35.6713722172064 139.73859952441347 15.2 35.6713722172064 139.73859952441347 26.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5298</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">94.4214</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>