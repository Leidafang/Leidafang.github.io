<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_01b68b1b-3f30-4752-b0c2-4dbd23d1af72">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">11.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6685405869109 139.7395634306869 0 35.66862646412158 139.73964882643503 0 35.66864996235242 139.7396133412526 0 35.668564085203 139.73952805597753 0 35.6685405869109 139.7395634306869 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6685405869109 139.7395634306869 11.468 35.668564085203 139.73952805597753 11.468 35.66864996235242 139.7396133412526 11.468 35.66862646412158 139.73964882643503 11.468 35.6685405869109 139.7395634306869 11.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6685405869109 139.7395634306869 11.468 35.66862646412158 139.73964882643503 11.468 35.66862646412158 139.73964882643503 22.7 35.6685405869109 139.7395634306869 22.7 35.6685405869109 139.7395634306869 11.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862646412158 139.73964882643503 11.468 35.66864996235242 139.7396133412526 11.468 35.66864996235242 139.7396133412526 22.7 35.66862646412158 139.73964882643503 22.7 35.66862646412158 139.73964882643503 11.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864996235242 139.7396133412526 11.468 35.668564085203 139.73952805597753 11.468 35.668564085203 139.73952805597753 22.7 35.66864996235242 139.7396133412526 22.7 35.66864996235242 139.7396133412526 11.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668564085203 139.73952805597753 11.468 35.6685405869109 139.7395634306869 11.468 35.6685405869109 139.7395634306869 22.7 35.668564085203 139.73952805597753 22.7 35.668564085203 139.73952805597753 11.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6685405869109 139.7395634306869 22.7 35.66862646412158 139.73964882643503 22.7 35.66864996235242 139.7396133412526 22.7 35.668564085203 139.73952805597753 22.7 35.6685405869109 139.7395634306869 22.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fd713804-37cd-499d-aab6-544b85950e31"/>
							<gml:surfaceMember xlink:href="#poly-2eb89897-0a48-4344-ba0d-d1d302660fa5"/>
							<gml:surfaceMember xlink:href="#poly-ab27e8c2-c03d-442a-9a07-d81e7617fe21"/>
							<gml:surfaceMember xlink:href="#poly-53bb2938-e735-4772-bca3-85aa2c058c17"/>
							<gml:surfaceMember xlink:href="#poly-0db5f934-d80c-44ed-8e69-513e70f2cd07"/>
							<gml:surfaceMember xlink:href="#poly-74514fac-4b65-4218-9f4e-3669d5c0aa0e"/>
							<gml:surfaceMember xlink:href="#poly-c7c77c55-03d5-4c5d-9b02-e9587fe381a1"/>
							<gml:surfaceMember xlink:href="#poly-a6b60518-1c08-4f33-b55a-89380af8cb94"/>
							<gml:surfaceMember xlink:href="#poly-f89ee1ed-1b0b-40cb-958d-4fbd8aed6ce1"/>
							<gml:surfaceMember xlink:href="#poly-818c3ab7-c2e9-4fdd-8e48-e14cc5656ac5"/>
							<gml:surfaceMember xlink:href="#poly-c41f4c47-a043-48b5-b65b-34c6fdfca95c"/>
							<gml:surfaceMember xlink:href="#poly-2d51d4d4-1a74-48c2-87d4-7c924cfc13d9"/>
							<gml:surfaceMember xlink:href="#poly-b3df9305-02e0-4814-bf31-a08e7fceb9e7"/>
							<gml:surfaceMember xlink:href="#poly-b572023d-5afd-4e2a-a127-7e94e7748045"/>
							<gml:surfaceMember xlink:href="#poly-05f12af6-a773-4afb-b039-8cc1dad5299a"/>
							<gml:surfaceMember xlink:href="#poly-08ad5ba7-88a5-4c33-9894-ab2f4b67ee10"/>
							<gml:surfaceMember xlink:href="#poly-aaebccbe-3a0b-474c-af18-2d855360f39b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fd713804-37cd-499d-aab6-544b85950e31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd713804-37cd-499d-aab6-544b85950e31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd713804-37cd-499d-aab6-544b85950e31">
											<gml:posList>35.668540586910886 139.73956343068687 11.468 35.66856408520299 139.7395280559775 11.468 35.66864996235241 139.7396133412526 11.468 35.66862646412155 139.73964882643503 11.468 35.668540586910886 139.73956343068687 11.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2eb89897-0a48-4344-ba0d-d1d302660fa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eb89897-0a48-4344-ba0d-d1d302660fa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eb89897-0a48-4344-ba0d-d1d302660fa5">
											<gml:posList>35.66854895986013 139.73955081740107 23.619 35.66855140233017 139.7395504942101 23.619 35.66856433088826 139.73953102706656 23.619 35.66856408520299 139.7395280559775 23.619 35.66854895986013 139.73955081740107 23.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab27e8c2-c03d-442a-9a07-d81e7617fe21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab27e8c2-c03d-442a-9a07-d81e7617fe21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab27e8c2-c03d-442a-9a07-d81e7617fe21">
											<gml:posList>35.6686167493975 139.7396167491079 23.619 35.66854895986013 139.73955081740107 23.619 35.668540586910886 139.73956343068687 20.603 35.6686167493975 139.7396167491079 23.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53bb2938-e735-4772-bca3-85aa2c058c17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53bb2938-e735-4772-bca3-85aa2c058c17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53bb2938-e735-4772-bca3-85aa2c058c17">
											<gml:posList>35.6686167493975 139.7396167491079 23.619 35.6686164586371 139.73961376702334 23.619 35.66855140233017 139.7395504942101 23.619 35.66854895986013 139.73955081740107 23.619 35.6686167493975 139.7396167491079 23.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0db5f934-d80c-44ed-8e69-513e70f2cd07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0db5f934-d80c-44ed-8e69-513e70f2cd07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0db5f934-d80c-44ed-8e69-513e70f2cd07">
											<gml:posList>35.668540586910886 139.73956343068687 20.603 35.66862646412155 139.73964882643503 20.603 35.6686167493975 139.7396167491079 23.619 35.668540586910886 139.73956343068687 20.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74514fac-4b65-4218-9f4e-3669d5c0aa0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74514fac-4b65-4218-9f4e-3669d5c0aa0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74514fac-4b65-4218-9f4e-3669d5c0aa0e">
											<gml:posList>35.668628612472055 139.73959487517277 23.408 35.66856433088826 139.73953102706656 23.408 35.66855140233017 139.7395504942101 23.408 35.6686164586371 139.73961376702334 23.408 35.668628612472055 139.73959487517277 23.408</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c7c77c55-03d5-4c5d-9b02-e9587fe381a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7c77c55-03d5-4c5d-9b02-e9587fe381a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7c77c55-03d5-4c5d-9b02-e9587fe381a1">
											<gml:posList>35.66856408520299 139.7395280559775 23.619 35.66856433088826 139.73953102706656 23.619 35.668628612472055 139.73959487517277 23.619 35.668631036914746 139.73959455200392 23.619 35.66856408520299 139.7395280559775 23.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6b60518-1c08-4f33-b55a-89380af8cb94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6b60518-1c08-4f33-b55a-89380af8cb94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6b60518-1c08-4f33-b55a-89380af8cb94">
											<gml:posList>35.668631036914746 139.73959455200392 23.619 35.668628612472055 139.73959487517277 23.619 35.6686164586371 139.73961376702334 23.619 35.6686167493975 139.7396167491079 23.619 35.668631036914746 139.73959455200392 23.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f89ee1ed-1b0b-40cb-958d-4fbd8aed6ce1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f89ee1ed-1b0b-40cb-958d-4fbd8aed6ce1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f89ee1ed-1b0b-40cb-958d-4fbd8aed6ce1">
											<gml:posList>35.66864996235241 139.7396133412526 20.603 35.668631036914746 139.73959455200392 23.619 35.6686167493975 139.7396167491079 23.619 35.66862646412155 139.73964882643503 20.603 35.66864996235241 139.7396133412526 20.603</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-818c3ab7-c2e9-4fdd-8e48-e14cc5656ac5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-818c3ab7-c2e9-4fdd-8e48-e14cc5656ac5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-818c3ab7-c2e9-4fdd-8e48-e14cc5656ac5">
											<gml:posList>35.6686164586371 139.73961376702334 23.619 35.6686164586371 139.73961376702334 23.408 35.66855140233017 139.7395504942101 23.408 35.66855140233017 139.7395504942101 23.619 35.6686164586371 139.73961376702334 23.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c41f4c47-a043-48b5-b65b-34c6fdfca95c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c41f4c47-a043-48b5-b65b-34c6fdfca95c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c41f4c47-a043-48b5-b65b-34c6fdfca95c">
											<gml:posList>35.66855140233017 139.7395504942101 23.619 35.66855140233017 139.7395504942101 23.408 35.66856433088826 139.73953102706656 23.408 35.66856433088826 139.73953102706656 23.619 35.66855140233017 139.7395504942101 23.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d51d4d4-1a74-48c2-87d4-7c924cfc13d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d51d4d4-1a74-48c2-87d4-7c924cfc13d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d51d4d4-1a74-48c2-87d4-7c924cfc13d9">
											<gml:posList>35.66856408520299 139.7395280559775 23.619 35.66856408520299 139.7395280559775 11.468 35.668540586910886 139.73956343068687 11.468 35.668540586910886 139.73956343068687 20.603 35.66854895986013 139.73955081740107 23.619 35.66856408520299 139.7395280559775 23.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3df9305-02e0-4814-bf31-a08e7fceb9e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3df9305-02e0-4814-bf31-a08e7fceb9e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3df9305-02e0-4814-bf31-a08e7fceb9e7">
											<gml:posList>35.66856433088826 139.73953102706656 23.619 35.66856433088826 139.73953102706656 23.408 35.668628612472055 139.73959487517277 23.408 35.668628612472055 139.73959487517277 23.619 35.66856433088826 139.73953102706656 23.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b572023d-5afd-4e2a-a127-7e94e7748045">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b572023d-5afd-4e2a-a127-7e94e7748045">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b572023d-5afd-4e2a-a127-7e94e7748045">
											<gml:posList>35.66864996235241 139.7396133412526 11.468 35.66856408520299 139.7395280559775 11.468 35.66856408520299 139.7395280559775 23.619 35.668631036914746 139.73959455200392 23.619 35.66864996235241 139.7396133412526 20.603 35.66864996235241 139.7396133412526 11.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05f12af6-a773-4afb-b039-8cc1dad5299a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05f12af6-a773-4afb-b039-8cc1dad5299a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05f12af6-a773-4afb-b039-8cc1dad5299a">
											<gml:posList>35.668628612472055 139.73959487517277 23.619 35.668628612472055 139.73959487517277 23.408 35.6686164586371 139.73961376702334 23.408 35.6686164586371 139.73961376702334 23.619 35.668628612472055 139.73959487517277 23.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08ad5ba7-88a5-4c33-9894-ab2f4b67ee10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08ad5ba7-88a5-4c33-9894-ab2f4b67ee10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08ad5ba7-88a5-4c33-9894-ab2f4b67ee10">
											<gml:posList>35.668540586910886 139.73956343068687 11.468 35.66862646412155 139.73964882643503 11.468 35.66862646412155 139.73964882643503 20.603 35.668540586910886 139.73956343068687 20.603 35.668540586910886 139.73956343068687 11.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aaebccbe-3a0b-474c-af18-2d855360f39b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aaebccbe-3a0b-474c-af18-2d855360f39b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aaebccbe-3a0b-474c-af18-2d855360f39b">
											<gml:posList>35.66862646412155 139.73964882643503 11.468 35.66864996235241 139.7396133412526 11.468 35.66864996235241 139.7396133412526 20.603 35.66862646412155 139.73964882643503 20.603 35.66862646412155 139.73964882643503 11.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10849</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">50.69995</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>