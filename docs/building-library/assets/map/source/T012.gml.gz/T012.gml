<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_01b8a644-eaf5-41fb-a0d5-c78dfe42ceb7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66940985101363 139.7495619198123 0 35.66944331418021 139.74946434751152 0 35.66939615677131 139.74944197320514 0 35.66936395492934 139.74953866044999 0 35.66940985101363 139.7495619198123 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66940985101363 139.7495619198123 6.36 35.66936395492934 139.74953866044999 6.36 35.66939615677131 139.74944197320514 6.36 35.66944331418021 139.74946434751152 6.36 35.66940985101363 139.7495619198123 6.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66940985101363 139.7495619198123 6.36 35.66944331418021 139.74946434751152 6.36 35.66944331418021 139.74946434751152 20.83 35.66940985101363 139.7495619198123 20.83 35.66940985101363 139.7495619198123 6.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66944331418021 139.74946434751152 6.36 35.66939615677131 139.74944197320514 6.36 35.66939615677131 139.74944197320514 20.83 35.66944331418021 139.74946434751152 20.83 35.66944331418021 139.74946434751152 6.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66939615677131 139.74944197320514 6.36 35.66936395492934 139.74953866044999 6.36 35.66936395492934 139.74953866044999 20.83 35.66939615677131 139.74944197320514 20.83 35.66939615677131 139.74944197320514 6.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66936395492934 139.74953866044999 6.36 35.66940985101363 139.7495619198123 6.36 35.66940985101363 139.7495619198123 20.83 35.66936395492934 139.74953866044999 20.83 35.66936395492934 139.74953866044999 6.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66940985101363 139.7495619198123 20.83 35.66944331418021 139.74946434751152 20.83 35.66939615677131 139.74944197320514 20.83 35.66936395492934 139.74953866044999 20.83 35.66940985101363 139.7495619198123 20.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-649dee80-c6b1-4047-979f-d98d8c233a62"/>
							<gml:surfaceMember xlink:href="#poly-8c489701-d2ff-4898-b5f9-524fc34bc7c8"/>
							<gml:surfaceMember xlink:href="#poly-9e82c03c-f3f1-4fb0-ab2d-33f85490d70b"/>
							<gml:surfaceMember xlink:href="#poly-23f26fa4-87ce-475e-b4c7-4f401302ec8d"/>
							<gml:surfaceMember xlink:href="#poly-e42f9026-307b-4a1a-90e4-836fb7159403"/>
							<gml:surfaceMember xlink:href="#poly-2dd85dcf-25ae-4af6-843b-6820523e1b30"/>
							<gml:surfaceMember xlink:href="#poly-8a05a14d-0f5a-4559-9199-064cbf304939"/>
							<gml:surfaceMember xlink:href="#poly-9782d929-6391-4748-a31d-cdb806378f5d"/>
							<gml:surfaceMember xlink:href="#poly-2140253b-4415-4370-bcb7-6dfd53e03333"/>
							<gml:surfaceMember xlink:href="#poly-8c9413b2-4781-4574-b635-785835b23b03"/>
							<gml:surfaceMember xlink:href="#poly-1667191f-c899-4f12-8ab7-16852507078e"/>
							<gml:surfaceMember xlink:href="#poly-e7ef85fc-e9c7-4703-9cc9-33af7ac7d48a"/>
							<gml:surfaceMember xlink:href="#poly-2f89404b-815d-4383-a9fb-29f1df9f7913"/>
							<gml:surfaceMember xlink:href="#poly-fd814ada-5e00-472e-ba64-ec9c7ca47c82"/>
							<gml:surfaceMember xlink:href="#poly-98dccb31-8954-4cb8-b267-f5990b27b3b2"/>
							<gml:surfaceMember xlink:href="#poly-3f6bea12-5272-4a22-8094-247606360d1f"/>
							<gml:surfaceMember xlink:href="#poly-c51214c9-8a85-439a-b475-1c238abb4b1a"/>
							<gml:surfaceMember xlink:href="#poly-a1fb73a1-2009-466f-a11d-13b9ab57f612"/>
							<gml:surfaceMember xlink:href="#poly-a6a3107b-5080-4908-99f7-0c00544bfe38"/>
							<gml:surfaceMember xlink:href="#poly-56ec4b0c-b5dd-4ddb-b08d-11fe786f56a9"/>
							<gml:surfaceMember xlink:href="#poly-30c77f67-f518-4db8-8b00-1358fb66c5ab"/>
							<gml:surfaceMember xlink:href="#poly-3e6b1c7e-a5bf-47fa-b942-8e1ace308670"/>
							<gml:surfaceMember xlink:href="#poly-6af65181-c004-4992-9ebf-997b6e32fd06"/>
							<gml:surfaceMember xlink:href="#poly-bf11e99e-fa1a-4b64-b6d3-8af72fe030bd"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-649dee80-c6b1-4047-979f-d98d8c233a62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-649dee80-c6b1-4047-979f-d98d8c233a62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-649dee80-c6b1-4047-979f-d98d8c233a62">
											<gml:posList>35.66940985101364 139.74956191981227 6.36 35.66936395492933 139.74953866044999 6.36 35.66939615677132 139.74944197320514 6.36 35.66944331418019 139.74946434751152 6.36 35.66940985101364 139.74956191981227 6.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c489701-d2ff-4898-b5f9-524fc34bc7c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c489701-d2ff-4898-b5f9-524fc34bc7c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c489701-d2ff-4898-b5f9-524fc34bc7c8">
											<gml:posList>35.66936395492933 139.74953866044999 22.1 35.66936863139297 139.74953626960058 22.1 35.669394356885576 139.7494590192584 22.1 35.66939236091252 139.74945336573074 22.1 35.66936395492933 139.74953866044999 22.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e82c03c-f3f1-4fb0-ab2d-33f85490d70b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e82c03c-f3f1-4fb0-ab2d-33f85490d70b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e82c03c-f3f1-4fb0-ab2d-33f85490d70b">
											<gml:posList>35.66939472063199 139.7495542475176 22.1 35.669392787698 139.74954850555267 22.1 35.66936863139297 139.74953626960058 22.1 35.66936395492933 139.74953866044999 22.1 35.66939472063199 139.7495542475176 22.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-23f26fa4-87ce-475e-b4c7-4f401302ec8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23f26fa4-87ce-475e-b4c7-4f401302ec8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23f26fa4-87ce-475e-b4c7-4f401302ec8d">
											<gml:posList>35.669394356885576 139.7494590192584 21.523 35.66936863139297 139.74953626960058 21.523 35.669392787698 139.74954850555267 21.523 35.66941701169087 139.74947669145632 21.523 35.66941896353076 139.7494707465982 21.523 35.669394356885576 139.7494590192584 21.523</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e42f9026-307b-4a1a-90e4-836fb7159403">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e42f9026-307b-4a1a-90e4-836fb7159403">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e42f9026-307b-4a1a-90e4-836fb7159403">
											<gml:posList>35.669420338902064 139.74947833384965 22.1 35.66941701169087 139.74947669145632 22.1 35.669392787698 139.74954850555267 22.1 35.66939472063199 139.7495542475176 22.1 35.669420338902064 139.74947833384965 22.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2dd85dcf-25ae-4af6-843b-6820523e1b30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dd85dcf-25ae-4af6-843b-6820523e1b30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dd85dcf-25ae-4af6-843b-6820523e1b30">
											<gml:posList>35.66939236091252 139.74945336573074 22.1 35.669394356885576 139.7494590192584 22.1 35.66941896353076 139.7494707465982 22.1 35.66942364894518 139.74946826736482 22.1 35.66939236091252 139.74945336573074 22.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a05a14d-0f5a-4559-9199-064cbf304939">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a05a14d-0f5a-4559-9199-064cbf304939">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a05a14d-0f5a-4559-9199-064cbf304939">
											<gml:posList>35.66939615677132 139.74944197320514 19.043 35.66939236091252 139.74945336573074 21.421 35.66942364894518 139.74946826736482 21.421 35.669427183284206 139.749456698371 19.043 35.66939615677132 139.74944197320514 19.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9782d929-6391-4748-a31d-cdb806378f5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9782d929-6391-4748-a31d-cdb806378f5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9782d929-6391-4748-a31d-cdb806378f5d">
											<gml:posList>35.669420338902064 139.74947833384965 20.1 35.66939472063199 139.7495542475176 20.1 35.66940985101364 139.74956191981227 20.1 35.669435883919874 139.74948600569886 20.1 35.669420338902064 139.74947833384965 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2140253b-4415-4370-bcb7-6dfd53e03333">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2140253b-4415-4370-bcb7-6dfd53e03333">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2140253b-4415-4370-bcb7-6dfd53e03333">
											<gml:posList>35.66942364894518 139.74946826736482 22.1 35.66941896353076 139.7494707465982 22.1 35.66941701169087 139.74947669145632 22.1 35.669420338902064 139.74947833384965 22.1 35.66942364894518 139.74946826736482 22.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c9413b2-4781-4574-b635-785835b23b03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c9413b2-4781-4574-b635-785835b23b03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c9413b2-4781-4574-b635-785835b23b03">
											<gml:posList>35.66942364894518 139.74946826736482 17.6 35.669420338902064 139.74947833384965 17.6 35.669435883919874 139.74948600569886 17.6 35.66944331418019 139.74946434751152 17.6 35.669427183284206 139.749456698371 17.6 35.66942364894518 139.74946826736482 17.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1667191f-c899-4f12-8ab7-16852507078e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1667191f-c899-4f12-8ab7-16852507078e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1667191f-c899-4f12-8ab7-16852507078e">
											<gml:posList>35.66941701169087 139.74947669145632 22.1 35.66941701169087 139.74947669145632 21.523 35.669392787698 139.74954850555267 21.523 35.669392787698 139.74954850555267 22.1 35.66941701169087 139.74947669145632 22.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7ef85fc-e9c7-4703-9cc9-33af7ac7d48a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7ef85fc-e9c7-4703-9cc9-33af7ac7d48a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7ef85fc-e9c7-4703-9cc9-33af7ac7d48a">
											<gml:posList>35.66936395492933 139.74953866044999 6.36 35.66936395492933 139.74953866044999 22.1 35.66939236091252 139.74945336573074 22.1 35.66939236091252 139.74945336573074 21.421 35.66939615677132 139.74944197320514 19.043 35.66939615677132 139.74944197320514 6.36 35.66936395492933 139.74953866044999 6.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f89404b-815d-4383-a9fb-29f1df9f7913">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f89404b-815d-4383-a9fb-29f1df9f7913">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f89404b-815d-4383-a9fb-29f1df9f7913">
											<gml:posList>35.669392787698 139.74954850555267 22.1 35.669392787698 139.74954850555267 21.523 35.66936863139297 139.74953626960058 21.523 35.66936863139297 139.74953626960058 22.1 35.669392787698 139.74954850555267 22.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd814ada-5e00-472e-ba64-ec9c7ca47c82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd814ada-5e00-472e-ba64-ec9c7ca47c82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd814ada-5e00-472e-ba64-ec9c7ca47c82">
											<gml:posList>35.66936863139297 139.74953626960058 22.1 35.66936863139297 139.74953626960058 21.523 35.669394356885576 139.7494590192584 21.523 35.669394356885576 139.7494590192584 22.1 35.66936863139297 139.74953626960058 22.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98dccb31-8954-4cb8-b267-f5990b27b3b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98dccb31-8954-4cb8-b267-f5990b27b3b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98dccb31-8954-4cb8-b267-f5990b27b3b2">
											<gml:posList>35.66939472063199 139.7495542475176 20.1 35.66939472063199 139.7495542475176 22.1 35.66936395492933 139.74953866044999 22.1 35.66936395492933 139.74953866044999 6.36 35.66940985101364 139.74956191981227 6.36 35.66940985101364 139.74956191981227 20.1 35.66939472063199 139.7495542475176 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f6bea12-5272-4a22-8094-247606360d1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f6bea12-5272-4a22-8094-247606360d1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f6bea12-5272-4a22-8094-247606360d1f">
											<gml:posList>35.669394356885576 139.7494590192584 22.1 35.669394356885576 139.7494590192584 21.523 35.66941896353076 139.7494707465982 21.523 35.66941896353076 139.7494707465982 22.1 35.669394356885576 139.7494590192584 22.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c51214c9-8a85-439a-b475-1c238abb4b1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c51214c9-8a85-439a-b475-1c238abb4b1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c51214c9-8a85-439a-b475-1c238abb4b1a">
											<gml:posList>35.669420338902064 139.74947833384965 20.1 35.669420338902064 139.74947833384965 22.1 35.66939472063199 139.7495542475176 22.1 35.66939472063199 139.7495542475176 20.1 35.669420338902064 139.74947833384965 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1fb73a1-2009-466f-a11d-13b9ab57f612">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1fb73a1-2009-466f-a11d-13b9ab57f612">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1fb73a1-2009-466f-a11d-13b9ab57f612">
											<gml:posList>35.66942364894518 139.74946826736482 22.1 35.66942364894518 139.74946826736482 21.421 35.66939236091252 139.74945336573074 21.421 35.66939236091252 139.74945336573074 22.1 35.66942364894518 139.74946826736482 22.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6a3107b-5080-4908-99f7-0c00544bfe38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6a3107b-5080-4908-99f7-0c00544bfe38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6a3107b-5080-4908-99f7-0c00544bfe38">
											<gml:posList>35.66941896353076 139.7494707465982 22.1 35.66941896353076 139.7494707465982 21.523 35.66941701169087 139.74947669145632 21.523 35.66941701169087 139.74947669145632 22.1 35.66941896353076 139.7494707465982 22.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56ec4b0c-b5dd-4ddb-b08d-11fe786f56a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56ec4b0c-b5dd-4ddb-b08d-11fe786f56a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56ec4b0c-b5dd-4ddb-b08d-11fe786f56a9">
											<gml:posList>35.66944331418019 139.74946434751152 6.36 35.66939615677132 139.74944197320514 6.36 35.66939615677132 139.74944197320514 19.043 35.669427183284206 139.749456698371 19.043 35.669427183284206 139.749456698371 17.6 35.66944331418019 139.74946434751152 17.6 35.66944331418019 139.74946434751152 6.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30c77f67-f518-4db8-8b00-1358fb66c5ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30c77f67-f518-4db8-8b00-1358fb66c5ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30c77f67-f518-4db8-8b00-1358fb66c5ab">
											<gml:posList>35.669420338902064 139.74947833384965 20.1 35.669420338902064 139.74947833384965 17.6 35.66942364894518 139.74946826736482 17.6 35.66942364894518 139.74946826736482 21.421 35.66942364894518 139.74946826736482 22.1 35.669420338902064 139.74947833384965 22.1 35.669420338902064 139.74947833384965 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e6b1c7e-a5bf-47fa-b942-8e1ace308670">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e6b1c7e-a5bf-47fa-b942-8e1ace308670">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e6b1c7e-a5bf-47fa-b942-8e1ace308670">
											<gml:posList>35.66942364894518 139.74946826736482 17.6 35.669427183284206 139.749456698371 17.6 35.669427183284206 139.749456698371 19.043 35.66942364894518 139.74946826736482 21.421 35.66942364894518 139.74946826736482 17.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6af65181-c004-4992-9ebf-997b6e32fd06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6af65181-c004-4992-9ebf-997b6e32fd06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6af65181-c004-4992-9ebf-997b6e32fd06">
											<gml:posList>35.66940985101364 139.74956191981227 20.1 35.66940985101364 139.74956191981227 6.36 35.66944331418019 139.74946434751152 6.36 35.66944331418019 139.74946434751152 17.6 35.669435883919874 139.74948600569886 17.6 35.669435883919874 139.74948600569886 20.1 35.66940985101364 139.74956191981227 20.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf11e99e-fa1a-4b64-b6d3-8af72fe030bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf11e99e-fa1a-4b64-b6d3-8af72fe030bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf11e99e-fa1a-4b64-b6d3-8af72fe030bd">
											<gml:posList>35.669420338902064 139.74947833384965 17.6 35.669420338902064 139.74947833384965 20.1 35.669435883919874 139.74948600569886 20.1 35.669435883919874 139.74948600569886 17.6 35.669420338902064 139.74947833384965 17.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-264</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">52.9119</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>