<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_02b0148a-0e3c-4a99-a75e-b8b1371aa671">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">19.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668617396666164 139.73911785501718 0 35.668513745690134 139.7390116038068 0 35.66848358431206 139.73905582327856 0 35.66854030822131 139.73911402426455 0 35.66855851313235 139.7390873709467 0 35.668574948795204 139.73910352298793 0 35.66855645576116 139.7391305853484 0 35.66858714511233 139.73916207461212 0 35.668617396666164 139.73911785501718 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668617396666164 139.73911785501718 12.439 35.66858714511233 139.73916207461212 12.439 35.66855645576116 139.7391305853484 12.439 35.668574948795204 139.73910352298793 12.439 35.66855851313235 139.7390873709467 12.439 35.66854030822131 139.73911402426455 12.439 35.66848358431206 139.73905582327856 12.439 35.668513745690134 139.7390116038068 12.439 35.668617396666164 139.73911785501718 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668617396666164 139.73911785501718 12.439 35.668513745690134 139.7390116038068 12.439 35.668513745690134 139.7390116038068 31.83 35.668617396666164 139.73911785501718 31.83 35.668617396666164 139.73911785501718 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668513745690134 139.7390116038068 12.439 35.66848358431206 139.73905582327856 12.439 35.66848358431206 139.73905582327856 31.83 35.668513745690134 139.7390116038068 31.83 35.668513745690134 139.7390116038068 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848358431206 139.73905582327856 12.439 35.66854030822131 139.73911402426455 12.439 35.66854030822131 139.73911402426455 31.83 35.66848358431206 139.73905582327856 31.83 35.66848358431206 139.73905582327856 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854030822131 139.73911402426455 12.439 35.66855851313235 139.7390873709467 12.439 35.66855851313235 139.7390873709467 31.83 35.66854030822131 139.73911402426455 31.83 35.66854030822131 139.73911402426455 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855851313235 139.7390873709467 12.439 35.668574948795204 139.73910352298793 12.439 35.668574948795204 139.73910352298793 31.83 35.66855851313235 139.7390873709467 31.83 35.66855851313235 139.7390873709467 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668574948795204 139.73910352298793 12.439 35.66855645576116 139.7391305853484 12.439 35.66855645576116 139.7391305853484 31.83 35.668574948795204 139.73910352298793 31.83 35.668574948795204 139.73910352298793 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855645576116 139.7391305853484 12.439 35.66858714511233 139.73916207461212 12.439 35.66858714511233 139.73916207461212 31.83 35.66855645576116 139.7391305853484 31.83 35.66855645576116 139.7391305853484 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858714511233 139.73916207461212 12.439 35.668617396666164 139.73911785501718 12.439 35.668617396666164 139.73911785501718 31.83 35.66858714511233 139.73916207461212 31.83 35.66858714511233 139.73916207461212 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668617396666164 139.73911785501718 31.83 35.668513745690134 139.7390116038068 31.83 35.66848358431206 139.73905582327856 31.83 35.66854030822131 139.73911402426455 31.83 35.66855851313235 139.7390873709467 31.83 35.668574948795204 139.73910352298793 31.83 35.66855645576116 139.7391305853484 31.83 35.66858714511233 139.73916207461212 31.83 35.668617396666164 139.73911785501718 31.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-576e5b9f-7976-4caf-8533-315b9d4118a7"/>
							<gml:surfaceMember xlink:href="#poly-66a344de-f986-4321-8225-5cab3fa28305"/>
							<gml:surfaceMember xlink:href="#poly-2b5c0900-da74-4701-abed-4e6b06048cb6"/>
							<gml:surfaceMember xlink:href="#poly-bca81332-b27b-480d-bc50-96f48f4926c3"/>
							<gml:surfaceMember xlink:href="#poly-8fffc6d5-9ad8-40a8-9147-b1f552213289"/>
							<gml:surfaceMember xlink:href="#poly-ebf2bd35-62ed-456c-a857-b448df07b901"/>
							<gml:surfaceMember xlink:href="#poly-289406c4-66b3-42e9-9d13-e8a02804da40"/>
							<gml:surfaceMember xlink:href="#poly-f8521bc6-2b41-47cc-b3b9-abe84f57d337"/>
							<gml:surfaceMember xlink:href="#poly-df1092b0-7c72-411e-8297-688819b47061"/>
							<gml:surfaceMember xlink:href="#poly-d5870278-d4ac-4575-9cd1-568f55abd141"/>
							<gml:surfaceMember xlink:href="#poly-f1610a07-aebb-4ae1-aff5-71a0ef722348"/>
							<gml:surfaceMember xlink:href="#poly-368ff2f7-2bf7-42bb-9f5b-c21cb8c497e8"/>
							<gml:surfaceMember xlink:href="#poly-09d773fd-40e1-4267-8283-d610ee0f3c02"/>
							<gml:surfaceMember xlink:href="#poly-3988f7cb-bb54-4dcc-a775-0190ec5c61d8"/>
							<gml:surfaceMember xlink:href="#poly-acf4027c-89e5-4f9e-82d5-5e15f60dbab2"/>
							<gml:surfaceMember xlink:href="#poly-db917584-a474-4433-a7c7-0e76fc1fc8d8"/>
							<gml:surfaceMember xlink:href="#poly-cfa59970-0e63-4627-8922-df5084481ee4"/>
							<gml:surfaceMember xlink:href="#poly-0099085c-6e6c-44cd-9448-c3800dda2135"/>
							<gml:surfaceMember xlink:href="#poly-26921e53-dbac-48a8-a170-6656eb38fad9"/>
							<gml:surfaceMember xlink:href="#poly-8d7cf789-325b-48ee-9076-c7482727edc5"/>
							<gml:surfaceMember xlink:href="#poly-f2c20c7d-6827-40c3-a615-f69bf0c930a9"/>
							<gml:surfaceMember xlink:href="#poly-5405712e-17dd-4c4e-8c2d-14e651aea040"/>
							<gml:surfaceMember xlink:href="#poly-e0d37a09-50fa-4e51-ad35-ab1b656a120a"/>
							<gml:surfaceMember xlink:href="#poly-9bf7deda-d360-4f4a-8ef6-47194cb73739"/>
							<gml:surfaceMember xlink:href="#poly-32efd060-a238-4c8c-ad85-4e30b7c6e1ea"/>
							<gml:surfaceMember xlink:href="#poly-1a6313c9-a637-48ff-ab2e-09ee78436c0a"/>
							<gml:surfaceMember xlink:href="#poly-ed9d1ffe-bfed-4cee-abac-ae44ac30ca5f"/>
							<gml:surfaceMember xlink:href="#poly-29bb7148-0d23-44f2-aad1-ced55ef9e7eb"/>
							<gml:surfaceMember xlink:href="#poly-1c19e3a4-1ac1-452b-9d1b-a608818f4b2a"/>
							<gml:surfaceMember xlink:href="#poly-26843b48-2299-4c16-9c4b-4a44834967f7"/>
							<gml:surfaceMember xlink:href="#poly-08095d65-8260-47ba-9d37-fb75ec4f3b8e"/>
							<gml:surfaceMember xlink:href="#poly-7f5db911-5af8-47bc-8a48-d1f058b76b38"/>
							<gml:surfaceMember xlink:href="#poly-c39523f3-53e2-4482-ba6e-a87d8c873b5b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_02b0148a-0e3c-4a99-a75e-b8b1371aa671_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7881e8ab-b762-4cc7-a3f6-e7d741163cbe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855732009364 139.73912932508802 12.54 35.668556455761156 139.7391305853484 12.54 35.66854030822132 139.73911402426455 12.54 35.668558513132375 139.7390873709467 12.54 35.66857493078504 139.73910354510113 12.54 35.66855732009364 139.73912932508802 12.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7af12f21-b739-4f93-9fff-c801a33b60db">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855938187751 139.73912630710538 26.914 35.66855732009364 139.73912932508802 26.914 35.668574939790126 139.73910353404452 26.914 35.66855938187751 139.73912630710538 26.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0910b89a-f0ea-4706-bf3d-140d1e732a12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0910b89a-f0ea-4706-bf3d-140d1e732a12_0">
											<gml:posList>35.66854030822132 139.73911402426455 12.54 35.668556455761156 139.7391305853484 12.54 35.668556455761156 139.7391305853484 32.822 35.66854030822132 139.73911402426455 32.822 35.66854030822132 139.73911402426455 12.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1599da68-c0aa-4452-879a-d9d34bbaf8c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1599da68-c0aa-4452-879a-d9d34bbaf8c3_0">
											<gml:posList>35.668558513132375 139.7390873709467 12.54 35.66854030822132 139.73911402426455 12.54 35.66854030822132 139.73911402426455 32.822 35.668558513132375 139.7390873709467 32.822 35.668558513132375 139.7390873709467 12.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33fea39d-3eec-45de-86a7-59e45ecfb9a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33fea39d-3eec-45de-86a7-59e45ecfb9a0_0">
											<gml:posList>35.668558513132375 139.7390873709467 32.822 35.66854030822132 139.73911402426455 32.822 35.668556455761156 139.7391305853484 32.822 35.668574948795204 139.73910352298793 32.822 35.668558513132375 139.7390873709467 32.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbd5f023-e170-4e89-a0be-e8394eb40d70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbd5f023-e170-4e89-a0be-e8394eb40d70_0">
											<gml:posList>35.668556455761156 139.7391305853484 32.822 35.668556455761156 139.7391305853484 12.54 35.66855732009364 139.73912932508802 12.54 35.66855732009364 139.73912932508802 26.914 35.66855938187751 139.73912630710538 26.914 35.668574939790126 139.73910353404452 26.914 35.668574948795204 139.73910352298793 32.822 35.668556455761156 139.7391305853484 32.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b70dfe69-8e90-4c00-b5f0-2e2a68f913bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b70dfe69-8e90-4c00-b5f0-2e2a68f913bb_0">
											<gml:posList>35.668574939790126 139.73910353404452 26.914 35.66855732009364 139.73912932508802 26.914 35.66855732009364 139.73912932508802 12.54 35.66857493078504 139.73910354510113 12.54 35.668574939790126 139.73910353404452 26.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45642c03-cc2d-4ee5-a499-9153c5a1f5a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45642c03-cc2d-4ee5-a499-9153c5a1f5a0_0">
											<gml:posList>35.66857493078504 139.73910354510113 12.54 35.668558513132375 139.7390873709467 12.54 35.668558513132375 139.7390873709467 32.822 35.668574948795204 139.73910352298793 32.822 35.668574939790126 139.73910353404452 26.914 35.66857493078504 139.73910354510113 12.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_02b0148a-0e3c-4a99-a75e-b8b1371aa671_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e91ad9da-cfe5-41b3-8c94-dee1b29b25f1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668612337581024 139.73911481226128 26.914 35.66858550740812 139.73915412340685 26.914 35.66858003168812 139.73914851846465 26.914 35.66860687086431 139.73910919626329 26.914 35.668612337581024 139.73911481226128 26.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c00f875c-8f53-4093-afe5-786160efd3c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c00f875c-8f53-4093-afe5-786160efd3c9_0">
											<gml:posList>35.66858550740812 139.73915412340685 26.914 35.66858550740812 139.73915412340685 28.679 35.66858003168812 139.73914851846465 28.679 35.66858003168812 139.73914851846465 26.914 35.66858550740812 139.73915412340685 26.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a92b6324-a869-493f-b58d-8ddd73bcf257">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a92b6324-a869-493f-b58d-8ddd73bcf257_0">
											<gml:posList>35.66860687086431 139.73910919626329 28.679 35.66860687086431 139.73910919626329 26.914 35.66858003168812 139.73914851846465 26.914 35.66858003168812 139.73914851846465 28.679 35.66860687086431 139.73910919626329 28.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3530a76-a724-4d5d-8994-941e1a2ad51a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3530a76-a724-4d5d-8994-941e1a2ad51a_0">
											<gml:posList>35.66858003168812 139.73914851846465 28.679 35.66858550740812 139.73915412340685 28.679 35.668612337581024 139.73911481226128 28.679 35.66860687086431 139.73910919626329 28.679 35.66858003168812 139.73914851846465 28.679</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df7a56ba-ef18-4724-bf5f-6a35c0f8857b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df7a56ba-ef18-4724-bf5f-6a35c0f8857b_0">
											<gml:posList>35.668612337581024 139.73911481226128 26.914 35.668612337581024 139.73911481226128 28.679 35.66858550740812 139.73915412340685 28.679 35.66858550740812 139.73915412340685 26.914 35.668612337581024 139.73911481226128 26.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a3a5ced-1bc8-4b0a-ad48-e994685052e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a3a5ced-1bc8-4b0a-ad48-e994685052e9_0">
											<gml:posList>35.66860687086431 139.73910919626329 26.914 35.66860687086431 139.73910919626329 28.679 35.668612337581024 139.73911481226128 28.679 35.668612337581024 139.73911481226128 26.914 35.66860687086431 139.73910919626329 26.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_02b0148a-0e3c-4a99-a75e-b8b1371aa671_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98df8402-fd45-447f-a5f8-cf2b79f2f3d4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668576419328964 139.7391051781614 26.914 35.66858819578717 139.7390879214967 26.914 35.668607726191475 139.73910794705847 26.914 35.66858061691498 139.73914766723433 26.914 35.66855938187751 139.73912630710538 26.914 35.668574948795204 139.73910352298793 26.914 35.668576419328964 139.7391051781614 26.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c3b9779-c31c-48ed-91bf-634fccc2c773">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c3b9779-c31c-48ed-91bf-634fccc2c773_0">
											<gml:posList>35.668576419328964 139.7391051781614 31.345 35.66858819578717 139.7390879214967 31.345 35.66858819578717 139.7390879214967 26.914 35.668576419328964 139.7391051781614 26.914 35.668576419328964 139.7391051781614 31.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0c73d84-d700-4b78-87fb-ab28bd0f9292">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0c73d84-d700-4b78-87fb-ab28bd0f9292_0">
											<gml:posList>35.66858819578717 139.7390879214967 26.914 35.66858819578717 139.7390879214967 31.345 35.668607726191475 139.73910794705847 31.345 35.668607726191475 139.73910794705847 26.914 35.66858819578717 139.7390879214967 26.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7575296-9405-4af7-bbfe-08fc0d67ee0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7575296-9405-4af7-bbfe-08fc0d67ee0f_0">
											<gml:posList>35.668574948795204 139.73910352298793 26.914 35.668574948795204 139.73910352298793 31.345 35.668576419328964 139.7391051781614 31.345 35.668576419328964 139.7391051781614 26.914 35.668574948795204 139.73910352298793 26.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-615bd730-bce9-48a8-81fc-0eccad24d4b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-615bd730-bce9-48a8-81fc-0eccad24d4b5_0">
											<gml:posList>35.66855938187751 139.73912630710538 31.345 35.668574948795204 139.73910352298793 31.345 35.668574948795204 139.73910352298793 26.914 35.66855938187751 139.73912630710538 26.914 35.66855938187751 139.73912630710538 31.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa25ac4d-cf46-4095-a21a-4ac3d34313e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa25ac4d-cf46-4095-a21a-4ac3d34313e8_0">
											<gml:posList>35.66855938187751 139.73912630710538 31.345 35.66858061691498 139.73914766723433 31.345 35.668607726191475 139.73910794705847 31.345 35.66858819578717 139.7390879214967 31.345 35.668576419328964 139.7391051781614 31.345 35.668574948795204 139.73910352298793 31.345 35.66855938187751 139.73912630710538 31.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-546fb596-30a2-49bb-be75-8b6568358d55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-546fb596-30a2-49bb-be75-8b6568358d55_0">
											<gml:posList>35.668607726191475 139.73910794705847 31.345 35.66858061691498 139.73914766723433 31.345 35.66858061691498 139.73914766723433 26.914 35.668607726191475 139.73910794705847 26.914 35.668607726191475 139.73910794705847 31.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00417822-59dd-4855-981d-ea6288461ec0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00417822-59dd-4855-981d-ea6288461ec0_0">
											<gml:posList>35.66858061691498 139.73914766723433 26.914 35.66858061691498 139.73914766723433 31.345 35.66855938187751 139.73912630710538 31.345 35.66855938187751 139.73912630710538 26.914 35.66858061691498 139.73914766723433 26.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-576e5b9f-7976-4caf-8533-315b9d4118a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-576e5b9f-7976-4caf-8533-315b9d4118a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-576e5b9f-7976-4caf-8533-315b9d4118a7">
											<gml:posList>35.668558513132375 139.7390873709467 12.439 35.66854030822132 139.73911402426455 12.439 35.66848358431205 139.73905582327856 12.439 35.668513745690106 139.73901160380683 12.439 35.66861739666614 139.73911785501716 12.439 35.668587145112355 139.73916207461212 12.439 35.668556455761156 139.7391305853484 12.439 35.668574948795204 139.73910352298793 12.439 35.668558513132375 139.7390873709467 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66a344de-f986-4321-8225-5cab3fa28305">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66a344de-f986-4321-8225-5cab3fa28305">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66a344de-f986-4321-8225-5cab3fa28305">
											<gml:posList>35.66848358431205 139.73905582327856 32.822 35.668485639268425 139.73905559994242 32.822 35.66851392793733 139.73901412208093 32.822 35.668513745690106 139.73901160380683 32.822 35.66848358431205 139.73905582327856 32.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b5c0900-da74-4701-abed-4e6b06048cb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b5c0900-da74-4701-abed-4e6b06048cb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b5c0900-da74-4701-abed-4e6b06048cb6">
											<gml:posList>35.66854030822132 139.73911402426455 32.822 35.66854011695383 139.73911149495396 32.822 35.668485639268425 139.73905559994242 32.822 35.66848358431205 139.73905582327856 32.822 35.66854030822132 139.73911402426455 32.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bca81332-b27b-480d-bc50-96f48f4926c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bca81332-b27b-480d-bc50-96f48f4926c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bca81332-b27b-480d-bc50-96f48f4926c3">
											<gml:posList>35.66851392793733 139.73901412208093 32.349 35.668485639268425 139.73905559994242 32.349 35.66854011695383 139.73911149495396 32.349 35.668557385508976 139.7390862124412 32.349 35.6685356088847 139.739063891969 32.349 35.668546674074456 139.73904768551404 32.349 35.66851392793733 139.73901412208093 32.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fffc6d5-9ad8-40a8-9147-b1f552213289">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fffc6d5-9ad8-40a8-9147-b1f552213289">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fffc6d5-9ad8-40a8-9147-b1f552213289">
											<gml:posList>35.66851392793733 139.73901412208093 32.822 35.668546674074456 139.73904768551404 32.822 35.66854761042937 139.73904631470816 32.822 35.668513745690106 139.73901160380683 32.822 35.66851392793733 139.73901412208093 32.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ebf2bd35-62ed-456c-a857-b448df07b901">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebf2bd35-62ed-456c-a857-b448df07b901">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebf2bd35-62ed-456c-a857-b448df07b901">
											<gml:posList>35.6685356088847 139.739063891969 38.975 35.668537059973374 139.7390637356189 38.975 35.668547738014034 139.73904809296522 38.975 35.66854761042937 139.73904631470816 38.975 35.6685356088847 139.739063891969 38.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-289406c4-66b3-42e9-9d13-e8a02804da40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-289406c4-66b3-42e9-9d13-e8a02804da40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-289406c4-66b3-42e9-9d13-e8a02804da40">
											<gml:posList>35.668558513132375 139.7390873709467 38.975 35.668558376543224 139.7390856037459 38.975 35.668537059973374 139.7390637356189 38.975 35.6685356088847 139.739063891969 38.975 35.668558513132375 139.7390873709467 38.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8521bc6-2b41-47cc-b3b9-abe84f57d337">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8521bc6-2b41-47cc-b3b9-abe84f57d337">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8521bc6-2b41-47cc-b3b9-abe84f57d337">
											<gml:posList>35.66854011695383 139.73911149495396 32.822 35.66854030822132 139.73911402426455 32.822 35.668558513132375 139.7390873709467 32.822 35.668557385508976 139.7390862124412 32.822 35.66854011695383 139.73911149495396 32.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df1092b0-7c72-411e-8297-688819b47061">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df1092b0-7c72-411e-8297-688819b47061">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df1092b0-7c72-411e-8297-688819b47061">
											<gml:posList>35.66856907259683 139.73906993897776 36.859 35.668547738014034 139.73904809296522 36.859 35.668537059973374 139.7390637356189 36.859 35.668558376543224 139.7390856037459 36.859 35.66856907259683 139.73906993897776 36.859</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5870278-d4ac-4575-9cd1-568f55abd141">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5870278-d4ac-4575-9cd1-568f55abd141">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5870278-d4ac-4575-9cd1-568f55abd141">
											<gml:posList>35.66854761042937 139.73904631470816 38.975 35.668547738014034 139.73904809296522 38.975 35.66856907259683 139.73906993897776 38.975 35.668570514680425 139.73906979368434 38.975 35.66854761042937 139.73904631470816 38.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1610a07-aebb-4ae1-aff5-71a0ef722348">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1610a07-aebb-4ae1-aff5-71a0ef722348">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1610a07-aebb-4ae1-aff5-71a0ef722348">
											<gml:posList>35.668570514680425 139.73906979368434 38.975 35.66856907259683 139.73906993897776 38.975 35.668558376543224 139.7390856037459 38.975 35.668558513132375 139.7390873709467 38.975 35.668570514680425 139.73906979368434 38.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-368ff2f7-2bf7-42bb-9f5b-c21cb8c497e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-368ff2f7-2bf7-42bb-9f5b-c21cb8c497e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-368ff2f7-2bf7-42bb-9f5b-c21cb8c497e8">
											<gml:posList>35.66858819578717 139.7390879214967 31.972 35.668570514680425 139.73906979368434 31.972 35.668558513132375 139.7390873709467 31.972 35.668574948795204 139.73910352298793 31.972 35.668576419328964 139.7391051781614 31.972 35.66858819578717 139.7390879214967 31.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09d773fd-40e1-4267-8283-d610ee0f3c02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09d773fd-40e1-4267-8283-d610ee0f3c02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09d773fd-40e1-4267-8283-d610ee0f3c02">
											<gml:posList>35.668587145112355 139.73916207461212 26.914 35.66861739666614 139.73911785501716 26.914 35.66858819578717 139.7390879214967 26.914 35.668576419328964 139.7391051781614 26.914 35.668574948795204 139.73910352298793 26.914 35.668556455761156 139.7391305853484 26.914 35.668587145112355 139.73916207461212 26.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3988f7cb-bb54-4dcc-a775-0190ec5c61d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3988f7cb-bb54-4dcc-a775-0190ec5c61d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3988f7cb-bb54-4dcc-a775-0190ec5c61d8">
											<gml:posList>35.668547738014034 139.73904809296522 38.975 35.668547738014034 139.73904809296522 36.859 35.66856907259683 139.73906993897776 36.859 35.66856907259683 139.73906993897776 38.975 35.668547738014034 139.73904809296522 38.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-acf4027c-89e5-4f9e-82d5-5e15f60dbab2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acf4027c-89e5-4f9e-82d5-5e15f60dbab2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acf4027c-89e5-4f9e-82d5-5e15f60dbab2">
											<gml:posList>35.668558376543224 139.7390856037459 38.975 35.668558376543224 139.7390856037459 36.859 35.668537059973374 139.7390637356189 36.859 35.668537059973374 139.7390637356189 38.975 35.668558376543224 139.7390856037459 38.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db917584-a474-4433-a7c7-0e76fc1fc8d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db917584-a474-4433-a7c7-0e76fc1fc8d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db917584-a474-4433-a7c7-0e76fc1fc8d8">
											<gml:posList>35.668513745690106 139.73901160380683 12.439 35.66848358431205 139.73905582327856 12.439 35.66848358431205 139.73905582327856 32.822 35.668513745690106 139.73901160380683 32.822 35.668513745690106 139.73901160380683 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfa59970-0e63-4627-8922-df5084481ee4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfa59970-0e63-4627-8922-df5084481ee4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfa59970-0e63-4627-8922-df5084481ee4">
											<gml:posList>35.668485639268425 139.73905559994242 32.822 35.668485639268425 139.73905559994242 32.349 35.66851392793733 139.73901412208093 32.349 35.66851392793733 139.73901412208093 32.822 35.668485639268425 139.73905559994242 32.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0099085c-6e6c-44cd-9448-c3800dda2135">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0099085c-6e6c-44cd-9448-c3800dda2135">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0099085c-6e6c-44cd-9448-c3800dda2135">
											<gml:posList>35.66851392793733 139.73901412208093 32.822 35.66851392793733 139.73901412208093 32.349 35.668546674074456 139.73904768551404 32.349 35.668546674074456 139.73904768551404 32.822 35.66851392793733 139.73901412208093 32.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26921e53-dbac-48a8-a170-6656eb38fad9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26921e53-dbac-48a8-a170-6656eb38fad9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26921e53-dbac-48a8-a170-6656eb38fad9">
											<gml:posList>35.6685356088847 139.739063891969 32.349 35.6685356088847 139.739063891969 38.975 35.66854761042937 139.73904631470816 38.975 35.66854761042937 139.73904631470816 32.822 35.668546674074456 139.73904768551404 32.822 35.668546674074456 139.73904768551404 32.349 35.6685356088847 139.739063891969 32.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d7cf789-325b-48ee-9076-c7482727edc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d7cf789-325b-48ee-9076-c7482727edc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d7cf789-325b-48ee-9076-c7482727edc5">
											<gml:posList>35.668537059973374 139.7390637356189 38.975 35.668537059973374 139.7390637356189 36.859 35.668547738014034 139.73904809296522 36.859 35.668547738014034 139.73904809296522 38.975 35.668537059973374 139.7390637356189 38.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2c20c7d-6827-40c3-a615-f69bf0c930a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2c20c7d-6827-40c3-a615-f69bf0c930a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2c20c7d-6827-40c3-a615-f69bf0c930a9">
											<gml:posList>35.66861739666614 139.73911785501716 26.914 35.66861739666614 139.73911785501716 12.439 35.668513745690106 139.73901160380683 12.439 35.668513745690106 139.73901160380683 32.822 35.66854761042937 139.73904631470816 32.822 35.66854761042937 139.73904631470816 38.975 35.668570514680425 139.73906979368434 38.975 35.668570514680425 139.73906979368434 31.972 35.66858819578717 139.7390879214967 31.972 35.66858819578717 139.7390879214967 26.914 35.66861739666614 139.73911785501716 26.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5405712e-17dd-4c4e-8c2d-14e651aea040">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5405712e-17dd-4c4e-8c2d-14e651aea040">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5405712e-17dd-4c4e-8c2d-14e651aea040">
											<gml:posList>35.668558513132375 139.7390873709467 38.975 35.6685356088847 139.739063891969 38.975 35.6685356088847 139.739063891969 32.349 35.668557385508976 139.7390862124412 32.349 35.668557385508976 139.7390862124412 32.822 35.668558513132375 139.7390873709467 32.822 35.668558513132375 139.7390873709467 38.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0d37a09-50fa-4e51-ad35-ab1b656a120a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0d37a09-50fa-4e51-ad35-ab1b656a120a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0d37a09-50fa-4e51-ad35-ab1b656a120a">
											<gml:posList>35.66856907259683 139.73906993897776 38.975 35.66856907259683 139.73906993897776 36.859 35.668558376543224 139.7390856037459 36.859 35.668558376543224 139.7390856037459 38.975 35.66856907259683 139.73906993897776 38.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bf7deda-d360-4f4a-8ef6-47194cb73739">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bf7deda-d360-4f4a-8ef6-47194cb73739">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bf7deda-d360-4f4a-8ef6-47194cb73739">
											<gml:posList>35.66848358431205 139.73905582327856 12.439 35.66854030822132 139.73911402426455 12.439 35.66854030822132 139.73911402426455 32.822 35.66848358431205 139.73905582327856 32.822 35.66848358431205 139.73905582327856 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32efd060-a238-4c8c-ad85-4e30b7c6e1ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32efd060-a238-4c8c-ad85-4e30b7c6e1ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32efd060-a238-4c8c-ad85-4e30b7c6e1ea">
											<gml:posList>35.66854030822132 139.73911402426455 12.439 35.668558513132375 139.7390873709467 12.439 35.668558513132375 139.7390873709467 31.972 35.668570514680425 139.73906979368434 31.972 35.668570514680425 139.73906979368434 38.975 35.668558513132375 139.7390873709467 38.975 35.668558513132375 139.7390873709467 32.822 35.66854030822132 139.73911402426455 32.822 35.66854030822132 139.73911402426455 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a6313c9-a637-48ff-ab2e-09ee78436c0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a6313c9-a637-48ff-ab2e-09ee78436c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a6313c9-a637-48ff-ab2e-09ee78436c0a">
											<gml:posList>35.668558513132375 139.7390873709467 31.972 35.668558513132375 139.7390873709467 12.439 35.668574948795204 139.73910352298793 12.439 35.668574948795204 139.73910352298793 26.914 35.668574948795204 139.73910352298793 31.972 35.668558513132375 139.7390873709467 31.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed9d1ffe-bfed-4cee-abac-ae44ac30ca5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed9d1ffe-bfed-4cee-abac-ae44ac30ca5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed9d1ffe-bfed-4cee-abac-ae44ac30ca5f">
											<gml:posList>35.66858819578717 139.7390879214967 31.972 35.668576419328964 139.7391051781614 31.972 35.668576419328964 139.7391051781614 26.914 35.66858819578717 139.7390879214967 26.914 35.66858819578717 139.7390879214967 31.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29bb7148-0d23-44f2-aad1-ced55ef9e7eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29bb7148-0d23-44f2-aad1-ced55ef9e7eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29bb7148-0d23-44f2-aad1-ced55ef9e7eb">
											<gml:posList>35.668557385508976 139.7390862124412 32.822 35.668557385508976 139.7390862124412 32.349 35.66854011695383 139.73911149495396 32.349 35.66854011695383 139.73911149495396 32.822 35.668557385508976 139.7390862124412 32.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c19e3a4-1ac1-452b-9d1b-a608818f4b2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c19e3a4-1ac1-452b-9d1b-a608818f4b2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c19e3a4-1ac1-452b-9d1b-a608818f4b2a">
											<gml:posList>35.668576419328964 139.7391051781614 31.972 35.668574948795204 139.73910352298793 31.972 35.668574948795204 139.73910352298793 26.914 35.668576419328964 139.7391051781614 26.914 35.668576419328964 139.7391051781614 31.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26843b48-2299-4c16-9c4b-4a44834967f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26843b48-2299-4c16-9c4b-4a44834967f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26843b48-2299-4c16-9c4b-4a44834967f7">
											<gml:posList>35.668574948795204 139.73910352298793 12.439 35.668556455761156 139.7391305853484 12.439 35.668556455761156 139.7391305853484 26.914 35.668574948795204 139.73910352298793 26.914 35.668574948795204 139.73910352298793 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08095d65-8260-47ba-9d37-fb75ec4f3b8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08095d65-8260-47ba-9d37-fb75ec4f3b8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08095d65-8260-47ba-9d37-fb75ec4f3b8e">
											<gml:posList>35.668587145112355 139.73916207461212 12.439 35.66861739666614 139.73911785501716 12.439 35.66861739666614 139.73911785501716 26.914 35.668587145112355 139.73916207461212 26.914 35.668587145112355 139.73916207461212 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f5db911-5af8-47bc-8a48-d1f058b76b38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f5db911-5af8-47bc-8a48-d1f058b76b38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f5db911-5af8-47bc-8a48-d1f058b76b38">
											<gml:posList>35.668556455761156 139.7391305853484 12.439 35.668587145112355 139.73916207461212 12.439 35.668587145112355 139.73916207461212 26.914 35.668556455761156 139.7391305853484 26.914 35.668556455761156 139.7391305853484 12.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c39523f3-53e2-4482-ba6e-a87d8c873b5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c39523f3-53e2-4482-ba6e-a87d8c873b5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c39523f3-53e2-4482-ba6e-a87d8c873b5b">
											<gml:posList>35.66854011695383 139.73911149495396 32.822 35.66854011695383 139.73911149495396 32.349 35.668485639268425 139.73905559994242 32.349 35.668485639268425 139.73905559994242 32.822 35.66854011695383 139.73911149495396 32.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7089</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">78.24865</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>