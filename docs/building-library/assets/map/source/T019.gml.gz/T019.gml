<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_038f326b-3e62-411c-b889-c6a89443511c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">9.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66899108489099 139.73943697867173 0 35.6689466109917 139.73950617909978 0 35.66898963898536 139.7395478828854 0 35.669034112908285 139.73947868244323 0 35.66899108489099 139.73943697867173 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66899108489099 139.73943697867173 11.71 35.669034112908285 139.73947868244323 11.71 35.66898963898536 139.7395478828854 11.71 35.6689466109917 139.73950617909978 11.71 35.66899108489099 139.73943697867173 11.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66899108489099 139.73943697867173 11.71 35.6689466109917 139.73950617909978 11.71 35.6689466109917 139.73950617909978 21.16 35.66899108489099 139.73943697867173 21.16 35.66899108489099 139.73943697867173 11.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689466109917 139.73950617909978 11.71 35.66898963898536 139.7395478828854 11.71 35.66898963898536 139.7395478828854 21.16 35.6689466109917 139.73950617909978 21.16 35.6689466109917 139.73950617909978 11.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898963898536 139.7395478828854 11.71 35.669034112908285 139.73947868244323 11.71 35.669034112908285 139.73947868244323 21.16 35.66898963898536 139.7395478828854 21.16 35.66898963898536 139.7395478828854 11.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669034112908285 139.73947868244323 11.71 35.66899108489099 139.73943697867173 11.71 35.66899108489099 139.73943697867173 21.16 35.669034112908285 139.73947868244323 21.16 35.669034112908285 139.73947868244323 11.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66899108489099 139.73943697867173 21.16 35.6689466109917 139.73950617909978 21.16 35.66898963898536 139.7395478828854 21.16 35.669034112908285 139.73947868244323 21.16 35.66899108489099 139.73943697867173 21.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fdfba47d-c86b-4e0a-9522-fb1758c6ca3e"/>
							<gml:surfaceMember xlink:href="#poly-9fbe16d9-3d80-464d-8fee-611ae9700e28"/>
							<gml:surfaceMember xlink:href="#poly-a9ce6e33-e053-423d-a27d-2cb4dd1019da"/>
							<gml:surfaceMember xlink:href="#poly-e8c94caf-566f-4924-9357-61dd0ee335bb"/>
							<gml:surfaceMember xlink:href="#poly-e119a276-6d63-4b6b-b3d3-d78151f8f4c8"/>
							<gml:surfaceMember xlink:href="#poly-48585999-2416-45a3-a5b4-0cd0c71341a1"/>
							<gml:surfaceMember xlink:href="#poly-b6132424-cc96-4eb6-a29e-c44065267322"/>
							<gml:surfaceMember xlink:href="#poly-ec08e400-8111-46fa-bb0e-51fbb7835ff0"/>
							<gml:surfaceMember xlink:href="#poly-660dc254-42e3-4a15-bd81-2a3ab4d6893e"/>
							<gml:surfaceMember xlink:href="#poly-249bac0c-30fc-47b2-b85a-8c6c5a5ddd39"/>
							<gml:surfaceMember xlink:href="#poly-9f779af0-245d-4626-9a47-b6d98fe6d70b"/>
							<gml:surfaceMember xlink:href="#poly-e0ea3737-fec9-4f71-bf5d-1b50f6e37612"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fdfba47d-c86b-4e0a-9522-fb1758c6ca3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdfba47d-c86b-4e0a-9522-fb1758c6ca3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdfba47d-c86b-4e0a-9522-fb1758c6ca3e">
											<gml:posList>35.66899108489099 139.73943697867173 11.71 35.66903411290827 139.73947868244323 11.71 35.66898963898536 139.7395478828854 11.71 35.668946610991696 139.73950617909978 11.71 35.66899108489099 139.73943697867173 11.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9fbe16d9-3d80-464d-8fee-611ae9700e28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fbe16d9-3d80-464d-8fee-611ae9700e28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fbe16d9-3d80-464d-8fee-611ae9700e28">
											<gml:posList>35.668955379737575 139.73949253799694 19.071 35.668946610991696 139.73950617909978 19.071 35.66898963898536 139.7395478828854 19.071 35.668998470754524 139.73953414229143 19.071 35.668955379737575 139.73949253799694 19.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9ce6e33-e053-423d-a27d-2cb4dd1019da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9ce6e33-e053-423d-a27d-2cb4dd1019da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9ce6e33-e053-423d-a27d-2cb4dd1019da">
											<gml:posList>35.66903411290827 139.73947868244323 23.751 35.66899108489099 139.73943697867173 23.751 35.66897796780158 139.73945739611665 23.751 35.66899553075798 139.7394743533615 23.751 35.66898160295212 139.7394954455603 23.751 35.66900723950349 139.73952050118282 23.751 35.66903411290827 139.73947868244323 23.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8c94caf-566f-4924-9357-61dd0ee335bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8c94caf-566f-4924-9357-61dd0ee335bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8c94caf-566f-4924-9357-61dd0ee335bb">
											<gml:posList>35.668955379737575 139.73949253799694 22.076 35.668998470754524 139.73953414229143 22.076 35.66900723950349 139.73952050118282 22.076 35.66898160295212 139.7394954455603 22.076 35.66899553075798 139.7394743533615 22.076 35.66897796780158 139.73945739611665 22.076 35.668955379737575 139.73949253799694 22.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e119a276-6d63-4b6b-b3d3-d78151f8f4c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e119a276-6d63-4b6b-b3d3-d78151f8f4c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e119a276-6d63-4b6b-b3d3-d78151f8f4c8">
											<gml:posList>35.66903411290827 139.73947868244323 11.71 35.66899108489099 139.73943697867173 11.71 35.66899108489099 139.73943697867173 23.751 35.66903411290827 139.73947868244323 23.751 35.66903411290827 139.73947868244323 11.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48585999-2416-45a3-a5b4-0cd0c71341a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48585999-2416-45a3-a5b4-0cd0c71341a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48585999-2416-45a3-a5b4-0cd0c71341a1">
											<gml:posList>35.66899553075798 139.7394743533615 23.751 35.66897796780158 139.73945739611665 23.751 35.66897796780158 139.73945739611665 22.076 35.66899553075798 139.7394743533615 22.076 35.66899553075798 139.7394743533615 23.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6132424-cc96-4eb6-a29e-c44065267322">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6132424-cc96-4eb6-a29e-c44065267322">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6132424-cc96-4eb6-a29e-c44065267322">
											<gml:posList>35.668946610991696 139.73950617909978 11.71 35.668946610991696 139.73950617909978 19.071 35.668955379737575 139.73949253799694 19.071 35.668955379737575 139.73949253799694 22.076 35.66897796780158 139.73945739611665 22.076 35.66897796780158 139.73945739611665 23.751 35.66899108489099 139.73943697867173 23.751 35.66899108489099 139.73943697867173 11.71 35.668946610991696 139.73950617909978 11.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec08e400-8111-46fa-bb0e-51fbb7835ff0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec08e400-8111-46fa-bb0e-51fbb7835ff0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec08e400-8111-46fa-bb0e-51fbb7835ff0">
											<gml:posList>35.66898160295212 139.7394954455603 23.751 35.66899553075798 139.7394743533615 23.751 35.66899553075798 139.7394743533615 22.076 35.66898160295212 139.7394954455603 22.076 35.66898160295212 139.7394954455603 23.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-660dc254-42e3-4a15-bd81-2a3ab4d6893e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-660dc254-42e3-4a15-bd81-2a3ab4d6893e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-660dc254-42e3-4a15-bd81-2a3ab4d6893e">
											<gml:posList>35.66900723950349 139.73952050118282 23.751 35.66898160295212 139.7394954455603 23.751 35.66898160295212 139.7394954455603 22.076 35.66900723950349 139.73952050118282 22.076 35.66900723950349 139.73952050118282 23.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-249bac0c-30fc-47b2-b85a-8c6c5a5ddd39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-249bac0c-30fc-47b2-b85a-8c6c5a5ddd39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-249bac0c-30fc-47b2-b85a-8c6c5a5ddd39">
											<gml:posList>35.668998470754524 139.73953414229143 19.071 35.66898963898536 139.7395478828854 19.071 35.66898963898536 139.7395478828854 11.71 35.66903411290827 139.73947868244323 11.71 35.66903411290827 139.73947868244323 23.751 35.66900723950349 139.73952050118282 23.751 35.66900723950349 139.73952050118282 22.076 35.668998470754524 139.73953414229143 22.076 35.668998470754524 139.73953414229143 19.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f779af0-245d-4626-9a47-b6d98fe6d70b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f779af0-245d-4626-9a47-b6d98fe6d70b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f779af0-245d-4626-9a47-b6d98fe6d70b">
											<gml:posList>35.668998470754524 139.73953414229143 19.071 35.668998470754524 139.73953414229143 22.076 35.668955379737575 139.73949253799694 22.076 35.668955379737575 139.73949253799694 19.071 35.668998470754524 139.73953414229143 19.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0ea3737-fec9-4f71-bf5d-1b50f6e37612">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0ea3737-fec9-4f71-bf5d-1b50f6e37612">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0ea3737-fec9-4f71-bf5d-1b50f6e37612">
											<gml:posList>35.668946610991696 139.73950617909978 11.71 35.66898963898536 139.7395478828854 11.71 35.66898963898536 139.7395478828854 19.071 35.668946610991696 139.73950617909978 19.071 35.668946610991696 139.73950617909978 11.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-335</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">48.5334</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>