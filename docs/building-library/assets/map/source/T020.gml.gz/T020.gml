<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0422c94e-f85f-4c21-83ae-97caf00e32fc">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">28.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66914026791227 139.74842887269028 0 35.66920711663538 139.74825416308482 0 35.66913921571893 139.74821524243868 0 35.66912221763362 139.74826883400473 0 35.66911302019906 139.7482639834846 0 35.66906632302319 139.74838310976224 0 35.66908481074706 139.7483966768555 0 35.66909389941547 139.74837512736596 0 35.66910408968033 139.7483818546801 0 35.66909436755674 139.748399870096 0 35.66914026791227 139.74842887269028 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914026791227 139.74842887269028 5.875 35.66909436755674 139.748399870096 5.875 35.66910408968033 139.7483818546801 5.875 35.66909389941547 139.74837512736596 5.875 35.66908481074706 139.7483966768555 5.875 35.66906632302319 139.74838310976224 5.875 35.66911302019906 139.7482639834846 5.875 35.66912221763362 139.74826883400473 5.875 35.66913921571893 139.74821524243868 5.875 35.66920711663538 139.74825416308482 5.875 35.66914026791227 139.74842887269028 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914026791227 139.74842887269028 5.875 35.66920711663538 139.74825416308482 5.875 35.66920711663538 139.74825416308482 34.22 35.66914026791227 139.74842887269028 34.22 35.66914026791227 139.74842887269028 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920711663538 139.74825416308482 5.875 35.66913921571893 139.74821524243868 5.875 35.66913921571893 139.74821524243868 34.22 35.66920711663538 139.74825416308482 34.22 35.66920711663538 139.74825416308482 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913921571893 139.74821524243868 5.875 35.66912221763362 139.74826883400473 5.875 35.66912221763362 139.74826883400473 34.22 35.66913921571893 139.74821524243868 34.22 35.66913921571893 139.74821524243868 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66912221763362 139.74826883400473 5.875 35.66911302019906 139.7482639834846 5.875 35.66911302019906 139.7482639834846 34.22 35.66912221763362 139.74826883400473 34.22 35.66912221763362 139.74826883400473 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911302019906 139.7482639834846 5.875 35.66906632302319 139.74838310976224 5.875 35.66906632302319 139.74838310976224 34.22 35.66911302019906 139.7482639834846 34.22 35.66911302019906 139.7482639834846 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66906632302319 139.74838310976224 5.875 35.66908481074706 139.7483966768555 5.875 35.66908481074706 139.7483966768555 34.22 35.66906632302319 139.74838310976224 34.22 35.66906632302319 139.74838310976224 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908481074706 139.7483966768555 5.875 35.66909389941547 139.74837512736596 5.875 35.66909389941547 139.74837512736596 34.22 35.66908481074706 139.7483966768555 34.22 35.66908481074706 139.7483966768555 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909389941547 139.74837512736596 5.875 35.66910408968033 139.7483818546801 5.875 35.66910408968033 139.7483818546801 34.22 35.66909389941547 139.74837512736596 34.22 35.66909389941547 139.74837512736596 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910408968033 139.7483818546801 5.875 35.66909436755674 139.748399870096 5.875 35.66909436755674 139.748399870096 34.22 35.66910408968033 139.7483818546801 34.22 35.66910408968033 139.7483818546801 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909436755674 139.748399870096 5.875 35.66914026791227 139.74842887269028 5.875 35.66914026791227 139.74842887269028 34.22 35.66909436755674 139.748399870096 34.22 35.66909436755674 139.748399870096 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914026791227 139.74842887269028 34.22 35.66920711663538 139.74825416308482 34.22 35.66913921571893 139.74821524243868 34.22 35.66912221763362 139.74826883400473 34.22 35.66911302019906 139.7482639834846 34.22 35.66906632302319 139.74838310976224 34.22 35.66908481074706 139.7483966768555 34.22 35.66909389941547 139.74837512736596 34.22 35.66910408968033 139.7483818546801 34.22 35.66909436755674 139.748399870096 34.22 35.66914026791227 139.74842887269028 34.22</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3ddfcefa-c76c-444b-beb9-bce472f78245"/>
							<gml:surfaceMember xlink:href="#poly-f2f359c4-f503-48fe-8012-ee0680432e7b"/>
							<gml:surfaceMember xlink:href="#poly-38edb74e-bb6a-46c7-af0a-f1d2e72ef5e5"/>
							<gml:surfaceMember xlink:href="#poly-3bded759-8297-4cdc-8fce-c0e05ec9702a"/>
							<gml:surfaceMember xlink:href="#poly-dc109710-ba0f-4888-9f4b-e9602de6d780"/>
							<gml:surfaceMember xlink:href="#poly-fa13df0f-435c-4201-a209-fb86d8168028"/>
							<gml:surfaceMember xlink:href="#poly-38fd744d-39dd-4668-b22e-26a4b6075628"/>
							<gml:surfaceMember xlink:href="#poly-76932d66-efbd-435e-8104-61d419b5c385"/>
							<gml:surfaceMember xlink:href="#poly-46f8d296-1729-4138-bdfe-b07984d1816c"/>
							<gml:surfaceMember xlink:href="#poly-f3842e7c-e125-4144-93a2-386a908fac45"/>
							<gml:surfaceMember xlink:href="#poly-1403f646-1718-428c-b8a1-85ce39fbaa90"/>
							<gml:surfaceMember xlink:href="#poly-70fee9ed-156f-4680-a00e-fa528843afca"/>
							<gml:surfaceMember xlink:href="#poly-508d0d79-ab95-4dee-a35f-d28570f82b5c"/>
							<gml:surfaceMember xlink:href="#poly-e003e082-c99a-496c-8c6b-94a10cddf227"/>
							<gml:surfaceMember xlink:href="#poly-2f887011-70dc-428e-82e5-d25a75e1b49a"/>
							<gml:surfaceMember xlink:href="#poly-924c0e1f-c38c-48d6-8bbc-66c3039ed28b"/>
							<gml:surfaceMember xlink:href="#poly-7ff4f534-4b63-4c97-9c86-c6fad88ac74d"/>
							<gml:surfaceMember xlink:href="#poly-e8dbb5b6-cdc6-40d8-814d-d187fa862729"/>
							<gml:surfaceMember xlink:href="#poly-84aeae5f-4018-4bc7-9ac5-54ff402b60d4"/>
							<gml:surfaceMember xlink:href="#poly-a40f3f41-27c3-4d90-9a1d-f3e1aa4b4ae7"/>
							<gml:surfaceMember xlink:href="#poly-996603cb-805e-4861-8332-31ccfad0d81f"/>
							<gml:surfaceMember xlink:href="#poly-93c8cb38-5995-4bf2-960d-719405e8b9c8"/>
							<gml:surfaceMember xlink:href="#poly-862c55bb-63db-469e-842b-efbf0e794100"/>
							<gml:surfaceMember xlink:href="#poly-4ad21f59-4e1d-4957-b0a9-836ad6648325"/>
							<gml:surfaceMember xlink:href="#poly-60880972-294c-4323-b270-9a7665197597"/>
							<gml:surfaceMember xlink:href="#poly-9734b427-5090-43a9-bc50-d1f1a05b7b50"/>
							<gml:surfaceMember xlink:href="#poly-c115bc9f-63b1-4e26-950d-e811b07bf308"/>
							<gml:surfaceMember xlink:href="#poly-99c8d838-2199-43e2-bf08-44b17eddee6e"/>
							<gml:surfaceMember xlink:href="#poly-f7397f34-bce5-4a0c-b617-b959d68f89a1"/>
							<gml:surfaceMember xlink:href="#poly-f5f300f9-2ae1-455f-afee-2adf0889473f"/>
							<gml:surfaceMember xlink:href="#poly-9d20f5c6-dd71-4871-ba4d-a20c937cb1e2"/>
							<gml:surfaceMember xlink:href="#poly-50c0b4dd-4c80-43f0-a15c-96e951d4bc21"/>
							<gml:surfaceMember xlink:href="#poly-7eeb3975-7afa-45aa-bf07-234e46b6569a"/>
							<gml:surfaceMember xlink:href="#poly-cba3dd46-ba93-4e1b-ae83-9fed7dae4dad"/>
							<gml:surfaceMember xlink:href="#poly-7923eeba-15cb-4d2e-af32-a84200c696c9"/>
							<gml:surfaceMember xlink:href="#poly-256c4c4b-5ee3-46de-aa3b-314d07255094"/>
							<gml:surfaceMember xlink:href="#poly-56294ee4-3092-41ec-9135-9f59b85b95c3"/>
							<gml:surfaceMember xlink:href="#poly-bbc2e04e-9a7e-4235-9970-1e7f3bbf2115"/>
							<gml:surfaceMember xlink:href="#poly-8f797bdc-5c7a-421f-b114-02fbbd8e826c"/>
							<gml:surfaceMember xlink:href="#poly-9bb3bd6c-fa4d-4b16-9cfb-b057e56d2de1"/>
							<gml:surfaceMember xlink:href="#poly-cab13615-c44c-4ee2-8f09-8e5e0ad327b1"/>
							<gml:surfaceMember xlink:href="#poly-8ed7c86d-19f9-42b0-b36f-8d8d5c598bb2"/>
							<gml:surfaceMember xlink:href="#poly-a3a9efcf-8dd1-4029-b9d8-602d2d766937"/>
							<gml:surfaceMember xlink:href="#poly-cb4398cf-1be8-4509-849f-658df77e11e0"/>
							<gml:surfaceMember xlink:href="#poly-3be665fa-706d-4a7f-82c0-f521e99b2b84"/>
							<gml:surfaceMember xlink:href="#poly-c703c174-eac8-40c7-b8d3-85c2aee2a881"/>
							<gml:surfaceMember xlink:href="#poly-2d78c713-0bee-4a04-a7c9-db439f63cf9b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0422c94e-f85f-4c21-83ae-97caf00e32fc_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f3018dc-f8e4-4651-b528-3fd5150ffc58">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914086168617 139.74832506091272 34.423 35.66914618211638 139.74832835805296 34.423 35.66911864724025 139.74839517188275 34.423 35.66911331779812 139.74839187474876 34.423 35.66914086168617 139.74832506091272 34.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf8d2cf1-0509-4e57-8fa2-96009ccf4f88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf8d2cf1-0509-4e57-8fa2-96009ccf4f88_0">
											<gml:posList>35.66914086168617 139.74832506091272 34.423 35.66914086168617 139.74832506091272 35.605 35.66914618211638 139.74832835805296 35.605 35.66914618211638 139.74832835805296 34.423 35.66914086168617 139.74832506091272 34.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4e93481-fbff-49c1-8980-9c15011fff75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4e93481-fbff-49c1-8980-9c15011fff75_0">
											<gml:posList>35.66911331779812 139.74839187474876 34.423 35.66911331779812 139.74839187474876 35.605 35.66914086168617 139.74832506091272 35.605 35.66914086168617 139.74832506091272 34.423 35.66911331779812 139.74839187474876 34.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc73f0df-beea-42e6-a72e-13b7e85ab27d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc73f0df-beea-42e6-a72e-13b7e85ab27d_0">
											<gml:posList>35.66914086168617 139.74832506091272 35.605 35.66911331779812 139.74839187474876 35.605 35.66911864724025 139.74839517188275 35.605 35.66914618211638 139.74832835805296 35.605 35.66914086168617 139.74832506091272 35.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2a00f1f-0c45-46b6-8cd3-f06880b27b70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2a00f1f-0c45-46b6-8cd3-f06880b27b70_0">
											<gml:posList>35.66914618211638 139.74832835805296 34.423 35.66914618211638 139.74832835805296 35.605 35.66911864724025 139.74839517188275 35.605 35.66911864724025 139.74839517188275 34.423 35.66914618211638 139.74832835805296 34.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3eb38d11-3cb2-4408-a9ea-7adb913bda7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3eb38d11-3cb2-4408-a9ea-7adb913bda7a_0">
											<gml:posList>35.66911864724025 139.74839517188275 34.423 35.66911864724025 139.74839517188275 35.605 35.66911331779812 139.74839187474876 35.605 35.66911331779812 139.74839187474876 34.423 35.66911864724025 139.74839517188275 34.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0422c94e-f85f-4c21-83ae-97caf00e32fc_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2c12b19-9ab9-4e79-8fa6-9bf39412680c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914790073673 139.74827304845616 34.423 35.66918053420807 139.74829112943257 34.423 35.6691722394257 139.74831361703107 34.423 35.66913960595768 139.74829553604738 34.423 35.66914790073673 139.74827304845616 34.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0133487d-0bde-4760-b62f-4502eaf2e907">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0133487d-0bde-4760-b62f-4502eaf2e907_0">
											<gml:posList>35.66913960595768 139.74829553604738 37.149 35.66914790073673 139.74827304845616 37.149 35.66914790073673 139.74827304845616 34.423 35.66913960595768 139.74829553604738 34.423 35.66913960595768 139.74829553604738 37.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9dc1fef-b8b4-493a-9739-d5af6fa50294">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9dc1fef-b8b4-493a-9739-d5af6fa50294_0">
											<gml:posList>35.6691722394257 139.74831361703107 37.149 35.66913960595768 139.74829553604738 37.149 35.66913960595768 139.74829553604738 34.423 35.6691722394257 139.74831361703107 34.423 35.6691722394257 139.74831361703107 37.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ceec8742-09f9-4b05-9ae2-4b20865c8a2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ceec8742-09f9-4b05-9ae2-4b20865c8a2e_0">
											<gml:posList>35.6691722394257 139.74831361703107 37.149 35.66918053420807 139.74829112943257 37.149 35.66914790073673 139.74827304845616 37.149 35.66913960595768 139.74829553604738 37.149 35.6691722394257 139.74831361703107 37.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-423045e2-9949-4cf9-b736-95d563dcede3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-423045e2-9949-4cf9-b736-95d563dcede3_0">
											<gml:posList>35.66914790073673 139.74827304845616 34.423 35.66914790073673 139.74827304845616 37.149 35.66918053420807 139.74829112943257 37.149 35.66918053420807 139.74829112943257 34.423 35.66914790073673 139.74827304845616 34.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87e35197-680f-4f89-878b-926da6ac11d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87e35197-680f-4f89-878b-926da6ac11d9_0">
											<gml:posList>35.66918053420807 139.74829112943257 34.423 35.66918053420807 139.74829112943257 37.149 35.6691722394257 139.74831361703107 37.149 35.6691722394257 139.74831361703107 34.423 35.66918053420807 139.74829112943257 34.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3ddfcefa-c76c-444b-beb9-bce472f78245">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ddfcefa-c76c-444b-beb9-bce472f78245">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ddfcefa-c76c-444b-beb9-bce472f78245">
											<gml:posList>35.66920711663539 139.74825416308485 5.875 35.669140267912255 139.74842887269028 5.875 35.66909436755671 139.748399870096 5.875 35.66910408968034 139.74838185468008 5.875 35.66909389941547 139.74837512736596 5.875 35.66908481074704 139.7483966768555 5.875 35.66906632302317 139.74838310976224 5.875 35.669113020199056 139.7482639834846 5.875 35.669122217633614 139.74826883400473 5.875 35.66913921571892 139.74821524243865 5.875 35.66920711663539 139.74825416308485 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2f359c4-f503-48fe-8012-ee0680432e7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2f359c4-f503-48fe-8012-ee0680432e7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2f359c4-f503-48fe-8012-ee0680432e7b">
											<gml:posList>35.66906632302317 139.74838310976224 38.54 35.66908481074704 139.7483966768555 38.54 35.669084132629386 139.74839371722396 38.54 35.66906853982327 139.74838229000372 38.54 35.66906632302317 139.74838310976224 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38edb74e-bb6a-46c7-af0a-f1d2e72ef5e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38edb74e-bb6a-46c7-af0a-f1d2e72ef5e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38edb74e-bb6a-46c7-af0a-f1d2e72ef5e5">
											<gml:posList>35.66906632302317 139.74838310976224 38.54 35.66906853982327 139.74838229000372 38.54 35.66909673808945 139.7483103501252 38.54 35.66909594290041 139.74830754526323 38.54 35.66906632302317 139.74838310976224 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3bded759-8297-4cdc-8fce-c0e05ec9702a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bded759-8297-4cdc-8fce-c0e05ec9702a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bded759-8297-4cdc-8fce-c0e05ec9702a">
											<gml:posList>35.66909389941547 139.74837512736596 38.54 35.66909317629101 139.74837225615062 38.54 35.669084132629386 139.74839371722396 38.54 35.66908481074704 139.7483966768555 38.54 35.66909389941547 139.74837512736596 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc109710-ba0f-4888-9f4b-e9602de6d780">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc109710-ba0f-4888-9f4b-e9602de6d780">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc109710-ba0f-4888-9f4b-e9602de6d780">
											<gml:posList>35.66909317629101 139.74837225615062 38.12 35.66909473639831 139.7483732928293 38.12 35.669115160799116 139.7483211888925 38.12 35.66909673808945 139.7483103501252 38.12 35.66906853982327 139.74838229000372 38.12 35.669084132629386 139.74839371722396 38.12 35.66909317629101 139.74837225615062 38.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa13df0f-435c-4201-a209-fb86d8168028">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa13df0f-435c-4201-a209-fb86d8168028">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa13df0f-435c-4201-a209-fb86d8168028">
											<gml:posList>35.66909389941547 139.74837512736596 38.54 35.66909550460698 139.7483761860891 38.54 35.66909473639831 139.7483732928293 38.54 35.66909317629101 139.74837225615062 38.54 35.66909389941547 139.74837512736596 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38fd744d-39dd-4668-b22e-26a4b6075628">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38fd744d-39dd-4668-b22e-26a4b6075628">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38fd744d-39dd-4668-b22e-26a4b6075628">
											<gml:posList>35.66909649433218 139.74837365548737 34.7 35.66909550460698 139.7483761860891 34.7 35.66909866754434 139.74837493453035 34.7 35.66909649433218 139.74837365548737 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76932d66-efbd-435e-8104-61d419b5c385">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76932d66-efbd-435e-8104-61d419b5c385">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76932d66-efbd-435e-8104-61d419b5c385">
											<gml:posList>35.66909915983362 139.74830617213757 34.7 35.66909594290041 139.74830754526323 34.7 35.669098116113275 139.74830882430442 34.7 35.66909915983362 139.74830617213757 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46f8d296-1729-4138-bdfe-b07984d1816c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46f8d296-1729-4138-bdfe-b07984d1816c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46f8d296-1729-4138-bdfe-b07984d1816c">
											<gml:posList>35.66910408968034 139.74838185468008 34.7 35.66909436755671 139.748399870096 34.7 35.66909785508197 139.74839875074733 34.7 35.66910755020321 139.74838079058952 34.7 35.66910408968034 139.74838185468008 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3842e7c-e125-4144-93a2-386a908fac45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3842e7c-e125-4144-93a2-386a908fac45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3842e7c-e125-4144-93a2-386a908fac45">
											<gml:posList>35.66910408968034 139.74838185468008 34.7 35.66910755020321 139.74838079058952 34.7 35.66909866754434 139.74837493453035 34.7 35.66909550460698 139.7483761860891 34.7 35.66910408968034 139.74838185468008 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1403f646-1718-428c-b8a1-85ce39fbaa90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1403f646-1718-428c-b8a1-85ce39fbaa90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1403f646-1718-428c-b8a1-85ce39fbaa90">
											<gml:posList>35.66909594290041 139.74830754526323 34.7 35.66909915983362 139.74830617213757 34.7 35.66911419469132 139.7482678152303 34.7 35.669113020199056 139.7482639834846 34.7 35.66909594290041 139.74830754526323 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70fee9ed-156f-4680-a00e-fa528843afca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70fee9ed-156f-4680-a00e-fa528843afca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70fee9ed-156f-4680-a00e-fa528843afca">
											<gml:posList>35.66911744959158 139.74832020336413 38.54 35.669115160799116 139.7483211888925 38.54 35.66909473639831 139.7483732928293 38.54 35.66909550460698 139.7483761860891 38.54 35.66911744959158 139.74832020336413 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-508d0d79-ab95-4dee-a35f-d28570f82b5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-508d0d79-ab95-4dee-a35f-d28570f82b5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-508d0d79-ab95-4dee-a35f-d28570f82b5c">
											<gml:posList>35.66909594290041 139.74830754526323 38.54 35.66909673808945 139.7483103501252 38.54 35.669115160799116 139.7483211888925 38.54 35.66911744959158 139.74832020336413 38.54 35.66909594290041 139.74830754526323 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e003e082-c99a-496c-8c6b-94a10cddf227">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e003e082-c99a-496c-8c6b-94a10cddf227">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e003e082-c99a-496c-8c6b-94a10cddf227">
											<gml:posList>35.669140267912255 139.74842887269028 34.7 35.66913915638878 139.7484248530908 34.7 35.66909785508197 139.74839875074733 34.7 35.66909436755671 139.748399870096 34.7 35.669140267912255 139.74842887269028 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f887011-70dc-428e-82e5-d25a75e1b49a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f887011-70dc-428e-82e5-d25a75e1b49a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f887011-70dc-428e-82e5-d25a75e1b49a">
											<gml:posList>35.669122217633614 139.74826883400473 34.7 35.669113020199056 139.7482639834846 34.7 35.66911419469132 139.7482678152303 34.7 35.669123563448956 139.74827275393784 34.7 35.669122217633614 139.74826883400473 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-924c0e1f-c38c-48d6-8bbc-66c3039ed28b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-924c0e1f-c38c-48d6-8bbc-66c3039ed28b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-924c0e1f-c38c-48d6-8bbc-66c3039ed28b">
											<gml:posList>35.669122217633614 139.74826883400473 34.7 35.669123563448956 139.74827275393784 34.7 35.669140525543554 139.74821925077862 34.7 35.66913921571892 139.74821524243865 34.7 35.669122217633614 139.74826883400473 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7ff4f534-4b63-4c97-9c86-c6fad88ac74d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ff4f534-4b63-4c97-9c86-c6fad88ac74d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ff4f534-4b63-4c97-9c86-c6fad88ac74d">
											<gml:posList>35.66913915638878 139.7484248530908 34.423 35.66920392678305 139.7482555914162 34.423 35.669140525543554 139.74821925077862 34.423 35.669123563448956 139.74827275393784 34.423 35.66911419469132 139.7482678152303 34.423 35.66909915983362 139.74830617213757 34.423 35.669098116113275 139.74830882430442 34.423 35.66911744959158 139.74832020336413 34.423 35.66909649433218 139.74837365548737 34.423 35.66909866754434 139.74837493453035 34.423 35.66910755020321 139.74838079058952 34.423 35.66909785508197 139.74839875074733 34.423 35.66913915638878 139.7484248530908 34.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8dbb5b6-cdc6-40d8-814d-d187fa862729">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8dbb5b6-cdc6-40d8-814d-d187fa862729">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8dbb5b6-cdc6-40d8-814d-d187fa862729">
											<gml:posList>35.66920711663539 139.74825416308485 34.7 35.66920392678305 139.7482555914162 34.7 35.66913915638878 139.7484248530908 34.7 35.669140267912255 139.74842887269028 34.7 35.66920711663539 139.74825416308485 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84aeae5f-4018-4bc7-9ac5-54ff402b60d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84aeae5f-4018-4bc7-9ac5-54ff402b60d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84aeae5f-4018-4bc7-9ac5-54ff402b60d4">
											<gml:posList>35.66913921571892 139.74821524243865 34.7 35.669140525543554 139.74821925077862 34.7 35.66920392678305 139.7482555914162 34.7 35.66920711663539 139.74825416308485 34.7 35.66913921571892 139.74821524243865 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a40f3f41-27c3-4d90-9a1d-f3e1aa4b4ae7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a40f3f41-27c3-4d90-9a1d-f3e1aa4b4ae7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a40f3f41-27c3-4d90-9a1d-f3e1aa4b4ae7">
											<gml:posList>35.669123563448956 139.74827275393784 34.7 35.669123563448956 139.74827275393784 34.423 35.669140525543554 139.74821925077862 34.423 35.669140525543554 139.74821925077862 34.7 35.669123563448956 139.74827275393784 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-996603cb-805e-4861-8332-31ccfad0d81f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-996603cb-805e-4861-8332-31ccfad0d81f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-996603cb-805e-4861-8332-31ccfad0d81f">
											<gml:posList>35.66906853982327 139.74838229000372 38.54 35.66906853982327 139.74838229000372 38.12 35.66909673808945 139.7483103501252 38.12 35.66909673808945 139.7483103501252 38.54 35.66906853982327 139.74838229000372 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93c8cb38-5995-4bf2-960d-719405e8b9c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93c8cb38-5995-4bf2-960d-719405e8b9c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93c8cb38-5995-4bf2-960d-719405e8b9c8">
											<gml:posList>35.669115160799116 139.7483211888925 38.54 35.669115160799116 139.7483211888925 38.12 35.66909473639831 139.7483732928293 38.12 35.66909473639831 139.7483732928293 38.54 35.669115160799116 139.7483211888925 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-862c55bb-63db-469e-842b-efbf0e794100">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-862c55bb-63db-469e-842b-efbf0e794100">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-862c55bb-63db-469e-842b-efbf0e794100">
											<gml:posList>35.66909317629101 139.74837225615062 38.54 35.66909317629101 139.74837225615062 38.12 35.669084132629386 139.74839371722396 38.12 35.669084132629386 139.74839371722396 38.54 35.66909317629101 139.74837225615062 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ad21f59-4e1d-4957-b0a9-836ad6648325">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ad21f59-4e1d-4957-b0a9-836ad6648325">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ad21f59-4e1d-4957-b0a9-836ad6648325">
											<gml:posList>35.66910408968034 139.74838185468008 5.875 35.66909436755671 139.748399870096 5.875 35.66909436755671 139.748399870096 34.7 35.66910408968034 139.74838185468008 34.7 35.66910408968034 139.74838185468008 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60880972-294c-4323-b270-9a7665197597">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60880972-294c-4323-b270-9a7665197597">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60880972-294c-4323-b270-9a7665197597">
											<gml:posList>35.66920711663539 139.74825416308485 5.875 35.66913921571892 139.74821524243865 5.875 35.66913921571892 139.74821524243865 34.7 35.66920711663539 139.74825416308485 34.7 35.66920711663539 139.74825416308485 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9734b427-5090-43a9-bc50-d1f1a05b7b50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9734b427-5090-43a9-bc50-d1f1a05b7b50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9734b427-5090-43a9-bc50-d1f1a05b7b50">
											<gml:posList>35.669140525543554 139.74821925077862 34.7 35.669140525543554 139.74821925077862 34.423 35.66920392678305 139.7482555914162 34.423 35.66920392678305 139.7482555914162 34.7 35.669140525543554 139.74821925077862 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c115bc9f-63b1-4e26-950d-e811b07bf308">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c115bc9f-63b1-4e26-950d-e811b07bf308">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c115bc9f-63b1-4e26-950d-e811b07bf308">
											<gml:posList>35.66913921571892 139.74821524243865 5.875 35.669122217633614 139.74826883400473 5.875 35.669122217633614 139.74826883400473 34.7 35.66913921571892 139.74821524243865 34.7 35.66913921571892 139.74821524243865 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99c8d838-2199-43e2-bf08-44b17eddee6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99c8d838-2199-43e2-bf08-44b17eddee6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99c8d838-2199-43e2-bf08-44b17eddee6e">
											<gml:posList>35.669122217633614 139.74826883400473 5.875 35.669113020199056 139.7482639834846 5.875 35.669113020199056 139.7482639834846 34.7 35.669122217633614 139.74826883400473 34.7 35.669122217633614 139.74826883400473 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7397f34-bce5-4a0c-b617-b959d68f89a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7397f34-bce5-4a0c-b617-b959d68f89a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7397f34-bce5-4a0c-b617-b959d68f89a1">
											<gml:posList>35.66911419469132 139.7482678152303 34.7 35.66911419469132 139.7482678152303 34.423 35.669123563448956 139.74827275393784 34.423 35.669123563448956 139.74827275393784 34.7 35.66911419469132 139.7482678152303 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5f300f9-2ae1-455f-afee-2adf0889473f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5f300f9-2ae1-455f-afee-2adf0889473f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5f300f9-2ae1-455f-afee-2adf0889473f">
											<gml:posList>35.66909915983362 139.74830617213757 34.7 35.66909915983362 139.74830617213757 34.423 35.66911419469132 139.7482678152303 34.423 35.66911419469132 139.7482678152303 34.7 35.66909915983362 139.74830617213757 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d20f5c6-dd71-4871-ba4d-a20c937cb1e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d20f5c6-dd71-4871-ba4d-a20c937cb1e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d20f5c6-dd71-4871-ba4d-a20c937cb1e2">
											<gml:posList>35.669098116113275 139.74830882430442 34.7 35.669098116113275 139.74830882430442 34.423 35.66909915983362 139.74830617213757 34.423 35.66909915983362 139.74830617213757 34.7 35.669098116113275 139.74830882430442 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50c0b4dd-4c80-43f0-a15c-96e951d4bc21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50c0b4dd-4c80-43f0-a15c-96e951d4bc21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50c0b4dd-4c80-43f0-a15c-96e951d4bc21">
											<gml:posList>35.669098116113275 139.74830882430442 34.7 35.66909594290041 139.74830754526323 34.7 35.66909594290041 139.74830754526323 38.54 35.66911744959158 139.74832020336413 38.54 35.66911744959158 139.74832020336413 34.423 35.669098116113275 139.74830882430442 34.423 35.669098116113275 139.74830882430442 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7eeb3975-7afa-45aa-bf07-234e46b6569a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7eeb3975-7afa-45aa-bf07-234e46b6569a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7eeb3975-7afa-45aa-bf07-234e46b6569a">
											<gml:posList>35.66909673808945 139.7483103501252 38.54 35.66909673808945 139.7483103501252 38.12 35.669115160799116 139.7483211888925 38.12 35.669115160799116 139.7483211888925 38.54 35.66909673808945 139.7483103501252 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cba3dd46-ba93-4e1b-ae83-9fed7dae4dad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cba3dd46-ba93-4e1b-ae83-9fed7dae4dad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cba3dd46-ba93-4e1b-ae83-9fed7dae4dad">
											<gml:posList>35.66906632302317 139.74838310976224 5.875 35.66906632302317 139.74838310976224 38.54 35.66909594290041 139.74830754526323 38.54 35.66909594290041 139.74830754526323 34.7 35.669113020199056 139.7482639834846 34.7 35.669113020199056 139.7482639834846 5.875 35.66906632302317 139.74838310976224 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7923eeba-15cb-4d2e-af32-a84200c696c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7923eeba-15cb-4d2e-af32-a84200c696c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7923eeba-15cb-4d2e-af32-a84200c696c9">
											<gml:posList>35.66920392678305 139.7482555914162 34.7 35.66920392678305 139.7482555914162 34.423 35.66913915638878 139.7484248530908 34.423 35.66913915638878 139.7484248530908 34.7 35.66920392678305 139.7482555914162 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-256c4c4b-5ee3-46de-aa3b-314d07255094">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-256c4c4b-5ee3-46de-aa3b-314d07255094">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-256c4c4b-5ee3-46de-aa3b-314d07255094">
											<gml:posList>35.669140267912255 139.74842887269028 5.875 35.66920711663539 139.74825416308485 5.875 35.66920711663539 139.74825416308485 34.7 35.669140267912255 139.74842887269028 34.7 35.669140267912255 139.74842887269028 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56294ee4-3092-41ec-9135-9f59b85b95c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56294ee4-3092-41ec-9135-9f59b85b95c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56294ee4-3092-41ec-9135-9f59b85b95c3">
											<gml:posList>35.66909550460698 139.7483761860891 38.54 35.66909550460698 139.7483761860891 34.7 35.66909649433218 139.74837365548737 34.7 35.66909649433218 139.74837365548737 34.423 35.66911744959158 139.74832020336413 34.423 35.66911744959158 139.74832020336413 38.54 35.66909550460698 139.7483761860891 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bbc2e04e-9a7e-4235-9970-1e7f3bbf2115">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbc2e04e-9a7e-4235-9970-1e7f3bbf2115">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbc2e04e-9a7e-4235-9970-1e7f3bbf2115">
											<gml:posList>35.66909473639831 139.7483732928293 38.54 35.66909473639831 139.7483732928293 38.12 35.66909317629101 139.74837225615062 38.12 35.66909317629101 139.74837225615062 38.54 35.66909473639831 139.7483732928293 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f797bdc-5c7a-421f-b114-02fbbd8e826c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f797bdc-5c7a-421f-b114-02fbbd8e826c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f797bdc-5c7a-421f-b114-02fbbd8e826c">
											<gml:posList>35.66909866754434 139.74837493453035 34.7 35.66909866754434 139.74837493453035 34.423 35.66909649433218 139.74837365548737 34.423 35.66909649433218 139.74837365548737 34.7 35.66909866754434 139.74837493453035 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bb3bd6c-fa4d-4b16-9cfb-b057e56d2de1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bb3bd6c-fa4d-4b16-9cfb-b057e56d2de1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bb3bd6c-fa4d-4b16-9cfb-b057e56d2de1">
											<gml:posList>35.66910755020321 139.74838079058952 34.7 35.66910755020321 139.74838079058952 34.423 35.66909866754434 139.74837493453035 34.423 35.66909866754434 139.74837493453035 34.7 35.66910755020321 139.74838079058952 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cab13615-c44c-4ee2-8f09-8e5e0ad327b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cab13615-c44c-4ee2-8f09-8e5e0ad327b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cab13615-c44c-4ee2-8f09-8e5e0ad327b1">
											<gml:posList>35.66909389941547 139.74837512736596 5.875 35.66910408968034 139.74838185468008 5.875 35.66910408968034 139.74838185468008 34.7 35.66909550460698 139.7483761860891 34.7 35.66909550460698 139.7483761860891 38.54 35.66909389941547 139.74837512736596 38.54 35.66909389941547 139.74837512736596 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ed7c86d-19f9-42b0-b36f-8d8d5c598bb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ed7c86d-19f9-42b0-b36f-8d8d5c598bb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ed7c86d-19f9-42b0-b36f-8d8d5c598bb2">
											<gml:posList>35.66908481074704 139.7483966768555 38.54 35.66908481074704 139.7483966768555 5.875 35.66909389941547 139.74837512736596 5.875 35.66909389941547 139.74837512736596 38.54 35.66908481074704 139.7483966768555 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3a9efcf-8dd1-4029-b9d8-602d2d766937">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3a9efcf-8dd1-4029-b9d8-602d2d766937">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3a9efcf-8dd1-4029-b9d8-602d2d766937">
											<gml:posList>35.669084132629386 139.74839371722396 38.54 35.669084132629386 139.74839371722396 38.12 35.66906853982327 139.74838229000372 38.12 35.66906853982327 139.74838229000372 38.54 35.669084132629386 139.74839371722396 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb4398cf-1be8-4509-849f-658df77e11e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb4398cf-1be8-4509-849f-658df77e11e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb4398cf-1be8-4509-849f-658df77e11e0">
											<gml:posList>35.66909785508197 139.74839875074733 34.7 35.66909785508197 139.74839875074733 34.423 35.66910755020321 139.74838079058952 34.423 35.66910755020321 139.74838079058952 34.7 35.66909785508197 139.74839875074733 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3be665fa-706d-4a7f-82c0-f521e99b2b84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3be665fa-706d-4a7f-82c0-f521e99b2b84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3be665fa-706d-4a7f-82c0-f521e99b2b84">
											<gml:posList>35.66906632302317 139.74838310976224 38.54 35.66906632302317 139.74838310976224 5.875 35.66908481074704 139.7483966768555 5.875 35.66908481074704 139.7483966768555 38.54 35.66906632302317 139.74838310976224 38.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c703c174-eac8-40c7-b8d3-85c2aee2a881">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c703c174-eac8-40c7-b8d3-85c2aee2a881">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c703c174-eac8-40c7-b8d3-85c2aee2a881">
											<gml:posList>35.66913915638878 139.7484248530908 34.7 35.66913915638878 139.7484248530908 34.423 35.66909785508197 139.74839875074733 34.423 35.66909785508197 139.74839875074733 34.7 35.66913915638878 139.7484248530908 34.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d78c713-0bee-4a04-a7c9-db439f63cf9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d78c713-0bee-4a04-a7c9-db439f63cf9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d78c713-0bee-4a04-a7c9-db439f63cf9b">
											<gml:posList>35.66909436755671 139.748399870096 5.875 35.669140267912255 139.74842887269028 5.875 35.669140267912255 139.74842887269028 34.7 35.66909436755671 139.748399870096 34.7 35.66909436755671 139.748399870096 5.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5326</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">150.77985</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>