<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_067a9894-2c79-4073-871d-7f4446ef923b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">26.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67170450218697 139.73876372376597 0 35.67157157002313 139.73878961873356 0 35.671587530296144 139.73891210477285 0 35.671720336164235 139.73888604445526 0 35.67170450218697 139.73876372376597 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170450218697 139.73876372376597 16.922 35.671720336164235 139.73888604445526 16.922 35.671587530296144 139.73891210477285 16.922 35.67157157002313 139.73878961873356 16.922 35.67170450218697 139.73876372376597 16.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170450218697 139.73876372376597 16.922 35.67157157002313 139.73878961873356 16.922 35.67157157002313 139.73878961873356 43.46 35.67170450218697 139.73876372376597 43.46 35.67170450218697 139.73876372376597 16.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157157002313 139.73878961873356 16.922 35.671587530296144 139.73891210477285 16.922 35.671587530296144 139.73891210477285 43.46 35.67157157002313 139.73878961873356 43.46 35.67157157002313 139.73878961873356 16.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671587530296144 139.73891210477285 16.922 35.671720336164235 139.73888604445526 16.922 35.671720336164235 139.73888604445526 43.46 35.671587530296144 139.73891210477285 43.46 35.671587530296144 139.73891210477285 16.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671720336164235 139.73888604445526 16.922 35.67170450218697 139.73876372376597 16.922 35.67170450218697 139.73876372376597 43.46 35.671720336164235 139.73888604445526 43.46 35.671720336164235 139.73888604445526 16.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170450218697 139.73876372376597 43.46 35.67157157002313 139.73878961873356 43.46 35.671587530296144 139.73891210477285 43.46 35.671720336164235 139.73888604445526 43.46 35.67170450218697 139.73876372376597 43.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a4a35f47-aa5f-4300-ae44-e6295c949b58"/>
							<gml:surfaceMember xlink:href="#poly-d2757adc-d2f0-4fbf-8ce3-c1fa7aaa2111"/>
							<gml:surfaceMember xlink:href="#poly-f38b829c-1074-4da0-b523-622d88dfafd5"/>
							<gml:surfaceMember xlink:href="#poly-c8d92df3-9d6f-4c57-945f-ff3bd36a23d7"/>
							<gml:surfaceMember xlink:href="#poly-05a9ed04-d39a-414f-b557-a89ed7ba940c"/>
							<gml:surfaceMember xlink:href="#poly-3a0e5a52-0e58-484c-935e-78529f958354"/>
							<gml:surfaceMember xlink:href="#poly-3cd5f5bf-28c0-4f6a-941d-698b83ec6647"/>
							<gml:surfaceMember xlink:href="#poly-3ecab25c-c0fe-45b5-8a3d-4c71a72cc54f"/>
							<gml:surfaceMember xlink:href="#poly-925ad850-a943-4744-8134-956570f90019"/>
							<gml:surfaceMember xlink:href="#poly-bb8a78e1-fbf2-4b24-aee7-24bfbb832178"/>
							<gml:surfaceMember xlink:href="#poly-875cc608-90c9-4601-ae25-28a482ea4f24"/>
							<gml:surfaceMember xlink:href="#poly-50f34b5c-9e46-45dd-b585-9c6d1f19fa0e"/>
							<gml:surfaceMember xlink:href="#poly-21651028-e839-44bf-934b-9032df18f3af"/>
							<gml:surfaceMember xlink:href="#poly-70b1507c-c36a-461e-be5f-feb38ab30e77"/>
							<gml:surfaceMember xlink:href="#poly-39cc3cba-db26-44bd-b902-d36e6cf5ef24"/>
							<gml:surfaceMember xlink:href="#poly-676e6aa6-79be-4d5a-aff2-3153009f8368"/>
							<gml:surfaceMember xlink:href="#poly-fa382522-5532-4d8a-9369-daa4f186c288"/>
							<gml:surfaceMember xlink:href="#poly-0c6b732d-e289-40f0-a757-9b7797524dba"/>
							<gml:surfaceMember xlink:href="#poly-bb494876-7434-467b-a0c8-e1fa2a6a4ce3"/>
							<gml:surfaceMember xlink:href="#poly-c7f22cda-3102-4797-92fb-570e3d1aecfa"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_067a9894-2c79-4073-871d-7f4446ef923b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e28a7c6-7a65-4fb4-a9ee-ce3c47d82b52">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671652797464816 139.73878416542658 44.855 35.67165543134754 139.73880951388873 44.855 35.67165517898937 139.73880954732556 44.855 35.67165190521058 139.73878429903604 44.855 35.671652797464816 139.73878416542658 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c07a646-4e27-4eb4-93ec-baac9c278ab8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671644318783066 139.7388112502339 44.328 35.67164168490071 139.73878590177523 44.328 35.67165190521058 139.73878429903604 44.328 35.67165517898937 139.73880954732556 44.328 35.671644318783066 139.7388112502339 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de7e8b39-62d7-4c16-93aa-466dd5a7ec9b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67163143985857 139.73885935053477 44.328 35.6716245814747 139.738860706281 44.328 35.67162300370059 139.73884874485591 44.328 35.67162986208433 139.73884738910868 44.328 35.67163143985857 139.73885935053477 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5099ccfc-001b-4965-8e3a-cd6e1c65ef30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67161830803529 139.738883833851 44.328 35.671610106814725 139.73888545629111 44.328 35.67160571805449 139.73885216752683 44.328 35.67161391927459 139.73885054508344 44.328 35.67161830803529 139.738883833851 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f6f8a35-eb76-4c22-bd44-5722ffa593d6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67158947784378 139.73885539012866 44.328 35.67159707524004 139.73885388990817 44.328 35.67160147300487 139.73888716761192 44.328 35.67159387561686 139.73888867887575 44.328 35.67158947784378 139.73885539012866 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd750577-42a2-4521-90b7-f6c51b1dc186">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd750577-42a2-4521-90b7-f6c51b1dc186_0">
											<gml:posList>35.67158947784378 139.73885539012866 44.328 35.67159387561686 139.73888867887575 44.328 35.67159387561686 139.73888867887575 45.327 35.67158947784378 139.73885539012866 45.327 35.67158947784378 139.73885539012866 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b98c9d0a-5357-43b4-b248-56a210c12c07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b98c9d0a-5357-43b4-b248-56a210c12c07_0">
											<gml:posList>35.67159707524004 139.73885388990817 44.328 35.67158947784378 139.73885539012866 44.328 35.67158947784378 139.73885539012866 45.327 35.67159707524004 139.73885388990817 45.327 35.67159707524004 139.73885388990817 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c951adc-8fc1-4c83-82b7-17e79b49989c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c951adc-8fc1-4c83-82b7-17e79b49989c_0">
											<gml:posList>35.67158947784378 139.73885539012866 45.327 35.67159387561686 139.73888867887575 45.327 35.67160147300487 139.73888716761192 45.327 35.67159707524004 139.73885388990817 45.327 35.67158947784378 139.73885539012866 45.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-797885d8-152c-4446-815c-7fb73d5a78f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-797885d8-152c-4446-815c-7fb73d5a78f8_0">
											<gml:posList>35.67159387561686 139.73888867887575 44.328 35.67160147300487 139.73888716761192 44.328 35.67160147300487 139.73888716761192 45.327 35.67159387561686 139.73888867887575 45.327 35.67159387561686 139.73888867887575 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1ea06ba-4ea8-4f2f-9376-71a21845a536">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1ea06ba-4ea8-4f2f-9376-71a21845a536_0">
											<gml:posList>35.67160147300487 139.73888716761192 44.328 35.67159707524004 139.73885388990817 44.328 35.67159707524004 139.73885388990817 45.327 35.67160147300487 139.73888716761192 45.327 35.67160147300487 139.73888716761192 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7f50be0-00d2-4a42-b6e5-d18aa3b95eec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7f50be0-00d2-4a42-b6e5-d18aa3b95eec_0">
											<gml:posList>35.67160571805449 139.73885216752683 44.328 35.671610106814725 139.73888545629111 44.328 35.671610106814725 139.73888545629111 45.327 35.67160571805449 139.73885216752683 45.327 35.67160571805449 139.73885216752683 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-420cad8c-1617-4431-9e81-52fba0db89f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-420cad8c-1617-4431-9e81-52fba0db89f6_0">
											<gml:posList>35.67161391927459 139.73885054508344 44.328 35.67160571805449 139.73885216752683 44.328 35.67160571805449 139.73885216752683 45.327 35.67161391927459 139.73885054508344 45.327 35.67161391927459 139.73885054508344 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-104b45b9-ff61-478e-91a6-786461c85364">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-104b45b9-ff61-478e-91a6-786461c85364_0">
											<gml:posList>35.67161830803529 139.738883833851 45.327 35.67161391927459 139.73885054508344 45.327 35.67160571805449 139.73885216752683 45.327 35.671610106814725 139.73888545629111 45.327 35.67161830803529 139.738883833851 45.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc286e55-4466-484b-b244-334b65128d02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc286e55-4466-484b-b244-334b65128d02_0">
											<gml:posList>35.671610106814725 139.73888545629111 44.328 35.67161830803529 139.738883833851 44.328 35.67161830803529 139.738883833851 45.327 35.671610106814725 139.73888545629111 45.327 35.671610106814725 139.73888545629111 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb55c440-0ad8-4329-a913-3de6a51a6f3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb55c440-0ad8-4329-a913-3de6a51a6f3a_0">
											<gml:posList>35.67161830803529 139.738883833851 44.328 35.67161391927459 139.73885054508344 44.328 35.67161391927459 139.73885054508344 45.327 35.67161830803529 139.738883833851 45.327 35.67161830803529 139.738883833851 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccea0911-3711-46bc-924e-ef038cebc6d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccea0911-3711-46bc-924e-ef038cebc6d4_0">
											<gml:posList>35.67162300370059 139.73884874485591 44.328 35.6716245814747 139.738860706281 44.328 35.6716245814747 139.738860706281 45.327 35.67162300370059 139.73884874485591 45.327 35.67162300370059 139.73884874485591 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87ce4cc6-d3dd-4581-a28b-e133f372bf39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87ce4cc6-d3dd-4581-a28b-e133f372bf39_0">
											<gml:posList>35.67162986208433 139.73884738910868 44.328 35.67162300370059 139.73884874485591 44.328 35.67162300370059 139.73884874485591 45.327 35.67162986208433 139.73884738910868 45.327 35.67162986208433 139.73884738910868 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0d67b86-4b2d-45f7-a7aa-fdcf0c7a2880">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0d67b86-4b2d-45f7-a7aa-fdcf0c7a2880_0">
											<gml:posList>35.67163143985857 139.73885935053477 45.327 35.67162986208433 139.73884738910868 45.327 35.67162300370059 139.73884874485591 45.327 35.6716245814747 139.738860706281 45.327 35.67163143985857 139.73885935053477 45.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8465a64-a90b-4ddc-a857-2375bb716025">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8465a64-a90b-4ddc-a857-2375bb716025_0">
											<gml:posList>35.6716245814747 139.738860706281 44.328 35.67163143985857 139.73885935053477 44.328 35.67163143985857 139.73885935053477 45.327 35.6716245814747 139.738860706281 45.327 35.6716245814747 139.738860706281 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef9eeed7-d705-4389-be6a-5174c1915379">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef9eeed7-d705-4389-be6a-5174c1915379_0">
											<gml:posList>35.67162986208433 139.73884738910868 44.328 35.67162986208433 139.73884738910868 45.327 35.67163143985857 139.73885935053477 45.327 35.67163143985857 139.73885935053477 44.328 35.67162986208433 139.73884738910868 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-177dfcef-f083-47f6-ac20-1fcd438486d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-177dfcef-f083-47f6-ac20-1fcd438486d6_0">
											<gml:posList>35.67164168490071 139.73878590177523 44.328 35.671644318783066 139.7388112502339 44.328 35.671644318783066 139.7388112502339 44.943 35.67164168490071 139.73878590177523 44.943 35.67164168490071 139.73878590177523 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4601db3a-6be9-4d3a-abdb-00042ece6413">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4601db3a-6be9-4d3a-abdb-00042ece6413_0">
											<gml:posList>35.67164168490071 139.73878590177523 44.328 35.67164168490071 139.73878590177523 44.943 35.671652797464816 139.73878416542658 44.943 35.671652797464816 139.73878416542658 44.855 35.67165190521058 139.73878429903604 44.855 35.67165190521058 139.73878429903604 44.328 35.67164168490071 139.73878590177523 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5f9c0df-18fd-4ec7-b7ba-fdbacfb4b858">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5f9c0df-18fd-4ec7-b7ba-fdbacfb4b858_0">
											<gml:posList>35.67165543134754 139.73880951388873 44.943 35.671652797464816 139.73878416542658 44.943 35.67164168490071 139.73878590177523 44.943 35.671644318783066 139.7388112502339 44.943 35.67165543134754 139.73880951388873 44.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6476cb8-f019-4459-a09b-907975153f86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6476cb8-f019-4459-a09b-907975153f86_0">
											<gml:posList>35.67165517898937 139.73880954732556 44.855 35.67165543134754 139.73880951388873 44.855 35.67165543134754 139.73880951388873 44.943 35.671644318783066 139.7388112502339 44.943 35.671644318783066 139.7388112502339 44.328 35.67165517898937 139.73880954732556 44.328 35.67165517898937 139.73880954732556 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77b28f5f-acb2-40a5-b196-7108d5092d2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77b28f5f-acb2-40a5-b196-7108d5092d2a_0">
											<gml:posList>35.67165517898937 139.73880954732556 44.328 35.67165190521058 139.73878429903604 44.328 35.67165190521058 139.73878429903604 44.855 35.67165517898937 139.73880954732556 44.855 35.67165517898937 139.73880954732556 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a48ef3b-708b-49ce-9c87-5398c3525b96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a48ef3b-708b-49ce-9c87-5398c3525b96_0">
											<gml:posList>35.67165543134754 139.73880951388873 44.855 35.671652797464816 139.73878416542658 44.855 35.671652797464816 139.73878416542658 44.943 35.67165543134754 139.73880951388873 44.943 35.67165543134754 139.73880951388873 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_067a9894-2c79-4073-871d-7f4446ef923b_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d9d45b2-96d7-4229-b3b5-4654bec5e36d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67162383469353 139.73880501105776 44.328 35.67162694537137 139.73882917698126 44.328 35.67159025604656 139.7388362678482 44.328 35.67158714537013 139.73881210193548 44.328 35.67162383469353 139.73880501105776 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0095c773-f8a4-431d-b121-d6669d4033ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0095c773-f8a4-431d-b121-d6669d4033ef_0">
											<gml:posList>35.67158714537013 139.73881210193548 44.328 35.67158714537013 139.73881210193548 46.153 35.67162383469353 139.73880501105776 46.153 35.67162383469353 139.73880501105776 44.328 35.67158714537013 139.73881210193548 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a433c954-b443-46ae-a75d-4df0e547d898">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a433c954-b443-46ae-a75d-4df0e547d898_0">
											<gml:posList>35.67162383469353 139.73880501105776 44.328 35.67162383469353 139.73880501105776 46.153 35.67162694537137 139.73882917698126 46.153 35.67162694537137 139.73882917698126 44.328 35.67162383469353 139.73880501105776 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ddb9249-2c5c-4c90-85ab-62762d80e2ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ddb9249-2c5c-4c90-85ab-62762d80e2ad_0">
											<gml:posList>35.67162383469353 139.73880501105776 46.153 35.67158714537013 139.73881210193548 46.153 35.67159025604656 139.7388362678482 46.153 35.67162694537137 139.73882917698126 46.153 35.67162383469353 139.73880501105776 46.153</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-958fde03-ed9d-4673-8f76-5726a8e16188">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-958fde03-ed9d-4673-8f76-5726a8e16188_0">
											<gml:posList>35.67159025604656 139.7388362678482 44.328 35.67159025604656 139.7388362678482 46.153 35.67158714537013 139.73881210193548 46.153 35.67158714537013 139.73881210193548 44.328 35.67159025604656 139.7388362678482 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61ee5688-636f-4656-bf4f-c6992a6bcc94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61ee5688-636f-4656-bf4f-c6992a6bcc94_0">
											<gml:posList>35.67162694537137 139.73882917698126 44.328 35.67162694537137 139.73882917698126 46.153 35.67159025604656 139.7388362678482 46.153 35.67159025604656 139.7388362678482 44.328 35.67162694537137 139.73882917698126 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_067a9894-2c79-4073-871d-7f4446ef923b_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2254cf69-a9c7-461f-ab90-bcdee5fdc198">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67173599866767 139.73881284329897 16.922 35.67174497590626 139.73888121022418 16.922 35.67172033616423 139.73888604445526 16.922 35.67171139493991 139.73881762227586 16.922 35.67173599866767 139.73881284329897 16.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40d93208-4292-4ecc-99a9-032d23d47ada">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40d93208-4292-4ecc-99a9-032d23d47ada_0">
											<gml:posList>35.67171139493991 139.73881762227586 44.855 35.67171139493991 139.73881762227586 16.922 35.67172033616423 139.73888604445526 16.922 35.67172033616423 139.73888604445526 44.855 35.67171139493991 139.73881762227586 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-329bb391-e7c4-4c50-a57e-24c40d02077e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-329bb391-e7c4-4c50-a57e-24c40d02077e_0">
											<gml:posList>35.67173599866767 139.73881284329897 44.855 35.67173599866767 139.73881284329897 16.922 35.67171139493991 139.73881762227586 16.922 35.67171139493991 139.73881762227586 44.855 35.67173599866767 139.73881284329897 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c89eb312-ad87-40d9-9fde-4e7eaf2c6ecb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c89eb312-ad87-40d9-9fde-4e7eaf2c6ecb_0">
											<gml:posList>35.67171139493991 139.73881762227586 44.855 35.67172033616423 139.73888604445526 44.855 35.67174497590626 139.73888121022418 44.855 35.67173599866767 139.73881284329897 44.855 35.67171139493991 139.73881762227586 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ca2e722-24e4-4f61-89dc-9b279dd12414">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ca2e722-24e4-4f61-89dc-9b279dd12414_0">
											<gml:posList>35.67172033616423 139.73888604445526 44.855 35.67172033616423 139.73888604445526 16.922 35.67174497590626 139.73888121022418 16.922 35.67174497590626 139.73888121022418 44.855 35.67172033616423 139.73888604445526 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32ae73e9-144f-4ea4-8279-a1f223ac2cfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32ae73e9-144f-4ea4-8279-a1f223ac2cfb_0">
											<gml:posList>35.67174497590626 139.73888121022418 44.855 35.67174497590626 139.73888121022418 16.922 35.67173599866767 139.73881284329897 16.922 35.67173599866767 139.73881284329897 44.855 35.67174497590626 139.73888121022418 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a4a35f47-aa5f-4300-ae44-e6295c949b58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4a35f47-aa5f-4300-ae44-e6295c949b58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4a35f47-aa5f-4300-ae44-e6295c949b58">
											<gml:posList>35.67170450218697 139.73876372376597 16.922 35.67172033616423 139.73888604445526 16.922 35.67158753029613 139.73891210477285 16.922 35.67157157002311 139.73878961873353 16.922 35.67170450218697 139.73876372376597 16.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2757adc-d2f0-4fbf-8ce3-c1fa7aaa2111">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2757adc-d2f0-4fbf-8ce3-c1fa7aaa2111">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2757adc-d2f0-4fbf-8ce3-c1fa7aaa2111">
											<gml:posList>35.67158753029613 139.73891210477285 44.855 35.67159023082608 139.73890752837204 44.855 35.671575295291625 139.73879292826777 44.855 35.67157157002311 139.73878961873353 44.855 35.67158753029613 139.73891210477285 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f38b829c-1074-4da0-b523-622d88dfafd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f38b829c-1074-4da0-b523-622d88dfafd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f38b829c-1074-4da0-b523-622d88dfafd5">
											<gml:posList>35.671575295291625 139.73879292826777 44.328 35.67159023082608 139.73890752837204 44.328 35.67166597054979 139.73889267008303 44.328 35.671651107180374 139.73877815815965 44.328 35.671575295291625 139.73879292826777 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8d92df3-9d6f-4c57-945f-ff3bd36a23d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8d92df3-9d6f-4c57-945f-ff3bd36a23d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8d92df3-9d6f-4c57-945f-ff3bd36a23d7">
											<gml:posList>35.67170450218697 139.73876372376597 44.855 35.67157157002311 139.73878961873353 44.855 35.671575295291625 139.73879292826777 44.855 35.671651107180374 139.73877815815965 44.855 35.67165643348239 139.73877712455945 44.855 35.67170178361776 139.73876827810653 44.855 35.67170450218697 139.73876372376597 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05a9ed04-d39a-414f-b557-a89ed7ba940c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05a9ed04-d39a-414f-b557-a89ed7ba940c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05a9ed04-d39a-414f-b557-a89ed7ba940c">
											<gml:posList>35.67158753029613 139.73891210477285 44.855 35.67172033616423 139.73888604445526 44.855 35.67171660188464 139.73888273492133 44.855 35.67167138697265 139.73889161429122 44.855 35.67166597054979 139.73889267008303 44.855 35.67159023082608 139.73890752837204 44.855 35.67158753029613 139.73891210477285 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a0e5a52-0e58-484c-935e-78529f958354">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a0e5a52-0e58-484c-935e-78529f958354">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a0e5a52-0e58-484c-935e-78529f958354">
											<gml:posList>35.67167138697265 139.73889161429122 44.855 35.67165643348239 139.73877712455945 44.855 35.671651107180374 139.73877815815965 44.855 35.67166597054979 139.73889267008303 44.855 35.67167138697265 139.73889161429122 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3cd5f5bf-28c0-4f6a-941d-698b83ec6647">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cd5f5bf-28c0-4f6a-941d-698b83ec6647">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cd5f5bf-28c0-4f6a-941d-698b83ec6647">
											<gml:posList>35.67171660188464 139.73888273492133 44.328 35.67170178361776 139.73876827810653 44.328 35.67165643348239 139.73877712455945 44.328 35.67167138697265 139.73889161429122 44.328 35.67171660188464 139.73888273492133 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ecab25c-c0fe-45b5-8a3d-4c71a72cc54f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ecab25c-c0fe-45b5-8a3d-4c71a72cc54f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ecab25c-c0fe-45b5-8a3d-4c71a72cc54f">
											<gml:posList>35.67170450218697 139.73876372376597 44.855 35.67170178361776 139.73876827810653 44.855 35.67171660188464 139.73888273492133 44.855 35.67172033616423 139.73888604445526 44.855 35.67170450218697 139.73876372376597 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-925ad850-a943-4744-8134-956570f90019">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-925ad850-a943-4744-8134-956570f90019">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-925ad850-a943-4744-8134-956570f90019">
											<gml:posList>35.67157157002311 139.73878961873353 16.922 35.67158753029613 139.73891210477285 16.922 35.67158753029613 139.73891210477285 44.855 35.67157157002311 139.73878961873353 44.855 35.67157157002311 139.73878961873353 16.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb8a78e1-fbf2-4b24-aee7-24bfbb832178">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb8a78e1-fbf2-4b24-aee7-24bfbb832178">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb8a78e1-fbf2-4b24-aee7-24bfbb832178">
											<gml:posList>35.67159023082608 139.73890752837204 44.855 35.67159023082608 139.73890752837204 44.328 35.671575295291625 139.73879292826777 44.328 35.671575295291625 139.73879292826777 44.855 35.67159023082608 139.73890752837204 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-875cc608-90c9-4601-ae25-28a482ea4f24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-875cc608-90c9-4601-ae25-28a482ea4f24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-875cc608-90c9-4601-ae25-28a482ea4f24">
											<gml:posList>35.67170178361776 139.73876827810653 44.328 35.67170178361776 139.73876827810653 44.855 35.67165643348239 139.73877712455945 44.855 35.67165643348239 139.73877712455945 44.328 35.67170178361776 139.73876827810653 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50f34b5c-9e46-45dd-b585-9c6d1f19fa0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50f34b5c-9e46-45dd-b585-9c6d1f19fa0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50f34b5c-9e46-45dd-b585-9c6d1f19fa0e">
											<gml:posList>35.67170450218697 139.73876372376597 16.922 35.67157157002311 139.73878961873353 16.922 35.67157157002311 139.73878961873353 44.855 35.67170450218697 139.73876372376597 44.855 35.67170450218697 139.73876372376597 16.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21651028-e839-44bf-934b-9032df18f3af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21651028-e839-44bf-934b-9032df18f3af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21651028-e839-44bf-934b-9032df18f3af">
											<gml:posList>35.671651107180374 139.73877815815965 44.328 35.671651107180374 139.73877815815965 44.855 35.671575295291625 139.73879292826777 44.855 35.671575295291625 139.73879292826777 44.328 35.671651107180374 139.73877815815965 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70b1507c-c36a-461e-be5f-feb38ab30e77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70b1507c-c36a-461e-be5f-feb38ab30e77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70b1507c-c36a-461e-be5f-feb38ab30e77">
											<gml:posList>35.67172033616423 139.73888604445526 16.922 35.67170450218697 139.73876372376597 16.922 35.67170450218697 139.73876372376597 44.855 35.67172033616423 139.73888604445526 44.855 35.67172033616423 139.73888604445526 16.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39cc3cba-db26-44bd-b902-d36e6cf5ef24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39cc3cba-db26-44bd-b902-d36e6cf5ef24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39cc3cba-db26-44bd-b902-d36e6cf5ef24">
											<gml:posList>35.67170178361776 139.73876827810653 44.855 35.67170178361776 139.73876827810653 44.328 35.67171660188464 139.73888273492133 44.328 35.67171660188464 139.73888273492133 44.855 35.67170178361776 139.73876827810653 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-676e6aa6-79be-4d5a-aff2-3153009f8368">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-676e6aa6-79be-4d5a-aff2-3153009f8368">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-676e6aa6-79be-4d5a-aff2-3153009f8368">
											<gml:posList>35.67167138697265 139.73889161429122 44.328 35.67165643348239 139.73877712455945 44.328 35.67165643348239 139.73877712455945 44.855 35.67167138697265 139.73889161429122 44.855 35.67167138697265 139.73889161429122 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa382522-5532-4d8a-9369-daa4f186c288">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa382522-5532-4d8a-9369-daa4f186c288">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa382522-5532-4d8a-9369-daa4f186c288">
											<gml:posList>35.67166597054979 139.73889267008303 44.855 35.671651107180374 139.73877815815965 44.855 35.671651107180374 139.73877815815965 44.328 35.67166597054979 139.73889267008303 44.328 35.67166597054979 139.73889267008303 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c6b732d-e289-40f0-a757-9b7797524dba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c6b732d-e289-40f0-a757-9b7797524dba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c6b732d-e289-40f0-a757-9b7797524dba">
											<gml:posList>35.67171660188464 139.73888273492133 44.855 35.67171660188464 139.73888273492133 44.328 35.67167138697265 139.73889161429122 44.328 35.67167138697265 139.73889161429122 44.855 35.67171660188464 139.73888273492133 44.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb494876-7434-467b-a0c8-e1fa2a6a4ce3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb494876-7434-467b-a0c8-e1fa2a6a4ce3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb494876-7434-467b-a0c8-e1fa2a6a4ce3">
											<gml:posList>35.67158753029613 139.73891210477285 16.922 35.67172033616423 139.73888604445526 16.922 35.67172033616423 139.73888604445526 44.855 35.67158753029613 139.73891210477285 44.855 35.67158753029613 139.73891210477285 16.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7f22cda-3102-4797-92fb-570e3d1aecfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7f22cda-3102-4797-92fb-570e3d1aecfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7f22cda-3102-4797-92fb-570e3d1aecfa">
											<gml:posList>35.67159023082608 139.73890752837204 44.328 35.67159023082608 139.73890752837204 44.855 35.67166597054979 139.73889267008303 44.855 35.67166597054979 139.73889267008303 44.328 35.67159023082608 139.73890752837204 44.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11316</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">184.78095</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1121</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.32</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>