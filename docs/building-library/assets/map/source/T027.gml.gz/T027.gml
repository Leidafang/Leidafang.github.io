<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_06c7304c-bf62-472f-abc2-46cda06b0926">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.90</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008003</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>霞が関三丁目南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">11.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67091575712888 139.74799585411435 0 35.670804400129015 139.74794306077374 0 35.6708646564865 139.74775200560651 0 35.67075708640021 139.74770097600342 0 35.67065240163113 139.7480321453526 0 35.67077647224673 139.7480910006726 0 35.670714596312436 139.74828691746814 0 35.670803411290244 139.74832902019511 0 35.67086528729187 139.74813310321474 0 35.670871508871606 139.74813607911182 0 35.67091575712888 139.74799585411435 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67091575712888 139.74799585411435 7.37 35.670871508871606 139.74813607911182 7.37 35.67086528729187 139.74813310321474 7.37 35.670803411290244 139.74832902019511 7.37 35.670714596312436 139.74828691746814 7.37 35.67077647224673 139.7480910006726 7.37 35.67065240163113 139.7480321453526 7.37 35.67075708640021 139.74770097600342 7.37 35.6708646564865 139.74775200560651 7.37 35.670804400129015 139.74794306077374 7.37 35.67091575712888 139.74799585411435 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67091575712888 139.74799585411435 7.37 35.670804400129015 139.74794306077374 7.37 35.670804400129015 139.74794306077374 18.77 35.67091575712888 139.74799585411435 18.77 35.67091575712888 139.74799585411435 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670804400129015 139.74794306077374 7.37 35.6708646564865 139.74775200560651 7.37 35.6708646564865 139.74775200560651 18.77 35.670804400129015 139.74794306077374 18.77 35.670804400129015 139.74794306077374 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708646564865 139.74775200560651 7.37 35.67075708640021 139.74770097600342 7.37 35.67075708640021 139.74770097600342 18.77 35.6708646564865 139.74775200560651 18.77 35.6708646564865 139.74775200560651 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67075708640021 139.74770097600342 7.37 35.67065240163113 139.7480321453526 7.37 35.67065240163113 139.7480321453526 18.77 35.67075708640021 139.74770097600342 18.77 35.67075708640021 139.74770097600342 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67065240163113 139.7480321453526 7.37 35.67077647224673 139.7480910006726 7.37 35.67077647224673 139.7480910006726 18.77 35.67065240163113 139.7480321453526 18.77 35.67065240163113 139.7480321453526 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077647224673 139.7480910006726 7.37 35.670714596312436 139.74828691746814 7.37 35.670714596312436 139.74828691746814 18.77 35.67077647224673 139.7480910006726 18.77 35.67077647224673 139.7480910006726 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670714596312436 139.74828691746814 7.37 35.670803411290244 139.74832902019511 7.37 35.670803411290244 139.74832902019511 18.77 35.670714596312436 139.74828691746814 18.77 35.670714596312436 139.74828691746814 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670803411290244 139.74832902019511 7.37 35.67086528729187 139.74813310321474 7.37 35.67086528729187 139.74813310321474 18.77 35.670803411290244 139.74832902019511 18.77 35.670803411290244 139.74832902019511 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67086528729187 139.74813310321474 7.37 35.670871508871606 139.74813607911182 7.37 35.670871508871606 139.74813607911182 18.77 35.67086528729187 139.74813310321474 18.77 35.67086528729187 139.74813310321474 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670871508871606 139.74813607911182 7.37 35.67091575712888 139.74799585411435 7.37 35.67091575712888 139.74799585411435 18.77 35.670871508871606 139.74813607911182 18.77 35.670871508871606 139.74813607911182 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67091575712888 139.74799585411435 18.77 35.670804400129015 139.74794306077374 18.77 35.6708646564865 139.74775200560651 18.77 35.67075708640021 139.74770097600342 18.77 35.67065240163113 139.7480321453526 18.77 35.67077647224673 139.7480910006726 18.77 35.670714596312436 139.74828691746814 18.77 35.670803411290244 139.74832902019511 18.77 35.67086528729187 139.74813310321474 18.77 35.670871508871606 139.74813607911182 18.77 35.67091575712888 139.74799585411435 18.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7b9660b5-dc02-42f0-822d-761f46bf1b99"/>
							<gml:surfaceMember xlink:href="#poly-bbc519ad-c698-444e-8a8f-5c86f10cf2fc"/>
							<gml:surfaceMember xlink:href="#poly-06a7000d-1b6f-454a-9d74-dbecab9aa1a0"/>
							<gml:surfaceMember xlink:href="#poly-5ff5249d-a83a-4203-b4b5-12bf1e8cc034"/>
							<gml:surfaceMember xlink:href="#poly-7b24542b-d828-4f67-b76c-56a26aa65289"/>
							<gml:surfaceMember xlink:href="#poly-9c72d70d-45d3-4dbb-a69d-02095b8ba542"/>
							<gml:surfaceMember xlink:href="#poly-32c06f64-8dae-4aa3-9a21-ebd439df9164"/>
							<gml:surfaceMember xlink:href="#poly-8ecb58ad-e798-423c-a95d-774df29297cb"/>
							<gml:surfaceMember xlink:href="#poly-75e2be85-0294-4e7d-af58-c8ecb980d8b6"/>
							<gml:surfaceMember xlink:href="#poly-85ead64b-11f9-4240-9c20-81826e9ad952"/>
							<gml:surfaceMember xlink:href="#poly-2d4254e5-5287-450d-9107-5f75fa42d84b"/>
							<gml:surfaceMember xlink:href="#poly-a035fe73-59c9-4b3a-87ca-9a6dbece3b6c"/>
							<gml:surfaceMember xlink:href="#poly-d9204220-65fa-4eaa-8772-901855849901"/>
							<gml:surfaceMember xlink:href="#poly-c12671e2-011e-479e-8c84-28254c34ea72"/>
							<gml:surfaceMember xlink:href="#poly-5bf282d8-7e52-4138-9e56-c55dfebb1a88"/>
							<gml:surfaceMember xlink:href="#poly-b20203af-4a2c-4e06-9123-a00f5d84f966"/>
							<gml:surfaceMember xlink:href="#poly-45da9972-f5e3-4542-827a-18a6cad3b70a"/>
							<gml:surfaceMember xlink:href="#poly-4d77b2c5-7014-462a-8b90-384f14d5ad7c"/>
							<gml:surfaceMember xlink:href="#poly-1d4d1d25-abde-4d1b-8e01-4304fbe890b9"/>
							<gml:surfaceMember xlink:href="#poly-e40cb9ae-887f-496f-bf60-f6834456f71f"/>
							<gml:surfaceMember xlink:href="#poly-d47c8a3d-8c50-4a6d-9cc6-08d1f96b263a"/>
							<gml:surfaceMember xlink:href="#poly-174f1ad4-a613-4426-b45f-ca5da4e5e1ee"/>
							<gml:surfaceMember xlink:href="#poly-b5f4d360-0629-4f74-ba85-7b2d0a5e4664"/>
							<gml:surfaceMember xlink:href="#poly-40bb7a93-da50-4cf1-9f4a-b81dd3ef0843"/>
							<gml:surfaceMember xlink:href="#poly-c69bbb61-5473-4f58-a2ab-ed7293542efe"/>
							<gml:surfaceMember xlink:href="#poly-38782808-cd3b-4c05-874b-ee4cb63af98a"/>
							<gml:surfaceMember xlink:href="#poly-04589554-30bd-418c-a8ee-5447cf9a4b71"/>
							<gml:surfaceMember xlink:href="#poly-5dfb3363-e207-4f16-abe2-27b2fa13675c"/>
							<gml:surfaceMember xlink:href="#poly-cb7aa5b5-f052-428a-a827-995a6e284e0a"/>
							<gml:surfaceMember xlink:href="#poly-1e5326e1-2a36-4754-b605-35ffa24acc77"/>
							<gml:surfaceMember xlink:href="#poly-c6c83050-502d-4b7c-a604-4f6818a8a3ad"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_06c7304c-bf62-472f-abc2-46cda06b0926_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88052efb-5456-4b7d-9ee8-65ffcf3c0ab8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078272092021 139.74778899880616 18.487 35.67077486692175 139.74778472121596 18.487 35.67078340421152 139.74776116136155 18.487 35.670791258202954 139.74776542790357 18.487 35.67078272092021 139.74778899880616 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3620d9c1-cc16-492b-b1bf-90aebe62fa29">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670799417684336 139.74778100554997 18.487 35.67080393301369 139.74776754631588 18.487 35.67081177777922 139.74777151461885 18.487 35.67080726244157 139.7477849628077 18.487 35.670799417684336 139.74778100554997 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fac6e49-9fc1-4b28-a287-f42308e7c565">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077435587426 139.7478139503093 18.487 35.670767502800146 139.74781023501143 18.487 35.670772279711294 139.74779702957053 18.487 35.670779123772064 139.7478007448771 18.487 35.67077435587426 139.7478139503093 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f1e724f-072d-49e3-b03d-2a3b22b88dea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67079634056282 139.74778885171884 18.487 35.67080448276485 139.74779279761356 18.487 35.670794427554604 139.7478239700024 18.487 35.670786285353586 139.74782002410504 18.487 35.67079634056282 139.74778885171884 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa7c11e9-8956-41f3-8232-709c84f37e2c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078637413901 139.7478435084784 18.487 35.67077958446777 139.7478402239161 18.487 35.67078537654424 139.74782224538384 18.487 35.67079216621595 139.74782552994483 18.487 35.67078637413901 139.7478435084784 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9892d5b-f123-4a53-8da0-50e0379f5976">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670757895699026 139.7478377837155 18.487 35.6707651003781 139.7478415980572 18.487 35.67075795783186 139.74786182042462 18.487 35.670750744139674 139.74785800609104 18.487 35.670757895699026 139.7478377837155 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c395804-adf4-48a3-87a8-d38ae1b88623">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077594753407 139.74787211850472 18.487 35.67076953629104 139.74786862365707 18.487 35.67077674218543 139.74784875470192 18.487 35.67078315342903 139.74785224954826 18.487 35.67077594753407 139.74787211850472 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4ebb2fc-a92b-48e8-af7d-bf6c125a9a42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4ebb2fc-a92b-48e8-af7d-bf6c125a9a42_0">
											<gml:posList>35.67079216621595 139.74782552994483 18.487 35.67078537654424 139.74782224538384 18.487 35.67078537654424 139.74782224538384 20.895 35.67079216621595 139.74782552994483 20.895 35.67079216621595 139.74782552994483 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90b4a798-8f28-4e29-a1e4-b9ec68e6aa52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90b4a798-8f28-4e29-a1e4-b9ec68e6aa52_0">
											<gml:posList>35.670757895699026 139.7478377837155 18.487 35.670750744139674 139.74785800609104 18.487 35.670750744139674 139.74785800609104 20.6 35.670757895699026 139.7478377837155 20.6 35.670757895699026 139.7478377837155 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af2209f7-9079-4c7e-9376-381b60dd75cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af2209f7-9079-4c7e-9376-381b60dd75cf_0">
											<gml:posList>35.67075795783186 139.74786182042462 20.6 35.6707651003781 139.7478415980572 20.6 35.670757895699026 139.7478377837155 20.6 35.670750744139674 139.74785800609104 20.6 35.67075795783186 139.74786182042462 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60f14e56-ccb2-4d48-b63e-413c62413f34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60f14e56-ccb2-4d48-b63e-413c62413f34_0">
											<gml:posList>35.670750744139674 139.74785800609104 18.487 35.67075795783186 139.74786182042462 18.487 35.67075795783186 139.74786182042462 20.6 35.670750744139674 139.74785800609104 20.6 35.670750744139674 139.74785800609104 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-371d3161-388c-493b-bad1-6b95840241ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-371d3161-388c-493b-bad1-6b95840241ab_0">
											<gml:posList>35.670791258202954 139.74776542790357 18.487 35.67078340421152 139.74776116136155 18.487 35.67078340421152 139.74776116136155 20.895 35.670791258202954 139.74776542790357 20.895 35.670791258202954 139.74776542790357 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3520a780-ed49-4f8d-ac51-8df6df4c2348">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3520a780-ed49-4f8d-ac51-8df6df4c2348_0">
											<gml:posList>35.67081177777922 139.74777151461885 18.487 35.67080393301369 139.74776754631588 18.487 35.67080393301369 139.74776754631588 20.895 35.67081177777922 139.74777151461885 20.895 35.67081177777922 139.74777151461885 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e575e666-a1b9-49d7-8936-e84cca7ae952">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e575e666-a1b9-49d7-8936-e84cca7ae952_0">
											<gml:posList>35.67078340421152 139.74776116136155 18.487 35.67077486692175 139.74778472121596 18.487 35.67077486692175 139.74778472121596 20.895 35.67078340421152 139.74776116136155 20.895 35.67078340421152 139.74776116136155 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c1332e2-57ec-4527-a92a-11ed6348a6d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c1332e2-57ec-4527-a92a-11ed6348a6d0_0">
											<gml:posList>35.67080393301369 139.74776754631588 18.487 35.670799417684336 139.74778100554997 18.487 35.670799417684336 139.74778100554997 20.895 35.67080393301369 139.74776754631588 20.895 35.67080393301369 139.74776754631588 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40986d78-85ba-4f22-b2a7-33c4d04c64fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40986d78-85ba-4f22-b2a7-33c4d04c64fd_0">
											<gml:posList>35.67078340421152 139.74776116136155 20.895 35.67077486692175 139.74778472121596 20.895 35.67078272092021 139.74778899880616 20.895 35.670791258202954 139.74776542790357 20.895 35.67078340421152 139.74776116136155 20.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbe8fa84-d115-4973-9551-00133a067af9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbe8fa84-d115-4973-9551-00133a067af9_0">
											<gml:posList>35.67081177777922 139.74777151461885 20.895 35.67080393301369 139.74776754631588 20.895 35.670799417684336 139.74778100554997 20.895 35.67080726244157 139.7477849628077 20.895 35.67081177777922 139.74777151461885 20.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd90ff4d-1dc7-4a6e-b42d-032a3125c443">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd90ff4d-1dc7-4a6e-b42d-032a3125c443_0">
											<gml:posList>35.67078272092021 139.74778899880616 18.487 35.670791258202954 139.74776542790357 18.487 35.670791258202954 139.74776542790357 20.895 35.67078272092021 139.74778899880616 20.895 35.67078272092021 139.74778899880616 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f98c909c-d65e-40e8-8c8c-c506f3dcc0f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f98c909c-d65e-40e8-8c8c-c506f3dcc0f4_0">
											<gml:posList>35.67080726244157 139.7477849628077 18.487 35.67081177777922 139.74777151461885 18.487 35.67081177777922 139.74777151461885 20.895 35.67080726244157 139.7477849628077 20.895 35.67080726244157 139.7477849628077 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d7bf124-5812-4292-ad98-3bacb9e627b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d7bf124-5812-4292-ad98-3bacb9e627b1_0">
											<gml:posList>35.670799417684336 139.74778100554997 18.487 35.67080726244157 139.7477849628077 18.487 35.67080726244157 139.7477849628077 20.895 35.670799417684336 139.74778100554997 20.895 35.670799417684336 139.74778100554997 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4a73788-e92b-4dce-94e8-24d71a30467b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4a73788-e92b-4dce-94e8-24d71a30467b_0">
											<gml:posList>35.67077486692175 139.74778472121596 18.487 35.67078272092021 139.74778899880616 18.487 35.67078272092021 139.74778899880616 20.895 35.67077486692175 139.74778472121596 20.895 35.67077486692175 139.74778472121596 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-105b2f39-aeb7-4bfa-8022-a895ffbfdfdc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-105b2f39-aeb7-4bfa-8022-a895ffbfdfdc_0">
											<gml:posList>35.67079634056282 139.74778885171884 18.487 35.67079634056282 139.74778885171884 20.895 35.67080448276485 139.74779279761356 20.895 35.67080448276485 139.74779279761356 18.487 35.67079634056282 139.74778885171884 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab3608e4-22ef-4d4a-a57d-a4c54074ad41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab3608e4-22ef-4d4a-a57d-a4c54074ad41_0">
											<gml:posList>35.670779123772064 139.7478007448771 18.487 35.670772279711294 139.74779702957053 18.487 35.670772279711294 139.74779702957053 20.895 35.670779123772064 139.7478007448771 20.895 35.670779123772064 139.7478007448771 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1070e7d9-619f-46d6-bb92-4c299d85c0a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1070e7d9-619f-46d6-bb92-4c299d85c0a3_0">
											<gml:posList>35.670772279711294 139.74779702957053 18.487 35.670767502800146 139.74781023501143 18.487 35.670767502800146 139.74781023501143 20.895 35.670772279711294 139.74779702957053 20.895 35.670772279711294 139.74779702957053 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7df2bca7-5ffa-463d-ab61-8dd7b3981560">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7df2bca7-5ffa-463d-ab61-8dd7b3981560_0">
											<gml:posList>35.670786285353586 139.74782002410504 18.487 35.670786285353586 139.74782002410504 20.895 35.67079634056282 139.74778885171884 20.895 35.67079634056282 139.74778885171884 18.487 35.670786285353586 139.74782002410504 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a879c08-2605-45d2-8ecf-7b1441f231c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a879c08-2605-45d2-8ecf-7b1441f231c3_0">
											<gml:posList>35.670772279711294 139.74779702957053 20.895 35.670767502800146 139.74781023501143 20.895 35.67077435587426 139.7478139503093 20.895 35.670779123772064 139.7478007448771 20.895 35.670772279711294 139.74779702957053 20.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb57dcd9-4f5b-46cb-a575-62799bac769c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb57dcd9-4f5b-46cb-a575-62799bac769c_0">
											<gml:posList>35.67079634056282 139.74778885171884 20.895 35.670786285353586 139.74782002410504 20.895 35.670794427554604 139.7478239700024 20.895 35.67080448276485 139.74779279761356 20.895 35.67079634056282 139.74778885171884 20.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9289a8f8-7fcc-4287-b000-cf62e86548d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9289a8f8-7fcc-4287-b000-cf62e86548d3_0">
											<gml:posList>35.67077435587426 139.7478139503093 18.487 35.670779123772064 139.7478007448771 18.487 35.670779123772064 139.7478007448771 20.895 35.67077435587426 139.7478139503093 20.895 35.67077435587426 139.7478139503093 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f2a2f1e-6a58-42ec-bad4-d465c50391cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f2a2f1e-6a58-42ec-bad4-d465c50391cc_0">
											<gml:posList>35.67080448276485 139.74779279761356 18.487 35.67080448276485 139.74779279761356 20.895 35.670794427554604 139.7478239700024 20.895 35.670794427554604 139.7478239700024 18.487 35.67080448276485 139.74779279761356 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2c06650-d910-459b-90b6-b117f9a51bd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2c06650-d910-459b-90b6-b117f9a51bd3_0">
											<gml:posList>35.670767502800146 139.74781023501143 18.487 35.67077435587426 139.7478139503093 18.487 35.67077435587426 139.7478139503093 20.895 35.670767502800146 139.74781023501143 20.895 35.670767502800146 139.74781023501143 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d500fc8-cd7b-4e5f-a3e3-b087feaa3bda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d500fc8-cd7b-4e5f-a3e3-b087feaa3bda_0">
											<gml:posList>35.670786285353586 139.74782002410504 18.487 35.670794427554604 139.7478239700024 18.487 35.670794427554604 139.7478239700024 20.895 35.670786285353586 139.74782002410504 20.895 35.670786285353586 139.74782002410504 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d84d583-31be-49b0-bb71-83fb2a05ccc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d84d583-31be-49b0-bb71-83fb2a05ccc2_0">
											<gml:posList>35.67077958446777 139.7478402239161 18.487 35.67077958446777 139.7478402239161 20.895 35.67078537654424 139.74782224538384 20.895 35.67078537654424 139.74782224538384 18.487 35.67077958446777 139.7478402239161 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60f9e0bb-40a2-4bc5-b42e-7c75a262d4bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60f9e0bb-40a2-4bc5-b42e-7c75a262d4bf_0">
											<gml:posList>35.67078537654424 139.74782224538384 20.895 35.67077958446777 139.7478402239161 20.895 35.67078637413901 139.7478435084784 20.895 35.67079216621595 139.74782552994483 20.895 35.67078537654424 139.74782224538384 20.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32835850-9678-472c-942c-45ec04402c58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32835850-9678-472c-942c-45ec04402c58_0">
											<gml:posList>35.67078637413901 139.7478435084784 18.487 35.67079216621595 139.74782552994483 18.487 35.67079216621595 139.74782552994483 20.895 35.67078637413901 139.7478435084784 20.895 35.67078637413901 139.7478435084784 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-186e8723-21e6-457b-9c94-dc45cee89100">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-186e8723-21e6-457b-9c94-dc45cee89100_0">
											<gml:posList>35.670757895699026 139.7478377837155 18.487 35.670757895699026 139.7478377837155 20.6 35.6707651003781 139.7478415980572 20.6 35.6707651003781 139.7478415980572 18.487 35.670757895699026 139.7478377837155 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a11b3afb-38c9-4690-b9b8-c16334418909">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a11b3afb-38c9-4690-b9b8-c16334418909_0">
											<gml:posList>35.67077958446777 139.7478402239161 18.487 35.67078637413901 139.7478435084784 18.487 35.67078637413901 139.7478435084784 20.895 35.67077958446777 139.7478402239161 20.895 35.67077958446777 139.7478402239161 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fb2c811-20de-48b1-a2a4-1c6e3d896e0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fb2c811-20de-48b1-a2a4-1c6e3d896e0a_0">
											<gml:posList>35.67078315342903 139.74785224954826 18.487 35.67077674218543 139.74784875470192 18.487 35.67077674218543 139.74784875470192 20.6 35.67078315342903 139.74785224954826 20.6 35.67078315342903 139.74785224954826 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b26a72cb-128c-4885-9435-5e8f8b415962">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b26a72cb-128c-4885-9435-5e8f8b415962_0">
											<gml:posList>35.67075795783186 139.74786182042462 18.487 35.6707651003781 139.7478415980572 18.487 35.6707651003781 139.7478415980572 20.6 35.67075795783186 139.74786182042462 20.6 35.67075795783186 139.74786182042462 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9086f074-57dc-4815-b700-0f6486989d45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9086f074-57dc-4815-b700-0f6486989d45_0">
											<gml:posList>35.67076953629104 139.74786862365707 18.487 35.67076953629104 139.74786862365707 20.6 35.67077674218543 139.74784875470192 20.6 35.67077674218543 139.74784875470192 18.487 35.67076953629104 139.74786862365707 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-115affe8-f65d-45ce-9742-700bdade74f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-115affe8-f65d-45ce-9742-700bdade74f6_0">
											<gml:posList>35.67077594753407 139.74787211850472 20.6 35.67078315342903 139.74785224954826 20.6 35.67077674218543 139.74784875470192 20.6 35.67076953629104 139.74786862365707 20.6 35.67077594753407 139.74787211850472 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0da81303-a069-4dfd-9b47-13680fa424cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0da81303-a069-4dfd-9b47-13680fa424cc_0">
											<gml:posList>35.67077594753407 139.74787211850472 18.487 35.67078315342903 139.74785224954826 18.487 35.67078315342903 139.74785224954826 20.6 35.67077594753407 139.74787211850472 20.6 35.67077594753407 139.74787211850472 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4f2d2d7-edb5-42fd-9061-c090b87a3cff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4f2d2d7-edb5-42fd-9061-c090b87a3cff_0">
											<gml:posList>35.67076953629104 139.74786862365707 18.487 35.67077594753407 139.74787211850472 18.487 35.67077594753407 139.74787211850472 20.6 35.67076953629104 139.74786862365707 20.6 35.67076953629104 139.74786862365707 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7b9660b5-dc02-42f0-822d-761f46bf1b99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b9660b5-dc02-42f0-822d-761f46bf1b99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b9660b5-dc02-42f0-822d-761f46bf1b99">
											<gml:posList>35.670804400128986 139.74794306077374 7.37 35.67091575712889 139.74799585411435 7.37 35.6708715088716 139.74813607911182 7.37 35.67086528729186 139.74813310321474 7.37 35.670803411290244 139.7483290201951 7.37 35.67071459631243 139.74828691746814 7.37 35.670776472246715 139.7480910006726 7.37 35.670652401631116 139.7480321453526 7.37 35.67075708640018 139.74770097600342 7.37 35.670864656486465 139.7477520056065 7.37 35.670804400128986 139.74794306077374 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbc519ad-c698-444e-8a8f-5c86f10cf2fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbc519ad-c698-444e-8a8f-5c86f10cf2fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbc519ad-c698-444e-8a8f-5c86f10cf2fc">
											<gml:posList>35.67071459631243 139.74828691746814 15 35.670720299823024 139.74828382949852 15 35.67077899201766 139.74809797926477 15 35.670776472246715 139.7480910006726 15 35.67071459631243 139.74828691746814 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06a7000d-1b6f-454a-9d74-dbecab9aa1a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06a7000d-1b6f-454a-9d74-dbecab9aa1a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06a7000d-1b6f-454a-9d74-dbecab9aa1a0">
											<gml:posList>35.670803411290244 139.7483290201951 15 35.67080088251895 139.74832204160307 15 35.670720299823024 139.74828382949852 15 35.67071459631243 139.74828691746814 15 35.670803411290244 139.7483290201951 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ff5249d-a83a-4203-b4b5-12bf1e8cc034">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ff5249d-a83a-4203-b4b5-12bf1e8cc034">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ff5249d-a83a-4203-b4b5-12bf1e8cc034">
											<gml:posList>35.67078058388894 139.74809295149896 15 35.670776472246715 139.7480910006726 15 35.67077899201766 139.74809797926477 15 35.67078058388894 139.74809295149896 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b24542b-d828-4f67-b76c-56a26aa65289">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b24542b-d828-4f67-b76c-56a26aa65289">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b24542b-d828-4f67-b76c-56a26aa65289">
											<gml:posList>35.67073125113466 139.74787591084583 18.487 35.67078548698697 139.74790164618545 18.487 35.67082874580159 139.7477647140694 18.487 35.67077450090678 139.74773897881826 18.487 35.67073125113466 139.74787591084583 18.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c72d70d-45d3-4dbb-a69d-02095b8ba542">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c72d70d-45d3-4dbb-a69d-02095b8ba542">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c72d70d-45d3-4dbb-a69d-02095b8ba542">
											<gml:posList>35.67078521697615 139.74795304498136 20.6 35.67085366504356 139.74774679242702 20.6 35.67082874580159 139.7477647140694 20.6 35.67078548698697 139.74790164618545 20.6 35.67073125113466 139.74787591084583 20.6 35.67077450090678 139.74773897881826 20.6 35.67075708640018 139.74770097600342 20.6 35.670652401631116 139.7480321453526 20.6 35.6708715088716 139.74813607911182 20.6 35.67090966850517 139.74801514749257 20.6 35.67078521697615 139.74795304498136 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32c06f64-8dae-4aa3-9a21-ebd439df9164">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32c06f64-8dae-4aa3-9a21-ebd439df9164">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32c06f64-8dae-4aa3-9a21-ebd439df9164">
											<gml:posList>35.67078058388894 139.74809295149896 14.393 35.67077899201766 139.74809797926477 14.393 35.670720299823024 139.74828382949852 14.393 35.67080088251895 139.74832204160307 14.393 35.67085959279901 139.7481361911911 14.393 35.67086118466404 139.74813115237467 14.393 35.67078058388894 139.74809295149896 14.393</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8ecb58ad-e798-423c-a95d-774df29297cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ecb58ad-e798-423c-a95d-774df29297cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ecb58ad-e798-423c-a95d-774df29297cb">
											<gml:posList>35.67077450090678 139.74773897881826 20.6 35.67082874580159 139.7477647140694 20.6 35.67085366504356 139.74774679242702 20.6 35.67075708640018 139.74770097600342 20.6 35.67077450090678 139.74773897881826 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-75e2be85-0294-4e7d-af58-c8ecb980d8b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75e2be85-0294-4e7d-af58-c8ecb980d8b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75e2be85-0294-4e7d-af58-c8ecb980d8b6">
											<gml:posList>35.67086528729186 139.74813310321474 15 35.67085959279901 139.7481361911911 15 35.67080088251895 139.74832204160307 15 35.670803411290244 139.7483290201951 15 35.67086528729186 139.74813310321474 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85ead64b-11f9-4240-9c20-81826e9ad952">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85ead64b-11f9-4240-9c20-81826e9ad952">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85ead64b-11f9-4240-9c20-81826e9ad952">
											<gml:posList>35.67078521697615 139.74795304498136 17.7 35.67090966850517 139.74801514749257 17.7 35.67091575712889 139.74799585411435 17.7 35.670804400128986 139.74794306077374 17.7 35.670864656486465 139.7477520056065 17.7 35.67085366504356 139.74774679242702 17.7 35.67078521697615 139.74795304498136 17.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d4254e5-5287-450d-9107-5f75fa42d84b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d4254e5-5287-450d-9107-5f75fa42d84b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d4254e5-5287-450d-9107-5f75fa42d84b">
											<gml:posList>35.67085959279901 139.7481361911911 15 35.67086528729186 139.74813310321474 15 35.67086118466404 139.74813115237467 15 35.67085959279901 139.7481361911911 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a035fe73-59c9-4b3a-87ca-9a6dbece3b6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a035fe73-59c9-4b3a-87ca-9a6dbece3b6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a035fe73-59c9-4b3a-87ca-9a6dbece3b6c">
											<gml:posList>35.67075708640018 139.74770097600342 20.6 35.67085366504356 139.74774679242702 20.6 35.67085366504356 139.74774679242702 17.7 35.670864656486465 139.7477520056065 17.7 35.670864656486465 139.7477520056065 7.37 35.67075708640018 139.74770097600342 7.37 35.67075708640018 139.74770097600342 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9204220-65fa-4eaa-8772-901855849901">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9204220-65fa-4eaa-8772-901855849901">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9204220-65fa-4eaa-8772-901855849901">
											<gml:posList>35.67077450090678 139.74773897881826 20.6 35.67077450090678 139.74773897881826 18.487 35.67082874580159 139.7477647140694 18.487 35.67082874580159 139.7477647140694 20.6 35.67077450090678 139.74773897881826 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c12671e2-011e-479e-8c84-28254c34ea72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c12671e2-011e-479e-8c84-28254c34ea72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c12671e2-011e-479e-8c84-28254c34ea72">
											<gml:posList>35.67073125113466 139.74787591084583 20.6 35.67073125113466 139.74787591084583 18.487 35.67077450090678 139.74773897881826 18.487 35.67077450090678 139.74773897881826 20.6 35.67073125113466 139.74787591084583 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5bf282d8-7e52-4138-9e56-c55dfebb1a88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bf282d8-7e52-4138-9e56-c55dfebb1a88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bf282d8-7e52-4138-9e56-c55dfebb1a88">
											<gml:posList>35.67082874580159 139.7477647140694 20.6 35.67082874580159 139.7477647140694 18.487 35.67078548698697 139.74790164618545 18.487 35.67078548698697 139.74790164618545 20.6 35.67082874580159 139.7477647140694 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b20203af-4a2c-4e06-9123-a00f5d84f966">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b20203af-4a2c-4e06-9123-a00f5d84f966">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b20203af-4a2c-4e06-9123-a00f5d84f966">
											<gml:posList>35.670804400128986 139.74794306077374 7.37 35.670864656486465 139.7477520056065 7.37 35.670864656486465 139.7477520056065 17.7 35.670804400128986 139.74794306077374 17.7 35.670804400128986 139.74794306077374 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45da9972-f5e3-4542-827a-18a6cad3b70a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45da9972-f5e3-4542-827a-18a6cad3b70a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45da9972-f5e3-4542-827a-18a6cad3b70a">
											<gml:posList>35.67085366504356 139.74774679242702 20.6 35.67078521697615 139.74795304498136 20.6 35.67078521697615 139.74795304498136 17.7 35.67085366504356 139.74774679242702 17.7 35.67085366504356 139.74774679242702 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d77b2c5-7014-462a-8b90-384f14d5ad7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d77b2c5-7014-462a-8b90-384f14d5ad7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d77b2c5-7014-462a-8b90-384f14d5ad7c">
											<gml:posList>35.67075708640018 139.74770097600342 7.37 35.670652401631116 139.7480321453526 7.37 35.670652401631116 139.7480321453526 20.6 35.67075708640018 139.74770097600342 20.6 35.67075708640018 139.74770097600342 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d4d1d25-abde-4d1b-8e01-4304fbe890b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d4d1d25-abde-4d1b-8e01-4304fbe890b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d4d1d25-abde-4d1b-8e01-4304fbe890b9">
											<gml:posList>35.67078548698697 139.74790164618545 20.6 35.67078548698697 139.74790164618545 18.487 35.67073125113466 139.74787591084583 18.487 35.67073125113466 139.74787591084583 20.6 35.67078548698697 139.74790164618545 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e40cb9ae-887f-496f-bf60-f6834456f71f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e40cb9ae-887f-496f-bf60-f6834456f71f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e40cb9ae-887f-496f-bf60-f6834456f71f">
											<gml:posList>35.67091575712889 139.74799585411435 7.37 35.670804400128986 139.74794306077374 7.37 35.670804400128986 139.74794306077374 17.7 35.67091575712889 139.74799585411435 17.7 35.67091575712889 139.74799585411435 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d47c8a3d-8c50-4a6d-9cc6-08d1f96b263a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d47c8a3d-8c50-4a6d-9cc6-08d1f96b263a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d47c8a3d-8c50-4a6d-9cc6-08d1f96b263a">
											<gml:posList>35.67078521697615 139.74795304498136 20.6 35.67090966850517 139.74801514749257 20.6 35.67090966850517 139.74801514749257 17.7 35.67078521697615 139.74795304498136 17.7 35.67078521697615 139.74795304498136 20.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-174f1ad4-a613-4426-b45f-ca5da4e5e1ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-174f1ad4-a613-4426-b45f-ca5da4e5e1ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-174f1ad4-a613-4426-b45f-ca5da4e5e1ee">
											<gml:posList>35.67090966850517 139.74801514749257 17.7 35.67090966850517 139.74801514749257 20.6 35.6708715088716 139.74813607911182 20.6 35.6708715088716 139.74813607911182 7.37 35.67091575712889 139.74799585411435 7.37 35.67091575712889 139.74799585411435 17.7 35.67090966850517 139.74801514749257 17.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5f4d360-0629-4f74-ba85-7b2d0a5e4664">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5f4d360-0629-4f74-ba85-7b2d0a5e4664">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5f4d360-0629-4f74-ba85-7b2d0a5e4664">
											<gml:posList>35.67086528729186 139.74813310321474 15 35.67086528729186 139.74813310321474 7.37 35.6708715088716 139.74813607911182 7.37 35.6708715088716 139.74813607911182 20.6 35.670652401631116 139.7480321453526 20.6 35.670652401631116 139.7480321453526 7.37 35.670776472246715 139.7480910006726 7.37 35.670776472246715 139.7480910006726 15 35.67078058388894 139.74809295149896 15 35.67078058388894 139.74809295149896 14.393 35.67086118466404 139.74813115237467 14.393 35.67086118466404 139.74813115237467 15 35.67086528729186 139.74813310321474 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40bb7a93-da50-4cf1-9f4a-b81dd3ef0843">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40bb7a93-da50-4cf1-9f4a-b81dd3ef0843">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40bb7a93-da50-4cf1-9f4a-b81dd3ef0843">
											<gml:posList>35.670776472246715 139.7480910006726 7.37 35.67071459631243 139.74828691746814 7.37 35.67071459631243 139.74828691746814 15 35.670776472246715 139.7480910006726 15 35.670776472246715 139.7480910006726 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c69bbb61-5473-4f58-a2ab-ed7293542efe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c69bbb61-5473-4f58-a2ab-ed7293542efe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c69bbb61-5473-4f58-a2ab-ed7293542efe">
											<gml:posList>35.670720299823024 139.74828382949852 15 35.670720299823024 139.74828382949852 14.393 35.67077899201766 139.74809797926477 14.393 35.67077899201766 139.74809797926477 15 35.670720299823024 139.74828382949852 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38782808-cd3b-4c05-874b-ee4cb63af98a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38782808-cd3b-4c05-874b-ee4cb63af98a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38782808-cd3b-4c05-874b-ee4cb63af98a">
											<gml:posList>35.67071459631243 139.74828691746814 7.37 35.670803411290244 139.7483290201951 7.37 35.670803411290244 139.7483290201951 15 35.67071459631243 139.74828691746814 15 35.67071459631243 139.74828691746814 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04589554-30bd-418c-a8ee-5447cf9a4b71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04589554-30bd-418c-a8ee-5447cf9a4b71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04589554-30bd-418c-a8ee-5447cf9a4b71">
											<gml:posList>35.67080088251895 139.74832204160307 15 35.67080088251895 139.74832204160307 14.393 35.670720299823024 139.74828382949852 14.393 35.670720299823024 139.74828382949852 15 35.67080088251895 139.74832204160307 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5dfb3363-e207-4f16-abe2-27b2fa13675c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dfb3363-e207-4f16-abe2-27b2fa13675c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dfb3363-e207-4f16-abe2-27b2fa13675c">
											<gml:posList>35.67077899201766 139.74809797926477 15 35.67077899201766 139.74809797926477 14.393 35.67078058388894 139.74809295149896 14.393 35.67078058388894 139.74809295149896 15 35.67077899201766 139.74809797926477 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb7aa5b5-f052-428a-a827-995a6e284e0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb7aa5b5-f052-428a-a827-995a6e284e0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb7aa5b5-f052-428a-a827-995a6e284e0a">
											<gml:posList>35.67085959279901 139.7481361911911 15 35.67085959279901 139.7481361911911 14.393 35.67080088251895 139.74832204160307 14.393 35.67080088251895 139.74832204160307 15 35.67085959279901 139.7481361911911 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e5326e1-2a36-4754-b605-35ffa24acc77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e5326e1-2a36-4754-b605-35ffa24acc77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e5326e1-2a36-4754-b605-35ffa24acc77">
											<gml:posList>35.670803411290244 139.7483290201951 7.37 35.67086528729186 139.74813310321474 7.37 35.67086528729186 139.74813310321474 15 35.670803411290244 139.7483290201951 15 35.670803411290244 139.7483290201951 7.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6c83050-502d-4b7c-a604-4f6818a8a3ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6c83050-502d-4b7c-a604-4f6818a8a3ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6c83050-502d-4b7c-a604-4f6818a8a3ad">
											<gml:posList>35.67086118466404 139.74813115237467 15 35.67086118466404 139.74813115237467 14.393 35.67085959279901 139.7481361911911 14.393 35.67085959279901 139.7481361911911 15 35.67086118466404 139.74813115237467 15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-1743</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">792.99785</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>