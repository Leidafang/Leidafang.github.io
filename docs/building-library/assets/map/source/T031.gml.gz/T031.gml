<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_07d911b9-2f05-406f-914e-5a5c82ce8177">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">12.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66910488637943 139.73892220836893 0 35.669161426023386 139.7388373078133 0 35.66911280476661 139.73878986695084 0 35.669056264808994 139.7388743256456 0 35.66910488637943 139.73892220836893 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910488637943 139.73892220836893 14.81 35.669056264808994 139.7388743256456 14.81 35.66911280476661 139.73878986695084 14.81 35.669161426023386 139.7388373078133 14.81 35.66910488637943 139.73892220836893 14.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910488637943 139.73892220836893 14.81 35.669161426023386 139.7388373078133 14.81 35.669161426023386 139.7388373078133 27.05 35.66910488637943 139.73892220836893 27.05 35.66910488637943 139.73892220836893 14.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669161426023386 139.7388373078133 14.81 35.66911280476661 139.73878986695084 14.81 35.66911280476661 139.73878986695084 27.05 35.669161426023386 139.7388373078133 27.05 35.669161426023386 139.7388373078133 14.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911280476661 139.73878986695084 14.81 35.669056264808994 139.7388743256456 14.81 35.669056264808994 139.7388743256456 27.05 35.66911280476661 139.73878986695084 27.05 35.66911280476661 139.73878986695084 14.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669056264808994 139.7388743256456 14.81 35.66910488637943 139.73892220836893 14.81 35.66910488637943 139.73892220836893 27.05 35.669056264808994 139.7388743256456 27.05 35.669056264808994 139.7388743256456 14.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910488637943 139.73892220836893 27.05 35.669161426023386 139.7388373078133 27.05 35.66911280476661 139.73878986695084 27.05 35.669056264808994 139.7388743256456 27.05 35.66910488637943 139.73892220836893 27.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-857940f6-7310-4cc5-a6cf-296cd42d4b39"/>
							<gml:surfaceMember xlink:href="#poly-5a1ef18e-e6fd-4839-865c-1f65572b3011"/>
							<gml:surfaceMember xlink:href="#poly-276679f9-978a-4230-b330-e2e4c8bc2c6f"/>
							<gml:surfaceMember xlink:href="#poly-7e3118ed-105c-40e8-912a-dcc43ab8ba5a"/>
							<gml:surfaceMember xlink:href="#poly-8ff95ef7-c7bb-47b9-85ff-85aebc714f75"/>
							<gml:surfaceMember xlink:href="#poly-6af637bc-88d1-4b69-97c7-257931356339"/>
							<gml:surfaceMember xlink:href="#poly-1629b7cd-bf04-4501-bf0f-659743bb43a8"/>
							<gml:surfaceMember xlink:href="#poly-6a1f1632-8c2f-437d-b7da-68963670ca12"/>
							<gml:surfaceMember xlink:href="#poly-13a614b9-583c-4a82-89a1-d0dedb6ebb34"/>
							<gml:surfaceMember xlink:href="#poly-5dba6aa9-24d8-444b-8ab0-7dc952f156e6"/>
							<gml:surfaceMember xlink:href="#poly-8ba0f122-dd13-4ccb-8a6a-4afc90659461"/>
							<gml:surfaceMember xlink:href="#poly-847f7ffd-409e-450d-bf34-e43a09c3da0d"/>
							<gml:surfaceMember xlink:href="#poly-4ba95cd4-5346-4660-ae46-f1f486bf8c59"/>
							<gml:surfaceMember xlink:href="#poly-77ba5694-4584-4622-b201-6948432318fa"/>
							<gml:surfaceMember xlink:href="#poly-72a78ae8-8e96-4196-afad-0ceb35d1a419"/>
							<gml:surfaceMember xlink:href="#poly-22392879-ef18-4ae9-ae2e-b31f77669c92"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-857940f6-7310-4cc5-a6cf-296cd42d4b39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-857940f6-7310-4cc5-a6cf-296cd42d4b39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-857940f6-7310-4cc5-a6cf-296cd42d4b39">
											<gml:posList>35.66910488637943 139.7389222083689 14.81 35.66905626480901 139.7388743256456 14.81 35.669112804766606 139.73878986695084 14.81 35.669161426023386 139.7388373078133 14.81 35.66910488637943 139.7389222083689 14.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a1ef18e-e6fd-4839-865c-1f65572b3011">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a1ef18e-e6fd-4839-865c-1f65572b3011">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a1ef18e-e6fd-4839-865c-1f65572b3011">
											<gml:posList>35.669112804766606 139.73878986695084 27.263 35.66911307765871 139.7387930258093 27.263 35.66914571434598 139.73882487738746 27.263 35.66914831001243 139.73882450980702 27.263 35.669112804766606 139.73878986695084 27.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-276679f9-978a-4230-b330-e2e4c8bc2c6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-276679f9-978a-4230-b330-e2e4c8bc2c6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-276679f9-978a-4230-b330-e2e4c8bc2c6f">
											<gml:posList>35.66905626480901 139.7388743256456 27.263 35.66905889655655 139.7388739911629 27.263 35.66911307765871 139.7387930258093 27.263 35.669112804766606 139.73878986695084 27.263 35.66905626480901 139.7388743256456 27.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e3118ed-105c-40e8-912a-dcc43ab8ba5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e3118ed-105c-40e8-912a-dcc43ab8ba5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e3118ed-105c-40e8-912a-dcc43ab8ba5a">
											<gml:posList>35.66914571434598 139.73882487738746 26.911 35.66911307765871 139.7387930258093 26.911 35.66905889655655 139.7388739911629 26.911 35.66909238138768 139.73890695740803 26.911 35.66914571434598 139.73882487738746 26.911</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8ff95ef7-c7bb-47b9-85ff-85aebc714f75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ff95ef7-c7bb-47b9-85ff-85aebc714f75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ff95ef7-c7bb-47b9-85ff-85aebc714f75">
											<gml:posList>35.669161426023386 139.7388373078133 24.196 35.66914831001243 139.73882450980702 27.263 35.669092654311356 139.73891016045036 27.263 35.669161426023386 139.7388373078133 24.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6af637bc-88d1-4b69-97c7-257931356339">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6af637bc-88d1-4b69-97c7-257931356339">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6af637bc-88d1-4b69-97c7-257931356339">
											<gml:posList>35.66914831001243 139.73882450980702 27.263 35.66914571434598 139.73882487738746 27.263 35.66909238138768 139.73890695740803 27.263 35.669092654311356 139.73891016045036 27.263 35.66914831001243 139.73882450980702 27.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1629b7cd-bf04-4501-bf0f-659743bb43a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1629b7cd-bf04-4501-bf0f-659743bb43a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1629b7cd-bf04-4501-bf0f-659743bb43a8">
											<gml:posList>35.669092654311356 139.73891016045036 27.263 35.66910488637943 139.7389222083689 24.196 35.669161426023386 139.7388373078133 24.196 35.669092654311356 139.73891016045036 27.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a1f1632-8c2f-437d-b7da-68963670ca12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a1f1632-8c2f-437d-b7da-68963670ca12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a1f1632-8c2f-437d-b7da-68963670ca12">
											<gml:posList>35.669092654311356 139.73891016045036 27.263 35.66909238138768 139.73890695740803 27.263 35.66905889655655 139.7388739911629 27.263 35.66905626480901 139.7388743256456 27.263 35.669092654311356 139.73891016045036 27.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13a614b9-583c-4a82-89a1-d0dedb6ebb34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13a614b9-583c-4a82-89a1-d0dedb6ebb34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13a614b9-583c-4a82-89a1-d0dedb6ebb34">
											<gml:posList>35.66914571434598 139.73882487738746 27.263 35.66914571434598 139.73882487738746 26.911 35.66909238138768 139.73890695740803 26.911 35.66909238138768 139.73890695740803 27.263 35.66914571434598 139.73882487738746 27.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5dba6aa9-24d8-444b-8ab0-7dc952f156e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dba6aa9-24d8-444b-8ab0-7dc952f156e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dba6aa9-24d8-444b-8ab0-7dc952f156e6">
											<gml:posList>35.66911307765871 139.7387930258093 27.263 35.66911307765871 139.7387930258093 26.911 35.66914571434598 139.73882487738746 26.911 35.66914571434598 139.73882487738746 27.263 35.66911307765871 139.7387930258093 27.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ba0f122-dd13-4ccb-8a6a-4afc90659461">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ba0f122-dd13-4ccb-8a6a-4afc90659461">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ba0f122-dd13-4ccb-8a6a-4afc90659461">
											<gml:posList>35.669161426023386 139.7388373078133 24.196 35.669161426023386 139.7388373078133 14.81 35.669112804766606 139.73878986695084 14.81 35.669112804766606 139.73878986695084 27.263 35.66914831001243 139.73882450980702 27.263 35.669161426023386 139.7388373078133 24.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-847f7ffd-409e-450d-bf34-e43a09c3da0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-847f7ffd-409e-450d-bf34-e43a09c3da0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-847f7ffd-409e-450d-bf34-e43a09c3da0d">
											<gml:posList>35.669112804766606 139.73878986695084 14.81 35.66905626480901 139.7388743256456 14.81 35.66905626480901 139.7388743256456 27.263 35.669112804766606 139.73878986695084 27.263 35.669112804766606 139.73878986695084 14.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ba95cd4-5346-4660-ae46-f1f486bf8c59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ba95cd4-5346-4660-ae46-f1f486bf8c59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ba95cd4-5346-4660-ae46-f1f486bf8c59">
											<gml:posList>35.66905889655655 139.7388739911629 27.263 35.66905889655655 139.7388739911629 26.911 35.66911307765871 139.7387930258093 26.911 35.66911307765871 139.7387930258093 27.263 35.66905889655655 139.7388739911629 27.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77ba5694-4584-4622-b201-6948432318fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77ba5694-4584-4622-b201-6948432318fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77ba5694-4584-4622-b201-6948432318fa">
											<gml:posList>35.66910488637943 139.7389222083689 14.81 35.669161426023386 139.7388373078133 14.81 35.669161426023386 139.7388373078133 24.196 35.66910488637943 139.7389222083689 24.196 35.66910488637943 139.7389222083689 14.81</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72a78ae8-8e96-4196-afad-0ceb35d1a419">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72a78ae8-8e96-4196-afad-0ceb35d1a419">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72a78ae8-8e96-4196-afad-0ceb35d1a419">
											<gml:posList>35.66909238138768 139.73890695740803 27.263 35.66909238138768 139.73890695740803 26.911 35.66905889655655 139.7388739911629 26.911 35.66905889655655 139.7388739911629 27.263 35.66909238138768 139.73890695740803 27.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22392879-ef18-4ae9-ae2e-b31f77669c92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22392879-ef18-4ae9-ae2e-b31f77669c92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22392879-ef18-4ae9-ae2e-b31f77669c92">
											<gml:posList>35.66910488637943 139.7389222083689 24.196 35.669092654311356 139.73891016045036 27.263 35.66905626480901 139.7388743256456 27.263 35.66905626480901 139.7388743256456 14.81 35.66910488637943 139.7389222083689 14.81 35.66910488637943 139.7389222083689 24.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3656</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">68.417</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>