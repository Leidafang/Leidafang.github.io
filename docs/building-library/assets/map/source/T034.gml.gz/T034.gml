<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_08cc3abd-f00c-42ef-8975-7cc3e6d86d19">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">13.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668702339910745 139.73950756954213 0 35.66857830998797 139.73939073741806 0 35.668525465057556 139.73947496988046 0 35.66864949498579 139.73959191251828 0 35.668702339910745 139.73950756954213 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668702339910745 139.73950756954213 11.456 35.66864949498579 139.73959191251828 11.456 35.668525465057556 139.73947496988046 11.456 35.66857830998797 139.73939073741806 11.456 35.668702339910745 139.73950756954213 11.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668702339910745 139.73950756954213 11.456 35.66857830998797 139.73939073741806 11.456 35.66857830998797 139.73939073741806 24.58 35.668702339910745 139.73950756954213 24.58 35.668702339910745 139.73950756954213 11.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857830998797 139.73939073741806 11.456 35.668525465057556 139.73947496988046 11.456 35.668525465057556 139.73947496988046 24.58 35.66857830998797 139.73939073741806 24.58 35.66857830998797 139.73939073741806 11.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668525465057556 139.73947496988046 11.456 35.66864949498579 139.73959191251828 11.456 35.66864949498579 139.73959191251828 24.58 35.668525465057556 139.73947496988046 24.58 35.668525465057556 139.73947496988046 11.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66864949498579 139.73959191251828 11.456 35.668702339910745 139.73950756954213 11.456 35.668702339910745 139.73950756954213 24.58 35.66864949498579 139.73959191251828 24.58 35.66864949498579 139.73959191251828 11.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668702339910745 139.73950756954213 24.58 35.66857830998797 139.73939073741806 24.58 35.668525465057556 139.73947496988046 24.58 35.66864949498579 139.73959191251828 24.58 35.668702339910745 139.73950756954213 24.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8f021c36-c5a4-4abf-8c10-a66db047428c"/>
							<gml:surfaceMember xlink:href="#poly-b6f7e1fb-e2b7-406a-b654-e0eff03c6d0b"/>
							<gml:surfaceMember xlink:href="#poly-51bd09ca-aade-4755-a4d0-464c24f7a4bc"/>
							<gml:surfaceMember xlink:href="#poly-06807286-ee50-4cae-a77f-d7d2b40b0db4"/>
							<gml:surfaceMember xlink:href="#poly-77b026e4-0453-4bd4-a6c4-376b1a5da082"/>
							<gml:surfaceMember xlink:href="#poly-8a32c405-d752-4b34-9b7c-fee66ef77114"/>
							<gml:surfaceMember xlink:href="#poly-aa971b94-5f9d-430e-bc76-9da43b81f46a"/>
							<gml:surfaceMember xlink:href="#poly-091105be-b4cc-4ffe-8025-04f20a2a529e"/>
							<gml:surfaceMember xlink:href="#poly-4b074331-066c-4f8e-b961-81c473adfa02"/>
							<gml:surfaceMember xlink:href="#poly-52bf0eee-b2f2-4d15-8e9a-ce26c7237178"/>
							<gml:surfaceMember xlink:href="#poly-fe130e6b-4ec3-44ea-8c2e-854cb7546b63"/>
							<gml:surfaceMember xlink:href="#poly-697c4178-7fcc-43a7-a86a-6175d0ea3ad5"/>
							<gml:surfaceMember xlink:href="#poly-97007341-5028-4d96-81d6-9487fc38c091"/>
							<gml:surfaceMember xlink:href="#poly-06ec4154-b5f1-4025-a8f5-3d2af7c53501"/>
							<gml:surfaceMember xlink:href="#poly-97bb615f-898d-41d8-8949-c2090475421d"/>
							<gml:surfaceMember xlink:href="#poly-8b20b32b-2074-4df1-94a9-3a982c8ce4e9"/>
							<gml:surfaceMember xlink:href="#poly-76f3a58c-d655-4b09-9f82-9c59027fcb1d"/>
							<gml:surfaceMember xlink:href="#poly-68997965-7e33-42e0-ab9e-d5a47f3c025f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8f021c36-c5a4-4abf-8c10-a66db047428c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f021c36-c5a4-4abf-8c10-a66db047428c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f021c36-c5a4-4abf-8c10-a66db047428c">
											<gml:posList>35.66870233991073 139.73950756954213 11.456 35.66864949498576 139.73959191251828 11.456 35.66852546505755 139.73947496988043 11.456 35.668578309987964 139.73939073741806 11.456 35.66870233991073 139.73950756954213 11.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6f7e1fb-e2b7-406a-b654-e0eff03c6d0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6f7e1fb-e2b7-406a-b654-e0eff03c6d0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6f7e1fb-e2b7-406a-b654-e0eff03c6d0b">
											<gml:posList>35.668578309987964 139.73939073741806 18.928 35.66852546505755 139.73947496988043 18.928 35.668565578602056 139.73951278864547 28.433 35.66861847765813 139.73942857819443 28.433 35.668578309987964 139.73939073741806 18.928</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51bd09ca-aade-4755-a4d0-464c24f7a4bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51bd09ca-aade-4755-a4d0-464c24f7a4bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51bd09ca-aade-4755-a4d0-464c24f7a4bc">
											<gml:posList>35.6686181492504 139.73956235688604 28.433 35.668617786051975 139.73955895513765 28.433 35.66856834546283 139.7395123325216 28.433 35.668565578602056 139.73951278864547 28.433 35.6686181492504 139.73956235688604 28.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06807286-ee50-4cae-a77f-d7d2b40b0db4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06807286-ee50-4cae-a77f-d7d2b40b0db4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06807286-ee50-4cae-a77f-d7d2b40b0db4">
											<gml:posList>35.668565578602056 139.73951278864547 28.433 35.66856834546283 139.7395123325216 28.433 35.66861883182928 139.73943195786075 28.433 35.66861847765813 139.73942857819443 28.433 35.668565578602056 139.73951278864547 28.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77b026e4-0453-4bd4-a6c4-376b1a5da082">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77b026e4-0453-4bd4-a6c4-376b1a5da082">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77b026e4-0453-4bd4-a6c4-376b1a5da082">
											<gml:posList>35.66866831750912 139.7394785693577 27.895 35.66861883182928 139.73943195786075 27.895 35.66856834546283 139.7395123325216 27.895 35.668617786051975 139.73955895513765 27.895 35.66866831750912 139.7394785693577 27.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a32c405-d752-4b34-9b7c-fee66ef77114">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a32c405-d752-4b34-9b7c-fee66ef77114">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a32c405-d752-4b34-9b7c-fee66ef77114">
											<gml:posList>35.668671093400654 139.73947813531356 28.433 35.66866831750912 139.7394785693577 28.433 35.668617786051975 139.73955895513765 28.433 35.6686181492504 139.73956235688604 28.433 35.668671093400654 139.73947813531356 28.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa971b94-5f9d-430e-bc76-9da43b81f46a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa971b94-5f9d-430e-bc76-9da43b81f46a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa971b94-5f9d-430e-bc76-9da43b81f46a">
											<gml:posList>35.66861847765813 139.73942857819443 28.433 35.66861883182928 139.73943195786075 28.433 35.66866831750912 139.7394785693577 28.433 35.668671093400654 139.73947813531356 28.433 35.66861847765813 139.73942857819443 28.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-091105be-b4cc-4ffe-8025-04f20a2a529e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-091105be-b4cc-4ffe-8025-04f20a2a529e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-091105be-b4cc-4ffe-8025-04f20a2a529e">
											<gml:posList>35.668671093400654 139.73947813531356 24.646 35.6686181492504 139.73956235688604 24.646 35.668633817607834 139.73957712918153 24.646 35.6686867166566 139.73949285242497 24.646 35.668671093400654 139.73947813531356 24.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b074331-066c-4f8e-b961-81c473adfa02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b074331-066c-4f8e-b961-81c473adfa02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b074331-066c-4f8e-b961-81c473adfa02">
											<gml:posList>35.66864949498576 139.73959191251828 18.928 35.66870233991073 139.73950756954213 18.928 35.6686867166566 139.73949285242497 24.646 35.668633817607834 139.73957712918153 24.646 35.66864949498576 139.73959191251828 18.928</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52bf0eee-b2f2-4d15-8e9a-ce26c7237178">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52bf0eee-b2f2-4d15-8e9a-ce26c7237178">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52bf0eee-b2f2-4d15-8e9a-ce26c7237178">
											<gml:posList>35.66861883182928 139.73943195786075 28.433 35.66861883182928 139.73943195786075 27.895 35.66866831750912 139.7394785693577 27.895 35.66866831750912 139.7394785693577 28.433 35.66861883182928 139.73943195786075 28.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe130e6b-4ec3-44ea-8c2e-854cb7546b63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe130e6b-4ec3-44ea-8c2e-854cb7546b63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe130e6b-4ec3-44ea-8c2e-854cb7546b63">
											<gml:posList>35.66856834546283 139.7395123325216 28.433 35.66856834546283 139.7395123325216 27.895 35.66861883182928 139.73943195786075 27.895 35.66861883182928 139.73943195786075 28.433 35.66856834546283 139.7395123325216 28.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-697c4178-7fcc-43a7-a86a-6175d0ea3ad5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-697c4178-7fcc-43a7-a86a-6175d0ea3ad5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-697c4178-7fcc-43a7-a86a-6175d0ea3ad5">
											<gml:posList>35.668578309987964 139.73939073741806 11.456 35.66852546505755 139.73947496988043 11.456 35.66852546505755 139.73947496988043 18.928 35.668578309987964 139.73939073741806 18.928 35.668578309987964 139.73939073741806 11.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97007341-5028-4d96-81d6-9487fc38c091">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97007341-5028-4d96-81d6-9487fc38c091">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97007341-5028-4d96-81d6-9487fc38c091">
											<gml:posList>35.66861847765813 139.73942857819443 28.433 35.668671093400654 139.73947813531356 28.433 35.668671093400654 139.73947813531356 24.646 35.6686867166566 139.73949285242497 24.646 35.66870233991073 139.73950756954213 18.928 35.66870233991073 139.73950756954213 11.456 35.668578309987964 139.73939073741806 11.456 35.668578309987964 139.73939073741806 18.928 35.66861847765813 139.73942857819443 28.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06ec4154-b5f1-4025-a8f5-3d2af7c53501">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06ec4154-b5f1-4025-a8f5-3d2af7c53501">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06ec4154-b5f1-4025-a8f5-3d2af7c53501">
											<gml:posList>35.66866831750912 139.7394785693577 28.433 35.66866831750912 139.7394785693577 27.895 35.668617786051975 139.73955895513765 27.895 35.668617786051975 139.73955895513765 28.433 35.66866831750912 139.7394785693577 28.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97bb615f-898d-41d8-8949-c2090475421d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97bb615f-898d-41d8-8949-c2090475421d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97bb615f-898d-41d8-8949-c2090475421d">
											<gml:posList>35.668671093400654 139.73947813531356 24.646 35.668671093400654 139.73947813531356 28.433 35.6686181492504 139.73956235688604 28.433 35.6686181492504 139.73956235688604 24.646 35.668671093400654 139.73947813531356 24.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b20b32b-2074-4df1-94a9-3a982c8ce4e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b20b32b-2074-4df1-94a9-3a982c8ce4e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b20b32b-2074-4df1-94a9-3a982c8ce4e9">
											<gml:posList>35.66852546505755 139.73947496988043 11.456 35.66864949498576 139.73959191251828 11.456 35.66864949498576 139.73959191251828 18.928 35.668633817607834 139.73957712918153 24.646 35.6686181492504 139.73956235688604 24.646 35.6686181492504 139.73956235688604 28.433 35.668565578602056 139.73951278864547 28.433 35.66852546505755 139.73947496988043 18.928 35.66852546505755 139.73947496988043 11.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76f3a58c-d655-4b09-9f82-9c59027fcb1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76f3a58c-d655-4b09-9f82-9c59027fcb1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76f3a58c-d655-4b09-9f82-9c59027fcb1d">
											<gml:posList>35.668617786051975 139.73955895513765 28.433 35.668617786051975 139.73955895513765 27.895 35.66856834546283 139.7395123325216 27.895 35.66856834546283 139.7395123325216 28.433 35.668617786051975 139.73955895513765 28.433</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68997965-7e33-42e0-ab9e-d5a47f3c025f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68997965-7e33-42e0-ab9e-d5a47f3c025f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68997965-7e33-42e0-ab9e-d5a47f3c025f">
											<gml:posList>35.66864949498576 139.73959191251828 11.456 35.66870233991073 139.73950756954213 11.456 35.66870233991073 139.73950756954213 18.928 35.66864949498576 139.73959191251828 18.928 35.66864949498576 139.73959191251828 11.456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4838</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">167.0364</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>