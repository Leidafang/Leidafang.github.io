<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0917bb1c-ec48-4b72-9457-35e4af54491d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">10.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672127051332296 139.7398069538915 0 35.67219740635183 139.73988030901444 0 35.67224019174432 139.73981868586313 0 35.672169836679195 139.73974531970885 0 35.672127051332296 139.7398069538915 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672127051332296 139.7398069538915 7.99 35.672169836679195 139.73974531970885 7.99 35.67224019174432 139.73981868586313 7.99 35.67219740635183 139.73988030901444 7.99 35.672127051332296 139.7398069538915 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672127051332296 139.7398069538915 7.99 35.67219740635183 139.73988030901444 7.99 35.67219740635183 139.73988030901444 18.85 35.672127051332296 139.7398069538915 18.85 35.672127051332296 139.7398069538915 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67219740635183 139.73988030901444 7.99 35.67224019174432 139.73981868586313 7.99 35.67224019174432 139.73981868586313 18.85 35.67219740635183 139.73988030901444 18.85 35.67219740635183 139.73988030901444 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67224019174432 139.73981868586313 7.99 35.672169836679195 139.73974531970885 7.99 35.672169836679195 139.73974531970885 18.85 35.67224019174432 139.73981868586313 18.85 35.67224019174432 139.73981868586313 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672169836679195 139.73974531970885 7.99 35.672127051332296 139.7398069538915 7.99 35.672127051332296 139.7398069538915 18.85 35.672169836679195 139.73974531970885 18.85 35.672169836679195 139.73974531970885 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672127051332296 139.7398069538915 18.85 35.67219740635183 139.73988030901444 18.85 35.67224019174432 139.73981868586313 18.85 35.672169836679195 139.73974531970885 18.85 35.672127051332296 139.7398069538915 18.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0e727d82-c948-4838-8c0b-d99fd1beab96"/>
							<gml:surfaceMember xlink:href="#poly-8697370b-e3ef-4f02-944d-949d7c6c461d"/>
							<gml:surfaceMember xlink:href="#poly-ac656890-d0aa-4be4-b6ea-a20d5509daf6"/>
							<gml:surfaceMember xlink:href="#poly-9301cf69-312a-4b55-8769-f3aa97606098"/>
							<gml:surfaceMember xlink:href="#poly-547a1518-9590-4f02-b9f0-9de97b2d1361"/>
							<gml:surfaceMember xlink:href="#poly-3c0ee138-cec2-4411-ba94-0bc2d59284f7"/>
							<gml:surfaceMember xlink:href="#poly-847cdb7e-559b-4a6b-80d5-7f153d3ec90e"/>
							<gml:surfaceMember xlink:href="#poly-2a504acb-c00a-4582-9370-b2b7d7175de2"/>
							<gml:surfaceMember xlink:href="#poly-575d6b1c-e5cd-4ea6-ba01-83cc72082245"/>
							<gml:surfaceMember xlink:href="#poly-036c7c78-ffcf-409f-9861-b246cc681773"/>
							<gml:surfaceMember xlink:href="#poly-0c74336e-7510-404c-81c5-10e1fa7a236c"/>
							<gml:surfaceMember xlink:href="#poly-703ea103-315a-49bd-8772-825a4b9b5beb"/>
							<gml:surfaceMember xlink:href="#poly-4b62ac2b-941c-4564-a560-654d3998f4aa"/>
							<gml:surfaceMember xlink:href="#poly-8debe110-1e1a-4ce9-80a5-5c54744d3ed8"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0917bb1c-ec48-4b72-9457-35e4af54491d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d28f0ae-79de-47e2-a326-e4b15cddd5dc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67213279264287 139.73980639486885 19.374 35.67213868338096 139.7398125408983 19.374 35.672136288425406 139.73981601229343 19.374 35.67212758303023 139.73980680966673 19.374 35.67213635257707 139.73979416223892 19.374 35.67213925726888 139.73979708617293 19.374 35.67213279264287 139.73980639486885 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1218bc0-7f92-4fe5-8ba9-f28780cbd2ee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67213868338096 139.7398125408983 18.92 35.67213279264287 139.73980639486885 18.92 35.67213925726888 139.73979708617293 18.92 35.67214520196106 139.73980306644168 18.92 35.67213868338096 139.7398125408983 18.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-056d5f63-383b-478f-8d49-239114f42ca5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67220713927133 139.73980819709126 18.92 35.67221939886008 139.73982098569812 18.92 35.67220930576051 139.73983552363313 18.92 35.672197046173295 139.73982273502568 18.92 35.67220713927133 139.73980819709126 18.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b715bcd8-a935-4046-91c4-9817420859e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b715bcd8-a935-4046-91c4-9817420859e1_0">
											<gml:posList>35.67213925726888 139.73979708617293 19.374 35.67213635257707 139.73979416223892 19.374 35.67213635257707 139.73979416223892 20.328 35.67214520196106 139.73980306644168 20.328 35.67214520196106 139.73980306644168 18.92 35.67213925726888 139.73979708617293 18.92 35.67213925726888 139.73979708617293 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d71c1cfe-a827-4878-ae61-04f7b4caabee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d71c1cfe-a827-4878-ae61-04f7b4caabee_0">
											<gml:posList>35.67213635257707 139.73979416223892 19.374 35.67212758303023 139.73980680966673 19.374 35.67212758303023 139.73980680966673 20.328 35.67213635257707 139.73979416223892 20.328 35.67213635257707 139.73979416223892 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68eec5f6-22fc-4a7a-b3ab-64593f0b4117">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68eec5f6-22fc-4a7a-b3ab-64593f0b4117_0">
											<gml:posList>35.67213279264287 139.73980639486885 19.374 35.67213925726888 139.73979708617293 19.374 35.67213925726888 139.73979708617293 18.92 35.67213279264287 139.73980639486885 18.92 35.67213279264287 139.73980639486885 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58003c24-ca85-4643-91a3-f1bab5ecc0c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58003c24-ca85-4643-91a3-f1bab5ecc0c8_0">
											<gml:posList>35.67213635257707 139.73979416223892 20.328 35.67212758303023 139.73980680966673 20.328 35.672136288425406 139.73981601229343 20.328 35.67214520196106 139.73980306644168 20.328 35.67213635257707 139.73979416223892 20.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81db3a14-5d9c-4b3f-948f-12899babd821">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81db3a14-5d9c-4b3f-948f-12899babd821_0">
											<gml:posList>35.67213279264287 139.73980639486885 18.92 35.67213868338096 139.7398125408983 18.92 35.67213868338096 139.7398125408983 19.374 35.67213279264287 139.73980639486885 19.374 35.67213279264287 139.73980639486885 18.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37fcd53b-8eb5-4e1b-9a2e-d33731eb4c4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37fcd53b-8eb5-4e1b-9a2e-d33731eb4c4c_0">
											<gml:posList>35.67214520196106 139.73980306644168 18.92 35.67214520196106 139.73980306644168 20.328 35.672136288425406 139.73981601229343 20.328 35.672136288425406 139.73981601229343 19.374 35.67213868338096 139.7398125408983 19.374 35.67213868338096 139.7398125408983 18.92 35.67214520196106 139.73980306644168 18.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d578b91e-d982-46a0-835e-589d86a7751b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d578b91e-d982-46a0-835e-589d86a7751b_0">
											<gml:posList>35.672136288425406 139.73981601229343 19.374 35.672136288425406 139.73981601229343 20.328 35.67212758303023 139.73980680966673 20.328 35.67212758303023 139.73980680966673 19.374 35.672136288425406 139.73981601229343 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9b0d181-7486-49ed-96d1-665ba4c75801">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9b0d181-7486-49ed-96d1-665ba4c75801_0">
											<gml:posList>35.67221939886008 139.73982098569812 18.92 35.67220713927133 139.73980819709126 18.92 35.67220713927133 139.73980819709126 21.502 35.67221939886008 139.73982098569812 21.502 35.67221939886008 139.73982098569812 18.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11258135-1c60-4e4d-927e-38f32e618280">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11258135-1c60-4e4d-927e-38f32e618280_0">
											<gml:posList>35.672197046173295 139.73982273502568 18.92 35.672197046173295 139.73982273502568 21.502 35.67220713927133 139.73980819709126 21.502 35.67220713927133 139.73980819709126 18.92 35.672197046173295 139.73982273502568 18.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa8e2c11-fde0-4599-bc4c-62b8bf511337">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa8e2c11-fde0-4599-bc4c-62b8bf511337_0">
											<gml:posList>35.67220713927133 139.73980819709126 21.502 35.672197046173295 139.73982273502568 21.502 35.67220930576051 139.73983552363313 21.502 35.67221939886008 139.73982098569812 21.502 35.67220713927133 139.73980819709126 21.502</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74b3f3ab-ee7e-488c-bcde-cd5ab5c8f328">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74b3f3ab-ee7e-488c-bcde-cd5ab5c8f328_0">
											<gml:posList>35.67220930576051 139.73983552363313 18.92 35.67221939886008 139.73982098569812 18.92 35.67221939886008 139.73982098569812 21.502 35.67220930576051 139.73983552363313 21.502 35.67220930576051 139.73983552363313 18.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adcba062-cb49-4257-8ab5-ad7e70176d95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adcba062-cb49-4257-8ab5-ad7e70176d95_0">
											<gml:posList>35.672197046173295 139.73982273502568 18.92 35.67220930576051 139.73983552363313 18.92 35.67220930576051 139.73983552363313 21.502 35.672197046173295 139.73982273502568 21.502 35.672197046173295 139.73982273502568 18.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0e727d82-c948-4838-8c0b-d99fd1beab96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e727d82-c948-4838-8c0b-d99fd1beab96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e727d82-c948-4838-8c0b-d99fd1beab96">
											<gml:posList>35.672127051332296 139.7398069538915 7.99 35.67216983667916 139.73974531970885 7.99 35.672240191744294 139.73981868586313 7.99 35.672197406351835 139.7398803090144 7.99 35.672127051332296 139.7398069538915 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8697370b-e3ef-4f02-944d-949d7c6c461d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8697370b-e3ef-4f02-944d-949d7c6c461d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8697370b-e3ef-4f02-944d-949d7c6c461d">
											<gml:posList>35.672127051332296 139.7398069538915 19.374 35.67213279264287 139.73980639486885 19.374 35.672170310861524 139.73975235577964 19.374 35.67216983667916 139.73974531970885 19.374 35.672127051332296 139.7398069538915 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ac656890-d0aa-4be4-b6ea-a20d5509daf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac656890-d0aa-4be4-b6ea-a20d5509daf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac656890-d0aa-4be4-b6ea-a20d5509daf6">
											<gml:posList>35.672197406351835 139.7398803090144 19.374 35.672196941199225 139.73987328397646 19.374 35.67213279264287 139.73980639486885 19.374 35.672127051332296 139.7398069538915 19.374 35.672197406351835 139.7398803090144 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9301cf69-312a-4b55-8769-f3aa97606098">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9301cf69-312a-4b55-8769-f3aa97606098">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9301cf69-312a-4b55-8769-f3aa97606098">
											<gml:posList>35.672234459456064 139.73981925592167 18.92 35.672170310861524 139.73975235577964 18.92 35.67213279264287 139.73980639486885 18.92 35.672196941199225 139.73987328397646 18.92 35.672234459456064 139.73981925592167 18.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-547a1518-9590-4f02-b9f0-9de97b2d1361">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-547a1518-9590-4f02-b9f0-9de97b2d1361">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-547a1518-9590-4f02-b9f0-9de97b2d1361">
											<gml:posList>35.67216983667916 139.73974531970885 19.374 35.672170310861524 139.73975235577964 19.374 35.672234459456064 139.73981925592167 19.374 35.672240191744294 139.73981868586313 19.374 35.67216983667916 139.73974531970885 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c0ee138-cec2-4411-ba94-0bc2d59284f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c0ee138-cec2-4411-ba94-0bc2d59284f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c0ee138-cec2-4411-ba94-0bc2d59284f7">
											<gml:posList>35.672240191744294 139.73981868586313 19.374 35.672234459456064 139.73981925592167 19.374 35.672196941199225 139.73987328397646 19.374 35.672197406351835 139.7398803090144 19.374 35.672240191744294 139.73981868586313 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-847cdb7e-559b-4a6b-80d5-7f153d3ec90e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-847cdb7e-559b-4a6b-80d5-7f153d3ec90e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-847cdb7e-559b-4a6b-80d5-7f153d3ec90e">
											<gml:posList>35.672170310861524 139.73975235577964 19.374 35.672170310861524 139.73975235577964 18.92 35.672234459456064 139.73981925592167 18.92 35.672234459456064 139.73981925592167 19.374 35.672170310861524 139.73975235577964 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a504acb-c00a-4582-9370-b2b7d7175de2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a504acb-c00a-4582-9370-b2b7d7175de2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a504acb-c00a-4582-9370-b2b7d7175de2">
											<gml:posList>35.672196941199225 139.73987328397646 19.374 35.672196941199225 139.73987328397646 18.92 35.67213279264287 139.73980639486885 18.92 35.67213279264287 139.73980639486885 19.374 35.672196941199225 139.73987328397646 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-575d6b1c-e5cd-4ea6-ba01-83cc72082245">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-575d6b1c-e5cd-4ea6-ba01-83cc72082245">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-575d6b1c-e5cd-4ea6-ba01-83cc72082245">
											<gml:posList>35.67216983667916 139.73974531970885 7.99 35.672127051332296 139.7398069538915 7.99 35.672127051332296 139.7398069538915 19.374 35.67216983667916 139.73974531970885 19.374 35.67216983667916 139.73974531970885 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-036c7c78-ffcf-409f-9861-b246cc681773">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-036c7c78-ffcf-409f-9861-b246cc681773">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-036c7c78-ffcf-409f-9861-b246cc681773">
											<gml:posList>35.67213279264287 139.73980639486885 19.374 35.67213279264287 139.73980639486885 18.92 35.672170310861524 139.73975235577964 18.92 35.672170310861524 139.73975235577964 19.374 35.67213279264287 139.73980639486885 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c74336e-7510-404c-81c5-10e1fa7a236c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c74336e-7510-404c-81c5-10e1fa7a236c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c74336e-7510-404c-81c5-10e1fa7a236c">
											<gml:posList>35.672240191744294 139.73981868586313 7.99 35.67216983667916 139.73974531970885 7.99 35.67216983667916 139.73974531970885 19.374 35.672240191744294 139.73981868586313 19.374 35.672240191744294 139.73981868586313 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-703ea103-315a-49bd-8772-825a4b9b5beb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-703ea103-315a-49bd-8772-825a4b9b5beb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-703ea103-315a-49bd-8772-825a4b9b5beb">
											<gml:posList>35.672127051332296 139.7398069538915 7.99 35.672197406351835 139.7398803090144 7.99 35.672197406351835 139.7398803090144 19.374 35.672127051332296 139.7398069538915 19.374 35.672127051332296 139.7398069538915 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b62ac2b-941c-4564-a560-654d3998f4aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b62ac2b-941c-4564-a560-654d3998f4aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b62ac2b-941c-4564-a560-654d3998f4aa">
											<gml:posList>35.672234459456064 139.73981925592167 19.374 35.672234459456064 139.73981925592167 18.92 35.672196941199225 139.73987328397646 18.92 35.672196941199225 139.73987328397646 19.374 35.672234459456064 139.73981925592167 19.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8debe110-1e1a-4ce9-80a5-5c54744d3ed8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8debe110-1e1a-4ce9-80a5-5c54744d3ed8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8debe110-1e1a-4ce9-80a5-5c54744d3ed8">
											<gml:posList>35.672197406351835 139.7398803090144 7.99 35.672240191744294 139.73981868586313 7.99 35.672240191744294 139.73981868586313 19.374 35.672197406351835 139.7398803090144 19.374 35.672197406351835 139.7398803090144 7.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6185</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">79.96555</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.15</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>