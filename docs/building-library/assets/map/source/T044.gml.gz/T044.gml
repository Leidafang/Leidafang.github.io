<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0a8202b6-d40f-412e-9fc3-ea85fa26744a">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>2</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67093874636947 139.7379138381914 0 35.670898473108565 139.7377094185426 0 35.67071544722453 139.73776354280218 0 35.67073562887752 139.73786569709614 0 35.67075058815191 139.73786126075976 0 35.6707641636289 139.7379305049712 0 35.670778041521615 139.73792640132152 0 35.67078455756608 139.73795942204922 0 35.67093874636947 139.7379138381914 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093874636947 139.7379138381914 13.1 35.67078455756608 139.73795942204922 13.1 35.670778041521615 139.73792640132152 13.1 35.6707641636289 139.7379305049712 13.1 35.67075058815191 139.73786126075976 13.1 35.67073562887752 139.73786569709614 13.1 35.67071544722453 139.73776354280218 13.1 35.670898473108565 139.7377094185426 13.1 35.67093874636947 139.7379138381914 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093874636947 139.7379138381914 13.1 35.670898473108565 139.7377094185426 13.1 35.670898473108565 139.7377094185426 29.83 35.67093874636947 139.7379138381914 29.83 35.67093874636947 139.7379138381914 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670898473108565 139.7377094185426 13.1 35.67071544722453 139.73776354280218 13.1 35.67071544722453 139.73776354280218 29.83 35.670898473108565 139.7377094185426 29.83 35.670898473108565 139.7377094185426 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071544722453 139.73776354280218 13.1 35.67073562887752 139.73786569709614 13.1 35.67073562887752 139.73786569709614 29.83 35.67071544722453 139.73776354280218 29.83 35.67071544722453 139.73776354280218 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073562887752 139.73786569709614 13.1 35.67075058815191 139.73786126075976 13.1 35.67075058815191 139.73786126075976 29.83 35.67073562887752 139.73786569709614 29.83 35.67073562887752 139.73786569709614 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67075058815191 139.73786126075976 13.1 35.6707641636289 139.7379305049712 13.1 35.6707641636289 139.7379305049712 29.83 35.67075058815191 139.73786126075976 29.83 35.67075058815191 139.73786126075976 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6707641636289 139.7379305049712 13.1 35.670778041521615 139.73792640132152 13.1 35.670778041521615 139.73792640132152 29.83 35.6707641636289 139.7379305049712 29.83 35.6707641636289 139.7379305049712 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670778041521615 139.73792640132152 13.1 35.67078455756608 139.73795942204922 13.1 35.67078455756608 139.73795942204922 29.83 35.670778041521615 139.73792640132152 29.83 35.670778041521615 139.73792640132152 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078455756608 139.73795942204922 13.1 35.67093874636947 139.7379138381914 13.1 35.67093874636947 139.7379138381914 29.83 35.67078455756608 139.73795942204922 29.83 35.67078455756608 139.73795942204922 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093874636947 139.7379138381914 29.83 35.670898473108565 139.7377094185426 29.83 35.67071544722453 139.73776354280218 29.83 35.67073562887752 139.73786569709614 29.83 35.67075058815191 139.73786126075976 29.83 35.6707641636289 139.7379305049712 29.83 35.670778041521615 139.73792640132152 29.83 35.67078455756608 139.73795942204922 29.83 35.67093874636947 139.7379138381914 29.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8507ea26-ebeb-4e9a-9e06-6fe01ff50ed4"/>
							<gml:surfaceMember xlink:href="#poly-948dcba7-684b-4818-97d4-ededf3d8a572"/>
							<gml:surfaceMember xlink:href="#poly-1c47ad33-d665-45d1-a2d5-7ff9eef7fdd8"/>
							<gml:surfaceMember xlink:href="#poly-d93c0cb5-0578-438b-9029-5f17605fa0e6"/>
							<gml:surfaceMember xlink:href="#poly-ae389390-eb00-48e7-b858-16d262f64aab"/>
							<gml:surfaceMember xlink:href="#poly-c40103c0-115a-4b70-827c-6d6a81df54e1"/>
							<gml:surfaceMember xlink:href="#poly-ff71eb3f-ce23-4d13-a6b9-f753cbee2325"/>
							<gml:surfaceMember xlink:href="#poly-26880f90-3d56-419c-b2c2-ebd50f3a57cf"/>
							<gml:surfaceMember xlink:href="#poly-1d84bade-e8d0-4811-bdd0-36ca03fc0623"/>
							<gml:surfaceMember xlink:href="#poly-2794ffdc-a1c7-43bb-880a-b416c4f46238"/>
							<gml:surfaceMember xlink:href="#poly-cca87e30-df20-4220-98a6-1125adc536e6"/>
							<gml:surfaceMember xlink:href="#poly-ed0d76e7-b3f3-4660-bf1b-9895ccb0b0d7"/>
							<gml:surfaceMember xlink:href="#poly-79310197-f07b-43aa-9894-0d663457d382"/>
							<gml:surfaceMember xlink:href="#poly-97f259d9-b88a-4ec1-b4f4-0080f344b91a"/>
							<gml:surfaceMember xlink:href="#poly-65a22d67-8bc1-4333-95cb-04dc1c8c44e9"/>
							<gml:surfaceMember xlink:href="#poly-edaa2c18-3356-4f0c-869e-5c9055036b0d"/>
							<gml:surfaceMember xlink:href="#poly-1a401f9e-4d28-4b01-ad04-a72cc6c02973"/>
							<gml:surfaceMember xlink:href="#poly-fcd788e4-3a1a-4302-bb1d-93103bbeee9e"/>
							<gml:surfaceMember xlink:href="#poly-b02d4e46-ad6f-4817-a37c-df28fdf4724f"/>
							<gml:surfaceMember xlink:href="#poly-c2b86f59-866e-41a4-9a52-7bd64cc27fee"/>
							<gml:surfaceMember xlink:href="#poly-272e42b3-3518-42fd-bdd8-517d170735d9"/>
							<gml:surfaceMember xlink:href="#poly-4fec30e3-0928-40af-a6b1-a786c7628470"/>
							<gml:surfaceMember xlink:href="#poly-c88ed2b4-d4fa-44f0-bd8f-b83836537f41"/>
							<gml:surfaceMember xlink:href="#poly-f20aa0f1-c19d-4b8b-a730-0d2dc609af9f"/>
							<gml:surfaceMember xlink:href="#poly-9aad426c-32ea-46fa-9608-5cb20c5df600"/>
							<gml:surfaceMember xlink:href="#poly-e5e97cdc-a870-4b36-a45f-ba4c80d8b092"/>
							<gml:surfaceMember xlink:href="#poly-613a56fe-b05d-440d-bcb8-773502829501"/>
							<gml:surfaceMember xlink:href="#poly-4db60a20-8b75-455d-b285-02e15130ee03"/>
							<gml:surfaceMember xlink:href="#poly-9f54510f-3ac5-42f4-9129-f6743b09cfb9"/>
							<gml:surfaceMember xlink:href="#poly-7e396432-b97d-49d0-bf8d-41555be1905f"/>
							<gml:surfaceMember xlink:href="#poly-3fe558b1-bd6c-4c6d-b1a1-744512982fb3"/>
							<gml:surfaceMember xlink:href="#poly-faa73983-6841-4ed6-9a2d-13ac49f019d9"/>
							<gml:surfaceMember xlink:href="#poly-7f02208f-aaed-43a7-9f05-556c36b517b5"/>
							<gml:surfaceMember xlink:href="#poly-406ed30a-040c-42f8-a082-5a00d85b5d41"/>
							<gml:surfaceMember xlink:href="#poly-bffbfa00-5429-4dee-851d-43cc8a62ec10"/>
							<gml:surfaceMember xlink:href="#poly-fa8ce6e4-5d97-4fe5-9cf7-89d13f036a4c"/>
							<gml:surfaceMember xlink:href="#poly-01d4fc5c-99e2-4bc1-94f3-d11211f6ae9d"/>
							<gml:surfaceMember xlink:href="#poly-21f5a559-e8ee-494e-a08c-fc1a494f2848"/>
							<gml:surfaceMember xlink:href="#poly-7084dbbd-3472-44fa-a2c2-94094e15acc7"/>
							<gml:surfaceMember xlink:href="#poly-112e2e99-0db0-4d93-a0c0-b33201304fa1"/>
							<gml:surfaceMember xlink:href="#poly-a530416f-a312-44c2-9767-c8aac2c8ca9b"/>
							<gml:surfaceMember xlink:href="#poly-7b4f90e4-d5a4-4c46-9348-10ce4a88c85e"/>
							<gml:surfaceMember xlink:href="#poly-f59b9c6a-482e-4737-b32b-61566966a3f4"/>
							<gml:surfaceMember xlink:href="#poly-2a790986-157f-4d36-af31-d9b235a4aea8"/>
							<gml:surfaceMember xlink:href="#poly-904fa24a-3f77-4f30-b4d3-bff64ac8e897"/>
							<gml:surfaceMember xlink:href="#poly-82092395-d6f5-420a-8a78-3f3ea5aa37ee"/>
							<gml:surfaceMember xlink:href="#poly-704ae621-2736-40d0-8e15-9dc696639ce9"/>
							<gml:surfaceMember xlink:href="#poly-2b324882-e96b-423f-a6c5-b29dad5ae2b5"/>
							<gml:surfaceMember xlink:href="#poly-7b925cf9-f216-4456-bb8e-2b2629c2f997"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0a8202b6-d40f-412e-9fc3-ea85fa26744a_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c530a32-cbb7-4e43-bbd1-8e2e8b6096e9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670862740503054 139.73792256687452 26.913 35.67086002809737 139.73791210923227 26.913 35.67090793353646 139.7378975373377 26.913 35.67091019580008 139.73790868039404 26.913 35.670862740503054 139.73792256687452 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b20fb1e-641f-46ff-b0ba-d42fb038f997">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b20fb1e-641f-46ff-b0ba-d42fb038f997_0">
											<gml:posList>35.670862740503054 139.73792256687452 26.913 35.670862740503054 139.73792256687452 27.114 35.67086002809737 139.73791210923227 27.114 35.67086002809737 139.73791210923227 26.913 35.670862740503054 139.73792256687452 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec46e6ce-8031-46d8-8f48-7ab839f0375f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec46e6ce-8031-46d8-8f48-7ab839f0375f_0">
											<gml:posList>35.67086002809737 139.73791210923227 26.913 35.67086002809737 139.73791210923227 27.114 35.67090793353646 139.7378975373377 27.114 35.67090793353646 139.7378975373377 26.913 35.67086002809737 139.73791210923227 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d142501-6a28-4ed0-9256-97ab547d36b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d142501-6a28-4ed0-9256-97ab547d36b3_0">
											<gml:posList>35.67090793353646 139.7378975373377 27.114 35.67086002809737 139.73791210923227 27.114 35.670862740503054 139.73792256687452 27.114 35.67091019580008 139.73790868039404 27.114 35.67090793353646 139.7378975373377 27.114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a2ab6c4-99bd-4ff0-84ed-4962ca8a74bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a2ab6c4-99bd-4ff0-84ed-4962ca8a74bc_0">
											<gml:posList>35.67091019580008 139.73790868039404 27.114 35.670862740503054 139.73792256687452 27.114 35.670862740503054 139.73792256687452 26.913 35.67091019580008 139.73790868039404 26.913 35.67091019580008 139.73790868039404 27.114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f844b43-25b3-4cee-b628-bacce38c5e42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f844b43-25b3-4cee-b628-bacce38c5e42_0">
											<gml:posList>35.67090793353646 139.7378975373377 26.913 35.67090793353646 139.7378975373377 27.114 35.67091019580008 139.73790868039404 27.114 35.67091019580008 139.73790868039404 26.913 35.67090793353646 139.7378975373377 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0a8202b6-d40f-412e-9fc3-ea85fa26744a_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28c41876-da39-4dc7-b983-f80148176321">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670818763972335 139.73774256419773 30.144 35.67082456672083 139.7377739951072 30.144 35.670816239865694 139.7377763026661 30.144 35.67081007664787 139.73774497160636 30.144 35.670818763972335 139.73774256419773 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8144933-cb64-43c7-9270-1ce16241a915">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67081007664787 139.73774497160636 30.63 35.670816239865694 139.7377763026661 30.63 35.67081477995843 139.73777670207355 30.63 35.670808977219394 139.73774528221406 30.63 35.67081007664787 139.73774497160636 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c7423ed-db4f-48ba-b6cf-a61bff34b57b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67083331372298 139.73780135746685 30.144 35.67084049589732 139.73779912859828 30.144 35.670848965318186 139.73784018873823 30.144 35.67084179214805 139.73784240654635 30.144 35.67083331372298 139.73780135746685 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b184b9c3-2f02-44f2-b2c4-e0f680559297">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670828258751776 139.7378035396152 30.144 35.67083771007958 139.7378552251419 30.144 35.67083208673494 139.73785676727718 30.144 35.67082196853262 139.7378052592896 30.144 35.670828258751776 139.7378035396152 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4668bed2-5161-45c5-b5f0-bc638599d13e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67082195051395 139.73780527035737 30.63 35.67083208673494 139.73785676727718 30.63 35.67083064485484 139.73785716666177 30.63 35.67082120253282 139.73780547008235 30.63 35.67082195051395 139.73780527035737 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d5d28ae-45c8-4d1f-bf7f-f65af58d2964">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67092201799026 139.7378470056879 34.339 35.67092325856363 139.73785418432755 34.339 35.67091222802866 139.73785704741726 34.339 35.67091098746421 139.73784987982492 34.339 35.67092201799026 139.7378470056879 34.339</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8e8a4af-2d4c-4550-a652-5e44fea4a665">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8e8a4af-2d4c-4550-a652-5e44fea4a665_0">
											<gml:posList>35.67083331372298 139.73780135746685 30.144 35.67084179214805 139.73784240654635 30.144 35.67084179214805 139.73784240654635 32.235 35.67083331372298 139.73780135746685 32.235 35.67083331372298 139.73780135746685 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-202d44e2-5a81-40bd-b7da-d1eb455d238e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-202d44e2-5a81-40bd-b7da-d1eb455d238e_0">
											<gml:posList>35.67081007664787 139.73774497160636 30.63 35.670808977219394 139.73774528221406 30.63 35.670808977219394 139.73774528221406 32.184 35.670818763972335 139.73774256419773 32.184 35.670818763972335 139.73774256419773 30.144 35.67081007664787 139.73774497160636 30.144 35.67081007664787 139.73774497160636 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe1ba729-613b-4f91-b4c2-6960a08d153f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe1ba729-613b-4f91-b4c2-6960a08d153f_0">
											<gml:posList>35.67082456672083 139.7377739951072 30.144 35.670818763972335 139.73774256419773 30.144 35.670818763972335 139.73774256419773 32.184 35.67082456672083 139.7377739951072 32.184 35.67082456672083 139.7377739951072 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca2940e6-9f74-4223-bd25-dbfa88df8899">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca2940e6-9f74-4223-bd25-dbfa88df8899_0">
											<gml:posList>35.670818763972335 139.73774256419773 32.184 35.670808977219394 139.73774528221406 32.184 35.67081477995843 139.73777670207355 32.184 35.67082456672083 139.7377739951072 32.184 35.670818763972335 139.73774256419773 32.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db36df16-7d97-4373-9d84-ef558cfecec0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db36df16-7d97-4373-9d84-ef558cfecec0_0">
											<gml:posList>35.67081007664787 139.73774497160636 30.144 35.670816239865694 139.7377763026661 30.144 35.670816239865694 139.7377763026661 30.63 35.67081007664787 139.73774497160636 30.63 35.67081007664787 139.73774497160636 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c5ba76d-9df3-4ffd-bf00-ef5587012c1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c5ba76d-9df3-4ffd-bf00-ef5587012c1e_0">
											<gml:posList>35.670808977219394 139.73774528221406 30.63 35.67081477995843 139.73777670207355 30.63 35.67081477995843 139.73777670207355 32.184 35.670808977219394 139.73774528221406 32.184 35.670808977219394 139.73774528221406 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20a57e7b-ab50-4d08-a89f-28b021a844f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20a57e7b-ab50-4d08-a89f-28b021a844f6_0">
											<gml:posList>35.67082456672083 139.7377739951072 30.144 35.67082456672083 139.7377739951072 32.184 35.67081477995843 139.73777670207355 32.184 35.67081477995843 139.73777670207355 30.63 35.670816239865694 139.7377763026661 30.63 35.670816239865694 139.7377763026661 30.144 35.67082456672083 139.7377739951072 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52c8930b-7eda-4350-a82c-dae5235b5881">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52c8930b-7eda-4350-a82c-dae5235b5881_0">
											<gml:posList>35.67084049589732 139.73779912859828 30.144 35.67083331372298 139.73780135746685 30.144 35.67083331372298 139.73780135746685 32.235 35.67084049589732 139.73779912859828 32.235 35.67084049589732 139.73779912859828 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2b1c749-29ca-4aa1-8a95-b1a3f1f022c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2b1c749-29ca-4aa1-8a95-b1a3f1f022c9_0">
											<gml:posList>35.67082195051395 139.73780527035737 30.63 35.67082120253282 139.73780547008235 30.63 35.67082120253282 139.73780547008235 32.235 35.670828258751776 139.7378035396152 32.235 35.670828258751776 139.7378035396152 30.144 35.67082196853262 139.7378052592896 30.144 35.67082195051395 139.73780527035737 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb129b19-d87b-4017-ae41-1a80564566cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb129b19-d87b-4017-ae41-1a80564566cb_0">
											<gml:posList>35.670848965318186 139.73784018873823 30.144 35.67084049589732 139.73779912859828 30.144 35.67084049589732 139.73779912859828 32.235 35.670848965318186 139.73784018873823 32.235 35.670848965318186 139.73784018873823 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-feef8694-1ebf-4477-864f-291b17e46157">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-feef8694-1ebf-4477-864f-291b17e46157_0">
											<gml:posList>35.67083331372298 139.73780135746685 32.235 35.67084179214805 139.73784240654635 32.235 35.670848965318186 139.73784018873823 32.235 35.67084049589732 139.73779912859828 32.235 35.67083331372298 139.73780135746685 32.235</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cffd79b0-6c3e-42d0-85d4-86bc584663b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cffd79b0-6c3e-42d0-85d4-86bc584663b3_0">
											<gml:posList>35.670828258751776 139.7378035396152 30.144 35.670828258751776 139.7378035396152 32.235 35.67083771007958 139.7378552251419 32.235 35.67083771007958 139.7378552251419 30.144 35.670828258751776 139.7378035396152 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5eaa0a40-a589-4e86-85d7-dd080a0182e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5eaa0a40-a589-4e86-85d7-dd080a0182e5_0">
											<gml:posList>35.67083771007958 139.7378552251419 32.235 35.670828258751776 139.7378035396152 32.235 35.67082120253282 139.73780547008235 32.235 35.67083064485484 139.73785716666177 32.235 35.67083771007958 139.7378552251419 32.235</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48eba70e-9e50-4d9d-80ec-e5b82cea2ad6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48eba70e-9e50-4d9d-80ec-e5b82cea2ad6_0">
											<gml:posList>35.67083208673494 139.73785676727718 30.144 35.67083208673494 139.73785676727718 30.63 35.67082195051395 139.73780527035737 30.63 35.67082196853262 139.7378052592896 30.144 35.67083208673494 139.73785676727718 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-283ad17c-d11d-4c1c-82f4-7814fe0d4fed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-283ad17c-d11d-4c1c-82f4-7814fe0d4fed_0">
											<gml:posList>35.67083064485484 139.73785716666177 30.63 35.67083064485484 139.73785716666177 32.235 35.67082120253282 139.73780547008235 32.235 35.67082120253282 139.73780547008235 30.63 35.67083064485484 139.73785716666177 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-919feab8-c8c0-47d9-b2cd-1aa0279ebf10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-919feab8-c8c0-47d9-b2cd-1aa0279ebf10_0">
											<gml:posList>35.67084179214805 139.73784240654635 30.144 35.670848965318186 139.73784018873823 30.144 35.670848965318186 139.73784018873823 32.235 35.67084179214805 139.73784240654635 32.235 35.67084179214805 139.73784240654635 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22de73b8-c56e-4a7d-82fc-822b0f09d03e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22de73b8-c56e-4a7d-82fc-822b0f09d03e_0">
											<gml:posList>35.67091098746421 139.73784987982492 34.339 35.67091098746421 139.73784987982492 34.757 35.67092201799026 139.7378470056879 34.757 35.67092201799026 139.7378470056879 34.339 35.67091098746421 139.73784987982492 34.339</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3533c984-4d61-423c-a673-de900299c21d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3533c984-4d61-423c-a673-de900299c21d_0">
											<gml:posList>35.67092325856363 139.73785418432755 34.339 35.67092201799026 139.7378470056879 34.339 35.67092201799026 139.7378470056879 34.757 35.67092325856363 139.73785418432755 34.757 35.67092325856363 139.73785418432755 34.339</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df8b1cc6-7fc3-42db-a685-f96c7e017fc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df8b1cc6-7fc3-42db-a685-f96c7e017fc3_0">
											<gml:posList>35.67091222802866 139.73785704741726 34.757 35.67092325856363 139.73785418432755 34.757 35.67092201799026 139.7378470056879 34.757 35.67091098746421 139.73784987982492 34.757 35.67091222802866 139.73785704741726 34.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa7a1049-b327-4a3b-b893-7f8570b733c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa7a1049-b327-4a3b-b893-7f8570b733c3_0">
											<gml:posList>35.67091098746421 139.73784987982492 34.339 35.67091222802866 139.73785704741726 34.339 35.67091222802866 139.73785704741726 34.757 35.67091098746421 139.73784987982492 34.757 35.67091098746421 139.73784987982492 34.339</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53563269-e605-485c-b2c6-c4c4debab5db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53563269-e605-485c-b2c6-c4c4debab5db_0">
											<gml:posList>35.67091222802866 139.73785704741726 34.339 35.67092325856363 139.73785418432755 34.339 35.67092325856363 139.73785418432755 34.757 35.67091222802866 139.73785704741726 34.757 35.67091222802866 139.73785704741726 34.339</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ac0f262-5f07-493b-8c27-5c5f8879bc21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ac0f262-5f07-493b-8c27-5c5f8879bc21_0">
											<gml:posList>35.67083771007958 139.7378552251419 30.144 35.67083771007958 139.7378552251419 32.235 35.67083064485484 139.73785716666177 32.235 35.67083064485484 139.73785716666177 30.63 35.67083208673494 139.73785676727718 30.63 35.67083208673494 139.73785676727718 30.144 35.67083771007958 139.7378552251419 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0a8202b6-d40f-412e-9fc3-ea85fa26744a_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08bd2b9f-abd9-4e46-b0ee-769c79b29990">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089872590186 139.7377780601395 30.144 35.670903838655704 139.73780326177408 30.144 35.670860141645775 139.7378165804759 30.144 35.67085502888594 139.7377913678079 30.144 35.67089872590186 139.7377780601395 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63362809-f37a-46f0-9af3-d8655f6f7c9d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077934474874 139.73793302755922 26.913 35.67077804152162 139.73792640132152 26.913 35.67077360780344 139.73792771006245 26.913 35.67073983265588 139.73775633363428 26.913 35.670804418897255 139.73773723488304 26.913 35.67083947029378 139.73791528190094 26.913 35.67077934474874 139.73793302755922 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7560225f-cf00-4b6a-995f-624bffaf4adf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7560225f-cf00-4b6a-995f-624bffaf4adf_0">
											<gml:posList>35.670804418897255 139.73773723488304 26.913 35.67073983265588 139.73775633363428 26.913 35.67073983265588 139.73775633363428 29.417 35.670804418897255 139.73773723488304 29.417 35.670804418897255 139.73773723488304 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fa555c4-031f-4785-9dbc-c3b74ffc44c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fa555c4-031f-4785-9dbc-c3b74ffc44c3_0">
											<gml:posList>35.67085502888594 139.7377913678079 30.144 35.67085502888594 139.7377913678079 32.618 35.67089872590186 139.7377780601395 32.618 35.67089872590186 139.7377780601395 30.144 35.67085502888594 139.7377913678079 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c755699-cf3e-48e6-b88c-251eb041cb4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c755699-cf3e-48e6-b88c-251eb041cb4c_0">
											<gml:posList>35.670903838655704 139.73780326177408 30.144 35.67089872590186 139.7377780601395 30.144 35.67089872590186 139.7377780601395 32.618 35.670903838655704 139.73780326177408 32.618 35.670903838655704 139.73780326177408 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db466fcf-1363-4620-86ba-0f4e0d5db54b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db466fcf-1363-4620-86ba-0f4e0d5db54b_0">
											<gml:posList>35.670860141645775 139.7378165804759 32.618 35.670903838655704 139.73780326177408 32.618 35.67089872590186 139.7377780601395 32.618 35.67085502888594 139.7377913678079 32.618 35.670860141645775 139.7378165804759 32.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b00855b-848f-4e8c-a099-40e0e90fda72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b00855b-848f-4e8c-a099-40e0e90fda72_0">
											<gml:posList>35.67085502888594 139.7377913678079 30.144 35.670860141645775 139.7378165804759 30.144 35.670860141645775 139.7378165804759 32.618 35.67085502888594 139.7377913678079 32.618 35.67085502888594 139.7377913678079 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e10846f9-f06a-4ce8-9e37-802a57aae4d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e10846f9-f06a-4ce8-9e37-802a57aae4d5_0">
											<gml:posList>35.670860141645775 139.7378165804759 30.144 35.670903838655704 139.73780326177408 30.144 35.670903838655704 139.73780326177408 32.618 35.670860141645775 139.7378165804759 32.618 35.670860141645775 139.7378165804759 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-262faedb-52cb-4635-927e-1590474c47e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-262faedb-52cb-4635-927e-1590474c47e3_0">
											<gml:posList>35.670804418897255 139.73773723488304 29.417 35.67083947029378 139.73791528190094 29.417 35.67083947029378 139.73791528190094 26.913 35.670804418897255 139.73773723488304 26.913 35.670804418897255 139.73773723488304 29.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e4e9cca-3dad-4f2a-8cbf-9144cb044507">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e4e9cca-3dad-4f2a-8cbf-9144cb044507_0">
											<gml:posList>35.67077360780344 139.73792771006245 29.417 35.67077804152162 139.73792640132152 29.417 35.67077934474874 139.73793302755922 29.417 35.67083947029378 139.73791528190094 29.417 35.670804418897255 139.73773723488304 29.417 35.67073983265588 139.73775633363428 29.417 35.67077360780344 139.73792771006245 29.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b11ec15b-bd75-4f88-81b4-c4d87372c412">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b11ec15b-bd75-4f88-81b4-c4d87372c412_0">
											<gml:posList>35.67073983265588 139.73775633363428 26.913 35.67077360780344 139.73792771006245 26.913 35.67077360780344 139.73792771006245 29.417 35.67073983265588 139.73775633363428 29.417 35.67073983265588 139.73775633363428 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-860c6363-6cbc-489f-9656-639012925840">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-860c6363-6cbc-489f-9656-639012925840_0">
											<gml:posList>35.67083947029378 139.73791528190094 26.913 35.67083947029378 139.73791528190094 29.417 35.67077934474874 139.73793302755922 29.417 35.67077934474874 139.73793302755922 26.913 35.67083947029378 139.73791528190094 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11eb07be-9e7b-49c7-9deb-23350f55acc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11eb07be-9e7b-49c7-9deb-23350f55acc8_0">
											<gml:posList>35.67077804152162 139.73792640132152 26.913 35.67077804152162 139.73792640132152 29.417 35.67077360780344 139.73792771006245 29.417 35.67077360780344 139.73792771006245 26.913 35.67077804152162 139.73792640132152 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08d9851d-1d0d-4c2e-a373-8a9454788b67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08d9851d-1d0d-4c2e-a373-8a9454788b67_0">
											<gml:posList>35.67077804152162 139.73792640132152 26.913 35.67077934474874 139.73793302755922 26.913 35.67077934474874 139.73793302755922 29.417 35.67077804152162 139.73792640132152 29.417 35.67077804152162 139.73792640132152 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8507ea26-ebeb-4e9a-9e06-6fe01ff50ed4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8507ea26-ebeb-4e9a-9e06-6fe01ff50ed4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8507ea26-ebeb-4e9a-9e06-6fe01ff50ed4">
											<gml:posList>35.6707505881519 139.73786126075976 13.1 35.67073562887749 139.73786569709614 13.1 35.670715447224524 139.73776354280218 13.1 35.67089847310857 139.7377094185426 13.1 35.670938746369465 139.73791383819136 13.1 35.67078455756609 139.73795942204922 13.1 35.67077804152162 139.73792640132152 13.1 35.67076416362889 139.73793050497116 13.1 35.6707505881519 139.73786126075976 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-948dcba7-684b-4818-97d4-ededf3d8a572">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-948dcba7-684b-4818-97d4-ededf3d8a572">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-948dcba7-684b-4818-97d4-ededf3d8a572">
											<gml:posList>35.670804418897255 139.73773723488304 30.63 35.67080926214203 139.73774085230073 30.63 35.670895521309816 139.7377153428961 30.63 35.67089847310857 139.7377094185426 30.63 35.670804418897255 139.73773723488304 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c47ad33-d665-45d1-a2d5-7ff9eef7fdd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c47ad33-d665-45d1-a2d5-7ff9eef7fdd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c47ad33-d665-45d1-a2d5-7ff9eef7fdd8">
											<gml:posList>35.67091985869689 139.73781795640238 30.63 35.67089847310857 139.7377094185426 30.63 35.670895521309816 139.7377153428961 30.63 35.670915956666896 139.73781910986958 30.63 35.67091985869689 139.73781795640238 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d93c0cb5-0578-438b-9029-5f17605fa0e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d93c0cb5-0578-438b-9029-5f17605fa0e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d93c0cb5-0578-438b-9029-5f17605fa0e6">
											<gml:posList>35.670895521309816 139.7377153428961 30.144 35.67080926214203 139.73774085230073 30.144 35.670836901415335 139.7378812070545 30.144 35.6708530145865 139.73787694608274 30.144 35.6708596095532 139.73790717202303 30.144 35.6709291517354 139.73788601284647 30.144 35.67092380311815 139.73785888941737 30.144 35.670904455177975 139.73786461236412 30.144 35.67089661774232 139.73782483281462 30.144 35.670915956666896 139.73781910986958 30.144 35.670895521309816 139.7377153428961 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae389390-eb00-48e7-b858-16d262f64aab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae389390-eb00-48e7-b858-16d262f64aab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae389390-eb00-48e7-b858-16d262f64aab">
											<gml:posList>35.6707407024116 139.737864188757 25.279 35.6707505881519 139.73786126075976 25.279 35.670730478596184 139.73775909531562 25.279 35.67072059285836 139.7377620233247 25.279 35.6707407024116 139.737864188757 25.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c40103c0-115a-4b70-827c-6d6a81df54e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c40103c0-115a-4b70-827c-6d6a81df54e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c40103c0-115a-4b70-827c-6d6a81df54e1">
											<gml:posList>35.670833913465636 139.73788702097693 30.63 35.670836901415335 139.7378812070545 30.63 35.67080926214203 139.73774085230073 30.63 35.670804418897255 139.73773723488304 30.63 35.670833913465636 139.73788702097693 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff71eb3f-ce23-4d13-a6b9-f753cbee2325">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff71eb3f-ce23-4d13-a6b9-f753cbee2325">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff71eb3f-ce23-4d13-a6b9-f753cbee2325">
											<gml:posList>35.67072059285836 139.7377620233247 23.8 35.670715447224524 139.73776354280218 23.8 35.67073562887749 139.73786569709614 23.8 35.6707407024116 139.737864188757 23.8 35.67072059285836 139.7377620233247 23.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26880f90-3d56-419c-b2c2-ebd50f3a57cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26880f90-3d56-419c-b2c2-ebd50f3a57cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26880f90-3d56-419c-b2c2-ebd50f3a57cf">
											<gml:posList>35.67089661774232 139.73782483281462 34.757 35.67090046889682 139.7378277223657 34.757 35.670917500852134 139.73782268704196 34.757 35.67091985869689 139.73781795640238 34.757 35.67089661774232 139.73782483281462 34.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d84bade-e8d0-4811-bdd0-36ca03fc0623">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d84bade-e8d0-4811-bdd0-36ca03fc0623">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d84bade-e8d0-4811-bdd0-36ca03fc0623">
											<gml:posList>35.67091985869689 139.73781795640238 34.757 35.670917500852134 139.73782268704196 34.757 35.67092383596733 139.73785484641996 34.757 35.67092769613481 139.73785773596273 34.757 35.67091985869689 139.73781795640238 34.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2794ffdc-a1c7-43bb-880a-b416c4f46238">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2794ffdc-a1c7-43bb-880a-b416c4f46238">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2794ffdc-a1c7-43bb-880a-b416c4f46238">
											<gml:posList>35.67092383596733 139.73785484641996 34.339 35.670917500852134 139.73782268704196 34.339 35.67090046889682 139.7378277223657 34.339 35.670906804010684 139.7378598817373 34.339 35.67092383596733 139.73785484641996 34.339</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cca87e30-df20-4220-98a6-1125adc536e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cca87e30-df20-4220-98a6-1125adc536e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cca87e30-df20-4220-98a6-1125adc536e6">
											<gml:posList>35.670804418897255 139.73773723488304 26.913 35.670730478596184 139.73775909531562 26.913 35.67076416362889 139.73793050497116 26.913 35.67077804152162 139.73792640132152 26.913 35.670783145747016 139.7379522546704 26.913 35.67093731644146 139.73790657140412 26.913 35.67093397693068 139.73788960820755 26.913 35.67085674789064 139.73791310730542 26.913 35.67085013478415 139.7378827377851 26.913 35.670833913465636 139.73788702097693 26.913 35.670804418897255 139.73773723488304 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed0d76e7-b3f3-4660-bf1b-9895ccb0b0d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed0d76e7-b3f3-4660-bf1b-9895ccb0b0d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed0d76e7-b3f3-4660-bf1b-9895ccb0b0d7">
											<gml:posList>35.670904455177975 139.73786461236412 34.757 35.670906804010684 139.7378598817373 34.757 35.67090046889682 139.7378277223657 34.757 35.67089661774232 139.73782483281462 34.757 35.670904455177975 139.73786461236412 34.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79310197-f07b-43aa-9894-0d663457d382">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79310197-f07b-43aa-9894-0d663457d382">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79310197-f07b-43aa-9894-0d663457d382">
											<gml:posList>35.67092769613481 139.73785773596273 34.757 35.67092383596733 139.73785484641996 34.757 35.670906804010684 139.7378598817373 34.757 35.670904455177975 139.73786461236412 34.757 35.67092769613481 139.73785773596273 34.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97f259d9-b88a-4ec1-b4f4-0080f344b91a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97f259d9-b88a-4ec1-b4f4-0080f344b91a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97f259d9-b88a-4ec1-b4f4-0080f344b91a">
											<gml:posList>35.67092769613481 139.73785773596273 30.63 35.67092380311815 139.73785888941737 30.63 35.6709291517354 139.73788601284647 30.63 35.67093397693068 139.73788960820755 30.63 35.67092769613481 139.73785773596273 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65a22d67-8bc1-4333-95cb-04dc1c8c44e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65a22d67-8bc1-4333-95cb-04dc1c8c44e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65a22d67-8bc1-4333-95cb-04dc1c8c44e9">
											<gml:posList>35.67085013478415 139.7378827377851 30.63 35.6708530145865 139.73787694608274 30.63 35.670836901415335 139.7378812070545 30.63 35.670833913465636 139.73788702097693 30.63 35.67085013478415 139.7378827377851 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-edaa2c18-3356-4f0c-869e-5c9055036b0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edaa2c18-3356-4f0c-869e-5c9055036b0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edaa2c18-3356-4f0c-869e-5c9055036b0d">
											<gml:posList>35.67085013478415 139.7378827377851 30.63 35.67085674789064 139.73791310730542 30.63 35.6708596095532 139.73790717202303 30.63 35.6708530145865 139.73787694608274 30.63 35.67085013478415 139.7378827377851 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a401f9e-4d28-4b01-ad04-a72cc6c02973">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a401f9e-4d28-4b01-ad04-a72cc6c02973">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a401f9e-4d28-4b01-ad04-a72cc6c02973">
											<gml:posList>35.67093397693068 139.73788960820755 30.63 35.6709291517354 139.73788601284647 30.63 35.6708596095532 139.73790717202303 30.63 35.67085674789064 139.73791310730542 30.63 35.67093397693068 139.73788960820755 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcd788e4-3a1a-4302-bb1d-93103bbeee9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcd788e4-3a1a-4302-bb1d-93103bbeee9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcd788e4-3a1a-4302-bb1d-93103bbeee9e">
											<gml:posList>35.670783145747016 139.7379522546704 25.645 35.67078455756609 139.73795942204922 25.645 35.670938746369465 139.73791383819136 25.645 35.67093731644146 139.73790657140412 25.645 35.670783145747016 139.7379522546704 25.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b02d4e46-ad6f-4817-a37c-df28fdf4724f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b02d4e46-ad6f-4817-a37c-df28fdf4724f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b02d4e46-ad6f-4817-a37c-df28fdf4724f">
											<gml:posList>35.670906804010684 139.7378598817373 34.757 35.670906804010684 139.7378598817373 34.339 35.67090046889682 139.7378277223657 34.339 35.67090046889682 139.7378277223657 34.757 35.670906804010684 139.7378598817373 34.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2b86f59-866e-41a4-9a52-7bd64cc27fee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2b86f59-866e-41a4-9a52-7bd64cc27fee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2b86f59-866e-41a4-9a52-7bd64cc27fee">
											<gml:posList>35.6707505881519 139.73786126075976 25.279 35.6707505881519 139.73786126075976 13.1 35.67076416362889 139.73793050497116 13.1 35.67076416362889 139.73793050497116 26.913 35.6707505881519 139.73786126075976 25.279</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-272e42b3-3518-42fd-bdd8-517d170735d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-272e42b3-3518-42fd-bdd8-517d170735d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-272e42b3-3518-42fd-bdd8-517d170735d9">
											<gml:posList>35.67076416362889 139.73793050497116 13.1 35.67077804152162 139.73792640132152 13.1 35.67077804152162 139.73792640132152 26.913 35.67076416362889 139.73793050497116 26.913 35.67076416362889 139.73793050497116 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fec30e3-0928-40af-a6b1-a786c7628470">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fec30e3-0928-40af-a6b1-a786c7628470">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fec30e3-0928-40af-a6b1-a786c7628470">
											<gml:posList>35.67077804152162 139.73792640132152 26.913 35.67077804152162 139.73792640132152 13.1 35.67078455756609 139.73795942204922 13.1 35.67078455756609 139.73795942204922 25.645 35.670783145747016 139.7379522546704 25.645 35.670783145747016 139.7379522546704 26.913 35.67077804152162 139.73792640132152 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c88ed2b4-d4fa-44f0-bd8f-b83836537f41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c88ed2b4-d4fa-44f0-bd8f-b83836537f41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c88ed2b4-d4fa-44f0-bd8f-b83836537f41">
											<gml:posList>35.67085674789064 139.73791310730542 30.63 35.67085013478415 139.7378827377851 30.63 35.67085013478415 139.7378827377851 26.913 35.67085674789064 139.73791310730542 26.913 35.67085674789064 139.73791310730542 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f20aa0f1-c19d-4b8b-a730-0d2dc609af9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f20aa0f1-c19d-4b8b-a730-0d2dc609af9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f20aa0f1-c19d-4b8b-a730-0d2dc609af9f">
											<gml:posList>35.67093731644146 139.73790657140412 25.645 35.67093731644146 139.73790657140412 26.913 35.670783145747016 139.7379522546704 26.913 35.670783145747016 139.7379522546704 25.645 35.67093731644146 139.73790657140412 25.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9aad426c-32ea-46fa-9608-5cb20c5df600">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9aad426c-32ea-46fa-9608-5cb20c5df600">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9aad426c-32ea-46fa-9608-5cb20c5df600">
											<gml:posList>35.67078455756609 139.73795942204922 13.1 35.670938746369465 139.73791383819136 13.1 35.670938746369465 139.73791383819136 25.645 35.67078455756609 139.73795942204922 25.645 35.67078455756609 139.73795942204922 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5e97cdc-a870-4b36-a45f-ba4c80d8b092">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5e97cdc-a870-4b36-a45f-ba4c80d8b092">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5e97cdc-a870-4b36-a45f-ba4c80d8b092">
											<gml:posList>35.6709291517354 139.73788601284647 30.63 35.6709291517354 139.73788601284647 30.144 35.6708596095532 139.73790717202303 30.144 35.6708596095532 139.73790717202303 30.63 35.6709291517354 139.73788601284647 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-613a56fe-b05d-440d-bcb8-773502829501">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-613a56fe-b05d-440d-bcb8-773502829501">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-613a56fe-b05d-440d-bcb8-773502829501">
											<gml:posList>35.67093397693068 139.73788960820755 26.913 35.67093397693068 139.73788960820755 30.63 35.67085674789064 139.73791310730542 30.63 35.67085674789064 139.73791310730542 26.913 35.67093397693068 139.73788960820755 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4db60a20-8b75-455d-b285-02e15130ee03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4db60a20-8b75-455d-b285-02e15130ee03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4db60a20-8b75-455d-b285-02e15130ee03">
											<gml:posList>35.670715447224524 139.73776354280218 23.8 35.670715447224524 139.73776354280218 13.1 35.67073562887749 139.73786569709614 13.1 35.670715447224524 139.73776354280218 23.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f54510f-3ac5-42f4-9129-f6743b09cfb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f54510f-3ac5-42f4-9129-f6743b09cfb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f54510f-3ac5-42f4-9129-f6743b09cfb9">
											<gml:posList>35.670715447224524 139.73776354280218 23.8 35.67073562887749 139.73786569709614 13.1 35.67073562887749 139.73786569709614 23.8 35.670715447224524 139.73776354280218 23.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e396432-b97d-49d0-bf8d-41555be1905f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e396432-b97d-49d0-bf8d-41555be1905f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e396432-b97d-49d0-bf8d-41555be1905f">
											<gml:posList>35.6707407024116 139.737864188757 23.8 35.6707407024116 139.737864188757 25.279 35.67072059285836 139.7377620233247 25.279 35.67072059285836 139.7377620233247 23.8 35.6707407024116 139.737864188757 23.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fe558b1-bd6c-4c6d-b1a1-744512982fb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fe558b1-bd6c-4c6d-b1a1-744512982fb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fe558b1-bd6c-4c6d-b1a1-744512982fb3">
											<gml:posList>35.6707505881519 139.73786126075976 13.1 35.6707505881519 139.73786126075976 25.279 35.6707407024116 139.737864188757 25.279 35.6707407024116 139.737864188757 23.8 35.67073562887749 139.73786569709614 23.8 35.6707505881519 139.73786126075976 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-faa73983-6841-4ed6-9a2d-13ac49f019d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faa73983-6841-4ed6-9a2d-13ac49f019d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faa73983-6841-4ed6-9a2d-13ac49f019d9">
											<gml:posList>35.6707505881519 139.73786126075976 13.1 35.67073562887749 139.73786569709614 23.8 35.67073562887749 139.73786569709614 13.1 35.6707505881519 139.73786126075976 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f02208f-aaed-43a7-9f05-556c36b517b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f02208f-aaed-43a7-9f05-556c36b517b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f02208f-aaed-43a7-9f05-556c36b517b5">
											<gml:posList>35.670730478596184 139.73775909531562 26.913 35.670730478596184 139.73775909531562 25.279 35.6707505881519 139.73786126075976 25.279 35.67076416362889 139.73793050497116 26.913 35.670730478596184 139.73775909531562 26.913</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-406ed30a-040c-42f8-a082-5a00d85b5d41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-406ed30a-040c-42f8-a082-5a00d85b5d41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-406ed30a-040c-42f8-a082-5a00d85b5d41">
											<gml:posList>35.670715447224524 139.73776354280218 13.1 35.670715447224524 139.73776354280218 23.8 35.67072059285836 139.7377620233247 23.8 35.67072059285836 139.7377620233247 25.279 35.670730478596184 139.73775909531562 25.279 35.670730478596184 139.73775909531562 26.913 35.670804418897255 139.73773723488304 26.913 35.670804418897255 139.73773723488304 30.63 35.67089847310857 139.7377094185426 30.63 35.67089847310857 139.7377094185426 13.1 35.670715447224524 139.73776354280218 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bffbfa00-5429-4dee-851d-43cc8a62ec10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bffbfa00-5429-4dee-851d-43cc8a62ec10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bffbfa00-5429-4dee-851d-43cc8a62ec10">
											<gml:posList>35.670833913465636 139.73788702097693 30.63 35.670804418897255 139.73773723488304 30.63 35.670804418897255 139.73773723488304 26.913 35.670833913465636 139.73788702097693 26.913 35.670833913465636 139.73788702097693 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa8ce6e4-5d97-4fe5-9cf7-89d13f036a4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa8ce6e4-5d97-4fe5-9cf7-89d13f036a4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa8ce6e4-5d97-4fe5-9cf7-89d13f036a4c">
											<gml:posList>35.670836901415335 139.7378812070545 30.63 35.670836901415335 139.7378812070545 30.144 35.67080926214203 139.73774085230073 30.144 35.67080926214203 139.73774085230073 30.63 35.670836901415335 139.7378812070545 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01d4fc5c-99e2-4bc1-94f3-d11211f6ae9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01d4fc5c-99e2-4bc1-94f3-d11211f6ae9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01d4fc5c-99e2-4bc1-94f3-d11211f6ae9d">
											<gml:posList>35.67085013478415 139.7378827377851 30.63 35.670833913465636 139.73788702097693 30.63 35.670833913465636 139.73788702097693 26.913 35.67085013478415 139.7378827377851 26.913 35.67085013478415 139.7378827377851 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21f5a559-e8ee-494e-a08c-fc1a494f2848">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21f5a559-e8ee-494e-a08c-fc1a494f2848">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21f5a559-e8ee-494e-a08c-fc1a494f2848">
											<gml:posList>35.6708530145865 139.73787694608274 30.63 35.6708530145865 139.73787694608274 30.144 35.670836901415335 139.7378812070545 30.144 35.670836901415335 139.7378812070545 30.63 35.6708530145865 139.73787694608274 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7084dbbd-3472-44fa-a2c2-94094e15acc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7084dbbd-3472-44fa-a2c2-94094e15acc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7084dbbd-3472-44fa-a2c2-94094e15acc7">
											<gml:posList>35.67080926214203 139.73774085230073 30.63 35.67080926214203 139.73774085230073 30.144 35.670895521309816 139.7377153428961 30.144 35.670895521309816 139.7377153428961 30.63 35.67080926214203 139.73774085230073 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-112e2e99-0db0-4d93-a0c0-b33201304fa1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-112e2e99-0db0-4d93-a0c0-b33201304fa1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-112e2e99-0db0-4d93-a0c0-b33201304fa1">
											<gml:posList>35.6708596095532 139.73790717202303 30.63 35.6708596095532 139.73790717202303 30.144 35.6708530145865 139.73787694608274 30.144 35.6708530145865 139.73787694608274 30.63 35.6708596095532 139.73790717202303 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a530416f-a312-44c2-9767-c8aac2c8ca9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a530416f-a312-44c2-9767-c8aac2c8ca9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a530416f-a312-44c2-9767-c8aac2c8ca9b">
											<gml:posList>35.67089661774232 139.73782483281462 30.144 35.670904455177975 139.73786461236412 30.144 35.670904455177975 139.73786461236412 34.757 35.67089661774232 139.73782483281462 34.757 35.67089661774232 139.73782483281462 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b4f90e4-d5a4-4c46-9348-10ce4a88c85e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b4f90e4-d5a4-4c46-9348-10ce4a88c85e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b4f90e4-d5a4-4c46-9348-10ce4a88c85e">
											<gml:posList>35.670895521309816 139.7377153428961 30.63 35.670895521309816 139.7377153428961 30.144 35.670915956666896 139.73781910986958 30.144 35.670915956666896 139.73781910986958 30.63 35.670895521309816 139.7377153428961 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f59b9c6a-482e-4737-b32b-61566966a3f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f59b9c6a-482e-4737-b32b-61566966a3f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f59b9c6a-482e-4737-b32b-61566966a3f4">
											<gml:posList>35.67089661774232 139.73782483281462 30.144 35.67089661774232 139.73782483281462 34.757 35.67091985869689 139.73781795640238 34.757 35.67091985869689 139.73781795640238 30.63 35.670915956666896 139.73781910986958 30.63 35.670915956666896 139.73781910986958 30.144 35.67089661774232 139.73782483281462 30.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a790986-157f-4d36-af31-d9b235a4aea8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a790986-157f-4d36-af31-d9b235a4aea8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a790986-157f-4d36-af31-d9b235a4aea8">
											<gml:posList>35.67090046889682 139.7378277223657 34.757 35.67090046889682 139.7378277223657 34.339 35.670917500852134 139.73782268704196 34.339 35.670917500852134 139.73782268704196 34.757 35.67090046889682 139.7378277223657 34.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-904fa24a-3f77-4f30-b4d3-bff64ac8e897">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-904fa24a-3f77-4f30-b4d3-bff64ac8e897">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-904fa24a-3f77-4f30-b4d3-bff64ac8e897">
											<gml:posList>35.67092383596733 139.73785484641996 34.757 35.67092383596733 139.73785484641996 34.339 35.670906804010684 139.7378598817373 34.339 35.670906804010684 139.7378598817373 34.757 35.67092383596733 139.73785484641996 34.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82092395-d6f5-420a-8a78-3f3ea5aa37ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82092395-d6f5-420a-8a78-3f3ea5aa37ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82092395-d6f5-420a-8a78-3f3ea5aa37ee">
											<gml:posList>35.67092769613481 139.73785773596273 34.757 35.670904455177975 139.73786461236412 34.757 35.670904455177975 139.73786461236412 30.144 35.67092380311815 139.73785888941737 30.144 35.67092380311815 139.73785888941737 30.63 35.67092769613481 139.73785773596273 30.63 35.67092769613481 139.73785773596273 34.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-704ae621-2736-40d0-8e15-9dc696639ce9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-704ae621-2736-40d0-8e15-9dc696639ce9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-704ae621-2736-40d0-8e15-9dc696639ce9">
											<gml:posList>35.670938746369465 139.73791383819136 25.645 35.670938746369465 139.73791383819136 13.1 35.67089847310857 139.7377094185426 13.1 35.67089847310857 139.7377094185426 30.63 35.67091985869689 139.73781795640238 30.63 35.67091985869689 139.73781795640238 34.757 35.67092769613481 139.73785773596273 34.757 35.67092769613481 139.73785773596273 30.63 35.67093397693068 139.73788960820755 30.63 35.67093397693068 139.73788960820755 26.913 35.67093731644146 139.73790657140412 26.913 35.67093731644146 139.73790657140412 25.645 35.670938746369465 139.73791383819136 25.645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b324882-e96b-423f-a6c5-b29dad5ae2b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b324882-e96b-423f-a6c5-b29dad5ae2b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b324882-e96b-423f-a6c5-b29dad5ae2b5">
											<gml:posList>35.670917500852134 139.73782268704196 34.757 35.670917500852134 139.73782268704196 34.339 35.67092383596733 139.73785484641996 34.339 35.67092383596733 139.73785484641996 34.757 35.670917500852134 139.73782268704196 34.757</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b925cf9-f216-4456-bb8e-2b2629c2f997">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b925cf9-f216-4456-bb8e-2b2629c2f997">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b925cf9-f216-4456-bb8e-2b2629c2f997">
											<gml:posList>35.67092380311815 139.73785888941737 30.63 35.67092380311815 139.73785888941737 30.144 35.6709291517354 139.73788601284647 30.144 35.6709291517354 139.73788601284647 30.63 35.67092380311815 139.73785888941737 30.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11647</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">376.46855</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>