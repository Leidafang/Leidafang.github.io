<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0aced056-3aa8-4e1a-9376-5704980274c3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">15.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67057286989935 139.73893141562183 0 35.67056825696478 139.73891109588845 0 35.67040947717925 139.73896485725547 0 35.670446562404024 139.7391295134688 0 35.67050468561448 139.73910989326788 0 35.67049645468394 139.73907356069498 0 35.670623334332284 139.73903055191326 0 35.670625867084475 139.73904192661618 0 35.670695344540086 139.7390184267458 0 35.67070529414819 139.73906248979497 0 35.670759632533404 139.73904408902712 0 35.670742898911925 139.73896976704486 0 35.67071108887046 139.73898051939935 0 35.670701048835355 139.73893612507453 0 35.67073051591149 139.73892614870417 0 35.67071188630196 139.7388479628011 0 35.670651510486074 139.73886858006364 0 35.67065512949235 139.7388858080233 0 35.67064602805927 139.73888891170753 0 35.6706491937778 139.73890282631186 0 35.67061179670669 139.7389154631293 0 35.6705883693442 139.73892609515428 0 35.67057286989935 139.73893141562183 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057286989935 139.73893141562183 18.49 35.6705883693442 139.73892609515428 18.49 35.67061179670669 139.7389154631293 18.49 35.6706491937778 139.73890282631186 18.49 35.67064602805927 139.73888891170753 18.49 35.67065512949235 139.7388858080233 18.49 35.670651510486074 139.73886858006364 18.49 35.67071188630196 139.7388479628011 18.49 35.67073051591149 139.73892614870417 18.49 35.670701048835355 139.73893612507453 18.49 35.67071108887046 139.73898051939935 18.49 35.670742898911925 139.73896976704486 18.49 35.670759632533404 139.73904408902712 18.49 35.67070529414819 139.73906248979497 18.49 35.670695344540086 139.7390184267458 18.49 35.670625867084475 139.73904192661618 18.49 35.670623334332284 139.73903055191326 18.49 35.67049645468394 139.73907356069498 18.49 35.67050468561448 139.73910989326788 18.49 35.670446562404024 139.7391295134688 18.49 35.67040947717925 139.73896485725547 18.49 35.67056825696478 139.73891109588845 18.49 35.67057286989935 139.73893141562183 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057286989935 139.73893141562183 18.49 35.67056825696478 139.73891109588845 18.49 35.67056825696478 139.73891109588845 34.16 35.67057286989935 139.73893141562183 34.16 35.67057286989935 139.73893141562183 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056825696478 139.73891109588845 18.49 35.67040947717925 139.73896485725547 18.49 35.67040947717925 139.73896485725547 34.16 35.67056825696478 139.73891109588845 34.16 35.67056825696478 139.73891109588845 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67040947717925 139.73896485725547 18.49 35.670446562404024 139.7391295134688 18.49 35.670446562404024 139.7391295134688 34.16 35.67040947717925 139.73896485725547 34.16 35.67040947717925 139.73896485725547 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670446562404024 139.7391295134688 18.49 35.67050468561448 139.73910989326788 18.49 35.67050468561448 139.73910989326788 34.16 35.670446562404024 139.7391295134688 34.16 35.670446562404024 139.7391295134688 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050468561448 139.73910989326788 18.49 35.67049645468394 139.73907356069498 18.49 35.67049645468394 139.73907356069498 34.16 35.67050468561448 139.73910989326788 34.16 35.67050468561448 139.73910989326788 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67049645468394 139.73907356069498 18.49 35.670623334332284 139.73903055191326 18.49 35.670623334332284 139.73903055191326 34.16 35.67049645468394 139.73907356069498 34.16 35.67049645468394 139.73907356069498 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670623334332284 139.73903055191326 18.49 35.670625867084475 139.73904192661618 18.49 35.670625867084475 139.73904192661618 34.16 35.670623334332284 139.73903055191326 34.16 35.670623334332284 139.73903055191326 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670625867084475 139.73904192661618 18.49 35.670695344540086 139.7390184267458 18.49 35.670695344540086 139.7390184267458 34.16 35.670625867084475 139.73904192661618 34.16 35.670625867084475 139.73904192661618 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670695344540086 139.7390184267458 18.49 35.67070529414819 139.73906248979497 18.49 35.67070529414819 139.73906248979497 34.16 35.670695344540086 139.7390184267458 34.16 35.670695344540086 139.7390184267458 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67070529414819 139.73906248979497 18.49 35.670759632533404 139.73904408902712 18.49 35.670759632533404 139.73904408902712 34.16 35.67070529414819 139.73906248979497 34.16 35.67070529414819 139.73906248979497 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670759632533404 139.73904408902712 18.49 35.670742898911925 139.73896976704486 18.49 35.670742898911925 139.73896976704486 34.16 35.670759632533404 139.73904408902712 34.16 35.670759632533404 139.73904408902712 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670742898911925 139.73896976704486 18.49 35.67071108887046 139.73898051939935 18.49 35.67071108887046 139.73898051939935 34.16 35.670742898911925 139.73896976704486 34.16 35.670742898911925 139.73896976704486 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071108887046 139.73898051939935 18.49 35.670701048835355 139.73893612507453 18.49 35.670701048835355 139.73893612507453 34.16 35.67071108887046 139.73898051939935 34.16 35.67071108887046 139.73898051939935 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670701048835355 139.73893612507453 18.49 35.67073051591149 139.73892614870417 18.49 35.67073051591149 139.73892614870417 34.16 35.670701048835355 139.73893612507453 34.16 35.670701048835355 139.73893612507453 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073051591149 139.73892614870417 18.49 35.67071188630196 139.7388479628011 18.49 35.67071188630196 139.7388479628011 34.16 35.67073051591149 139.73892614870417 34.16 35.67073051591149 139.73892614870417 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071188630196 139.7388479628011 18.49 35.670651510486074 139.73886858006364 18.49 35.670651510486074 139.73886858006364 34.16 35.67071188630196 139.7388479628011 34.16 35.67071188630196 139.7388479628011 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670651510486074 139.73886858006364 18.49 35.67065512949235 139.7388858080233 18.49 35.67065512949235 139.7388858080233 34.16 35.670651510486074 139.73886858006364 34.16 35.670651510486074 139.73886858006364 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67065512949235 139.7388858080233 18.49 35.67064602805927 139.73888891170753 18.49 35.67064602805927 139.73888891170753 34.16 35.67065512949235 139.7388858080233 34.16 35.67065512949235 139.7388858080233 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064602805927 139.73888891170753 18.49 35.6706491937778 139.73890282631186 18.49 35.6706491937778 139.73890282631186 34.16 35.67064602805927 139.73888891170753 34.16 35.67064602805927 139.73888891170753 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6706491937778 139.73890282631186 18.49 35.67061179670669 139.7389154631293 18.49 35.67061179670669 139.7389154631293 34.16 35.6706491937778 139.73890282631186 34.16 35.6706491937778 139.73890282631186 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061179670669 139.7389154631293 18.49 35.6705883693442 139.73892609515428 18.49 35.6705883693442 139.73892609515428 34.16 35.67061179670669 139.7389154631293 34.16 35.67061179670669 139.7389154631293 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705883693442 139.73892609515428 18.49 35.67057286989935 139.73893141562183 18.49 35.67057286989935 139.73893141562183 34.16 35.6705883693442 139.73892609515428 34.16 35.6705883693442 139.73892609515428 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057286989935 139.73893141562183 34.16 35.67056825696478 139.73891109588845 34.16 35.67040947717925 139.73896485725547 34.16 35.670446562404024 139.7391295134688 34.16 35.67050468561448 139.73910989326788 34.16 35.67049645468394 139.73907356069498 34.16 35.670623334332284 139.73903055191326 34.16 35.670625867084475 139.73904192661618 34.16 35.670695344540086 139.7390184267458 34.16 35.67070529414819 139.73906248979497 34.16 35.670759632533404 139.73904408902712 34.16 35.670742898911925 139.73896976704486 34.16 35.67071108887046 139.73898051939935 34.16 35.670701048835355 139.73893612507453 34.16 35.67073051591149 139.73892614870417 34.16 35.67071188630196 139.7388479628011 34.16 35.670651510486074 139.73886858006364 34.16 35.67065512949235 139.7388858080233 34.16 35.67064602805927 139.73888891170753 34.16 35.6706491937778 139.73890282631186 34.16 35.67061179670669 139.7389154631293 34.16 35.6705883693442 139.73892609515428 34.16 35.67057286989935 139.73893141562183 34.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-343c3891-78a0-44c9-932b-596f880338d4"/>
							<gml:surfaceMember xlink:href="#poly-b1c069cb-dd09-4abb-a8fd-1657d47f9097"/>
							<gml:surfaceMember xlink:href="#poly-7a900516-87e0-43dd-a972-0f5b5f6f52fc"/>
							<gml:surfaceMember xlink:href="#poly-57c00abc-c980-4ec8-acd0-4c6283bbd161"/>
							<gml:surfaceMember xlink:href="#poly-ce966264-c150-44c9-b71f-9315128fc4a8"/>
							<gml:surfaceMember xlink:href="#poly-fc826b2a-8af6-412d-873e-3abe09ec39ab"/>
							<gml:surfaceMember xlink:href="#poly-d9644e39-1af9-4129-b995-a3255dc05706"/>
							<gml:surfaceMember xlink:href="#poly-cb6f1132-0c09-4d87-a64a-eae92a868945"/>
							<gml:surfaceMember xlink:href="#poly-22a802fd-eea3-4b8a-916f-7f9cdfe35d4f"/>
							<gml:surfaceMember xlink:href="#poly-65c36ba0-a4ca-42d7-a424-233cdcd6b847"/>
							<gml:surfaceMember xlink:href="#poly-4ece835a-0e06-473b-8bc6-4c8a1722efb1"/>
							<gml:surfaceMember xlink:href="#poly-a892495f-ed6b-46ef-93d7-e84037f7370b"/>
							<gml:surfaceMember xlink:href="#poly-7256651b-d3ab-48f0-ba9f-3e61436c40f7"/>
							<gml:surfaceMember xlink:href="#poly-4135b669-e572-41b2-9bf4-e2de9d676c76"/>
							<gml:surfaceMember xlink:href="#poly-02d8e062-8af4-4833-a3af-133b4df96618"/>
							<gml:surfaceMember xlink:href="#poly-e884e57d-7e6f-4a02-87d9-5e3af0bc4f06"/>
							<gml:surfaceMember xlink:href="#poly-04e9aa2e-5533-4687-a358-81d2e0fe0b4f"/>
							<gml:surfaceMember xlink:href="#poly-84577301-ecad-4931-b57b-90a26127d2b5"/>
							<gml:surfaceMember xlink:href="#poly-868d8f6f-d602-4168-934e-d50443548e03"/>
							<gml:surfaceMember xlink:href="#poly-14769589-380c-4997-8cb6-eeb934cc63e9"/>
							<gml:surfaceMember xlink:href="#poly-2acf9386-96ef-4cba-bb90-f2cdb428720a"/>
							<gml:surfaceMember xlink:href="#poly-c30ebdca-d89d-4ead-bef5-79597373d57c"/>
							<gml:surfaceMember xlink:href="#poly-227a955d-9625-4c9b-8a5f-bd20bc3f7eea"/>
							<gml:surfaceMember xlink:href="#poly-5a9f004b-e86b-4d14-b584-283045e38ac1"/>
							<gml:surfaceMember xlink:href="#poly-2c57b15e-393b-497f-a8e7-e728f35d657a"/>
							<gml:surfaceMember xlink:href="#poly-ee548cb0-c6e0-46b3-9963-38d3ac35a9fd"/>
							<gml:surfaceMember xlink:href="#poly-0b1bb92f-d346-4e29-969a-9fe86da5a55e"/>
							<gml:surfaceMember xlink:href="#poly-059a3420-b45f-48a8-a52b-9062fe08221c"/>
							<gml:surfaceMember xlink:href="#poly-b15a09c0-1c97-4ba2-9093-fc11dfd74ab5"/>
							<gml:surfaceMember xlink:href="#poly-f54ee680-739c-4e90-b098-636275cc49c2"/>
							<gml:surfaceMember xlink:href="#poly-43df0859-4a60-47fb-8757-88bc0f4b32bb"/>
							<gml:surfaceMember xlink:href="#poly-637681d0-2a61-4c1e-a06d-b95b94d7f1ca"/>
							<gml:surfaceMember xlink:href="#poly-7be52170-cd61-4685-862a-7b369240a4c5"/>
							<gml:surfaceMember xlink:href="#poly-d69f2d05-9de2-4099-9d54-b7f4ed0f3160"/>
							<gml:surfaceMember xlink:href="#poly-2394165d-d994-45b5-aea2-7e1603e53dbe"/>
							<gml:surfaceMember xlink:href="#poly-3eca0550-6627-4b4c-a347-492ad5176582"/>
							<gml:surfaceMember xlink:href="#poly-5c170a8c-8c62-41a2-b45c-7b88e8f96ed1"/>
							<gml:surfaceMember xlink:href="#poly-6605a1bd-c6c5-40f8-bf24-856056a5f48b"/>
							<gml:surfaceMember xlink:href="#poly-ceed47c7-f9f2-462a-a606-1eaaca8b6a8f"/>
							<gml:surfaceMember xlink:href="#poly-b933f3e3-b504-44c2-bad2-f2235701132d"/>
							<gml:surfaceMember xlink:href="#poly-89fce20e-e3cc-4ad2-970f-76aa58640298"/>
							<gml:surfaceMember xlink:href="#poly-796509bf-01df-481f-8998-3d1006b3a326"/>
							<gml:surfaceMember xlink:href="#poly-2f606b50-9a70-406d-8950-1d30d532b3e7"/>
							<gml:surfaceMember xlink:href="#poly-ca4dc8d9-6d0c-4b2a-8515-59d9c1819280"/>
							<gml:surfaceMember xlink:href="#poly-ac2f12cf-2e8b-4b0d-8e9a-73f667854abf"/>
							<gml:surfaceMember xlink:href="#poly-7ac08a07-829c-4ed7-93fc-5bff577e175d"/>
							<gml:surfaceMember xlink:href="#poly-46b6f5c9-b13c-4a42-a60e-007fc76bbf52"/>
							<gml:surfaceMember xlink:href="#poly-3b493c90-3de4-41e7-8158-98bb1a9e2088"/>
							<gml:surfaceMember xlink:href="#poly-152aa52b-ac31-4a83-b8b0-f6f1780ff3e5"/>
							<gml:surfaceMember xlink:href="#poly-8b9e6ded-c0af-4c78-9c55-2e913291d097"/>
							<gml:surfaceMember xlink:href="#poly-03ff053c-17e1-4670-b75c-3055cb85075d"/>
							<gml:surfaceMember xlink:href="#poly-e4b4ab4b-ef48-4a65-8843-324156f10aaf"/>
							<gml:surfaceMember xlink:href="#poly-7ccf0ac8-d2e7-49e9-a8a6-49bd4baf1f2b"/>
							<gml:surfaceMember xlink:href="#poly-d7c5639d-a066-41b0-927d-b13beb9764be"/>
							<gml:surfaceMember xlink:href="#poly-c2895461-995e-4488-a0b0-52f445265bdc"/>
							<gml:surfaceMember xlink:href="#poly-2f0e2c81-8c51-44cd-8634-1e072c50dac1"/>
							<gml:surfaceMember xlink:href="#poly-8e58af0d-c554-42c9-a62f-1351c34fcdc9"/>
							<gml:surfaceMember xlink:href="#poly-32c7f0a7-91ad-4625-a45c-d7c9facaff0a"/>
							<gml:surfaceMember xlink:href="#poly-e012a4bd-a312-4efa-b208-a5d363cb155d"/>
							<gml:surfaceMember xlink:href="#poly-8bbbf3da-c6fd-4f9a-bd5c-234c440b61c8"/>
							<gml:surfaceMember xlink:href="#poly-74ae51ea-d50f-40ae-aed3-cdefb355f06a"/>
							<gml:surfaceMember xlink:href="#poly-f5f9aab5-0e28-42b7-b93d-fd6b880f9e0c"/>
							<gml:surfaceMember xlink:href="#poly-e491c3e2-9d68-4d52-858b-e04894115dad"/>
							<gml:surfaceMember xlink:href="#poly-ec5f7a2d-ed75-4a18-b928-868eb2c3755c"/>
							<gml:surfaceMember xlink:href="#poly-537ea436-dfdf-457b-96cc-0bd5dccb319d"/>
							<gml:surfaceMember xlink:href="#poly-2a485152-473e-4947-8a9a-2f7e6b9c3486"/>
							<gml:surfaceMember xlink:href="#poly-b2f08977-306f-4ed9-87ec-e1931ace8dfa"/>
							<gml:surfaceMember xlink:href="#poly-6a18d419-fe45-4552-b0d2-8a154cf20031"/>
							<gml:surfaceMember xlink:href="#poly-56d4a030-ec23-4df7-bc98-e1555b489aab"/>
							<gml:surfaceMember xlink:href="#poly-a98390cc-7de8-4683-8e87-8879118b11d6"/>
							<gml:surfaceMember xlink:href="#poly-2553ec7e-c9a7-47b7-83f2-0b69c7a1a727"/>
							<gml:surfaceMember xlink:href="#poly-df892f62-4ef2-4fd9-8122-e184080156b1"/>
							<gml:surfaceMember xlink:href="#poly-eb8b29e6-67dc-4d6e-9e64-05e94fde0589"/>
							<gml:surfaceMember xlink:href="#poly-9eeff467-6a3f-4f6e-ad95-ad7903a4fba9"/>
							<gml:surfaceMember xlink:href="#poly-da23849b-0978-4ac1-a40f-e24383483a2b"/>
							<gml:surfaceMember xlink:href="#poly-e970b097-174b-45ea-aa30-23673e9ea61d"/>
							<gml:surfaceMember xlink:href="#poly-ef7a6a99-9d67-4b54-9c65-99268a5a230d"/>
							<gml:surfaceMember xlink:href="#poly-51df76d1-f06d-4644-beb1-520a4b5d8b0a"/>
							<gml:surfaceMember xlink:href="#poly-f5ed9c7e-36d9-4fa4-97ee-fa62f61f8b5a"/>
							<gml:surfaceMember xlink:href="#poly-1cd7e98d-f87f-4172-ba46-0ed206ba50ef"/>
							<gml:surfaceMember xlink:href="#poly-c2abee64-90de-4018-8697-5c8444965ea0"/>
							<gml:surfaceMember xlink:href="#poly-d3e13ffa-72b3-4af2-810b-85714d04d110"/>
							<gml:surfaceMember xlink:href="#poly-a1e38966-6e26-47b9-82f0-7f2a355b4f32"/>
							<gml:surfaceMember xlink:href="#poly-0e3e027c-ab96-4949-9e59-360696ef83f2"/>
							<gml:surfaceMember xlink:href="#poly-f59a526f-3081-42aa-b880-abfbe160aae9"/>
							<gml:surfaceMember xlink:href="#poly-ab31edb8-d606-4d68-9c78-b5f9c89df5c2"/>
							<gml:surfaceMember xlink:href="#poly-5afddea8-010a-4fd9-92d2-a0ce4412ce3b"/>
							<gml:surfaceMember xlink:href="#poly-c3b24b42-6cbc-4638-838f-bdfe75d43a9c"/>
							<gml:surfaceMember xlink:href="#poly-e758654c-24a7-4496-b46c-a0b64703459c"/>
							<gml:surfaceMember xlink:href="#poly-3643fcc0-7280-45b8-bef0-3c702396619b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0aced056-3aa8-4e1a-9376-5704980274c3_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0402398c-2cbe-4b75-b405-efea5324cb17">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705853845091 139.7389129535867 18.49 35.67060935468614 139.73890486156586 18.49 35.67061179670666 139.7389154631293 18.49 35.6705883693442 139.73892609515428 18.49 35.6705853845091 139.7389129535867 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6c9c739-be37-46ab-975d-d88053449e0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6c9c739-be37-46ab-975d-d88053449e0c_0">
											<gml:posList>35.6705853845091 139.7389129535867 32.356 35.6705853845091 139.7389129535867 18.49 35.6705883693442 139.73892609515428 18.49 35.6705883693442 139.73892609515428 32.356 35.6705853845091 139.7389129535867 32.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e84f10d-5ff7-4ca7-8cb9-2074a5bcfc27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e84f10d-5ff7-4ca7-8cb9-2074a5bcfc27_0">
											<gml:posList>35.67060935468614 139.73890486156586 32.356 35.67060935468614 139.73890486156586 18.49 35.6705853845091 139.7389129535867 18.49 35.6705853845091 139.7389129535867 32.356 35.67060935468614 139.73890486156586 32.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcc0f996-c58f-427a-b5c5-ad2386f1929f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcc0f996-c58f-427a-b5c5-ad2386f1929f_0">
											<gml:posList>35.6705883693442 139.73892609515428 32.356 35.67061179670666 139.7389154631293 32.356 35.67060935468614 139.73890486156586 32.356 35.6705853845091 139.7389129535867 32.356 35.6705883693442 139.73892609515428 32.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0db24ae3-ee88-46e5-a133-64e7a87b3e33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0db24ae3-ee88-46e5-a133-64e7a87b3e33_0">
											<gml:posList>35.6705883693442 139.73892609515428 32.356 35.6705883693442 139.73892609515428 18.49 35.67061179670666 139.7389154631293 18.49 35.67061179670666 139.7389154631293 32.356 35.6705883693442 139.73892609515428 32.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33a1b898-cc1a-4b72-98af-2411d54a7cc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33a1b898-cc1a-4b72-98af-2411d54a7cc9_0">
											<gml:posList>35.67061179670666 139.7389154631293 32.356 35.67061179670666 139.7389154631293 18.49 35.67060935468614 139.73890486156586 18.49 35.67060935468614 139.73890486156586 32.356 35.67061179670666 139.7389154631293 32.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0aced056-3aa8-4e1a-9376-5704980274c3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9927caa3-0050-4b3c-9d87-bdb296e33d07">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670454353676774 139.73905325191598 41.418 35.670449351719334 139.73903107688994 41.418 35.67046277861844 139.73902653212662 41.418 35.67046778056809 139.73904869610982 41.418 35.670454353676774 139.73905325191598 41.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d38b221c-2a99-4f04-b96e-ffd233b333c4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67048050460668 139.7390789589816 34.454 35.670471070542646 139.73903713784065 34.454 35.67049332854526 139.73902958914988 34.454 35.67050165908101 139.7390664849598 34.454 35.6704912058354 139.73906991054886 34.454 35.6704923455075 139.73907494631024 34.454 35.67048050460668 139.7390789589816 34.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64df5b76-9522-445f-8cbe-33feec2cba7f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6704923455075 139.73907494631024 35.126 35.6704912058354 139.73906991054886 35.126 35.67050165908101 139.7390664849598 35.126 35.67050277163427 139.7390714213372 35.126 35.6704923455075 139.73907494631024 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad507c95-2e06-4ecd-b1f3-5e282152baf6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad507c95-2e06-4ecd-b1f3-5e282152baf6_0">
											<gml:posList>35.670449351719334 139.73903107688994 41.418 35.670454353676774 139.73905325191598 41.418 35.670454353676774 139.73905325191598 43.526 35.670449351719334 139.73903107688994 43.526 35.670449351719334 139.73903107688994 41.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e7347fc-b05c-4e38-a6db-78f9ee10cc88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e7347fc-b05c-4e38-a6db-78f9ee10cc88_0">
											<gml:posList>35.67049332854526 139.73902958914988 34.454 35.67049332854526 139.73902958914988 38.035 35.67050277163427 139.7390714213372 38.035 35.67050277163427 139.7390714213372 35.126 35.67050165908101 139.7390664849598 35.126 35.67050165908101 139.7390664849598 34.454 35.67049332854526 139.73902958914988 34.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c681b65-0c5d-4c8b-a7d8-05880362a847">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c681b65-0c5d-4c8b-a7d8-05880362a847_0">
											<gml:posList>35.670454353676774 139.73905325191598 41.418 35.67046778056809 139.73904869610982 41.418 35.67046778056809 139.73904869610982 43.526 35.670454353676774 139.73905325191598 43.526 35.670454353676774 139.73905325191598 41.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f1d1a23-46da-41d8-b687-8dae28b70ae2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f1d1a23-46da-41d8-b687-8dae28b70ae2_0">
											<gml:posList>35.67049332854526 139.73902958914988 38.035 35.670471070542646 139.73903713784065 38.035 35.67048050460668 139.7390789589816 38.035 35.67050277163427 139.7390714213372 38.035 35.67049332854526 139.73902958914988 38.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b533440-de00-467f-97eb-6d4bf090b4eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b533440-de00-467f-97eb-6d4bf090b4eb_0">
											<gml:posList>35.670471070542646 139.73903713784065 38.035 35.670471070542646 139.73903713784065 34.454 35.67048050460668 139.7390789589816 34.454 35.67048050460668 139.7390789589816 38.035 35.670471070542646 139.73903713784065 38.035</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9da29088-aaee-4b43-908d-c365e155895c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9da29088-aaee-4b43-908d-c365e155895c_0">
											<gml:posList>35.67050165908101 139.7390664849598 34.454 35.67050165908101 139.7390664849598 35.126 35.6704912058354 139.73906991054886 35.126 35.6704912058354 139.73906991054886 34.454 35.67050165908101 139.7390664849598 34.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2ca8f22-2a62-4843-a224-a69d4a66aeaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2ca8f22-2a62-4843-a224-a69d4a66aeaa_0">
											<gml:posList>35.6704912058354 139.73906991054886 35.126 35.6704923455075 139.73907494631024 35.126 35.6704923455075 139.73907494631024 34.454 35.6704912058354 139.73906991054886 34.454 35.6704912058354 139.73906991054886 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16525dc2-ecd6-4f9b-826d-cc88cb2f8811">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16525dc2-ecd6-4f9b-826d-cc88cb2f8811_0">
											<gml:posList>35.6704923455075 139.73907494631024 35.126 35.67050277163427 139.7390714213372 35.126 35.67050277163427 139.7390714213372 38.035 35.67048050460668 139.7390789589816 38.035 35.67048050460668 139.7390789589816 34.454 35.6704923455075 139.73907494631024 34.454 35.6704923455075 139.73907494631024 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18241d4a-f8ae-4a4a-9894-af88dfa58c14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18241d4a-f8ae-4a4a-9894-af88dfa58c14_0">
											<gml:posList>35.670449351719334 139.73903107688994 41.418 35.670449351719334 139.73903107688994 43.526 35.67046277861844 139.73902653212662 43.526 35.67046277861844 139.73902653212662 41.418 35.670449351719334 139.73903107688994 41.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56150705-6421-4853-8b62-dd229bb03d6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56150705-6421-4853-8b62-dd229bb03d6c_0">
											<gml:posList>35.67049332854526 139.73902958914988 34.454 35.670471070542646 139.73903713784065 34.454 35.670471070542646 139.73903713784065 38.035 35.67049332854526 139.73902958914988 38.035 35.67049332854526 139.73902958914988 34.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4954091-36fc-437f-9e87-aa59d0471dc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4954091-36fc-437f-9e87-aa59d0471dc4_0">
											<gml:posList>35.67046778056809 139.73904869610982 41.418 35.67046277861844 139.73902653212662 41.418 35.67046277861844 139.73902653212662 43.526 35.67046778056809 139.73904869610982 43.526 35.67046778056809 139.73904869610982 41.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6b23ef6-73f0-4046-8fde-691cf0a47809">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6b23ef6-73f0-4046-8fde-691cf0a47809_0">
											<gml:posList>35.670454353676774 139.73905325191598 43.526 35.67046778056809 139.73904869610982 43.526 35.67046277861844 139.73902653212662 43.526 35.670449351719334 139.73903107688994 43.526 35.670454353676774 139.73905325191598 43.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-343c3891-78a0-44c9-932b-596f880338d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-343c3891-78a0-44c9-932b-596f880338d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-343c3891-78a0-44c9-932b-596f880338d4">
											<gml:posList>35.67044656240402 139.7391295134688 18.49 35.67040947717922 139.73896485725547 18.49 35.67056825696478 139.73891109588843 18.49 35.670572869899324 139.73893141562183 18.49 35.6705883693442 139.73892609515428 18.49 35.67061179670666 139.7389154631293 18.49 35.67064919377776 139.73890282631186 18.49 35.670646028059224 139.73888891170753 18.49 35.67065512949235 139.73888580802327 18.49 35.67065151048604 139.73886858006364 18.49 35.670711886301966 139.7388479628011 18.49 35.67073051591149 139.73892614870414 18.49 35.670701048835355 139.73893612507453 18.49 35.67071108887043 139.73898051939935 18.49 35.670742898911904 139.73896976704484 18.49 35.67075963253338 139.73904408902712 18.49 35.67070529414818 139.73906248979497 18.49 35.67069534454009 139.7390184267458 18.49 35.67062586708447 139.73904192661618 18.49 35.6706233343323 139.73903055191326 18.49 35.670496454683935 139.73907356069498 18.49 35.670504685614446 139.73910989326788 18.49 35.67044656240402 139.7391295134688 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1c069cb-dd09-4abb-a8fd-1657d47f9097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1c069cb-dd09-4abb-a8fd-1657d47f9097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1c069cb-dd09-4abb-a8fd-1657d47f9097">
											<gml:posList>35.6705883693442 139.73892609515428 35.126 35.67058968924478 139.73893106442978 35.126 35.67061305352895 139.73892045457293 35.126 35.67061179670666 139.7389154631293 35.126 35.6705883693442 139.73892609515428 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a900516-87e0-43dd-a972-0f5b5f6f52fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a900516-87e0-43dd-a972-0f5b5f6f52fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a900516-87e0-43dd-a972-0f5b5f6f52fc">
											<gml:posList>35.6705883693442 139.73892609515428 35.126 35.670572869899324 139.73893141562183 35.126 35.67057410869352 139.73893640708454 35.126 35.67058968924478 139.73893106442978 35.126 35.6705883693442 139.73892609515428 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57c00abc-c980-4ec8-acd0-4c6283bbd161">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57c00abc-c980-4ec8-acd0-4c6283bbd161">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57c00abc-c980-4ec8-acd0-4c6283bbd161">
											<gml:posList>35.670572869899324 139.73893141562183 35.126 35.67052427308886 139.73894957769213 35.126 35.67052947675984 139.7389530842834 35.126 35.67057410869352 139.73893640708454 35.126 35.670572869899324 139.73893141562183 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce966264-c150-44c9-b71f-9315128fc4a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce966264-c150-44c9-b71f-9315128fc4a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce966264-c150-44c9-b71f-9315128fc4a8">
											<gml:posList>35.67040947717922 139.73896485725547 30.097 35.67041440681407 139.73898674514857 30.097 35.67052427308886 139.73894957769213 30.097 35.670572869899324 139.73893141562183 30.097 35.67056825696478 139.73891109588843 30.097 35.67040947717922 139.73896485725547 30.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc826b2a-8af6-412d-873e-3abe09ec39ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc826b2a-8af6-412d-873e-3abe09ec39ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc826b2a-8af6-412d-873e-3abe09ec39ab">
											<gml:posList>35.67052751130843 139.73896400032126 35.126 35.67053274211538 139.73896762839075 35.126 35.67052947675984 139.7389530842834 35.126 35.67052427308886 139.73894957769213 35.126 35.67052751130843 139.73896400032126 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9644e39-1af9-4129-b995-a3255dc05706">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9644e39-1af9-4129-b995-a3255dc05706">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9644e39-1af9-4129-b995-a3255dc05706">
											<gml:posList>35.67052751130843 139.73896400032126 32.672 35.67052427308886 139.73894957769213 32.672 35.67041440681407 139.73898674514857 32.672 35.67041777164536 139.73900170887745 32.672 35.67052751130843 139.73896400032126 32.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb6f1132-0c09-4d87-a64a-eae92a868945">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb6f1132-0c09-4d87-a64a-eae92a868945">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb6f1132-0c09-4d87-a64a-eae92a868945">
											<gml:posList>35.67052751130843 139.73896400032126 35.126 35.67041777164536 139.73900170887745 35.126 35.67042301144767 139.73900531484134 35.126 35.67053274211538 139.73896762839075 35.126 35.67052751130843 139.73896400032126 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22a802fd-eea3-4b8a-916f-7f9cdfe35d4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22a802fd-eea3-4b8a-916f-7f9cdfe35d4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22a802fd-eea3-4b8a-916f-7f9cdfe35d4f">
											<gml:posList>35.67066028821777 139.73888946931723 34.454 35.67065126789072 139.73889255081315 34.454 35.67065443360883 139.73890646541855 34.454 35.67061305352895 139.73892045457293 34.454 35.67058968924478 139.73893106442978 34.454 35.67057410869352 139.73893640708454 34.454 35.67052947675984 139.7389530842834 34.454 35.67053274211538 139.73896762839075 34.454 35.67046666558176 139.73901763530634 34.454 35.67047511371472 139.73905506118555 34.454 35.67045136883542 139.7390631086979 34.454 35.67044292071359 139.73902569387516 34.454 35.67042301144767 139.73900531484134 34.454 35.67044954091631 139.73912308104073 34.454 35.67049943675838 139.73910623207274 34.454 35.6704912058354 139.73906991054886 34.454 35.670626638475184 139.739025577195 34.454 35.67062884558332 139.7390354831242 34.454 35.67069830501885 139.7390119943148 34.454 35.6707082546293 139.73905605736485 34.454 35.67075438368416 139.73904043887097 34.454 35.67073991138561 139.73897618846644 34.454 35.67070811035726 139.7389869408074 34.454 35.670695790977774 139.73893248598503 34.454 35.67072520397995 139.73892252072397 34.454 35.67070896186954 139.7388543731041 34.454 35.670656669203304 139.73887223031002 34.454 35.67066028821777 139.73888946931723 34.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-65c36ba0-a4ca-42d7-a424-233cdcd6b847">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65c36ba0-a4ca-42d7-a424-233cdcd6b847">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65c36ba0-a4ca-42d7-a424-233cdcd6b847">
											<gml:posList>35.67042301144767 139.73900531484134 34.454 35.67044292071359 139.73902569387516 34.454 35.67046666558176 139.73901763530634 34.454 35.67053274211538 139.73896762839075 34.454 35.67042301144767 139.73900531484134 34.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ece835a-0e06-473b-8bc6-4c8a1722efb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ece835a-0e06-473b-8bc6-4c8a1722efb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ece835a-0e06-473b-8bc6-4c8a1722efb1">
											<gml:posList>35.67044292071359 139.73902569387516 42.063 35.67044638386892 139.73902809788817 42.063 35.6704647129264 139.73902187937136 42.063 35.67046666558176 139.73901763530634 42.063 35.67044292071359 139.73902569387516 42.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a892495f-ed6b-46ef-93d7-e84037f7370b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a892495f-ed6b-46ef-93d7-e84037f7370b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a892495f-ed6b-46ef-93d7-e84037f7370b">
											<gml:posList>35.67046666558176 139.73901763530634 42.063 35.6704647129264 139.73902187937136 42.063 35.67047165958232 139.73905266820617 42.063 35.67047511371472 139.73905506118555 42.063 35.67046666558176 139.73901763530634 42.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7256651b-d3ab-48f0-ba9f-3e61436c40f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7256651b-d3ab-48f0-ba9f-3e61436c40f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7256651b-d3ab-48f0-ba9f-3e61436c40f7">
											<gml:posList>35.67047165958232 139.73905266820617 41.418 35.6704647129264 139.73902187937136 41.418 35.67044638386892 139.73902809788817 41.418 35.670453330514604 139.73905887567022 41.418 35.67047165958232 139.73905266820617 41.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4135b669-e572-41b2-9bf4-e2de9d676c76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4135b669-e572-41b2-9bf4-e2de9d676c76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4135b669-e572-41b2-9bf4-e2de9d676c76">
											<gml:posList>35.67045136883542 139.7390631086979 42.063 35.670453330514604 139.73905887567022 42.063 35.67044638386892 139.73902809788817 42.063 35.67044292071359 139.73902569387516 42.063 35.67045136883542 139.7390631086979 42.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02d8e062-8af4-4833-a3af-133b4df96618">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02d8e062-8af4-4833-a3af-133b4df96618">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02d8e062-8af4-4833-a3af-133b4df96618">
											<gml:posList>35.6706233343323 139.73903055191326 35.126 35.670626638475184 139.739025577195 35.126 35.6704912058354 139.73906991054886 35.126 35.670496454683935 139.73907356069498 35.126 35.6706233343323 139.73903055191326 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e884e57d-7e6f-4a02-87d9-5e3af0bc4f06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e884e57d-7e6f-4a02-87d9-5e3af0bc4f06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e884e57d-7e6f-4a02-87d9-5e3af0bc4f06">
											<gml:posList>35.67047511371472 139.73905506118555 42.063 35.67047165958232 139.73905266820617 42.063 35.670453330514604 139.73905887567022 42.063 35.67045136883542 139.7390631086979 42.063 35.67047511371472 139.73905506118555 42.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-04e9aa2e-5533-4687-a358-81d2e0fe0b4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04e9aa2e-5533-4687-a358-81d2e0fe0b4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04e9aa2e-5533-4687-a358-81d2e0fe0b4f">
											<gml:posList>35.67044656240402 139.7391295134688 35.126 35.67044954091631 139.73912308104073 35.126 35.67042301144767 139.73900531484134 35.126 35.67041777164536 139.73900170887745 35.126 35.67044656240402 139.7391295134688 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84577301-ecad-4931-b57b-90a26127d2b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84577301-ecad-4931-b57b-90a26127d2b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84577301-ecad-4931-b57b-90a26127d2b5">
											<gml:posList>35.670496454683935 139.73907356069498 35.126 35.6704912058354 139.73906991054886 35.126 35.67049943675838 139.73910623207274 35.126 35.670504685614446 139.73910989326788 35.126 35.670496454683935 139.73907356069498 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-868d8f6f-d602-4168-934e-d50443548e03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-868d8f6f-d602-4168-934e-d50443548e03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-868d8f6f-d602-4168-934e-d50443548e03">
											<gml:posList>35.670504685614446 139.73910989326788 35.126 35.67049943675838 139.73910623207274 35.126 35.67044954091631 139.73912308104073 35.126 35.67044656240402 139.7391295134688 35.126 35.670504685614446 139.73910989326788 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14769589-380c-4997-8cb6-eeb934cc63e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14769589-380c-4997-8cb6-eeb934cc63e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14769589-380c-4997-8cb6-eeb934cc63e9">
											<gml:posList>35.6706233343323 139.73903055191326 35.126 35.67062586708447 139.73904192661618 35.126 35.67062884558332 139.7390354831242 35.126 35.670626638475184 139.739025577195 35.126 35.6706233343323 139.73903055191326 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2acf9386-96ef-4cba-bb90-f2cdb428720a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2acf9386-96ef-4cba-bb90-f2cdb428720a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2acf9386-96ef-4cba-bb90-f2cdb428720a">
											<gml:posList>35.67064919377776 139.73890282631186 35.126 35.67061179670666 139.7389154631293 35.126 35.67061305352895 139.73892045457293 35.126 35.67065443360883 139.73890646541855 35.126 35.67064919377776 139.73890282631186 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c30ebdca-d89d-4ead-bef5-79597373d57c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c30ebdca-d89d-4ead-bef5-79597373d57c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c30ebdca-d89d-4ead-bef5-79597373d57c">
											<gml:posList>35.67064919377776 139.73890282631186 35.126 35.67065443360883 139.73890646541855 35.126 35.67065126789072 139.73889255081315 35.126 35.670646028059224 139.73888891170753 35.126 35.67064919377776 139.73890282631186 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-227a955d-9625-4c9b-8a5f-bd20bc3f7eea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-227a955d-9625-4c9b-8a5f-bd20bc3f7eea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-227a955d-9625-4c9b-8a5f-bd20bc3f7eea">
											<gml:posList>35.67065512949235 139.73888580802327 35.126 35.670646028059224 139.73888891170753 35.126 35.67065126789072 139.73889255081315 35.126 35.67066028821777 139.73888946931723 35.126 35.67065512949235 139.73888580802327 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a9f004b-e86b-4d14-b584-283045e38ac1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a9f004b-e86b-4d14-b584-283045e38ac1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a9f004b-e86b-4d14-b584-283045e38ac1">
											<gml:posList>35.67065512949235 139.73888580802327 35.126 35.67066028821777 139.73888946931723 35.126 35.670656669203304 139.73887223031002 35.126 35.67065151048604 139.73886858006364 35.126 35.67065512949235 139.73888580802327 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c57b15e-393b-497f-a8e7-e728f35d657a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c57b15e-393b-497f-a8e7-e728f35d657a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c57b15e-393b-497f-a8e7-e728f35d657a">
											<gml:posList>35.67069534454009 139.7390184267458 35.126 35.67069830501885 139.7390119943148 35.126 35.67062884558332 139.7390354831242 35.126 35.67062586708447 139.73904192661618 35.126 35.67069534454009 139.7390184267458 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee548cb0-c6e0-46b3-9963-38d3ac35a9fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee548cb0-c6e0-46b3-9963-38d3ac35a9fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee548cb0-c6e0-46b3-9963-38d3ac35a9fd">
											<gml:posList>35.67065151048604 139.73886858006364 35.126 35.670656669203304 139.73887223031002 35.126 35.67070896186954 139.7388543731041 35.126 35.670711886301966 139.7388479628011 35.126 35.67065151048604 139.73886858006364 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b1bb92f-d346-4e29-969a-9fe86da5a55e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b1bb92f-d346-4e29-969a-9fe86da5a55e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b1bb92f-d346-4e29-969a-9fe86da5a55e">
											<gml:posList>35.67069534454009 139.7390184267458 35.126 35.67070529414818 139.73906248979497 35.126 35.6707082546293 139.73905605736485 35.126 35.67069830501885 139.7390119943148 35.126 35.67069534454009 139.7390184267458 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-059a3420-b45f-48a8-a52b-9062fe08221c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-059a3420-b45f-48a8-a52b-9062fe08221c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-059a3420-b45f-48a8-a52b-9062fe08221c">
											<gml:posList>35.670701048835355 139.73893612507453 35.126 35.670695790977774 139.73893248598503 35.126 35.67070811035726 139.7389869408074 35.126 35.67071108887043 139.73898051939935 35.126 35.670701048835355 139.73893612507453 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b15a09c0-1c97-4ba2-9093-fc11dfd74ab5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b15a09c0-1c97-4ba2-9093-fc11dfd74ab5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b15a09c0-1c97-4ba2-9093-fc11dfd74ab5">
											<gml:posList>35.670701048835355 139.73893612507453 35.126 35.67073051591149 139.73892614870414 35.126 35.67072520397995 139.73892252072397 35.126 35.670695790977774 139.73893248598503 35.126 35.670701048835355 139.73893612507453 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f54ee680-739c-4e90-b098-636275cc49c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f54ee680-739c-4e90-b098-636275cc49c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f54ee680-739c-4e90-b098-636275cc49c2">
											<gml:posList>35.670711886301966 139.7388479628011 35.126 35.67070896186954 139.7388543731041 35.126 35.67072520397995 139.73892252072397 35.126 35.67073051591149 139.73892614870414 35.126 35.670711886301966 139.7388479628011 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43df0859-4a60-47fb-8757-88bc0f4b32bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43df0859-4a60-47fb-8757-88bc0f4b32bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43df0859-4a60-47fb-8757-88bc0f4b32bb">
											<gml:posList>35.67071108887043 139.73898051939935 35.126 35.67070811035726 139.7389869408074 35.126 35.67073991138561 139.73897618846644 35.126 35.670742898911904 139.73896976704484 35.126 35.67071108887043 139.73898051939935 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-637681d0-2a61-4c1e-a06d-b95b94d7f1ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-637681d0-2a61-4c1e-a06d-b95b94d7f1ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-637681d0-2a61-4c1e-a06d-b95b94d7f1ca">
											<gml:posList>35.67075963253338 139.73904408902712 35.126 35.67075438368416 139.73904043887097 35.126 35.6707082546293 139.73905605736485 35.126 35.67070529414818 139.73906248979497 35.126 35.67075963253338 139.73904408902712 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7be52170-cd61-4685-862a-7b369240a4c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7be52170-cd61-4685-862a-7b369240a4c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7be52170-cd61-4685-862a-7b369240a4c5">
											<gml:posList>35.670742898911904 139.73896976704484 35.126 35.67073991138561 139.73897618846644 35.126 35.67075438368416 139.73904043887097 35.126 35.67075963253338 139.73904408902712 35.126 35.670742898911904 139.73896976704484 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d69f2d05-9de2-4099-9d54-b7f4ed0f3160">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d69f2d05-9de2-4099-9d54-b7f4ed0f3160">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d69f2d05-9de2-4099-9d54-b7f4ed0f3160">
											<gml:posList>35.67041777164536 139.73900170887745 32.672 35.67041440681407 139.73898674514857 32.672 35.67041440681407 139.73898674514857 30.097 35.67040947717922 139.73896485725547 30.097 35.67040947717922 139.73896485725547 18.49 35.67044656240402 139.7391295134688 18.49 35.67044656240402 139.7391295134688 35.126 35.67041777164536 139.73900170887745 35.126 35.67041777164536 139.73900170887745 32.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2394165d-d994-45b5-aea2-7e1603e53dbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2394165d-d994-45b5-aea2-7e1603e53dbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2394165d-d994-45b5-aea2-7e1603e53dbe">
											<gml:posList>35.67044954091631 139.73912308104073 35.126 35.67044954091631 139.73912308104073 34.454 35.67042301144767 139.73900531484134 34.454 35.67042301144767 139.73900531484134 35.126 35.67044954091631 139.73912308104073 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3eca0550-6627-4b4c-a347-492ad5176582">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3eca0550-6627-4b4c-a347-492ad5176582">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3eca0550-6627-4b4c-a347-492ad5176582">
											<gml:posList>35.67045136883542 139.7390631086979 42.063 35.67044292071359 139.73902569387516 42.063 35.67044292071359 139.73902569387516 34.454 35.67045136883542 139.7390631086979 34.454 35.67045136883542 139.7390631086979 42.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c170a8c-8c62-41a2-b45c-7b88e8f96ed1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c170a8c-8c62-41a2-b45c-7b88e8f96ed1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c170a8c-8c62-41a2-b45c-7b88e8f96ed1">
											<gml:posList>35.670453330514604 139.73905887567022 42.063 35.670453330514604 139.73905887567022 41.418 35.67044638386892 139.73902809788817 41.418 35.67044638386892 139.73902809788817 42.063 35.670453330514604 139.73905887567022 42.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6605a1bd-c6c5-40f8-bf24-856056a5f48b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6605a1bd-c6c5-40f8-bf24-856056a5f48b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6605a1bd-c6c5-40f8-bf24-856056a5f48b">
											<gml:posList>35.67044292071359 139.73902569387516 42.063 35.67046666558176 139.73901763530634 42.063 35.67046666558176 139.73901763530634 34.454 35.67044292071359 139.73902569387516 34.454 35.67044292071359 139.73902569387516 42.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ceed47c7-f9f2-462a-a606-1eaaca8b6a8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceed47c7-f9f2-462a-a606-1eaaca8b6a8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceed47c7-f9f2-462a-a606-1eaaca8b6a8f">
											<gml:posList>35.67044638386892 139.73902809788817 42.063 35.67044638386892 139.73902809788817 41.418 35.6704647129264 139.73902187937136 41.418 35.6704647129264 139.73902187937136 42.063 35.67044638386892 139.73902809788817 42.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b933f3e3-b504-44c2-bad2-f2235701132d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b933f3e3-b504-44c2-bad2-f2235701132d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b933f3e3-b504-44c2-bad2-f2235701132d">
											<gml:posList>35.67047165958232 139.73905266820617 42.063 35.67047165958232 139.73905266820617 41.418 35.670453330514604 139.73905887567022 41.418 35.670453330514604 139.73905887567022 42.063 35.67047165958232 139.73905266820617 42.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89fce20e-e3cc-4ad2-970f-76aa58640298">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89fce20e-e3cc-4ad2-970f-76aa58640298">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89fce20e-e3cc-4ad2-970f-76aa58640298">
											<gml:posList>35.67047511371472 139.73905506118555 42.063 35.67045136883542 139.7390631086979 42.063 35.67045136883542 139.7390631086979 34.454 35.67047511371472 139.73905506118555 34.454 35.67047511371472 139.73905506118555 42.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-796509bf-01df-481f-8998-3d1006b3a326">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-796509bf-01df-481f-8998-3d1006b3a326">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-796509bf-01df-481f-8998-3d1006b3a326">
											<gml:posList>35.6704647129264 139.73902187937136 42.063 35.6704647129264 139.73902187937136 41.418 35.67047165958232 139.73905266820617 41.418 35.67047165958232 139.73905266820617 42.063 35.6704647129264 139.73902187937136 42.063</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f606b50-9a70-406d-8950-1d30d532b3e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f606b50-9a70-406d-8950-1d30d532b3e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f606b50-9a70-406d-8950-1d30d532b3e7">
											<gml:posList>35.67041440681407 139.73898674514857 30.097 35.67041440681407 139.73898674514857 32.672 35.67052427308886 139.73894957769213 32.672 35.67052427308886 139.73894957769213 30.097 35.67041440681407 139.73898674514857 30.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca4dc8d9-6d0c-4b2a-8515-59d9c1819280">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca4dc8d9-6d0c-4b2a-8515-59d9c1819280">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca4dc8d9-6d0c-4b2a-8515-59d9c1819280">
											<gml:posList>35.67046666558176 139.73901763530634 34.454 35.67046666558176 139.73901763530634 42.063 35.67047511371472 139.73905506118555 42.063 35.67047511371472 139.73905506118555 34.454 35.67046666558176 139.73901763530634 34.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac2f12cf-2e8b-4b0d-8e9a-73f667854abf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac2f12cf-2e8b-4b0d-8e9a-73f667854abf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac2f12cf-2e8b-4b0d-8e9a-73f667854abf">
											<gml:posList>35.67041777164536 139.73900170887745 32.672 35.67041777164536 139.73900170887745 35.126 35.67052751130843 139.73896400032126 35.126 35.67052751130843 139.73896400032126 32.672 35.67041777164536 139.73900170887745 32.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ac08a07-829c-4ed7-93fc-5bff577e175d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ac08a07-829c-4ed7-93fc-5bff577e175d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ac08a07-829c-4ed7-93fc-5bff577e175d">
											<gml:posList>35.67049943675838 139.73910623207274 35.126 35.67049943675838 139.73910623207274 34.454 35.67044954091631 139.73912308104073 34.454 35.67044954091631 139.73912308104073 35.126 35.67049943675838 139.73910623207274 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46b6f5c9-b13c-4a42-a60e-007fc76bbf52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46b6f5c9-b13c-4a42-a60e-007fc76bbf52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46b6f5c9-b13c-4a42-a60e-007fc76bbf52">
											<gml:posList>35.67044656240402 139.7391295134688 18.49 35.670504685614446 139.73910989326788 18.49 35.670504685614446 139.73910989326788 35.126 35.67044656240402 139.7391295134688 35.126 35.67044656240402 139.7391295134688 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b493c90-3de4-41e7-8158-98bb1a9e2088">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b493c90-3de4-41e7-8158-98bb1a9e2088">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b493c90-3de4-41e7-8158-98bb1a9e2088">
											<gml:posList>35.67042301144767 139.73900531484134 35.126 35.67042301144767 139.73900531484134 34.454 35.67053274211538 139.73896762839075 34.454 35.67053274211538 139.73896762839075 35.126 35.67042301144767 139.73900531484134 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-152aa52b-ac31-4a83-b8b0-f6f1780ff3e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-152aa52b-ac31-4a83-b8b0-f6f1780ff3e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-152aa52b-ac31-4a83-b8b0-f6f1780ff3e5">
											<gml:posList>35.67056825696478 139.73891109588843 18.49 35.67040947717922 139.73896485725547 18.49 35.67040947717922 139.73896485725547 30.097 35.67056825696478 139.73891109588843 30.097 35.67056825696478 139.73891109588843 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b9e6ded-c0af-4c78-9c55-2e913291d097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b9e6ded-c0af-4c78-9c55-2e913291d097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b9e6ded-c0af-4c78-9c55-2e913291d097">
											<gml:posList>35.6704912058354 139.73906991054886 35.126 35.6704912058354 139.73906991054886 34.454 35.67049943675838 139.73910623207274 34.454 35.67049943675838 139.73910623207274 35.126 35.6704912058354 139.73906991054886 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03ff053c-17e1-4670-b75c-3055cb85075d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03ff053c-17e1-4670-b75c-3055cb85075d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03ff053c-17e1-4670-b75c-3055cb85075d">
											<gml:posList>35.670504685614446 139.73910989326788 18.49 35.670496454683935 139.73907356069498 18.49 35.670496454683935 139.73907356069498 35.126 35.670504685614446 139.73910989326788 35.126 35.670504685614446 139.73910989326788 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4b4ab4b-ef48-4a65-8843-324156f10aaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4b4ab4b-ef48-4a65-8843-324156f10aaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4b4ab4b-ef48-4a65-8843-324156f10aaf">
											<gml:posList>35.67052751130843 139.73896400032126 32.672 35.67052751130843 139.73896400032126 35.126 35.67052427308886 139.73894957769213 35.126 35.67052427308886 139.73894957769213 32.672 35.67052751130843 139.73896400032126 32.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ccf0ac8-d2e7-49e9-a8a6-49bd4baf1f2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ccf0ac8-d2e7-49e9-a8a6-49bd4baf1f2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ccf0ac8-d2e7-49e9-a8a6-49bd4baf1f2b">
											<gml:posList>35.67053274211538 139.73896762839075 35.126 35.67053274211538 139.73896762839075 34.454 35.67052947675984 139.7389530842834 34.454 35.67052947675984 139.7389530842834 35.126 35.67053274211538 139.73896762839075 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7c5639d-a066-41b0-927d-b13beb9764be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7c5639d-a066-41b0-927d-b13beb9764be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7c5639d-a066-41b0-927d-b13beb9764be">
											<gml:posList>35.670572869899324 139.73893141562183 35.126 35.670572869899324 139.73893141562183 30.097 35.67052427308886 139.73894957769213 30.097 35.67052427308886 139.73894957769213 32.672 35.67052427308886 139.73894957769213 35.126 35.670572869899324 139.73893141562183 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2895461-995e-4488-a0b0-52f445265bdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2895461-995e-4488-a0b0-52f445265bdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2895461-995e-4488-a0b0-52f445265bdc">
											<gml:posList>35.67052947675984 139.7389530842834 35.126 35.67052947675984 139.7389530842834 34.454 35.67057410869352 139.73893640708454 34.454 35.67057410869352 139.73893640708454 35.126 35.67052947675984 139.7389530842834 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f0e2c81-8c51-44cd-8634-1e072c50dac1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f0e2c81-8c51-44cd-8634-1e072c50dac1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f0e2c81-8c51-44cd-8634-1e072c50dac1">
											<gml:posList>35.670626638475184 139.739025577195 35.126 35.670626638475184 139.739025577195 34.454 35.6704912058354 139.73906991054886 34.454 35.6704912058354 139.73906991054886 35.126 35.670626638475184 139.739025577195 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e58af0d-c554-42c9-a62f-1351c34fcdc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e58af0d-c554-42c9-a62f-1351c34fcdc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e58af0d-c554-42c9-a62f-1351c34fcdc9">
											<gml:posList>35.6706233343323 139.73903055191326 35.126 35.670496454683935 139.73907356069498 35.126 35.670496454683935 139.73907356069498 18.49 35.6706233343323 139.73903055191326 18.49 35.6706233343323 139.73903055191326 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32c7f0a7-91ad-4625-a45c-d7c9facaff0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32c7f0a7-91ad-4625-a45c-d7c9facaff0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32c7f0a7-91ad-4625-a45c-d7c9facaff0a">
											<gml:posList>35.670572869899324 139.73893141562183 18.49 35.67056825696478 139.73891109588843 18.49 35.67056825696478 139.73891109588843 30.097 35.670572869899324 139.73893141562183 30.097 35.670572869899324 139.73893141562183 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e012a4bd-a312-4efa-b208-a5d363cb155d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e012a4bd-a312-4efa-b208-a5d363cb155d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e012a4bd-a312-4efa-b208-a5d363cb155d">
											<gml:posList>35.6705883693442 139.73892609515428 35.126 35.6705883693442 139.73892609515428 18.49 35.670572869899324 139.73893141562183 18.49 35.670572869899324 139.73893141562183 30.097 35.670572869899324 139.73893141562183 35.126 35.6705883693442 139.73892609515428 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bbbf3da-c6fd-4f9a-bd5c-234c440b61c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bbbf3da-c6fd-4f9a-bd5c-234c440b61c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bbbf3da-c6fd-4f9a-bd5c-234c440b61c8">
											<gml:posList>35.67057410869352 139.73893640708454 35.126 35.67057410869352 139.73893640708454 34.454 35.67058968924478 139.73893106442978 34.454 35.67058968924478 139.73893106442978 35.126 35.67057410869352 139.73893640708454 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74ae51ea-d50f-40ae-aed3-cdefb355f06a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74ae51ea-d50f-40ae-aed3-cdefb355f06a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74ae51ea-d50f-40ae-aed3-cdefb355f06a">
											<gml:posList>35.67061179670666 139.7389154631293 18.49 35.6705883693442 139.73892609515428 18.49 35.6705883693442 139.73892609515428 35.126 35.67061179670666 139.7389154631293 35.126 35.67061179670666 139.7389154631293 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5f9aab5-0e28-42b7-b93d-fd6b880f9e0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5f9aab5-0e28-42b7-b93d-fd6b880f9e0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5f9aab5-0e28-42b7-b93d-fd6b880f9e0c">
											<gml:posList>35.67058968924478 139.73893106442978 35.126 35.67058968924478 139.73893106442978 34.454 35.67061305352895 139.73892045457293 34.454 35.67061305352895 139.73892045457293 35.126 35.67058968924478 139.73893106442978 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e491c3e2-9d68-4d52-858b-e04894115dad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e491c3e2-9d68-4d52-858b-e04894115dad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e491c3e2-9d68-4d52-858b-e04894115dad">
											<gml:posList>35.6706233343323 139.73903055191326 18.49 35.67062586708447 139.73904192661618 18.49 35.67062586708447 139.73904192661618 35.126 35.6706233343323 139.73903055191326 35.126 35.6706233343323 139.73903055191326 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec5f7a2d-ed75-4a18-b928-868eb2c3755c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec5f7a2d-ed75-4a18-b928-868eb2c3755c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec5f7a2d-ed75-4a18-b928-868eb2c3755c">
											<gml:posList>35.67062884558332 139.7390354831242 35.126 35.67062884558332 139.7390354831242 34.454 35.670626638475184 139.739025577195 34.454 35.670626638475184 139.739025577195 35.126 35.67062884558332 139.7390354831242 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-537ea436-dfdf-457b-96cc-0bd5dccb319d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-537ea436-dfdf-457b-96cc-0bd5dccb319d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-537ea436-dfdf-457b-96cc-0bd5dccb319d">
											<gml:posList>35.67064919377776 139.73890282631186 18.49 35.67061179670666 139.7389154631293 18.49 35.67061179670666 139.7389154631293 35.126 35.67064919377776 139.73890282631186 35.126 35.67064919377776 139.73890282631186 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a485152-473e-4947-8a9a-2f7e6b9c3486">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a485152-473e-4947-8a9a-2f7e6b9c3486">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a485152-473e-4947-8a9a-2f7e6b9c3486">
											<gml:posList>35.67061305352895 139.73892045457293 35.126 35.67061305352895 139.73892045457293 34.454 35.67065443360883 139.73890646541855 34.454 35.67065443360883 139.73890646541855 35.126 35.67061305352895 139.73892045457293 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2f08977-306f-4ed9-87ec-e1931ace8dfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2f08977-306f-4ed9-87ec-e1931ace8dfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2f08977-306f-4ed9-87ec-e1931ace8dfa">
											<gml:posList>35.670646028059224 139.73888891170753 18.49 35.67064919377776 139.73890282631186 18.49 35.67064919377776 139.73890282631186 35.126 35.670646028059224 139.73888891170753 35.126 35.670646028059224 139.73888891170753 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a18d419-fe45-4552-b0d2-8a154cf20031">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a18d419-fe45-4552-b0d2-8a154cf20031">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a18d419-fe45-4552-b0d2-8a154cf20031">
											<gml:posList>35.67065512949235 139.73888580802327 18.49 35.670646028059224 139.73888891170753 18.49 35.670646028059224 139.73888891170753 35.126 35.67065512949235 139.73888580802327 35.126 35.67065512949235 139.73888580802327 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56d4a030-ec23-4df7-bc98-e1555b489aab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56d4a030-ec23-4df7-bc98-e1555b489aab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56d4a030-ec23-4df7-bc98-e1555b489aab">
											<gml:posList>35.67065443360883 139.73890646541855 35.126 35.67065443360883 139.73890646541855 34.454 35.67065126789072 139.73889255081315 34.454 35.67065126789072 139.73889255081315 35.126 35.67065443360883 139.73890646541855 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a98390cc-7de8-4683-8e87-8879118b11d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a98390cc-7de8-4683-8e87-8879118b11d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a98390cc-7de8-4683-8e87-8879118b11d6">
											<gml:posList>35.67065151048604 139.73886858006364 18.49 35.67065512949235 139.73888580802327 18.49 35.67065512949235 139.73888580802327 35.126 35.67065151048604 139.73886858006364 35.126 35.67065151048604 139.73886858006364 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2553ec7e-c9a7-47b7-83f2-0b69c7a1a727">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2553ec7e-c9a7-47b7-83f2-0b69c7a1a727">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2553ec7e-c9a7-47b7-83f2-0b69c7a1a727">
											<gml:posList>35.67065126789072 139.73889255081315 35.126 35.67065126789072 139.73889255081315 34.454 35.67066028821777 139.73888946931723 34.454 35.67066028821777 139.73888946931723 35.126 35.67065126789072 139.73889255081315 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df892f62-4ef2-4fd9-8122-e184080156b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df892f62-4ef2-4fd9-8122-e184080156b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df892f62-4ef2-4fd9-8122-e184080156b1">
											<gml:posList>35.67066028821777 139.73888946931723 35.126 35.67066028821777 139.73888946931723 34.454 35.670656669203304 139.73887223031002 34.454 35.670656669203304 139.73887223031002 35.126 35.67066028821777 139.73888946931723 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb8b29e6-67dc-4d6e-9e64-05e94fde0589">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb8b29e6-67dc-4d6e-9e64-05e94fde0589">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb8b29e6-67dc-4d6e-9e64-05e94fde0589">
											<gml:posList>35.67062586708447 139.73904192661618 18.49 35.67069534454009 139.7390184267458 18.49 35.67069534454009 139.7390184267458 35.126 35.67062586708447 139.73904192661618 35.126 35.67062586708447 139.73904192661618 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9eeff467-6a3f-4f6e-ad95-ad7903a4fba9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9eeff467-6a3f-4f6e-ad95-ad7903a4fba9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9eeff467-6a3f-4f6e-ad95-ad7903a4fba9">
											<gml:posList>35.67069830501885 139.7390119943148 35.126 35.67069830501885 139.7390119943148 34.454 35.67062884558332 139.7390354831242 34.454 35.67062884558332 139.7390354831242 35.126 35.67069830501885 139.7390119943148 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da23849b-0978-4ac1-a40f-e24383483a2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da23849b-0978-4ac1-a40f-e24383483a2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da23849b-0978-4ac1-a40f-e24383483a2b">
											<gml:posList>35.670711886301966 139.7388479628011 18.49 35.67065151048604 139.73886858006364 18.49 35.67065151048604 139.73886858006364 35.126 35.670711886301966 139.7388479628011 35.126 35.670711886301966 139.7388479628011 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e970b097-174b-45ea-aa30-23673e9ea61d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e970b097-174b-45ea-aa30-23673e9ea61d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e970b097-174b-45ea-aa30-23673e9ea61d">
											<gml:posList>35.670656669203304 139.73887223031002 35.126 35.670656669203304 139.73887223031002 34.454 35.67070896186954 139.7388543731041 34.454 35.67070896186954 139.7388543731041 35.126 35.670656669203304 139.73887223031002 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef7a6a99-9d67-4b54-9c65-99268a5a230d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef7a6a99-9d67-4b54-9c65-99268a5a230d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef7a6a99-9d67-4b54-9c65-99268a5a230d">
											<gml:posList>35.67069534454009 139.7390184267458 18.49 35.67070529414818 139.73906248979497 18.49 35.67070529414818 139.73906248979497 35.126 35.67069534454009 139.7390184267458 35.126 35.67069534454009 139.7390184267458 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51df76d1-f06d-4644-beb1-520a4b5d8b0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51df76d1-f06d-4644-beb1-520a4b5d8b0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51df76d1-f06d-4644-beb1-520a4b5d8b0a">
											<gml:posList>35.670695790977774 139.73893248598503 35.126 35.670695790977774 139.73893248598503 34.454 35.67070811035726 139.7389869408074 34.454 35.67070811035726 139.7389869408074 35.126 35.670695790977774 139.73893248598503 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5ed9c7e-36d9-4fa4-97ee-fa62f61f8b5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5ed9c7e-36d9-4fa4-97ee-fa62f61f8b5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5ed9c7e-36d9-4fa4-97ee-fa62f61f8b5a">
											<gml:posList>35.6707082546293 139.73905605736485 35.126 35.6707082546293 139.73905605736485 34.454 35.67069830501885 139.7390119943148 34.454 35.67069830501885 139.7390119943148 35.126 35.6707082546293 139.73905605736485 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cd7e98d-f87f-4172-ba46-0ed206ba50ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cd7e98d-f87f-4172-ba46-0ed206ba50ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cd7e98d-f87f-4172-ba46-0ed206ba50ef">
											<gml:posList>35.67071108887043 139.73898051939935 18.49 35.670701048835355 139.73893612507453 18.49 35.670701048835355 139.73893612507453 35.126 35.67071108887043 139.73898051939935 35.126 35.67071108887043 139.73898051939935 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2abee64-90de-4018-8697-5c8444965ea0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2abee64-90de-4018-8697-5c8444965ea0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2abee64-90de-4018-8697-5c8444965ea0">
											<gml:posList>35.67072520397995 139.73892252072397 35.126 35.67072520397995 139.73892252072397 34.454 35.670695790977774 139.73893248598503 34.454 35.670695790977774 139.73893248598503 35.126 35.67072520397995 139.73892252072397 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3e13ffa-72b3-4af2-810b-85714d04d110">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3e13ffa-72b3-4af2-810b-85714d04d110">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3e13ffa-72b3-4af2-810b-85714d04d110">
											<gml:posList>35.670701048835355 139.73893612507453 18.49 35.67073051591149 139.73892614870414 18.49 35.67073051591149 139.73892614870414 35.126 35.670701048835355 139.73893612507453 35.126 35.670701048835355 139.73893612507453 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1e38966-6e26-47b9-82f0-7f2a355b4f32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1e38966-6e26-47b9-82f0-7f2a355b4f32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1e38966-6e26-47b9-82f0-7f2a355b4f32">
											<gml:posList>35.67070896186954 139.7388543731041 35.126 35.67070896186954 139.7388543731041 34.454 35.67072520397995 139.73892252072397 34.454 35.67072520397995 139.73892252072397 35.126 35.67070896186954 139.7388543731041 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e3e027c-ab96-4949-9e59-360696ef83f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e3e027c-ab96-4949-9e59-360696ef83f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e3e027c-ab96-4949-9e59-360696ef83f2">
											<gml:posList>35.67073051591149 139.73892614870414 18.49 35.670711886301966 139.7388479628011 18.49 35.670711886301966 139.7388479628011 35.126 35.67073051591149 139.73892614870414 35.126 35.67073051591149 139.73892614870414 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f59a526f-3081-42aa-b880-abfbe160aae9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f59a526f-3081-42aa-b880-abfbe160aae9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f59a526f-3081-42aa-b880-abfbe160aae9">
											<gml:posList>35.67070811035726 139.7389869408074 35.126 35.67070811035726 139.7389869408074 34.454 35.67073991138561 139.73897618846644 34.454 35.67073991138561 139.73897618846644 35.126 35.67070811035726 139.7389869408074 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab31edb8-d606-4d68-9c78-b5f9c89df5c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab31edb8-d606-4d68-9c78-b5f9c89df5c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab31edb8-d606-4d68-9c78-b5f9c89df5c2">
											<gml:posList>35.670742898911904 139.73896976704484 18.49 35.67071108887043 139.73898051939935 18.49 35.67071108887043 139.73898051939935 35.126 35.670742898911904 139.73896976704484 35.126 35.670742898911904 139.73896976704484 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5afddea8-010a-4fd9-92d2-a0ce4412ce3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5afddea8-010a-4fd9-92d2-a0ce4412ce3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5afddea8-010a-4fd9-92d2-a0ce4412ce3b">
											<gml:posList>35.67075438368416 139.73904043887097 35.126 35.67075438368416 139.73904043887097 34.454 35.6707082546293 139.73905605736485 34.454 35.6707082546293 139.73905605736485 35.126 35.67075438368416 139.73904043887097 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3b24b42-6cbc-4638-838f-bdfe75d43a9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3b24b42-6cbc-4638-838f-bdfe75d43a9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3b24b42-6cbc-4638-838f-bdfe75d43a9c">
											<gml:posList>35.67070529414818 139.73906248979497 18.49 35.67075963253338 139.73904408902712 18.49 35.67075963253338 139.73904408902712 35.126 35.67070529414818 139.73906248979497 35.126 35.67070529414818 139.73906248979497 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e758654c-24a7-4496-b46c-a0b64703459c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e758654c-24a7-4496-b46c-a0b64703459c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e758654c-24a7-4496-b46c-a0b64703459c">
											<gml:posList>35.67073991138561 139.73897618846644 35.126 35.67073991138561 139.73897618846644 34.454 35.67075438368416 139.73904043887097 34.454 35.67075438368416 139.73904043887097 35.126 35.67073991138561 139.73897618846644 35.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3643fcc0-7280-45b8-bef0-3c702396619b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3643fcc0-7280-45b8-bef0-3c702396619b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3643fcc0-7280-45b8-bef0-3c702396619b">
											<gml:posList>35.67075963253338 139.73904408902712 18.49 35.670742898911904 139.73896976704484 18.49 35.670742898911904 139.73896976704484 35.126 35.67075963253338 139.73904408902712 35.126 35.67075963253338 139.73904408902712 18.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-926</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">470.99455</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>