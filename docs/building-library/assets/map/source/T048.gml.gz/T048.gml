<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0b630ff1-c58b-4175-a5e7-20d19aca40a6">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672317299655234 139.7404299769672 0 35.67235256815108 139.740380381359 0 35.67233671796307 139.74036345436056 0 35.67230144948263 139.74041306101287 0 35.672317299655234 139.7404299769672 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672317299655234 139.7404299769672 7.42 35.67230144948263 139.74041306101287 7.42 35.67233671796307 139.74036345436056 7.42 35.67235256815108 139.740380381359 7.42 35.672317299655234 139.7404299769672 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672317299655234 139.7404299769672 7.42 35.67235256815108 139.740380381359 7.42 35.67235256815108 139.740380381359 11.31 35.672317299655234 139.7404299769672 11.31 35.672317299655234 139.7404299769672 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67235256815108 139.740380381359 7.42 35.67233671796307 139.74036345436056 7.42 35.67233671796307 139.74036345436056 11.31 35.67235256815108 139.740380381359 11.31 35.67235256815108 139.740380381359 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67233671796307 139.74036345436056 7.42 35.67230144948263 139.74041306101287 7.42 35.67230144948263 139.74041306101287 11.31 35.67233671796307 139.74036345436056 11.31 35.67233671796307 139.74036345436056 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67230144948263 139.74041306101287 7.42 35.672317299655234 139.7404299769672 7.42 35.672317299655234 139.7404299769672 11.31 35.67230144948263 139.74041306101287 11.31 35.67230144948263 139.74041306101287 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672317299655234 139.7404299769672 11.31 35.67235256815108 139.740380381359 11.31 35.67233671796307 139.74036345436056 11.31 35.67230144948263 139.74041306101287 11.31 35.672317299655234 139.7404299769672 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-66d93697-6970-475c-b6f8-1d6abc9b7ef0"/>
							<gml:surfaceMember xlink:href="#poly-a4ff10d4-b234-4879-81ea-f8603b1a14df"/>
							<gml:surfaceMember xlink:href="#poly-fcf41d25-2403-4c52-82df-456f0d4361c9"/>
							<gml:surfaceMember xlink:href="#poly-a9aaa780-cc5e-45eb-bf9b-375ba85dcda9"/>
							<gml:surfaceMember xlink:href="#poly-4d15dbf3-3309-48fa-9275-ce8e8ea17e95"/>
							<gml:surfaceMember xlink:href="#poly-9b3f5421-25af-46b6-ba84-902914dcb78f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-66d93697-6970-475c-b6f8-1d6abc9b7ef0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66d93697-6970-475c-b6f8-1d6abc9b7ef0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66d93697-6970-475c-b6f8-1d6abc9b7ef0">
											<gml:posList>35.672317299655234 139.7404299769672 7.42 35.6723014494826 139.7404130610129 7.42 35.672336717963056 139.74036345436056 7.42 35.672352568151084 139.740380381359 7.42 35.672317299655234 139.7404299769672 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4ff10d4-b234-4879-81ea-f8603b1a14df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4ff10d4-b234-4879-81ea-f8603b1a14df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4ff10d4-b234-4879-81ea-f8603b1a14df">
											<gml:posList>35.672352568151084 139.740380381359 11.386 35.672336717963056 139.74036345436056 11.386 35.6723014494826 139.7404130610129 11.386 35.672317299655234 139.7404299769672 11.386 35.672352568151084 139.740380381359 11.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcf41d25-2403-4c52-82df-456f0d4361c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcf41d25-2403-4c52-82df-456f0d4361c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcf41d25-2403-4c52-82df-456f0d4361c9">
											<gml:posList>35.672352568151084 139.740380381359 11.386 35.672352568151084 139.740380381359 7.42 35.672336717963056 139.74036345436056 7.42 35.672336717963056 139.74036345436056 11.386 35.672352568151084 139.740380381359 11.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9aaa780-cc5e-45eb-bf9b-375ba85dcda9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9aaa780-cc5e-45eb-bf9b-375ba85dcda9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9aaa780-cc5e-45eb-bf9b-375ba85dcda9">
											<gml:posList>35.672336717963056 139.74036345436056 11.386 35.672336717963056 139.74036345436056 7.42 35.6723014494826 139.7404130610129 7.42 35.6723014494826 139.7404130610129 11.386 35.672336717963056 139.74036345436056 11.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d15dbf3-3309-48fa-9275-ce8e8ea17e95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d15dbf3-3309-48fa-9275-ce8e8ea17e95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d15dbf3-3309-48fa-9275-ce8e8ea17e95">
											<gml:posList>35.672317299655234 139.7404299769672 11.386 35.672317299655234 139.7404299769672 7.42 35.672352568151084 139.740380381359 7.42 35.672352568151084 139.740380381359 11.386 35.672317299655234 139.7404299769672 11.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b3f5421-25af-46b6-ba84-902914dcb78f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b3f5421-25af-46b6-ba84-902914dcb78f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b3f5421-25af-46b6-ba84-902914dcb78f">
											<gml:posList>35.6723014494826 139.7404130610129 11.386 35.6723014494826 139.7404130610129 7.42 35.672317299655234 139.7404299769672 7.42 35.672317299655234 139.7404299769672 11.386 35.6723014494826 139.7404130610129 11.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2358</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.38</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>