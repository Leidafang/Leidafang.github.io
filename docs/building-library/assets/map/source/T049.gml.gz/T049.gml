<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0b712f77-a504-4922-89aa-72385d41d7de">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.673167897167396 139.74458733460895 0 35.673191955167695 139.74457559853107 0 35.67317813290081 139.74453319471593 0 35.6731540749046 139.7445449308045 0 35.673167897167396 139.74458733460895 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673167897167396 139.74458733460895 24.341 35.6731540749046 139.7445449308045 24.341 35.67317813290081 139.74453319471593 24.341 35.673191955167695 139.74457559853107 24.341 35.673167897167396 139.74458733460895 24.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673167897167396 139.74458733460895 24.341 35.673191955167695 139.74457559853107 24.341 35.673191955167695 139.74457559853107 27.341 35.673167897167396 139.74458733460895 27.341 35.673167897167396 139.74458733460895 24.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673191955167695 139.74457559853107 24.341 35.67317813290081 139.74453319471593 24.341 35.67317813290081 139.74453319471593 27.341 35.673191955167695 139.74457559853107 27.341 35.673191955167695 139.74457559853107 24.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67317813290081 139.74453319471593 24.341 35.6731540749046 139.7445449308045 24.341 35.6731540749046 139.7445449308045 27.341 35.67317813290081 139.74453319471593 27.341 35.67317813290081 139.74453319471593 24.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6731540749046 139.7445449308045 24.341 35.673167897167396 139.74458733460895 24.341 35.673167897167396 139.74458733460895 27.341 35.6731540749046 139.7445449308045 27.341 35.6731540749046 139.7445449308045 24.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673167897167396 139.74458733460895 27.341 35.673191955167695 139.74457559853107 27.341 35.67317813290081 139.74453319471593 27.341 35.6731540749046 139.7445449308045 27.341 35.673167897167396 139.74458733460895 27.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1ffa7cdd-e967-4336-bc37-d5e8d70d2464"/>
							<gml:surfaceMember xlink:href="#poly-bff2eb40-3993-493c-84b0-576719d76421"/>
							<gml:surfaceMember xlink:href="#poly-770904dc-8dff-471b-83a2-9917ae7b0a10"/>
							<gml:surfaceMember xlink:href="#poly-5d7a5470-645d-482f-ad8f-70c1c2a0a57e"/>
							<gml:surfaceMember xlink:href="#poly-1386a825-60e1-4eeb-a64e-8be821d4be93"/>
							<gml:surfaceMember xlink:href="#poly-879b990b-0e71-475e-a97d-7740784c63f8"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1ffa7cdd-e967-4336-bc37-d5e8d70d2464">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ffa7cdd-e967-4336-bc37-d5e8d70d2464">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ffa7cdd-e967-4336-bc37-d5e8d70d2464">
											<gml:posList>35.67316789716738 139.74458733460895 24.341 35.6731540749046 139.7445449308045 24.341 35.673178132900794 139.74453319471593 24.341 35.67319195516767 139.74457559853104 24.341 35.67316789716738 139.74458733460895 24.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bff2eb40-3993-493c-84b0-576719d76421">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bff2eb40-3993-493c-84b0-576719d76421">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bff2eb40-3993-493c-84b0-576719d76421">
											<gml:posList>35.6731540749046 139.7445449308045 26.5 35.67316789716738 139.74458733460895 26.5 35.67319195516767 139.74457559853104 26.5 35.673178132900794 139.74453319471593 26.5 35.6731540749046 139.7445449308045 26.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-770904dc-8dff-471b-83a2-9917ae7b0a10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-770904dc-8dff-471b-83a2-9917ae7b0a10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-770904dc-8dff-471b-83a2-9917ae7b0a10">
											<gml:posList>35.673178132900794 139.74453319471593 24.341 35.6731540749046 139.7445449308045 24.341 35.6731540749046 139.7445449308045 26.5 35.673178132900794 139.74453319471593 26.5 35.673178132900794 139.74453319471593 24.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d7a5470-645d-482f-ad8f-70c1c2a0a57e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d7a5470-645d-482f-ad8f-70c1c2a0a57e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d7a5470-645d-482f-ad8f-70c1c2a0a57e">
											<gml:posList>35.67319195516767 139.74457559853104 24.341 35.673178132900794 139.74453319471593 24.341 35.673178132900794 139.74453319471593 26.5 35.67319195516767 139.74457559853104 26.5 35.67319195516767 139.74457559853104 24.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1386a825-60e1-4eeb-a64e-8be821d4be93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1386a825-60e1-4eeb-a64e-8be821d4be93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1386a825-60e1-4eeb-a64e-8be821d4be93">
											<gml:posList>35.6731540749046 139.7445449308045 24.341 35.67316789716738 139.74458733460895 24.341 35.67316789716738 139.74458733460895 26.5 35.6731540749046 139.7445449308045 26.5 35.6731540749046 139.7445449308045 24.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-879b990b-0e71-475e-a97d-7740784c63f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-879b990b-0e71-475e-a97d-7740784c63f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-879b990b-0e71-475e-a97d-7740784c63f8">
											<gml:posList>35.67316789716738 139.74458733460895 24.341 35.67319195516767 139.74457559853104 24.341 35.67319195516767 139.74457559853104 26.5 35.67316789716738 139.74458733460895 26.5 35.67316789716738 139.74458733460895 24.341</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4534</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>