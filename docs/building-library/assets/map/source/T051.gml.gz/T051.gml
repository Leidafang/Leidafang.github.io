<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0bb8ab0f-aab4-4d72-b134-b93c5f2f9917">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">62.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6732347265759 139.73906249812265 0 35.67325597576842 139.73903286809886 0 35.673266616394585 139.73892349367836 0 35.67326837763842 139.73887057811615 0 35.67325922280819 139.7388056345662 0 35.67322977006635 139.73871906354321 0 35.67309165145821 139.73879776810767 0 35.67307463382833 139.73882109656518 0 35.6732347265759 139.73906249812265 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6732347265759 139.73906249812265 7.42 35.67307463382833 139.73882109656518 7.42 35.67309165145821 139.73879776810767 7.42 35.67322977006635 139.73871906354321 7.42 35.67325922280819 139.7388056345662 7.42 35.67326837763842 139.73887057811615 7.42 35.673266616394585 139.73892349367836 7.42 35.67325597576842 139.73903286809886 7.42 35.6732347265759 139.73906249812265 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6732347265759 139.73906249812265 7.42 35.67325597576842 139.73903286809886 7.42 35.67325597576842 139.73903286809886 70.23 35.6732347265759 139.73906249812265 70.23 35.6732347265759 139.73906249812265 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67325597576842 139.73903286809886 7.42 35.673266616394585 139.73892349367836 7.42 35.673266616394585 139.73892349367836 70.23 35.67325597576842 139.73903286809886 70.23 35.67325597576842 139.73903286809886 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673266616394585 139.73892349367836 7.42 35.67326837763842 139.73887057811615 7.42 35.67326837763842 139.73887057811615 70.23 35.673266616394585 139.73892349367836 70.23 35.673266616394585 139.73892349367836 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67326837763842 139.73887057811615 7.42 35.67325922280819 139.7388056345662 7.42 35.67325922280819 139.7388056345662 70.23 35.67326837763842 139.73887057811615 70.23 35.67326837763842 139.73887057811615 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67325922280819 139.7388056345662 7.42 35.67322977006635 139.73871906354321 7.42 35.67322977006635 139.73871906354321 70.23 35.67325922280819 139.7388056345662 70.23 35.67325922280819 139.7388056345662 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67322977006635 139.73871906354321 7.42 35.67309165145821 139.73879776810767 7.42 35.67309165145821 139.73879776810767 70.23 35.67322977006635 139.73871906354321 70.23 35.67322977006635 139.73871906354321 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67309165145821 139.73879776810767 7.42 35.67307463382833 139.73882109656518 7.42 35.67307463382833 139.73882109656518 70.23 35.67309165145821 139.73879776810767 70.23 35.67309165145821 139.73879776810767 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67307463382833 139.73882109656518 7.42 35.6732347265759 139.73906249812265 7.42 35.6732347265759 139.73906249812265 70.23 35.67307463382833 139.73882109656518 70.23 35.67307463382833 139.73882109656518 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6732347265759 139.73906249812265 70.23 35.67325597576842 139.73903286809886 70.23 35.673266616394585 139.73892349367836 70.23 35.67326837763842 139.73887057811615 70.23 35.67325922280819 139.7388056345662 70.23 35.67322977006635 139.73871906354321 70.23 35.67309165145821 139.73879776810767 70.23 35.67307463382833 139.73882109656518 70.23 35.6732347265759 139.73906249812265 70.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0ef612fe-4ae9-4845-b168-4b2d04b38053"/>
							<gml:surfaceMember xlink:href="#poly-3fa65263-94fa-44d1-bac6-c1a83ad2007c"/>
							<gml:surfaceMember xlink:href="#poly-4ffd9c80-c08b-4ccf-a0bb-73dc6c500f9a"/>
							<gml:surfaceMember xlink:href="#poly-6c94aaee-0858-4e1c-9989-2f11561b0d33"/>
							<gml:surfaceMember xlink:href="#poly-a13fe4a8-7e41-4118-99ea-cbf6cb5f904a"/>
							<gml:surfaceMember xlink:href="#poly-4fc51565-59ae-49ed-81d5-162507de16f1"/>
							<gml:surfaceMember xlink:href="#poly-1c80a958-4eb0-4bec-bc3b-fca97d554e16"/>
							<gml:surfaceMember xlink:href="#poly-7d6c2ef2-bb61-41eb-b606-5fbfd51d8ac1"/>
							<gml:surfaceMember xlink:href="#poly-244c5d5d-4f57-4b4e-b836-be1e64953bca"/>
							<gml:surfaceMember xlink:href="#poly-61ec6b6e-a279-4a1b-b2d7-c4185c6dda9f"/>
							<gml:surfaceMember xlink:href="#poly-8ca1ec6a-6f58-45d6-8d22-58eca28b135e"/>
							<gml:surfaceMember xlink:href="#poly-d8eee79d-332e-4fd2-9bdd-863a035397fc"/>
							<gml:surfaceMember xlink:href="#poly-769f9cda-e232-4286-a89a-af9b4f7456ee"/>
							<gml:surfaceMember xlink:href="#poly-5dda4879-edaa-4fcb-b546-4587fb083aae"/>
							<gml:surfaceMember xlink:href="#poly-fc52a5bb-6573-415e-97c7-4768214e120e"/>
							<gml:surfaceMember xlink:href="#poly-a8a43efc-5a6e-4cdd-8abf-fcd8b01269e2"/>
							<gml:surfaceMember xlink:href="#poly-5040030f-fbdd-4563-a089-c646ca5cf730"/>
							<gml:surfaceMember xlink:href="#poly-2eae5812-7c31-4b76-97d2-b45eb9e757e5"/>
							<gml:surfaceMember xlink:href="#poly-b71d02be-e162-4b89-b820-1c7a338b5b9f"/>
							<gml:surfaceMember xlink:href="#poly-9d35553d-e776-4976-95ec-94f35150ea31"/>
							<gml:surfaceMember xlink:href="#poly-d0dc38d5-a4e3-4fc4-9c74-670281b5fafb"/>
							<gml:surfaceMember xlink:href="#poly-0f5b7776-c04b-4ed5-8591-cb5ff1003e34"/>
							<gml:surfaceMember xlink:href="#poly-c1da8f57-fe61-4cc9-bf69-197822073823"/>
							<gml:surfaceMember xlink:href="#poly-e6b1c5ea-cca2-4e73-8333-1c6546c8dc44"/>
							<gml:surfaceMember xlink:href="#poly-f93bc435-a6cc-456e-98b9-95056f7007f2"/>
							<gml:surfaceMember xlink:href="#poly-bce6c7aa-ae2e-4b2b-a374-08e6a401573b"/>
							<gml:surfaceMember xlink:href="#poly-6f8c1d3a-ae37-4e2c-8f8c-acb7a4d37b2e"/>
							<gml:surfaceMember xlink:href="#poly-55f58a1d-fc22-4b84-98f4-470d32fa6a56"/>
							<gml:surfaceMember xlink:href="#poly-e777bc53-7939-4f7e-8123-0f26d88ccdc1"/>
							<gml:surfaceMember xlink:href="#poly-e24ae4a8-67ee-4a92-bcbb-0037b191bbb7"/>
							<gml:surfaceMember xlink:href="#poly-1e314aed-a429-4f89-b4dc-c8d78b96e9b7"/>
							<gml:surfaceMember xlink:href="#poly-3df7a7f9-9180-4f47-9c91-1eafb1f99b50"/>
							<gml:surfaceMember xlink:href="#poly-8c335779-82c3-44f0-ba38-3702e6977285"/>
							<gml:surfaceMember xlink:href="#poly-a702305c-3dd7-41f1-9527-4a2e348af016"/>
							<gml:surfaceMember xlink:href="#poly-335f76c6-275a-4297-8aff-d2aa556525c2"/>
							<gml:surfaceMember xlink:href="#poly-1719ae29-e1c3-4450-b02e-0c25fb7e3942"/>
							<gml:surfaceMember xlink:href="#poly-529db238-5cb3-41c7-b660-59257b8cc35a"/>
							<gml:surfaceMember xlink:href="#poly-85f69b79-9416-4897-9265-ef21275ebab1"/>
							<gml:surfaceMember xlink:href="#poly-57ea2f05-cd3c-4712-ac30-0eeb8ed7ee0a"/>
							<gml:surfaceMember xlink:href="#poly-b3928be2-fd6a-4189-9da2-f68f97ec565b"/>
							<gml:surfaceMember xlink:href="#poly-4fa10437-3deb-4070-9e87-0c9b8405a2ff"/>
							<gml:surfaceMember xlink:href="#poly-f3c8f175-ad0f-4aab-b2e8-1fde37e6f1e5"/>
							<gml:surfaceMember xlink:href="#poly-1435aa68-3ede-408a-9aaf-3254c4604d16"/>
							<gml:surfaceMember xlink:href="#poly-720c4d10-dabe-4523-85cb-3defda083696"/>
							<gml:surfaceMember xlink:href="#poly-39a74fd2-92ab-4d1e-89fb-b0c9d8bbe004"/>
							<gml:surfaceMember xlink:href="#poly-801d70cd-0dcf-4291-9ccf-1286ea128548"/>
							<gml:surfaceMember xlink:href="#poly-5d81634f-a14a-4ee5-83bd-21b1ea1e94f0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0bb8ab0f-aab4-4d72-b134-b93c5f2f9917_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be700618-eece-47fd-828f-39b1d0df6bba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67317984746531 139.73878207729092 70.268 35.67318983079605 139.73877713871232 70.268 35.67319678794334 139.73879825169638 70.268 35.67318692206759 139.73880354362697 70.268 35.67317984746531 139.73878207729092 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4b31dd7-c4eb-4813-95a5-19b46ebc9c4f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67314906064116 139.73881021625488 70.268 35.673143911443596 139.73879572913424 70.268 35.67316862573328 139.73878253239153 70.268 35.6731737749411 139.73879703056238 70.268 35.67314906064116 139.73881021625488 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8cfd2d3-af20-4e6b-b96b-97c14669813d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673198351037136 139.73880298886502 66.844 35.67319931022898 139.73880774883915 66.844 35.6731898494932 139.7388124327255 66.844 35.67318692206759 139.73880354362697 66.844 35.67319678794334 139.73879825169638 66.844 35.673198351037136 139.73880298886502 66.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-932e67a0-21f8-496e-8cbc-1336d9c6f162">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673199832825176 139.73880749415008 70.268 35.67319931022898 139.73880774883915 70.268 35.673198351037136 139.73880298886502 70.268 35.673199832825176 139.73880749415008 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3749c29c-c3d0-4643-accd-680db31ea8dc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673140549384534 139.73880728788387 70.268 35.67314627687198 139.7388235749253 70.268 35.67313772638231 139.73882808098745 70.268 35.67313200790917 139.7388117939368 70.268 35.673140549384534 139.73880728788387 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4192f83e-98bb-4112-b1d9-8bfdea2a9d6d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673206974656544 139.73884571818064 70.268 35.67320549062466 139.73883835181513 70.268 35.673207085324535 139.73883742201699 70.268 35.67321616255711 139.73886091858884 70.268 35.67320888278371 139.73886514698734 70.268 35.673206974656544 139.73884571818064 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-047c50fc-8f0f-4cb7-a09e-addf261fa3a4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673206974656544 139.73884571818064 66.844 35.67320888278371 139.73886514698734 66.844 35.67320745025254 139.73886597717404 66.844 35.67319836400723 139.7388424806148 66.844 35.67320549062466 139.73883835181513 66.844 35.673206974656544 139.73884571818064 66.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-163f719a-79cd-4fe2-b79e-c310c06948b9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6731568746434 139.73887798923627 70.268 35.673153316219015 139.7388690456493 70.268 35.673160577887195 139.73886471785562 70.268 35.67316412729817 139.73887366145382 70.268 35.6731568746434 139.73887798923627 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8214827f-e8e0-470d-96bb-3393ef1d4d7a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67314855625403 139.73891409945884 70.268 35.67312035501032 139.7388715810277 70.268 35.673147752778874 139.73885504506444 70.268 35.673166818389255 139.73890302026078 70.268 35.67314855625403 139.73891409945884 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-557565e9-cc22-4657-96d6-68afe9dd7b7f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673153259418086 139.7389000536385 72.071 35.67314347472188 139.73890542278454 72.071 35.67313234595927 139.73887501345024 72.071 35.673142130654135 139.73886964430127 72.071 35.673153259418086 139.7389000536385 72.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92c45ec8-7e94-433f-a5cd-7cfc27b490d4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673221488366046 139.7389512076362 70.268 35.67321468080075 139.73895989831743 70.268 35.67320368292183 139.73894695354542 70.268 35.67321049048621 139.7389382628643 70.268 35.673221488366046 139.7389512076362 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-261304d3-e402-4e71-b680-7e2ce70b25d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67321714769076 139.73897923809793 70.268 35.67321094207771 139.7389854204785 70.268 35.673174294051364 139.73893019724682 70.268 35.67318049966161 139.7389240148648 70.268 35.67321714769076 139.73897923809793 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d32d64d8-24eb-4706-ba3d-eca65fe9b25d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d32d64d8-24eb-4706-ba3d-eca65fe9b25d_0">
											<gml:posList>35.673153316219015 139.7388690456493 70.268 35.6731568746434 139.73887798923627 70.268 35.6731568746434 139.73887798923627 71.288 35.673153316219015 139.7388690456493 71.288 35.673153316219015 139.7388690456493 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ab792c2-3d47-463c-ad46-3308956d7359">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ab792c2-3d47-463c-ad46-3308956d7359_0">
											<gml:posList>35.67320368292183 139.73894695354542 70.268 35.67321468080075 139.73895989831743 70.268 35.67321468080075 139.73895989831743 70.491 35.67320368292183 139.73894695354542 70.491 35.67320368292183 139.73894695354542 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9a3f6cc-0543-47f1-8f23-efe5f8e17e1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9a3f6cc-0543-47f1-8f23-efe5f8e17e1f_0">
											<gml:posList>35.67312035501032 139.7388715810277 72.071 35.673147752778874 139.73885504506444 72.071 35.673147752778874 139.73885504506444 70.268 35.67312035501032 139.7388715810277 70.268 35.67312035501032 139.7388715810277 72.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dafd1d62-37a6-4e39-9df5-ea3dfe4a52d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dafd1d62-37a6-4e39-9df5-ea3dfe4a52d3_0">
											<gml:posList>35.67314855625403 139.73891409945884 72.071 35.67312035501032 139.7388715810277 72.071 35.67312035501032 139.7388715810277 70.268 35.67314855625403 139.73891409945884 70.268 35.67314855625403 139.73891409945884 72.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-468c82ba-010a-4b41-9d0b-83f103a6dee1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-468c82ba-010a-4b41-9d0b-83f103a6dee1_0">
											<gml:posList>35.67313200790917 139.7388117939368 70.268 35.67313772638231 139.73882808098745 70.268 35.67313772638231 139.73882808098745 71.759 35.67313200790917 139.7388117939368 71.759 35.67313200790917 139.7388117939368 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d9ed10c-3909-45e3-a152-0d032b9284be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d9ed10c-3909-45e3-a152-0d032b9284be_0">
											<gml:posList>35.673140549384534 139.73880728788387 70.268 35.67313200790917 139.7388117939368 70.268 35.67313200790917 139.7388117939368 71.759 35.673140549384534 139.73880728788387 71.759 35.673140549384534 139.73880728788387 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c591ec0f-6dd4-480e-86b9-d10687acbc33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c591ec0f-6dd4-480e-86b9-d10687acbc33_0">
											<gml:posList>35.673142130654135 139.73886964430127 72.071 35.67313234595927 139.73887501345024 72.071 35.67313234595927 139.73887501345024 74.294 35.673142130654135 139.73886964430127 74.294 35.673142130654135 139.73886964430127 72.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1251f41-e60d-4135-9d15-b61cb500f745">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1251f41-e60d-4135-9d15-b61cb500f745_0">
											<gml:posList>35.67313234595927 139.73887501345024 72.071 35.67314347472188 139.73890542278454 72.071 35.67314347472188 139.73890542278454 74.294 35.67313234595927 139.73887501345024 74.294 35.67313234595927 139.73887501345024 72.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-612bdbd0-57fc-456c-b0a1-36e1c150bfa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-612bdbd0-57fc-456c-b0a1-36e1c150bfa9_0">
											<gml:posList>35.67313772638231 139.73882808098745 71.759 35.67314627687198 139.7388235749253 71.759 35.673140549384534 139.73880728788387 71.759 35.67313200790917 139.7388117939368 71.759 35.67313772638231 139.73882808098745 71.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e717da02-29be-4dbd-b86f-ea6625139739">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e717da02-29be-4dbd-b86f-ea6625139739_0">
											<gml:posList>35.67313772638231 139.73882808098745 70.268 35.67314627687198 139.7388235749253 70.268 35.67314627687198 139.7388235749253 71.759 35.67313772638231 139.73882808098745 71.759 35.67313772638231 139.73882808098745 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b266c03c-de49-40c4-96d8-ddc7002168b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b266c03c-de49-40c4-96d8-ddc7002168b4_0">
											<gml:posList>35.673153259418086 139.7389000536385 74.294 35.673142130654135 139.73886964430127 74.294 35.67313234595927 139.73887501345024 74.294 35.67314347472188 139.73890542278454 74.294 35.673153259418086 139.7389000536385 74.294</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9974a8d-e0a3-41c2-8505-1d3a73290eeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9974a8d-e0a3-41c2-8505-1d3a73290eeb_0">
											<gml:posList>35.67314627687198 139.7388235749253 70.268 35.673140549384534 139.73880728788387 70.268 35.673140549384534 139.73880728788387 71.759 35.67314627687198 139.7388235749253 71.759 35.67314627687198 139.7388235749253 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7ae89cd-1b74-4cbe-9bed-b16037baa087">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7ae89cd-1b74-4cbe-9bed-b16037baa087_0">
											<gml:posList>35.67314855625403 139.73891409945884 72.071 35.673166818389255 139.73890302026078 72.071 35.673147752778874 139.73885504506444 72.071 35.67312035501032 139.7388715810277 72.071 35.67314855625403 139.73891409945884 72.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64cb6f5a-9cf4-4274-bf13-6a02aff7dcd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64cb6f5a-9cf4-4274-bf13-6a02aff7dcd8_0">
											<gml:posList>35.67314906064116 139.73881021625488 70.268 35.67314906064116 139.73881021625488 71.145 35.673143911443596 139.73879572913424 71.145 35.673143911443596 139.73879572913424 70.268 35.67314906064116 139.73881021625488 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39df4136-f542-460a-8ff1-3862253358b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39df4136-f542-460a-8ff1-3862253358b9_0">
											<gml:posList>35.673153259418086 139.7389000536385 72.071 35.673142130654135 139.73886964430127 72.071 35.673142130654135 139.73886964430127 74.294 35.673153259418086 139.7389000536385 74.294 35.673153259418086 139.7389000536385 72.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0eae9862-f823-40ab-bae8-c0879eeaf003">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0eae9862-f823-40ab-bae8-c0879eeaf003_0">
											<gml:posList>35.673153259418086 139.7389000536385 72.071 35.673153259418086 139.7389000536385 74.294 35.67314347472188 139.73890542278454 74.294 35.67314347472188 139.73890542278454 72.071 35.673153259418086 139.7389000536385 72.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ea0da08-1cd8-4e9e-a405-da05f33b06ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ea0da08-1cd8-4e9e-a405-da05f33b06ae_0">
											<gml:posList>35.673143911443596 139.73879572913424 70.268 35.673143911443596 139.73879572913424 71.145 35.67316862573328 139.73878253239153 71.145 35.67316862573328 139.73878253239153 70.268 35.673143911443596 139.73879572913424 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-067f9fba-6c91-4642-b59a-6691775d067b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-067f9fba-6c91-4642-b59a-6691775d067b_0">
											<gml:posList>35.673160577887195 139.73886471785562 70.268 35.673153316219015 139.7388690456493 70.268 35.673153316219015 139.7388690456493 71.288 35.673160577887195 139.73886471785562 71.288 35.673160577887195 139.73886471785562 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6375e76a-214c-42fc-8226-0f336e249625">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6375e76a-214c-42fc-8226-0f336e249625_0">
											<gml:posList>35.673166818389255 139.73890302026078 70.268 35.673147752778874 139.73885504506444 70.268 35.673147752778874 139.73885504506444 72.071 35.673166818389255 139.73890302026078 72.071 35.673166818389255 139.73890302026078 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-202f1a15-4390-495e-aec4-d9e556deee09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-202f1a15-4390-495e-aec4-d9e556deee09_0">
											<gml:posList>35.673166818389255 139.73890302026078 72.071 35.67314855625403 139.73891409945884 72.071 35.67314855625403 139.73891409945884 70.268 35.673166818389255 139.73890302026078 70.268 35.673166818389255 139.73890302026078 72.071</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ed25952-db7e-44c5-a28a-ecfb60530422">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ed25952-db7e-44c5-a28a-ecfb60530422_0">
											<gml:posList>35.673160577887195 139.73886471785562 71.288 35.673153316219015 139.7388690456493 71.288 35.6731568746434 139.73887798923627 71.288 35.67316412729817 139.73887366145382 71.288 35.673160577887195 139.73886471785562 71.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55c91abf-1045-4270-828e-992167872da4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55c91abf-1045-4270-828e-992167872da4_0">
											<gml:posList>35.67316862573328 139.73878253239153 71.145 35.673143911443596 139.73879572913424 71.145 35.67314906064116 139.73881021625488 71.145 35.6731737749411 139.73879703056238 71.145 35.67316862573328 139.73878253239153 71.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3761a76-f68b-429b-8b55-cc5f42a691bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3761a76-f68b-429b-8b55-cc5f42a691bc_0">
											<gml:posList>35.6731568746434 139.73887798923627 70.268 35.67316412729817 139.73887366145382 70.268 35.67316412729817 139.73887366145382 71.288 35.6731568746434 139.73887798923627 71.288 35.6731568746434 139.73887798923627 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8df2d9ee-cb45-4dbb-b67a-32480bd7e6ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8df2d9ee-cb45-4dbb-b67a-32480bd7e6ce_0">
											<gml:posList>35.6731737749411 139.73879703056238 70.268 35.6731737749411 139.73879703056238 71.145 35.67314906064116 139.73881021625488 71.145 35.67314906064116 139.73881021625488 70.268 35.6731737749411 139.73879703056238 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc5b8d60-db36-423a-8a36-4caf4b98b3a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc5b8d60-db36-423a-8a36-4caf4b98b3a8_0">
											<gml:posList>35.67316412729817 139.73887366145382 70.268 35.673160577887195 139.73886471785562 70.268 35.673160577887195 139.73886471785562 71.288 35.67316412729817 139.73887366145382 71.288 35.67316412729817 139.73887366145382 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c34a4fe8-9401-4523-95c7-d1f1e31807a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c34a4fe8-9401-4523-95c7-d1f1e31807a8_0">
											<gml:posList>35.67316862573328 139.73878253239153 70.268 35.67316862573328 139.73878253239153 71.145 35.6731737749411 139.73879703056238 71.145 35.6731737749411 139.73879703056238 70.268 35.67316862573328 139.73878253239153 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95300207-7635-48e8-917f-9d207a4f84e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95300207-7635-48e8-917f-9d207a4f84e3_0">
											<gml:posList>35.67318049966161 139.7389240148648 70.268 35.673174294051364 139.73893019724682 70.268 35.673174294051364 139.73893019724682 70.491 35.67318049966161 139.7389240148648 70.491 35.67318049966161 139.7389240148648 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0da94e98-bb8d-4e53-9512-d8c1859237d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0da94e98-bb8d-4e53-9512-d8c1859237d1_0">
											<gml:posList>35.67318692206759 139.73880354362697 70.268 35.67318692206759 139.73880354362697 66.844 35.6731898494932 139.7388124327255 66.844 35.6731898494932 139.7388124327255 70.926 35.67317984746531 139.73878207729092 70.926 35.67317984746531 139.73878207729092 70.268 35.67318692206759 139.73880354362697 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-680fec3d-af54-4dba-8d61-64049de4f9b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-680fec3d-af54-4dba-8d61-64049de4f9b0_0">
											<gml:posList>35.67317984746531 139.73878207729092 70.268 35.67317984746531 139.73878207729092 70.926 35.67318983079605 139.73877713871232 70.926 35.67318983079605 139.73877713871232 70.268 35.67317984746531 139.73878207729092 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ad71405-4240-4ed8-9752-4bc94e7214b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ad71405-4240-4ed8-9752-4bc94e7214b6_0">
											<gml:posList>35.67318983079605 139.73877713871232 70.926 35.67317984746531 139.73878207729092 70.926 35.6731898494932 139.7388124327255 70.926 35.673199832825176 139.73880749415008 70.926 35.67318983079605 139.73877713871232 70.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e3a9c37-69bc-45e7-9338-ba6aa8c6e010">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e3a9c37-69bc-45e7-9338-ba6aa8c6e010_0">
											<gml:posList>35.67318692206759 139.73880354362697 66.844 35.67318692206759 139.73880354362697 70.268 35.67319678794334 139.73879825169638 70.268 35.67319678794334 139.73879825169638 66.844 35.67318692206759 139.73880354362697 66.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-148ea30e-06fa-4e00-b22d-85fb5d46a259">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-148ea30e-06fa-4e00-b22d-85fb5d46a259_0">
											<gml:posList>35.67321094207771 139.7389854204785 70.268 35.67321094207771 139.7389854204785 70.491 35.673174294051364 139.73893019724682 70.491 35.673174294051364 139.73893019724682 70.268 35.67321094207771 139.7389854204785 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42166fdb-c31e-4ffe-b60b-df5aa5d663ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42166fdb-c31e-4ffe-b60b-df5aa5d663ef_0">
											<gml:posList>35.67319931022898 139.73880774883915 70.268 35.673199832825176 139.73880749415008 70.268 35.673199832825176 139.73880749415008 70.926 35.6731898494932 139.7388124327255 70.926 35.6731898494932 139.7388124327255 66.844 35.67319931022898 139.73880774883915 66.844 35.67319931022898 139.73880774883915 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-025b5b93-cb7a-4f1c-ae24-81f32d5ea5da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-025b5b93-cb7a-4f1c-ae24-81f32d5ea5da_0">
											<gml:posList>35.67319678794334 139.73879825169638 66.844 35.67319678794334 139.73879825169638 70.268 35.67318983079605 139.73877713871232 70.268 35.67318983079605 139.73877713871232 70.926 35.673199832825176 139.73880749415008 70.926 35.673199832825176 139.73880749415008 70.268 35.673198351037136 139.73880298886502 70.268 35.673198351037136 139.73880298886502 66.844 35.67319678794334 139.73879825169638 66.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b82673c-e49a-4630-8be6-ee486da4a5bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b82673c-e49a-4630-8be6-ee486da4a5bd_0">
											<gml:posList>35.673174294051364 139.73893019724682 70.491 35.67321094207771 139.7389854204785 70.491 35.67321714769076 139.73897923809793 70.491 35.67318049966161 139.7389240148648 70.491 35.673174294051364 139.73893019724682 70.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84092e20-2a50-43e5-8303-ffe5aee445a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84092e20-2a50-43e5-8303-ffe5aee445a9_0">
											<gml:posList>35.67318049966161 139.7389240148648 70.268 35.67318049966161 139.7389240148648 70.491 35.67321714769076 139.73897923809793 70.491 35.67321714769076 139.73897923809793 70.268 35.67318049966161 139.7389240148648 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2243186-5aa4-4715-afb2-104876fc2a4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2243186-5aa4-4715-afb2-104876fc2a4c_0">
											<gml:posList>35.67319931022898 139.73880774883915 70.268 35.67319931022898 139.73880774883915 66.844 35.673198351037136 139.73880298886502 66.844 35.673198351037136 139.73880298886502 70.268 35.67319931022898 139.73880774883915 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb27fd98-de3e-4eea-9389-dad56eb923a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb27fd98-de3e-4eea-9389-dad56eb923a3_0">
											<gml:posList>35.67320549062466 139.73883835181513 70.268 35.67320549062466 139.73883835181513 66.844 35.67319836400723 139.7388424806148 66.844 35.67319836400723 139.7388424806148 71.096 35.673207085324535 139.73883742201699 71.096 35.673207085324535 139.73883742201699 70.268 35.67320549062466 139.73883835181513 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5334fa72-80e7-44fa-8677-b049f9cdbdbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5334fa72-80e7-44fa-8677-b049f9cdbdbc_0">
											<gml:posList>35.67319836400723 139.7388424806148 66.844 35.67320745025254 139.73886597717404 66.844 35.67320745025254 139.73886597717404 71.096 35.67319836400723 139.7388424806148 71.096 35.67319836400723 139.7388424806148 66.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2901ff29-1bb9-4732-9366-4cfb2461f5bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2901ff29-1bb9-4732-9366-4cfb2461f5bb_0">
											<gml:posList>35.673206974656544 139.73884571818064 66.844 35.67320549062466 139.73883835181513 66.844 35.67320549062466 139.73883835181513 70.268 35.673206974656544 139.73884571818064 70.268 35.673206974656544 139.73884571818064 66.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96d0e621-9d50-45d8-9e58-9547630eed8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96d0e621-9d50-45d8-9e58-9547630eed8e_0">
											<gml:posList>35.67321049048621 139.7389382628643 70.268 35.67320368292183 139.73894695354542 70.268 35.67320368292183 139.73894695354542 70.491 35.67321049048621 139.7389382628643 70.491 35.67321049048621 139.7389382628643 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db964fa6-afe0-45d8-bfed-1d84522bf23c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db964fa6-afe0-45d8-bfed-1d84522bf23c_0">
											<gml:posList>35.67321616255711 139.73886091858884 71.096 35.673207085324535 139.73883742201699 71.096 35.67319836400723 139.7388424806148 71.096 35.67320745025254 139.73886597717404 71.096 35.67321616255711 139.73886091858884 71.096</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5659756d-4a54-4630-88f8-f258857e8d5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5659756d-4a54-4630-88f8-f258857e8d5c_0">
											<gml:posList>35.673206974656544 139.73884571818064 70.268 35.67320888278371 139.73886514698734 70.268 35.67320888278371 139.73886514698734 66.844 35.673206974656544 139.73884571818064 66.844 35.673206974656544 139.73884571818064 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb5579ef-ea65-4cb5-bfd6-5d442182b595">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb5579ef-ea65-4cb5-bfd6-5d442182b595_0">
											<gml:posList>35.673207085324535 139.73883742201699 70.268 35.673207085324535 139.73883742201699 71.096 35.67321616255711 139.73886091858884 71.096 35.67321616255711 139.73886091858884 70.268 35.673207085324535 139.73883742201699 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8b6f788-a1e3-4d8b-87a8-680430df3092">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8b6f788-a1e3-4d8b-87a8-680430df3092_0">
											<gml:posList>35.67320888278371 139.73886514698734 70.268 35.67321616255711 139.73886091858884 70.268 35.67321616255711 139.73886091858884 71.096 35.67320745025254 139.73886597717404 71.096 35.67320745025254 139.73886597717404 66.844 35.67320888278371 139.73886514698734 66.844 35.67320888278371 139.73886514698734 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f834249-4c2a-4bac-b420-de17f51a0d04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f834249-4c2a-4bac-b420-de17f51a0d04_0">
											<gml:posList>35.673221488366046 139.7389512076362 70.491 35.67321049048621 139.7389382628643 70.491 35.67320368292183 139.73894695354542 70.491 35.67321468080075 139.73895989831743 70.491 35.673221488366046 139.7389512076362 70.491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b40db73-b10f-4b8e-b4ba-771d5fb80dda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b40db73-b10f-4b8e-b4ba-771d5fb80dda_0">
											<gml:posList>35.67321094207771 139.7389854204785 70.268 35.67321714769076 139.73897923809793 70.268 35.67321714769076 139.73897923809793 70.491 35.67321094207771 139.7389854204785 70.491 35.67321094207771 139.7389854204785 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20f833e2-b044-48c8-9be4-2a8b24a1c2bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20f833e2-b044-48c8-9be4-2a8b24a1c2bb_0">
											<gml:posList>35.673221488366046 139.7389512076362 70.268 35.67321049048621 139.7389382628643 70.268 35.67321049048621 139.7389382628643 70.491 35.673221488366046 139.7389512076362 70.491 35.673221488366046 139.7389512076362 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4392975-a5ec-47ee-9a41-87d632154814">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4392975-a5ec-47ee-9a41-87d632154814_0">
											<gml:posList>35.673221488366046 139.7389512076362 70.268 35.673221488366046 139.7389512076362 70.491 35.67321468080075 139.73895989831743 70.491 35.67321468080075 139.73895989831743 70.268 35.673221488366046 139.7389512076362 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0bb8ab0f-aab4-4d72-b134-b93c5f2f9917_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d388a9a-c259-402a-9794-2fd31346a07d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67318729465908 139.73891079507413 70.268 35.67315388477955 139.73882398572889 70.268 35.67317439972895 139.73881213058834 70.268 35.67320834250926 139.73890032015427 70.268 35.67318729465908 139.73891079507413 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eee229c8-1920-4a24-81d5-00ab218efe9d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67319761837721 139.7389376152217 70.268 35.67319032042212 139.73891865672272 70.268 35.67321083537208 139.73890679055435 70.268 35.673218133337684 139.7389257601037 70.268 35.67319761837721 139.7389376152217 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82b5a5af-19d2-4da3-bde6-754f94342c2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82b5a5af-19d2-4da3-bde6-754f94342c2c_0">
											<gml:posList>35.67315388477955 139.73882398572889 70.268 35.67315388477955 139.73882398572889 71.333 35.67317439972895 139.73881213058834 71.333 35.67317439972895 139.73881213058834 70.268 35.67315388477955 139.73882398572889 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fe1251e-aaf5-40a7-91b5-70fcc33e7042">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fe1251e-aaf5-40a7-91b5-70fcc33e7042_0">
											<gml:posList>35.67320834250926 139.73890032015427 70.268 35.67317439972895 139.73881213058834 70.268 35.67317439972895 139.73881213058834 71.333 35.67320834250926 139.73890032015427 71.333 35.67320834250926 139.73890032015427 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab955f03-6cc9-4788-b8e3-5a8e9f69abec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab955f03-6cc9-4788-b8e3-5a8e9f69abec_0">
											<gml:posList>35.67318729465908 139.73891079507413 71.333 35.67320834250926 139.73890032015427 71.333 35.67317439972895 139.73881213058834 71.333 35.67315388477955 139.73882398572889 71.333 35.67318729465908 139.73891079507413 71.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc9d4877-f6a1-4a60-974f-0a981e46ce6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc9d4877-f6a1-4a60-974f-0a981e46ce6e_0">
											<gml:posList>35.67315388477955 139.73882398572889 70.268 35.67318729465908 139.73891079507413 70.268 35.67318729465908 139.73891079507413 71.333 35.67315388477955 139.73882398572889 71.333 35.67315388477955 139.73882398572889 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31e71d9f-3d4a-4bc6-9c27-57d5b1bd6703">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31e71d9f-3d4a-4bc6-9c27-57d5b1bd6703_0">
											<gml:posList>35.67318729465908 139.73891079507413 70.268 35.67320834250926 139.73890032015427 70.268 35.67320834250926 139.73890032015427 71.333 35.67318729465908 139.73891079507413 71.333 35.67318729465908 139.73891079507413 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e03cc6d-e837-459e-83e8-e61ce9668b57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e03cc6d-e837-459e-83e8-e61ce9668b57_0">
											<gml:posList>35.67319032042212 139.73891865672272 70.268 35.67319032042212 139.73891865672272 71.333 35.67321083537208 139.73890679055435 71.333 35.67321083537208 139.73890679055435 70.268 35.67319032042212 139.73891865672272 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-651e410f-e825-40a7-b12d-7af311c87915">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-651e410f-e825-40a7-b12d-7af311c87915_0">
											<gml:posList>35.673218133337684 139.7389257601037 70.268 35.67321083537208 139.73890679055435 70.268 35.67321083537208 139.73890679055435 71.333 35.673218133337684 139.7389257601037 71.333 35.673218133337684 139.7389257601037 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22491c73-1ed5-49c1-a036-19579023ec9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22491c73-1ed5-49c1-a036-19579023ec9d_0">
											<gml:posList>35.67321083537208 139.73890679055435 71.333 35.67319032042212 139.73891865672272 71.333 35.67319761837721 139.7389376152217 71.333 35.673218133337684 139.7389257601037 71.333 35.67321083537208 139.73890679055435 71.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cbb5d3f-7b1f-48a9-89a7-45d7ca6dda78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cbb5d3f-7b1f-48a9-89a7-45d7ca6dda78_0">
											<gml:posList>35.67319032042212 139.73891865672272 70.268 35.67319761837721 139.7389376152217 70.268 35.67319761837721 139.7389376152217 71.333 35.67319032042212 139.73891865672272 71.333 35.67319032042212 139.73891865672272 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10fd4561-0048-437b-b9a4-7a38fa7a9a57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10fd4561-0048-437b-b9a4-7a38fa7a9a57_0">
											<gml:posList>35.673218133337684 139.7389257601037 70.268 35.673218133337684 139.7389257601037 71.333 35.67319761837721 139.7389376152217 71.333 35.67319761837721 139.7389376152217 70.268 35.673218133337684 139.7389257601037 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0ef612fe-4ae9-4845-b168-4b2d04b38053">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ef612fe-4ae9-4845-b168-4b2d04b38053">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ef612fe-4ae9-4845-b168-4b2d04b38053">
											<gml:posList>35.67323472657587 139.73906249812265 7.42 35.673074633828314 139.73882109656518 7.42 35.67309165145817 139.73879776810764 7.42 35.67322977006631 139.73871906354321 7.42 35.673259222808156 139.7388056345662 7.42 35.67326837763841 139.73887057811615 7.42 35.67326661639458 139.73892349367836 7.42 35.673255975768406 139.73903286809886 7.42 35.67323472657587 139.73906249812265 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3fa65263-94fa-44d1-bac6-c1a83ad2007c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fa65263-94fa-44d1-bac6-c1a83ad2007c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fa65263-94fa-44d1-bac6-c1a83ad2007c">
											<gml:posList>35.673074633828314 139.73882109656518 75.296 35.673077509282464 139.73882119259497 75.296 35.673092122834056 139.7388011588681 75.296 35.67309165145817 139.73879776810764 75.296 35.673074633828314 139.73882109656518 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ffd9c80-c08b-4ccf-a0bb-73dc6c500f9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ffd9c80-c08b-4ccf-a0bb-73dc6c500f9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ffd9c80-c08b-4ccf-a0bb-73dc6c500f9a">
											<gml:posList>35.673107536809766 139.73887071240028 75.296 35.67310812908926 139.73886736457195 75.296 35.673077509282464 139.73882119259497 75.296 35.673074633828314 139.73882109656518 75.296 35.673107536809766 139.73887071240028 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c94aaee-0858-4e1c-9989-2f11561b0d33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c94aaee-0858-4e1c-9989-2f11561b0d33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c94aaee-0858-4e1c-9989-2f11561b0d33">
											<gml:posList>35.673092408272254 139.73879733639654 75.296 35.67309165145817 139.73879776810764 75.296 35.673092122834056 139.7388011588681 75.296 35.673092408272254 139.73879733639654 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a13fe4a8-7e41-4118-99ea-cbf6cb5f904a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a13fe4a8-7e41-4118-99ea-cbf6cb5f904a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a13fe4a8-7e41-4118-99ea-cbf6cb5f904a">
											<gml:posList>35.673077509282464 139.73882119259497 74.821 35.67310812908926 139.73886736457195 74.821 35.673125292075405 139.73885696050903 74.821 35.67312110902435 139.73884460425188 74.821 35.673092122834056 139.7388011588681 74.821 35.673077509282464 139.73882119259497 74.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4fc51565-59ae-49ed-81d5-162507de16f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fc51565-59ae-49ed-81d5-162507de16f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fc51565-59ae-49ed-81d5-162507de16f1">
											<gml:posList>35.673123018849026 139.7388432211713 75.296 35.673092408272254 139.73879733639654 75.296 35.673092122834056 139.7388011588681 75.296 35.67312110902435 139.73884460425188 75.296 35.673123018849026 139.7388432211713 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c80a958-4eb0-4bec-bc3b-fca97d554e16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c80a958-4eb0-4bec-bc3b-fca97d554e16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c80a958-4eb0-4bec-bc3b-fca97d554e16">
											<gml:posList>35.673107536809766 139.73887071240028 75.296 35.67312810536956 139.73885824965032 75.296 35.673125292075405 139.73885696050903 75.296 35.67310812908926 139.73886736457195 75.296 35.673107536809766 139.73887071240028 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d6c2ef2-bb61-41eb-b606-5fbfd51d8ac1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d6c2ef2-bb61-41eb-b606-5fbfd51d8ac1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d6c2ef2-bb61-41eb-b606-5fbfd51d8ac1">
											<gml:posList>35.673123018849026 139.7388432211713 75.296 35.67312110902435 139.73884460425188 75.296 35.673125292075405 139.73885696050903 75.296 35.67312810536956 139.73885824965032 75.296 35.673123018849026 139.7388432211713 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-244c5d5d-4f57-4b4e-b836-be1e64953bca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-244c5d5d-4f57-4b4e-b836-be1e64953bca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-244c5d5d-4f57-4b4e-b836-be1e64953bca">
											<gml:posList>35.67322977006631 139.73871906354321 75.187 35.673092408272254 139.73879733639654 75.187 35.67309801239975 139.73880574732306 75.187 35.673105823651014 139.7388010985262 75.187 35.673225346253254 139.73873298754472 75.187 35.67322977006631 139.73871906354321 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61ec6b6e-a279-4a1b-b2d7-c4185c6dda9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61ec6b6e-a279-4a1b-b2d7-c4185c6dda9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61ec6b6e-a279-4a1b-b2d7-c4185c6dda9f">
											<gml:posList>35.673107536809766 139.73887071240028 75.187 35.67323472657587 139.73906249812265 75.187 35.673234966409716 139.7390464691476 75.187 35.67312075370243 139.73887424279744 75.187 35.67311542006927 139.73886593096472 75.187 35.673107536809766 139.73887071240028 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8ca1ec6a-6f58-45d6-8d22-58eca28b135e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ca1ec6a-6f58-45d6-8d22-58eca28b135e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ca1ec6a-6f58-45d6-8d22-58eca28b135e">
											<gml:posList>35.673213171605646 139.73890893085266 70.268 35.67317741658424 139.7388086362917 70.268 35.67312075370243 139.73887424279744 70.268 35.673234966409716 139.7390464691476 70.268 35.673213171605646 139.73890893085266 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d8eee79d-332e-4fd2-9bdd-863a035397fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8eee79d-332e-4fd2-9bdd-863a035397fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8eee79d-332e-4fd2-9bdd-863a035397fc">
											<gml:posList>35.67312810536956 139.73885824965032 70.268 35.67311542006927 139.73886593096472 70.268 35.67312075370243 139.73887424279744 70.268 35.67317741658424 139.7388086362917 70.268 35.67319733755464 139.73879796383548 70.268 35.673206974656544 139.73884571818064 70.268 35.673213171605646 139.73890893085266 70.268 35.673234966409716 139.7390464691476 70.268 35.67324789599913 139.73902843684778 70.268 35.67325817890494 139.73892267511545 70.268 35.67325989624112 139.73887123986245 70.268 35.673251058669116 139.73880856050943 70.268 35.673225346253254 139.73873298754472 70.268 35.673105823651014 139.7388010985262 70.268 35.67309801239975 139.73880574732306 70.268 35.673123018849026 139.7388432211713 70.268 35.67312810536956 139.73885824965032 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-769f9cda-e232-4286-a89a-af9b4f7456ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-769f9cda-e232-4286-a89a-af9b4f7456ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-769f9cda-e232-4286-a89a-af9b4f7456ee">
											<gml:posList>35.67317741658424 139.7388086362917 66.844 35.673213171605646 139.73890893085266 66.844 35.673206974656544 139.73884571818064 66.844 35.67319733755464 139.73879796383548 66.844 35.67317741658424 139.7388086362917 66.844</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5dda4879-edaa-4fcb-b546-4587fb083aae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dda4879-edaa-4fcb-b546-4587fb083aae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dda4879-edaa-4fcb-b546-4587fb083aae">
											<gml:posList>35.673259222808156 139.7388056345662 75.187 35.67322977006631 139.73871906354321 75.187 35.673225346253254 139.73873298754472 75.187 35.673251058669116 139.73880856050943 75.187 35.673259222808156 139.7388056345662 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc52a5bb-6573-415e-97c7-4768214e120e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc52a5bb-6573-415e-97c7-4768214e120e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc52a5bb-6573-415e-97c7-4768214e120e">
											<gml:posList>35.673255975768406 139.73903286809886 75.187 35.67324789599913 139.73902843684778 75.187 35.673234966409716 139.7390464691476 75.187 35.67323472657587 139.73906249812265 75.187 35.673255975768406 139.73903286809886 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a8a43efc-5a6e-4cdd-8abf-fcd8b01269e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8a43efc-5a6e-4cdd-8abf-fcd8b01269e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8a43efc-5a6e-4cdd-8abf-fcd8b01269e2">
											<gml:posList>35.67326661639458 139.73892349367836 75.187 35.67325817890494 139.73892267511545 75.187 35.67324789599913 139.73902843684778 75.187 35.673255975768406 139.73903286809886 75.187 35.67326661639458 139.73892349367836 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5040030f-fbdd-4563-a089-c646ca5cf730">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5040030f-fbdd-4563-a089-c646ca5cf730">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5040030f-fbdd-4563-a089-c646ca5cf730">
											<gml:posList>35.673259222808156 139.7388056345662 75.187 35.673251058669116 139.73880856050943 75.187 35.67325989624112 139.73887123986245 75.187 35.67326837763841 139.73887057811615 75.187 35.673259222808156 139.7388056345662 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2eae5812-7c31-4b76-97d2-b45eb9e757e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eae5812-7c31-4b76-97d2-b45eb9e757e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eae5812-7c31-4b76-97d2-b45eb9e757e5">
											<gml:posList>35.67326661639458 139.73892349367836 75.187 35.67326837763841 139.73887057811615 75.187 35.67325989624112 139.73887123986245 75.187 35.67325817890494 139.73892267511545 75.187 35.67326661639458 139.73892349367836 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b71d02be-e162-4b89-b820-1c7a338b5b9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b71d02be-e162-4b89-b820-1c7a338b5b9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b71d02be-e162-4b89-b820-1c7a338b5b9f">
											<gml:posList>35.67319733755464 139.73879796383548 70.268 35.67319733755464 139.73879796383548 66.844 35.673206974656544 139.73884571818064 66.844 35.673206974656544 139.73884571818064 70.268 35.67319733755464 139.73879796383548 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d35553d-e776-4976-95ec-94f35150ea31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d35553d-e776-4976-95ec-94f35150ea31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d35553d-e776-4976-95ec-94f35150ea31">
											<gml:posList>35.673092122834056 139.7388011588681 75.296 35.673092122834056 139.7388011588681 74.821 35.67312110902435 139.73884460425188 74.821 35.67312110902435 139.73884460425188 75.296 35.673092122834056 139.7388011588681 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0dc38d5-a4e3-4fc4-9c74-670281b5fafb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0dc38d5-a4e3-4fc4-9c74-670281b5fafb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0dc38d5-a4e3-4fc4-9c74-670281b5fafb">
											<gml:posList>35.67312110902435 139.73884460425188 75.296 35.67312110902435 139.73884460425188 74.821 35.673125292075405 139.73885696050903 74.821 35.673125292075405 139.73885696050903 75.296 35.67312110902435 139.73884460425188 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f5b7776-c04b-4ed5-8591-cb5ff1003e34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f5b7776-c04b-4ed5-8591-cb5ff1003e34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f5b7776-c04b-4ed5-8591-cb5ff1003e34">
											<gml:posList>35.673206974656544 139.73884571818064 70.268 35.673206974656544 139.73884571818064 66.844 35.673213171605646 139.73890893085266 66.844 35.673213171605646 139.73890893085266 70.268 35.673206974656544 139.73884571818064 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1da8f57-fe61-4cc9-bf69-197822073823">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1da8f57-fe61-4cc9-bf69-197822073823">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1da8f57-fe61-4cc9-bf69-197822073823">
											<gml:posList>35.67324789599913 139.73902843684778 75.187 35.67324789599913 139.73902843684778 70.268 35.673234966409716 139.7390464691476 70.268 35.673234966409716 139.7390464691476 75.187 35.67324789599913 139.73902843684778 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6b1c5ea-cca2-4e73-8333-1c6546c8dc44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6b1c5ea-cca2-4e73-8333-1c6546c8dc44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6b1c5ea-cca2-4e73-8333-1c6546c8dc44">
											<gml:posList>35.673092408272254 139.73879733639654 75.187 35.67322977006631 139.73871906354321 75.187 35.67322977006631 139.73871906354321 7.42 35.67309165145817 139.73879776810764 7.42 35.67309165145817 139.73879776810764 75.296 35.673092408272254 139.73879733639654 75.296 35.673092408272254 139.73879733639654 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f93bc435-a6cc-456e-98b9-95056f7007f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f93bc435-a6cc-456e-98b9-95056f7007f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f93bc435-a6cc-456e-98b9-95056f7007f2">
											<gml:posList>35.673259222808156 139.7388056345662 7.42 35.67322977006631 139.73871906354321 7.42 35.67322977006631 139.73871906354321 75.187 35.673259222808156 139.7388056345662 75.187 35.673259222808156 139.7388056345662 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bce6c7aa-ae2e-4b2b-a374-08e6a401573b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bce6c7aa-ae2e-4b2b-a374-08e6a401573b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bce6c7aa-ae2e-4b2b-a374-08e6a401573b">
											<gml:posList>35.673105823651014 139.7388010985262 75.187 35.673105823651014 139.7388010985262 70.268 35.673225346253254 139.73873298754472 70.268 35.673225346253254 139.73873298754472 75.187 35.673105823651014 139.7388010985262 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f8c1d3a-ae37-4e2c-8f8c-acb7a4d37b2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f8c1d3a-ae37-4e2c-8f8c-acb7a4d37b2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f8c1d3a-ae37-4e2c-8f8c-acb7a4d37b2e">
											<gml:posList>35.673225346253254 139.73873298754472 75.187 35.673225346253254 139.73873298754472 70.268 35.673251058669116 139.73880856050943 70.268 35.673251058669116 139.73880856050943 75.187 35.673225346253254 139.73873298754472 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55f58a1d-fc22-4b84-98f4-470d32fa6a56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55f58a1d-fc22-4b84-98f4-470d32fa6a56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55f58a1d-fc22-4b84-98f4-470d32fa6a56">
											<gml:posList>35.67319733755464 139.73879796383548 70.268 35.67317741658424 139.7388086362917 70.268 35.67317741658424 139.7388086362917 66.844 35.67319733755464 139.73879796383548 66.844 35.67319733755464 139.73879796383548 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e777bc53-7939-4f7e-8123-0f26d88ccdc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e777bc53-7939-4f7e-8123-0f26d88ccdc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e777bc53-7939-4f7e-8123-0f26d88ccdc1">
											<gml:posList>35.67309801239975 139.73880574732306 75.187 35.67309801239975 139.73880574732306 70.268 35.673105823651014 139.7388010985262 70.268 35.673105823651014 139.7388010985262 75.187 35.67309801239975 139.73880574732306 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e24ae4a8-67ee-4a92-bcbb-0037b191bbb7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e24ae4a8-67ee-4a92-bcbb-0037b191bbb7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e24ae4a8-67ee-4a92-bcbb-0037b191bbb7">
											<gml:posList>35.67309165145817 139.73879776810764 75.296 35.67309165145817 139.73879776810764 7.42 35.673074633828314 139.73882109656518 7.42 35.673074633828314 139.73882109656518 75.296 35.67309165145817 139.73879776810764 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e314aed-a429-4f89-b4dc-c8d78b96e9b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e314aed-a429-4f89-b4dc-c8d78b96e9b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e314aed-a429-4f89-b4dc-c8d78b96e9b7">
											<gml:posList>35.673077509282464 139.73882119259497 75.296 35.673077509282464 139.73882119259497 74.821 35.673092122834056 139.7388011588681 74.821 35.673092122834056 139.7388011588681 75.296 35.673077509282464 139.73882119259497 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3df7a7f9-9180-4f47-9c91-1eafb1f99b50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3df7a7f9-9180-4f47-9c91-1eafb1f99b50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3df7a7f9-9180-4f47-9c91-1eafb1f99b50">
											<gml:posList>35.67309801239975 139.73880574732306 75.187 35.673092408272254 139.73879733639654 75.187 35.673092408272254 139.73879733639654 75.296 35.673123018849026 139.7388432211713 75.296 35.673123018849026 139.7388432211713 70.268 35.67309801239975 139.73880574732306 70.268 35.67309801239975 139.73880574732306 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c335779-82c3-44f0-ba38-3702e6977285">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c335779-82c3-44f0-ba38-3702e6977285">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c335779-82c3-44f0-ba38-3702e6977285">
											<gml:posList>35.67326837763841 139.73887057811615 7.42 35.673259222808156 139.7388056345662 7.42 35.673259222808156 139.7388056345662 75.187 35.67326837763841 139.73887057811615 75.187 35.67326837763841 139.73887057811615 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a702305c-3dd7-41f1-9527-4a2e348af016">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a702305c-3dd7-41f1-9527-4a2e348af016">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a702305c-3dd7-41f1-9527-4a2e348af016">
											<gml:posList>35.673251058669116 139.73880856050943 75.187 35.673251058669116 139.73880856050943 70.268 35.67325989624112 139.73887123986245 70.268 35.67325989624112 139.73887123986245 75.187 35.673251058669116 139.73880856050943 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-335f76c6-275a-4297-8aff-d2aa556525c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-335f76c6-275a-4297-8aff-d2aa556525c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-335f76c6-275a-4297-8aff-d2aa556525c2">
											<gml:posList>35.67310812908926 139.73886736457195 75.296 35.67310812908926 139.73886736457195 74.821 35.673077509282464 139.73882119259497 74.821 35.673077509282464 139.73882119259497 75.296 35.67310812908926 139.73886736457195 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1719ae29-e1c3-4450-b02e-0c25fb7e3942">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1719ae29-e1c3-4450-b02e-0c25fb7e3942">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1719ae29-e1c3-4450-b02e-0c25fb7e3942">
											<gml:posList>35.673123018849026 139.7388432211713 75.296 35.67312810536956 139.73885824965032 75.296 35.67312810536956 139.73885824965032 70.268 35.673123018849026 139.7388432211713 70.268 35.673123018849026 139.7388432211713 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-529db238-5cb3-41c7-b660-59257b8cc35a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-529db238-5cb3-41c7-b660-59257b8cc35a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-529db238-5cb3-41c7-b660-59257b8cc35a">
											<gml:posList>35.673213171605646 139.73890893085266 70.268 35.673213171605646 139.73890893085266 66.844 35.67317741658424 139.7388086362917 66.844 35.67317741658424 139.7388086362917 70.268 35.673213171605646 139.73890893085266 70.268</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85f69b79-9416-4897-9265-ef21275ebab1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85f69b79-9416-4897-9265-ef21275ebab1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85f69b79-9416-4897-9265-ef21275ebab1">
											<gml:posList>35.673125292075405 139.73885696050903 75.296 35.673125292075405 139.73885696050903 74.821 35.67310812908926 139.73886736457195 74.821 35.67310812908926 139.73886736457195 75.296 35.673125292075405 139.73885696050903 75.296</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57ea2f05-cd3c-4712-ac30-0eeb8ed7ee0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57ea2f05-cd3c-4712-ac30-0eeb8ed7ee0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57ea2f05-cd3c-4712-ac30-0eeb8ed7ee0a">
											<gml:posList>35.67311542006927 139.73886593096472 75.187 35.67311542006927 139.73886593096472 70.268 35.67312810536956 139.73885824965032 70.268 35.67312810536956 139.73885824965032 75.296 35.673107536809766 139.73887071240028 75.296 35.673107536809766 139.73887071240028 75.187 35.67311542006927 139.73886593096472 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3928be2-fd6a-4189-9da2-f68f97ec565b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3928be2-fd6a-4189-9da2-f68f97ec565b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3928be2-fd6a-4189-9da2-f68f97ec565b">
											<gml:posList>35.67312075370243 139.73887424279744 75.187 35.67312075370243 139.73887424279744 70.268 35.67311542006927 139.73886593096472 70.268 35.67311542006927 139.73886593096472 75.187 35.67312075370243 139.73887424279744 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fa10437-3deb-4070-9e87-0c9b8405a2ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fa10437-3deb-4070-9e87-0c9b8405a2ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fa10437-3deb-4070-9e87-0c9b8405a2ff">
											<gml:posList>35.67325989624112 139.73887123986245 75.187 35.67325989624112 139.73887123986245 70.268 35.67325817890494 139.73892267511545 70.268 35.67325817890494 139.73892267511545 75.187 35.67325989624112 139.73887123986245 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3c8f175-ad0f-4aab-b2e8-1fde37e6f1e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3c8f175-ad0f-4aab-b2e8-1fde37e6f1e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3c8f175-ad0f-4aab-b2e8-1fde37e6f1e5">
											<gml:posList>35.67326661639458 139.73892349367836 7.42 35.67326837763841 139.73887057811615 7.42 35.67326837763841 139.73887057811615 75.187 35.67326661639458 139.73892349367836 75.187 35.67326661639458 139.73892349367836 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1435aa68-3ede-408a-9aaf-3254c4604d16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1435aa68-3ede-408a-9aaf-3254c4604d16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1435aa68-3ede-408a-9aaf-3254c4604d16">
											<gml:posList>35.67323472657587 139.73906249812265 7.42 35.67323472657587 139.73906249812265 75.187 35.673107536809766 139.73887071240028 75.187 35.673107536809766 139.73887071240028 75.296 35.673074633828314 139.73882109656518 75.296 35.673074633828314 139.73882109656518 7.42 35.67323472657587 139.73906249812265 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-720c4d10-dabe-4523-85cb-3defda083696">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-720c4d10-dabe-4523-85cb-3defda083696">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-720c4d10-dabe-4523-85cb-3defda083696">
											<gml:posList>35.673234966409716 139.7390464691476 75.187 35.673234966409716 139.7390464691476 70.268 35.67312075370243 139.73887424279744 70.268 35.67312075370243 139.73887424279744 75.187 35.673234966409716 139.7390464691476 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39a74fd2-92ab-4d1e-89fb-b0c9d8bbe004">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39a74fd2-92ab-4d1e-89fb-b0c9d8bbe004">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39a74fd2-92ab-4d1e-89fb-b0c9d8bbe004">
											<gml:posList>35.67325817890494 139.73892267511545 75.187 35.67325817890494 139.73892267511545 70.268 35.67324789599913 139.73902843684778 70.268 35.67324789599913 139.73902843684778 75.187 35.67325817890494 139.73892267511545 75.187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-801d70cd-0dcf-4291-9ccf-1286ea128548">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-801d70cd-0dcf-4291-9ccf-1286ea128548">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-801d70cd-0dcf-4291-9ccf-1286ea128548">
											<gml:posList>35.673255975768406 139.73903286809886 7.42 35.67326661639458 139.73892349367836 7.42 35.67326661639458 139.73892349367836 75.187 35.673255975768406 139.73903286809886 75.187 35.673255975768406 139.73903286809886 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d81634f-a14a-4ee5-83bd-21b1ea1e94f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d81634f-a14a-4ee5-83bd-21b1ea1e94f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d81634f-a14a-4ee5-83bd-21b1ea1e94f0">
											<gml:posList>35.67323472657587 139.73906249812265 7.42 35.673255975768406 139.73903286809886 7.42 35.673255975768406 139.73903286809886 75.187 35.67323472657587 139.73906249812265 75.187 35.67323472657587 139.73906249812265 7.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-598</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">369.3338</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.41</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>