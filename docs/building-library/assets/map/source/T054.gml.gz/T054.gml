<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0d0e9871-85fc-4db9-a552-0576c9f1d399">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">7.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67006497464833 139.74429386902233 0 35.67004241812401 139.74438579856624 0 35.670122752678104 139.744415865638 0 35.67014612046007 139.7443239351097 0 35.67006497464833 139.74429386902233 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006497464833 139.74429386902233 8.7 35.67014612046007 139.7443239351097 8.7 35.670122752678104 139.744415865638 8.7 35.67004241812401 139.74438579856624 8.7 35.67006497464833 139.74429386902233 8.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006497464833 139.74429386902233 8.7 35.67004241812401 139.74438579856624 8.7 35.67004241812401 139.74438579856624 16.12 35.67006497464833 139.74429386902233 16.12 35.67006497464833 139.74429386902233 8.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67004241812401 139.74438579856624 8.7 35.670122752678104 139.744415865638 8.7 35.670122752678104 139.744415865638 16.12 35.67004241812401 139.74438579856624 16.12 35.67004241812401 139.74438579856624 8.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670122752678104 139.744415865638 8.7 35.67014612046007 139.7443239351097 8.7 35.67014612046007 139.7443239351097 16.12 35.670122752678104 139.744415865638 16.12 35.670122752678104 139.744415865638 8.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014612046007 139.7443239351097 8.7 35.67006497464833 139.74429386902233 8.7 35.67006497464833 139.74429386902233 16.12 35.67014612046007 139.7443239351097 16.12 35.67014612046007 139.7443239351097 8.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006497464833 139.74429386902233 16.12 35.67004241812401 139.74438579856624 16.12 35.670122752678104 139.744415865638 16.12 35.67014612046007 139.7443239351097 16.12 35.67006497464833 139.74429386902233 16.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-503bb6af-20fa-4763-bef7-c890bb89855e"/>
							<gml:surfaceMember xlink:href="#poly-6e110e15-290d-4e68-b185-34d4a75e4e69"/>
							<gml:surfaceMember xlink:href="#poly-fb1c5fc1-48b5-4765-98db-299624ebf39c"/>
							<gml:surfaceMember xlink:href="#poly-db3429ad-09de-40c7-894d-3eabffd25435"/>
							<gml:surfaceMember xlink:href="#poly-4120e751-9bd3-4af1-93e1-e25e924a3334"/>
							<gml:surfaceMember xlink:href="#poly-996349ad-ed48-4cb8-a0e9-69ea92b5cd9a"/>
							<gml:surfaceMember xlink:href="#poly-03609fe2-c519-4c96-8004-29533e8dc35f"/>
							<gml:surfaceMember xlink:href="#poly-c9471b8b-69ba-4f94-8866-5fb066531382"/>
							<gml:surfaceMember xlink:href="#poly-efb2ae59-ae61-4bfe-bbcc-4811dc369866"/>
							<gml:surfaceMember xlink:href="#poly-8f2f80aa-f51e-4338-b849-a5aef2f728bd"/>
							<gml:surfaceMember xlink:href="#poly-c5502265-078d-426e-8f49-0e29291746b7"/>
							<gml:surfaceMember xlink:href="#poly-544c060d-e95f-477c-94a5-6e1dbeaac5a7"/>
							<gml:surfaceMember xlink:href="#poly-ef3bc685-30ce-44c2-b977-68ef88a33865"/>
							<gml:surfaceMember xlink:href="#poly-ee6e519a-8fad-44cc-96ef-e74e5c17b404"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0d0e9871-85fc-4db9-a552-0576c9f1d399_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a65716ec-d9a2-4a82-b2ee-44af60fcdbbe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011435123845 139.7443417879361 15.467 35.67012446764103 139.74434584171834 15.467 35.670119712514484 139.74436362037025 15.467 35.670109605118064 139.74435955552977 15.467 35.67011435123845 139.7443417879361 15.467</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6950f020-ca50-4ec1-83a4-e764d21c101d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6950f020-ca50-4ec1-83a4-e764d21c101d_0">
											<gml:posList>35.670109605118064 139.74435955552977 18.47 35.67011435123845 139.7443417879361 18.47 35.67011435123845 139.7443417879361 15.467 35.670109605118064 139.74435955552977 15.467 35.670109605118064 139.74435955552977 18.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0d8f83f-9671-4257-8327-17510956bdbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0d8f83f-9671-4257-8327-17510956bdbd_0">
											<gml:posList>35.670119712514484 139.74436362037025 15.467 35.670119712514484 139.74436362037025 18.47 35.670109605118064 139.74435955552977 18.47 35.670109605118064 139.74435955552977 15.467 35.670119712514484 139.74436362037025 15.467</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faace55e-593c-4480-8546-bbdc7b21e065">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faace55e-593c-4480-8546-bbdc7b21e065_0">
											<gml:posList>35.67011435123845 139.7443417879361 18.47 35.670109605118064 139.74435955552977 18.47 35.670119712514484 139.74436362037025 18.47 35.67012446764103 139.74434584171834 18.47 35.67011435123845 139.7443417879361 18.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1aaa4aee-2cc5-420d-bee9-5014ec165aa0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1aaa4aee-2cc5-420d-bee9-5014ec165aa0_0">
											<gml:posList>35.67011435123845 139.7443417879361 18.47 35.67012446764103 139.74434584171834 18.47 35.67012446764103 139.74434584171834 15.467 35.67011435123845 139.7443417879361 15.467 35.67011435123845 139.7443417879361 18.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc610cd6-9c02-45ed-a4b4-54e09178ca97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc610cd6-9c02-45ed-a4b4-54e09178ca97_0">
											<gml:posList>35.67012446764103 139.74434584171834 15.467 35.67012446764103 139.74434584171834 18.47 35.670119712514484 139.74436362037025 18.47 35.670119712514484 139.74436362037025 15.467 35.67012446764103 139.74434584171834 15.467</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-503bb6af-20fa-4763-bef7-c890bb89855e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-503bb6af-20fa-4763-bef7-c890bb89855e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-503bb6af-20fa-4763-bef7-c890bb89855e">
											<gml:posList>35.67006497464829 139.7442938690223 8.7 35.67014612046006 139.7443239351097 8.7 35.67012275267808 139.74441586563796 8.7 35.670042418124005 139.74438579856627 8.7 35.67006497464829 139.7442938690223 8.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e110e15-290d-4e68-b185-34d4a75e4e69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e110e15-290d-4e68-b185-34d4a75e4e69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e110e15-290d-4e68-b185-34d4a75e4e69">
											<gml:posList>35.670042418124005 139.74438579856627 16.1 35.670045048866704 139.74438408348468 16.1 35.67006639217985 139.74429708189712 16.1 35.67006497464829 139.7442938690223 16.1 35.670042418124005 139.74438579856627 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb1c5fc1-48b5-4765-98db-299624ebf39c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb1c5fc1-48b5-4765-98db-299624ebf39c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb1c5fc1-48b5-4765-98db-299624ebf39c">
											<gml:posList>35.67012275267808 139.74441586563796 16.1 35.67012136218271 139.74441264168257 16.1 35.670045048866704 139.74438408348468 16.1 35.670042418124005 139.74438579856627 16.1 35.67012275267808 139.74441586563796 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db3429ad-09de-40c7-894d-3eabffd25435">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db3429ad-09de-40c7-894d-3eabffd25435">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db3429ad-09de-40c7-894d-3eabffd25435">
											<gml:posList>35.6701434807127 139.74432566125162 15.467 35.67006639217985 139.74429708189712 15.467 35.670045048866704 139.74438408348468 15.467 35.67012136218271 139.74441264168257 15.467 35.6701434807127 139.74432566125162 15.467</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4120e751-9bd3-4af1-93e1-e25e924a3334">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4120e751-9bd3-4af1-93e1-e25e924a3334">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4120e751-9bd3-4af1-93e1-e25e924a3334">
											<gml:posList>35.67006497464829 139.7442938690223 16.1 35.67006639217985 139.74429708189712 16.1 35.6701434807127 139.74432566125162 16.1 35.67014612046006 139.7443239351097 16.1 35.67006497464829 139.7442938690223 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-996349ad-ed48-4cb8-a0e9-69ea92b5cd9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-996349ad-ed48-4cb8-a0e9-69ea92b5cd9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-996349ad-ed48-4cb8-a0e9-69ea92b5cd9a">
											<gml:posList>35.67014612046006 139.7443239351097 16.1 35.6701434807127 139.74432566125162 16.1 35.67012136218271 139.74441264168257 16.1 35.67012275267808 139.74441586563796 16.1 35.67014612046006 139.7443239351097 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03609fe2-c519-4c96-8004-29533e8dc35f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03609fe2-c519-4c96-8004-29533e8dc35f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03609fe2-c519-4c96-8004-29533e8dc35f">
											<gml:posList>35.670042418124005 139.74438579856627 8.7 35.67012275267808 139.74441586563796 8.7 35.67012275267808 139.74441586563796 16.1 35.670042418124005 139.74438579856627 16.1 35.670042418124005 139.74438579856627 8.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9471b8b-69ba-4f94-8866-5fb066531382">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9471b8b-69ba-4f94-8866-5fb066531382">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9471b8b-69ba-4f94-8866-5fb066531382">
											<gml:posList>35.67014612046006 139.7443239351097 8.7 35.67006497464829 139.7442938690223 8.7 35.67006497464829 139.7442938690223 16.1 35.67014612046006 139.7443239351097 16.1 35.67014612046006 139.7443239351097 8.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efb2ae59-ae61-4bfe-bbcc-4811dc369866">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efb2ae59-ae61-4bfe-bbcc-4811dc369866">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efb2ae59-ae61-4bfe-bbcc-4811dc369866">
											<gml:posList>35.67006639217985 139.74429708189712 16.1 35.67006639217985 139.74429708189712 15.467 35.6701434807127 139.74432566125162 15.467 35.6701434807127 139.74432566125162 16.1 35.67006639217985 139.74429708189712 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f2f80aa-f51e-4338-b849-a5aef2f728bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f2f80aa-f51e-4338-b849-a5aef2f728bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f2f80aa-f51e-4338-b849-a5aef2f728bd">
											<gml:posList>35.67006497464829 139.7442938690223 8.7 35.670042418124005 139.74438579856627 8.7 35.670042418124005 139.74438579856627 16.1 35.67006497464829 139.7442938690223 16.1 35.67006497464829 139.7442938690223 8.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5502265-078d-426e-8f49-0e29291746b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5502265-078d-426e-8f49-0e29291746b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5502265-078d-426e-8f49-0e29291746b7">
											<gml:posList>35.670045048866704 139.74438408348468 16.1 35.670045048866704 139.74438408348468 15.467 35.67006639217985 139.74429708189712 15.467 35.67006639217985 139.74429708189712 16.1 35.670045048866704 139.74438408348468 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-544c060d-e95f-477c-94a5-6e1dbeaac5a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-544c060d-e95f-477c-94a5-6e1dbeaac5a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-544c060d-e95f-477c-94a5-6e1dbeaac5a7">
											<gml:posList>35.6701434807127 139.74432566125162 16.1 35.6701434807127 139.74432566125162 15.467 35.67012136218271 139.74441264168257 15.467 35.67012136218271 139.74441264168257 16.1 35.6701434807127 139.74432566125162 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef3bc685-30ce-44c2-b977-68ef88a33865">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef3bc685-30ce-44c2-b977-68ef88a33865">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef3bc685-30ce-44c2-b977-68ef88a33865">
											<gml:posList>35.67012275267808 139.74441586563796 8.7 35.67014612046006 139.7443239351097 8.7 35.67014612046006 139.7443239351097 16.1 35.67012275267808 139.74441586563796 16.1 35.67012275267808 139.74441586563796 8.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee6e519a-8fad-44cc-96ef-e74e5c17b404">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee6e519a-8fad-44cc-96ef-e74e5c17b404">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee6e519a-8fad-44cc-96ef-e74e5c17b404">
											<gml:posList>35.67012136218271 139.74441264168257 16.1 35.67012136218271 139.74441264168257 15.467 35.670045048866704 139.74438408348468 15.467 35.670045048866704 139.74438408348468 16.1 35.67012136218271 139.74441264168257 16.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4552</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">81.48075</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>