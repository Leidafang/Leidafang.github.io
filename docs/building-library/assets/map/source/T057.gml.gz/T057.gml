<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0d35f44a-0ecd-4941-915a-29f6e51740d7">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">19</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67013288584121 139.73814542033705 0 35.670130597414015 139.73813535994304 0 35.67015666709135 139.73812644782214 0 35.67014648223322 139.738081689558 0 35.67011629438886 139.73809199840832 0 35.67011177179931 139.73807212058057 0 35.6700031857118 139.73810925438755 0 35.6700289643062 139.7382224474325 0 35.67013989321066 139.73818431682622 0 35.67013790320855 139.7381754822071 0 35.67014793276675 139.73817203492712 0 35.67014154560092 139.73814233920524 0 35.67013288584121 139.73814542033705 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013288584121 139.73814542033705 19.894 35.67014154560092 139.73814233920524 19.894 35.67014793276675 139.73817203492712 19.894 35.67013790320855 139.7381754822071 19.894 35.67013989321066 139.73818431682622 19.894 35.6700289643062 139.7382224474325 19.894 35.6700031857118 139.73810925438755 19.894 35.67011177179931 139.73807212058057 19.894 35.67011629438886 139.73809199840832 19.894 35.67014648223322 139.738081689558 19.894 35.67015666709135 139.73812644782214 19.894 35.670130597414015 139.73813535994304 19.894 35.67013288584121 139.73814542033705 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013288584121 139.73814542033705 19.894 35.670130597414015 139.73813535994304 19.894 35.670130597414015 139.73813535994304 38.92 35.67013288584121 139.73814542033705 38.92 35.67013288584121 139.73814542033705 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670130597414015 139.73813535994304 19.894 35.67015666709135 139.73812644782214 19.894 35.67015666709135 139.73812644782214 38.92 35.670130597414015 139.73813535994304 38.92 35.670130597414015 139.73813535994304 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67015666709135 139.73812644782214 19.894 35.67014648223322 139.738081689558 19.894 35.67014648223322 139.738081689558 38.92 35.67015666709135 139.73812644782214 38.92 35.67015666709135 139.73812644782214 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014648223322 139.738081689558 19.894 35.67011629438886 139.73809199840832 19.894 35.67011629438886 139.73809199840832 38.92 35.67014648223322 139.738081689558 38.92 35.67014648223322 139.738081689558 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011629438886 139.73809199840832 19.894 35.67011177179931 139.73807212058057 19.894 35.67011177179931 139.73807212058057 38.92 35.67011629438886 139.73809199840832 38.92 35.67011629438886 139.73809199840832 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011177179931 139.73807212058057 19.894 35.6700031857118 139.73810925438755 19.894 35.6700031857118 139.73810925438755 38.92 35.67011177179931 139.73807212058057 38.92 35.67011177179931 139.73807212058057 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6700031857118 139.73810925438755 19.894 35.6700289643062 139.7382224474325 19.894 35.6700289643062 139.7382224474325 38.92 35.6700031857118 139.73810925438755 38.92 35.6700031857118 139.73810925438755 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6700289643062 139.7382224474325 19.894 35.67013989321066 139.73818431682622 19.894 35.67013989321066 139.73818431682622 38.92 35.6700289643062 139.7382224474325 38.92 35.6700289643062 139.7382224474325 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013989321066 139.73818431682622 19.894 35.67013790320855 139.7381754822071 19.894 35.67013790320855 139.7381754822071 38.92 35.67013989321066 139.73818431682622 38.92 35.67013989321066 139.73818431682622 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013790320855 139.7381754822071 19.894 35.67014793276675 139.73817203492712 19.894 35.67014793276675 139.73817203492712 38.92 35.67013790320855 139.7381754822071 38.92 35.67013790320855 139.7381754822071 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014793276675 139.73817203492712 19.894 35.67014154560092 139.73814233920524 19.894 35.67014154560092 139.73814233920524 38.92 35.67014793276675 139.73817203492712 38.92 35.67014793276675 139.73817203492712 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014154560092 139.73814233920524 19.894 35.67013288584121 139.73814542033705 19.894 35.67013288584121 139.73814542033705 38.92 35.67014154560092 139.73814233920524 38.92 35.67014154560092 139.73814233920524 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013288584121 139.73814542033705 38.92 35.670130597414015 139.73813535994304 38.92 35.67015666709135 139.73812644782214 38.92 35.67014648223322 139.738081689558 38.92 35.67011629438886 139.73809199840832 38.92 35.67011177179931 139.73807212058057 38.92 35.6700031857118 139.73810925438755 38.92 35.6700289643062 139.7382224474325 38.92 35.67013989321066 139.73818431682622 38.92 35.67013790320855 139.7381754822071 38.92 35.67014793276675 139.73817203492712 38.92 35.67014154560092 139.73814233920524 38.92 35.67013288584121 139.73814542033705 38.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e6c0be8d-b105-4033-a430-2cdf47a83e42"/>
							<gml:surfaceMember xlink:href="#poly-c57cce80-4046-4a8c-86d1-c67f71c37917"/>
							<gml:surfaceMember xlink:href="#poly-f5675295-ea9e-4c5b-bc7a-dc59447e43fa"/>
							<gml:surfaceMember xlink:href="#poly-1099a961-a009-41d0-a9d6-e7ec53340c04"/>
							<gml:surfaceMember xlink:href="#poly-fba569e8-3f16-40d9-9103-22dd0158ab52"/>
							<gml:surfaceMember xlink:href="#poly-d311b5a0-6362-4cdd-ad22-59b7ca79cf5d"/>
							<gml:surfaceMember xlink:href="#poly-66b3ea0b-41cd-46ac-88e1-eebf22ea9c91"/>
							<gml:surfaceMember xlink:href="#poly-4ea7285e-1237-4bb1-8b46-4d5a8cc4cd1a"/>
							<gml:surfaceMember xlink:href="#poly-83845845-330e-4282-8cc6-76a26f5f293b"/>
							<gml:surfaceMember xlink:href="#poly-6b63461d-96d3-4e5f-8f27-90d20dd8ff5e"/>
							<gml:surfaceMember xlink:href="#poly-e66fb5df-a7b8-4636-accc-0fdf50693570"/>
							<gml:surfaceMember xlink:href="#poly-bced14a3-ce10-4f32-b93b-228e66fb382e"/>
							<gml:surfaceMember xlink:href="#poly-37a65348-2972-4703-a9c2-a405efd3ad62"/>
							<gml:surfaceMember xlink:href="#poly-7c9dfad4-94f4-4032-bee8-a54449030e91"/>
							<gml:surfaceMember xlink:href="#poly-887ccd2c-298f-44e7-8152-8f037d6b64b9"/>
							<gml:surfaceMember xlink:href="#poly-24d3f390-d589-4208-a4be-ddeed5dfb470"/>
							<gml:surfaceMember xlink:href="#poly-6e5e7b7e-db68-44f3-a5b3-3599a3ccdcc2"/>
							<gml:surfaceMember xlink:href="#poly-76fe3d0d-ea1b-44e3-b932-85d31516bd5d"/>
							<gml:surfaceMember xlink:href="#poly-84b0d8d7-28d6-48f1-91c1-e8d15e8da779"/>
							<gml:surfaceMember xlink:href="#poly-5622224e-e59b-4aaa-868a-ec2701b520c1"/>
							<gml:surfaceMember xlink:href="#poly-0cfc577b-25a6-44b9-ad49-b889d1210def"/>
							<gml:surfaceMember xlink:href="#poly-4aee46ef-8810-4fc5-8f24-45b9d8b5653c"/>
							<gml:surfaceMember xlink:href="#poly-262c69ac-9a17-46c9-a4bf-a915db2fac9b"/>
							<gml:surfaceMember xlink:href="#poly-7a216841-4b84-4fa7-a119-73d7fff3928e"/>
							<gml:surfaceMember xlink:href="#poly-8965b762-97ef-4ee0-b8c3-a76647640886"/>
							<gml:surfaceMember xlink:href="#poly-26c16c8f-724a-4f92-a306-5b4d7bdb9985"/>
							<gml:surfaceMember xlink:href="#poly-c5acc171-2291-461a-9792-00521ca83ecf"/>
							<gml:surfaceMember xlink:href="#poly-b9f69019-b0dc-430f-aee3-25855d89593d"/>
							<gml:surfaceMember xlink:href="#poly-37845b4e-eac9-4f4e-96ef-d9ba72915383"/>
							<gml:surfaceMember xlink:href="#poly-107961ce-3571-4cdc-a213-ff1f5fcdd1cc"/>
							<gml:surfaceMember xlink:href="#poly-4aa33f7d-9d83-4501-b4eb-2849fb28b914"/>
							<gml:surfaceMember xlink:href="#poly-d31c381b-6239-48a8-98f2-d452de93ff25"/>
							<gml:surfaceMember xlink:href="#poly-9680f9b5-2201-44ce-babd-4f61a72537b8"/>
							<gml:surfaceMember xlink:href="#poly-740afbc4-6427-414f-96d0-ad12be8d3b27"/>
							<gml:surfaceMember xlink:href="#poly-0c88ae67-6b9d-4ac5-8a97-5fc68ababbb6"/>
							<gml:surfaceMember xlink:href="#poly-1b2501b2-5ce0-4a4d-a600-0242c2ef3c3b"/>
							<gml:surfaceMember xlink:href="#poly-73588de4-c65a-4e64-a29e-6f70853f6218"/>
							<gml:surfaceMember xlink:href="#poly-dac9ddc9-c1a4-4298-ab08-15a586843deb"/>
							<gml:surfaceMember xlink:href="#poly-7b1ddf1e-ca56-4440-a1c4-d76639295420"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0d35f44a-0ecd-4941-915a-29f6e51740d7_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8624cdb9-7d81-4790-b01a-9d1a94e605c5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670165657966024 139.73816594950944 19.894 35.67014793276676 139.7381720349271 19.894 35.670141545600906 139.73814233920524 19.894 35.6701328858412 139.73814542033705 19.894 35.670130597414015 139.73813535994304 19.894 35.67015666709136 139.73812644782214 19.894 35.670165657966024 139.73816594950944 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b7cdd83-b644-4f42-8f47-7a0d2d9066a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b7cdd83-b644-4f42-8f47-7a0d2d9066a3_0">
											<gml:posList>35.670130597414015 139.73813535994304 44.658 35.670130597414015 139.73813535994304 19.894 35.6701328858412 139.73814542033705 19.894 35.6701328858412 139.73814542033705 44.658 35.670130597414015 139.73813535994304 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0ae1359-a576-48d7-b4c6-d587c5fc4a08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0ae1359-a576-48d7-b4c6-d587c5fc4a08_0">
											<gml:posList>35.6701328858412 139.73814542033705 44.658 35.6701328858412 139.73814542033705 19.894 35.670141545600906 139.73814233920524 19.894 35.670141545600906 139.73814233920524 44.658 35.6701328858412 139.73814542033705 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6946350-ce19-4cd6-b77e-e457b27ec5db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6946350-ce19-4cd6-b77e-e457b27ec5db_0">
											<gml:posList>35.67015666709136 139.73812644782214 44.658 35.67015666709136 139.73812644782214 19.894 35.670130597414015 139.73813535994304 19.894 35.670130597414015 139.73813535994304 44.658 35.67015666709136 139.73812644782214 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c04fd24d-0393-47fc-9e7f-5efc734c30ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c04fd24d-0393-47fc-9e7f-5efc734c30ed_0">
											<gml:posList>35.670141545600906 139.73814233920524 44.658 35.670141545600906 139.73814233920524 19.894 35.67014793276676 139.7381720349271 19.894 35.67014793276676 139.7381720349271 44.658 35.670141545600906 139.73814233920524 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc3e25c2-040f-4f04-99ef-574d92f518f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc3e25c2-040f-4f04-99ef-574d92f518f1_0">
											<gml:posList>35.670130597414015 139.73813535994304 44.658 35.6701328858412 139.73814542033705 44.658 35.670141545600906 139.73814233920524 44.658 35.67014793276676 139.7381720349271 44.658 35.670165657966024 139.73816594950944 44.658 35.67015666709136 139.73812644782214 44.658 35.670130597414015 139.73813535994304 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea42da30-605b-4f49-a49d-eb0c75b8c08b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea42da30-605b-4f49-a49d-eb0c75b8c08b_0">
											<gml:posList>35.67014793276676 139.7381720349271 44.658 35.67014793276676 139.7381720349271 19.894 35.670165657966024 139.73816594950944 19.894 35.670165657966024 139.73816594950944 44.658 35.67014793276676 139.7381720349271 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64db0e16-b350-40c8-988e-7c08ccf0e30c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64db0e16-b350-40c8-988e-7c08ccf0e30c_0">
											<gml:posList>35.670165657966024 139.73816594950944 44.658 35.670165657966024 139.73816594950944 19.894 35.67015666709136 139.73812644782214 19.894 35.67015666709136 139.73812644782214 44.658 35.670165657966024 139.73816594950944 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0d35f44a-0ecd-4941-915a-29f6e51740d7_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1354f904-c233-42b9-8e5a-6c3e82585a54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014438758427 139.7380887064004 43.719 35.670152284029136 139.73812342636032 43.719 35.67012887267527 139.7381314184887 43.719 35.67012096721897 139.73809669854882 43.719 35.67014438758427 139.7380887064004 43.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ed56fe8-8885-4b08-a7f5-c1db1ad5f1d7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670135247447384 139.73812262917022 45.671 35.67013121031973 139.73810112696435 45.671 35.670141204318895 139.73809830935244 45.671 35.67014524144706 139.73811981156084 45.671 35.670135247447384 139.73812262917022 45.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b32097b6-2a1f-4918-a3b5-8d743a6cf07c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670152284029136 139.73812342636032 44.658 35.67014438758427 139.7380887064004 44.658 35.670146406107655 139.73808800809027 44.658 35.670155261326215 139.7381269244792 44.658 35.67012982244347 139.7381356259726 44.658 35.67012887267527 139.7381314184887 44.658 35.670152284029136 139.73812342636032 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d085fdcd-39c8-4597-bab3-4d25dcd4765f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011554868177 139.73811786954778 43.719 35.67012032453872 139.73813887379316 43.719 35.67011197106224 139.73814172259023 43.719 35.6701071862008 139.73812072940382 43.719 35.67011554868177 139.73811786954778 43.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdef220f-6940-4dc4-a2b9-60a6de7645d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdef220f-6940-4dc4-a2b9-60a6de7645d8_0">
											<gml:posList>35.67014438758427 139.7380887064004 44.658 35.67014438758427 139.7380887064004 43.719 35.67012096721897 139.73809669854882 43.719 35.67012096721897 139.73809669854882 45.671 35.670146406107655 139.73808800809027 45.671 35.670146406107655 139.73808800809027 44.658 35.67014438758427 139.7380887064004 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5f1b9b3-72dc-482c-a369-ab7a500fc446">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5f1b9b3-72dc-482c-a369-ab7a500fc446_0">
											<gml:posList>35.67013121031973 139.73810112696435 45.671 35.67013121031973 139.73810112696435 51.715 35.670141204318895 139.73809830935244 51.715 35.670141204318895 139.73809830935244 45.671 35.67013121031973 139.73810112696435 45.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5783fc1-a41a-4e48-9796-b46745d64694">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5783fc1-a41a-4e48-9796-b46745d64694_0">
											<gml:posList>35.670152284029136 139.73812342636032 43.719 35.67014438758427 139.7380887064004 43.719 35.67014438758427 139.7380887064004 44.658 35.670152284029136 139.73812342636032 44.658 35.670152284029136 139.73812342636032 43.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a66d7ac5-bae3-4593-9041-d22007c7ddf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a66d7ac5-bae3-4593-9041-d22007c7ddf5_0">
											<gml:posList>35.670146406107655 139.73808800809027 44.658 35.670146406107655 139.73808800809027 45.671 35.670155261326215 139.7381269244792 45.671 35.670155261326215 139.7381269244792 44.658 35.670146406107655 139.73808800809027 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26bd65cf-0856-41dc-a2ee-c5a310bbe9aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26bd65cf-0856-41dc-a2ee-c5a310bbe9aa_0">
											<gml:posList>35.670141204318895 139.73809830935244 51.715 35.67014524144706 139.73811981156084 51.715 35.67014524144706 139.73811981156084 45.671 35.670141204318895 139.73809830935244 45.671 35.670141204318895 139.73809830935244 51.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81ac55bc-9960-447f-9244-1219aa859730">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81ac55bc-9960-447f-9244-1219aa859730_0">
											<gml:posList>35.670135247447384 139.73812262917022 51.715 35.67014524144706 139.73811981156084 51.715 35.670141204318895 139.73809830935244 51.715 35.67013121031973 139.73810112696435 51.715 35.670135247447384 139.73812262917022 51.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d2cbacf-184d-4e9a-8205-b33f6554afb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d2cbacf-184d-4e9a-8205-b33f6554afb0_0">
											<gml:posList>35.67012982244347 139.7381356259726 45.671 35.670155261326215 139.7381269244792 45.671 35.670146406107655 139.73808800809027 45.671 35.67012096721897 139.73809669854882 45.671 35.67012982244347 139.7381356259726 45.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dab90edd-e32a-41da-962c-67ed48baead1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dab90edd-e32a-41da-962c-67ed48baead1_0">
											<gml:posList>35.670135247447384 139.73812262917022 51.715 35.67013121031973 139.73810112696435 51.715 35.67013121031973 139.73810112696435 45.671 35.670135247447384 139.73812262917022 45.671 35.670135247447384 139.73812262917022 51.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1194e995-e4a0-423b-afa9-a9fec887207e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1194e995-e4a0-423b-afa9-a9fec887207e_0">
											<gml:posList>35.67012982244347 139.7381356259726 45.671 35.67012096721897 139.73809669854882 45.671 35.67012096721897 139.73809669854882 43.719 35.67012887267527 139.7381314184887 43.719 35.67012887267527 139.7381314184887 44.658 35.67012982244347 139.7381356259726 44.658 35.67012982244347 139.7381356259726 45.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ad82700-7a86-4d1e-969b-a13cfe879500">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ad82700-7a86-4d1e-969b-a13cfe879500_0">
											<gml:posList>35.6701071862008 139.73812072940382 43.719 35.6701071862008 139.73812072940382 45.209 35.67011554868177 139.73811786954778 45.209 35.67011554868177 139.73811786954778 43.719 35.6701071862008 139.73812072940382 43.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbeea97f-b1d7-4250-8f03-a2a44cca0945">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbeea97f-b1d7-4250-8f03-a2a44cca0945_0">
											<gml:posList>35.67014524144706 139.73811981156084 45.671 35.67014524144706 139.73811981156084 51.715 35.670135247447384 139.73812262917022 51.715 35.670135247447384 139.73812262917022 45.671 35.67014524144706 139.73811981156084 45.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13e64569-56e1-446f-9a2d-cc6a9a3ce20c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13e64569-56e1-446f-9a2d-cc6a9a3ce20c_0">
											<gml:posList>35.67012887267527 139.7381314184887 44.658 35.67012887267527 139.7381314184887 43.719 35.670152284029136 139.73812342636032 43.719 35.670152284029136 139.73812342636032 44.658 35.67012887267527 139.7381314184887 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0f8eb20-2a48-4aa9-90f7-c20b6ed38524">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0f8eb20-2a48-4aa9-90f7-c20b6ed38524_0">
											<gml:posList>35.67012032453872 139.73813887379316 43.719 35.67011554868177 139.73811786954778 43.719 35.67011554868177 139.73811786954778 45.209 35.67012032453872 139.73813887379316 45.209 35.67012032453872 139.73813887379316 43.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aee5739d-0a22-4155-92ad-9f78f4e99db7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aee5739d-0a22-4155-92ad-9f78f4e99db7_0">
											<gml:posList>35.67011554868177 139.73811786954778 45.209 35.6701071862008 139.73812072940382 45.209 35.67011197106224 139.73814172259023 45.209 35.67012032453872 139.73813887379316 45.209 35.67011554868177 139.73811786954778 45.209</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e60dc56-0ca8-4345-8d38-57869a584d81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e60dc56-0ca8-4345-8d38-57869a584d81_0">
											<gml:posList>35.6701071862008 139.73812072940382 43.719 35.67011197106224 139.73814172259023 43.719 35.67011197106224 139.73814172259023 45.209 35.6701071862008 139.73812072940382 45.209 35.6701071862008 139.73812072940382 43.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-175eb6eb-aa84-4d0a-8bb7-6f9672dc215b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-175eb6eb-aa84-4d0a-8bb7-6f9672dc215b_0">
											<gml:posList>35.67012982244347 139.7381356259726 44.658 35.670155261326215 139.7381269244792 44.658 35.670155261326215 139.7381269244792 45.671 35.67012982244347 139.7381356259726 45.671 35.67012982244347 139.7381356259726 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dae50528-ee87-4ac8-bf4f-4b48437dc81f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dae50528-ee87-4ac8-bf4f-4b48437dc81f_0">
											<gml:posList>35.67011197106224 139.73814172259023 43.719 35.67012032453872 139.73813887379316 43.719 35.67012032453872 139.73813887379316 45.209 35.67011197106224 139.73814172259023 45.209 35.67011197106224 139.73814172259023 43.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e6c0be8d-b105-4033-a430-2cdf47a83e42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6c0be8d-b105-4033-a430-2cdf47a83e42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6c0be8d-b105-4033-a430-2cdf47a83e42">
											<gml:posList>35.67011629438885 139.73809199840832 19.894 35.67014648223319 139.738081689558 19.894 35.67015666709136 139.73812644782214 19.894 35.670130597414015 139.73813535994304 19.894 35.6701328858412 139.73814542033705 19.894 35.670141545600906 139.73814233920524 19.894 35.67014793276676 139.7381720349271 19.894 35.670137903208534 139.7381754822071 19.894 35.67013989321065 139.7381843168262 19.894 35.67002896430619 139.7382224474325 19.894 35.6700031857118 139.73810925438752 19.894 35.67011177179932 139.73807212058057 19.894 35.67011629438885 139.73809199840832 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c57cce80-4046-4a8c-86d1-c67f71c37917">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c57cce80-4046-4a8c-86d1-c67f71c37917">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c57cce80-4046-4a8c-86d1-c67f71c37917">
											<gml:posList>35.67008181825998 139.73808236287437 44.658 35.670086210337 139.73808538432056 44.658 35.67010931530005 139.73807749196303 44.658 35.67011177179932 139.73807212058057 44.658 35.67008181825998 139.73808236287437 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5675295-ea9e-4c5b-bc7a-dc59447e43fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5675295-ea9e-4c5b-bc7a-dc59447e43fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5675295-ea9e-4c5b-bc7a-dc59447e43fa">
											<gml:posList>35.67011629438885 139.73809199840832 44.658 35.67011177179932 139.73807212058057 44.658 35.67010931530005 139.73807749196303 44.658 35.67011383787995 139.73809735874426 44.658 35.67011629438885 139.73809199840832 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1099a961-a009-41d0-a9d6-e7ec53340c04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1099a961-a009-41d0-a9d6-e7ec53340c04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1099a961-a009-41d0-a9d6-e7ec53340c04">
											<gml:posList>35.67011629438885 139.73809199840832 44.658 35.67011383787995 139.73809735874426 44.658 35.670144007697324 139.73808704991765 44.658 35.67014648223319 139.738081689558 44.658 35.67011629438885 139.73809199840832 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fba569e8-3f16-40d9-9103-22dd0158ab52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fba569e8-3f16-40d9-9103-22dd0158ab52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fba569e8-3f16-40d9-9103-22dd0158ab52">
											<gml:posList>35.67014648223319 139.738081689558 44.658 35.670144007697324 139.73808704991765 44.658 35.670152284029136 139.73812342636032 44.658 35.67015666709136 139.73812644782214 44.658 35.67014648223319 139.738081689558 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d311b5a0-6362-4cdd-ad22-59b7ca79cf5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d311b5a0-6362-4cdd-ad22-59b7ca79cf5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d311b5a0-6362-4cdd-ad22-59b7ca79cf5d">
											<gml:posList>35.670130597414015 139.73813535994304 44.658 35.67015666709136 139.73812644782214 44.658 35.670152284029136 139.73812342636032 44.658 35.670126223356995 139.73813232742486 44.658 35.670130597414015 139.73813535994304 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66b3ea0b-41cd-46ac-88e1-eebf22ea9c91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66b3ea0b-41cd-46ac-88e1-eebf22ea9c91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66b3ea0b-41cd-46ac-88e1-eebf22ea9c91">
											<gml:posList>35.67010931530005 139.73807749196303 43.719 35.670086210337 139.73808538432056 43.719 35.67011004426556 139.73819005209901 43.719 35.670135528177305 139.73818129534047 43.719 35.67013353816624 139.73817244967574 43.719 35.67014360377054 139.7381689913065 43.719 35.67013903505109 139.73814775483658 43.719 35.670130420342396 139.7381508138218 43.719 35.670126223356995 139.73813232742486 43.719 35.670152284029136 139.73812342636032 43.719 35.670144007697324 139.73808704991765 43.719 35.67011383787995 139.73809735874426 43.719 35.67010931530005 139.73807749196303 43.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ea7285e-1237-4bb1-8b46-4d5a8cc4cd1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ea7285e-1237-4bb1-8b46-4d5a8cc4cd1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ea7285e-1237-4bb1-8b46-4d5a8cc4cd1a">
											<gml:posList>35.670107569733574 139.73819542349915 44.658 35.67011004426556 139.73819005209901 44.658 35.670086210337 139.73808538432056 44.658 35.67008181825998 139.73808236287437 44.658 35.670107569733574 139.73819542349915 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83845845-330e-4282-8cc6-76a26f5f293b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83845845-330e-4282-8cc6-76a26f5f293b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83845845-330e-4282-8cc6-76a26f5f293b">
											<gml:posList>35.670130597414015 139.73813535994304 44.658 35.670126223356995 139.73813232742486 44.658 35.670130420342396 139.7381508138218 44.658 35.6701328858412 139.73814542033705 44.658 35.670130597414015 139.73813535994304 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b63461d-96d3-4e5f-8f27-90d20dd8ff5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b63461d-96d3-4e5f-8f27-90d20dd8ff5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b63461d-96d3-4e5f-8f27-90d20dd8ff5e">
											<gml:posList>35.6701328858412 139.73814542033705 44.658 35.670130420342396 139.7381508138218 44.658 35.67013903505109 139.73814775483658 44.658 35.670141545600906 139.73814233920524 44.658 35.6701328858412 139.73814542033705 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e66fb5df-a7b8-4636-accc-0fdf50693570">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e66fb5df-a7b8-4636-accc-0fdf50693570">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e66fb5df-a7b8-4636-accc-0fdf50693570">
											<gml:posList>35.67002896430619 139.7382224474325 31.734 35.670107569733574 139.73819542349915 44.658 35.67008181825998 139.73808236287437 44.658 35.6700031857118 139.73810925438752 31.734 35.67002896430619 139.7382224474325 31.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bced14a3-ce10-4f32-b93b-228e66fb382e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bced14a3-ce10-4f32-b93b-228e66fb382e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bced14a3-ce10-4f32-b93b-228e66fb382e">
											<gml:posList>35.67014793276676 139.7381720349271 44.658 35.670141545600906 139.73814233920524 44.658 35.67013903505109 139.73814775483658 44.658 35.67014360377054 139.7381689913065 44.658 35.67014793276676 139.7381720349271 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37a65348-2972-4703-a9c2-a405efd3ad62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37a65348-2972-4703-a9c2-a405efd3ad62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37a65348-2972-4703-a9c2-a405efd3ad62">
											<gml:posList>35.670137903208534 139.7381754822071 44.658 35.67014793276676 139.7381720349271 44.658 35.67014360377054 139.7381689913065 44.658 35.67013353816624 139.73817244967574 44.658 35.670137903208534 139.7381754822071 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c9dfad4-94f4-4032-bee8-a54449030e91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c9dfad4-94f4-4032-bee8-a54449030e91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c9dfad4-94f4-4032-bee8-a54449030e91">
											<gml:posList>35.670137903208534 139.7381754822071 44.658 35.67013353816624 139.73817244967574 44.658 35.670135528177305 139.73818129534047 44.658 35.67013989321065 139.7381843168262 44.658 35.670137903208534 139.7381754822071 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-887ccd2c-298f-44e7-8152-8f037d6b64b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-887ccd2c-298f-44e7-8152-8f037d6b64b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-887ccd2c-298f-44e7-8152-8f037d6b64b9">
											<gml:posList>35.67013989321065 139.7381843168262 44.658 35.670135528177305 139.73818129534047 44.658 35.67011004426556 139.73819005209901 44.658 35.670107569733574 139.73819542349915 44.658 35.67013989321065 139.7381843168262 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24d3f390-d589-4208-a4be-ddeed5dfb470">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24d3f390-d589-4208-a4be-ddeed5dfb470">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24d3f390-d589-4208-a4be-ddeed5dfb470">
											<gml:posList>35.6700031857118 139.73810925438752 19.894 35.67002896430619 139.7382224474325 19.894 35.67002896430619 139.7382224474325 31.734 35.6700031857118 139.73810925438752 31.734 35.6700031857118 139.73810925438752 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e5e7b7e-db68-44f3-a5b3-3599a3ccdcc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e5e7b7e-db68-44f3-a5b3-3599a3ccdcc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e5e7b7e-db68-44f3-a5b3-3599a3ccdcc2">
											<gml:posList>35.67008181825998 139.73808236287437 44.658 35.67011177179932 139.73807212058057 44.658 35.67011177179932 139.73807212058057 19.894 35.6700031857118 139.73810925438752 19.894 35.6700031857118 139.73810925438752 31.734 35.67008181825998 139.73808236287437 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76fe3d0d-ea1b-44e3-b932-85d31516bd5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76fe3d0d-ea1b-44e3-b932-85d31516bd5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76fe3d0d-ea1b-44e3-b932-85d31516bd5d">
											<gml:posList>35.67013989321065 139.7381843168262 44.658 35.670107569733574 139.73819542349915 44.658 35.67002896430619 139.7382224474325 31.734 35.67002896430619 139.7382224474325 19.894 35.67013989321065 139.7381843168262 19.894 35.67013989321065 139.7381843168262 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84b0d8d7-28d6-48f1-91c1-e8d15e8da779">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84b0d8d7-28d6-48f1-91c1-e8d15e8da779">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84b0d8d7-28d6-48f1-91c1-e8d15e8da779">
											<gml:posList>35.670086210337 139.73808538432056 44.658 35.670086210337 139.73808538432056 43.719 35.67010931530005 139.73807749196303 43.719 35.67010931530005 139.73807749196303 44.658 35.670086210337 139.73808538432056 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5622224e-e59b-4aaa-868a-ec2701b520c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5622224e-e59b-4aaa-868a-ec2701b520c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5622224e-e59b-4aaa-868a-ec2701b520c1">
											<gml:posList>35.67011004426556 139.73819005209901 44.658 35.67011004426556 139.73819005209901 43.719 35.670086210337 139.73808538432056 43.719 35.670086210337 139.73808538432056 44.658 35.67011004426556 139.73819005209901 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cfc577b-25a6-44b9-ad49-b889d1210def">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cfc577b-25a6-44b9-ad49-b889d1210def">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cfc577b-25a6-44b9-ad49-b889d1210def">
											<gml:posList>35.67010931530005 139.73807749196303 44.658 35.67010931530005 139.73807749196303 43.719 35.67011383787995 139.73809735874426 43.719 35.67011383787995 139.73809735874426 44.658 35.67010931530005 139.73807749196303 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4aee46ef-8810-4fc5-8f24-45b9d8b5653c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4aee46ef-8810-4fc5-8f24-45b9d8b5653c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4aee46ef-8810-4fc5-8f24-45b9d8b5653c">
											<gml:posList>35.67011629438885 139.73809199840832 19.894 35.67011177179932 139.73807212058057 19.894 35.67011177179932 139.73807212058057 44.658 35.67011629438885 139.73809199840832 44.658 35.67011629438885 139.73809199840832 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-262c69ac-9a17-46c9-a4bf-a915db2fac9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-262c69ac-9a17-46c9-a4bf-a915db2fac9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-262c69ac-9a17-46c9-a4bf-a915db2fac9b">
											<gml:posList>35.670135528177305 139.73818129534047 44.658 35.670135528177305 139.73818129534047 43.719 35.67011004426556 139.73819005209901 43.719 35.67011004426556 139.73819005209901 44.658 35.670135528177305 139.73818129534047 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a216841-4b84-4fa7-a119-73d7fff3928e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a216841-4b84-4fa7-a119-73d7fff3928e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a216841-4b84-4fa7-a119-73d7fff3928e">
											<gml:posList>35.670126223356995 139.73813232742486 44.658 35.670126223356995 139.73813232742486 43.719 35.670130420342396 139.7381508138218 43.719 35.670130420342396 139.7381508138218 44.658 35.670126223356995 139.73813232742486 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8965b762-97ef-4ee0-b8c3-a76647640886">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8965b762-97ef-4ee0-b8c3-a76647640886">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8965b762-97ef-4ee0-b8c3-a76647640886">
											<gml:posList>35.67011383787995 139.73809735874426 44.658 35.67011383787995 139.73809735874426 43.719 35.670144007697324 139.73808704991765 43.719 35.670144007697324 139.73808704991765 44.658 35.67011383787995 139.73809735874426 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26c16c8f-724a-4f92-a306-5b4d7bdb9985">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26c16c8f-724a-4f92-a306-5b4d7bdb9985">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26c16c8f-724a-4f92-a306-5b4d7bdb9985">
											<gml:posList>35.67014648223319 139.738081689558 19.894 35.67011629438885 139.73809199840832 19.894 35.67011629438885 139.73809199840832 44.658 35.67014648223319 139.738081689558 44.658 35.67014648223319 139.738081689558 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5acc171-2291-461a-9792-00521ca83ecf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5acc171-2291-461a-9792-00521ca83ecf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5acc171-2291-461a-9792-00521ca83ecf">
											<gml:posList>35.6701328858412 139.73814542033705 19.894 35.670130597414015 139.73813535994304 19.894 35.670130597414015 139.73813535994304 44.658 35.6701328858412 139.73814542033705 44.658 35.6701328858412 139.73814542033705 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9f69019-b0dc-430f-aee3-25855d89593d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9f69019-b0dc-430f-aee3-25855d89593d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9f69019-b0dc-430f-aee3-25855d89593d">
											<gml:posList>35.67013353816624 139.73817244967574 44.658 35.67013353816624 139.73817244967574 43.719 35.670135528177305 139.73818129534047 43.719 35.670135528177305 139.73818129534047 44.658 35.67013353816624 139.73817244967574 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37845b4e-eac9-4f4e-96ef-d9ba72915383">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37845b4e-eac9-4f4e-96ef-d9ba72915383">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37845b4e-eac9-4f4e-96ef-d9ba72915383">
											<gml:posList>35.670130420342396 139.7381508138218 44.658 35.670130420342396 139.7381508138218 43.719 35.67013903505109 139.73814775483658 43.719 35.67013903505109 139.73814775483658 44.658 35.670130420342396 139.7381508138218 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-107961ce-3571-4cdc-a213-ff1f5fcdd1cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-107961ce-3571-4cdc-a213-ff1f5fcdd1cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-107961ce-3571-4cdc-a213-ff1f5fcdd1cc">
											<gml:posList>35.670141545600906 139.73814233920524 19.894 35.6701328858412 139.73814542033705 19.894 35.6701328858412 139.73814542033705 44.658 35.670141545600906 139.73814233920524 44.658 35.670141545600906 139.73814233920524 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4aa33f7d-9d83-4501-b4eb-2849fb28b914">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4aa33f7d-9d83-4501-b4eb-2849fb28b914">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4aa33f7d-9d83-4501-b4eb-2849fb28b914">
											<gml:posList>35.67014360377054 139.7381689913065 44.658 35.67014360377054 139.7381689913065 43.719 35.67013353816624 139.73817244967574 43.719 35.67013353816624 139.73817244967574 44.658 35.67014360377054 139.7381689913065 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d31c381b-6239-48a8-98f2-d452de93ff25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d31c381b-6239-48a8-98f2-d452de93ff25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d31c381b-6239-48a8-98f2-d452de93ff25">
											<gml:posList>35.67013989321065 139.7381843168262 19.894 35.670137903208534 139.7381754822071 19.894 35.670137903208534 139.7381754822071 44.658 35.67013989321065 139.7381843168262 44.658 35.67013989321065 139.7381843168262 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9680f9b5-2201-44ce-babd-4f61a72537b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9680f9b5-2201-44ce-babd-4f61a72537b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9680f9b5-2201-44ce-babd-4f61a72537b8">
											<gml:posList>35.670152284029136 139.73812342636032 44.658 35.670152284029136 139.73812342636032 43.719 35.670126223356995 139.73813232742486 43.719 35.670126223356995 139.73813232742486 44.658 35.670152284029136 139.73812342636032 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-740afbc4-6427-414f-96d0-ad12be8d3b27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-740afbc4-6427-414f-96d0-ad12be8d3b27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-740afbc4-6427-414f-96d0-ad12be8d3b27">
											<gml:posList>35.67013903505109 139.73814775483658 44.658 35.67013903505109 139.73814775483658 43.719 35.67014360377054 139.7381689913065 43.719 35.67014360377054 139.7381689913065 44.658 35.67013903505109 139.73814775483658 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c88ae67-6b9d-4ac5-8a97-5fc68ababbb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c88ae67-6b9d-4ac5-8a97-5fc68ababbb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c88ae67-6b9d-4ac5-8a97-5fc68ababbb6">
											<gml:posList>35.670137903208534 139.7381754822071 19.894 35.67014793276676 139.7381720349271 19.894 35.67014793276676 139.7381720349271 44.658 35.670137903208534 139.7381754822071 44.658 35.670137903208534 139.7381754822071 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b2501b2-5ce0-4a4d-a600-0242c2ef3c3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b2501b2-5ce0-4a4d-a600-0242c2ef3c3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b2501b2-5ce0-4a4d-a600-0242c2ef3c3b">
											<gml:posList>35.670130597414015 139.73813535994304 19.894 35.67015666709136 139.73812644782214 19.894 35.67015666709136 139.73812644782214 44.658 35.670130597414015 139.73813535994304 44.658 35.670130597414015 139.73813535994304 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73588de4-c65a-4e64-a29e-6f70853f6218">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73588de4-c65a-4e64-a29e-6f70853f6218">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73588de4-c65a-4e64-a29e-6f70853f6218">
											<gml:posList>35.67014793276676 139.7381720349271 19.894 35.670141545600906 139.73814233920524 19.894 35.670141545600906 139.73814233920524 44.658 35.67014793276676 139.7381720349271 44.658 35.67014793276676 139.7381720349271 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dac9ddc9-c1a4-4298-ab08-15a586843deb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dac9ddc9-c1a4-4298-ab08-15a586843deb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dac9ddc9-c1a4-4298-ab08-15a586843deb">
											<gml:posList>35.670144007697324 139.73808704991765 44.658 35.670144007697324 139.73808704991765 43.719 35.670152284029136 139.73812342636032 43.719 35.670152284029136 139.73812342636032 44.658 35.670144007697324 139.73808704991765 44.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b1ddf1e-ca56-4440-a1c4-d76639295420">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b1ddf1e-ca56-4440-a1c4-d76639295420">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b1ddf1e-ca56-4440-a1c4-d76639295420">
											<gml:posList>35.67015666709136 139.73812644782214 19.894 35.67014648223319 139.738081689558 19.894 35.67014648223319 139.738081689558 44.658 35.67015666709136 139.73812644782214 44.658 35.67015666709136 139.73812644782214 19.894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3045</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">160.71555</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>