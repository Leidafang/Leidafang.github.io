<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0d45ea82-7d74-43a8-b7ee-5603a0004328">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">21.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671393228516955 139.74046280615684 0 35.671398630444735 139.74045462556364 0 35.67151941706927 139.74057500204017 0 35.67156137231787 139.74051176796462 0 35.67136923191016 139.74032000405694 0 35.67132196480456 139.74039119763944 0 35.67132160468202 139.74039175037638 0 35.67125227887461 139.74049533531812 0 35.67138515328841 139.74062795915958 0 35.67140478048966 139.7405984425751 0 35.671423272908974 139.7406169791429 0 35.6714570353116 139.74056623708702 0 35.67143773113889 139.74054703867827 0 35.67145348684751 139.74052327066832 0 35.671393228516955 139.74046280615684 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671393228516955 139.74046280615684 8.71 35.67145348684751 139.74052327066832 8.71 35.67143773113889 139.74054703867827 8.71 35.6714570353116 139.74056623708702 8.71 35.671423272908974 139.7406169791429 8.71 35.67140478048966 139.7405984425751 8.71 35.67138515328841 139.74062795915958 8.71 35.67125227887461 139.74049533531812 8.71 35.67132160468202 139.74039175037638 8.71 35.67132196480456 139.74039119763944 8.71 35.67136923191016 139.74032000405694 8.71 35.67156137231787 139.74051176796462 8.71 35.67151941706927 139.74057500204017 8.71 35.671398630444735 139.74045462556364 8.71 35.671393228516955 139.74046280615684 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671393228516955 139.74046280615684 8.71 35.671398630444735 139.74045462556364 8.71 35.671398630444735 139.74045462556364 30.09 35.671393228516955 139.74046280615684 30.09 35.671393228516955 139.74046280615684 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671398630444735 139.74045462556364 8.71 35.67151941706927 139.74057500204017 8.71 35.67151941706927 139.74057500204017 30.09 35.671398630444735 139.74045462556364 30.09 35.671398630444735 139.74045462556364 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67151941706927 139.74057500204017 8.71 35.67156137231787 139.74051176796462 8.71 35.67156137231787 139.74051176796462 30.09 35.67151941706927 139.74057500204017 30.09 35.67151941706927 139.74057500204017 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156137231787 139.74051176796462 8.71 35.67136923191016 139.74032000405694 8.71 35.67136923191016 139.74032000405694 30.09 35.67156137231787 139.74051176796462 30.09 35.67156137231787 139.74051176796462 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67136923191016 139.74032000405694 8.71 35.67132196480456 139.74039119763944 8.71 35.67132196480456 139.74039119763944 30.09 35.67136923191016 139.74032000405694 30.09 35.67136923191016 139.74032000405694 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67132196480456 139.74039119763944 8.71 35.67132160468202 139.74039175037638 8.71 35.67132160468202 139.74039175037638 30.09 35.67132196480456 139.74039119763944 30.09 35.67132196480456 139.74039119763944 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67132160468202 139.74039175037638 8.71 35.67125227887461 139.74049533531812 8.71 35.67125227887461 139.74049533531812 30.09 35.67132160468202 139.74039175037638 30.09 35.67132160468202 139.74039175037638 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67125227887461 139.74049533531812 8.71 35.67138515328841 139.74062795915958 8.71 35.67138515328841 139.74062795915958 30.09 35.67125227887461 139.74049533531812 30.09 35.67125227887461 139.74049533531812 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138515328841 139.74062795915958 8.71 35.67140478048966 139.7405984425751 8.71 35.67140478048966 139.7405984425751 30.09 35.67138515328841 139.74062795915958 30.09 35.67138515328841 139.74062795915958 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67140478048966 139.7405984425751 8.71 35.671423272908974 139.7406169791429 8.71 35.671423272908974 139.7406169791429 30.09 35.67140478048966 139.7405984425751 30.09 35.67140478048966 139.7405984425751 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671423272908974 139.7406169791429 8.71 35.6714570353116 139.74056623708702 8.71 35.6714570353116 139.74056623708702 30.09 35.671423272908974 139.7406169791429 30.09 35.671423272908974 139.7406169791429 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714570353116 139.74056623708702 8.71 35.67143773113889 139.74054703867827 8.71 35.67143773113889 139.74054703867827 30.09 35.6714570353116 139.74056623708702 30.09 35.6714570353116 139.74056623708702 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67143773113889 139.74054703867827 8.71 35.67145348684751 139.74052327066832 8.71 35.67145348684751 139.74052327066832 30.09 35.67143773113889 139.74054703867827 30.09 35.67143773113889 139.74054703867827 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145348684751 139.74052327066832 8.71 35.671393228516955 139.74046280615684 8.71 35.671393228516955 139.74046280615684 30.09 35.67145348684751 139.74052327066832 30.09 35.67145348684751 139.74052327066832 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671393228516955 139.74046280615684 30.09 35.671398630444735 139.74045462556364 30.09 35.67151941706927 139.74057500204017 30.09 35.67156137231787 139.74051176796462 30.09 35.67136923191016 139.74032000405694 30.09 35.67132196480456 139.74039119763944 30.09 35.67132160468202 139.74039175037638 30.09 35.67125227887461 139.74049533531812 30.09 35.67138515328841 139.74062795915958 30.09 35.67140478048966 139.7405984425751 30.09 35.671423272908974 139.7406169791429 30.09 35.6714570353116 139.74056623708702 30.09 35.67143773113889 139.74054703867827 30.09 35.67145348684751 139.74052327066832 30.09 35.671393228516955 139.74046280615684 30.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-bec9e314-4a70-4846-b041-7b0d039b96de"/>
							<gml:surfaceMember xlink:href="#poly-1a176b72-7579-4814-8821-be4c10afdb82"/>
							<gml:surfaceMember xlink:href="#poly-5d69ba44-bc42-424b-9fc9-d372d5edfd99"/>
							<gml:surfaceMember xlink:href="#poly-f53acfdb-6f83-459e-b906-1ac708c27c7f"/>
							<gml:surfaceMember xlink:href="#poly-1ffd9fcc-8dcd-4228-ba8a-dd39b472681c"/>
							<gml:surfaceMember xlink:href="#poly-8eb83734-b66f-44ee-8d1f-c94cdc0f8b73"/>
							<gml:surfaceMember xlink:href="#poly-3db41419-a7ab-4795-9251-dbaf123944dd"/>
							<gml:surfaceMember xlink:href="#poly-7b4e76a1-2395-4687-8603-7c12e6fbb8f8"/>
							<gml:surfaceMember xlink:href="#poly-a9a21611-1cca-4d8c-9aea-d7bf3820cb12"/>
							<gml:surfaceMember xlink:href="#poly-a2a1dad0-9dc8-4d8d-aac3-c34145a41f84"/>
							<gml:surfaceMember xlink:href="#poly-acf1ac8a-80b1-45fc-901b-db91de108a84"/>
							<gml:surfaceMember xlink:href="#poly-b4a62ebd-3f9c-4414-9951-c4ef7fe03032"/>
							<gml:surfaceMember xlink:href="#poly-1cf1144a-8021-44c2-b227-e9969692d768"/>
							<gml:surfaceMember xlink:href="#poly-4f148dfc-af64-47f4-b405-8f75b8e057fa"/>
							<gml:surfaceMember xlink:href="#poly-5e962ca4-19a0-49d6-b152-e40bbcf222b8"/>
							<gml:surfaceMember xlink:href="#poly-54627157-9783-4ecf-97d3-0a281aa59613"/>
							<gml:surfaceMember xlink:href="#poly-74f9b927-f3f5-45d1-812b-e1cff7e661f7"/>
							<gml:surfaceMember xlink:href="#poly-714631bc-1fcc-4f8e-b534-6430cad88cd9"/>
							<gml:surfaceMember xlink:href="#poly-e134df95-7bb5-4448-895b-659888f30ae1"/>
							<gml:surfaceMember xlink:href="#poly-9f21bc65-0406-4e51-b24c-22672aaef72c"/>
							<gml:surfaceMember xlink:href="#poly-02de2452-919a-4990-9529-015622437490"/>
							<gml:surfaceMember xlink:href="#poly-3491be8b-c7fe-4709-8d64-28f92cd905c9"/>
							<gml:surfaceMember xlink:href="#poly-5df42545-ec9f-4672-84b6-9ba79d20f353"/>
							<gml:surfaceMember xlink:href="#poly-cdc9cb76-db19-4919-8619-bbb4aeb01196"/>
							<gml:surfaceMember xlink:href="#poly-94474a0a-9f23-41c7-b873-eeb1b20addca"/>
							<gml:surfaceMember xlink:href="#poly-7ce713e8-2753-4471-b9da-83f0ae18235c"/>
							<gml:surfaceMember xlink:href="#poly-9e7ffda4-def2-4758-a55f-583d1b41a143"/>
							<gml:surfaceMember xlink:href="#poly-3cd27b90-059e-4515-b08e-672ad5b20aff"/>
							<gml:surfaceMember xlink:href="#poly-c0d27d23-a429-49bd-bdd3-bef1245b6c83"/>
							<gml:surfaceMember xlink:href="#poly-5077cece-29b6-49f3-b022-e959cb7e3cc2"/>
							<gml:surfaceMember xlink:href="#poly-8288e599-9d5a-458b-84fd-05dcfe11a54c"/>
							<gml:surfaceMember xlink:href="#poly-eff0c902-15c7-4de9-ba80-f573d7b9e6a6"/>
							<gml:surfaceMember xlink:href="#poly-d5f8bde0-7a1d-41cf-b167-26122ea7713e"/>
							<gml:surfaceMember xlink:href="#poly-5b7d083c-edb2-4def-b2b8-639727013a50"/>
							<gml:surfaceMember xlink:href="#poly-cd9d4953-aae6-4da5-8dd7-dec8e6a3a5e0"/>
							<gml:surfaceMember xlink:href="#poly-4c7b3f0f-2c19-44ab-9fd9-9f7b437e30db"/>
							<gml:surfaceMember xlink:href="#poly-7472b5bb-3ccf-4c1d-970b-da811a9fbe80"/>
							<gml:surfaceMember xlink:href="#poly-94129202-53a2-4e87-8d43-d03034a040a4"/>
							<gml:surfaceMember xlink:href="#poly-95c2d380-6081-4ef5-9a6d-9144e8892063"/>
							<gml:surfaceMember xlink:href="#poly-d47cea92-b5ed-461b-85b9-b064ffb008a7"/>
							<gml:surfaceMember xlink:href="#poly-66e85f38-0f25-4d85-afc4-dea5e0958601"/>
							<gml:surfaceMember xlink:href="#poly-a303a586-cefd-467e-bc46-e957333ccbbf"/>
							<gml:surfaceMember xlink:href="#poly-ba6e940d-fc37-43b4-bf6c-8c358e9171ec"/>
							<gml:surfaceMember xlink:href="#poly-33a6ad59-5010-4281-8cc2-fd971f36e2ea"/>
							<gml:surfaceMember xlink:href="#poly-da199ac0-6be8-40a3-bb9e-5f9b2438ee5e"/>
							<gml:surfaceMember xlink:href="#poly-71fa705d-3574-4481-9393-a0523272fcfa"/>
							<gml:surfaceMember xlink:href="#poly-a601cc8b-a18c-4ea8-83c8-0cb76e917e98"/>
							<gml:surfaceMember xlink:href="#poly-17720cc8-1e1f-4620-8281-2e0533e456a3"/>
							<gml:surfaceMember xlink:href="#poly-3cc0d7e9-314b-4e63-8a7e-25fcac31e192"/>
							<gml:surfaceMember xlink:href="#poly-a758156a-b131-4aea-becd-19334c7a4d78"/>
							<gml:surfaceMember xlink:href="#poly-219286a4-7387-41fa-9f54-aa8b6aaf318f"/>
							<gml:surfaceMember xlink:href="#poly-72b3a748-04a8-4007-aab8-5e0287c2e3d6"/>
							<gml:surfaceMember xlink:href="#poly-77e4b35a-c56c-47eb-a1ce-1d1ffb42d105"/>
							<gml:surfaceMember xlink:href="#poly-c7af208a-7952-4954-8c20-623e5b13f8c2"/>
							<gml:surfaceMember xlink:href="#poly-fa600420-5fbf-44eb-8fc2-b1ed83184c3c"/>
							<gml:surfaceMember xlink:href="#poly-526fcd71-2b56-4b9f-816e-b1de9e954b5d"/>
							<gml:surfaceMember xlink:href="#poly-51a2be93-a75b-4454-bb99-291e754069c2"/>
							<gml:surfaceMember xlink:href="#poly-ceaf18eb-de7e-46d4-8f69-5ce354ea75fa"/>
							<gml:surfaceMember xlink:href="#poly-d875037c-32c3-4855-bb8f-638d066eaa3f"/>
							<gml:surfaceMember xlink:href="#poly-119a1113-1232-480b-8ce9-b72f5629c358"/>
							<gml:surfaceMember xlink:href="#poly-d4d9be9a-844c-4469-93b8-dd05d42fd11a"/>
							<gml:surfaceMember xlink:href="#poly-7d991cbe-e776-4cea-8bea-67e75ef58e3c"/>
							<gml:surfaceMember xlink:href="#poly-9dd4e71e-bf9e-4056-87f2-7dcf7a829561"/>
							<gml:surfaceMember xlink:href="#poly-cca060f5-88c5-43b5-ac35-88fb91f9c982"/>
							<gml:surfaceMember xlink:href="#poly-61d0a2eb-6ccc-4b52-bc5e-c71ffaaae923"/>
							<gml:surfaceMember xlink:href="#poly-8213fac0-89dd-4d6c-979e-da8a52731ec1"/>
							<gml:surfaceMember xlink:href="#poly-2066af57-552f-4499-b646-7668a4213f1e"/>
							<gml:surfaceMember xlink:href="#poly-9e2c7637-b90e-4090-b6fa-a1544d68f43a"/>
							<gml:surfaceMember xlink:href="#poly-4b758037-cea5-4d0a-bbc7-3ecf8ee6d2f8"/>
							<gml:surfaceMember xlink:href="#poly-992aa5a9-c43b-44f6-9162-68ee435f8449"/>
							<gml:surfaceMember xlink:href="#poly-d125ad30-b06c-42d6-a228-e75e3d346510"/>
							<gml:surfaceMember xlink:href="#poly-e1110d90-d1c4-440f-8c5f-cf5e37a3fd85"/>
							<gml:surfaceMember xlink:href="#poly-cfc7e442-0b0d-469d-acfb-733327784b20"/>
							<gml:surfaceMember xlink:href="#poly-f6d98767-270f-4131-b325-e93330f55325"/>
							<gml:surfaceMember xlink:href="#poly-0f3047dd-ca3d-4456-84f0-454962562765"/>
							<gml:surfaceMember xlink:href="#poly-0986c17e-da19-448a-bcac-7b9763d0b44a"/>
							<gml:surfaceMember xlink:href="#poly-bd234a4e-f1f0-4fed-8127-ecd6a843e9c8"/>
							<gml:surfaceMember xlink:href="#poly-1332d06a-860c-427e-9d45-fd760b63df95"/>
							<gml:surfaceMember xlink:href="#poly-930f53a3-6cf9-4413-822b-5f0b9b0c9ca7"/>
							<gml:surfaceMember xlink:href="#poly-b8358294-03dd-4f13-a8b3-39a8544002fb"/>
							<gml:surfaceMember xlink:href="#poly-89dff13e-df90-4ad6-b0c2-f98cd5cbf044"/>
							<gml:surfaceMember xlink:href="#poly-0060cf73-4ec0-4ea1-8932-5663cb77d9e2"/>
							<gml:surfaceMember xlink:href="#poly-935e894e-36c7-4b3f-98b3-a8aa275b3582"/>
							<gml:surfaceMember xlink:href="#poly-4c30ad74-daa9-46ed-b0e1-78d69d9edc07"/>
							<gml:surfaceMember xlink:href="#poly-a34dc877-c4e8-40ea-b4cb-60c5d8b1ed31"/>
							<gml:surfaceMember xlink:href="#poly-d0a01a74-7e46-4ff1-b017-e205ea62bae8"/>
							<gml:surfaceMember xlink:href="#poly-23d7a644-9d7c-4f26-bd79-fcc413e8c8a0"/>
							<gml:surfaceMember xlink:href="#poly-72b92299-cfbd-4d40-8380-cb19a2a0574b"/>
							<gml:surfaceMember xlink:href="#poly-0edffb06-1fdb-458a-a0d0-3cccb2756dd0"/>
							<gml:surfaceMember xlink:href="#poly-039830ea-c152-4745-ba28-58d484f20807"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0d45ea82-7d74-43a8-b7ee-5603a0004328_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68ccaa37-c9dc-48be-a884-f70390bca614">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68ccaa37-c9dc-48be-a884-f70390bca614_0">
											<gml:posList>35.67139375292237 139.74041815600427 32.863 35.67139913688786 139.74041006380006 9.29 35.67139375292237 139.74041815600427 9.29 35.67139375292237 139.74041815600427 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10203f45-de02-4a57-9413-04af58187c80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10203f45-de02-4a57-9413-04af58187c80_0">
											<gml:posList>35.67139375292237 139.74041815600427 32.863 35.67139913688786 139.74041006380006 32.863 35.67139913688786 139.74041006380006 9.29 35.67139375292237 139.74041815600427 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6beaf24-9fda-4e35-9561-c67672aaf9d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6beaf24-9fda-4e35-9561-c67672aaf9d1_0">
											<gml:posList>35.67140196937858 139.7404128883956 32.863 35.67141990248141 139.7404307848767 24.783 35.67139913688786 139.74041006380006 32.863 35.67140196937858 139.7404128883956 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1b3b3e7-314b-4490-89a0-8f735f9120eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1b3b3e7-314b-4490-89a0-8f735f9120eb_0">
											<gml:posList>35.67139913688786 139.74041006380006 32.863 35.67141990248141 139.7404307848767 24.783 35.67139913688786 139.74041006380006 9.29 35.67139913688786 139.74041006380006 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcc2fe14-68de-4ec6-a56e-312ed07e0a52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcc2fe14-68de-4ec6-a56e-312ed07e0a52_0">
											<gml:posList>35.67141990248141 139.7404307848767 24.783 35.67141990248141 139.7404307848767 9.29 35.67139913688786 139.74041006380006 9.29 35.67141990248141 139.7404307848767 24.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44e014d8-f588-4a58-8c66-a95fe5bd1b3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44e014d8-f588-4a58-8c66-a95fe5bd1b3c_0">
											<gml:posList>35.67139293361989 139.74041938310407 32.863 35.67139293361989 139.74041938310407 9.29 35.6714054904021 139.74043191726324 32.863 35.67139293361989 139.74041938310407 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc200a8d-d68b-49c1-9a77-8ac11b47c030">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc200a8d-d68b-49c1-9a77-8ac11b47c030_0">
											<gml:posList>35.67139293361989 139.74041938310407 9.29 35.671455013893805 139.74048133673762 9.29 35.6714054904021 139.74043191726324 32.863 35.67139293361989 139.74041938310407 9.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1d181e8-c567-4d8c-ba87-769069709135">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1d181e8-c567-4d8c-ba87-769069709135_0">
											<gml:posList>35.6714054904021 139.74043191726324 32.863 35.671455013893805 139.74048133673762 34.829 35.6714054904021 139.74043191726324 34.829 35.6714054904021 139.74043191726324 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94c52447-2627-4ff2-89a9-5940743f6318">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94c52447-2627-4ff2-89a9-5940743f6318_0">
											<gml:posList>35.6714054904021 139.74043191726324 32.863 35.671455013893805 139.74048133673762 9.29 35.671455013893805 139.74048133673762 34.829 35.6714054904021 139.74043191726324 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45432a4c-8aa8-4aa2-9467-34b8b646982a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45432a4c-8aa8-4aa2-9467-34b8b646982a_0">
											<gml:posList>35.6714054904021 139.74043191726324 32.863 35.6714054904021 139.74043191726324 34.829 35.67139293361989 139.74041938310407 32.863 35.6714054904021 139.74043191726324 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cbb6f5f-c661-45ec-8681-4eaec032e5f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cbb6f5f-c661-45ec-8681-4eaec032e5f0_0">
											<gml:posList>35.67139293361989 139.74041938310407 32.863 35.6714054904021 139.74043191726324 34.829 35.67139293361989 139.74041938310407 35.451 35.67139293361989 139.74041938310407 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7823fb4-308a-4504-891f-e5d30b4e70a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7823fb4-308a-4504-891f-e5d30b4e70a7_0">
											<gml:posList>35.67139293361989 139.74041938310407 35.451 35.6714054904021 139.74043191726324 34.829 35.67145500488009 139.74048133674808 35.451 35.67139293361989 139.74041938310407 35.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-caa13696-29af-43a0-a2f9-00abda06c5c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-caa13696-29af-43a0-a2f9-00abda06c5c4_0">
											<gml:posList>35.6714054904021 139.74043191726324 34.829 35.67145500488009 139.74048133674808 34.829 35.67145500488009 139.74048133674808 35.451 35.6714054904021 139.74043191726324 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ee3fbba-c4f4-4197-b322-3b31283836b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ee3fbba-c4f4-4197-b322-3b31283836b1_0">
											<gml:posList>35.67146059474269 139.74047139955323 31.11 35.67145729318205 139.74046811154773 35.451 35.67146059474269 139.74047139955323 34.829 35.67146059474269 139.74047139955323 31.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35921211-3360-4d88-a507-b8a0bf5923b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35921211-3360-4d88-a507-b8a0bf5923b6_0">
											<gml:posList>35.67145729318205 139.74046811154773 35.451 35.67146059474269 139.74047139955323 35.451 35.67146059474269 139.74047139955323 34.829 35.67145729318205 139.74046811154773 35.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84782af0-da52-423e-96e9-c1a76abe9439">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84782af0-da52-423e-96e9-c1a76abe9439_0">
											<gml:posList>35.6714606669121 139.7404714767945 34.829 35.67146059474269 139.74047139955323 31.11 35.67146059474269 139.74047139955323 34.829 35.6714606669121 139.7404714767945 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f3f46ea-16f2-45bb-b020-7bfd78f7ab47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f3f46ea-16f2-45bb-b020-7bfd78f7ab47_0">
											<gml:posList>35.671460712960375 139.74047274707812 9.29 35.67146120814426 139.74047200639524 34.829 35.671460712960375 139.74047274707812 34.829 35.671460712960375 139.74047274707812 9.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccd91ae1-5c52-4bb6-892b-6719de3afa2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccd91ae1-5c52-4bb6-892b-6719de3afa2a_0">
											<gml:posList>35.671460712960375 139.74047274707812 9.29 35.67146120814426 139.74047200639524 9.29 35.67146120814426 139.74047200639524 34.829 35.671460712960375 139.74047274707812 9.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e3a612d-dd1a-4e3f-8917-7700f6862d82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e3a612d-dd1a-4e3f-8917-7700f6862d82_0">
											<gml:posList>35.6714102121006 139.74050010122758 35.528 35.671419746987176 139.74050966741837 33.902 35.6714102121006 139.74050010122758 33.902 35.6714102121006 139.74050010122758 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fef8d700-f0dc-48ec-a6d1-2b387dbb4f8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fef8d700-f0dc-48ec-a6d1-2b387dbb4f8f_0">
											<gml:posList>35.6714102121006 139.74050010122758 35.528 35.671419746987176 139.74050966741837 35.528 35.671419746987176 139.74050966741837 33.902 35.6714102121006 139.74050010122758 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a69ee4d-2c5e-46d3-b8e6-fb4921af2901">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a69ee4d-2c5e-46d3-b8e6-fb4921af2901_0">
											<gml:posList>35.67142482487551 139.7405020726602 33.902 35.671419746987176 139.74050966741837 33.902 35.67142482487551 139.7405020726602 34.475 35.67142482487551 139.7405020726602 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7860c5a-f74c-41d8-9d7a-3074c824c428">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7860c5a-f74c-41d8-9d7a-3074c824c428_0">
											<gml:posList>35.67142590527867 139.74050045863433 34.475 35.67142482487551 139.7405020726602 34.475 35.67142590527867 139.74050045863433 35.528 35.67142590527867 139.74050045863433 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5413262-3f28-427a-a29f-678069760dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5413262-3f28-427a-a29f-678069760dc2_0">
											<gml:posList>35.67142590527867 139.74050045863433 35.528 35.67142482487551 139.7405020726602 34.475 35.671419746987176 139.74050966741837 35.528 35.67142590527867 139.74050045863433 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adda6404-4371-48bb-9941-ebde94941984">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adda6404-4371-48bb-9941-ebde94941984_0">
											<gml:posList>35.67142482487551 139.7405020726602 34.475 35.671419746987176 139.74050966741837 33.902 35.671419746987176 139.74050966741837 35.528 35.67142482487551 139.7405020726602 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e66fc8a2-5f80-4ddd-b0be-1e033f44fec4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e66fc8a2-5f80-4ddd-b0be-1e033f44fec4_0">
											<gml:posList>35.67142590527867 139.74050045863433 35.528 35.67144419927493 139.7405188186716 34.475 35.67142590527867 139.74050045863433 34.475 35.67142590527867 139.74050045863433 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5249c0f-c304-4812-bff7-b97eaa6c4ee3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5249c0f-c304-4812-bff7-b97eaa6c4ee3_0">
											<gml:posList>35.67142590527867 139.74050045863433 35.528 35.67144419927493 139.7405188186716 35.528 35.67144419927493 139.7405188186716 34.475 35.67142590527867 139.74050045863433 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6cf016f-a69e-40d9-a554-5c85c71ac677">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6cf016f-a69e-40d9-a554-5c85c71ac677_0">
											<gml:posList>35.67142482487551 139.7405020726602 34.475 35.67144311887153 139.7405204326976 33.902 35.67142482487551 139.7405020726602 33.902 35.67142482487551 139.7405020726602 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bddd9422-633a-4b1b-9cd8-d214d0d8a246">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bddd9422-633a-4b1b-9cd8-d214d0d8a246_0">
											<gml:posList>35.67142482487551 139.7405020726602 34.475 35.67144311887153 139.7405204326976 34.475 35.67144311887153 139.7405204326976 33.902 35.67142482487551 139.7405020726602 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3486cd00-4ad5-4726-92c0-c27596c169af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3486cd00-4ad5-4726-92c0-c27596c169af_0">
											<gml:posList>35.6714102121006 139.74050010122758 33.902 35.67139473535348 139.74052326135433 35.528 35.6714102121006 139.74050010122758 35.528 35.6714102121006 139.74050010122758 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dea49fd-63af-4da3-a1ca-4015c4036f71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6dea49fd-63af-4da3-a1ca-4015c4036f71_0">
											<gml:posList>35.6714102121006 139.74050010122758 33.902 35.67139473535348 139.74052326135433 33.902 35.67139473535348 139.74052326135433 35.528 35.6714102121006 139.74050010122758 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ceb251a-eae3-4226-bf59-25a057b936d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ceb251a-eae3-4226-bf59-25a057b936d2_0">
											<gml:posList>35.67141044879506 139.74051482580657 35.528 35.6714007071792 139.74052940728618 33.902 35.67141044879506 139.74051482580657 33.902 35.67141044879506 139.74051482580657 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74794c80-22cb-45c2-afbd-e5f9a7a74829">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74794c80-22cb-45c2-afbd-e5f9a7a74829_0">
											<gml:posList>35.67141044879506 139.74051482580657 35.528 35.6714007071792 139.74052940728618 35.528 35.6714007071792 139.74052940728618 33.902 35.67141044879506 139.74051482580657 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f6fb3de-c9ba-42b5-ba7d-107e1e564097">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f6fb3de-c9ba-42b5-ba7d-107e1e564097_0">
											<gml:posList>35.67141044879506 139.74051482580657 35.528 35.671432251842404 139.740536705585 33.902 35.671432251842404 139.740536705585 35.528 35.67141044879506 139.74051482580657 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42c59bd5-141e-4e9a-b221-06b4666ab8ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42c59bd5-141e-4e9a-b221-06b4666ab8ce_0">
											<gml:posList>35.67141044879506 139.74051482580657 35.528 35.67141044879506 139.74051482580657 33.902 35.671432251842404 139.740536705585 33.902 35.67141044879506 139.74051482580657 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd7ab222-17c9-4c8a-8986-5e32c5ce7d3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd7ab222-17c9-4c8a-8986-5e32c5ce7d3b_0">
											<gml:posList>35.6714007071792 139.74052940728618 35.528 35.67139472633976 139.74052326136476 33.902 35.6714007071792 139.74052940728618 33.902 35.6714007071792 139.74052940728618 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40528fea-ab0b-4d69-9086-7fb689d8072b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40528fea-ab0b-4d69-9086-7fb689d8072b_0">
											<gml:posList>35.6714007071792 139.74052940728618 35.528 35.67139472633976 139.74052326136476 35.528 35.67139472633976 139.74052326136476 33.902 35.6714007071792 139.74052940728618 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82cf009d-b507-4901-8f44-9c8bcbe75087">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82cf009d-b507-4901-8f44-9c8bcbe75087_0">
											<gml:posList>35.67144311887153 139.7405204326976 33.902 35.67144311887153 139.7405204326976 34.475 35.671432251842404 139.740536705585 33.902 35.67144311887153 139.7405204326976 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f1b4eff-8562-4599-a635-a06c35b6ffbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f1b4eff-8562-4599-a635-a06c35b6ffbb_0">
											<gml:posList>35.671432251842404 139.740536705585 33.902 35.67144311887153 139.7405204326976 34.475 35.671432251842404 139.740536705585 35.528 35.671432251842404 139.740536705585 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2673c7bf-4531-4691-a211-809217619d81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2673c7bf-4531-4691-a211-809217619d81_0">
											<gml:posList>35.671432251842404 139.740536705585 35.528 35.67144311887153 139.7405204326976 34.475 35.67144419927493 139.7405188186716 35.528 35.671432251842404 139.740536705585 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-918b80d4-e603-46c9-a5ac-4e4bc5f76b71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-918b80d4-e603-46c9-a5ac-4e4bc5f76b71_0">
											<gml:posList>35.67144311887153 139.7405204326976 34.475 35.67144419927493 139.7405188186716 34.475 35.67144419927493 139.7405188186716 35.528 35.67144311887153 139.7405204326976 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d37fca25-483a-47b5-86f6-37ed1d5cd8dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d37fca25-483a-47b5-86f6-37ed1d5cd8dc_0">
											<gml:posList>35.671399127865605 139.7404100527641 32.863 35.67139375292237 139.74041815600427 32.863 35.671399127865605 139.7404100527641 35.451 35.671399127865605 139.7404100527641 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aebe374b-ed8a-4203-b8eb-95dcbb67facf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aebe374b-ed8a-4203-b8eb-95dcbb67facf_0">
											<gml:posList>35.671399127865605 139.7404100527641 35.451 35.67139375292237 139.74041815600427 32.863 35.67139293361989 139.74041938310407 35.451 35.671399127865605 139.7404100527641 35.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23868065-3385-4e66-8a2a-13b5601bd652">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23868065-3385-4e66-8a2a-13b5601bd652_0">
											<gml:posList>35.67139293361989 139.74041938310407 35.451 35.67139375292237 139.74041815600427 32.863 35.67139293361989 139.74041938310407 32.863 35.67139293361989 139.74041938310407 35.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bdaeaaf-a729-4d36-bdf7-9b2a58f7eded">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bdaeaaf-a729-4d36-bdf7-9b2a58f7eded_0">
											<gml:posList>35.67139375292237 139.74041815600427 32.863 35.67139375292237 139.74041815600427 9.29 35.67139293361989 139.74041938310407 9.29 35.67139375292237 139.74041815600427 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48b49c4e-1b32-423d-9a16-468b09946505">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48b49c4e-1b32-423d-9a16-468b09946505_0">
											<gml:posList>35.67139293361989 139.74041938310407 32.863 35.67139375292237 139.74041815600427 32.863 35.67139293361989 139.74041938310407 9.29 35.67139293361989 139.74041938310407 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c3da50c-1c39-4cea-84d6-388e5a42e937">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c3da50c-1c39-4cea-84d6-388e5a42e937_0">
											<gml:posList>35.6714606669121 139.7404714767945 34.829 35.67146059474269 139.74047139955323 34.829 35.67146059474269 139.74047139955323 35.451 35.6714606669121 139.7404714767945 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a994b71c-8914-4af8-8531-9ddd3c46ea2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a994b71c-8914-4af8-8531-9ddd3c46ea2c_0">
											<gml:posList>35.67140196937858 139.7404128883956 32.863 35.671399127865605 139.7404100527641 35.451 35.67145729318205 139.74046811154773 35.451 35.67140196937858 139.7404128883956 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9440e93c-56fe-4769-9941-83392536ac1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9440e93c-56fe-4769-9941-83392536ac1a_0">
											<gml:posList>35.67146059474269 139.74047139955323 35.451 35.67146120814426 139.74047200639524 35.451 35.6714606669121 139.7404714767945 34.829 35.67146059474269 139.74047139955323 35.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16f5100b-8a1f-435c-b456-a8f56f07164e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16f5100b-8a1f-435c-b456-a8f56f07164e_0">
											<gml:posList>35.67146059474269 139.74047139955323 31.11 35.67140196937858 139.7404128883956 32.863 35.67145729318205 139.74046811154773 35.451 35.67146059474269 139.74047139955323 31.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54d6f947-6c1d-4f9a-bb33-1365232803a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54d6f947-6c1d-4f9a-bb33-1365232803a0_0">
											<gml:posList>35.671399127865605 139.7404100527641 32.863 35.671399127865605 139.7404100527641 35.451 35.67140196937858 139.7404128883956 32.863 35.671399127865605 139.7404100527641 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-972672fe-9947-4833-9ec9-1ade92db180c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-972672fe-9947-4833-9ec9-1ade92db180c_0">
											<gml:posList>35.6714606669121 139.7404714767945 34.829 35.67146120814426 139.74047200639524 35.451 35.67146120814426 139.74047200639524 34.829 35.6714606669121 139.7404714767945 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-400133df-2092-4db7-9250-83770d036ced">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-400133df-2092-4db7-9250-83770d036ced_0">
											<gml:posList>35.67146059474269 139.74047139955323 31.11 35.6714606669121 139.7404714767945 34.829 35.67146120814426 139.74047200639524 34.829 35.67146059474269 139.74047139955323 31.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cacf3a09-9981-477b-b04f-0d0c6a754cc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cacf3a09-9981-477b-b04f-0d0c6a754cc9_0">
											<gml:posList>35.67146059474269 139.74047139955323 31.11 35.67146120814426 139.74047200639524 34.829 35.67146120814426 139.74047200639524 9.29 35.67146059474269 139.74047139955323 31.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af309df7-4310-4636-ae26-a9303f755243">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af309df7-4310-4636-ae26-a9303f755243_0">
											<gml:posList>35.67141990248141 139.7404307848767 24.783 35.67146120814426 139.74047200639524 9.29 35.67141990248141 139.7404307848767 9.29 35.67141990248141 139.7404307848767 24.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd463f4a-8c64-4434-92d4-7326488c3664">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd463f4a-8c64-4434-92d4-7326488c3664_0">
											<gml:posList>35.67141990248141 139.7404307848767 24.783 35.67140196937858 139.7404128883956 32.863 35.67146059474269 139.74047139955323 31.11 35.67141990248141 139.7404307848767 24.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c0ff97f-c973-4ea0-af77-2529a11f644c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c0ff97f-c973-4ea0-af77-2529a11f644c_0">
											<gml:posList>35.67141990248141 139.7404307848767 24.783 35.67146059474269 139.74047139955323 31.11 35.67146120814426 139.74047200639524 9.29 35.67141990248141 139.7404307848767 24.783</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea0109ea-1e12-47b3-b0bd-4d8c8281a737">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea0109ea-1e12-47b3-b0bd-4d8c8281a737_0">
											<gml:posList>35.67146059474269 139.74047139955323 35.451 35.67145500488009 139.74048133674808 35.451 35.67146120814426 139.74047200639524 35.451 35.67146059474269 139.74047139955323 35.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f5c4c27-785c-4268-9987-c83e7ef7f377">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f5c4c27-785c-4268-9987-c83e7ef7f377_0">
											<gml:posList>35.67139293361989 139.74041938310407 35.451 35.67145500488009 139.74048133674808 35.451 35.67145729318205 139.74046811154773 35.451 35.67139293361989 139.74041938310407 35.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24c7a623-64b3-4f50-96eb-088091e6046d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24c7a623-64b3-4f50-96eb-088091e6046d_0">
											<gml:posList>35.671399127865605 139.7404100527641 35.451 35.67139293361989 139.74041938310407 35.451 35.67145729318205 139.74046811154773 35.451 35.671399127865605 139.7404100527641 35.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b93333ec-0157-49c7-97bc-3a592ce54149">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b93333ec-0157-49c7-97bc-3a592ce54149_0">
											<gml:posList>35.67145500488009 139.74048133674808 35.451 35.67146059474269 139.74047139955323 35.451 35.67145729318205 139.74046811154773 35.451 35.67145500488009 139.74048133674808 35.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-571f3c17-0eaf-4f3a-a46f-f1961b4289d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-571f3c17-0eaf-4f3a-a46f-f1961b4289d1_0">
											<gml:posList>35.671455013893805 139.74048133673762 9.29 35.671460712960375 139.74047274707812 9.29 35.671455013893805 139.74048133673762 34.829 35.671455013893805 139.74048133673762 9.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e7fd68e-4a2c-4e50-88a1-6f5a2f95c5c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e7fd68e-4a2c-4e50-88a1-6f5a2f95c5c0_0">
											<gml:posList>35.671455013893805 139.74048133673762 34.829 35.671460712960375 139.74047274707812 34.829 35.67145500488009 139.74048133674808 35.451 35.671455013893805 139.74048133673762 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d994930-1e0f-4223-8dbe-b6f7c097ec75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d994930-1e0f-4223-8dbe-b6f7c097ec75_0">
											<gml:posList>35.67145500488009 139.74048133674808 35.451 35.671460712960375 139.74047274707812 34.829 35.67146120814426 139.74047200639524 35.451 35.67145500488009 139.74048133674808 35.451</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce117351-f696-4935-ad38-bbc67d7a719c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce117351-f696-4935-ad38-bbc67d7a719c_0">
											<gml:posList>35.671460712960375 139.74047274707812 34.829 35.67146120814426 139.74047200639524 34.829 35.67146120814426 139.74047200639524 35.451 35.671460712960375 139.74047274707812 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cce1500-0d25-403d-b345-c2efce1e34e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cce1500-0d25-403d-b345-c2efce1e34e8_0">
											<gml:posList>35.671455013893805 139.74048133673762 34.829 35.671460712960375 139.74047274707812 9.29 35.671460712960375 139.74047274707812 34.829 35.671455013893805 139.74048133673762 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-089a305a-8f0c-44ed-aa10-97f3171413d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-089a305a-8f0c-44ed-aa10-97f3171413d5_0">
											<gml:posList>35.67141044879506 139.74051482580657 35.528 35.6714102121006 139.74050010122758 35.528 35.67139472633976 139.74052326136476 35.528 35.67141044879506 139.74051482580657 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6259ca59-4cca-49a4-8ec3-179d61999068">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6259ca59-4cca-49a4-8ec3-179d61999068_0">
											<gml:posList>35.67139472633976 139.74052326136476 35.528 35.6714007071792 139.74052940728618 35.528 35.67141044879506 139.74051482580657 35.528 35.67139472633976 139.74052326136476 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15068886-cf8c-4241-914f-75a800df1f99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15068886-cf8c-4241-914f-75a800df1f99_0">
											<gml:posList>35.671419746987176 139.74050966741837 35.528 35.6714102121006 139.74050010122758 35.528 35.67141044879506 139.74051482580657 35.528 35.671419746987176 139.74050966741837 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3add8216-5d87-42be-991e-40a6a3617aaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3add8216-5d87-42be-991e-40a6a3617aaa_0">
											<gml:posList>35.671419746987176 139.74050966741837 35.528 35.67144419927493 139.7405188186716 35.528 35.67142590527867 139.74050045863433 35.528 35.671419746987176 139.74050966741837 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a2357e9-7534-4f83-8b0f-d140dbea9f93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a2357e9-7534-4f83-8b0f-d140dbea9f93_0">
											<gml:posList>35.671432251842404 139.740536705585 35.528 35.67144419927493 139.7405188186716 35.528 35.671419746987176 139.74050966741837 35.528 35.671432251842404 139.740536705585 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8481807d-0ca4-4c13-8ceb-5662142a76b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8481807d-0ca4-4c13-8ceb-5662142a76b9_0">
											<gml:posList>35.671432251842404 139.740536705585 35.528 35.671419746987176 139.74050966741837 35.528 35.67141044879506 139.74051482580657 35.528 35.671432251842404 139.740536705585 35.528</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c84dc56-127a-4926-9420-badd9365870b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67139375292237 139.74041815600427 9.29 35.67139913688786 139.74041006380006 9.29 35.67141990248141 139.7404307848767 9.29 35.67139375292237 139.74041815600427 9.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-247b3602-93cd-4b7d-ba0b-6a79f8fbc207">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67141990248141 139.7404307848767 9.29 35.67146120814426 139.74047200639524 9.29 35.671460712960375 139.74047274707812 9.29 35.67141990248141 139.7404307848767 9.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25977390-4ca6-453d-8127-41d4509e3cdf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67139293361989 139.74041938310407 9.29 35.67139375292237 139.74041815600427 9.29 35.67141990248141 139.7404307848767 9.29 35.67139293361989 139.74041938310407 9.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b7c985f-1d2f-4f9f-985e-8feec5ff9a42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671455013893805 139.74048133673762 9.29 35.67139293361989 139.74041938310407 9.29 35.67141990248141 139.7404307848767 9.29 35.671455013893805 139.74048133673762 9.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c805be7-bd13-4efe-93dc-22656c7d89ab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671455013893805 139.74048133673762 9.29 35.67141990248141 139.7404307848767 9.29 35.671460712960375 139.74047274707812 9.29 35.671455013893805 139.74048133673762 9.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f715ab8b-ea94-4317-afac-4d235ebc29ee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67142590527867 139.74050045863433 34.475 35.67144419927493 139.7405188186716 34.475 35.67144311887153 139.7405204326976 34.475 35.67142590527867 139.74050045863433 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d973eae-1761-461c-a7f7-976f0f384322">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67142482487551 139.7405020726602 34.475 35.67142590527867 139.74050045863433 34.475 35.67144311887153 139.7405204326976 34.475 35.67142482487551 139.7405020726602 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0793999c-8510-4fcb-9e31-6680adb9e586">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67142482487551 139.7405020726602 33.902 35.67144311887153 139.7405204326976 33.902 35.671419746987176 139.74050966741837 33.902 35.67142482487551 139.7405020726602 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ada0511-e4a0-45a7-aefa-cbedd3b8eebd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67141044879506 139.74051482580657 33.902 35.6714102121006 139.74050010122758 33.902 35.671419746987176 139.74050966741837 33.902 35.67141044879506 139.74051482580657 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80ea89e8-b6e7-40fa-845e-204b20bb85d6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714102121006 139.74050010122758 33.902 35.67141044879506 139.74051482580657 33.902 35.67139473535348 139.74052326135433 33.902 35.6714102121006 139.74050010122758 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89353a7d-be37-466a-90ab-7dd34f913ea3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67144311887153 139.7405204326976 33.902 35.671432251842404 139.740536705585 33.902 35.671419746987176 139.74050966741837 33.902 35.67144311887153 139.7405204326976 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb1a94d9-1ae6-486d-b0b2-1b9816d0e7da">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67141044879506 139.74051482580657 33.902 35.6714007071792 139.74052940728618 33.902 35.67139473535348 139.74052326135433 33.902 35.67141044879506 139.74051482580657 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79c64cc4-393e-4c74-81fa-51ca5b395fd9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671419746987176 139.74050966741837 33.902 35.671432251842404 139.740536705585 33.902 35.67141044879506 139.74051482580657 33.902 35.671419746987176 139.74050966741837 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-bec9e314-4a70-4846-b041-7b0d039b96de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bec9e314-4a70-4846-b041-7b0d039b96de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bec9e314-4a70-4846-b041-7b0d039b96de">
											<gml:posList>35.671393228516955 139.74046280615684 8.71 35.67145348684751 139.74052327066832 8.71 35.67143773113889 139.74054703867827 8.71 35.671457035311576 139.74056623708702 8.71 35.67142327290899 139.7406169791429 8.71 35.67140478048962 139.74059844257508 8.71 35.67138515328841 139.74062795915958 8.71 35.67125227887464 139.74049533531812 8.71 35.671321604682014 139.74039175037638 8.71 35.67132196480454 139.74039119763944 8.71 35.67136923191017 139.74032000405694 8.71 35.671561372317875 139.74051176796462 8.71 35.67151941706927 139.74057500204015 8.71 35.67139863044474 139.74045462556364 8.71 35.671393228516955 139.74046280615684 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a176b72-7579-4814-8821-be4c10afdb82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a176b72-7579-4814-8821-be4c10afdb82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a176b72-7579-4814-8821-be4c10afdb82">
											<gml:posList>35.671321604682014 139.74039175037638 22.111 35.67134256674258 139.74048019663016 34.475 35.67132196480454 139.74039119763944 22.111 35.671321604682014 139.74039175037638 22.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d69ba44-bc42-424b-9fc9-d372d5edfd99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d69ba44-bc42-424b-9fc9-d372d5edfd99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d69ba44-bc42-424b-9fc9-d372d5edfd99">
											<gml:posList>35.67138515328841 139.74062795915958 22.111 35.67142398298337 139.74056755671353 34.475 35.67134256674258 139.74048019663016 34.475 35.67138515328841 139.74062795915958 22.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f53acfdb-6f83-459e-b906-1ac708c27c7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f53acfdb-6f83-459e-b906-1ac708c27c7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f53acfdb-6f83-459e-b906-1ac708c27c7f">
											<gml:posList>35.671412197415215 139.7403628805278 33.233 35.67136923191017 139.74032000405694 25.807 35.67132196480454 139.74039119763944 25.807 35.671412197415215 139.7403628805278 33.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ffd9fcc-8dcd-4228-ba8a-dd39b472681c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ffd9fcc-8dcd-4228-ba8a-dd39b472681c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ffd9fcc-8dcd-4228-ba8a-dd39b472681c">
											<gml:posList>35.6714126699837 139.74036787295336 33.233 35.6714338415174 139.74038900226896 33.233 35.671435651177774 139.74038628275548 33.233 35.671412197415215 139.7403628805278 33.233 35.6714126699837 139.74036787295336 33.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8eb83734-b66f-44ee-8d1f-c94cdc0f8b73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8eb83734-b66f-44ee-8d1f-c94cdc0f8b73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8eb83734-b66f-44ee-8d1f-c94cdc0f8b73">
											<gml:posList>35.67136814750978 139.74043319773023 33.233 35.671412197415215 139.7403628805278 33.233 35.67132196480454 139.74039119763944 25.807 35.67136814750978 139.74043319773023 33.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3db41419-a7ab-4795-9251-dbaf123944dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3db41419-a7ab-4795-9251-dbaf123944dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3db41419-a7ab-4795-9251-dbaf123944dd">
											<gml:posList>35.67137041159864 139.74043532706116 33.233 35.67137475988229 139.74042839593224 33.233 35.6714126699837 139.74036787295336 33.233 35.671412197415215 139.7403628805278 33.233 35.67136814750978 139.74043319773023 33.233 35.67137041159864 139.74043532706116 33.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b4e76a1-2395-4687-8603-7c12e6fbb8f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b4e76a1-2395-4687-8603-7c12e6fbb8f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b4e76a1-2395-4687-8603-7c12e6fbb8f8">
											<gml:posList>35.67137475988229 139.74042839593224 32.863 35.67139465046013 139.74044823430916 32.863 35.6714338415174 139.74038900226896 32.863 35.6714126699837 139.74036787295336 32.863 35.67137475988229 139.74042839593224 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9a21611-1cca-4d8c-9aea-d7bf3820cb12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9a21611-1cca-4d8c-9aea-d7bf3820cb12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9a21611-1cca-4d8c-9aea-d7bf3820cb12">
											<gml:posList>35.67136255805663 139.74043197805702 32.583 35.67136814750978 139.74043319773023 33.233 35.67132196480454 139.74039119763944 25.807 35.67136255805663 139.74043197805702 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2a1dad0-9dc8-4d8d-aac3-c34145a41f84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2a1dad0-9dc8-4d8d-aac3-c34145a41f84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2a1dad0-9dc8-4d8d-aac3-c34145a41f84">
											<gml:posList>35.67145800063809 139.74041537517678 39.345 35.67145833728261 139.74041943986478 39.345 35.671478624780704 139.7404396865174 39.345 35.67148194151474 139.74043927395724 39.345 35.67145800063809 139.74041537517678 39.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-acf1ac8a-80b1-45fc-901b-db91de108a84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acf1ac8a-80b1-45fc-901b-db91de108a84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acf1ac8a-80b1-45fc-901b-db91de108a84">
											<gml:posList>35.67143665387233 139.7404475007695 39.345 35.67143996159269 139.74044708822038 39.345 35.67145833728261 139.74041943986478 39.345 35.67145800063809 139.74041537517678 39.345 35.67143665387233 139.7404475007695 39.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4a62ebd-3f9c-4414-9951-c4ef7fe03032">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4a62ebd-3f9c-4414-9951-c4ef7fe03032">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4a62ebd-3f9c-4414-9951-c4ef7fe03032">
											<gml:posList>35.67136255805663 139.74043197805702 32.583 35.67136645500967 139.7404358950118 33.233 35.67136814750978 139.74043319773023 33.233 35.67136255805663 139.74043197805702 32.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1cf1144a-8021-44c2-b227-e9969692d768">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cf1144a-8021-44c2-b227-e9969692d768">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cf1144a-8021-44c2-b227-e9969692d768">
											<gml:posList>35.67134256674258 139.74048019663016 34.475 35.67136989190487 139.7404393485514 34.475 35.67136255805663 139.74043197805702 32.583 35.67132196480454 139.74039119763944 22.111 35.67134256674258 139.74048019663016 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f148dfc-af64-47f4-b405-8f75b8e057fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f148dfc-af64-47f4-b405-8f75b8e057fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f148dfc-af64-47f4-b405-8f75b8e057fa">
											<gml:posList>35.67139465046013 139.74044823430916 37.854 35.67137475988229 139.74042839593224 34.146 35.67137041159864 139.74043532706116 34.146 35.67139465046013 139.74044823430916 37.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e962ca4-19a0-49d6-b152-e40bbcf222b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e962ca4-19a0-49d6-b152-e40bbcf222b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e962ca4-19a0-49d6-b152-e40bbcf222b8">
											<gml:posList>35.671321604682014 139.74039175037638 22.111 35.67125227887464 139.74049533531812 22.111 35.67134256674258 139.74048019663016 34.475 35.671321604682014 139.74039175037638 22.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54627157-9783-4ecf-97d3-0a281aa59613">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54627157-9783-4ecf-97d3-0a281aa59613">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54627157-9783-4ecf-97d3-0a281aa59613">
											<gml:posList>35.671478624780704 139.7404396865174 39.254 35.67145833728261 139.74041943986478 39.254 35.67143996159269 139.74044708822038 39.254 35.671460249086216 139.74046733487535 39.254 35.671478624780704 139.7404396865174 39.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74f9b927-f3f5-45d1-812b-e1cff7e661f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74f9b927-f3f5-45d1-812b-e1cff7e661f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74f9b927-f3f5-45d1-812b-e1cff7e661f7">
											<gml:posList>35.67137041159864 139.74043532706116 34.146 35.67139008579493 139.74045509941098 37.854 35.67139465046013 139.74044823430916 37.854 35.67137041159864 139.74043532706116 34.146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-714631bc-1fcc-4f8e-b534-6430cad88cd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-714631bc-1fcc-4f8e-b534-6430cad88cd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-714631bc-1fcc-4f8e-b534-6430cad88cd9">
											<gml:posList>35.67136814750978 139.74043319773023 33.233 35.67136645500967 139.7404358950118 33.233 35.67136989190487 139.7404393485514 33.233 35.67138827614149 139.7404578299678 33.233 35.67139008579493 139.74045509941098 33.233 35.67137041159864 139.74043532706116 33.233 35.67136814750978 139.74043319773023 33.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e134df95-7bb5-4448-895b-659888f30ae1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e134df95-7bb5-4448-895b-659888f30ae1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e134df95-7bb5-4448-895b-659888f30ae1">
											<gml:posList>35.671460249086216 139.74046733487535 39.345 35.67146059474269 139.74047139955323 39.345 35.67148194151474 139.74043927395724 39.345 35.671478624780704 139.7404396865174 39.345 35.671460249086216 139.74046733487535 39.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f21bc65-0406-4e51-b24c-22672aaef72c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f21bc65-0406-4e51-b24c-22672aaef72c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f21bc65-0406-4e51-b24c-22672aaef72c">
											<gml:posList>35.67143996159269 139.74044708822038 39.345 35.67143665387233 139.7404475007695 39.345 35.67146059474269 139.74047139955323 39.345 35.671460249086216 139.74046733487535 39.345 35.67143996159269 139.74044708822038 39.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02de2452-919a-4990-9529-015622437490">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02de2452-919a-4990-9529-015622437490">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02de2452-919a-4990-9529-015622437490">
											<gml:posList>35.67136989190487 139.7404393485514 34.475 35.67134256674258 139.74048019663016 34.475 35.67134920033034 139.740479526164 34.475 35.671370556272116 139.74044759943936 34.475 35.67136989190487 139.7404393485514 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3491be8b-c7fe-4709-8d64-28f92cd905c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3491be8b-c7fe-4709-8d64-28f92cd905c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3491be8b-c7fe-4709-8d64-28f92cd905c9">
											<gml:posList>35.67145800063809 139.74041537517678 34.829 35.67148194151474 139.74043927395724 34.829 35.671561372317875 139.74051176796462 34.829 35.671435651177774 139.74038628275548 34.829 35.67139464144641 139.7404482343196 34.829 35.67139008579493 139.74045509941098 34.829 35.67138827614149 139.7404578299678 34.829 35.671393228516955 139.74046280615684 34.829 35.67139863044474 139.74045462556364 34.829 35.67151941706927 139.74057500204015 34.829 35.67146059474269 139.74047139955323 34.829 35.67143665387233 139.7404475007695 34.829 35.67145800063809 139.74041537517678 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5df42545-ec9f-4672-84b6-9ba79d20f353">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5df42545-ec9f-4672-84b6-9ba79d20f353">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5df42545-ec9f-4672-84b6-9ba79d20f353">
											<gml:posList>35.67139757422914 139.74047591319928 39.356 35.67141277412956 139.74049117276846 39.356 35.67141648742494 139.74049070451957 39.356 35.67139720114831 139.7404713514684 39.356 35.67139757422914 139.74047591319928 39.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cdc9cb76-db19-4919-8619-bbb4aeb01196">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdc9cb76-db19-4919-8619-bbb4aeb01196">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdc9cb76-db19-4919-8619-bbb4aeb01196">
											<gml:posList>35.671370556272116 139.74044759943936 34.475 35.67139600370346 139.740473142372 34.475 35.67139720114831 139.7404713514684 34.475 35.67141648742494 139.74049070451957 34.475 35.67141528997981 139.74049249542335 34.475 35.67144675421939 139.7405240848497 34.475 35.67145348684751 139.74052327066832 34.475 35.671393228516955 139.74046280615684 34.475 35.67138827614149 139.7404578299678 34.475 35.67136989190487 139.7404393485514 34.475 35.671370556272116 139.74044759943936 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94474a0a-9f23-41c7-b873-eeb1b20addca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94474a0a-9f23-41c7-b873-eeb1b20addca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94474a0a-9f23-41c7-b873-eeb1b20addca">
											<gml:posList>35.671379234436145 139.74050337369064 39.356 35.67139757422914 139.74047591319928 39.356 35.67139720114831 139.7404713514684 39.356 35.67137551210992 139.7405038198564 39.356 35.671379234436145 139.74050337369064 39.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7ce713e8-2753-4471-b9da-83f0ae18235c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ce713e8-2753-4471-b9da-83f0ae18235c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ce713e8-2753-4471-b9da-83f0ae18235c">
											<gml:posList>35.67139757422914 139.74047591319928 39.142 35.671379234436145 139.74050337369064 39.142 35.671394380301884 139.7405186996025 39.142 35.67141277412956 139.74049117276846 39.142 35.67139757422914 139.74047591319928 39.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e7ffda4-def2-4758-a55f-583d1b41a143">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e7ffda4-def2-4758-a55f-583d1b41a143">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e7ffda4-def2-4758-a55f-583d1b41a143">
											<gml:posList>35.67137551210992 139.7405038198564 33.902 35.67139600370346 139.740473142372 33.902 35.671370556272116 139.74044759943936 33.902 35.67134920033034 139.740479526164 33.902 35.67142339962015 139.7405591400293 33.902 35.67144675421939 139.7405240848497 33.902 35.67141528997981 139.74049249542335 33.902 35.67139473535348 139.74052326135433 33.902 35.67137551210992 139.7405038198564 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3cd27b90-059e-4515-b08e-672ad5b20aff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cd27b90-059e-4515-b08e-672ad5b20aff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cd27b90-059e-4515-b08e-672ad5b20aff">
											<gml:posList>35.67141648742494 139.74049070451957 39.356 35.67141277412956 139.74049117276846 39.356 35.671394380301884 139.7405186996025 39.356 35.67139473535348 139.74052326135433 39.356 35.67141648742494 139.74049070451957 39.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0d27d23-a429-49bd-bdd3-bef1245b6c83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0d27d23-a429-49bd-bdd3-bef1245b6c83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0d27d23-a429-49bd-bdd3-bef1245b6c83">
											<gml:posList>35.671561372317875 139.74051176796462 34.829 35.67148194151474 139.74043927395724 34.829 35.67146059474269 139.74047139955323 34.829 35.67151941706927 139.74057500204015 34.829 35.671561372317875 139.74051176796462 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5077cece-29b6-49f3-b022-e959cb7e3cc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5077cece-29b6-49f3-b022-e959cb7e3cc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5077cece-29b6-49f3-b022-e959cb7e3cc2">
											<gml:posList>35.67137551210992 139.7405038198564 39.356 35.67139473535348 139.74052326135433 39.356 35.671394380301884 139.7405186996025 39.356 35.671379234436145 139.74050337369064 39.356 35.67137551210992 139.7405038198564 39.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8288e599-9d5a-458b-84fd-05dcfe11a54c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8288e599-9d5a-458b-84fd-05dcfe11a54c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8288e599-9d5a-458b-84fd-05dcfe11a54c">
											<gml:posList>35.67134256674258 139.74048019663016 34.475 35.67142398298337 139.74056755671353 34.475 35.67142339962015 139.7405591400293 34.475 35.67134920033034 139.740479526164 34.475 35.67134256674258 139.74048019663016 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eff0c902-15c7-4de9-ba80-f573d7b9e6a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eff0c902-15c7-4de9-ba80-f573d7b9e6a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eff0c902-15c7-4de9-ba80-f573d7b9e6a6">
											<gml:posList>35.67142339962015 139.7405591400293 34.475 35.67142398298337 139.74056755671353 34.475 35.67145348684751 139.74052327066832 34.475 35.67144675421939 139.7405240848497 34.475 35.67142339962015 139.7405591400293 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5f8bde0-7a1d-41cf-b167-26122ea7713e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5f8bde0-7a1d-41cf-b167-26122ea7713e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5f8bde0-7a1d-41cf-b167-26122ea7713e">
											<gml:posList>35.67134256674258 139.74048019663016 34.475 35.67125227887464 139.74049533531812 22.111 35.67138515328841 139.74062795915958 22.111 35.67134256674258 139.74048019663016 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b7d083c-edb2-4def-b2b8-639727013a50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b7d083c-edb2-4def-b2b8-639727013a50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b7d083c-edb2-4def-b2b8-639727013a50">
											<gml:posList>35.67142327290899 139.7406169791429 20.704 35.671457035311576 139.74056623708702 20.704 35.67143773113889 139.74054703867827 20.704 35.67142398298337 139.74056755671353 20.704 35.67140478048962 139.74059844257508 20.704 35.67142327290899 139.7406169791429 20.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd9d4953-aae6-4da5-8dd7-dec8e6a3a5e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd9d4953-aae6-4da5-8dd7-dec8e6a3a5e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd9d4953-aae6-4da5-8dd7-dec8e6a3a5e0">
											<gml:posList>35.67145833728261 139.74041943986478 39.345 35.67143996159269 139.74044708822038 39.345 35.67143996159269 139.74044708822038 39.254 35.67145833728261 139.74041943986478 39.254 35.67145833728261 139.74041943986478 39.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c7b3f0f-2c19-44ab-9fd9-9f7b437e30db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c7b3f0f-2c19-44ab-9fd9-9f7b437e30db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c7b3f0f-2c19-44ab-9fd9-9f7b437e30db">
											<gml:posList>35.67138827614149 139.7404578299678 33.233 35.67136989190487 139.7404393485514 33.233 35.67136989190487 139.7404393485514 34.475 35.67138827614149 139.7404578299678 34.475 35.67138827614149 139.7404578299678 33.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7472b5bb-3ccf-4c1d-970b-da811a9fbe80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7472b5bb-3ccf-4c1d-970b-da811a9fbe80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7472b5bb-3ccf-4c1d-970b-da811a9fbe80">
											<gml:posList>35.671478624780704 139.7404396865174 39.254 35.671460249086216 139.74046733487535 39.254 35.671460249086216 139.74046733487535 39.345 35.671478624780704 139.7404396865174 39.345 35.671478624780704 139.7404396865174 39.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94129202-53a2-4e87-8d43-d03034a040a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94129202-53a2-4e87-8d43-d03034a040a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94129202-53a2-4e87-8d43-d03034a040a4">
											<gml:posList>35.671379234436145 139.74050337369064 39.142 35.67139757422914 139.74047591319928 39.142 35.67139757422914 139.74047591319928 39.356 35.671379234436145 139.74050337369064 39.356 35.671379234436145 139.74050337369064 39.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95c2d380-6081-4ef5-9a6d-9144e8892063">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95c2d380-6081-4ef5-9a6d-9144e8892063">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95c2d380-6081-4ef5-9a6d-9144e8892063">
											<gml:posList>35.671393228516955 139.74046280615684 8.71 35.671393228516955 139.74046280615684 34.475 35.67145348684751 139.74052327066832 34.475 35.67145348684751 139.74052327066832 8.71 35.671393228516955 139.74046280615684 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d47cea92-b5ed-461b-85b9-b064ffb008a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d47cea92-b5ed-461b-85b9-b064ffb008a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d47cea92-b5ed-461b-85b9-b064ffb008a7">
											<gml:posList>35.67141277412956 139.74049117276846 39.142 35.671394380301884 139.7405186996025 39.142 35.671394380301884 139.7405186996025 39.356 35.67141277412956 139.74049117276846 39.356 35.67141277412956 139.74049117276846 39.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66e85f38-0f25-4d85-afc4-dea5e0958601">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66e85f38-0f25-4d85-afc4-dea5e0958601">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66e85f38-0f25-4d85-afc4-dea5e0958601">
											<gml:posList>35.671321604682014 139.74039175037638 22.111 35.671321604682014 139.74039175037638 8.71 35.67125227887464 139.74049533531812 8.71 35.67125227887464 139.74049533531812 22.111 35.671321604682014 139.74039175037638 22.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a303a586-cefd-467e-bc46-e957333ccbbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a303a586-cefd-467e-bc46-e957333ccbbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a303a586-cefd-467e-bc46-e957333ccbbf">
											<gml:posList>35.67125227887464 139.74049533531812 22.111 35.67125227887464 139.74049533531812 8.71 35.67138515328841 139.74062795915958 8.71 35.67138515328841 139.74062795915958 22.111 35.67125227887464 139.74049533531812 22.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba6e940d-fc37-43b4-bf6c-8c358e9171ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba6e940d-fc37-43b4-bf6c-8c358e9171ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba6e940d-fc37-43b4-bf6c-8c358e9171ec">
											<gml:posList>35.67132196480454 139.74039119763944 22.111 35.67132196480454 139.74039119763944 8.71 35.671321604682014 139.74039175037638 8.71 35.671321604682014 139.74039175037638 22.111 35.67132196480454 139.74039119763944 22.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33a6ad59-5010-4281-8cc2-fd971f36e2ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33a6ad59-5010-4281-8cc2-fd971f36e2ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33a6ad59-5010-4281-8cc2-fd971f36e2ea">
											<gml:posList>35.67132196480454 139.74039119763944 22.111 35.67136255805663 139.74043197805702 32.583 35.67132196480454 139.74039119763944 25.807 35.67132196480454 139.74039119763944 22.111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da199ac0-6be8-40a3-bb9e-5f9b2438ee5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da199ac0-6be8-40a3-bb9e-5f9b2438ee5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da199ac0-6be8-40a3-bb9e-5f9b2438ee5e">
											<gml:posList>35.67136923191017 139.74032000405694 25.807 35.67136923191017 139.74032000405694 8.71 35.67132196480454 139.74039119763944 8.71 35.67132196480454 139.74039119763944 22.111 35.67132196480454 139.74039119763944 25.807 35.67136923191017 139.74032000405694 25.807</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71fa705d-3574-4481-9393-a0523272fcfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71fa705d-3574-4481-9393-a0523272fcfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71fa705d-3574-4481-9393-a0523272fcfa">
											<gml:posList>35.671370556272116 139.74044759943936 34.475 35.67134920033034 139.740479526164 34.475 35.67134920033034 139.740479526164 33.902 35.671370556272116 139.74044759943936 33.902 35.671370556272116 139.74044759943936 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a601cc8b-a18c-4ea8-83c8-0cb76e917e98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a601cc8b-a18c-4ea8-83c8-0cb76e917e98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a601cc8b-a18c-4ea8-83c8-0cb76e917e98">
											<gml:posList>35.67136645500967 139.7404358950118 33.233 35.67136255805663 139.74043197805702 32.583 35.67136989190487 139.7404393485514 34.475 35.67136989190487 139.7404393485514 33.233 35.67136645500967 139.7404358950118 33.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17720cc8-1e1f-4620-8281-2e0533e456a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17720cc8-1e1f-4620-8281-2e0533e456a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17720cc8-1e1f-4620-8281-2e0533e456a3">
											<gml:posList>35.67137475988229 139.74042839593224 33.233 35.67137041159864 139.74043532706116 33.233 35.67137041159864 139.74043532706116 34.146 35.67137475988229 139.74042839593224 34.146 35.67137475988229 139.74042839593224 33.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cc0d7e9-314b-4e63-8a7e-25fcac31e192">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cc0d7e9-314b-4e63-8a7e-25fcac31e192">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cc0d7e9-314b-4e63-8a7e-25fcac31e192">
											<gml:posList>35.67137041159864 139.74043532706116 34.146 35.67137041159864 139.74043532706116 33.233 35.67139008579493 139.74045509941098 33.233 35.67139008579493 139.74045509941098 34.829 35.67139008579493 139.74045509941098 37.854 35.67137041159864 139.74043532706116 34.146</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a758156a-b131-4aea-becd-19334c7a4d78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a758156a-b131-4aea-becd-19334c7a4d78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a758156a-b131-4aea-becd-19334c7a4d78">
											<gml:posList>35.671370556272116 139.74044759943936 34.475 35.671370556272116 139.74044759943936 33.902 35.67139600370346 139.740473142372 33.902 35.67139600370346 139.740473142372 34.475 35.671370556272116 139.74044759943936 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-219286a4-7387-41fa-9f54-aa8b6aaf318f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-219286a4-7387-41fa-9f54-aa8b6aaf318f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-219286a4-7387-41fa-9f54-aa8b6aaf318f">
											<gml:posList>35.67137475988229 139.74042839593224 33.233 35.67137475988229 139.74042839593224 34.146 35.67139465046013 139.74044823430916 37.854 35.67139464144641 139.7404482343196 34.829 35.67139465046013 139.74044823430916 32.863 35.67137475988229 139.74042839593224 32.863 35.67137475988229 139.74042839593224 33.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72b3a748-04a8-4007-aab8-5e0287c2e3d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72b3a748-04a8-4007-aab8-5e0287c2e3d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72b3a748-04a8-4007-aab8-5e0287c2e3d6">
											<gml:posList>35.67139473535348 139.74052326135433 39.356 35.67137551210992 139.7405038198564 39.356 35.67137551210992 139.7405038198564 33.902 35.67139473535348 139.74052326135433 33.902 35.67139473535348 139.74052326135433 39.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77e4b35a-c56c-47eb-a1ce-1d1ffb42d105">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77e4b35a-c56c-47eb-a1ce-1d1ffb42d105">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77e4b35a-c56c-47eb-a1ce-1d1ffb42d105">
											<gml:posList>35.67134920033034 139.740479526164 34.475 35.67142339962015 139.7405591400293 34.475 35.67142339962015 139.7405591400293 33.902 35.67134920033034 139.740479526164 33.902 35.67134920033034 139.740479526164 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7af208a-7952-4954-8c20-623e5b13f8c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7af208a-7952-4954-8c20-623e5b13f8c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7af208a-7952-4954-8c20-623e5b13f8c2">
											<gml:posList>35.67137551210992 139.7405038198564 33.902 35.67137551210992 139.7405038198564 39.356 35.67139720114831 139.7404713514684 39.356 35.67139720114831 139.7404713514684 34.475 35.67139600370346 139.740473142372 34.475 35.67139600370346 139.740473142372 33.902 35.67137551210992 139.7405038198564 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa600420-5fbf-44eb-8fc2-b1ed83184c3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa600420-5fbf-44eb-8fc2-b1ed83184c3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa600420-5fbf-44eb-8fc2-b1ed83184c3c">
											<gml:posList>35.671394380301884 139.7405186996025 39.142 35.671379234436145 139.74050337369064 39.142 35.671379234436145 139.74050337369064 39.356 35.671394380301884 139.7405186996025 39.356 35.671394380301884 139.7405186996025 39.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-526fcd71-2b56-4b9f-816e-b1de9e954b5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-526fcd71-2b56-4b9f-816e-b1de9e954b5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-526fcd71-2b56-4b9f-816e-b1de9e954b5d">
											<gml:posList>35.67139008579493 139.74045509941098 33.233 35.67138827614149 139.7404578299678 33.233 35.67138827614149 139.7404578299678 34.475 35.67138827614149 139.7404578299678 34.829 35.67139008579493 139.74045509941098 34.829 35.67139008579493 139.74045509941098 33.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51a2be93-a75b-4454-bb99-291e754069c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51a2be93-a75b-4454-bb99-291e754069c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51a2be93-a75b-4454-bb99-291e754069c2">
											<gml:posList>35.67138827614149 139.7404578299678 34.829 35.67138827614149 139.7404578299678 34.475 35.671393228516955 139.74046280615684 34.475 35.671393228516955 139.74046280615684 34.829 35.67138827614149 139.7404578299678 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ceaf18eb-de7e-46d4-8f69-5ce354ea75fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceaf18eb-de7e-46d4-8f69-5ce354ea75fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceaf18eb-de7e-46d4-8f69-5ce354ea75fa">
											<gml:posList>35.67139464144641 139.7404482343196 34.829 35.67139465046013 139.74044823430916 37.854 35.67139008579493 139.74045509941098 37.854 35.67139008579493 139.74045509941098 34.829 35.67139464144641 139.7404482343196 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d875037c-32c3-4855-bb8f-638d066eaa3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d875037c-32c3-4855-bb8f-638d066eaa3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d875037c-32c3-4855-bb8f-638d066eaa3f">
											<gml:posList>35.67137475988229 139.74042839593224 33.233 35.67137475988229 139.74042839593224 32.863 35.6714126699837 139.74036787295336 32.863 35.6714126699837 139.74036787295336 33.233 35.67137475988229 139.74042839593224 33.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-119a1113-1232-480b-8ce9-b72f5629c358">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-119a1113-1232-480b-8ce9-b72f5629c358">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-119a1113-1232-480b-8ce9-b72f5629c358">
											<gml:posList>35.67138515328841 139.74062795915958 8.71 35.67140478048962 139.74059844257508 8.71 35.67140478048962 139.74059844257508 20.704 35.67138515328841 139.74062795915958 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4d9be9a-844c-4469-93b8-dd05d42fd11a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4d9be9a-844c-4469-93b8-dd05d42fd11a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4d9be9a-844c-4469-93b8-dd05d42fd11a">
											<gml:posList>35.671393228516955 139.74046280615684 34.475 35.671393228516955 139.74046280615684 8.71 35.67139863044474 139.74045462556364 8.71 35.67139863044474 139.74045462556364 34.829 35.671393228516955 139.74046280615684 34.829 35.671393228516955 139.74046280615684 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d991cbe-e776-4cea-8bea-67e75ef58e3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d991cbe-e776-4cea-8bea-67e75ef58e3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d991cbe-e776-4cea-8bea-67e75ef58e3c">
											<gml:posList>35.67142398298337 139.74056755671353 34.475 35.67138515328841 139.74062795915958 8.71 35.67140478048962 139.74059844257508 20.704 35.67142398298337 139.74056755671353 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9dd4e71e-bf9e-4056-87f2-7dcf7a829561">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dd4e71e-bf9e-4056-87f2-7dcf7a829561">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dd4e71e-bf9e-4056-87f2-7dcf7a829561">
											<gml:posList>35.67142398298337 139.74056755671353 34.475 35.67138515328841 139.74062795915958 22.111 35.67138515328841 139.74062795915958 8.71 35.67142398298337 139.74056755671353 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cca060f5-88c5-43b5-ac35-88fb91f9c982">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cca060f5-88c5-43b5-ac35-88fb91f9c982">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cca060f5-88c5-43b5-ac35-88fb91f9c982">
											<gml:posList>35.67139757422914 139.74047591319928 39.142 35.67141277412956 139.74049117276846 39.142 35.67141277412956 139.74049117276846 39.356 35.67139757422914 139.74047591319928 39.356 35.67139757422914 139.74047591319928 39.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61d0a2eb-6ccc-4b52-bc5e-c71ffaaae923">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61d0a2eb-6ccc-4b52-bc5e-c71ffaaae923">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61d0a2eb-6ccc-4b52-bc5e-c71ffaaae923">
											<gml:posList>35.67141528997981 139.74049249542335 34.475 35.67141648742494 139.74049070451957 34.475 35.67141648742494 139.74049070451957 39.356 35.67139473535348 139.74052326135433 39.356 35.67139473535348 139.74052326135433 33.902 35.67141528997981 139.74049249542335 33.902 35.67141528997981 139.74049249542335 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8213fac0-89dd-4d6c-979e-da8a52731ec1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8213fac0-89dd-4d6c-979e-da8a52731ec1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8213fac0-89dd-4d6c-979e-da8a52731ec1">
											<gml:posList>35.67139720114831 139.7404713514684 39.356 35.67141648742494 139.74049070451957 39.356 35.67141648742494 139.74049070451957 34.475 35.67139720114831 139.7404713514684 34.475 35.67139720114831 139.7404713514684 39.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2066af57-552f-4499-b646-7668a4213f1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2066af57-552f-4499-b646-7668a4213f1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2066af57-552f-4499-b646-7668a4213f1e">
											<gml:posList>35.67140478048962 139.74059844257508 20.704 35.67140478048962 139.74059844257508 8.71 35.67142327290899 139.7406169791429 8.71 35.67142327290899 139.7406169791429 20.704 35.67140478048962 139.74059844257508 20.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e2c7637-b90e-4090-b6fa-a1544d68f43a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e2c7637-b90e-4090-b6fa-a1544d68f43a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e2c7637-b90e-4090-b6fa-a1544d68f43a">
											<gml:posList>35.67139465046013 139.74044823430916 32.863 35.67139464144641 139.7404482343196 34.829 35.6714338415174 139.74038900226896 32.863 35.67139465046013 139.74044823430916 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b758037-cea5-4d0a-bbc7-3ecf8ee6d2f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b758037-cea5-4d0a-bbc7-3ecf8ee6d2f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b758037-cea5-4d0a-bbc7-3ecf8ee6d2f8">
											<gml:posList>35.67139464144641 139.7404482343196 34.829 35.6714338415174 139.74038900226896 33.233 35.6714338415174 139.74038900226896 32.863 35.67139464144641 139.7404482343196 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-992aa5a9-c43b-44f6-9162-68ee435f8449">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-992aa5a9-c43b-44f6-9162-68ee435f8449">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-992aa5a9-c43b-44f6-9162-68ee435f8449">
											<gml:posList>35.67142398298337 139.74056755671353 34.475 35.67140478048962 139.74059844257508 20.704 35.67142398298337 139.74056755671353 20.704 35.67142398298337 139.74056755671353 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d125ad30-b06c-42d6-a228-e75e3d346510">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d125ad30-b06c-42d6-a228-e75e3d346510">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d125ad30-b06c-42d6-a228-e75e3d346510">
											<gml:posList>35.67139464144641 139.7404482343196 34.829 35.671435651177774 139.74038628275548 34.829 35.6714338415174 139.74038900226896 33.233 35.67139464144641 139.7404482343196 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1110d90-d1c4-440f-8c5f-cf5e37a3fd85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1110d90-d1c4-440f-8c5f-cf5e37a3fd85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1110d90-d1c4-440f-8c5f-cf5e37a3fd85">
											<gml:posList>35.6714126699837 139.74036787295336 32.863 35.6714338415174 139.74038900226896 32.863 35.6714338415174 139.74038900226896 33.233 35.6714126699837 139.74036787295336 33.233 35.6714126699837 139.74036787295336 32.863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfc7e442-0b0d-469d-acfb-733327784b20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfc7e442-0b0d-469d-acfb-733327784b20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfc7e442-0b0d-469d-acfb-733327784b20">
											<gml:posList>35.67142398298337 139.74056755671353 34.475 35.67142398298337 139.74056755671353 20.704 35.67143773113889 139.74054703867827 20.704 35.67142398298337 139.74056755671353 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6d98767-270f-4131-b325-e93330f55325">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6d98767-270f-4131-b325-e93330f55325">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6d98767-270f-4131-b325-e93330f55325">
											<gml:posList>35.67144675421939 139.7405240848497 33.902 35.67144675421939 139.7405240848497 34.475 35.67141528997981 139.74049249542335 34.475 35.67141528997981 139.74049249542335 33.902 35.67144675421939 139.7405240848497 33.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f3047dd-ca3d-4456-84f0-454962562765">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f3047dd-ca3d-4456-84f0-454962562765">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f3047dd-ca3d-4456-84f0-454962562765">
											<gml:posList>35.671435651177774 139.74038628275548 34.829 35.671435651177774 139.74038628275548 33.233 35.6714338415174 139.74038900226896 33.233 35.671435651177774 139.74038628275548 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0986c17e-da19-448a-bcac-7b9763d0b44a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0986c17e-da19-448a-bcac-7b9763d0b44a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0986c17e-da19-448a-bcac-7b9763d0b44a">
											<gml:posList>35.67142339962015 139.7405591400293 34.475 35.67144675421939 139.7405240848497 34.475 35.67144675421939 139.7405240848497 33.902 35.67142339962015 139.7405591400293 33.902 35.67142339962015 139.7405591400293 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd234a4e-f1f0-4fed-8127-ecd6a843e9c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd234a4e-f1f0-4fed-8127-ecd6a843e9c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd234a4e-f1f0-4fed-8127-ecd6a843e9c8">
											<gml:posList>35.67142398298337 139.74056755671353 34.475 35.67143773113889 139.74054703867827 20.704 35.67145348684751 139.74052327066832 8.71 35.67142398298337 139.74056755671353 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1332d06a-860c-427e-9d45-fd760b63df95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1332d06a-860c-427e-9d45-fd760b63df95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1332d06a-860c-427e-9d45-fd760b63df95">
											<gml:posList>35.67142398298337 139.74056755671353 34.475 35.67145348684751 139.74052327066832 8.71 35.67145348684751 139.74052327066832 34.475 35.67142398298337 139.74056755671353 34.475</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-930f53a3-6cf9-4413-822b-5f0b9b0c9ca7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-930f53a3-6cf9-4413-822b-5f0b9b0c9ca7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-930f53a3-6cf9-4413-822b-5f0b9b0c9ca7">
											<gml:posList>35.67142327290899 139.7406169791429 20.704 35.67142327290899 139.7406169791429 8.71 35.671457035311576 139.74056623708702 8.71 35.671457035311576 139.74056623708702 20.704 35.67142327290899 139.7406169791429 20.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8358294-03dd-4f13-a8b3-39a8544002fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8358294-03dd-4f13-a8b3-39a8544002fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8358294-03dd-4f13-a8b3-39a8544002fb">
											<gml:posList>35.67143773113889 139.74054703867827 20.704 35.67143773113889 139.74054703867827 8.71 35.67145348684751 139.74052327066832 8.71 35.67143773113889 139.74054703867827 20.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89dff13e-df90-4ad6-b0c2-f98cd5cbf044">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89dff13e-df90-4ad6-b0c2-f98cd5cbf044">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89dff13e-df90-4ad6-b0c2-f98cd5cbf044">
											<gml:posList>35.671457035311576 139.74056623708702 20.704 35.671457035311576 139.74056623708702 8.71 35.67143773113889 139.74054703867827 8.71 35.67143773113889 139.74054703867827 20.704 35.671457035311576 139.74056623708702 20.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0060cf73-4ec0-4ea1-8932-5663cb77d9e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0060cf73-4ec0-4ea1-8932-5663cb77d9e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0060cf73-4ec0-4ea1-8932-5663cb77d9e2">
											<gml:posList>35.67143665387233 139.7404475007695 34.829 35.67143665387233 139.7404475007695 39.345 35.67145800063809 139.74041537517678 39.345 35.67145800063809 139.74041537517678 34.829 35.67143665387233 139.7404475007695 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-935e894e-36c7-4b3f-98b3-a8aa275b3582">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-935e894e-36c7-4b3f-98b3-a8aa275b3582">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-935e894e-36c7-4b3f-98b3-a8aa275b3582">
											<gml:posList>35.67146059474269 139.74047139955323 39.345 35.67143665387233 139.7404475007695 39.345 35.67143665387233 139.7404475007695 34.829 35.67146059474269 139.74047139955323 34.829 35.67146059474269 139.74047139955323 39.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c30ad74-daa9-46ed-b0e1-78d69d9edc07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c30ad74-daa9-46ed-b0e1-78d69d9edc07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c30ad74-daa9-46ed-b0e1-78d69d9edc07">
											<gml:posList>35.67143996159269 139.74044708822038 39.345 35.671460249086216 139.74046733487535 39.345 35.671460249086216 139.74046733487535 39.254 35.67143996159269 139.74044708822038 39.254 35.67143996159269 139.74044708822038 39.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a34dc877-c4e8-40ea-b4cb-60c5d8b1ed31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a34dc877-c4e8-40ea-b4cb-60c5d8b1ed31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a34dc877-c4e8-40ea-b4cb-60c5d8b1ed31">
											<gml:posList>35.67139863044474 139.74045462556364 34.829 35.67139863044474 139.74045462556364 8.71 35.67151941706927 139.74057500204015 8.71 35.67151941706927 139.74057500204015 34.829 35.67139863044474 139.74045462556364 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0a01a74-7e46-4ff1-b017-e205ea62bae8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0a01a74-7e46-4ff1-b017-e205ea62bae8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0a01a74-7e46-4ff1-b017-e205ea62bae8">
											<gml:posList>35.67136923191017 139.74032000405694 8.71 35.67136923191017 139.74032000405694 25.807 35.671412197415215 139.7403628805278 33.233 35.671435651177774 139.74038628275548 33.233 35.671435651177774 139.74038628275548 34.829 35.671561372317875 139.74051176796462 34.829 35.671561372317875 139.74051176796462 8.71 35.67136923191017 139.74032000405694 8.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23d7a644-9d7c-4f26-bd79-fcc413e8c8a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23d7a644-9d7c-4f26-bd79-fcc413e8c8a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23d7a644-9d7c-4f26-bd79-fcc413e8c8a0">
											<gml:posList>35.67145833728261 139.74041943986478 39.254 35.671478624780704 139.7404396865174 39.254 35.671478624780704 139.7404396865174 39.345 35.67145833728261 139.74041943986478 39.345 35.67145833728261 139.74041943986478 39.254</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72b92299-cfbd-4d40-8380-cb19a2a0574b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72b92299-cfbd-4d40-8380-cb19a2a0574b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72b92299-cfbd-4d40-8380-cb19a2a0574b">
											<gml:posList>35.67145800063809 139.74041537517678 34.829 35.67145800063809 139.74041537517678 39.345 35.67148194151474 139.74043927395724 39.345 35.67148194151474 139.74043927395724 34.829 35.67145800063809 139.74041537517678 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0edffb06-1fdb-458a-a0d0-3cccb2756dd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0edffb06-1fdb-458a-a0d0-3cccb2756dd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0edffb06-1fdb-458a-a0d0-3cccb2756dd0">
											<gml:posList>35.67148194151474 139.74043927395724 34.829 35.67148194151474 139.74043927395724 39.345 35.67146059474269 139.74047139955323 39.345 35.67146059474269 139.74047139955323 34.829 35.67148194151474 139.74043927395724 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-039830ea-c152-4745-ba28-58d484f20807">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-039830ea-c152-4745-ba28-58d484f20807">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-039830ea-c152-4745-ba28-58d484f20807">
											<gml:posList>35.67151941706927 139.74057500204015 34.829 35.67151941706927 139.74057500204015 8.71 35.671561372317875 139.74051176796462 8.71 35.671561372317875 139.74051176796462 34.829 35.67151941706927 139.74057500204015 34.829</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-143</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">246.3923</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>