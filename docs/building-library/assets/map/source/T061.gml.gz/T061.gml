<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0e950ab3-5ae1-460c-8a34-a49099fb8eac">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>マンション付属施設</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">7.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66960768528209 139.73916893969346 0 35.66959790993676 139.73911714472308 0 35.66957150551728 139.73912457666893 0 35.66958128085945 139.7391763716232 0 35.66960768528209 139.73916893969346 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66960768528209 139.73916893969346 16.95 35.66958128085945 139.7391763716232 16.95 35.66957150551728 139.73912457666893 16.95 35.66959790993676 139.73911714472308 16.95 35.66960768528209 139.73916893969346 16.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66960768528209 139.73916893969346 16.95 35.66959790993676 139.73911714472308 16.95 35.66959790993676 139.73911714472308 24.68 35.66960768528209 139.73916893969346 24.68 35.66960768528209 139.73916893969346 16.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66959790993676 139.73911714472308 16.95 35.66957150551728 139.73912457666893 16.95 35.66957150551728 139.73912457666893 24.68 35.66959790993676 139.73911714472308 24.68 35.66959790993676 139.73911714472308 16.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66957150551728 139.73912457666893 16.95 35.66958128085945 139.7391763716232 16.95 35.66958128085945 139.7391763716232 24.68 35.66957150551728 139.73912457666893 24.68 35.66957150551728 139.73912457666893 16.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66958128085945 139.7391763716232 16.95 35.66960768528209 139.73916893969346 16.95 35.66960768528209 139.73916893969346 24.68 35.66958128085945 139.7391763716232 24.68 35.66958128085945 139.7391763716232 16.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66960768528209 139.73916893969346 24.68 35.66959790993676 139.73911714472308 24.68 35.66957150551728 139.73912457666893 24.68 35.66958128085945 139.7391763716232 24.68 35.66960768528209 139.73916893969346 24.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-68ff3a54-57b3-42a5-9fde-911d91afaf01"/>
							<gml:surfaceMember xlink:href="#poly-6b15c52a-c82c-4bab-a18f-eade0f028389"/>
							<gml:surfaceMember xlink:href="#poly-f4018ffe-9663-4760-acf6-2bf31f9ff26b"/>
							<gml:surfaceMember xlink:href="#poly-d22b2397-1b03-46a4-bf16-2cd0fba79d39"/>
							<gml:surfaceMember xlink:href="#poly-92514dc2-4b0a-4d03-bc59-197488ff9508"/>
							<gml:surfaceMember xlink:href="#poly-6ce41db4-969b-4de6-a53c-91bb40249055"/>
							<gml:surfaceMember xlink:href="#poly-c6aeafb5-e52b-4277-b644-eb8aab21e28e"/>
							<gml:surfaceMember xlink:href="#poly-d3b83488-f830-4dd7-959b-951612f8e9ad"/>
							<gml:surfaceMember xlink:href="#poly-173ee5d9-9060-4cc2-bff9-602851adf06e"/>
							<gml:surfaceMember xlink:href="#poly-95de9fa0-ec87-454d-8a9d-4db1367b2d40"/>
							<gml:surfaceMember xlink:href="#poly-93655bf5-f9ff-4a3e-bc70-2d187b9261bf"/>
							<gml:surfaceMember xlink:href="#poly-2ae1b092-4509-4b98-8c8d-09defc2585e6"/>
							<gml:surfaceMember xlink:href="#poly-18aa3ebd-5792-4169-8446-d59cde64eeaa"/>
							<gml:surfaceMember xlink:href="#poly-e3f87a15-3802-4a8f-a58b-8f601e42a652"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0e950ab3-5ae1-460c-8a34-a49099fb8eac_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-953b93f9-0e95-4bed-bb6d-e2d9570a8695">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66958182394033 139.7391331584493 26.108 35.66958944752833 139.73913056469348 26.108 35.66959525434152 139.73915612971103 26.108 35.66958763076162 139.73915873451077 26.108 35.66958182394033 139.7391331584493 26.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d03a9c34-d928-4820-94c2-4847761fb7e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d03a9c34-d928-4820-94c2-4847761fb7e3_0">
											<gml:posList>35.66958182394033 139.7391331584493 26.108 35.66958182394033 139.7391331584493 26.351 35.66958944752833 139.73913056469348 26.351 35.66958944752833 139.73913056469348 26.108 35.66958182394033 139.7391331584493 26.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abf36abf-cdc3-4b64-9046-e00b07b377b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abf36abf-cdc3-4b64-9046-e00b07b377b2_0">
											<gml:posList>35.66958944752833 139.73913056469348 26.108 35.66958944752833 139.73913056469348 26.351 35.66959525434152 139.73915612971103 26.351 35.66959525434152 139.73915612971103 26.108 35.66958944752833 139.73913056469348 26.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28061988-c22e-446f-8172-e55623bf2487">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28061988-c22e-446f-8172-e55623bf2487_0">
											<gml:posList>35.66958182394033 139.7391331584493 26.351 35.66958763076162 139.73915873451077 26.351 35.66959525434152 139.73915612971103 26.351 35.66958944752833 139.73913056469348 26.351 35.66958182394033 139.7391331584493 26.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0e36b3d-8719-4b37-92f7-5d9ff7e48d98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0e36b3d-8719-4b37-92f7-5d9ff7e48d98_0">
											<gml:posList>35.66958763076162 139.73915873451077 26.108 35.66958763076162 139.73915873451077 26.351 35.66958182394033 139.7391331584493 26.351 35.66958182394033 139.7391331584493 26.108 35.66958763076162 139.73915873451077 26.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b098d61a-5e77-4c44-aadd-867f03122f34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b098d61a-5e77-4c44-aadd-867f03122f34_0">
											<gml:posList>35.66959525434152 139.73915612971103 26.108 35.66959525434152 139.73915612971103 26.351 35.66958763076162 139.73915873451077 26.351 35.66958763076162 139.73915873451077 26.108 35.66959525434152 139.73915612971103 26.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-68ff3a54-57b3-42a5-9fde-911d91afaf01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68ff3a54-57b3-42a5-9fde-911d91afaf01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68ff3a54-57b3-42a5-9fde-911d91afaf01">
											<gml:posList>35.66960768528209 139.73916893969346 16.95 35.669581280859425 139.7391763716232 16.95 35.66957150551726 139.73912457666896 16.95 35.66959790993675 139.73911714472308 16.95 35.66960768528209 139.73916893969346 16.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b15c52a-c82c-4bab-a18f-eade0f028389">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b15c52a-c82c-4bab-a18f-eade0f028389">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b15c52a-c82c-4bab-a18f-eade0f028389">
											<gml:posList>35.66957150551726 139.73912457666896 26.668 35.669574508893405 139.73912688178507 26.668 35.6695960289552 139.73912083634787 26.668 35.66959790993675 139.73911714472308 26.668 35.66957150551726 139.73912457666896 26.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4018ffe-9663-4760-acf6-2bf31f9ff26b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4018ffe-9663-4760-acf6-2bf31f9ff26b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4018ffe-9663-4760-acf6-2bf31f9ff26b">
											<gml:posList>35.66959790993675 139.73911714472308 26.668 35.6695960289552 139.73912083634787 26.668 35.66960468190677 139.7391666345748 26.668 35.66960768528209 139.73916893969346 26.668 35.66959790993675 139.73911714472308 26.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d22b2397-1b03-46a4-bf16-2cd0fba79d39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d22b2397-1b03-46a4-bf16-2cd0fba79d39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d22b2397-1b03-46a4-bf16-2cd0fba79d39">
											<gml:posList>35.66960468190677 139.7391666345748 26.108 35.6695960289552 139.73912083634787 26.108 35.669574508893405 139.73912688178507 26.108 35.669583161842695 139.73917268000037 26.108 35.66960468190677 139.7391666345748 26.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92514dc2-4b0a-4d03-bc59-197488ff9508">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92514dc2-4b0a-4d03-bc59-197488ff9508">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92514dc2-4b0a-4d03-bc59-197488ff9508">
											<gml:posList>35.669581280859425 139.7391763716232 26.668 35.669583161842695 139.73917268000037 26.668 35.669574508893405 139.73912688178507 26.668 35.66957150551726 139.73912457666896 26.668 35.669581280859425 139.7391763716232 26.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ce41db4-969b-4de6-a53c-91bb40249055">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ce41db4-969b-4de6-a53c-91bb40249055">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ce41db4-969b-4de6-a53c-91bb40249055">
											<gml:posList>35.66960768528209 139.73916893969346 26.668 35.66960468190677 139.7391666345748 26.668 35.669583161842695 139.73917268000037 26.668 35.669581280859425 139.7391763716232 26.668 35.66960768528209 139.73916893969346 26.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6aeafb5-e52b-4277-b644-eb8aab21e28e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6aeafb5-e52b-4277-b644-eb8aab21e28e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6aeafb5-e52b-4277-b644-eb8aab21e28e">
											<gml:posList>35.66959790993675 139.73911714472308 16.95 35.66957150551726 139.73912457666896 16.95 35.66957150551726 139.73912457666896 26.668 35.66959790993675 139.73911714472308 26.668 35.66959790993675 139.73911714472308 16.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3b83488-f830-4dd7-959b-951612f8e9ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3b83488-f830-4dd7-959b-951612f8e9ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3b83488-f830-4dd7-959b-951612f8e9ad">
											<gml:posList>35.669574508893405 139.73912688178507 26.668 35.669574508893405 139.73912688178507 26.108 35.6695960289552 139.73912083634787 26.108 35.6695960289552 139.73912083634787 26.668 35.669574508893405 139.73912688178507 26.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-173ee5d9-9060-4cc2-bff9-602851adf06e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-173ee5d9-9060-4cc2-bff9-602851adf06e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-173ee5d9-9060-4cc2-bff9-602851adf06e">
											<gml:posList>35.66960768528209 139.73916893969346 16.95 35.66959790993675 139.73911714472308 16.95 35.66959790993675 139.73911714472308 26.668 35.66960768528209 139.73916893969346 26.668 35.66960768528209 139.73916893969346 16.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95de9fa0-ec87-454d-8a9d-4db1367b2d40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95de9fa0-ec87-454d-8a9d-4db1367b2d40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95de9fa0-ec87-454d-8a9d-4db1367b2d40">
											<gml:posList>35.6695960289552 139.73912083634787 26.668 35.6695960289552 139.73912083634787 26.108 35.66960468190677 139.7391666345748 26.108 35.66960468190677 139.7391666345748 26.668 35.6695960289552 139.73912083634787 26.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93655bf5-f9ff-4a3e-bc70-2d187b9261bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93655bf5-f9ff-4a3e-bc70-2d187b9261bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93655bf5-f9ff-4a3e-bc70-2d187b9261bf">
											<gml:posList>35.669583161842695 139.73917268000037 26.668 35.669583161842695 139.73917268000037 26.108 35.669574508893405 139.73912688178507 26.108 35.669574508893405 139.73912688178507 26.668 35.669583161842695 139.73917268000037 26.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ae1b092-4509-4b98-8c8d-09defc2585e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ae1b092-4509-4b98-8c8d-09defc2585e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ae1b092-4509-4b98-8c8d-09defc2585e6">
											<gml:posList>35.66957150551726 139.73912457666896 16.95 35.669581280859425 139.7391763716232 16.95 35.669581280859425 139.7391763716232 26.668 35.66957150551726 139.73912457666896 26.668 35.66957150551726 139.73912457666896 16.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18aa3ebd-5792-4169-8446-d59cde64eeaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18aa3ebd-5792-4169-8446-d59cde64eeaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18aa3ebd-5792-4169-8446-d59cde64eeaa">
											<gml:posList>35.66960468190677 139.7391666345748 26.668 35.66960468190677 139.7391666345748 26.108 35.669583161842695 139.73917268000037 26.108 35.669583161842695 139.73917268000037 26.668 35.66960468190677 139.7391666345748 26.668</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3f87a15-3802-4a8f-a58b-8f601e42a652">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3f87a15-3802-4a8f-a58b-8f601e42a652">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3f87a15-3802-4a8f-a58b-8f601e42a652">
											<gml:posList>35.669581280859425 139.7391763716232 16.95 35.66960768528209 139.73916893969346 16.95 35.66960768528209 139.73916893969346 26.668 35.669581280859425 139.7391763716232 26.668 35.669581280859425 139.7391763716232 16.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5282</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">14.4653</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.44</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>