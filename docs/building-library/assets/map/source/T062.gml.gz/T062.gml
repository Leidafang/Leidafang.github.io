<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_0ea986b0-33e0-42bb-9c14-02e2329ed914">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">11.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668420449636095 139.7384330141751 0 35.66838030703912 139.73839307522442 0 35.66835680908013 139.73842845018441 0 35.66848670885832 139.73855797645612 0 35.66856431521596 139.73844112841036 0 35.66851470072178 139.7383917010364 0 35.668471035870226 139.73845736595572 0 35.66843098333176 139.7384173164012 0 35.668420449636095 139.7384330141751 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668420449636095 139.7384330141751 17.33 35.66843098333176 139.7384173164012 17.33 35.668471035870226 139.73845736595572 17.33 35.66851470072178 139.7383917010364 17.33 35.66856431521596 139.73844112841036 17.33 35.66848670885832 139.73855797645612 17.33 35.66835680908013 139.73842845018441 17.33 35.66838030703912 139.73839307522442 17.33 35.668420449636095 139.7384330141751 17.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668420449636095 139.7384330141751 17.33 35.66838030703912 139.73839307522442 17.33 35.66838030703912 139.73839307522442 29.24 35.668420449636095 139.7384330141751 29.24 35.668420449636095 139.7384330141751 17.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838030703912 139.73839307522442 17.33 35.66835680908013 139.73842845018441 17.33 35.66835680908013 139.73842845018441 29.24 35.66838030703912 139.73839307522442 29.24 35.66838030703912 139.73839307522442 17.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66835680908013 139.73842845018441 17.33 35.66848670885832 139.73855797645612 17.33 35.66848670885832 139.73855797645612 29.24 35.66835680908013 139.73842845018441 29.24 35.66835680908013 139.73842845018441 17.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848670885832 139.73855797645612 17.33 35.66856431521596 139.73844112841036 17.33 35.66856431521596 139.73844112841036 29.24 35.66848670885832 139.73855797645612 29.24 35.66848670885832 139.73855797645612 17.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66856431521596 139.73844112841036 17.33 35.66851470072178 139.7383917010364 17.33 35.66851470072178 139.7383917010364 29.24 35.66856431521596 139.73844112841036 29.24 35.66856431521596 139.73844112841036 17.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851470072178 139.7383917010364 17.33 35.668471035870226 139.73845736595572 17.33 35.668471035870226 139.73845736595572 29.24 35.66851470072178 139.7383917010364 29.24 35.66851470072178 139.7383917010364 17.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668471035870226 139.73845736595572 17.33 35.66843098333176 139.7384173164012 17.33 35.66843098333176 139.7384173164012 29.24 35.668471035870226 139.73845736595572 29.24 35.668471035870226 139.73845736595572 17.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66843098333176 139.7384173164012 17.33 35.668420449636095 139.7384330141751 17.33 35.668420449636095 139.7384330141751 29.24 35.66843098333176 139.7384173164012 29.24 35.66843098333176 139.7384173164012 17.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668420449636095 139.7384330141751 29.24 35.66838030703912 139.73839307522442 29.24 35.66835680908013 139.73842845018441 29.24 35.66848670885832 139.73855797645612 29.24 35.66856431521596 139.73844112841036 29.24 35.66851470072178 139.7383917010364 29.24 35.668471035870226 139.73845736595572 29.24 35.66843098333176 139.7384173164012 29.24 35.668420449636095 139.7384330141751 29.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-eb39c08c-6744-4615-986d-1a6f7be0ca17"/>
							<gml:surfaceMember xlink:href="#poly-0637fc4a-e19f-45f7-8788-ddc4681301a1"/>
							<gml:surfaceMember xlink:href="#poly-26af9a32-ec6b-40d4-a936-14da85966f71"/>
							<gml:surfaceMember xlink:href="#poly-4ca7e232-2525-4504-9f4d-ee7d979469e4"/>
							<gml:surfaceMember xlink:href="#poly-df05ae02-bbce-4e55-bfd7-bcfc9c94198a"/>
							<gml:surfaceMember xlink:href="#poly-77abb2d4-26e1-4c3c-8581-6338142280f8"/>
							<gml:surfaceMember xlink:href="#poly-16c66669-b0f9-48c7-bdfa-ca83eca1ba27"/>
							<gml:surfaceMember xlink:href="#poly-9ff29d64-b394-4a1b-83b0-6d6c6e657664"/>
							<gml:surfaceMember xlink:href="#poly-2e9569fa-e880-4393-bb50-d9775d106082"/>
							<gml:surfaceMember xlink:href="#poly-9eff48e8-6833-41d0-b860-cf70deb55a61"/>
							<gml:surfaceMember xlink:href="#poly-2b52145d-4efe-439a-ae6f-573de90cfedf"/>
							<gml:surfaceMember xlink:href="#poly-f39fff7c-e052-4b41-ae77-27212dca43a4"/>
							<gml:surfaceMember xlink:href="#poly-27b7999f-9afb-4505-b94a-a883bc6baf85"/>
							<gml:surfaceMember xlink:href="#poly-aeaf01cc-f0cd-4b55-bfb5-0c6dbd5800ee"/>
							<gml:surfaceMember xlink:href="#poly-9814b1a8-411c-44fa-a184-6fd505fc79b6"/>
							<gml:surfaceMember xlink:href="#poly-754e1e3a-d0f9-4208-a325-fc212c1414b7"/>
							<gml:surfaceMember xlink:href="#poly-41b56736-8ccf-4e12-8fa4-a2eaa81254be"/>
							<gml:surfaceMember xlink:href="#poly-3f94d0dc-c73b-441e-98ed-5a218e5178e5"/>
							<gml:surfaceMember xlink:href="#poly-c79efe0e-a5ff-4857-a2ec-a5c83c22d9ca"/>
							<gml:surfaceMember xlink:href="#poly-479d1f13-b75e-45e2-b004-cf20e425c3ae"/>
							<gml:surfaceMember xlink:href="#poly-063d18c2-b879-4625-82d1-d362272a54b3"/>
							<gml:surfaceMember xlink:href="#poly-a3d4edb3-2adb-4abc-a118-6d07c716755b"/>
							<gml:surfaceMember xlink:href="#poly-f9bd846d-7e75-4839-b6d4-4933c013159b"/>
							<gml:surfaceMember xlink:href="#poly-4eda1086-2a2c-4c80-a40f-795ccb1480aa"/>
							<gml:surfaceMember xlink:href="#poly-95f30bb5-1e11-436a-9c20-46f648d3738a"/>
							<gml:surfaceMember xlink:href="#poly-498f9527-4fd2-40a0-b02e-9ac78c1afc72"/>
							<gml:surfaceMember xlink:href="#poly-708d28b5-124b-4c77-beba-657f7c095018"/>
							<gml:surfaceMember xlink:href="#poly-f6d0c70d-e36e-4c2d-8820-99dcb9d0d2cf"/>
							<gml:surfaceMember xlink:href="#poly-ba14fefc-b9ec-43fa-b6cb-578635c3f8d2"/>
							<gml:surfaceMember xlink:href="#poly-3c6d516a-339e-451b-a5b3-d6575d524847"/>
							<gml:surfaceMember xlink:href="#poly-8858824f-bd5c-428b-8080-f19e4f54cbb1"/>
							<gml:surfaceMember xlink:href="#poly-db92bce8-1ee5-4e67-89d0-7f72c4e64aac"/>
							<gml:surfaceMember xlink:href="#poly-ad4a5f66-5cbd-4660-92a3-879abc553fa6"/>
							<gml:surfaceMember xlink:href="#poly-2ef5783b-0273-4f86-aa66-d3f6bba2320e"/>
							<gml:surfaceMember xlink:href="#poly-c270640f-4c23-48b3-990a-2f1008f7ac95"/>
							<gml:surfaceMember xlink:href="#poly-fe30295d-efd1-464e-8623-2d99845445bc"/>
							<gml:surfaceMember xlink:href="#poly-8c803f81-b81f-475b-9c59-e29f3e5128eb"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_0ea986b0-33e0-42bb-9c14-02e2329ed914_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef82602c-a897-451c-a82e-65244439a2c9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668414996220825 139.73846719691784 34.787 35.668404143693415 139.73845576611507 34.787 35.66841432678824 139.73844125068308 34.787 35.668425179317005 139.7384526814853 34.787 35.668414996220825 139.73846719691784 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2538afb-3997-4d6c-9262-a97210bb3c67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66849324840104 139.73844934236948 29.47 35.66849940060942 139.73845548771138 29.47 35.66849085670568 139.73846834431788 29.47 35.66848469548423 139.73846219898627 29.47 35.66849324840104 139.73844934236948 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d86a2fb7-c804-4639-a940-eb4c42b17e23">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668485248159904 139.7384772429819 29.47 35.66847596601577 139.73849122714867 29.47 35.6684820731099 139.73849731731588 29.47 35.66847587000406 139.7385066585199 29.47 35.66846976291039 139.7385005683525 29.47 35.66845441267087 139.7385236505426 29.47 35.66844404775114 139.73851331270322 29.47 35.6684666274137 139.7384793085193 29.47 35.66847492823524 139.73846681672333 29.47 35.668485248159904 139.7384772429819 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c221003-fec0-4094-bcf0-5334800aebb7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66844344455349 139.73851423023387 29.9 35.66844404775114 139.73851331270322 29.9 35.66845441267087 139.7385236505426 29.9 35.66845380947314 139.7385245680733 29.9 35.66844344455349 139.73851423023387 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6c4006b-baea-4eb5-9731-5e4e0dd1cf20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6c4006b-baea-4eb5-9731-5e4e0dd1cf20_0">
											<gml:posList>35.66841432678824 139.73844125068308 34.787 35.66841432678824 139.73844125068308 36.791 35.668425179317005 139.7384526814853 36.791 35.668425179317005 139.7384526814853 34.787 35.66841432678824 139.73844125068308 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0aaf1b4f-16f3-467f-bbeb-2c3e551994b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0aaf1b4f-16f3-467f-bbeb-2c3e551994b6_0">
											<gml:posList>35.66841432678824 139.73844125068308 34.787 35.668404143693415 139.73845576611507 34.787 35.668404143693415 139.73845576611507 36.791 35.66841432678824 139.73844125068308 36.791 35.66841432678824 139.73844125068308 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-247c32ca-2132-4f59-b350-10967383c2d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-247c32ca-2132-4f59-b350-10967383c2d1_0">
											<gml:posList>35.66849324840104 139.73844934236948 29.47 35.66849324840104 139.73844934236948 30.593 35.66849940060942 139.73845548771138 30.593 35.66849940060942 139.73845548771138 29.47 35.66849324840104 139.73844934236948 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c29dc29-7773-4efd-86bb-6e6730311202">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c29dc29-7773-4efd-86bb-6e6730311202_0">
											<gml:posList>35.668414996220825 139.73846719691784 36.791 35.668425179317005 139.7384526814853 36.791 35.66841432678824 139.73844125068308 36.791 35.668404143693415 139.73845576611507 36.791 35.668414996220825 139.73846719691784 36.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-997408a6-04ec-4a16-b238-3b04b18f4d1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-997408a6-04ec-4a16-b238-3b04b18f4d1f_0">
											<gml:posList>35.66848469548423 139.73846219898627 30.593 35.66849324840104 139.73844934236948 30.593 35.66849324840104 139.73844934236948 29.47 35.66848469548423 139.73846219898627 29.47 35.66848469548423 139.73846219898627 30.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fef703e0-bb32-44fd-87d3-144d8352c1ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fef703e0-bb32-44fd-87d3-144d8352c1ea_0">
											<gml:posList>35.66849324840104 139.73844934236948 30.593 35.66848469548423 139.73846219898627 30.593 35.66849085670568 139.73846834431788 30.593 35.66849940060942 139.73845548771138 30.593 35.66849324840104 139.73844934236948 30.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e899679e-1e5b-4765-94e8-60bb40457f7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e899679e-1e5b-4765-94e8-60bb40457f7b_0">
											<gml:posList>35.668425179317005 139.7384526814853 34.787 35.668425179317005 139.7384526814853 36.791 35.668414996220825 139.73846719691784 36.791 35.668414996220825 139.73846719691784 34.787 35.668425179317005 139.7384526814853 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e24d4370-4d1e-4ad4-9620-c7f36d40c0aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e24d4370-4d1e-4ad4-9620-c7f36d40c0aa_0">
											<gml:posList>35.668404143693415 139.73845576611507 34.787 35.668414996220825 139.73846719691784 34.787 35.668414996220825 139.73846719691784 36.791 35.668404143693415 139.73845576611507 36.791 35.668404143693415 139.73845576611507 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-990cc901-119d-479b-b7c3-3a23a98aba25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-990cc901-119d-479b-b7c3-3a23a98aba25_0">
											<gml:posList>35.66849940060942 139.73845548771138 29.47 35.66849940060942 139.73845548771138 30.593 35.66849085670568 139.73846834431788 30.593 35.66849085670568 139.73846834431788 29.47 35.66849940060942 139.73845548771138 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94f89da9-ed95-4cd7-937b-a0e8e6291ecf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94f89da9-ed95-4cd7-937b-a0e8e6291ecf_0">
											<gml:posList>35.66848469548423 139.73846219898627 29.47 35.66849085670568 139.73846834431788 29.47 35.66849085670568 139.73846834431788 30.593 35.66848469548423 139.73846219898627 30.593 35.66848469548423 139.73846219898627 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2de0b23-8919-431e-a4b8-d89b27c78a7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2de0b23-8919-431e-a4b8-d89b27c78a7d_0">
											<gml:posList>35.668485248159904 139.7384772429819 33.234 35.668485248159904 139.7384772429819 29.47 35.66847492823524 139.73846681672333 29.47 35.66847492823524 139.73846681672333 35.021 35.668485248159904 139.7384772429819 33.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3783547d-9410-4a5a-9c80-e5073d6052b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3783547d-9410-4a5a-9c80-e5073d6052b3_0">
											<gml:posList>35.6684666274137 139.7384793085193 29.605 35.6684688151559 139.73847601422446 30.806 35.6684688151559 139.73847601422446 35.021 35.66847492823524 139.73846681672333 35.021 35.66847492823524 139.73846681672333 29.47 35.6684666274137 139.7384793085193 29.47 35.6684666274137 139.7384793085193 29.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c10fdfb4-8096-4be7-8539-2f559eaec85b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c10fdfb4-8096-4be7-8539-2f559eaec85b_0">
											<gml:posList>35.6684820731099 139.73849731731588 29.47 35.66847596601577 139.73849122714867 29.47 35.66847596601577 139.73849122714867 31.328 35.6684820731099 139.73849731731588 31.328 35.6684820731099 139.73849731731588 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d7cd28a-a530-43a8-b41a-95ddb369d624">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d7cd28a-a530-43a8-b41a-95ddb369d624_0">
											<gml:posList>35.66844344455349 139.73851423023387 35.019 35.6684688151559 139.73847601422446 35.021 35.6684688151559 139.73847601422446 30.806 35.6684666274137 139.7384793085193 29.605 35.6684666274137 139.7384793085193 29.47 35.66844404775114 139.73851331270322 29.47 35.66844404775114 139.73851331270322 29.9 35.66844344455349 139.73851423023387 29.9 35.66844344455349 139.73851423023387 35.019</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ad9eac7-0a5c-4e94-a52b-4f7c7a66f773">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ad9eac7-0a5c-4e94-a52b-4f7c7a66f773_0">
											<gml:posList>35.66845380947314 139.7385245680733 33.234 35.668485248159904 139.7384772429819 33.234 35.66847492823524 139.73846681672333 35.021 35.6684688151559 139.73847601422446 35.021 35.66844344455349 139.73851423023387 35.019 35.66845380947314 139.7385245680733 33.234</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9821231f-3fb7-401f-b218-30db223253ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9821231f-3fb7-401f-b218-30db223253ec_0">
											<gml:posList>35.6684820731099 139.73849731731588 31.328 35.66847596601577 139.73849122714867 31.328 35.66846976291039 139.7385005683525 31.328 35.66847587000406 139.7385066585199 31.328 35.6684820731099 139.73849731731588 31.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4366502-4f7a-4aa8-8c21-b2a05afc6767">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4366502-4f7a-4aa8-8c21-b2a05afc6767_0">
											<gml:posList>35.66845441267087 139.7385236505426 29.47 35.66846976291039 139.7385005683525 29.47 35.66846976291039 139.7385005683525 31.328 35.66847596601577 139.73849122714867 31.328 35.66847596601577 139.73849122714867 29.47 35.668485248159904 139.7384772429819 29.47 35.668485248159904 139.7384772429819 33.234 35.66845380947314 139.7385245680733 33.234 35.66845380947314 139.7385245680733 29.9 35.66845441267087 139.7385236505426 29.9 35.66845441267087 139.7385236505426 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cf06a8c-a806-4c28-89ce-7135a9179987">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cf06a8c-a806-4c28-89ce-7135a9179987_0">
											<gml:posList>35.6684820731099 139.73849731731588 29.47 35.6684820731099 139.73849731731588 31.328 35.66847587000406 139.7385066585199 31.328 35.66847587000406 139.7385066585199 29.47 35.6684820731099 139.73849731731588 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-005f14f2-b89d-4616-95a3-672103b2cbbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-005f14f2-b89d-4616-95a3-672103b2cbbe_0">
											<gml:posList>35.66847587000406 139.7385066585199 31.328 35.66846976291039 139.7385005683525 31.328 35.66846976291039 139.7385005683525 29.47 35.66847587000406 139.7385066585199 29.47 35.66847587000406 139.7385066585199 31.328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6dc7768-b326-4ea5-97eb-c44e4f0aa015">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6dc7768-b326-4ea5-97eb-c44e4f0aa015_0">
											<gml:posList>35.66845441267087 139.7385236505426 29.9 35.66844404775114 139.73851331270322 29.9 35.66844404775114 139.73851331270322 29.47 35.66845441267087 139.7385236505426 29.47 35.66845441267087 139.7385236505426 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6df67a7-c9a5-4613-a664-d5aa7b4bcb1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6df67a7-c9a5-4613-a664-d5aa7b4bcb1f_0">
											<gml:posList>35.66844344455349 139.73851423023387 29.9 35.66845380947314 139.7385245680733 29.9 35.66845380947314 139.7385245680733 33.234 35.66844344455349 139.73851423023387 35.019 35.66844344455349 139.73851423023387 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-eb39c08c-6744-4615-986d-1a6f7be0ca17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb39c08c-6744-4615-986d-1a6f7be0ca17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb39c08c-6744-4615-986d-1a6f7be0ca17">
											<gml:posList>35.66835680908012 139.7384284501844 17.33 35.66838030703912 139.73839307522442 17.33 35.66842044963609 139.73843301417506 17.33 35.66843098333178 139.7384173164012 17.33 35.66847103587022 139.73845736595572 17.33 35.66851470072177 139.7383917010364 17.33 35.66856431521594 139.73844112841036 17.33 35.668486708858325 139.73855797645612 17.33 35.66835680908012 139.7384284501844 17.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0637fc4a-e19f-45f7-8788-ddc4681301a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0637fc4a-e19f-45f7-8788-ddc4681301a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0637fc4a-e19f-45f7-8788-ddc4681301a1">
											<gml:posList>35.66835680908012 139.7384284501844 31.845 35.66837706083179 139.73844865140987 35.021 35.66840054071695 139.7384132101923 35.021 35.66838030703912 139.73839307522442 31.845 35.66835680908012 139.7384284501844 31.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26af9a32-ec6b-40d4-a936-14da85966f71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26af9a32-ec6b-40d4-a936-14da85966f71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26af9a32-ec6b-40d4-a936-14da85966f71">
											<gml:posList>35.66840080446589 139.73841619229646 35.021 35.66840054071695 139.7384132101923 35.021 35.66837706083179 139.73844865140987 35.021 35.668379503307605 139.73844833923204 35.021 35.66840080446589 139.73841619229646 35.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ca7e232-2525-4504-9f4d-ee7d979469e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ca7e232-2525-4504-9f4d-ee7d979469e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ca7e232-2525-4504-9f4d-ee7d979469e4">
											<gml:posList>35.668379503307605 139.73844833923204 35.021 35.66837706083179 139.73844865140987 35.021 35.668443201469934 139.7385145950391 35.021 35.668442955742194 139.73851160186572 35.021 35.668379503307605 139.73844833923204 35.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df05ae02-bbce-4e55-bfd7-bcfc9c94198a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df05ae02-bbce-4e55-bfd7-bcfc9c94198a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df05ae02-bbce-4e55-bfd7-bcfc9c94198a">
											<gml:posList>35.66840080446589 139.73841619229646 35.021 35.6684207043621 139.7384359852447 35.021 35.66842044963609 139.73843301417506 35.021 35.66840054071695 139.7384132101923 35.021 35.66840080446589 139.73841619229646 35.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77abb2d4-26e1-4c3c-8581-6338142280f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77abb2d4-26e1-4c3c-8581-6338142280f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77abb2d4-26e1-4c3c-8581-6338142280f8">
											<gml:posList>35.66843122905317 139.7384202985278 35.021 35.66843098333178 139.7384173164012 35.021 35.66842044963609 139.73843301417506 35.021 35.6684207043621 139.7384359852447 35.021 35.66843122905317 139.7384202985278 35.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16c66669-b0f9-48c7-bdfa-ca83eca1ba27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16c66669-b0f9-48c7-bdfa-ca83eca1ba27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16c66669-b0f9-48c7-bdfa-ca83eca1ba27">
											<gml:posList>35.66840080446589 139.73841619229646 34.787 35.668379503307605 139.73844833923204 34.787 35.668442955742194 139.73851160186572 34.787 35.668474547448376 139.7384640114907 34.787 35.66846993748382 139.7384590020628 34.787 35.66843122905317 139.7384202985278 34.787 35.6684207043621 139.7384359852447 34.787 35.66840080446589 139.73841619229646 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ff29d64-b394-4a1b-83b0-6d6c6e657664">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ff29d64-b394-4a1b-83b0-6d6c6e657664">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ff29d64-b394-4a1b-83b0-6d6c6e657664">
											<gml:posList>35.66843122905317 139.7384202985278 35.021 35.66846993748382 139.7384590020628 35.021 35.66847103587022 139.73845736595572 35.021 35.66843098333178 139.7384173164012 35.021 35.66843122905317 139.7384202985278 35.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e9569fa-e880-4393-bb50-d9775d106082">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e9569fa-e880-4393-bb50-d9775d106082">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e9569fa-e880-4393-bb50-d9775d106082">
											<gml:posList>35.668443201469934 139.7385145950391 29.9 35.66847226653806 139.73854357850144 29.9 35.66847207542381 139.7385412590681 29.9 35.66844404775114 139.73851331270322 29.9 35.668443201469934 139.7385145950391 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9eff48e8-6833-41d0-b860-cf70deb55a61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9eff48e8-6833-41d0-b860-cf70deb55a61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9eff48e8-6833-41d0-b860-cf70deb55a61">
											<gml:posList>35.668442955742194 139.73851160186572 35.021 35.668443201469934 139.7385145950391 35.021 35.668476935911464 139.73846378774485 35.021 35.668474547448376 139.7384640114907 35.021 35.668442955742194 139.73851160186572 35.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b52145d-4efe-439a-ae6f-573de90cfedf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b52145d-4efe-439a-ae6f-573de90cfedf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b52145d-4efe-439a-ae6f-573de90cfedf">
											<gml:posList>35.668474547448376 139.7384640114907 35.021 35.668476935911464 139.73846378774485 35.021 35.66847103587022 139.73845736595572 35.021 35.66846993748382 139.7384590020628 35.021 35.668474547448376 139.7384640114907 35.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f39fff7c-e052-4b41-ae77-27212dca43a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f39fff7c-e052-4b41-ae77-27212dca43a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f39fff7c-e052-4b41-ae77-27212dca43a4">
											<gml:posList>35.66847103587022 139.73845736595572 29.9 35.66847200116559 139.73845841418319 29.9 35.668514882816474 139.73839400943524 29.9 35.66851470072177 139.7383917010364 29.9 35.66847103587022 139.73845736595572 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27b7999f-9afb-4505-b94a-a883bc6baf85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27b7999f-9afb-4505-b94a-a883bc6baf85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27b7999f-9afb-4505-b94a-a883bc6baf85">
											<gml:posList>35.66854792606532 139.73842692054927 29.47 35.668514882816474 139.73839400943524 29.47 35.66847200116559 139.73845841418319 29.47 35.668476935911464 139.73846378774485 29.47 35.66844404775114 139.73851331270322 29.47 35.66847207542381 139.7385412590681 29.47 35.66854792606532 139.73842692054927 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aeaf01cc-f0cd-4b55-bfb5-0c6dbd5800ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aeaf01cc-f0cd-4b55-bfb5-0c6dbd5800ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aeaf01cc-f0cd-4b55-bfb5-0c6dbd5800ee">
											<gml:posList>35.66847207542381 139.7385412590681 29.9 35.66847226653806 139.73854357850144 29.9 35.66854981876474 139.73842668634288 29.9 35.66854792606532 139.73842692054927 29.9 35.66847207542381 139.7385412590681 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9814b1a8-411c-44fa-a184-6fd505fc79b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9814b1a8-411c-44fa-a184-6fd505fc79b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9814b1a8-411c-44fa-a184-6fd505fc79b6">
											<gml:posList>35.66856431521594 139.73844112841036 26.925 35.66854981876474 139.73842668634288 29.9 35.66847226653806 139.73854357850144 29.9 35.668486708858325 139.73855797645612 26.925 35.66856431521594 139.73844112841036 26.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-754e1e3a-d0f9-4208-a325-fc212c1414b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-754e1e3a-d0f9-4208-a325-fc212c1414b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-754e1e3a-d0f9-4208-a325-fc212c1414b7">
											<gml:posList>35.66854792606532 139.73842692054927 29.9 35.66854981876474 139.73842668634288 29.9 35.66851470072177 139.7383917010364 29.9 35.668514882816474 139.73839400943524 29.9 35.66854792606532 139.73842692054927 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41b56736-8ccf-4e12-8fa4-a2eaa81254be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41b56736-8ccf-4e12-8fa4-a2eaa81254be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41b56736-8ccf-4e12-8fa4-a2eaa81254be">
											<gml:posList>35.6684207043621 139.7384359852447 34.787 35.6684207043621 139.7384359852447 35.021 35.66840080446589 139.73841619229646 35.021 35.66840080446589 139.73841619229646 34.787 35.6684207043621 139.7384359852447 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f94d0dc-c73b-441e-98ed-5a218e5178e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f94d0dc-c73b-441e-98ed-5a218e5178e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f94d0dc-c73b-441e-98ed-5a218e5178e5">
											<gml:posList>35.66846993748382 139.7384590020628 34.787 35.66846993748382 139.7384590020628 35.021 35.66843122905317 139.7384202985278 35.021 35.66843122905317 139.7384202985278 34.787 35.66846993748382 139.7384590020628 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c79efe0e-a5ff-4857-a2ec-a5c83c22d9ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c79efe0e-a5ff-4857-a2ec-a5c83c22d9ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c79efe0e-a5ff-4857-a2ec-a5c83c22d9ca">
											<gml:posList>35.668474547448376 139.7384640114907 34.787 35.668474547448376 139.7384640114907 35.021 35.66846993748382 139.7384590020628 35.021 35.66846993748382 139.7384590020628 34.787 35.668474547448376 139.7384640114907 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-479d1f13-b75e-45e2-b004-cf20e425c3ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-479d1f13-b75e-45e2-b004-cf20e425c3ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-479d1f13-b75e-45e2-b004-cf20e425c3ae">
											<gml:posList>35.66835680908012 139.7384284501844 31.845 35.66838030703912 139.73839307522442 31.845 35.66838030703912 139.73839307522442 17.33 35.66835680908012 139.7384284501844 17.33 35.66835680908012 139.7384284501844 31.845</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-063d18c2-b879-4625-82d1-d362272a54b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-063d18c2-b879-4625-82d1-d362272a54b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-063d18c2-b879-4625-82d1-d362272a54b3">
											<gml:posList>35.66840080446589 139.73841619229646 34.787 35.66840080446589 139.73841619229646 35.021 35.668379503307605 139.73844833923204 35.021 35.668379503307605 139.73844833923204 34.787 35.66840080446589 139.73841619229646 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3d4edb3-2adb-4abc-a118-6d07c716755b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3d4edb3-2adb-4abc-a118-6d07c716755b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3d4edb3-2adb-4abc-a118-6d07c716755b">
											<gml:posList>35.66838030703912 139.73839307522442 17.33 35.66838030703912 139.73839307522442 31.845 35.66840054071695 139.7384132101923 35.021 35.66842044963609 139.73843301417506 35.021 35.66842044963609 139.73843301417506 17.33 35.66838030703912 139.73839307522442 17.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9bd846d-7e75-4839-b6d4-4933c013159b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9bd846d-7e75-4839-b6d4-4933c013159b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9bd846d-7e75-4839-b6d4-4933c013159b">
											<gml:posList>35.668379503307605 139.73844833923204 34.787 35.668379503307605 139.73844833923204 35.021 35.668442955742194 139.73851160186572 35.021 35.668442955742194 139.73851160186572 34.787 35.668379503307605 139.73844833923204 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4eda1086-2a2c-4c80-a40f-795ccb1480aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4eda1086-2a2c-4c80-a40f-795ccb1480aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4eda1086-2a2c-4c80-a40f-795ccb1480aa">
											<gml:posList>35.66837706083179 139.73844865140987 35.021 35.66835680908012 139.7384284501844 31.845 35.66835680908012 139.7384284501844 17.33 35.668486708858325 139.73855797645612 17.33 35.668486708858325 139.73855797645612 26.925 35.66847226653806 139.73854357850144 29.9 35.668443201469934 139.7385145950391 29.9 35.668443201469934 139.7385145950391 35.021 35.66837706083179 139.73844865140987 35.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95f30bb5-1e11-436a-9c20-46f648d3738a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95f30bb5-1e11-436a-9c20-46f648d3738a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95f30bb5-1e11-436a-9c20-46f648d3738a">
											<gml:posList>35.66842044963609 139.73843301417506 35.021 35.66843098333178 139.7384173164012 35.021 35.66843098333178 139.7384173164012 17.33 35.66842044963609 139.73843301417506 17.33 35.66842044963609 139.73843301417506 35.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-498f9527-4fd2-40a0-b02e-9ac78c1afc72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-498f9527-4fd2-40a0-b02e-9ac78c1afc72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-498f9527-4fd2-40a0-b02e-9ac78c1afc72">
											<gml:posList>35.66843122905317 139.7384202985278 34.787 35.66843122905317 139.7384202985278 35.021 35.6684207043621 139.7384359852447 35.021 35.6684207043621 139.7384359852447 34.787 35.66843122905317 139.7384202985278 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-708d28b5-124b-4c77-beba-657f7c095018">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-708d28b5-124b-4c77-beba-657f7c095018">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-708d28b5-124b-4c77-beba-657f7c095018">
											<gml:posList>35.66843098333178 139.7384173164012 35.021 35.66847103587022 139.73845736595572 35.021 35.66847103587022 139.73845736595572 29.9 35.66847103587022 139.73845736595572 17.33 35.66843098333178 139.7384173164012 17.33 35.66843098333178 139.7384173164012 35.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6d0c70d-e36e-4c2d-8820-99dcb9d0d2cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6d0c70d-e36e-4c2d-8820-99dcb9d0d2cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6d0c70d-e36e-4c2d-8820-99dcb9d0d2cf">
											<gml:posList>35.66844404775114 139.73851331270322 29.47 35.66844404775114 139.73851331270322 29.9 35.66847207542381 139.7385412590681 29.9 35.66847207542381 139.7385412590681 29.47 35.66844404775114 139.73851331270322 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba14fefc-b9ec-43fa-b6cb-578635c3f8d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba14fefc-b9ec-43fa-b6cb-578635c3f8d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba14fefc-b9ec-43fa-b6cb-578635c3f8d2">
											<gml:posList>35.668442955742194 139.73851160186572 34.787 35.668442955742194 139.73851160186572 35.021 35.668474547448376 139.7384640114907 35.021 35.668474547448376 139.7384640114907 34.787 35.668442955742194 139.73851160186572 34.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c6d516a-339e-451b-a5b3-d6575d524847">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c6d516a-339e-451b-a5b3-d6575d524847">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c6d516a-339e-451b-a5b3-d6575d524847">
											<gml:posList>35.66844404775114 139.73851331270322 29.9 35.66844404775114 139.73851331270322 29.47 35.668476935911464 139.73846378774485 29.47 35.668476935911464 139.73846378774485 35.021 35.668443201469934 139.7385145950391 35.021 35.668443201469934 139.7385145950391 29.9 35.66844404775114 139.73851331270322 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8858824f-bd5c-428b-8080-f19e4f54cbb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8858824f-bd5c-428b-8080-f19e4f54cbb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8858824f-bd5c-428b-8080-f19e4f54cbb1">
											<gml:posList>35.668476935911464 139.73846378774485 35.021 35.668476935911464 139.73846378774485 29.47 35.66847200116559 139.73845841418319 29.47 35.66847200116559 139.73845841418319 29.9 35.66847103587022 139.73845736595572 29.9 35.66847103587022 139.73845736595572 35.021 35.668476935911464 139.73846378774485 35.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db92bce8-1ee5-4e67-89d0-7f72c4e64aac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db92bce8-1ee5-4e67-89d0-7f72c4e64aac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db92bce8-1ee5-4e67-89d0-7f72c4e64aac">
											<gml:posList>35.66847103587022 139.73845736595572 29.9 35.66851470072177 139.7383917010364 29.9 35.66851470072177 139.7383917010364 17.33 35.66847103587022 139.73845736595572 17.33 35.66847103587022 139.73845736595572 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad4a5f66-5cbd-4660-92a3-879abc553fa6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad4a5f66-5cbd-4660-92a3-879abc553fa6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad4a5f66-5cbd-4660-92a3-879abc553fa6">
											<gml:posList>35.668514882816474 139.73839400943524 29.47 35.668514882816474 139.73839400943524 29.9 35.66847200116559 139.73845841418319 29.9 35.66847200116559 139.73845841418319 29.47 35.668514882816474 139.73839400943524 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ef5783b-0273-4f86-aa66-d3f6bba2320e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ef5783b-0273-4f86-aa66-d3f6bba2320e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ef5783b-0273-4f86-aa66-d3f6bba2320e">
											<gml:posList>35.66854792606532 139.73842692054927 29.47 35.66854792606532 139.73842692054927 29.9 35.668514882816474 139.73839400943524 29.9 35.668514882816474 139.73839400943524 29.47 35.66854792606532 139.73842692054927 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c270640f-4c23-48b3-990a-2f1008f7ac95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c270640f-4c23-48b3-990a-2f1008f7ac95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c270640f-4c23-48b3-990a-2f1008f7ac95">
											<gml:posList>35.66851470072177 139.7383917010364 29.9 35.66854981876474 139.73842668634288 29.9 35.66856431521594 139.73844112841036 26.925 35.66856431521594 139.73844112841036 17.33 35.66851470072177 139.7383917010364 17.33 35.66851470072177 139.7383917010364 29.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe30295d-efd1-464e-8623-2d99845445bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe30295d-efd1-464e-8623-2d99845445bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe30295d-efd1-464e-8623-2d99845445bc">
											<gml:posList>35.66847207542381 139.7385412590681 29.47 35.66847207542381 139.7385412590681 29.9 35.66854792606532 139.73842692054927 29.9 35.66854792606532 139.73842692054927 29.47 35.66847207542381 139.7385412590681 29.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c803f81-b81f-475b-9c59-e29f3e5128eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c803f81-b81f-475b-9c59-e29f3e5128eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c803f81-b81f-475b-9c59-e29f3e5128eb">
											<gml:posList>35.66856431521594 139.73844112841036 26.925 35.668486708858325 139.73855797645612 26.925 35.668486708858325 139.73855797645612 17.33 35.66856431521594 139.73844112841036 17.33 35.66856431521594 139.73844112841036 26.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6753</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">154.7863</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>