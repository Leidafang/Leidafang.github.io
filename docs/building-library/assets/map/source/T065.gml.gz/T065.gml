<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_105bb476-18c1-47d2-8100-4c22f5119798">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">14.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66911533569077 139.73949029621974 0 35.66909050462695 139.73955041596597 0 35.66916165731612 139.73959451710905 0 35.66918639826432 139.73953439742849 0 35.66911533569077 139.73949029621974 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911533569077 139.73949029621974 11.65 35.66918639826432 139.73953439742849 11.65 35.66916165731612 139.73959451710905 11.65 35.66909050462695 139.73955041596597 11.65 35.66911533569077 139.73949029621974 11.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911533569077 139.73949029621974 11.65 35.66909050462695 139.73955041596597 11.65 35.66909050462695 139.73955041596597 26.15 35.66911533569077 139.73949029621974 26.15 35.66911533569077 139.73949029621974 11.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909050462695 139.73955041596597 11.65 35.66916165731612 139.73959451710905 11.65 35.66916165731612 139.73959451710905 26.15 35.66909050462695 139.73955041596597 26.15 35.66909050462695 139.73955041596597 11.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916165731612 139.73959451710905 11.65 35.66918639826432 139.73953439742849 11.65 35.66918639826432 139.73953439742849 26.15 35.66916165731612 139.73959451710905 26.15 35.66916165731612 139.73959451710905 11.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918639826432 139.73953439742849 11.65 35.66911533569077 139.73949029621974 11.65 35.66911533569077 139.73949029621974 26.15 35.66918639826432 139.73953439742849 26.15 35.66918639826432 139.73953439742849 11.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911533569077 139.73949029621974 26.15 35.66909050462695 139.73955041596597 26.15 35.66916165731612 139.73959451710905 26.15 35.66918639826432 139.73953439742849 26.15 35.66911533569077 139.73949029621974 26.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7325ed85-b3f0-43c8-ab19-f7fbf92c339e"/>
							<gml:surfaceMember xlink:href="#poly-38506ef7-5e8f-485d-887f-074f68ded916"/>
							<gml:surfaceMember xlink:href="#poly-6ddf734b-bd93-4dc0-a989-1db66e606713"/>
							<gml:surfaceMember xlink:href="#poly-b210e635-0fc1-4c19-9065-b2a0f10e5e4f"/>
							<gml:surfaceMember xlink:href="#poly-bf0c61e7-dc48-4645-96ef-bba0a0afd31a"/>
							<gml:surfaceMember xlink:href="#poly-085eafe7-5bab-4633-a9bc-14ea4046a687"/>
							<gml:surfaceMember xlink:href="#poly-db63f51a-2fc9-4e8b-8d19-d507747b74d0"/>
							<gml:surfaceMember xlink:href="#poly-7b33fe5d-6a49-4b4e-9c9e-d82b184ee3dc"/>
							<gml:surfaceMember xlink:href="#poly-754c52a9-b0b5-4e93-bde6-a74de01ebb33"/>
							<gml:surfaceMember xlink:href="#poly-ba9d943d-a884-4413-bfde-3990227846c5"/>
							<gml:surfaceMember xlink:href="#poly-9cc40437-e88d-401e-abea-ad52a8639ab6"/>
							<gml:surfaceMember xlink:href="#poly-4c37afd4-2f01-4504-8e54-4c5aeebb9236"/>
							<gml:surfaceMember xlink:href="#poly-55251a2a-6305-4ecc-95db-be4e7face4b1"/>
							<gml:surfaceMember xlink:href="#poly-19ca95c6-81c8-4a66-ba1e-87758bb22cc4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7325ed85-b3f0-43c8-ab19-f7fbf92c339e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7325ed85-b3f0-43c8-ab19-f7fbf92c339e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7325ed85-b3f0-43c8-ab19-f7fbf92c339e">
											<gml:posList>35.669115335690755 139.73949029621974 11.65 35.66918639826432 139.73953439742849 11.65 35.6691616573161 139.73959451710903 11.65 35.66909050462696 139.73955041596597 11.65 35.669115335690755 139.73949029621974 11.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38506ef7-5e8f-485d-887f-074f68ded916">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38506ef7-5e8f-485d-887f-074f68ded916">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38506ef7-5e8f-485d-887f-074f68ded916">
											<gml:posList>35.669115335690755 139.73949029621974 26.848 35.669116447624205 139.7394944592925 26.848 35.66918299213491 139.73953576008273 26.848 35.66918639826432 139.73953439742849 26.848 35.669115335690755 139.73949029621974 26.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ddf734b-bd93-4dc0-a989-1db66e606713">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ddf734b-bd93-4dc0-a989-1db66e606713">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ddf734b-bd93-4dc0-a989-1db66e606713">
											<gml:posList>35.66909050462696 139.73955041596597 26.848 35.669093901742876 139.73954905332445 26.848 35.669116447624205 139.7394944592925 26.848 35.669115335690755 139.73949029621974 26.848 35.66909050462696 139.73955041596597 26.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b210e635-0fc1-4c19-9065-b2a0f10e5e4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b210e635-0fc1-4c19-9065-b2a0f10e5e4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b210e635-0fc1-4c19-9065-b2a0f10e5e4f">
											<gml:posList>35.66918299213491 139.73953576008273 26.202 35.669116447624205 139.7394944592925 26.202 35.669093901742876 139.73954905332445 26.202 35.66916052735867 139.73959035405363 26.202 35.66918299213491 139.73953576008273 26.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bf0c61e7-dc48-4645-96ef-bba0a0afd31a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf0c61e7-dc48-4645-96ef-bba0a0afd31a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf0c61e7-dc48-4645-96ef-bba0a0afd31a">
											<gml:posList>35.66918639826432 139.73953439742849 26.848 35.66918299213491 139.73953576008273 26.848 35.66916052735867 139.73959035405363 26.848 35.6691616573161 139.73959451710903 26.848 35.66918639826432 139.73953439742849 26.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-085eafe7-5bab-4633-a9bc-14ea4046a687">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-085eafe7-5bab-4633-a9bc-14ea4046a687">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-085eafe7-5bab-4633-a9bc-14ea4046a687">
											<gml:posList>35.6691616573161 139.73959451710903 26.848 35.66916052735867 139.73959035405363 26.848 35.669093901742876 139.73954905332445 26.848 35.66909050462696 139.73955041596597 26.848 35.6691616573161 139.73959451710903 26.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db63f51a-2fc9-4e8b-8d19-d507747b74d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db63f51a-2fc9-4e8b-8d19-d507747b74d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db63f51a-2fc9-4e8b-8d19-d507747b74d0">
											<gml:posList>35.66918639826432 139.73953439742849 11.65 35.669115335690755 139.73949029621974 11.65 35.669115335690755 139.73949029621974 26.848 35.66918639826432 139.73953439742849 26.848 35.66918639826432 139.73953439742849 11.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b33fe5d-6a49-4b4e-9c9e-d82b184ee3dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b33fe5d-6a49-4b4e-9c9e-d82b184ee3dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b33fe5d-6a49-4b4e-9c9e-d82b184ee3dc">
											<gml:posList>35.669116447624205 139.7394944592925 26.848 35.669116447624205 139.7394944592925 26.202 35.66918299213491 139.73953576008273 26.202 35.66918299213491 139.73953576008273 26.848 35.669116447624205 139.7394944592925 26.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-754c52a9-b0b5-4e93-bde6-a74de01ebb33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-754c52a9-b0b5-4e93-bde6-a74de01ebb33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-754c52a9-b0b5-4e93-bde6-a74de01ebb33">
											<gml:posList>35.669115335690755 139.73949029621974 11.65 35.66909050462696 139.73955041596597 11.65 35.66909050462696 139.73955041596597 26.848 35.669115335690755 139.73949029621974 26.848 35.669115335690755 139.73949029621974 11.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba9d943d-a884-4413-bfde-3990227846c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba9d943d-a884-4413-bfde-3990227846c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba9d943d-a884-4413-bfde-3990227846c5">
											<gml:posList>35.669093901742876 139.73954905332445 26.848 35.669093901742876 139.73954905332445 26.202 35.669116447624205 139.7394944592925 26.202 35.669116447624205 139.7394944592925 26.848 35.669093901742876 139.73954905332445 26.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cc40437-e88d-401e-abea-ad52a8639ab6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cc40437-e88d-401e-abea-ad52a8639ab6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cc40437-e88d-401e-abea-ad52a8639ab6">
											<gml:posList>35.66918299213491 139.73953576008273 26.848 35.66918299213491 139.73953576008273 26.202 35.66916052735867 139.73959035405363 26.202 35.66916052735867 139.73959035405363 26.848 35.66918299213491 139.73953576008273 26.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c37afd4-2f01-4504-8e54-4c5aeebb9236">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c37afd4-2f01-4504-8e54-4c5aeebb9236">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c37afd4-2f01-4504-8e54-4c5aeebb9236">
											<gml:posList>35.6691616573161 139.73959451710903 11.65 35.66918639826432 139.73953439742849 11.65 35.66918639826432 139.73953439742849 26.848 35.6691616573161 139.73959451710903 26.848 35.6691616573161 139.73959451710903 11.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55251a2a-6305-4ecc-95db-be4e7face4b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55251a2a-6305-4ecc-95db-be4e7face4b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55251a2a-6305-4ecc-95db-be4e7face4b1">
											<gml:posList>35.66916052735867 139.73959035405363 26.848 35.66916052735867 139.73959035405363 26.202 35.669093901742876 139.73954905332445 26.202 35.669093901742876 139.73954905332445 26.848 35.66916052735867 139.73959035405363 26.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19ca95c6-81c8-4a66-ba1e-87758bb22cc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19ca95c6-81c8-4a66-ba1e-87758bb22cc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19ca95c6-81c8-4a66-ba1e-87758bb22cc4">
											<gml:posList>35.66909050462696 139.73955041596597 11.65 35.6691616573161 139.73959451710903 11.65 35.6691616573161 139.73959451710903 26.848 35.66909050462696 139.73955041596597 26.848 35.66909050462696 139.73955041596597 11.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5838</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">77.00095</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>