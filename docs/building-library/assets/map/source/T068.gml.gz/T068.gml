<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_10a8f921-82e6-485e-84be-37f320f94457">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668819940853716 139.73912501787436 0 35.66880958751374 139.73914093634065 0 35.668779277460516 139.73911037441937 0 35.668741103680695 139.73916719588988 0 35.66885864522917 139.73928569242253 0 35.66890717232919 139.73921284199216 0 35.668819940853716 139.73912501787436 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668819940853716 139.73912501787436 12.323 35.66890717232919 139.73921284199216 12.323 35.66885864522917 139.73928569242253 12.323 35.668741103680695 139.73916719588988 12.323 35.668779277460516 139.73911037441937 12.323 35.66880958751374 139.73914093634065 12.323 35.668819940853716 139.73912501787436 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668819940853716 139.73912501787436 12.323 35.66880958751374 139.73914093634065 12.323 35.66880958751374 139.73914093634065 27.62 35.668819940853716 139.73912501787436 27.62 35.668819940853716 139.73912501787436 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880958751374 139.73914093634065 12.323 35.668779277460516 139.73911037441937 12.323 35.668779277460516 139.73911037441937 27.62 35.66880958751374 139.73914093634065 27.62 35.66880958751374 139.73914093634065 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668779277460516 139.73911037441937 12.323 35.668741103680695 139.73916719588988 12.323 35.668741103680695 139.73916719588988 27.62 35.668779277460516 139.73911037441937 27.62 35.668779277460516 139.73911037441937 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668741103680695 139.73916719588988 12.323 35.66885864522917 139.73928569242253 12.323 35.66885864522917 139.73928569242253 27.62 35.668741103680695 139.73916719588988 27.62 35.668741103680695 139.73916719588988 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66885864522917 139.73928569242253 12.323 35.66890717232919 139.73921284199216 12.323 35.66890717232919 139.73921284199216 27.62 35.66885864522917 139.73928569242253 27.62 35.66885864522917 139.73928569242253 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66890717232919 139.73921284199216 12.323 35.668819940853716 139.73912501787436 12.323 35.668819940853716 139.73912501787436 27.62 35.66890717232919 139.73921284199216 27.62 35.66890717232919 139.73921284199216 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668819940853716 139.73912501787436 27.62 35.66880958751374 139.73914093634065 27.62 35.668779277460516 139.73911037441937 27.62 35.668741103680695 139.73916719588988 27.62 35.66885864522917 139.73928569242253 27.62 35.66890717232919 139.73921284199216 27.62 35.668819940853716 139.73912501787436 27.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7c1cca80-6c3e-4a3a-9a05-14139381cd4d"/>
							<gml:surfaceMember xlink:href="#poly-4c9310b0-0225-40ba-92f8-4ede31a52e82"/>
							<gml:surfaceMember xlink:href="#poly-a7b40fc9-eaf8-4807-af5b-e7a369bac7dd"/>
							<gml:surfaceMember xlink:href="#poly-4fb44ebe-eef9-4b9c-9cbe-9fa757b5695d"/>
							<gml:surfaceMember xlink:href="#poly-63c70cea-27ee-418c-b86a-790d1ef0cd90"/>
							<gml:surfaceMember xlink:href="#poly-ae19967c-07a8-4cb5-914a-74f4b9c067d2"/>
							<gml:surfaceMember xlink:href="#poly-30b7f474-3a4c-4aaf-b5c8-36e7579fdd6a"/>
							<gml:surfaceMember xlink:href="#poly-9eba4aae-b31e-4ac1-b606-d38d479b510a"/>
							<gml:surfaceMember xlink:href="#poly-2452a26f-cbcd-4d23-85d1-28341cc4a98e"/>
							<gml:surfaceMember xlink:href="#poly-2dd2e06b-1f68-4c4a-bd25-aa9bd68cbd00"/>
							<gml:surfaceMember xlink:href="#poly-9512e97b-7825-4253-936d-2fa1bf1b2be5"/>
							<gml:surfaceMember xlink:href="#poly-cd426616-8c46-408d-b8ee-34685b43ca83"/>
							<gml:surfaceMember xlink:href="#poly-0924c353-28e5-4d52-950f-f9add83baa52"/>
							<gml:surfaceMember xlink:href="#poly-c1283f6b-4b98-4ec4-975e-559c5663ab39"/>
							<gml:surfaceMember xlink:href="#poly-160b71a7-6044-4d8e-add9-9520340abb85"/>
							<gml:surfaceMember xlink:href="#poly-80d7735c-1af2-4530-9ca4-d398643dfe91"/>
							<gml:surfaceMember xlink:href="#poly-76ff46b2-113e-4247-ac03-4c31fe2a05cb"/>
							<gml:surfaceMember xlink:href="#poly-715287ec-111c-4550-bc3d-98f00ee1b088"/>
							<gml:surfaceMember xlink:href="#poly-dabc7615-3150-4755-8e87-07c2b7b2aea8"/>
							<gml:surfaceMember xlink:href="#poly-4040f39f-aea8-4b68-ad09-bc35c5d3a469"/>
							<gml:surfaceMember xlink:href="#poly-de8a56e8-7990-4691-a5ee-0fd9520085f9"/>
							<gml:surfaceMember xlink:href="#poly-8bc86699-6cfa-42f1-8f59-3afe1a39b1de"/>
							<gml:surfaceMember xlink:href="#poly-17f532a9-68f9-453c-b0bf-16ae3bbb3e8f"/>
							<gml:surfaceMember xlink:href="#poly-28d4e04d-984e-4fa9-a1ed-dd1eaf09943b"/>
							<gml:surfaceMember xlink:href="#poly-62bf0233-9e16-4d01-a934-096b21e150b8"/>
							<gml:surfaceMember xlink:href="#poly-77b2a90e-12df-41e8-b60a-054f4b13159d"/>
							<gml:surfaceMember xlink:href="#poly-d6f3e24a-9082-4ed5-9edb-7c23044d201b"/>
							<gml:surfaceMember xlink:href="#poly-64ba0083-1748-4d27-b344-970c095ad057"/>
							<gml:surfaceMember xlink:href="#poly-344bf3ed-f90e-4011-b5b7-4b67a7c0f35d"/>
							<gml:surfaceMember xlink:href="#poly-2e5adaae-5af6-425f-b10a-ffb1841ff6bd"/>
							<gml:surfaceMember xlink:href="#poly-f105f4a7-7597-49bb-b429-b1f3db05df0c"/>
							<gml:surfaceMember xlink:href="#poly-07e77fd8-1dd1-467b-ad82-fec29018e648"/>
							<gml:surfaceMember xlink:href="#poly-27b92f78-a345-4c6e-a153-25ad5f88cd8f"/>
							<gml:surfaceMember xlink:href="#poly-6c11df6b-e7dd-4242-8fb3-6e307872f37e"/>
							<gml:surfaceMember xlink:href="#poly-8df30414-410e-4fdc-bb6b-2db679308c79"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_10a8f921-82e6-485e-84be-37f320f94457_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60f0a2d7-2a31-4deb-80b4-6d16a4a6bd7c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882444609792 139.73914598902044 30.951 35.66884170321924 139.73916369765507 30.952 35.66884159517549 139.73916385242663 30.952 35.668824771153616 139.73914670663154 30.951 35.668819170992904 139.73915486519047 30.951 35.66881871092145 139.73915439075097 30.951 35.66882444609792 139.73914598902044 30.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c47d70d-60b4-4dba-892a-8de1e87a94cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884159517549 139.73916385242663 30.952 35.66883603118082 139.73917215454222 30.954 35.668819170992904 139.73915486519047 30.951 35.668824771153616 139.73914670663154 30.951 35.66884159517549 139.73916385242663 30.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43ecd811-1899-4fcf-8158-491ac42c71a0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668829225053464 139.7391827115085 30.951 35.668811877771745 139.7391649698403 30.951 35.6688176039266 139.7391565570758 30.951 35.66883472569368 139.7391740780874 30.952 35.66883495121817 139.73917430978952 30.952 35.668829225053464 139.7391827115085 30.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e1066f2-0e0a-40bb-9cf9-e2c5084a8ca6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e1066f2-0e0a-40bb-9cf9-e2c5084a8ca6_0">
											<gml:posList>35.66883472569368 139.7391740780874 30.952 35.6688176039266 139.7391565570758 30.951 35.6688176039266 139.7391565570758 31.486 35.668834734716036 139.7391740891228 33.338 35.66883472569368 139.7391740780874 30.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9354cf3e-0663-4707-8ec3-dfb7f9e7847e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9354cf3e-0663-4707-8ec3-dfb7f9e7847e_0">
											<gml:posList>35.66881871092145 139.73915439075097 31.486 35.66882444609792 139.73914598902044 31.486 35.66882444609792 139.73914598902044 30.951 35.66881871092145 139.73915439075097 30.951 35.66881871092145 139.73915439075097 31.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed95cd03-d153-43ec-8b8d-14f24aae25aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed95cd03-d153-43ec-8b8d-14f24aae25aa_0">
											<gml:posList>35.66884170321924 139.73916369765507 30.952 35.66882444609792 139.73914598902044 30.951 35.66882444609792 139.73914598902044 31.486 35.66884170321924 139.73916369765507 34.027 35.66884170321924 139.73916369765507 30.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6726b5a5-44a7-44d9-b748-45527d9bd08a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6726b5a5-44a7-44d9-b748-45527d9bd08a_0">
											<gml:posList>35.66884170321924 139.73916369765507 34.027 35.66882444609792 139.73914598902044 31.486 35.66881871092145 139.73915439075097 31.486 35.66883603118082 139.73917215454222 34.016 35.66884170321924 139.73916369765507 34.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cf28021-ea30-4711-9fb0-f059eb11d4de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cf28021-ea30-4711-9fb0-f059eb11d4de_0">
											<gml:posList>35.668811877771745 139.7391649698403 30.951 35.668811877771745 139.7391649698403 31.486 35.6688176039266 139.7391565570758 31.486 35.6688176039266 139.7391565570758 30.951 35.668811877771745 139.7391649698403 30.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a7fb9d1-c130-494c-9a5a-3402844bebe8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a7fb9d1-c130-494c-9a5a-3402844bebe8_0">
											<gml:posList>35.66881871092145 139.73915439075097 31.486 35.66881871092145 139.73915439075097 30.951 35.668819170992904 139.73915486519047 30.951 35.66883603118082 139.73917215454222 30.954 35.66883603118082 139.73917215454222 34.016 35.66881871092145 139.73915439075097 31.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba6386dc-8b6c-4b61-9bdf-c25adbfc8360">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba6386dc-8b6c-4b61-9bdf-c25adbfc8360_0">
											<gml:posList>35.66883603118082 139.73917215454222 30.954 35.66884159517549 139.73916385242663 30.952 35.66884170321924 139.73916369765507 30.952 35.66884170321924 139.73916369765507 34.027 35.66883603118082 139.73917215454222 34.016 35.66883603118082 139.73917215454222 30.954</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ef91f23-dba9-4bf4-b188-91f7c405fe83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ef91f23-dba9-4bf4-b188-91f7c405fe83_0">
											<gml:posList>35.668834734716036 139.7391740891228 33.338 35.6688176039266 139.7391565570758 31.486 35.668811877771745 139.7391649698403 31.486 35.668829225053464 139.7391827115085 33.361 35.66883495121817 139.73917430978952 33.361 35.668834734716036 139.7391740891228 33.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3acc51c5-68f4-4582-bc2a-51d9741eff36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3acc51c5-68f4-4582-bc2a-51d9741eff36_0">
											<gml:posList>35.668811877771745 139.7391649698403 31.486 35.668811877771745 139.7391649698403 30.951 35.668829225053464 139.7391827115085 30.951 35.668829225053464 139.7391827115085 33.361 35.668811877771745 139.7391649698403 31.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53c7e162-7c36-4cf1-b3d5-156408973470">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53c7e162-7c36-4cf1-b3d5-156408973470_0">
											<gml:posList>35.66883495121817 139.73917430978952 30.952 35.66883472569368 139.7391740780874 30.952 35.668834734716036 139.7391740891228 33.338 35.66883495121817 139.73917430978952 33.361 35.66883495121817 139.73917430978952 30.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6896dc24-bc8e-4778-a77b-f68aa8849baf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6896dc24-bc8e-4778-a77b-f68aa8849baf_0">
											<gml:posList>35.66883495121817 139.73917430978952 30.952 35.66883495121817 139.73917430978952 33.361 35.668829225053464 139.7391827115085 33.361 35.668829225053464 139.7391827115085 30.951 35.66883495121817 139.73917430978952 30.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7c1cca80-6c3e-4a3a-9a05-14139381cd4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c1cca80-6c3e-4a3a-9a05-14139381cd4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c1cca80-6c3e-4a3a-9a05-14139381cd4d">
											<gml:posList>35.66874110368067 139.73916719588988 12.323 35.668779277460494 139.73911037441937 12.323 35.66880958751372 139.73914093634065 12.323 35.668819940853716 139.73912501787436 12.323 35.66890717232922 139.73921284199216 12.323 35.66885864522915 139.73928569242253 12.323 35.66874110368067 139.73916719588988 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c9310b0-0225-40ba-92f8-4ede31a52e82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c9310b0-0225-40ba-92f8-4ede31a52e82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c9310b0-0225-40ba-92f8-4ede31a52e82">
											<gml:posList>35.66882316260766 139.73912994062502 31.079 35.66884841061727 139.73915368205783 29.184 35.66882302597592 139.73912811818815 31.08 35.66882316260766 139.73912994062502 31.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7b40fc9-eaf8-4807-af5b-e7a369bac7dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7b40fc9-eaf8-4807-af5b-e7a369bac7dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7b40fc9-eaf8-4807-af5b-e7a369bac7dd">
											<gml:posList>35.66877387640946 139.73920024028544 31.08 35.66881237495796 139.73914374980717 31.08 35.668779277460494 139.73911037441937 22.265 35.66874110368067 139.73916719588988 22.265 35.66877387640946 139.73920024028544 31.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4fb44ebe-eef9-4b9c-9cbe-9fa757b5695d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fb44ebe-eef9-4b9c-9cbe-9fa757b5695d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fb44ebe-eef9-4b9c-9cbe-9fa757b5695d">
											<gml:posList>35.66881237495796 139.73914374980717 31.08 35.66877387640946 139.73920024028544 31.08 35.66877537254962 139.7392000617924 31.08 35.668813186841206 139.73914457730672 31.079 35.66881237495796 139.73914374980717 31.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63c70cea-27ee-418c-b86a-790d1ef0cd90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63c70cea-27ee-418c-b86a-790d1ef0cd90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63c70cea-27ee-418c-b86a-790d1ef0cd90">
											<gml:posList>35.66877387640946 139.73920024028544 31.08 35.66881974738058 139.7392464804052 31.078 35.66881960172826 139.73924464693275 31.078 35.66877537254962 139.7392000617924 31.08 35.66877387640946 139.73920024028544 31.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae19967c-07a8-4cb5-914a-74f4b9c067d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae19967c-07a8-4cb5-914a-74f4b9c067d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae19967c-07a8-4cb5-914a-74f4b9c067d2">
											<gml:posList>35.66877537254962 139.7392000617924 30.952 35.66881960172826 139.73924464693275 30.95 35.668823082057 139.73922289318662 30.951 35.66880838722527 139.73920823024318 30.951 35.66882190094578 139.73918790070346 30.951 35.66883659578859 139.73920257469166 30.951 35.66885378671297 139.73919326478293 30.952 35.668834734716036 139.7391740891228 30.952 35.66884172122078 139.7391636644958 30.952 35.66881724737383 139.73913861871915 30.951 35.668813186841206 139.73914457730672 30.951 35.66877537254962 139.7392000617924 30.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-30b7f474-3a4c-4aaf-b5c8-36e7579fdd6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30b7f474-3a4c-4aaf-b5c8-36e7579fdd6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30b7f474-3a4c-4aaf-b5c8-36e7579fdd6a">
											<gml:posList>35.66882302597592 139.73912811818815 30.198 35.668819940853716 139.73912501787436 30.198 35.66880958751372 139.73914093634065 30.198 35.66881237495796 139.73914374980717 30.198 35.66882302597592 139.73912811818815 30.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9eba4aae-b31e-4ac1-b606-d38d479b510a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9eba4aae-b31e-4ac1-b606-d38d479b510a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9eba4aae-b31e-4ac1-b606-d38d479b510a">
											<gml:posList>35.66882302597592 139.73912811818815 31.08 35.66881237495796 139.73914374980717 31.08 35.668813186841206 139.73914457730672 31.079 35.66882316260766 139.73912994062502 31.079 35.66882302597592 139.73912811818815 31.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2452a26f-cbcd-4d23-85d1-28341cc4a98e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2452a26f-cbcd-4d23-85d1-28341cc4a98e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2452a26f-cbcd-4d23-85d1-28341cc4a98e">
											<gml:posList>35.66882190094578 139.73918790070346 33.366 35.66880838722527 139.73920823024318 33.366 35.668823082057 139.73922289318662 33.366 35.66883659578859 139.73920257469166 33.366 35.66882190094578 139.73918790070346 33.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2dd2e06b-1f68-4c4a-bd25-aa9bd68cbd00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dd2e06b-1f68-4c4a-bd25-aa9bd68cbd00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dd2e06b-1f68-4c4a-bd25-aa9bd68cbd00">
											<gml:posList>35.668847744387826 139.73915468803074 29.097 35.66882316260766 139.73912994062502 30.952 35.66881724737383 139.73913861871915 30.951 35.66884172122078 139.7391636644958 29.097 35.668847744387826 139.73915468803074 29.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9512e97b-7825-4253-936d-2fa1bf1b2be5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9512e97b-7825-4253-936d-2fa1bf1b2be5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9512e97b-7825-4253-936d-2fa1bf1b2be5">
											<gml:posList>35.66882316260766 139.73912994062502 31.079 35.668847744387826 139.73915468803074 29.184 35.66884841061727 139.73915368205783 29.184 35.66882316260766 139.73912994062502 31.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd426616-8c46-408d-b8ee-34685b43ca83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd426616-8c46-408d-b8ee-34685b43ca83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd426616-8c46-408d-b8ee-34685b43ca83">
											<gml:posList>35.66881960172826 139.73924464693275 30.95 35.66885378671297 139.73919326478293 30.952 35.66883659578859 139.73920257469166 30.951 35.668823082057 139.73922289318662 30.951 35.66881960172826 139.73924464693275 30.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0924c353-28e5-4d52-950f-f9add83baa52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0924c353-28e5-4d52-950f-f9add83baa52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0924c353-28e5-4d52-950f-f9add83baa52">
											<gml:posList>35.66881974738058 139.7392464804052 31.078 35.6688546076096 139.7391940922728 31.08 35.66885378671297 139.73919326478293 31.08 35.66881960172826 139.73924464693275 31.078 35.66881974738058 139.7392464804052 31.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1283f6b-4b98-4ec4-975e-559c5663ab39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1283f6b-4b98-4ec4-975e-559c5663ab39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1283f6b-4b98-4ec4-975e-559c5663ab39">
											<gml:posList>35.668834734716036 139.7391740891228 34.669 35.66885998402085 139.73919949852498 34.669 35.66887365993497 139.73917910250393 34.669 35.66884841061727 139.73915368205783 34.669 35.668834734716036 139.7391740891228 34.669</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-160b71a7-6044-4d8e-add9-9520340abb85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-160b71a7-6044-4d8e-add9-9520340abb85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-160b71a7-6044-4d8e-add9-9520340abb85">
											<gml:posList>35.668858654242875 139.73928569241195 22.265 35.66890716330685 139.7392128309567 22.264 35.6688736509126 139.7391790914685 29.852 35.66886001108793 139.73919953163133 29.856 35.6688546076096 139.7391940922728 31.08 35.66881974738058 139.7392464804052 31.078 35.668858654242875 139.73928569241195 22.265</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80d7735c-1af2-4530-9ca4-d398643dfe91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80d7735c-1af2-4530-9ca4-d398643dfe91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80d7735c-1af2-4530-9ca4-d398643dfe91">
											<gml:posList>35.66880958751372 139.73914093634065 12.323 35.668779277460494 139.73911037441937 12.323 35.668779277460494 139.73911037441937 22.265 35.66881237495796 139.73914374980717 31.08 35.66881237495796 139.73914374980717 30.198 35.66880958751372 139.73914093634065 30.198 35.66880958751372 139.73914093634065 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76ff46b2-113e-4247-ac03-4c31fe2a05cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76ff46b2-113e-4247-ac03-4c31fe2a05cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76ff46b2-113e-4247-ac03-4c31fe2a05cb">
											<gml:posList>35.668819940853716 139.73912501787436 12.323 35.66880958751372 139.73914093634065 12.323 35.66880958751372 139.73914093634065 30.198 35.668819940853716 139.73912501787436 30.198 35.668819940853716 139.73912501787436 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-715287ec-111c-4550-bc3d-98f00ee1b088">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-715287ec-111c-4550-bc3d-98f00ee1b088">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-715287ec-111c-4550-bc3d-98f00ee1b088">
											<gml:posList>35.66882302597592 139.73912811818815 30.198 35.66881237495796 139.73914374980717 30.198 35.66881237495796 139.73914374980717 31.08 35.66882302597592 139.73912811818815 31.08 35.66882302597592 139.73912811818815 30.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dabc7615-3150-4755-8e87-07c2b7b2aea8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dabc7615-3150-4755-8e87-07c2b7b2aea8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dabc7615-3150-4755-8e87-07c2b7b2aea8">
											<gml:posList>35.66882316260766 139.73912994062502 31.079 35.668813186841206 139.73914457730672 31.079 35.668813186841206 139.73914457730672 30.951 35.66881724737383 139.73913861871915 30.951 35.66882316260766 139.73912994062502 30.952 35.66882316260766 139.73912994062502 31.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4040f39f-aea8-4b68-ad09-bc35c5d3a469">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4040f39f-aea8-4b68-ad09-bc35c5d3a469">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4040f39f-aea8-4b68-ad09-bc35c5d3a469">
											<gml:posList>35.668779277460494 139.73911037441937 12.323 35.66874110368067 139.73916719588988 12.323 35.66874110368067 139.73916719588988 22.265 35.668779277460494 139.73911037441937 22.265 35.668779277460494 139.73911037441937 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de8a56e8-7990-4691-a5ee-0fd9520085f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de8a56e8-7990-4691-a5ee-0fd9520085f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de8a56e8-7990-4691-a5ee-0fd9520085f9">
											<gml:posList>35.668847744387826 139.73915468803074 29.184 35.66882316260766 139.73912994062502 31.079 35.66882316260766 139.73912994062502 30.952 35.668847744387826 139.73915468803074 29.097 35.668847744387826 139.73915468803074 29.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bc86699-6cfa-42f1-8f59-3afe1a39b1de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bc86699-6cfa-42f1-8f59-3afe1a39b1de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bc86699-6cfa-42f1-8f59-3afe1a39b1de">
											<gml:posList>35.66881724737383 139.73913861871915 30.951 35.66884172122078 139.7391636644958 30.952 35.66884172122078 139.7391636644958 29.097 35.66881724737383 139.73913861871915 30.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17f532a9-68f9-453c-b0bf-16ae3bbb3e8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17f532a9-68f9-453c-b0bf-16ae3bbb3e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17f532a9-68f9-453c-b0bf-16ae3bbb3e8f">
											<gml:posList>35.668834734716036 139.7391740891228 34.669 35.66884841061727 139.73915368205783 34.669 35.66884841061727 139.73915368205783 29.184 35.668847744387826 139.73915468803074 29.184 35.668847744387826 139.73915468803074 29.097 35.66884172122078 139.7391636644958 29.097 35.66884172122078 139.7391636644958 30.952 35.668834734716036 139.7391740891228 30.952 35.668834734716036 139.7391740891228 34.669</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28d4e04d-984e-4fa9-a1ed-dd1eaf09943b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28d4e04d-984e-4fa9-a1ed-dd1eaf09943b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28d4e04d-984e-4fa9-a1ed-dd1eaf09943b">
											<gml:posList>35.6688736509126 139.7391790914685 29.852 35.66890716330685 139.7392128309567 22.264 35.66890717232922 139.73921284199216 12.323 35.668819940853716 139.73912501787436 12.323 35.668819940853716 139.73912501787436 30.198 35.66882302597592 139.73912811818815 30.198 35.66882302597592 139.73912811818815 31.08 35.66884841061727 139.73915368205783 29.184 35.66884841061727 139.73915368205783 34.669 35.66887365993497 139.73917910250393 34.669 35.6688736509126 139.7391790914685 29.852</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62bf0233-9e16-4d01-a934-096b21e150b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62bf0233-9e16-4d01-a934-096b21e150b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62bf0233-9e16-4d01-a934-096b21e150b8">
											<gml:posList>35.668813186841206 139.73914457730672 31.079 35.66877537254962 139.7392000617924 31.08 35.66877537254962 139.7392000617924 30.952 35.668813186841206 139.73914457730672 30.951 35.668813186841206 139.73914457730672 31.079</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77b2a90e-12df-41e8-b60a-054f4b13159d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77b2a90e-12df-41e8-b60a-054f4b13159d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77b2a90e-12df-41e8-b60a-054f4b13159d">
											<gml:posList>35.6688546076096 139.7391940922728 31.08 35.66886001108793 139.73919953163133 29.856 35.66885998402085 139.73919949852498 34.669 35.668834734716036 139.7391740891228 34.669 35.668834734716036 139.7391740891228 30.952 35.66885378671297 139.73919326478293 30.952 35.66885378671297 139.73919326478293 31.08 35.6688546076096 139.7391940922728 31.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6f3e24a-9082-4ed5-9edb-7c23044d201b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6f3e24a-9082-4ed5-9edb-7c23044d201b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6f3e24a-9082-4ed5-9edb-7c23044d201b">
											<gml:posList>35.66886001108793 139.73919953163133 29.856 35.6688736509126 139.7391790914685 29.852 35.66887365993497 139.73917910250393 34.669 35.66885998402085 139.73919949852498 34.669 35.66886001108793 139.73919953163133 29.856</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64ba0083-1748-4d27-b344-970c095ad057">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64ba0083-1748-4d27-b344-970c095ad057">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64ba0083-1748-4d27-b344-970c095ad057">
											<gml:posList>35.66883659578859 139.73920257469166 30.951 35.66882190094578 139.73918790070346 30.951 35.66882190094578 139.73918790070346 33.366 35.66883659578859 139.73920257469166 33.366 35.66883659578859 139.73920257469166 30.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-344bf3ed-f90e-4011-b5b7-4b67a7c0f35d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-344bf3ed-f90e-4011-b5b7-4b67a7c0f35d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-344bf3ed-f90e-4011-b5b7-4b67a7c0f35d">
											<gml:posList>35.66882190094578 139.73918790070346 30.951 35.66880838722527 139.73920823024318 30.951 35.66880838722527 139.73920823024318 33.366 35.66882190094578 139.73918790070346 33.366 35.66882190094578 139.73918790070346 30.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e5adaae-5af6-425f-b10a-ffb1841ff6bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e5adaae-5af6-425f-b10a-ffb1841ff6bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e5adaae-5af6-425f-b10a-ffb1841ff6bd">
											<gml:posList>35.668823082057 139.73922289318662 30.951 35.66883659578859 139.73920257469166 30.951 35.66883659578859 139.73920257469166 33.366 35.668823082057 139.73922289318662 33.366 35.668823082057 139.73922289318662 30.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f105f4a7-7597-49bb-b429-b1f3db05df0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f105f4a7-7597-49bb-b429-b1f3db05df0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f105f4a7-7597-49bb-b429-b1f3db05df0c">
											<gml:posList>35.66880838722527 139.73920823024318 30.951 35.668823082057 139.73922289318662 30.951 35.668823082057 139.73922289318662 33.366 35.66880838722527 139.73920823024318 33.366 35.66880838722527 139.73920823024318 30.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07e77fd8-1dd1-467b-ad82-fec29018e648">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07e77fd8-1dd1-467b-ad82-fec29018e648">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07e77fd8-1dd1-467b-ad82-fec29018e648">
											<gml:posList>35.66881960172826 139.73924464693275 31.078 35.66885378671297 139.73919326478293 31.08 35.66885378671297 139.73919326478293 30.952 35.66881960172826 139.73924464693275 30.95 35.66881960172826 139.73924464693275 31.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-27b92f78-a345-4c6e-a153-25ad5f88cd8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27b92f78-a345-4c6e-a153-25ad5f88cd8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27b92f78-a345-4c6e-a153-25ad5f88cd8f">
											<gml:posList>35.66877537254962 139.7392000617924 31.08 35.66881960172826 139.73924464693275 31.078 35.66881960172826 139.73924464693275 30.95 35.66877537254962 139.7392000617924 30.952 35.66877537254962 139.7392000617924 31.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c11df6b-e7dd-4242-8fb3-6e307872f37e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c11df6b-e7dd-4242-8fb3-6e307872f37e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c11df6b-e7dd-4242-8fb3-6e307872f37e">
											<gml:posList>35.66874110368067 139.73916719588988 12.323 35.66885864522915 139.73928569242253 12.323 35.668858654242875 139.73928569241195 22.265 35.66881974738058 139.7392464804052 31.078 35.66877387640946 139.73920024028544 31.08 35.66874110368067 139.73916719588988 22.265 35.66874110368067 139.73916719588988 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8df30414-410e-4fdc-bb6b-2db679308c79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8df30414-410e-4fdc-bb6b-2db679308c79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8df30414-410e-4fdc-bb6b-2db679308c79">
											<gml:posList>35.66885864522915 139.73928569242253 12.323 35.66890717232922 139.73921284199216 12.323 35.66890716330685 139.7392128309567 22.264 35.668858654242875 139.73928569241195 22.265 35.66885864522915 139.73928569242253 12.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1836</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">135.52285</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>