<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_10b0a4c8-60b4-41e8-bd49-1c2db08197ea">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">32.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67242076111956 139.74670777196695 0 35.67220375508872 139.74702084364193 0 35.67234248961063 139.74716518289964 0 35.67255940595363 139.74685222163475 0 35.67242076111956 139.74670777196695 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242076111956 139.74670777196695 10.75 35.67255940595363 139.74685222163475 10.75 35.67234248961063 139.74716518289964 10.75 35.67220375508872 139.74702084364193 10.75 35.67242076111956 139.74670777196695 10.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242076111956 139.74670777196695 10.75 35.67220375508872 139.74702084364193 10.75 35.67220375508872 139.74702084364193 43.38 35.67242076111956 139.74670777196695 43.38 35.67242076111956 139.74670777196695 10.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67220375508872 139.74702084364193 10.75 35.67234248961063 139.74716518289964 10.75 35.67234248961063 139.74716518289964 43.38 35.67220375508872 139.74702084364193 43.38 35.67220375508872 139.74702084364193 10.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234248961063 139.74716518289964 10.75 35.67255940595363 139.74685222163475 10.75 35.67255940595363 139.74685222163475 43.38 35.67234248961063 139.74716518289964 43.38 35.67234248961063 139.74716518289964 10.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67255940595363 139.74685222163475 10.75 35.67242076111956 139.74670777196695 10.75 35.67242076111956 139.74670777196695 43.38 35.67255940595363 139.74685222163475 43.38 35.67255940595363 139.74685222163475 10.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242076111956 139.74670777196695 43.38 35.67220375508872 139.74702084364193 43.38 35.67234248961063 139.74716518289964 43.38 35.67255940595363 139.74685222163475 43.38 35.67242076111956 139.74670777196695 43.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7c33e709-781f-4fc6-910b-036acdaa6a0d"/>
							<gml:surfaceMember xlink:href="#poly-26bdc4be-15dc-4698-aa35-a6755b92b198"/>
							<gml:surfaceMember xlink:href="#poly-9d37b6cc-b428-45f9-b861-491c21a4f82a"/>
							<gml:surfaceMember xlink:href="#poly-dfebf817-1146-41cb-9340-bae701221a7b"/>
							<gml:surfaceMember xlink:href="#poly-030a009b-90b9-4bcc-8986-e9bf1ace8ef6"/>
							<gml:surfaceMember xlink:href="#poly-ba445633-ff99-444f-8d0d-6293ba826780"/>
							<gml:surfaceMember xlink:href="#poly-ad917049-5656-42ab-9caf-3c5aaf92f9b0"/>
							<gml:surfaceMember xlink:href="#poly-49a7de47-fd14-47ab-ba91-70dac355bcc0"/>
							<gml:surfaceMember xlink:href="#poly-535faf38-4ef1-4ce6-b3f7-9e2364ff6ca8"/>
							<gml:surfaceMember xlink:href="#poly-df9d11b8-d92f-44a6-8224-cb7b29fe1307"/>
							<gml:surfaceMember xlink:href="#poly-9bbb8cac-2ab1-409c-9065-49e110f6c5cf"/>
							<gml:surfaceMember xlink:href="#poly-72a307fe-8e07-4f28-8f6f-d1b82108940d"/>
							<gml:surfaceMember xlink:href="#poly-cfe6ca78-05d2-4bd0-ac59-ade59c6a323e"/>
							<gml:surfaceMember xlink:href="#poly-beb51be2-be58-4d94-89c0-5d6f1ea1540f"/>
							<gml:surfaceMember xlink:href="#poly-e5f0d17f-f58c-46ca-a9a5-248653ac3d5c"/>
							<gml:surfaceMember xlink:href="#poly-6574fc4c-8c7c-4e03-81be-c3fb981d6ba3"/>
							<gml:surfaceMember xlink:href="#poly-bf318f6d-fb4d-4b47-971c-07b00948e174"/>
							<gml:surfaceMember xlink:href="#poly-84e4e3f4-3985-4084-ba09-91029d55512e"/>
							<gml:surfaceMember xlink:href="#poly-6975a4a8-65ab-420f-8682-1a22c4d7759e"/>
							<gml:surfaceMember xlink:href="#poly-8f663e1f-d503-445e-b90f-6a9e556f285c"/>
							<gml:surfaceMember xlink:href="#poly-3b0c5999-4599-48f4-a34f-4ae24f76d261"/>
							<gml:surfaceMember xlink:href="#poly-a568f3ff-2952-4ce2-8adf-bf40acfaf239"/>
							<gml:surfaceMember xlink:href="#poly-8fcfffcd-7641-48a2-bc35-6956b5a218f1"/>
							<gml:surfaceMember xlink:href="#poly-5fb4d5bc-3bc1-49b4-a2d5-39473a2176bf"/>
							<gml:surfaceMember xlink:href="#poly-2de5f8cc-51c3-4ee3-9295-27b4b7dfab47"/>
							<gml:surfaceMember xlink:href="#poly-404b73b8-a86c-4a2e-8a0d-024c809f203f"/>
							<gml:surfaceMember xlink:href="#poly-f5fdcfaf-31cb-40bd-9b6b-e08ea9d3655a"/>
							<gml:surfaceMember xlink:href="#poly-7c1e5f86-0a7c-4ade-b0de-c3cb11c8d46d"/>
							<gml:surfaceMember xlink:href="#poly-1787e0f8-4a34-4f46-927e-ac7f7574b1ec"/>
							<gml:surfaceMember xlink:href="#poly-0795349f-ed43-4d2b-83be-a84d1ade9094"/>
							<gml:surfaceMember xlink:href="#poly-a2d5c620-c67e-4721-839b-211f48fc082e"/>
							<gml:surfaceMember xlink:href="#poly-fb036596-6459-4dcd-8844-b8c2b6c81910"/>
							<gml:surfaceMember xlink:href="#poly-88368b3e-14c3-4329-a92c-ecddaeb61ae9"/>
							<gml:surfaceMember xlink:href="#poly-c63bff7d-2a1c-4817-8962-52285225c1ea"/>
							<gml:surfaceMember xlink:href="#poly-aa306b82-7549-4894-aeaf-3871f0d2c40a"/>
							<gml:surfaceMember xlink:href="#poly-37391ce8-a31b-4fa1-9b0d-9ff2e1236b7a"/>
							<gml:surfaceMember xlink:href="#poly-74fe7d5c-b265-400a-9780-f580245a2226"/>
							<gml:surfaceMember xlink:href="#poly-e69b1335-8e2e-42f0-9020-f891611fd2cd"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_10b0a4c8-60b4-41e8-bd49-1c2db08197ea_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6955dbd2-0704-4366-a002-4e1518a8c7d4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67227893199599 139.74704936215173 43.611 35.6722460349169 139.7470158603307 43.611 35.672306950326764 139.74692877021755 43.611 35.6723528276746 139.746975502836 43.611 35.672374284686185 139.74694385349412 43.611 35.672441107396104 139.74701219273592 43.611 35.6724363080478 139.7470191240861 43.611 35.6723761152688 139.746957527132 43.611 35.672353298615434 139.74699117735753 43.611 35.67230591488849 139.74694292193251 43.611 35.67225538329432 139.74701745201088 43.611 35.67228211048332 139.74704467500555 43.611 35.67227893199599 139.74704936215173 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57482524-d896-4548-8e81-6a34cae4801f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672333420293484 139.74701206565942 43.611 35.672295759205866 139.74697194104795 43.611 35.67230154017562 139.7469637935319 43.611 35.67232031210158 139.74698381170947 43.611 35.672323454721564 139.74697938971357 43.611 35.67233199725115 139.74698849389873 43.611 35.672329151790564 139.74699250685316 43.611 35.672340283229275 139.74700435883858 43.611 35.672340877532974 139.74700351866232 43.611 35.67234328294521 139.74700177072032 43.611 35.672349375444675 139.74700068159964 43.611 35.67235607488121 139.74699122960024 43.611 35.67236201044845 139.74699755287133 43.611 35.672356247480174 139.74700566723212 43.611 35.67236700907781 139.74701713299282 43.611 35.67234583070444 139.74704771049886 43.611 35.67233594410566 139.74703717170368 43.611 35.672320428923385 139.74705876227213 43.611 35.6723181490059 139.7470595379825 43.611 35.67231461527886 139.747059055738 43.611 35.672311233597824 139.747056916351 43.611 35.672300868916345 139.74704588098018 43.611 35.6723050740811 139.74703995551667 43.611 35.672276559909385 139.74700957513474 43.611 35.672278099687695 139.74700738626552 43.611 35.67227459066525 139.74700364527325 43.611 35.67227850767401 139.74699811779456 43.611 35.672317179065644 139.7470393238819 43.611 35.67232914621939 139.74702245399826 43.611 35.672327387197605 139.74702057798214 43.611 35.672333420293484 139.74701206565942 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ca2f362-724b-47a5-8c29-594db34243d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ca2f362-724b-47a5-8c29-594db34243d2_0">
											<gml:posList>35.6723528276746 139.746975502836 43.611 35.672306950326764 139.74692877021755 43.611 35.672306950326764 139.74692877021755 43.72 35.6723528276746 139.746975502836 43.72 35.6723528276746 139.746975502836 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-009c585a-6f5c-4b04-9745-9e47ebc99206">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-009c585a-6f5c-4b04-9745-9e47ebc99206_0">
											<gml:posList>35.6723528276746 139.746975502836 43.611 35.6723528276746 139.746975502836 43.72 35.672374284686185 139.74694385349412 43.72 35.672374284686185 139.74694385349412 43.611 35.6723528276746 139.746975502836 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc2f2bb2-acaf-4f40-9ef7-a90178513319">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc2f2bb2-acaf-4f40-9ef7-a90178513319_0">
											<gml:posList>35.672353298615434 139.74699117735753 43.611 35.672353298615434 139.74699117735753 43.72 35.67230591488849 139.74694292193251 43.72 35.67230591488849 139.74694292193251 43.611 35.672353298615434 139.74699117735753 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b48e7932-fa18-4bca-bb6f-1749bfaec034">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b48e7932-fa18-4bca-bb6f-1749bfaec034_0">
											<gml:posList>35.67230154017562 139.7469637935319 43.611 35.672295759205866 139.74697194104795 43.611 35.672295759205866 139.74697194104795 45.798 35.67230154017562 139.7469637935319 45.798 35.67230154017562 139.7469637935319 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2019e7e9-dc7f-4fa5-9c96-d502fa5514a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2019e7e9-dc7f-4fa5-9c96-d502fa5514a4_0">
											<gml:posList>35.672306950326764 139.74692877021755 43.611 35.6722460349169 139.7470158603307 43.611 35.6722460349169 139.7470158603307 43.72 35.672306950326764 139.74692877021755 43.72 35.672306950326764 139.74692877021755 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3d197e4-54a8-4100-afa1-d2b4aed79c18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3d197e4-54a8-4100-afa1-d2b4aed79c18_0">
											<gml:posList>35.67230154017562 139.7469637935319 43.611 35.67230154017562 139.7469637935319 45.798 35.67232031210158 139.74698381170947 45.798 35.67232031210158 139.74698381170947 43.611 35.67230154017562 139.7469637935319 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8f042dc-0793-4e26-855a-6560b73baba2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8f042dc-0793-4e26-855a-6560b73baba2_0">
											<gml:posList>35.672353298615434 139.74699117735753 43.611 35.6723761152688 139.746957527132 43.611 35.6723761152688 139.746957527132 43.72 35.672353298615434 139.74699117735753 43.72 35.672353298615434 139.74699117735753 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad1aec18-23c2-4666-a8e1-c7ac542dc77c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad1aec18-23c2-4666-a8e1-c7ac542dc77c_0">
											<gml:posList>35.672441107396104 139.74701219273592 43.72 35.672441107396104 139.74701219273592 43.611 35.672374284686185 139.74694385349412 43.611 35.672374284686185 139.74694385349412 43.72 35.672441107396104 139.74701219273592 43.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2377c7cb-7838-4823-a2dd-588a41e520d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2377c7cb-7838-4823-a2dd-588a41e520d0_0">
											<gml:posList>35.67230591488849 139.74694292193251 43.611 35.67230591488849 139.74694292193251 43.72 35.67225538329432 139.74701745201088 43.72 35.67225538329432 139.74701745201088 43.611 35.67230591488849 139.74694292193251 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2bd86e8-c019-40fc-8133-a95834d862a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2bd86e8-c019-40fc-8133-a95834d862a3_0">
											<gml:posList>35.672323454721564 139.74697938971357 43.611 35.67232031210158 139.74698381170947 43.611 35.67232031210158 139.74698381170947 45.798 35.672323454721564 139.74697938971357 45.798 35.672323454721564 139.74697938971357 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98dc1253-96a3-4ee0-a018-3013896f3dc5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98dc1253-96a3-4ee0-a018-3013896f3dc5_0">
											<gml:posList>35.67233199725115 139.74698849389873 43.611 35.672323454721564 139.74697938971357 43.611 35.672323454721564 139.74697938971357 45.798 35.67233199725115 139.74698849389873 45.798 35.67233199725115 139.74698849389873 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4e3180a-725f-4a64-814f-0055ce9e85fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4e3180a-725f-4a64-814f-0055ce9e85fa_0">
											<gml:posList>35.6724363080478 139.7470191240861 43.72 35.6723761152688 139.746957527132 43.72 35.6723761152688 139.746957527132 43.611 35.6724363080478 139.7470191240861 43.611 35.6724363080478 139.7470191240861 43.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd48408e-8dad-438d-929e-0fedca1a71de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd48408e-8dad-438d-929e-0fedca1a71de_0">
											<gml:posList>35.67225538329432 139.74701745201088 43.72 35.67230591488849 139.74694292193251 43.72 35.672353298615434 139.74699117735753 43.72 35.6723761152688 139.746957527132 43.72 35.6724363080478 139.7470191240861 43.72 35.672441107396104 139.74701219273592 43.72 35.672374284686185 139.74694385349412 43.72 35.6723528276746 139.746975502836 43.72 35.672306950326764 139.74692877021755 43.72 35.6722460349169 139.7470158603307 43.72 35.67227893199599 139.74704936215173 43.72 35.67228211048332 139.74704467500555 43.72 35.67225538329432 139.74701745201088 43.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad513bcb-f1d1-4381-9eac-e48f8ba51a7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad513bcb-f1d1-4381-9eac-e48f8ba51a7f_0">
											<gml:posList>35.672329151790564 139.74699250685316 43.611 35.67233199725115 139.74698849389873 43.611 35.67233199725115 139.74698849389873 45.798 35.672329151790564 139.74699250685316 45.798 35.672329151790564 139.74699250685316 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a5b957f-f165-4d1e-875c-4b4b9bad22e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a5b957f-f165-4d1e-875c-4b4b9bad22e4_0">
											<gml:posList>35.672295759205866 139.74697194104795 43.611 35.672333420293484 139.74701206565942 43.611 35.672333420293484 139.74701206565942 45.798 35.672295759205866 139.74697194104795 45.798 35.672295759205866 139.74697194104795 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0706643-8f2d-4e3c-abee-8ed69b3588fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0706643-8f2d-4e3c-abee-8ed69b3588fb_0">
											<gml:posList>35.67236201044845 139.74699755287133 43.611 35.67235607488121 139.74699122960024 43.611 35.67235607488121 139.74699122960024 45.798 35.67236201044845 139.74699755287133 45.798 35.67236201044845 139.74699755287133 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6da12608-e773-4ca8-9384-c2cbb8d59092">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6da12608-e773-4ca8-9384-c2cbb8d59092_0">
											<gml:posList>35.672349375444675 139.74700068159964 43.611 35.672349375444675 139.74700068159964 45.798 35.67235607488121 139.74699122960024 45.798 35.67235607488121 139.74699122960024 43.611 35.672349375444675 139.74700068159964 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a52d6f8-455e-4bb4-8ca3-0792fdca576e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a52d6f8-455e-4bb4-8ca3-0792fdca576e_0">
											<gml:posList>35.672340283229275 139.74700435883858 43.611 35.672329151790564 139.74699250685316 43.611 35.672329151790564 139.74699250685316 45.798 35.672340283229275 139.74700435883858 45.798 35.672340283229275 139.74700435883858 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79acaf27-f3c7-4e72-85fd-c8341f2e2902">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79acaf27-f3c7-4e72-85fd-c8341f2e2902_0">
											<gml:posList>35.67227850767401 139.74699811779456 43.611 35.67227459066525 139.74700364527325 43.611 35.67227459066525 139.74700364527325 45.798 35.67227850767401 139.74699811779456 45.798 35.67227850767401 139.74699811779456 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4099e21d-1ca8-4b10-b672-f83135bd663b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4099e21d-1ca8-4b10-b672-f83135bd663b_0">
											<gml:posList>35.67234328294521 139.74700177072032 43.611 35.67234328294521 139.74700177072032 45.798 35.672349375444675 139.74700068159964 45.798 35.672349375444675 139.74700068159964 43.611 35.67234328294521 139.74700177072032 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-956ebbac-7712-4d30-baac-df1f62e96856">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-956ebbac-7712-4d30-baac-df1f62e96856_0">
											<gml:posList>35.672356247480174 139.74700566723212 43.611 35.67236201044845 139.74699755287133 43.611 35.67236201044845 139.74699755287133 45.798 35.672356247480174 139.74700566723212 45.798 35.672356247480174 139.74700566723212 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9312ddf-9a2b-4f03-b7e6-7b532ccf82a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9312ddf-9a2b-4f03-b7e6-7b532ccf82a3_0">
											<gml:posList>35.672340877532974 139.74700351866232 43.611 35.672340877532974 139.74700351866232 45.798 35.67234328294521 139.74700177072032 45.798 35.67234328294521 139.74700177072032 43.611 35.672340877532974 139.74700351866232 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8a161ff-9051-4721-b653-8c1a0b70b2fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8a161ff-9051-4721-b653-8c1a0b70b2fc_0">
											<gml:posList>35.672340877532974 139.74700351866232 43.611 35.672340283229275 139.74700435883858 43.611 35.672340283229275 139.74700435883858 45.798 35.672340877532974 139.74700351866232 45.798 35.672340877532974 139.74700351866232 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7d9fb5e-42cd-45d7-8e51-e72dd524c6c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7d9fb5e-42cd-45d7-8e51-e72dd524c6c8_0">
											<gml:posList>35.67227459066525 139.74700364527325 43.611 35.672278099687695 139.74700738626552 43.611 35.672278099687695 139.74700738626552 45.798 35.67227459066525 139.74700364527325 45.798 35.67227459066525 139.74700364527325 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efbadafe-847a-4b84-9e33-2c65cffa581a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efbadafe-847a-4b84-9e33-2c65cffa581a_0">
											<gml:posList>35.672278099687695 139.74700738626552 43.611 35.672276559909385 139.74700957513474 43.611 35.672276559909385 139.74700957513474 45.798 35.672278099687695 139.74700738626552 45.798 35.672278099687695 139.74700738626552 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76b588ef-c761-425a-b570-d07d26330141">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76b588ef-c761-425a-b570-d07d26330141_0">
											<gml:posList>35.67236700907781 139.74701713299282 43.611 35.672356247480174 139.74700566723212 43.611 35.672356247480174 139.74700566723212 45.798 35.67236700907781 139.74701713299282 45.798 35.67236700907781 139.74701713299282 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffdc0b18-f165-47b3-98b1-3460e6a9418a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffdc0b18-f165-47b3-98b1-3460e6a9418a_0">
											<gml:posList>35.67232914621939 139.74702245399826 45.798 35.672317179065644 139.7470393238819 45.798 35.67227850767401 139.74699811779456 45.798 35.67227459066525 139.74700364527325 45.798 35.672278099687695 139.74700738626552 45.798 35.672276559909385 139.74700957513474 45.798 35.6723050740811 139.74703995551667 45.798 35.672300868916345 139.74704588098018 45.798 35.672311233597824 139.747056916351 45.798 35.67231461527886 139.747059055738 45.798 35.6723181490059 139.7470595379825 45.798 35.672320428923385 139.74705876227213 45.798 35.67233594410566 139.74703717170368 45.798 35.67234583070444 139.74704771049886 45.798 35.67236700907781 139.74701713299282 45.798 35.672356247480174 139.74700566723212 45.798 35.67236201044845 139.74699755287133 45.798 35.67235607488121 139.74699122960024 45.798 35.672349375444675 139.74700068159964 45.798 35.67234328294521 139.74700177072032 45.798 35.672340877532974 139.74700351866232 45.798 35.672340283229275 139.74700435883858 45.798 35.672329151790564 139.74699250685316 45.798 35.67233199725115 139.74698849389873 45.798 35.672323454721564 139.74697938971357 45.798 35.67232031210158 139.74698381170947 45.798 35.67230154017562 139.7469637935319 45.798 35.672295759205866 139.74697194104795 45.798 35.672333420293484 139.74701206565942 45.798 35.672327387197605 139.74702057798214 45.798 35.67232914621939 139.74702245399826 45.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8bf2ba1-1589-4a99-9912-e036e3f9da61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8bf2ba1-1589-4a99-9912-e036e3f9da61_0">
											<gml:posList>35.6724363080478 139.7470191240861 43.611 35.672441107396104 139.74701219273592 43.611 35.672441107396104 139.74701219273592 43.72 35.6724363080478 139.7470191240861 43.72 35.6724363080478 139.7470191240861 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8760a3ae-f4d7-4c04-968b-367c78b2af96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8760a3ae-f4d7-4c04-968b-367c78b2af96_0">
											<gml:posList>35.672327387197605 139.74702057798214 43.611 35.672327387197605 139.74702057798214 45.798 35.672333420293484 139.74701206565942 45.798 35.672333420293484 139.74701206565942 43.611 35.672327387197605 139.74702057798214 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e7ef979-ff64-42f4-8bcd-b87ac37fbaf8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e7ef979-ff64-42f4-8bcd-b87ac37fbaf8_0">
											<gml:posList>35.672317179065644 139.7470393238819 43.611 35.67227850767401 139.74699811779456 43.611 35.67227850767401 139.74699811779456 45.798 35.672317179065644 139.7470393238819 45.798 35.672317179065644 139.7470393238819 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aad6185e-6296-49fe-b557-17500c7daa9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aad6185e-6296-49fe-b557-17500c7daa9f_0">
											<gml:posList>35.672327387197605 139.74702057798214 43.611 35.67232914621939 139.74702245399826 43.611 35.67232914621939 139.74702245399826 45.798 35.672327387197605 139.74702057798214 45.798 35.672327387197605 139.74702057798214 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-781ed124-9ce6-46cd-bc0b-89d7851f99cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-781ed124-9ce6-46cd-bc0b-89d7851f99cb_0">
											<gml:posList>35.672276559909385 139.74700957513474 43.611 35.6723050740811 139.74703995551667 43.611 35.6723050740811 139.74703995551667 45.798 35.672276559909385 139.74700957513474 45.798 35.672276559909385 139.74700957513474 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55ba8b62-6e58-4060-9b4c-8b5b08d838dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55ba8b62-6e58-4060-9b4c-8b5b08d838dd_0">
											<gml:posList>35.67232914621939 139.74702245399826 43.611 35.672317179065644 139.7470393238819 43.611 35.672317179065644 139.7470393238819 45.798 35.67232914621939 139.74702245399826 45.798 35.67232914621939 139.74702245399826 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3abde7b6-119d-48d4-b370-ba7624f33144">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3abde7b6-119d-48d4-b370-ba7624f33144_0">
											<gml:posList>35.67228211048332 139.74704467500555 43.611 35.67225538329432 139.74701745201088 43.611 35.67225538329432 139.74701745201088 43.72 35.67228211048332 139.74704467500555 43.72 35.67228211048332 139.74704467500555 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50f8c6ae-3176-4dee-b978-02705a5a4ab2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50f8c6ae-3176-4dee-b978-02705a5a4ab2_0">
											<gml:posList>35.67234583070444 139.74704771049886 43.611 35.67236700907781 139.74701713299282 43.611 35.67236700907781 139.74701713299282 45.798 35.67234583070444 139.74704771049886 45.798 35.67234583070444 139.74704771049886 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1a38c61-e781-4079-8ff1-ff3d6b30457c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1a38c61-e781-4079-8ff1-ff3d6b30457c_0">
											<gml:posList>35.67227893199599 139.74704936215173 43.611 35.67227893199599 139.74704936215173 43.72 35.6722460349169 139.7470158603307 43.72 35.6722460349169 139.7470158603307 43.611 35.67227893199599 139.74704936215173 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b66cbf4-db04-4bdd-a932-a4bbd71f3672">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b66cbf4-db04-4bdd-a932-a4bbd71f3672_0">
											<gml:posList>35.67233594410566 139.74703717170368 43.611 35.67234583070444 139.74704771049886 43.611 35.67234583070444 139.74704771049886 45.798 35.67233594410566 139.74703717170368 45.798 35.67233594410566 139.74703717170368 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-784f0506-a2ac-407c-9d52-b953ed141aaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-784f0506-a2ac-407c-9d52-b953ed141aaa_0">
											<gml:posList>35.67227893199599 139.74704936215173 43.611 35.67228211048332 139.74704467500555 43.611 35.67228211048332 139.74704467500555 43.72 35.67227893199599 139.74704936215173 43.72 35.67227893199599 139.74704936215173 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7ec8e39-2d4d-4a7f-85ad-03df186e26fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7ec8e39-2d4d-4a7f-85ad-03df186e26fc_0">
											<gml:posList>35.672300868916345 139.74704588098018 43.611 35.672300868916345 139.74704588098018 45.798 35.6723050740811 139.74703995551667 45.798 35.6723050740811 139.74703995551667 43.611 35.672300868916345 139.74704588098018 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a3e26cd-99aa-4da2-8c9f-0d8ff77c0426">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a3e26cd-99aa-4da2-8c9f-0d8ff77c0426_0">
											<gml:posList>35.672311233597824 139.747056916351 43.611 35.672311233597824 139.747056916351 45.798 35.672300868916345 139.74704588098018 45.798 35.672300868916345 139.74704588098018 43.611 35.672311233597824 139.747056916351 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5470e3fc-42a7-4822-808f-ced36ded289e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5470e3fc-42a7-4822-808f-ced36ded289e_0">
											<gml:posList>35.672311233597824 139.747056916351 43.611 35.67231461527886 139.747059055738 43.611 35.67231461527886 139.747059055738 45.798 35.672311233597824 139.747056916351 45.798 35.672311233597824 139.747056916351 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b21d040b-6092-467d-abe9-1e1dc11fcca6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b21d040b-6092-467d-abe9-1e1dc11fcca6_0">
											<gml:posList>35.6723181490059 139.7470595379825 43.611 35.6723181490059 139.7470595379825 45.798 35.67231461527886 139.747059055738 45.798 35.67231461527886 139.747059055738 43.611 35.6723181490059 139.7470595379825 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f0bac08-98ee-4055-af01-ecae5269e166">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f0bac08-98ee-4055-af01-ecae5269e166_0">
											<gml:posList>35.672320428923385 139.74705876227213 43.611 35.672320428923385 139.74705876227213 45.798 35.6723181490059 139.7470595379825 45.798 35.6723181490059 139.7470595379825 43.611 35.672320428923385 139.74705876227213 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47794c3e-b063-4060-9280-8158f9cb152f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47794c3e-b063-4060-9280-8158f9cb152f_0">
											<gml:posList>35.672320428923385 139.74705876227213 43.611 35.67233594410566 139.74703717170368 43.611 35.67233594410566 139.74703717170368 45.798 35.672320428923385 139.74705876227213 45.798 35.672320428923385 139.74705876227213 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_10b0a4c8-60b4-41e8-bd49-1c2db08197ea_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4a49b75-555a-4041-8de9-804452ca8ffb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67239303119323 139.74679037479618 43.611 35.67240572288281 139.7468034181051 43.611 35.672399320850396 139.7468127814328 43.611 35.67238662916183 139.7467997381234 43.611 35.67239303119323 139.74679037479618 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2657af8-02ec-4ae2-a8d1-bbe661701cad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67238669445483 139.74682788462798 43.611 35.67238165228625 139.7468355674109 43.611 35.67237015164147 139.74682423502836 43.611 35.67237518479562 139.74681655225558 43.611 35.67238669445483 139.74682788462798 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ee16319-38b6-4f17-b5eb-b6428c76df67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67235747226501 139.74684087374143 43.611 35.67236977555787 139.74685280177158 43.611 35.67236422026401 139.74686140196704 43.611 35.672351925985716 139.74684947392666 43.611 35.67235747226501 139.74684087374143 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22a8b7da-ebce-4feb-90e3-4a8e004cc9bb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672251939277324 139.74697866034774 43.611 35.67224553465478 139.74697186259175 43.611 35.6722712967769 139.74693540341565 43.611 35.67227770140148 139.74694220117092 43.611 35.672251939277324 139.74697866034774 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85802720-a044-4c6b-9b19-89744ff54dc1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67228325710328 139.74694672425838 43.611 35.67228903028331 139.74695284885797 43.611 35.67225719006429 139.74699791982061 43.611 35.67225141688654 139.7469917952202 43.611 35.67228325710328 139.74694672425838 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc05d990-3b85-4a78-bc31-26d4413d6aba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67232135409321 139.74702907925703 43.611 35.672288140173976 139.74699368881238 43.611 35.67230021539097 139.74697668625333 43.611 35.672333420293484 139.74701206565942 43.611 35.67232135409321 139.74702907925703 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-786d152a-991b-4307-9de3-a5dc6bf0289e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67227006756518 139.74701871759765 43.611 35.67227655089567 139.74700957514443 43.611 35.6723050740811 139.74703995551667 43.611 35.67229858173463 139.74704909798044 43.611 35.67227006756518 139.74701871759765 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43ad16db-ad9a-46b7-b01c-1b7a0c924063">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672420301753505 139.7470220355126 43.611 35.67242860926585 139.74703022310325 43.611 35.672421747903925 139.74704012819046 43.611 35.67241365687991 139.74703216129723 43.611 35.672420301753505 139.7470220355126 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c9df6a1-a010-4105-82ba-15088cbf4712">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242860926585 139.74703022310325 43.611 35.67242860926585 139.74703022310325 44.3 35.672421747903925 139.74704012819046 44.3 35.672421747903925 139.74704012819046 43.611 35.67242860926585 139.74703022310325 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee10f909-a997-4845-aaf2-1607ea7144d8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242223499321 139.74704061371398 44.3 35.672421747903925 139.74704012819046 44.3 35.67242860926585 139.74703022310325 44.3 35.672428879867496 139.74703048792895 44.3 35.67242223499321 139.74704061371398 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-927efae3-54b9-4f31-bc65-250a9d96b4a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67242223499321 139.74704061371398 44.3 35.672428879867496 139.74703048792895 44.3 35.672428879867496 139.74703048792895 44.951 35.67242223499321 139.74704061371398 44.951 35.67242223499321 139.74704061371398 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e1fbdb1-c77c-4d0a-ab6a-faa814223dee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672244278207295 139.7470172098971 43.611 35.67227944833485 139.74705292962258 43.611 35.67227458607797 139.74706012614052 43.611 35.67223941595251 139.74702440641408 43.611 35.672244278207295 139.7470172098971 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f62cb672-bebb-4b7e-b60d-1a202ac49ad6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67224088578203 139.7470503862384 44.3 35.67222959237779 139.74703892106365 44.3 35.67222970944533 139.74703876628644 44.3 35.67224088578203 139.7470503862384 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4eee1843-3cec-435c-b3b6-3db36bcc1a72">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67241199571714 139.7470536375592 43.611 35.6724046981627 139.74704603434736 43.611 35.67240960557431 139.74703895928022 43.611 35.67241690312918 139.74704656249185 43.611 35.67241199571714 139.7470536375592 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-980955f0-7928-49a0-bc21-7f195e8d0d3e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67224088578203 139.7470503862384 43.611 35.67222970944533 139.74703876628644 43.611 35.6722348688371 139.74703112759076 43.611 35.67227009308249 139.7470669024925 43.611 35.67226481662089 139.7470746959665 43.611 35.67224088578203 139.7470503862384 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c77ce75e-d6bf-4d37-9747-316fa2f6463d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67238227226157 139.74704638988007 48.027 35.67240094429457 139.74706539192303 48.027 35.67238634847534 139.7470869373284 48.027 35.6723676764457 139.7470679352838 48.027 35.67238227226157 139.74704638988007 48.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-003497e3-b41a-4887-a3b1-601b703f01da">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672357152074525 139.74708563210663 43.611 35.67232810379797 139.74712754074582 43.611 35.672319939823545 139.74711839195308 43.611 35.6723243880143 139.74711198018335 43.611 35.67230841279215 139.7470953502497 43.611 35.672322198557275 139.74707545167107 43.611 35.6723432703402 139.7470973895024 43.611 35.672353453687265 139.74708178084563 43.611 35.672357152074525 139.74708563210663 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e894330-c00f-461c-91a0-48aa88ef2bb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e894330-c00f-461c-91a0-48aa88ef2bb9_0">
											<gml:posList>35.672251939277324 139.74697866034774 43.611 35.67227770140148 139.74694220117092 43.611 35.67227770140148 139.74694220117092 45.198 35.672251939277324 139.74697866034774 45.198 35.672251939277324 139.74697866034774 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9dab6f5f-9ca8-4846-99e3-9eb00865a612">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9dab6f5f-9ca8-4846-99e3-9eb00865a612_0">
											<gml:posList>35.67227655089567 139.74700957514443 43.611 35.67227655089567 139.74700957514443 45.798 35.6723050740811 139.74703995551667 45.798 35.6723050740811 139.74703995551667 43.611 35.67227655089567 139.74700957514443 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85ca8164-0457-44c5-b5af-639d7aa60292">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85ca8164-0457-44c5-b5af-639d7aa60292_0">
											<gml:posList>35.67227458607797 139.74706012614052 43.611 35.67227458607797 139.74706012614052 44.789 35.67223941595251 139.74702440641408 44.789 35.67223941595251 139.74702440641408 43.611 35.67227458607797 139.74706012614052 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35814567-175a-4981-baf6-8000f931d074">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35814567-175a-4981-baf6-8000f931d074_0">
											<gml:posList>35.67227009308249 139.7470669024925 43.611 35.6722348688371 139.74703112759076 43.611 35.6722348688371 139.74703112759076 44.789 35.67227009308249 139.7470669024925 44.789 35.67227009308249 139.7470669024925 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2672e432-a48e-43e6-b6f1-cf0fc4be2fb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2672e432-a48e-43e6-b6f1-cf0fc4be2fb7_0">
											<gml:posList>35.67239303119323 139.74679037479618 43.611 35.67238662916183 139.7467997381234 43.611 35.67238662916183 139.7467997381234 45.86 35.67239303119323 139.74679037479618 45.86 35.67239303119323 139.74679037479618 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91915c02-d169-4435-8b75-bd834df0be72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91915c02-d169-4435-8b75-bd834df0be72_0">
											<gml:posList>35.67239303119323 139.74679037479618 43.611 35.67239303119323 139.74679037479618 45.86 35.67240572288281 139.7468034181051 45.86 35.67240572288281 139.7468034181051 43.611 35.67239303119323 139.74679037479618 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbce9bb3-001c-4c95-933f-b5784d0af1d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbce9bb3-001c-4c95-933f-b5784d0af1d1_0">
											<gml:posList>35.672399320850396 139.7468127814328 45.86 35.67240572288281 139.7468034181051 45.86 35.67239303119323 139.74679037479618 45.86 35.67238662916183 139.7467997381234 45.86 35.672399320850396 139.7468127814328 45.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-536ae59e-1600-463b-898f-56740626667d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-536ae59e-1600-463b-898f-56740626667d_0">
											<gml:posList>35.67238662916183 139.7467997381234 43.611 35.672399320850396 139.7468127814328 43.611 35.672399320850396 139.7468127814328 45.86 35.67238662916183 139.7467997381234 45.86 35.67238662916183 139.7467997381234 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-263b6f83-5b69-4db5-8b2c-8d01e8f0b480">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-263b6f83-5b69-4db5-8b2c-8d01e8f0b480_0">
											<gml:posList>35.672399320850396 139.7468127814328 43.611 35.67240572288281 139.7468034181051 43.611 35.67240572288281 139.7468034181051 45.86 35.672399320850396 139.7468127814328 45.86 35.672399320850396 139.7468127814328 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c9f8206-dcb6-4077-a1cc-9e65fe6588d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c9f8206-dcb6-4077-a1cc-9e65fe6588d7_0">
											<gml:posList>35.67237518479562 139.74681655225558 43.611 35.67237015164147 139.74682423502836 43.611 35.67237015164147 139.74682423502836 45.86 35.67237518479562 139.74681655225558 45.86 35.67237518479562 139.74681655225558 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9476136-6188-4ca9-aa44-865ba45e96b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9476136-6188-4ca9-aa44-865ba45e96b9_0">
											<gml:posList>35.67238669445483 139.74682788462798 43.611 35.67237518479562 139.74681655225558 43.611 35.67237518479562 139.74681655225558 45.86 35.67238669445483 139.74682788462798 45.86 35.67238669445483 139.74682788462798 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c44fb95-ea71-4e1c-a4ab-ca849a18720a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c44fb95-ea71-4e1c-a4ab-ca849a18720a_0">
											<gml:posList>35.67237015164147 139.74682423502836 45.86 35.67238165228625 139.7468355674109 45.86 35.67238669445483 139.74682788462798 45.86 35.67237518479562 139.74681655225558 45.86 35.67237015164147 139.74682423502836 45.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84851a53-4758-44fa-b058-91608904304b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84851a53-4758-44fa-b058-91608904304b_0">
											<gml:posList>35.67237015164147 139.74682423502836 43.611 35.67238165228625 139.7468355674109 43.611 35.67238165228625 139.7468355674109 45.86 35.67237015164147 139.74682423502836 45.86 35.67237015164147 139.74682423502836 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f073ad6e-4fd1-480d-a985-80a487c3fec0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f073ad6e-4fd1-480d-a985-80a487c3fec0_0">
											<gml:posList>35.67238165228625 139.7468355674109 43.611 35.67238669445483 139.74682788462798 43.611 35.67238669445483 139.74682788462798 45.86 35.67238165228625 139.7468355674109 45.86 35.67238165228625 139.7468355674109 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdca3ffe-ebce-48ca-bbe6-0b1a31ec3cb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdca3ffe-ebce-48ca-bbe6-0b1a31ec3cb4_0">
											<gml:posList>35.67235747226501 139.74684087374143 43.611 35.672351925985716 139.74684947392666 43.611 35.672351925985716 139.74684947392666 45.86 35.67235747226501 139.74684087374143 45.86 35.67235747226501 139.74684087374143 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d7bcbe9-bdab-4ac2-9e98-a4934e59869a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d7bcbe9-bdab-4ac2-9e98-a4934e59869a_0">
											<gml:posList>35.67236977555787 139.74685280177158 43.611 35.67235747226501 139.74684087374143 43.611 35.67235747226501 139.74684087374143 45.86 35.67236977555787 139.74685280177158 45.86 35.67236977555787 139.74685280177158 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-631da7ec-1c39-4e35-9341-504920017f6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-631da7ec-1c39-4e35-9341-504920017f6b_0">
											<gml:posList>35.67236422026401 139.74686140196704 45.86 35.67236977555787 139.74685280177158 45.86 35.67235747226501 139.74684087374143 45.86 35.672351925985716 139.74684947392666 45.86 35.67236422026401 139.74686140196704 45.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-007a6057-5db0-409e-824d-d168cd5a0014">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-007a6057-5db0-409e-824d-d168cd5a0014_0">
											<gml:posList>35.672351925985716 139.74684947392666 43.611 35.67236422026401 139.74686140196704 43.611 35.67236422026401 139.74686140196704 45.86 35.672351925985716 139.74684947392666 45.86 35.672351925985716 139.74684947392666 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01f5037e-1e9f-417b-af1b-fe794ccb6f55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01f5037e-1e9f-417b-af1b-fe794ccb6f55_0">
											<gml:posList>35.67236422026401 139.74686140196704 43.611 35.67236977555787 139.74685280177158 43.611 35.67236977555787 139.74685280177158 45.86 35.67236422026401 139.74686140196704 45.86 35.67236422026401 139.74686140196704 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5982068c-821f-4a8e-9ae9-4945596395ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5982068c-821f-4a8e-9ae9-4945596395ee_0">
											<gml:posList>35.67227770140148 139.74694220117092 43.611 35.6722712967769 139.74693540341565 43.611 35.6722712967769 139.74693540341565 45.198 35.67227770140148 139.74694220117092 45.198 35.67227770140148 139.74694220117092 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-261ca421-4902-4317-bbde-a52b9d5e6bd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-261ca421-4902-4317-bbde-a52b9d5e6bd3_0">
											<gml:posList>35.67228903028331 139.74695284885797 43.611 35.67228325710328 139.74694672425838 43.611 35.67228325710328 139.74694672425838 45.198 35.67228903028331 139.74695284885797 45.198 35.67228903028331 139.74695284885797 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-551ac1e6-a8aa-4ea3-b17b-91e1a87bb105">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-551ac1e6-a8aa-4ea3-b17b-91e1a87bb105_0">
											<gml:posList>35.6722712967769 139.74693540341565 43.611 35.67224553465478 139.74697186259175 43.611 35.67224553465478 139.74697186259175 45.198 35.6722712967769 139.74693540341565 45.198 35.6722712967769 139.74693540341565 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72a0d347-e9b7-4bfc-b8ae-6839e196817e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72a0d347-e9b7-4bfc-b8ae-6839e196817e_0">
											<gml:posList>35.6722712967769 139.74693540341565 45.198 35.67224553465478 139.74697186259175 45.198 35.672251939277324 139.74697866034774 45.198 35.67227770140148 139.74694220117092 45.198 35.6722712967769 139.74693540341565 45.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb7110ac-0c82-4ba6-8f37-18e5c3c02365">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb7110ac-0c82-4ba6-8f37-18e5c3c02365_0">
											<gml:posList>35.67228325710328 139.74694672425838 43.611 35.67225141688654 139.7469917952202 43.611 35.67225141688654 139.7469917952202 45.198 35.67228325710328 139.74694672425838 45.198 35.67228325710328 139.74694672425838 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e6e293e-653d-4430-b597-dc812d17dca4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e6e293e-653d-4430-b597-dc812d17dca4_0">
											<gml:posList>35.67225719006429 139.74699791982061 45.198 35.67228903028331 139.74695284885797 45.198 35.67228325710328 139.74694672425838 45.198 35.67225141688654 139.7469917952202 45.198 35.67225719006429 139.74699791982061 45.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbc99efb-3464-4a9a-a1ff-49ae77732571">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbc99efb-3464-4a9a-a1ff-49ae77732571_0">
											<gml:posList>35.67224553465478 139.74697186259175 43.611 35.672251939277324 139.74697866034774 43.611 35.672251939277324 139.74697866034774 45.198 35.67224553465478 139.74697186259175 45.198 35.67224553465478 139.74697186259175 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85def42e-2e8f-44cc-b061-99f59f4ed8dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85def42e-2e8f-44cc-b061-99f59f4ed8dd_0">
											<gml:posList>35.67225719006429 139.74699791982061 43.611 35.67228903028331 139.74695284885797 43.611 35.67228903028331 139.74695284885797 45.198 35.67225719006429 139.74699791982061 45.198 35.67225719006429 139.74699791982061 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a95b34b7-c6da-4e96-a572-6391d712b144">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a95b34b7-c6da-4e96-a572-6391d712b144_0">
											<gml:posList>35.67230021539097 139.74697668625333 43.611 35.672288140173976 139.74699368881238 43.611 35.672288140173976 139.74699368881238 45.798 35.67230021539097 139.74697668625333 45.798 35.67230021539097 139.74697668625333 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34212c08-a389-4354-95d3-e8dcea4c0049">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34212c08-a389-4354-95d3-e8dcea4c0049_0">
											<gml:posList>35.672333420293484 139.74701206565942 43.611 35.67230021539097 139.74697668625333 43.611 35.67230021539097 139.74697668625333 45.798 35.672333420293484 139.74701206565942 45.798 35.672333420293484 139.74701206565942 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-299341d8-4edf-42d7-b09a-92f662895591">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-299341d8-4edf-42d7-b09a-92f662895591_0">
											<gml:posList>35.67225141688654 139.7469917952202 43.611 35.67225719006429 139.74699791982061 43.611 35.67225719006429 139.74699791982061 45.198 35.67225141688654 139.7469917952202 45.198 35.67225141688654 139.7469917952202 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07c71a74-6f22-46f4-97a8-39f057f76677">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07c71a74-6f22-46f4-97a8-39f057f76677_0">
											<gml:posList>35.67230021539097 139.74697668625333 45.798 35.672288140173976 139.74699368881238 45.798 35.67232135409321 139.74702907925703 45.798 35.672333420293484 139.74701206565942 45.798 35.67230021539097 139.74697668625333 45.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23807dcf-9ee4-4253-97be-a3996a5091c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23807dcf-9ee4-4253-97be-a3996a5091c7_0">
											<gml:posList>35.672288140173976 139.74699368881238 43.611 35.67232135409321 139.74702907925703 43.611 35.67232135409321 139.74702907925703 45.798 35.672288140173976 139.74699368881238 45.798 35.672288140173976 139.74699368881238 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72a85144-3ec9-4494-9fee-be4a40b60bc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72a85144-3ec9-4494-9fee-be4a40b60bc9_0">
											<gml:posList>35.67227655089567 139.74700957514443 43.611 35.67227006756518 139.74701871759765 43.611 35.67227006756518 139.74701871759765 45.798 35.67227655089567 139.74700957514443 45.798 35.67227655089567 139.74700957514443 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb35fe56-f248-4ec3-907a-32810e32d076">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb35fe56-f248-4ec3-907a-32810e32d076_0">
											<gml:posList>35.672333420293484 139.74701206565942 43.611 35.672333420293484 139.74701206565942 45.798 35.67232135409321 139.74702907925703 45.798 35.67232135409321 139.74702907925703 43.611 35.672333420293484 139.74701206565942 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf6050fa-45e3-4537-8317-8ffc3c483992">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf6050fa-45e3-4537-8317-8ffc3c483992_0">
											<gml:posList>35.672244278207295 139.7470172098971 43.611 35.67223941595251 139.74702440641408 43.611 35.67223941595251 139.74702440641408 44.789 35.672244278207295 139.7470172098971 44.789 35.672244278207295 139.7470172098971 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-930ea3e0-3661-49cc-85c3-b1abf8955149">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-930ea3e0-3661-49cc-85c3-b1abf8955149_0">
											<gml:posList>35.67242860926585 139.74703022310325 44.3 35.67242860926585 139.74703022310325 43.611 35.672420301753505 139.7470220355126 43.611 35.672420301753505 139.7470220355126 44.951 35.672428879867496 139.74703048792895 44.951 35.672428879867496 139.74703048792895 44.3 35.67242860926585 139.74703022310325 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6797ce9-b3b8-4e7a-88f7-659feb05fc86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6797ce9-b3b8-4e7a-88f7-659feb05fc86_0">
											<gml:posList>35.67241365687991 139.74703216129723 43.611 35.67241365687991 139.74703216129723 44.951 35.672420301753505 139.7470220355126 44.951 35.672420301753505 139.7470220355126 43.611 35.67241365687991 139.74703216129723 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acfb5d03-25a7-48b3-be96-ba4888c68724">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acfb5d03-25a7-48b3-be96-ba4888c68724_0">
											<gml:posList>35.6723050740811 139.74703995551667 45.798 35.67227655089567 139.74700957514443 45.798 35.67227006756518 139.74701871759765 45.798 35.67229858173463 139.74704909798044 45.798 35.6723050740811 139.74703995551667 45.798</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1da0fc8a-2d50-4410-8621-d016e69328cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1da0fc8a-2d50-4410-8621-d016e69328cc_0">
											<gml:posList>35.67242223499321 139.74704061371398 44.951 35.672428879867496 139.74703048792895 44.951 35.672420301753505 139.7470220355126 44.951 35.67241365687991 139.74703216129723 44.951 35.67242223499321 139.74704061371398 44.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f8b0044-9518-4818-8614-21f832cf1005">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f8b0044-9518-4818-8614-21f832cf1005_0">
											<gml:posList>35.67227006756518 139.74701871759765 43.611 35.67229858173463 139.74704909798044 43.611 35.67229858173463 139.74704909798044 45.798 35.67227006756518 139.74701871759765 45.798 35.67227006756518 139.74701871759765 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c3d4651-e2bb-4d71-a6ef-e4a911e0a191">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c3d4651-e2bb-4d71-a6ef-e4a911e0a191_0">
											<gml:posList>35.67222959237779 139.74703892106365 44.789 35.6722348688371 139.74703112759076 44.789 35.6722348688371 139.74703112759076 43.611 35.67222970944533 139.74703876628644 43.611 35.67222970944533 139.74703876628644 44.3 35.67222959237779 139.74703892106365 44.3 35.67222959237779 139.74703892106365 44.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8433cd28-e7a4-404b-b870-513fca8966a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8433cd28-e7a4-404b-b870-513fca8966a0_0">
											<gml:posList>35.672244278207295 139.7470172098971 43.611 35.672244278207295 139.7470172098971 44.789 35.67227944833485 139.74705292962258 44.789 35.67227944833485 139.74705292962258 43.611 35.672244278207295 139.7470172098971 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad85227a-ac8f-4205-99b4-f0665893c8a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad85227a-ac8f-4205-99b4-f0665893c8a9_0">
											<gml:posList>35.67242223499321 139.74704061371398 44.951 35.67241365687991 139.74703216129723 44.951 35.67241365687991 139.74703216129723 43.611 35.672421747903925 139.74704012819046 43.611 35.672421747903925 139.74704012819046 44.3 35.67242223499321 139.74704061371398 44.3 35.67242223499321 139.74704061371398 44.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-605608cd-28c1-4cd8-8230-af8c5ef93da4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-605608cd-28c1-4cd8-8230-af8c5ef93da4_0">
											<gml:posList>35.67227458607797 139.74706012614052 44.789 35.67227944833485 139.74705292962258 44.789 35.672244278207295 139.7470172098971 44.789 35.67223941595251 139.74702440641408 44.789 35.67227458607797 139.74706012614052 44.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b2890ac-cdbf-4375-9f04-dfec5eadad7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b2890ac-cdbf-4375-9f04-dfec5eadad7d_0">
											<gml:posList>35.6724046981627 139.74704603434736 49.971 35.67240960557431 139.74703895928022 49.971 35.67240960557431 139.74703895928022 43.611 35.6724046981627 139.74704603434736 43.611 35.6724046981627 139.74704603434736 49.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f457610-cbeb-43ba-841c-a8027648394a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f457610-cbeb-43ba-841c-a8027648394a_0">
											<gml:posList>35.67240960557431 139.74703895928022 43.611 35.67240960557431 139.74703895928022 49.971 35.67241690312918 139.74704656249185 49.971 35.67241690312918 139.74704656249185 43.611 35.67240960557431 139.74703895928022 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d0a5137-e32f-4426-8e1d-4892dd6a7be9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d0a5137-e32f-4426-8e1d-4892dd6a7be9_0">
											<gml:posList>35.67224088578203 139.7470503862384 44.3 35.67222970944533 139.74703876628644 44.3 35.67222970944533 139.74703876628644 43.611 35.67224088578203 139.7470503862384 43.611 35.67224088578203 139.7470503862384 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fc16abf-acde-4ac8-ae4c-2ac2a05e41cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fc16abf-acde-4ac8-ae4c-2ac2a05e41cc_0">
											<gml:posList>35.67229858173463 139.74704909798044 43.611 35.6723050740811 139.74703995551667 43.611 35.6723050740811 139.74703995551667 45.798 35.67229858173463 139.74704909798044 45.798 35.67229858173463 139.74704909798044 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a3a9f2c-f1a2-4b9d-9da7-06fcdd6d6019">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a3a9f2c-f1a2-4b9d-9da7-06fcdd6d6019_0">
											<gml:posList>35.67240960557431 139.74703895928022 49.971 35.6724046981627 139.74704603434736 49.971 35.67241199571714 139.7470536375592 49.971 35.67241690312918 139.74704656249185 49.971 35.67240960557431 139.74703895928022 49.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-633473e0-acee-4b90-80be-9e31483394af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-633473e0-acee-4b90-80be-9e31483394af_0">
											<gml:posList>35.67241199571714 139.7470536375592 49.971 35.6724046981627 139.74704603434736 49.971 35.6724046981627 139.74704603434736 43.611 35.67241199571714 139.7470536375592 43.611 35.67241199571714 139.7470536375592 49.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0a8675d-620c-40e3-b533-6c468d867fd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0a8675d-620c-40e3-b533-6c468d867fd8_0">
											<gml:posList>35.67241199571714 139.7470536375592 49.971 35.67241199571714 139.7470536375592 43.611 35.67241690312918 139.74704656249185 43.611 35.67241690312918 139.74704656249185 49.971 35.67241199571714 139.7470536375592 49.971</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7207f578-38fd-441e-8db0-b505dd2665ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7207f578-38fd-441e-8db0-b505dd2665ad_0">
											<gml:posList>35.67227009308249 139.7470669024925 44.789 35.6722348688371 139.74703112759076 44.789 35.67222959237779 139.74703892106365 44.789 35.67226481662089 139.7470746959665 44.789 35.67227009308249 139.7470669024925 44.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57bbce27-b4da-4d55-a4f3-b3cf9ad716cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57bbce27-b4da-4d55-a4f3-b3cf9ad716cf_0">
											<gml:posList>35.67240094429457 139.74706539192303 48.027 35.67238227226157 139.74704638988007 48.027 35.67238227226157 139.74704638988007 48.33 35.67240094429457 139.74706539192303 48.33 35.67240094429457 139.74706539192303 48.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d77fe78d-5adf-4b21-9109-75b96e1c1e46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d77fe78d-5adf-4b21-9109-75b96e1c1e46_0">
											<gml:posList>35.67227458607797 139.74706012614052 43.611 35.67227944833485 139.74705292962258 43.611 35.67227944833485 139.74705292962258 44.789 35.67227458607797 139.74706012614052 44.789 35.67227458607797 139.74706012614052 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddde4e3d-526e-4e2e-97aa-df983b50c316">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddde4e3d-526e-4e2e-97aa-df983b50c316_0">
											<gml:posList>35.67224088578203 139.7470503862384 44.3 35.67224088578203 139.7470503862384 43.611 35.67226481662089 139.7470746959665 43.611 35.67226481662089 139.7470746959665 44.789 35.67222959237779 139.74703892106365 44.789 35.67222959237779 139.74703892106365 44.3 35.67224088578203 139.7470503862384 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-719631a9-2573-4ab3-9915-1579f5762855">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-719631a9-2573-4ab3-9915-1579f5762855_0">
											<gml:posList>35.6723676764457 139.7470679352838 48.33 35.67238227226157 139.74704638988007 48.33 35.67238227226157 139.74704638988007 48.027 35.6723676764457 139.7470679352838 48.027 35.6723676764457 139.7470679352838 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11581ee7-1012-449b-b175-c67de21922c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11581ee7-1012-449b-b175-c67de21922c2_0">
											<gml:posList>35.67238634847534 139.7470869373284 48.33 35.67240094429457 139.74706539192303 48.33 35.67238227226157 139.74704638988007 48.33 35.6723676764457 139.7470679352838 48.33 35.67238634847534 139.7470869373284 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd94a93c-175f-4a6a-8e21-d195fd99bc4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd94a93c-175f-4a6a-8e21-d195fd99bc4d_0">
											<gml:posList>35.67227009308249 139.7470669024925 43.611 35.67227009308249 139.7470669024925 44.789 35.67226481662089 139.7470746959665 44.789 35.67226481662089 139.7470746959665 43.611 35.67227009308249 139.7470669024925 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23626ce9-3785-4142-b125-0cff73b0adfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23626ce9-3785-4142-b125-0cff73b0adfa_0">
											<gml:posList>35.67238634847534 139.7470869373284 48.027 35.67240094429457 139.74706539192303 48.027 35.67240094429457 139.74706539192303 48.33 35.67238634847534 139.7470869373284 48.33 35.67238634847534 139.7470869373284 48.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3756f53d-f140-47b6-b596-a71fd7cdb6e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3756f53d-f140-47b6-b596-a71fd7cdb6e6_0">
											<gml:posList>35.67238634847534 139.7470869373284 48.027 35.67238634847534 139.7470869373284 48.33 35.6723676764457 139.7470679352838 48.33 35.6723676764457 139.7470679352838 48.027 35.67238634847534 139.7470869373284 48.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef51eb36-6103-4450-a787-d8c9dbcba958">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef51eb36-6103-4450-a787-d8c9dbcba958_0">
											<gml:posList>35.672353453687265 139.74708178084563 43.611 35.672353453687265 139.74708178084563 45.272 35.672357152074525 139.74708563210663 45.272 35.672357152074525 139.74708563210663 43.611 35.672353453687265 139.74708178084563 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c33e0ddc-c44f-4a47-bb61-a2bf8ed04bff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c33e0ddc-c44f-4a47-bb61-a2bf8ed04bff_0">
											<gml:posList>35.672322198557275 139.74707545167107 43.611 35.67230841279215 139.7470953502497 43.611 35.67230841279215 139.7470953502497 45.272 35.672322198557275 139.74707545167107 45.272 35.672322198557275 139.74707545167107 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cd27c99-6e4b-4738-ae90-04aa554cc0f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cd27c99-6e4b-4738-ae90-04aa554cc0f5_0">
											<gml:posList>35.672322198557275 139.74707545167107 43.611 35.672322198557275 139.74707545167107 45.272 35.6723432703402 139.7470973895024 45.272 35.6723432703402 139.7470973895024 43.611 35.672322198557275 139.74707545167107 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccf2a390-855b-4a82-a1da-cb111585d2a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccf2a390-855b-4a82-a1da-cb111585d2a6_0">
											<gml:posList>35.672353453687265 139.74708178084563 43.611 35.6723432703402 139.7470973895024 43.611 35.6723432703402 139.7470973895024 45.272 35.672353453687265 139.74708178084563 45.272 35.672353453687265 139.74708178084563 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39a4a49d-409e-4849-9258-746a02c63def">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39a4a49d-409e-4849-9258-746a02c63def_0">
											<gml:posList>35.6723432703402 139.7470973895024 45.272 35.672322198557275 139.74707545167107 45.272 35.67230841279215 139.7470953502497 45.272 35.6723243880143 139.74711198018335 45.272 35.672319939823545 139.74711839195308 45.272 35.67232810379797 139.74712754074582 45.272 35.672357152074525 139.74708563210663 45.272 35.672353453687265 139.74708178084563 45.272 35.6723432703402 139.7470973895024 45.272</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb303069-edbf-4e13-ae7c-fac4b5a43abd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb303069-edbf-4e13-ae7c-fac4b5a43abd_0">
											<gml:posList>35.67230841279215 139.7470953502497 43.611 35.6723243880143 139.74711198018335 43.611 35.6723243880143 139.74711198018335 45.272 35.67230841279215 139.7470953502497 45.272 35.67230841279215 139.7470953502497 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68fc084d-49b6-4d9b-adb5-b6e96143c66b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68fc084d-49b6-4d9b-adb5-b6e96143c66b_0">
											<gml:posList>35.672357152074525 139.74708563210663 43.611 35.672357152074525 139.74708563210663 45.272 35.67232810379797 139.74712754074582 45.272 35.67232810379797 139.74712754074582 43.611 35.672357152074525 139.74708563210663 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c390a7e-01f8-45dd-bf68-6bcf027d519e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c390a7e-01f8-45dd-bf68-6bcf027d519e_0">
											<gml:posList>35.6723243880143 139.74711198018335 43.611 35.672319939823545 139.74711839195308 43.611 35.672319939823545 139.74711839195308 45.272 35.6723243880143 139.74711198018335 45.272 35.6723243880143 139.74711198018335 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a04fe13-555f-4f7d-a117-d8d9c4b5e2b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a04fe13-555f-4f7d-a117-d8d9c4b5e2b8_0">
											<gml:posList>35.672319939823545 139.74711839195308 43.611 35.67232810379797 139.74712754074582 43.611 35.67232810379797 139.74712754074582 45.272 35.672319939823545 139.74711839195308 45.272 35.672319939823545 139.74711839195308 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_10b0a4c8-60b4-41e8-bd49-1c2db08197ea_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-536732ae-fbdc-4d2c-9c2a-3e1f1d460dc8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672443169699385 139.74697191481485 43.611 35.67245823379194 139.7469874852646 43.611 35.6724441328862 139.74700783713985 43.611 35.672429068796234 139.74699226668898 43.611 35.672443169699385 139.74697191481485 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e21bb2a3-ebfa-4ca7-9262-4f6f139f3f09">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67245823379194 139.7469874852646 44.3 35.67246158036187 139.74699093922948 44.3 35.672447470441824 139.74701129111463 44.3 35.6724441328862 139.74700783713985 44.3 35.67245823379194 139.7469874852646 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6cdfaa7b-fabf-433f-9230-b14de7acd3aa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67229808775871 139.74710191194492 43.611 35.672275797280335 139.7470774015964 43.611 35.67229055633454 139.74705723685884 43.611 35.672312846809064 139.7470817361597 43.611 35.67229808775871 139.74710191194492 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca829e7c-3fb2-4f7e-a3a4-2d6d58e4b7d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca829e7c-3fb2-4f7e-a3a4-2d6d58e4b7d9_0">
											<gml:posList>35.672443169699385 139.74697191481485 43.611 35.672443169699385 139.74697191481485 47.179 35.67246158036187 139.74699093922948 47.179 35.67246158036187 139.74699093922948 44.3 35.67245823379194 139.7469874852646 44.3 35.67245823379194 139.7469874852646 43.611 35.672443169699385 139.74697191481485 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f628823-9645-46f1-99a2-c7daf815f44e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f628823-9645-46f1-99a2-c7daf815f44e_0">
											<gml:posList>35.672443169699385 139.74697191481485 43.611 35.672429068796234 139.74699226668898 43.611 35.672429068796234 139.74699226668898 47.179 35.672443169699385 139.74697191481485 47.179 35.672443169699385 139.74697191481485 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a681df68-fa14-4a2c-80c8-fb30a820afe4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a681df68-fa14-4a2c-80c8-fb30a820afe4_0">
											<gml:posList>35.672443169699385 139.74697191481485 47.179 35.672429068796234 139.74699226668898 47.179 35.672447470441824 139.74701129111463 47.179 35.67246158036187 139.74699093922948 47.179 35.672443169699385 139.74697191481485 47.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8b52675-ff33-4ff8-9766-1a79d1da9d65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8b52675-ff33-4ff8-9766-1a79d1da9d65_0">
											<gml:posList>35.67245823379194 139.7469874852646 44.3 35.6724441328862 139.74700783713985 44.3 35.6724441328862 139.74700783713985 43.611 35.67245823379194 139.7469874852646 43.611 35.67245823379194 139.7469874852646 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fddb8021-ff4b-4abf-8b26-7bef65cc5c41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fddb8021-ff4b-4abf-8b26-7bef65cc5c41_0">
											<gml:posList>35.672447470441824 139.74701129111463 44.3 35.67246158036187 139.74699093922948 44.3 35.67246158036187 139.74699093922948 47.179 35.672447470441824 139.74701129111463 47.179 35.672447470441824 139.74701129111463 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ffc0e38-a814-4222-ab9a-2130418b74b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ffc0e38-a814-4222-ab9a-2130418b74b4_0">
											<gml:posList>35.6724441328862 139.74700783713985 44.3 35.672447470441824 139.74701129111463 44.3 35.672447470441824 139.74701129111463 47.179 35.672429068796234 139.74699226668898 47.179 35.672429068796234 139.74699226668898 43.611 35.6724441328862 139.74700783713985 43.611 35.6724441328862 139.74700783713985 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7516ff10-dea5-43e1-96f5-19d4a6646e4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7516ff10-dea5-43e1-96f5-19d4a6646e4c_0">
											<gml:posList>35.67229055633454 139.74705723685884 43.611 35.672275797280335 139.7470774015964 43.611 35.672275797280335 139.7470774015964 45.513 35.67229055633454 139.74705723685884 45.513 35.67229055633454 139.74705723685884 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1a01f7b-5563-4082-8f51-705b963b44e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1a01f7b-5563-4082-8f51-705b963b44e6_0">
											<gml:posList>35.672312846809064 139.7470817361597 43.611 35.67229055633454 139.74705723685884 43.611 35.67229055633454 139.74705723685884 45.513 35.672312846809064 139.7470817361597 45.513 35.672312846809064 139.7470817361597 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d202915b-3cfc-423f-9e39-0aba064a07de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d202915b-3cfc-423f-9e39-0aba064a07de_0">
											<gml:posList>35.67229055633454 139.74705723685884 45.513 35.672275797280335 139.7470774015964 45.513 35.67229808775871 139.74710191194492 45.513 35.672312846809064 139.7470817361597 45.513 35.67229055633454 139.74705723685884 45.513</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bf87a31-c14b-4620-98b3-9cfb480010c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bf87a31-c14b-4620-98b3-9cfb480010c8_0">
											<gml:posList>35.67229808775871 139.74710191194492 43.611 35.67229808775871 139.74710191194492 45.513 35.672275797280335 139.7470774015964 45.513 35.672275797280335 139.7470774015964 43.611 35.67229808775871 139.74710191194492 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2041b28d-d364-451c-bf92-6e25ce697e9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2041b28d-d364-451c-bf92-6e25ce697e9c_0">
											<gml:posList>35.672312846809064 139.7470817361597 45.513 35.67229808775871 139.74710191194492 45.513 35.67229808775871 139.74710191194492 43.611 35.672312846809064 139.7470817361597 43.611 35.672312846809064 139.7470817361597 45.513</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7c33e709-781f-4fc6-910b-036acdaa6a0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c33e709-781f-4fc6-910b-036acdaa6a0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c33e709-781f-4fc6-910b-036acdaa6a0d">
											<gml:posList>35.67242076111954 139.74670777196695 10.75 35.67255940595363 139.74685222163475 10.75 35.67234248961062 139.7471651828996 10.75 35.672203755088724 139.7470208436419 10.75 35.67242076111954 139.74670777196695 10.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26bdc4be-15dc-4698-aa35-a6755b92b198">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26bdc4be-15dc-4698-aa35-a6755b92b198">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26bdc4be-15dc-4698-aa35-a6755b92b198">
											<gml:posList>35.67234248961062 139.7471651828996 44.3 35.6723418516616 139.7471554184524 44.3 35.672211731678026 139.74702006179854 44.3 35.672203755088724 139.7470208436419 44.3 35.67234248961062 139.7471651828996 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d37b6cc-b428-45f9-b861-491c21a4f82a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d37b6cc-b428-45f9-b861-491c21a4f82a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d37b6cc-b428-45f9-b861-491c21a4f82a">
											<gml:posList>35.67235187222377 139.74715164081383 48.33 35.67235161696951 139.74714763119718 48.33 35.67233201553164 139.74712722723686 48.33 35.672328734766396 139.7471275511139 48.33 35.67235187222377 139.74715164081383 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dfebf817-1146-41cb-9340-bae701221a7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfebf817-1146-41cb-9340-bae701221a7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfebf817-1146-41cb-9340-bae701221a7b">
											<gml:posList>35.672357783042926 139.74708564247436 48.33 35.672328734766396 139.7471275511139 48.33 35.67233201553164 139.74712722723686 48.33 35.67236106380805 139.7470853185955 48.33 35.672357783042926 139.74708564247436 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-030a009b-90b9-4bcc-8986-e9bf1ace8ef6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-030a009b-90b9-4bcc-8986-e9bf1ace8ef6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-030a009b-90b9-4bcc-8986-e9bf1ace8ef6">
											<gml:posList>35.67235187222377 139.74715164081383 44.3 35.67234391366914 139.74715243367265 44.3 35.6723418516616 139.7471554184524 44.3 35.67234248961062 139.7471651828996 44.3 35.67235187222377 139.74715164081383 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba445633-ff99-444f-8d0d-6293ba826780">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba445633-ff99-444f-8d0d-6293ba826780">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba445633-ff99-444f-8d0d-6293ba826780">
											<gml:posList>35.67234391366914 139.74715243367265 44.3 35.67235187222377 139.74715164081383 44.3 35.672347569468606 139.74714716054748 44.3 35.67234391366914 139.74715243367265 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad917049-5656-42ab-9caf-3c5aaf92f9b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad917049-5656-42ab-9caf-3c5aaf92f9b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad917049-5656-42ab-9caf-3c5aaf92f9b0">
											<gml:posList>35.672357783042926 139.74708564247436 48.33 35.67236106380805 139.7470853185955 48.33 35.672338846433505 139.7470622000165 48.33 35.672335565660525 139.7470625128497 48.33 35.672357783042926 139.74708564247436 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-49a7de47-fd14-47ab-ba91-70dac355bcc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49a7de47-fd14-47ab-ba91-70dac355bcc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49a7de47-fd14-47ab-ba91-70dac355bcc0">
											<gml:posList>35.672335565660525 139.7470625128497 48.33 35.672338846433505 139.7470622000165 48.33 35.67237143340544 139.7470151619463 48.33 35.67237116912498 139.74701114129232 48.33 35.672335565660525 139.7470625128497 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-535faf38-4ef1-4ce6-b3f7-9e2364ff6ca8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-535faf38-4ef1-4ce6-b3f7-9e2364ff6ca8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-535faf38-4ef1-4ce6-b3f7-9e2364ff6ca8">
											<gml:posList>35.672413261263245 139.74705869551266 48.027 35.67237143340544 139.7470151619463 48.027 35.672338846433505 139.7470622000165 48.027 35.67236106380805 139.7470853185955 48.027 35.67233201553164 139.74712722723686 48.027 35.67235161696951 139.74714763119718 48.027 35.672413261263245 139.74705869551266 48.027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df9d11b8-d92f-44a6-8224-cb7b29fe1307">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df9d11b8-d92f-44a6-8224-cb7b29fe1307">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df9d11b8-d92f-44a6-8224-cb7b29fe1307">
											<gml:posList>35.67241653300662 139.74705836059562 48.33 35.672413261263245 139.74705869551266 48.33 35.67235161696951 139.74714763119718 48.33 35.67235187222377 139.74715164081383 48.33 35.67241653300662 139.74705836059562 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9bbb8cac-2ab1-409c-9065-49e110f6c5cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bbb8cac-2ab1-409c-9065-49e110f6c5cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bbb8cac-2ab1-409c-9065-49e110f6c5cf">
											<gml:posList>35.67237116912498 139.74701114129232 48.33 35.67237143340544 139.7470151619463 48.33 35.672413261263245 139.74705869551266 48.33 35.67241653300662 139.74705836059562 48.33 35.67237116912498 139.74701114129232 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72a307fe-8e07-4f28-8f6f-d1b82108940d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72a307fe-8e07-4f28-8f6f-d1b82108940d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72a307fe-8e07-4f28-8f6f-d1b82108940d">
											<gml:posList>35.67241222122639 139.74705386929384 44.3 35.67241653300662 139.74705836059562 44.3 35.672415877021486 139.7470485961597 44.3 35.67241222122639 139.74705386929384 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cfe6ca78-05d2-4bd0-ac59-ade59c6a323e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfe6ca78-05d2-4bd0-ac59-ade59c6a323e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfe6ca78-05d2-4bd0-ac59-ade59c6a323e">
											<gml:posList>35.67242076111954 139.74670777196695 44.3 35.672421408126525 139.7467175474569 44.3 35.67255143839549 139.74685302558166 44.3 35.67255940595363 139.74685222163475 44.3 35.67242076111954 139.74670777196695 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-beb51be2-be58-4d94-89c0-5d6f1ea1540f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-beb51be2-be58-4d94-89c0-5d6f1ea1540f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-beb51be2-be58-4d94-89c0-5d6f1ea1540f">
											<gml:posList>35.672203755088724 139.7470208436419 44.3 35.672211731678026 139.74702006179854 44.3 35.672421408126525 139.7467175474569 44.3 35.67242076111954 139.74670777196695 44.3 35.672203755088724 139.7470208436419 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5f0d17f-f58c-46ca-a9a5-248653ac3d5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5f0d17f-f58c-46ca-a9a5-248653ac3d5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5f0d17f-f58c-46ca-a9a5-248653ac3d5c">
											<gml:posList>35.672328734766396 139.7471275511139 43.611 35.672357783042926 139.74708564247436 43.611 35.672335565660525 139.7470625128497 43.611 35.67237116912498 139.74701114129232 43.611 35.67241222122639 139.74705386929384 43.611 35.672415877021486 139.7470485961597 43.611 35.67255143839549 139.74685302558166 43.611 35.672421408126525 139.7467175474569 43.611 35.672211731678026 139.74702006179854 43.611 35.6723418516616 139.7471554184524 43.611 35.67234391366914 139.74715243367265 43.611 35.672347569468606 139.74714716054748 43.611 35.672328734766396 139.7471275511139 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6574fc4c-8c7c-4e03-81be-c3fb981d6ba3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6574fc4c-8c7c-4e03-81be-c3fb981d6ba3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6574fc4c-8c7c-4e03-81be-c3fb981d6ba3">
											<gml:posList>35.67255940595363 139.74685222163475 44.3 35.67255143839549 139.74685302558166 44.3 35.672415877021486 139.7470485961597 44.3 35.67241653300662 139.74705836059562 44.3 35.67255940595363 139.74685222163475 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf318f6d-fb4d-4b47-971c-07b00948e174">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf318f6d-fb4d-4b47-971c-07b00948e174">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf318f6d-fb4d-4b47-971c-07b00948e174">
											<gml:posList>35.672211731678026 139.74702006179854 44.3 35.672211731678026 139.74702006179854 43.611 35.672421408126525 139.7467175474569 43.611 35.672421408126525 139.7467175474569 44.3 35.672211731678026 139.74702006179854 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84e4e3f4-3985-4084-ba09-91029d55512e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84e4e3f4-3985-4084-ba09-91029d55512e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84e4e3f4-3985-4084-ba09-91029d55512e">
											<gml:posList>35.67255143839549 139.74685302558166 44.3 35.67255143839549 139.74685302558166 43.611 35.672415877021486 139.7470485961597 43.611 35.672415877021486 139.7470485961597 44.3 35.67255143839549 139.74685302558166 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6975a4a8-65ab-420f-8682-1a22c4d7759e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6975a4a8-65ab-420f-8682-1a22c4d7759e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6975a4a8-65ab-420f-8682-1a22c4d7759e">
											<gml:posList>35.672338846433505 139.7470622000165 48.33 35.672338846433505 139.7470622000165 48.027 35.67237143340544 139.7470151619463 48.027 35.67237143340544 139.7470151619463 48.33 35.672338846433505 139.7470622000165 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f663e1f-d503-445e-b90f-6a9e556f285c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f663e1f-d503-445e-b90f-6a9e556f285c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f663e1f-d503-445e-b90f-6a9e556f285c">
											<gml:posList>35.672413261263245 139.74705869551266 48.33 35.672413261263245 139.74705869551266 48.027 35.67235161696951 139.74714763119718 48.027 35.67235161696951 139.74714763119718 48.33 35.672413261263245 139.74705869551266 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b0c5999-4599-48f4-a34f-4ae24f76d261">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b0c5999-4599-48f4-a34f-4ae24f76d261">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b0c5999-4599-48f4-a34f-4ae24f76d261">
											<gml:posList>35.67233201553164 139.74712722723686 48.33 35.67233201553164 139.74712722723686 48.027 35.67236106380805 139.7470853185955 48.027 35.67236106380805 139.7470853185955 48.33 35.67233201553164 139.74712722723686 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a568f3ff-2952-4ce2-8adf-bf40acfaf239">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a568f3ff-2952-4ce2-8adf-bf40acfaf239">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a568f3ff-2952-4ce2-8adf-bf40acfaf239">
											<gml:posList>35.67255940595363 139.74685222163475 10.75 35.67242076111954 139.74670777196695 10.75 35.67242076111954 139.74670777196695 44.3 35.67255940595363 139.74685222163475 44.3 35.67255940595363 139.74685222163475 10.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fcfffcd-7641-48a2-bc35-6956b5a218f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fcfffcd-7641-48a2-bc35-6956b5a218f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fcfffcd-7641-48a2-bc35-6956b5a218f1">
											<gml:posList>35.672421408126525 139.7467175474569 44.3 35.672421408126525 139.7467175474569 43.611 35.67255143839549 139.74685302558166 43.611 35.67255143839549 139.74685302558166 44.3 35.672421408126525 139.7467175474569 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fb4d5bc-3bc1-49b4-a2d5-39473a2176bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fb4d5bc-3bc1-49b4-a2d5-39473a2176bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fb4d5bc-3bc1-49b4-a2d5-39473a2176bf">
											<gml:posList>35.67242076111954 139.74670777196695 10.75 35.672203755088724 139.7470208436419 10.75 35.672203755088724 139.7470208436419 44.3 35.67242076111954 139.74670777196695 44.3 35.67242076111954 139.74670777196695 10.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2de5f8cc-51c3-4ee3-9295-27b4b7dfab47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2de5f8cc-51c3-4ee3-9295-27b4b7dfab47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2de5f8cc-51c3-4ee3-9295-27b4b7dfab47">
											<gml:posList>35.67241653300662 139.74705836059562 44.3 35.67241653300662 139.74705836059562 48.33 35.67235187222377 139.74715164081383 48.33 35.67235187222377 139.74715164081383 44.3 35.67234248961062 139.7471651828996 44.3 35.67234248961062 139.7471651828996 10.75 35.67255940595363 139.74685222163475 10.75 35.67255940595363 139.74685222163475 44.3 35.67241653300662 139.74705836059562 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-404b73b8-a86c-4a2e-8a0d-024c809f203f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-404b73b8-a86c-4a2e-8a0d-024c809f203f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-404b73b8-a86c-4a2e-8a0d-024c809f203f">
											<gml:posList>35.67237116912498 139.74701114129232 43.611 35.67237116912498 139.74701114129232 48.33 35.67241653300662 139.74705836059562 48.33 35.67241653300662 139.74705836059562 44.3 35.67241222122639 139.74705386929384 44.3 35.67241222122639 139.74705386929384 43.611 35.67237116912498 139.74701114129232 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5fdcfaf-31cb-40bd-9b6b-e08ea9d3655a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5fdcfaf-31cb-40bd-9b6b-e08ea9d3655a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5fdcfaf-31cb-40bd-9b6b-e08ea9d3655a">
											<gml:posList>35.672335565660525 139.7470625128497 48.33 35.67237116912498 139.74701114129232 48.33 35.67237116912498 139.74701114129232 43.611 35.672335565660525 139.7470625128497 43.611 35.672335565660525 139.7470625128497 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c1e5f86-0a7c-4ade-b0de-c3cb11c8d46d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c1e5f86-0a7c-4ade-b0de-c3cb11c8d46d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c1e5f86-0a7c-4ade-b0de-c3cb11c8d46d">
											<gml:posList>35.67237143340544 139.7470151619463 48.33 35.67237143340544 139.7470151619463 48.027 35.672413261263245 139.74705869551266 48.027 35.672413261263245 139.74705869551266 48.33 35.67237143340544 139.7470151619463 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1787e0f8-4a34-4f46-927e-ac7f7574b1ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1787e0f8-4a34-4f46-927e-ac7f7574b1ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1787e0f8-4a34-4f46-927e-ac7f7574b1ec">
											<gml:posList>35.672415877021486 139.7470485961597 44.3 35.672415877021486 139.7470485961597 43.611 35.67241222122639 139.74705386929384 43.611 35.67241222122639 139.74705386929384 44.3 35.672415877021486 139.7470485961597 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0795349f-ed43-4d2b-83be-a84d1ade9094">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0795349f-ed43-4d2b-83be-a84d1ade9094">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0795349f-ed43-4d2b-83be-a84d1ade9094">
											<gml:posList>35.67236106380805 139.7470853185955 48.33 35.67236106380805 139.7470853185955 48.027 35.672338846433505 139.7470622000165 48.027 35.672338846433505 139.7470622000165 48.33 35.67236106380805 139.7470853185955 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2d5c620-c67e-4721-839b-211f48fc082e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2d5c620-c67e-4721-839b-211f48fc082e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2d5c620-c67e-4721-839b-211f48fc082e">
											<gml:posList>35.672335565660525 139.7470625128497 43.611 35.672357783042926 139.74708564247436 43.611 35.672357783042926 139.74708564247436 48.33 35.672335565660525 139.7470625128497 48.33 35.672335565660525 139.7470625128497 43.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb036596-6459-4dcd-8844-b8c2b6c81910">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb036596-6459-4dcd-8844-b8c2b6c81910">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb036596-6459-4dcd-8844-b8c2b6c81910">
											<gml:posList>35.6723418516616 139.7471554184524 44.3 35.6723418516616 139.7471554184524 43.611 35.672211731678026 139.74702006179854 43.611 35.672211731678026 139.74702006179854 44.3 35.6723418516616 139.7471554184524 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88368b3e-14c3-4329-a92c-ecddaeb61ae9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88368b3e-14c3-4329-a92c-ecddaeb61ae9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88368b3e-14c3-4329-a92c-ecddaeb61ae9">
											<gml:posList>35.672203755088724 139.7470208436419 10.75 35.67234248961062 139.7471651828996 10.75 35.67234248961062 139.7471651828996 44.3 35.672203755088724 139.7470208436419 44.3 35.672203755088724 139.7470208436419 10.75</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c63bff7d-2a1c-4817-8962-52285225c1ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c63bff7d-2a1c-4817-8962-52285225c1ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c63bff7d-2a1c-4817-8962-52285225c1ea">
											<gml:posList>35.672328734766396 139.7471275511139 48.33 35.672357783042926 139.74708564247436 48.33 35.672357783042926 139.74708564247436 43.611 35.672328734766396 139.7471275511139 43.611 35.672328734766396 139.7471275511139 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa306b82-7549-4894-aeaf-3871f0d2c40a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa306b82-7549-4894-aeaf-3871f0d2c40a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa306b82-7549-4894-aeaf-3871f0d2c40a">
											<gml:posList>35.67235161696951 139.74714763119718 48.33 35.67235161696951 139.74714763119718 48.027 35.67233201553164 139.74712722723686 48.027 35.67233201553164 139.74712722723686 48.33 35.67235161696951 139.74714763119718 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37391ce8-a31b-4fa1-9b0d-9ff2e1236b7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37391ce8-a31b-4fa1-9b0d-9ff2e1236b7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37391ce8-a31b-4fa1-9b0d-9ff2e1236b7a">
											<gml:posList>35.67235187222377 139.74715164081383 48.33 35.672328734766396 139.7471275511139 48.33 35.672328734766396 139.7471275511139 43.611 35.672347569468606 139.74714716054748 43.611 35.672347569468606 139.74714716054748 44.3 35.67235187222377 139.74715164081383 44.3 35.67235187222377 139.74715164081383 48.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74fe7d5c-b265-400a-9780-f580245a2226">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74fe7d5c-b265-400a-9780-f580245a2226">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74fe7d5c-b265-400a-9780-f580245a2226">
											<gml:posList>35.672347569468606 139.74714716054748 44.3 35.672347569468606 139.74714716054748 43.611 35.67234391366914 139.74715243367265 43.611 35.67234391366914 139.74715243367265 44.3 35.672347569468606 139.74714716054748 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e69b1335-8e2e-42f0-9020-f891611fd2cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e69b1335-8e2e-42f0-9020-f891611fd2cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e69b1335-8e2e-42f0-9020-f891611fd2cd">
											<gml:posList>35.67234391366914 139.74715243367265 44.3 35.67234391366914 139.74715243367265 43.611 35.6723418516616 139.7471554184524 43.611 35.6723418516616 139.7471554184524 44.3 35.67234391366914 139.74715243367265 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-2857</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">750.6262</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>