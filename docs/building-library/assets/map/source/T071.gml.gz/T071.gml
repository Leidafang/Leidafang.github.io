<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_110cf00e-e31d-41a8-b6ab-9524d56e7b8e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門二丁目10地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">12.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667205420252806 139.7446093871006 0 35.667176941443714 139.74459115987327 0 35.66714749039123 139.74466026194457 0 35.667175969190026 139.7446784891898 0 35.667205420252806 139.7446093871006 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667205420252806 139.7446093871006 11.02 35.667175969190026 139.7446784891898 11.02 35.66714749039123 139.74466026194457 11.02 35.667176941443714 139.74459115987327 11.02 35.667205420252806 139.7446093871006 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667205420252806 139.7446093871006 11.02 35.667176941443714 139.74459115987327 11.02 35.667176941443714 139.74459115987327 23.95 35.667205420252806 139.7446093871006 23.95 35.667205420252806 139.7446093871006 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667176941443714 139.74459115987327 11.02 35.66714749039123 139.74466026194457 11.02 35.66714749039123 139.74466026194457 23.95 35.667176941443714 139.74459115987327 23.95 35.667176941443714 139.74459115987327 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714749039123 139.74466026194457 11.02 35.667175969190026 139.7446784891898 11.02 35.667175969190026 139.7446784891898 23.95 35.66714749039123 139.74466026194457 23.95 35.66714749039123 139.74466026194457 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667175969190026 139.7446784891898 11.02 35.667205420252806 139.7446093871006 11.02 35.667205420252806 139.7446093871006 23.95 35.667175969190026 139.7446784891898 23.95 35.667175969190026 139.7446784891898 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667205420252806 139.7446093871006 23.95 35.667176941443714 139.74459115987327 23.95 35.66714749039123 139.74466026194457 23.95 35.667175969190026 139.7446784891898 23.95 35.667205420252806 139.7446093871006 23.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fdfcd02f-4d00-4f8c-96fa-ed0f7ee57d8e"/>
							<gml:surfaceMember xlink:href="#poly-a9dd2f3a-46ca-4d94-a3c0-e1740255d9d3"/>
							<gml:surfaceMember xlink:href="#poly-71ab9f16-51b7-4406-a373-8dfd69051afa"/>
							<gml:surfaceMember xlink:href="#poly-d74cca1a-d97b-4f70-8c12-48ceec0f9504"/>
							<gml:surfaceMember xlink:href="#poly-20e9e9d9-cd32-4bb8-ab4c-6947c7bebc98"/>
							<gml:surfaceMember xlink:href="#poly-ba05fc24-4376-4d66-8d41-8374a32fa808"/>
							<gml:surfaceMember xlink:href="#poly-4b2ac958-39df-481c-9bfd-a79dada38b5e"/>
							<gml:surfaceMember xlink:href="#poly-afa87501-a222-4ad5-9c36-3f9a86eabb53"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fdfcd02f-4d00-4f8c-96fa-ed0f7ee57d8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdfcd02f-4d00-4f8c-96fa-ed0f7ee57d8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdfcd02f-4d00-4f8c-96fa-ed0f7ee57d8e">
											<gml:posList>35.6672054202528 139.7446093871006 11.02 35.66717596919002 139.7446784891898 11.02 35.66714749039122 139.74466026194457 11.02 35.66717694144371 139.74459115987327 11.02 35.6672054202528 139.7446093871006 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9dd2f3a-46ca-4d94-a3c0-e1740255d9d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9dd2f3a-46ca-4d94-a3c0-e1740255d9d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9dd2f3a-46ca-4d94-a3c0-e1740255d9d3">
											<gml:posList>35.66717596919002 139.7446784891898 23.864 35.66718747787062 139.74465148048168 23.864 35.6671589990678 139.7446332532434 23.864 35.66714749039122 139.74466026194457 23.864 35.66717596919002 139.7446784891898 23.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71ab9f16-51b7-4406-a373-8dfd69051afa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71ab9f16-51b7-4406-a373-8dfd69051afa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71ab9f16-51b7-4406-a373-8dfd69051afa">
											<gml:posList>35.66718747787062 139.74465148048168 28.295 35.6672054202528 139.7446093871006 28.295 35.66717694144371 139.74459115987327 28.295 35.6671589990678 139.7446332532434 28.295 35.66718747787062 139.74465148048168 28.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d74cca1a-d97b-4f70-8c12-48ceec0f9504">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d74cca1a-d97b-4f70-8c12-48ceec0f9504">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d74cca1a-d97b-4f70-8c12-48ceec0f9504">
											<gml:posList>35.66714749039122 139.74466026194457 11.02 35.66717596919002 139.7446784891898 11.02 35.66717596919002 139.7446784891898 23.864 35.66714749039122 139.74466026194457 23.864 35.66714749039122 139.74466026194457 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20e9e9d9-cd32-4bb8-ab4c-6947c7bebc98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20e9e9d9-cd32-4bb8-ab4c-6947c7bebc98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20e9e9d9-cd32-4bb8-ab4c-6947c7bebc98">
											<gml:posList>35.66714749039122 139.74466026194457 11.02 35.66714749039122 139.74466026194457 23.864 35.6671589990678 139.7446332532434 23.864 35.6671589990678 139.7446332532434 28.295 35.66717694144371 139.74459115987327 28.295 35.66717694144371 139.74459115987327 11.02 35.66714749039122 139.74466026194457 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba05fc24-4376-4d66-8d41-8374a32fa808">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba05fc24-4376-4d66-8d41-8374a32fa808">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba05fc24-4376-4d66-8d41-8374a32fa808">
											<gml:posList>35.66718747787062 139.74465148048168 23.864 35.66718747787062 139.74465148048168 28.295 35.6671589990678 139.7446332532434 28.295 35.6671589990678 139.7446332532434 23.864 35.66718747787062 139.74465148048168 23.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b2ac958-39df-481c-9bfd-a79dada38b5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b2ac958-39df-481c-9bfd-a79dada38b5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b2ac958-39df-481c-9bfd-a79dada38b5e">
											<gml:posList>35.6672054202528 139.7446093871006 11.02 35.6672054202528 139.7446093871006 28.295 35.66718747787062 139.74465148048168 28.295 35.66718747787062 139.74465148048168 23.864 35.66717596919002 139.7446784891898 23.864 35.66717596919002 139.7446784891898 11.02 35.6672054202528 139.7446093871006 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afa87501-a222-4ad5-9c36-3f9a86eabb53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afa87501-a222-4ad5-9c36-3f9a86eabb53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afa87501-a222-4ad5-9c36-3f9a86eabb53">
											<gml:posList>35.6672054202528 139.7446093871006 11.02 35.66717694144371 139.74459115987327 11.02 35.66717694144371 139.74459115987327 28.295 35.6672054202528 139.7446093871006 28.295 35.6672054202528 139.7446093871006 11.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7923</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>