<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_121b0e9f-8010-47f5-b722-8ff71434eede">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">17.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66670519362468 139.74676376313369 0 35.66671124195493 139.7467764592219 0 35.66671863940601 139.74678506692635 0 35.666738117556285 139.74679686486473 0 35.66676390698286 139.7468109756089 0 35.666797281852745 139.74671903882063 0 35.666729649476935 139.74667824257136 0 35.6667062543843 139.7467347116557 0 35.666703650807804 139.74674918440456 0 35.66670519362468 139.74676376313369 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66670519362468 139.74676376313369 7.55 35.666703650807804 139.74674918440456 7.55 35.6667062543843 139.7467347116557 7.55 35.666729649476935 139.74667824257136 7.55 35.666797281852745 139.74671903882063 7.55 35.66676390698286 139.7468109756089 7.55 35.666738117556285 139.74679686486473 7.55 35.66671863940601 139.74678506692635 7.55 35.66671124195493 139.7467764592219 7.55 35.66670519362468 139.74676376313369 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66670519362468 139.74676376313369 7.55 35.66671124195493 139.7467764592219 7.55 35.66671124195493 139.7467764592219 25.19 35.66670519362468 139.74676376313369 25.19 35.66670519362468 139.74676376313369 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66671124195493 139.7467764592219 7.55 35.66671863940601 139.74678506692635 7.55 35.66671863940601 139.74678506692635 25.19 35.66671124195493 139.7467764592219 25.19 35.66671124195493 139.7467764592219 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66671863940601 139.74678506692635 7.55 35.666738117556285 139.74679686486473 7.55 35.666738117556285 139.74679686486473 25.19 35.66671863940601 139.74678506692635 25.19 35.66671863940601 139.74678506692635 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666738117556285 139.74679686486473 7.55 35.66676390698286 139.7468109756089 7.55 35.66676390698286 139.7468109756089 25.19 35.666738117556285 139.74679686486473 25.19 35.666738117556285 139.74679686486473 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676390698286 139.7468109756089 7.55 35.666797281852745 139.74671903882063 7.55 35.666797281852745 139.74671903882063 25.19 35.66676390698286 139.7468109756089 25.19 35.66676390698286 139.7468109756089 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666797281852745 139.74671903882063 7.55 35.666729649476935 139.74667824257136 7.55 35.666729649476935 139.74667824257136 25.19 35.666797281852745 139.74671903882063 25.19 35.666797281852745 139.74671903882063 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666729649476935 139.74667824257136 7.55 35.6667062543843 139.7467347116557 7.55 35.6667062543843 139.7467347116557 25.19 35.666729649476935 139.74667824257136 25.19 35.666729649476935 139.74667824257136 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6667062543843 139.7467347116557 7.55 35.666703650807804 139.74674918440456 7.55 35.666703650807804 139.74674918440456 25.19 35.6667062543843 139.7467347116557 25.19 35.6667062543843 139.7467347116557 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666703650807804 139.74674918440456 7.55 35.66670519362468 139.74676376313369 7.55 35.66670519362468 139.74676376313369 25.19 35.666703650807804 139.74674918440456 25.19 35.666703650807804 139.74674918440456 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66670519362468 139.74676376313369 25.19 35.66671124195493 139.7467764592219 25.19 35.66671863940601 139.74678506692635 25.19 35.666738117556285 139.74679686486473 25.19 35.66676390698286 139.7468109756089 25.19 35.666797281852745 139.74671903882063 25.19 35.666729649476935 139.74667824257136 25.19 35.6667062543843 139.7467347116557 25.19 35.666703650807804 139.74674918440456 25.19 35.66670519362468 139.74676376313369 25.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ec5e8c7c-4d58-4c0d-a71a-d67a9ce1be6f"/>
							<gml:surfaceMember xlink:href="#poly-a17f7a72-40ca-4964-b680-10f4852f560d"/>
							<gml:surfaceMember xlink:href="#poly-57cc65ae-3a03-485e-8108-5a3bf5308847"/>
							<gml:surfaceMember xlink:href="#poly-46d4940e-d1c0-42d4-9c4c-92e7cc4ae0f1"/>
							<gml:surfaceMember xlink:href="#poly-66b5a41b-db90-4133-89ff-c627f787b767"/>
							<gml:surfaceMember xlink:href="#poly-8b2a79b5-2a79-41c0-9b8c-78b6de9e5a3a"/>
							<gml:surfaceMember xlink:href="#poly-91c5c310-ccaa-4e97-8af4-80ee1eb90daf"/>
							<gml:surfaceMember xlink:href="#poly-1a6245ac-5b3b-46bc-aa99-82ea3ef75f24"/>
							<gml:surfaceMember xlink:href="#poly-dec8f625-482f-4b99-bbe4-997593e681a8"/>
							<gml:surfaceMember xlink:href="#poly-dab65ede-6eb4-459f-b41b-fb3fa6ba1a48"/>
							<gml:surfaceMember xlink:href="#poly-ee099298-411d-4659-a88a-acebcd643060"/>
							<gml:surfaceMember xlink:href="#poly-099e0fbd-0824-424d-8419-a824d3e63f96"/>
							<gml:surfaceMember xlink:href="#poly-2ba40a60-a35c-4b99-9c36-e2a598659ebf"/>
							<gml:surfaceMember xlink:href="#poly-f3f0f53d-f91c-4e5a-b4ed-463dffb3001d"/>
							<gml:surfaceMember xlink:href="#poly-bc90759e-4e21-416b-8510-8da3642675af"/>
							<gml:surfaceMember xlink:href="#poly-28444ca8-5df8-45ba-8a2d-c94828c61cb7"/>
							<gml:surfaceMember xlink:href="#poly-672dab40-73d5-483e-afb3-8f2befd0c3a4"/>
							<gml:surfaceMember xlink:href="#poly-3c580898-7ac1-4c78-b743-1f3f0b35a125"/>
							<gml:surfaceMember xlink:href="#poly-c678b0ac-6f5a-4a98-bd64-b9495547f151"/>
							<gml:surfaceMember xlink:href="#poly-6ee6cdf5-9d1b-4ca8-931f-b518a4a2a875"/>
							<gml:surfaceMember xlink:href="#poly-0c44a098-b576-4fde-8f0c-0ba2d4a8fab6"/>
							<gml:surfaceMember xlink:href="#poly-59c5a6e5-e3c3-4e7e-a629-ddbea6724333"/>
							<gml:surfaceMember xlink:href="#poly-13435df4-4f25-4840-9155-3d9c98c4011f"/>
							<gml:surfaceMember xlink:href="#poly-65af63d2-2dd7-4e8e-9f32-d2ab66f559c4"/>
							<gml:surfaceMember xlink:href="#poly-514bdfd1-64c2-40c2-9f10-79ca3a8040cb"/>
							<gml:surfaceMember xlink:href="#poly-084c7438-946e-4df5-a753-dd9ea034943e"/>
							<gml:surfaceMember xlink:href="#poly-2045b589-f0a1-47dd-aa92-0edb86bd467b"/>
							<gml:surfaceMember xlink:href="#poly-9f90c85c-3511-4bed-9d38-1f6756fc68ac"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_121b0e9f-8010-47f5-b722-8ff71434eede_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-337ca0bb-1915-4108-bf8d-3410d6d80bde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-337ca0bb-1915-4108-bf8d-3410d6d80bde_0">
											<gml:posList>35.666763906982844 139.7468109756089 22.5 35.66676952944381 139.74679549442882 24.837 35.666763906982844 139.7468109756089 24.837 35.666763906982844 139.7468109756089 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c984bb1-e5e2-4e68-8bb6-fc096a0d7d11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c984bb1-e5e2-4e68-8bb6-fc096a0d7d11_0">
											<gml:posList>35.666744717860745 139.74679999473753 22.5 35.66674456491309 139.74680039254991 24.837 35.66675034933405 139.7467845135507 24.837 35.666744717860745 139.74679999473753 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e404055b-4834-455d-b853-707604a6875b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e404055b-4834-455d-b853-707604a6875b_0">
											<gml:posList>35.666744717860745 139.74679999473753 22.5 35.66674456491309 139.74680039254991 22.5 35.66674456491309 139.74680039254991 24.837 35.666744717860745 139.74679999473753 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29d3e3fc-33b5-48ce-a9c0-34dda328899b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29d3e3fc-33b5-48ce-a9c0-34dda328899b_0">
											<gml:posList>35.66674456491309 139.74680039254991 22.5 35.666763906982844 139.7468109756089 24.837 35.66674456491309 139.74680039254991 24.837 35.66674456491309 139.74680039254991 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3370628-4466-42d5-b2cf-ac141308c0e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3370628-4466-42d5-b2cf-ac141308c0e3_0">
											<gml:posList>35.66674456491309 139.74680039254991 22.5 35.666763906982844 139.7468109756089 22.5 35.666763906982844 139.7468109756089 24.837 35.66674456491309 139.74680039254991 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ef9cff1-d527-4dd3-9253-24fba60d4eff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ef9cff1-d527-4dd3-9253-24fba60d4eff_0">
											<gml:posList>35.666763906982844 139.7468109756089 22.5 35.666744717860745 139.74679999473753 22.5 35.66676952944381 139.74679549442882 24.837 35.666763906982844 139.7468109756089 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51f0b70b-2de7-4938-92c7-816b263edeb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51f0b70b-2de7-4938-92c7-816b263edeb0_0">
											<gml:posList>35.66676952944381 139.74679549442882 24.837 35.666744717860745 139.74679999473753 22.5 35.66675034933405 139.7467845135507 24.837 35.66676952944381 139.74679549442882 24.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6527127d-73a9-42b5-9634-993128532cb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6527127d-73a9-42b5-9634-993128532cb2_0">
											<gml:posList>35.66674456491309 139.74680039254991 22.5 35.666744717860745 139.74679999473753 22.5 35.666763906982844 139.7468109756089 22.5 35.66674456491309 139.74680039254991 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d960420d-8248-4792-8c4c-c6369fb17d75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d960420d-8248-4792-8c4c-c6369fb17d75_0">
											<gml:posList>35.66674456491309 139.74680039254991 24.837 35.66676952944381 139.74679549442882 24.837 35.66675034933405 139.7467845135507 24.837 35.66674456491309 139.74680039254991 24.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90f6e735-2c3b-4e55-8c59-96a4ecfecd55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90f6e735-2c3b-4e55-8c59-96a4ecfecd55_0">
											<gml:posList>35.66674456491309 139.74680039254991 24.837 35.666763906982844 139.7468109756089 24.837 35.66676952944381 139.74679549442882 24.837 35.66674456491309 139.74680039254991 24.837</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3757cb48-ab29-48e4-8cec-07b69f2929b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3757cb48-ab29-48e4-8cec-07b69f2929b8_0">
											<gml:posList>35.666773873486 139.74673199869363 26.391 35.66677790286633 139.74671979981875 27.967 35.66677790286633 139.74671979981875 26.391 35.666773873486 139.74673199869363 26.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a04cbaab-f1d4-4267-aefe-eabb52dbdf31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a04cbaab-f1d4-4267-aefe-eabb52dbdf31_0">
											<gml:posList>35.666773873486 139.74673199869363 26.391 35.666773873486 139.74673199869363 27.967 35.66677790286633 139.74671979981875 27.967 35.666773873486 139.74673199869363 26.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-164d979b-ea6e-4d75-87c3-5514d1e649e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-164d979b-ea6e-4d75-87c3-5514d1e649e7_0">
											<gml:posList>35.666773873486 139.74673199869363 26.391 35.666784468407414 139.74673725608113 27.967 35.666773873486 139.74673199869363 27.967 35.666773873486 139.74673199869363 26.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19d9d530-d5e5-4c39-a7ce-72cea349231d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19d9d530-d5e5-4c39-a7ce-72cea349231d_0">
											<gml:posList>35.666773873486 139.74673199869363 26.391 35.666784468407414 139.74673725608113 26.391 35.666784468407414 139.74673725608113 27.967 35.666773873486 139.74673199869363 26.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fd374a0-d80e-4c38-a5e5-cb67a2ee3f8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fd374a0-d80e-4c38-a5e5-cb67a2ee3f8a_0">
											<gml:posList>35.66678849778826 139.7467250572049 27.967 35.66677790286633 139.74671979981875 27.967 35.666773873486 139.74673199869363 27.967 35.66678849778826 139.7467250572049 27.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23446921-6a92-49ee-b519-216c20a881c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23446921-6a92-49ee-b519-216c20a881c5_0">
											<gml:posList>35.666784468407414 139.74673725608113 27.967 35.66678849778826 139.7467250572049 27.967 35.666773873486 139.74673199869363 27.967 35.666784468407414 139.74673725608113 27.967</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-198df66b-5680-462d-950b-dc9f053abd48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-198df66b-5680-462d-950b-dc9f053abd48_0">
											<gml:posList>35.66678849778826 139.7467250572049 26.391 35.66677790286633 139.74671979981875 27.967 35.66678849778826 139.7467250572049 27.967 35.66678849778826 139.7467250572049 26.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45c19b50-d947-4df0-b8dc-7627313d880c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45c19b50-d947-4df0-b8dc-7627313d880c_0">
											<gml:posList>35.66678849778826 139.7467250572049 26.391 35.66677790286633 139.74671979981875 26.391 35.66677790286633 139.74671979981875 27.967 35.66678849778826 139.7467250572049 26.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4febd2e-1869-44b9-8451-800e6fe12453">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4febd2e-1869-44b9-8451-800e6fe12453_0">
											<gml:posList>35.666784468407414 139.74673725608113 26.391 35.66678849778826 139.7467250572049 27.967 35.666784468407414 139.74673725608113 27.967 35.666784468407414 139.74673725608113 26.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f984635-1f43-47c3-a8e8-6a6a872e0915">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f984635-1f43-47c3-a8e8-6a6a872e0915_0">
											<gml:posList>35.666784468407414 139.74673725608113 26.391 35.66678849778826 139.7467250572049 26.391 35.66678849778826 139.7467250572049 27.967 35.666784468407414 139.74673725608113 26.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6455ec26-6514-41c3-85e9-365084db05cb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66677790286633 139.74671979981875 26.391 35.66678849778826 139.7467250572049 26.391 35.666784468407414 139.74673725608113 26.391 35.666773873486 139.74673199869363 26.391 35.66677790286633 139.74671979981875 26.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ec5e8c7c-4d58-4c0d-a71a-d67a9ce1be6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec5e8c7c-4d58-4c0d-a71a-d67a9ce1be6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec5e8c7c-4d58-4c0d-a71a-d67a9ce1be6f">
											<gml:posList>35.66670519362468 139.74676376313369 7.55 35.6667036508078 139.74674918440456 7.55 35.66670625438428 139.7467347116557 7.55 35.66672964947693 139.74667824257133 7.55 35.66679728185272 139.74671903882063 7.55 35.666763906982844 139.7468109756089 7.55 35.666738117556285 139.74679686486473 7.55 35.666718639406 139.74678506692635 7.55 35.66671124195494 139.74677645922188 7.55 35.66670519362468 139.74676376313369 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a17f7a72-40ca-4964-b680-10f4852f560d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a17f7a72-40ca-4964-b680-10f4852f560d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a17f7a72-40ca-4964-b680-10f4852f560d">
											<gml:posList>35.66672455866636 139.7467561427472 26.454 35.6667036508078 139.74674918440456 22.5 35.66670519362468 139.74676376313369 22.5 35.66672455866636 139.7467561427472 26.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57cc65ae-3a03-485e-8108-5a3bf5308847">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57cc65ae-3a03-485e-8108-5a3bf5308847">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57cc65ae-3a03-485e-8108-5a3bf5308847">
											<gml:posList>35.66672455866636 139.7467561427472 26.454 35.66670625438428 139.7467347116557 22.5 35.6667036508078 139.74674918440456 22.5 35.66672455866636 139.7467561427472 26.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46d4940e-d1c0-42d4-9c4c-92e7cc4ae0f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46d4940e-d1c0-42d4-9c4c-92e7cc4ae0f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46d4940e-d1c0-42d4-9c4c-92e7cc4ae0f1">
											<gml:posList>35.66672455866636 139.7467561427472 26.454 35.66670519362468 139.74676376313369 22.5 35.66671124195494 139.74677645922188 22.5 35.66672455866636 139.7467561427472 26.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66b5a41b-db90-4133-89ff-c627f787b767">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66b5a41b-db90-4133-89ff-c627f787b767">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66b5a41b-db90-4133-89ff-c627f787b767">
											<gml:posList>35.66671124195494 139.74677645922188 22.5 35.666718639406 139.74678506692635 22.5 35.66672455866636 139.7467561427472 26.454 35.66671124195494 139.74677645922188 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b2a79b5-2a79-41c0-9b8c-78b6de9e5a3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b2a79b5-2a79-41c0-9b8c-78b6de9e5a3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b2a79b5-2a79-41c0-9b8c-78b6de9e5a3a">
											<gml:posList>35.66670625438428 139.7467347116557 22.5 35.66675074176282 139.74669096658516 26.454 35.66672964947693 139.74667824257133 22.5 35.66670625438428 139.7467347116557 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-91c5c310-ccaa-4e97-8af4-80ee1eb90daf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91c5c310-ccaa-4e97-8af4-80ee1eb90daf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91c5c310-ccaa-4e97-8af4-80ee1eb90daf">
											<gml:posList>35.66670625438428 139.7467347116557 22.5 35.66672455866636 139.7467561427472 26.454 35.66675074176282 139.74669096658516 26.454 35.66670625438428 139.7467347116557 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a6245ac-5b3b-46bc-aa99-82ea3ef75f24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a6245ac-5b3b-46bc-aa99-82ea3ef75f24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a6245ac-5b3b-46bc-aa99-82ea3ef75f24">
											<gml:posList>35.66672455866636 139.7467561427472 26.454 35.666727550311336 139.74675486925517 26.454 35.66675175393112 139.74669462163817 26.454 35.66675074176282 139.74669096658516 26.454 35.66672455866636 139.7467561427472 26.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dec8f625-482f-4b99-bbe4-997593e681a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dec8f625-482f-4b99-bbe4-997593e681a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dec8f625-482f-4b99-bbe4-997593e681a8">
											<gml:posList>35.666718639406 139.74678506692635 22.5 35.666738117556285 139.74679686486473 22.5 35.666763906982844 139.7468109756089 22.5 35.666718639406 139.74678506692635 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dab65ede-6eb4-459f-b41b-fb3fa6ba1a48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dab65ede-6eb4-459f-b41b-fb3fa6ba1a48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dab65ede-6eb4-459f-b41b-fb3fa6ba1a48">
											<gml:posList>35.666718639406 139.74678506692635 22.5 35.666763906982844 139.7468109756089 22.5 35.66677341568267 139.74678478689032 26.454 35.666718639406 139.74678506692635 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee099298-411d-4659-a88a-acebcd643060">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee099298-411d-4659-a88a-acebcd643060">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee099298-411d-4659-a88a-acebcd643060">
											<gml:posList>35.666718639406 139.74678506692635 22.5 35.66677341568267 139.74678478689032 26.454 35.66672455866636 139.7467561427472 26.454 35.666718639406 139.74678506692635 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-099e0fbd-0824-424d-8419-a824d3e63f96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-099e0fbd-0824-424d-8419-a824d3e63f96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-099e0fbd-0824-424d-8419-a824d3e63f96">
											<gml:posList>35.66677341568267 139.74678478689032 26.454 35.66677229533646 139.74678110986042 26.454 35.666727550311336 139.74675486925517 26.454 35.66672455866636 139.7467561427472 26.454 35.66677341568267 139.74678478689032 26.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ba40a60-a35c-4b99-9c36-e2a598659ebf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ba40a60-a35c-4b99-9c36-e2a598659ebf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ba40a60-a35c-4b99-9c36-e2a598659ebf">
											<gml:posList>35.666794362325945 139.74672032328297 26.391 35.66675175393112 139.74669462163817 26.391 35.666727550311336 139.74675486925517 26.391 35.66677229533646 139.74678110986042 26.391 35.666794362325945 139.74672032328297 26.391</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3f0f53d-f91c-4e5a-b4ed-463dffb3001d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3f0f53d-f91c-4e5a-b4ed-463dffb3001d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3f0f53d-f91c-4e5a-b4ed-463dffb3001d">
											<gml:posList>35.66675074176282 139.74669096658516 26.454 35.66675175393112 139.74669462163817 26.454 35.666794362325945 139.74672032328297 26.454 35.66679728185272 139.74671903882063 26.454 35.66675074176282 139.74669096658516 26.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc90759e-4e21-416b-8510-8da3642675af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc90759e-4e21-416b-8510-8da3642675af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc90759e-4e21-416b-8510-8da3642675af">
											<gml:posList>35.66679728185272 139.74671903882063 26.454 35.666794362325945 139.74672032328297 26.454 35.66677229533646 139.74678110986042 26.454 35.66677341568267 139.74678478689032 26.454 35.66679728185272 139.74671903882063 26.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28444ca8-5df8-45ba-8a2d-c94828c61cb7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28444ca8-5df8-45ba-8a2d-c94828c61cb7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28444ca8-5df8-45ba-8a2d-c94828c61cb7">
											<gml:posList>35.6667036508078 139.74674918440456 7.55 35.66670519362468 139.74676376313369 7.55 35.66670519362468 139.74676376313369 22.5 35.6667036508078 139.74674918440456 22.5 35.6667036508078 139.74674918440456 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-672dab40-73d5-483e-afb3-8f2befd0c3a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-672dab40-73d5-483e-afb3-8f2befd0c3a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-672dab40-73d5-483e-afb3-8f2befd0c3a4">
											<gml:posList>35.66670625438428 139.7467347116557 7.55 35.6667036508078 139.74674918440456 7.55 35.6667036508078 139.74674918440456 22.5 35.66670625438428 139.7467347116557 22.5 35.66670625438428 139.7467347116557 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c580898-7ac1-4c78-b743-1f3f0b35a125">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c580898-7ac1-4c78-b743-1f3f0b35a125">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c580898-7ac1-4c78-b743-1f3f0b35a125">
											<gml:posList>35.66670519362468 139.74676376313369 7.55 35.66671124195494 139.74677645922188 7.55 35.66671124195494 139.74677645922188 22.5 35.66670519362468 139.74676376313369 22.5 35.66670519362468 139.74676376313369 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c678b0ac-6f5a-4a98-bd64-b9495547f151">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c678b0ac-6f5a-4a98-bd64-b9495547f151">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c678b0ac-6f5a-4a98-bd64-b9495547f151">
											<gml:posList>35.66671124195494 139.74677645922188 7.55 35.666718639406 139.74678506692635 7.55 35.666718639406 139.74678506692635 22.5 35.66671124195494 139.74677645922188 22.5 35.66671124195494 139.74677645922188 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ee6cdf5-9d1b-4ca8-931f-b518a4a2a875">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ee6cdf5-9d1b-4ca8-931f-b518a4a2a875">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ee6cdf5-9d1b-4ca8-931f-b518a4a2a875">
											<gml:posList>35.66672964947693 139.74667824257133 7.55 35.66670625438428 139.7467347116557 7.55 35.66670625438428 139.7467347116557 22.5 35.66672964947693 139.74667824257133 22.5 35.66672964947693 139.74667824257133 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c44a098-b576-4fde-8f0c-0ba2d4a8fab6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c44a098-b576-4fde-8f0c-0ba2d4a8fab6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c44a098-b576-4fde-8f0c-0ba2d4a8fab6">
											<gml:posList>35.666718639406 139.74678506692635 7.55 35.666738117556285 139.74679686486473 7.55 35.666738117556285 139.74679686486473 22.5 35.666718639406 139.74678506692635 22.5 35.666718639406 139.74678506692635 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59c5a6e5-e3c3-4e7e-a629-ddbea6724333">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59c5a6e5-e3c3-4e7e-a629-ddbea6724333">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59c5a6e5-e3c3-4e7e-a629-ddbea6724333">
											<gml:posList>35.666727550311336 139.74675486925517 26.454 35.666727550311336 139.74675486925517 26.391 35.66675175393112 139.74669462163817 26.391 35.66675175393112 139.74669462163817 26.454 35.666727550311336 139.74675486925517 26.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13435df4-4f25-4840-9155-3d9c98c4011f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13435df4-4f25-4840-9155-3d9c98c4011f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13435df4-4f25-4840-9155-3d9c98c4011f">
											<gml:posList>35.66677229533646 139.74678110986042 26.454 35.66677229533646 139.74678110986042 26.391 35.666727550311336 139.74675486925517 26.391 35.666727550311336 139.74675486925517 26.454 35.66677229533646 139.74678110986042 26.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65af63d2-2dd7-4e8e-9f32-d2ab66f559c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65af63d2-2dd7-4e8e-9f32-d2ab66f559c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65af63d2-2dd7-4e8e-9f32-d2ab66f559c4">
											<gml:posList>35.666763906982844 139.7468109756089 22.5 35.666738117556285 139.74679686486473 22.5 35.666738117556285 139.74679686486473 7.55 35.666763906982844 139.7468109756089 7.55 35.666763906982844 139.7468109756089 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-514bdfd1-64c2-40c2-9f10-79ca3a8040cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-514bdfd1-64c2-40c2-9f10-79ca3a8040cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-514bdfd1-64c2-40c2-9f10-79ca3a8040cb">
											<gml:posList>35.66672964947693 139.74667824257133 22.5 35.66675074176282 139.74669096658516 26.454 35.66679728185272 139.74671903882063 26.454 35.66679728185272 139.74671903882063 7.55 35.66672964947693 139.74667824257133 7.55 35.66672964947693 139.74667824257133 22.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-084c7438-946e-4df5-a753-dd9ea034943e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-084c7438-946e-4df5-a753-dd9ea034943e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-084c7438-946e-4df5-a753-dd9ea034943e">
											<gml:posList>35.66675175393112 139.74669462163817 26.454 35.66675175393112 139.74669462163817 26.391 35.666794362325945 139.74672032328297 26.391 35.666794362325945 139.74672032328297 26.454 35.66675175393112 139.74669462163817 26.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2045b589-f0a1-47dd-aa92-0edb86bd467b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2045b589-f0a1-47dd-aa92-0edb86bd467b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2045b589-f0a1-47dd-aa92-0edb86bd467b">
											<gml:posList>35.66679728185272 139.74671903882063 26.454 35.66677341568267 139.74678478689032 26.454 35.666763906982844 139.7468109756089 22.5 35.666763906982844 139.7468109756089 7.55 35.66679728185272 139.74671903882063 7.55 35.66679728185272 139.74671903882063 26.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f90c85c-3511-4bed-9d38-1f6756fc68ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f90c85c-3511-4bed-9d38-1f6756fc68ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f90c85c-3511-4bed-9d38-1f6756fc68ac">
											<gml:posList>35.666794362325945 139.74672032328297 26.454 35.666794362325945 139.74672032328297 26.391 35.66677229533646 139.74678110986042 26.391 35.66677229533646 139.74678110986042 26.454 35.666794362325945 139.74672032328297 26.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4202</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">75.9446</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>