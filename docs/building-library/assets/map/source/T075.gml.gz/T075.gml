<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_12dc9926-5dfc-4b8d-981c-91adf2cff827">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">16.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672055639747946 139.7424371844574 0 35.67206466533342 139.7424290108672 0 35.672107164196376 139.742499527706 0 35.672131504676564 139.74253990822913 0 35.67218254167479 139.74249378649253 0 35.67215820114594 139.74245336177177 0 35.67214434771603 139.7424303676103 0 35.67212903221548 139.74240493383834 0 35.67210024231744 139.74235713516035 0 35.67204017084856 139.74241152995643 0 35.672055639747946 139.7424371844574 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672055639747946 139.7424371844574 9.31 35.67204017084856 139.74241152995643 9.31 35.67210024231744 139.74235713516035 9.31 35.67212903221548 139.74240493383834 9.31 35.67214434771603 139.7424303676103 9.31 35.67215820114594 139.74245336177177 9.31 35.67218254167479 139.74249378649253 9.31 35.672131504676564 139.74253990822913 9.31 35.672107164196376 139.742499527706 9.31 35.67206466533342 139.7424290108672 9.31 35.672055639747946 139.7424371844574 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672055639747946 139.7424371844574 9.31 35.67206466533342 139.7424290108672 9.31 35.67206466533342 139.7424290108672 24.32 35.672055639747946 139.7424371844574 24.32 35.672055639747946 139.7424371844574 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67206466533342 139.7424290108672 9.31 35.672107164196376 139.742499527706 9.31 35.672107164196376 139.742499527706 24.32 35.67206466533342 139.7424290108672 24.32 35.67206466533342 139.7424290108672 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672107164196376 139.742499527706 9.31 35.672131504676564 139.74253990822913 9.31 35.672131504676564 139.74253990822913 24.32 35.672107164196376 139.742499527706 24.32 35.672107164196376 139.742499527706 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672131504676564 139.74253990822913 9.31 35.67218254167479 139.74249378649253 9.31 35.67218254167479 139.74249378649253 24.32 35.672131504676564 139.74253990822913 24.32 35.672131504676564 139.74253990822913 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67218254167479 139.74249378649253 9.31 35.67215820114594 139.74245336177177 9.31 35.67215820114594 139.74245336177177 24.32 35.67218254167479 139.74249378649253 24.32 35.67218254167479 139.74249378649253 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67215820114594 139.74245336177177 9.31 35.67214434771603 139.7424303676103 9.31 35.67214434771603 139.7424303676103 24.32 35.67215820114594 139.74245336177177 24.32 35.67215820114594 139.74245336177177 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67214434771603 139.7424303676103 9.31 35.67212903221548 139.74240493383834 9.31 35.67212903221548 139.74240493383834 24.32 35.67214434771603 139.7424303676103 24.32 35.67214434771603 139.7424303676103 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212903221548 139.74240493383834 9.31 35.67210024231744 139.74235713516035 9.31 35.67210024231744 139.74235713516035 24.32 35.67212903221548 139.74240493383834 24.32 35.67212903221548 139.74240493383834 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67210024231744 139.74235713516035 9.31 35.67204017084856 139.74241152995643 9.31 35.67204017084856 139.74241152995643 24.32 35.67210024231744 139.74235713516035 24.32 35.67210024231744 139.74235713516035 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67204017084856 139.74241152995643 9.31 35.672055639747946 139.7424371844574 9.31 35.672055639747946 139.7424371844574 24.32 35.67204017084856 139.74241152995643 24.32 35.67204017084856 139.74241152995643 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672055639747946 139.7424371844574 24.32 35.67206466533342 139.7424290108672 24.32 35.672107164196376 139.742499527706 24.32 35.672131504676564 139.74253990822913 24.32 35.67218254167479 139.74249378649253 24.32 35.67215820114594 139.74245336177177 24.32 35.67214434771603 139.7424303676103 24.32 35.67212903221548 139.74240493383834 24.32 35.67210024231744 139.74235713516035 24.32 35.67204017084856 139.74241152995643 24.32 35.672055639747946 139.7424371844574 24.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7cd87345-6e53-429b-8760-ecd9fb9f8e55"/>
							<gml:surfaceMember xlink:href="#poly-1383eaa4-7161-4e44-949d-cd2cbf9645b2"/>
							<gml:surfaceMember xlink:href="#poly-fa0d4472-5d82-4d85-9f5d-2905f627ff4d"/>
							<gml:surfaceMember xlink:href="#poly-6fe66b0a-dcbc-4517-8ca6-97ebb69294c2"/>
							<gml:surfaceMember xlink:href="#poly-dea805e4-0b80-4fe5-af16-a742df3a892f"/>
							<gml:surfaceMember xlink:href="#poly-ae3e55fc-462a-436a-aa1a-5b39d22d1b1f"/>
							<gml:surfaceMember xlink:href="#poly-6dcc8307-d591-41e8-bdba-4232ca82bdbb"/>
							<gml:surfaceMember xlink:href="#poly-ad7891c6-f356-416c-b25f-26d8666369bf"/>
							<gml:surfaceMember xlink:href="#poly-7dd8a637-8339-45fe-8c52-911472077bd8"/>
							<gml:surfaceMember xlink:href="#poly-958171d0-d372-4ca4-b913-070dc6131376"/>
							<gml:surfaceMember xlink:href="#poly-df3068e6-2b3b-4d8b-83aa-32394bdda9d6"/>
							<gml:surfaceMember xlink:href="#poly-a86ae83a-a677-4ee4-9fcd-94c3ef8502ad"/>
							<gml:surfaceMember xlink:href="#poly-8411734c-aaae-4f3d-b40b-5aa22cc8ad52"/>
							<gml:surfaceMember xlink:href="#poly-8447a939-bbbe-4db1-af1d-456014f498c1"/>
							<gml:surfaceMember xlink:href="#poly-736828c6-1ef3-4709-a227-35dfab29a0d9"/>
							<gml:surfaceMember xlink:href="#poly-3da4bbfb-9822-4300-8329-4d25b1b49115"/>
							<gml:surfaceMember xlink:href="#poly-a5fc9fc1-5c2f-4b2d-900a-fd02d6660210"/>
							<gml:surfaceMember xlink:href="#poly-b7df69ea-c9dc-483e-9dca-e84f10a0f3a3"/>
							<gml:surfaceMember xlink:href="#poly-ef7fa790-b9a8-46fe-b0e4-36232dac1b01"/>
							<gml:surfaceMember xlink:href="#poly-e6180558-d9c6-4a02-b406-a376f43868df"/>
							<gml:surfaceMember xlink:href="#poly-123a0e1a-9257-446a-829e-571ef9a1f5c0"/>
							<gml:surfaceMember xlink:href="#poly-c9c5145d-4b6e-40fc-9df1-695e4136a8c0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7cd87345-6e53-429b-8760-ecd9fb9f8e55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cd87345-6e53-429b-8760-ecd9fb9f8e55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cd87345-6e53-429b-8760-ecd9fb9f8e55">
											<gml:posList>35.67205563974793 139.74243718445737 9.31 35.672040170848554 139.7424115299564 9.31 35.672100242317434 139.74235713516035 9.31 35.672182541674765 139.74249378649253 9.31 35.672131504676564 139.7425399082291 9.31 35.67206465631967 139.7424290108774 9.31 35.67205563974793 139.74243718445737 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1383eaa4-7161-4e44-949d-cd2cbf9645b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1383eaa4-7161-4e44-949d-cd2cbf9645b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1383eaa4-7161-4e44-949d-cd2cbf9645b2">
											<gml:posList>35.67214434771604 139.7424303676103 25.651 35.67212903221547 139.74240493383834 25.651 35.67210913447744 139.74242292905757 25.651 35.67212445898797 139.74244836281645 25.651 35.67214434771604 139.7424303676103 25.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa0d4472-5d82-4d85-9f5d-2905f627ff4d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa0d4472-5d82-4d85-9f5d-2905f627ff4d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa0d4472-5d82-4d85-9f5d-2905f627ff4d">
											<gml:posList>35.672100242317434 139.74235713516035 25.051 35.672040170848554 139.7424115299564 25.051 35.67205563974793 139.74243718445737 25.051 35.67206465631967 139.7424290108774 25.051 35.672107164196376 139.742499527706 25.051 35.67210760835727 139.74249087779512 25.051 35.67209809421847 139.742472761275 25.051 35.67212445898797 139.74244836281645 25.051 35.67210913447744 139.74242292905757 25.051 35.67212903221547 139.74240493383834 25.051 35.672100242317434 139.74235713516035 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6fe66b0a-dcbc-4517-8ca6-97ebb69294c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fe66b0a-dcbc-4517-8ca6-97ebb69294c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fe66b0a-dcbc-4517-8ca6-97ebb69294c2">
											<gml:posList>35.67214047855415 139.74243929757108 25.051 35.672150001711664 139.74245741408657 25.051 35.67215819213223 139.74245336178197 25.051 35.67214434771604 139.7424303676103 25.051 35.67214047855415 139.74243929757108 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dea805e4-0b80-4fe5-af16-a742df3a892f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dea805e4-0b80-4fe5-af16-a742df3a892f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dea805e4-0b80-4fe5-af16-a742df3a892f">
											<gml:posList>35.67212445898797 139.74244836281645 25.051 35.67209809421847 139.742472761275 25.051 35.67214047855415 139.74243929757108 25.051 35.67214434771604 139.7424303676103 25.051 35.67212445898797 139.74244836281645 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae3e55fc-462a-436a-aa1a-5b39d22d1b1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae3e55fc-462a-436a-aa1a-5b39d22d1b1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae3e55fc-462a-436a-aa1a-5b39d22d1b1f">
											<gml:posList>35.67209809421847 139.742472761275 25.951 35.67210760835727 139.74249087779512 25.951 35.672150001711664 139.74245741408657 25.951 35.67214047855415 139.74243929757108 25.951 35.67209809421847 139.742472761275 25.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6dcc8307-d591-41e8-bdba-4232ca82bdbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dcc8307-d591-41e8-bdba-4232ca82bdbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dcc8307-d591-41e8-bdba-4232ca82bdbb">
											<gml:posList>35.672150001711664 139.74245741408657 25.051 35.67210760835727 139.74249087779512 25.051 35.672107164196376 139.742499527706 25.051 35.67215819213223 139.74245336178197 25.051 35.672150001711664 139.74245741408657 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad7891c6-f356-416c-b25f-26d8666369bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad7891c6-f356-416c-b25f-26d8666369bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad7891c6-f356-416c-b25f-26d8666369bf">
											<gml:posList>35.672182541674765 139.74249378649253 17.34 35.67215819213223 139.74245336178197 25.051 35.672107164196376 139.742499527706 24.951 35.672131504676564 139.7425399082291 17.34 35.672182541674765 139.74249378649253 17.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7dd8a637-8339-45fe-8c52-911472077bd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dd8a637-8339-45fe-8c52-911472077bd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dd8a637-8339-45fe-8c52-911472077bd8">
											<gml:posList>35.672040170848554 139.7424115299564 25.051 35.672100242317434 139.74235713516035 25.051 35.672100242317434 139.74235713516035 9.31 35.672040170848554 139.7424115299564 9.31 35.672040170848554 139.7424115299564 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-958171d0-d372-4ca4-b913-070dc6131376">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-958171d0-d372-4ca4-b913-070dc6131376">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-958171d0-d372-4ca4-b913-070dc6131376">
											<gml:posList>35.67212903221547 139.74240493383834 25.051 35.67210913447744 139.74242292905757 25.051 35.67210913447744 139.74242292905757 25.651 35.67212903221547 139.74240493383834 25.651 35.67212903221547 139.74240493383834 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df3068e6-2b3b-4d8b-83aa-32394bdda9d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df3068e6-2b3b-4d8b-83aa-32394bdda9d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df3068e6-2b3b-4d8b-83aa-32394bdda9d6">
											<gml:posList>35.67205563974793 139.74243718445737 25.051 35.672040170848554 139.7424115299564 25.051 35.672040170848554 139.7424115299564 9.31 35.67205563974793 139.74243718445737 9.31 35.67205563974793 139.74243718445737 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a86ae83a-a677-4ee4-9fcd-94c3ef8502ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a86ae83a-a677-4ee4-9fcd-94c3ef8502ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a86ae83a-a677-4ee4-9fcd-94c3ef8502ad">
											<gml:posList>35.672182541674765 139.74249378649253 17.34 35.672182541674765 139.74249378649253 9.31 35.672100242317434 139.74235713516035 9.31 35.672100242317434 139.74235713516035 25.051 35.67212903221547 139.74240493383834 25.051 35.67212903221547 139.74240493383834 25.651 35.67214434771604 139.7424303676103 25.651 35.67214434771604 139.7424303676103 25.051 35.67215819213223 139.74245336178197 25.051 35.672182541674765 139.74249378649253 17.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8411734c-aaae-4f3d-b40b-5aa22cc8ad52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8411734c-aaae-4f3d-b40b-5aa22cc8ad52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8411734c-aaae-4f3d-b40b-5aa22cc8ad52">
											<gml:posList>35.67206465631967 139.7424290108774 25.051 35.67205563974793 139.74243718445737 25.051 35.67205563974793 139.74243718445737 9.31 35.67206465631967 139.7424290108774 9.31 35.67206465631967 139.7424290108774 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8447a939-bbbe-4db1-af1d-456014f498c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8447a939-bbbe-4db1-af1d-456014f498c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8447a939-bbbe-4db1-af1d-456014f498c1">
											<gml:posList>35.67210913447744 139.74242292905757 25.051 35.67212445898797 139.74244836281645 25.051 35.67212445898797 139.74244836281645 25.651 35.67210913447744 139.74242292905757 25.651 35.67210913447744 139.74242292905757 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-736828c6-1ef3-4709-a227-35dfab29a0d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-736828c6-1ef3-4709-a227-35dfab29a0d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-736828c6-1ef3-4709-a227-35dfab29a0d9">
											<gml:posList>35.67212445898797 139.74244836281645 25.051 35.67214434771604 139.7424303676103 25.051 35.67214434771604 139.7424303676103 25.651 35.67212445898797 139.74244836281645 25.651 35.67212445898797 139.74244836281645 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3da4bbfb-9822-4300-8329-4d25b1b49115">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3da4bbfb-9822-4300-8329-4d25b1b49115">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3da4bbfb-9822-4300-8329-4d25b1b49115">
											<gml:posList>35.672150001711664 139.74245741408657 25.051 35.67214047855415 139.74243929757108 25.051 35.67214047855415 139.74243929757108 25.951 35.672150001711664 139.74245741408657 25.951 35.672150001711664 139.74245741408657 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5fc9fc1-5c2f-4b2d-900a-fd02d6660210">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5fc9fc1-5c2f-4b2d-900a-fd02d6660210">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5fc9fc1-5c2f-4b2d-900a-fd02d6660210">
											<gml:posList>35.67214047855415 139.74243929757108 25.051 35.67209809421847 139.742472761275 25.051 35.67209809421847 139.742472761275 25.951 35.67214047855415 139.74243929757108 25.951 35.67214047855415 139.74243929757108 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7df69ea-c9dc-483e-9dca-e84f10a0f3a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7df69ea-c9dc-483e-9dca-e84f10a0f3a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7df69ea-c9dc-483e-9dca-e84f10a0f3a3">
											<gml:posList>35.67210760835727 139.74249087779512 25.051 35.672150001711664 139.74245741408657 25.051 35.672150001711664 139.74245741408657 25.951 35.67210760835727 139.74249087779512 25.951 35.67210760835727 139.74249087779512 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef7fa790-b9a8-46fe-b0e4-36232dac1b01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef7fa790-b9a8-46fe-b0e4-36232dac1b01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef7fa790-b9a8-46fe-b0e4-36232dac1b01">
											<gml:posList>35.672107164196376 139.742499527706 24.951 35.67215819213223 139.74245336178197 25.051 35.672107164196376 139.742499527706 25.051 35.672107164196376 139.742499527706 24.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6180558-d9c6-4a02-b406-a376f43868df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6180558-d9c6-4a02-b406-a376f43868df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6180558-d9c6-4a02-b406-a376f43868df">
											<gml:posList>35.67209809421847 139.742472761275 25.051 35.67210760835727 139.74249087779512 25.051 35.67210760835727 139.74249087779512 25.951 35.67209809421847 139.742472761275 25.951 35.67209809421847 139.742472761275 25.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-123a0e1a-9257-446a-829e-571ef9a1f5c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-123a0e1a-9257-446a-829e-571ef9a1f5c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-123a0e1a-9257-446a-829e-571ef9a1f5c0">
											<gml:posList>35.67206465631967 139.7424290108774 9.31 35.672131504676564 139.7425399082291 9.31 35.672131504676564 139.7425399082291 17.34 35.672107164196376 139.742499527706 24.951 35.672107164196376 139.742499527706 25.051 35.67206465631967 139.7424290108774 25.051 35.67206465631967 139.7424290108774 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9c5145d-4b6e-40fc-9df1-695e4136a8c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9c5145d-4b6e-40fc-9df1-695e4136a8c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9c5145d-4b6e-40fc-9df1-695e4136a8c0">
											<gml:posList>35.672182541674765 139.74249378649253 9.31 35.672182541674765 139.74249378649253 17.34 35.672131504676564 139.7425399082291 17.34 35.672131504676564 139.7425399082291 9.31 35.672182541674765 139.74249378649253 9.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4495</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">118.57275</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>