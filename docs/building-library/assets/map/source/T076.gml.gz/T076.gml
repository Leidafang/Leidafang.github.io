<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_13114d0e-724f-48e0-8a6a-335c02129e9b">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">8.7</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66874402966101 139.738576748805 0 35.66877359979433 139.73860612945904 0 35.668789985305914 139.73858136697126 0 35.66876041516662 139.73855198632037 0 35.66874402966101 139.738576748805 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66874402966101 139.738576748805 16.998 35.66876041516662 139.73855198632037 16.998 35.668789985305914 139.73858136697126 16.998 35.66877359979433 139.73860612945904 16.998 35.66874402966101 139.738576748805 16.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66874402966101 139.738576748805 16.998 35.66877359979433 139.73860612945904 16.998 35.66877359979433 139.73860612945904 25.72 35.66874402966101 139.738576748805 25.72 35.66874402966101 139.738576748805 16.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877359979433 139.73860612945904 16.998 35.668789985305914 139.73858136697126 16.998 35.668789985305914 139.73858136697126 25.72 35.66877359979433 139.73860612945904 25.72 35.66877359979433 139.73860612945904 16.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668789985305914 139.73858136697126 16.998 35.66876041516662 139.73855198632037 16.998 35.66876041516662 139.73855198632037 25.72 35.668789985305914 139.73858136697126 25.72 35.668789985305914 139.73858136697126 16.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876041516662 139.73855198632037 16.998 35.66874402966101 139.738576748805 16.998 35.66874402966101 139.738576748805 25.72 35.66876041516662 139.73855198632037 25.72 35.66876041516662 139.73855198632037 16.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66874402966101 139.738576748805 25.72 35.66877359979433 139.73860612945904 25.72 35.668789985305914 139.73858136697126 25.72 35.66876041516662 139.73855198632037 25.72 35.66874402966101 139.738576748805 25.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7aae0820-c8ee-4683-8e27-a91507cb82e2"/>
							<gml:surfaceMember xlink:href="#poly-aab766c3-1220-4420-b550-1395a765c511"/>
							<gml:surfaceMember xlink:href="#poly-41889268-5f9e-466f-b822-40ee53eb4779"/>
							<gml:surfaceMember xlink:href="#poly-777f776e-8c9b-4b3e-b04a-2259cc1ff537"/>
							<gml:surfaceMember xlink:href="#poly-5a51215e-f09b-47a7-9786-5e615a897037"/>
							<gml:surfaceMember xlink:href="#poly-0b23acc5-f609-4471-a5e7-c276943f034a"/>
							<gml:surfaceMember xlink:href="#poly-1745cf8c-8ebd-491e-9acf-9dcb8d037250"/>
							<gml:surfaceMember xlink:href="#poly-2d6b7e32-1102-4013-b003-8e88932c6085"/>
							<gml:surfaceMember xlink:href="#poly-35e33b40-5627-45c4-b21a-9191611302b4"/>
							<gml:surfaceMember xlink:href="#poly-b2f3e9d4-c50d-4898-ab9e-1227b350927c"/>
							<gml:surfaceMember xlink:href="#poly-223ca960-4ffb-4d41-8fb0-70c6d1157c11"/>
							<gml:surfaceMember xlink:href="#poly-c176a3f4-2ec6-4d67-88dd-f9fa6ddeb4ff"/>
							<gml:surfaceMember xlink:href="#poly-8bb9d595-6451-4ba1-b721-a8a6b9d6a058"/>
							<gml:surfaceMember xlink:href="#poly-2dde3172-71fe-46b6-8777-d84405fbb12c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7aae0820-c8ee-4683-8e27-a91507cb82e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7aae0820-c8ee-4683-8e27-a91507cb82e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7aae0820-c8ee-4683-8e27-a91507cb82e2">
											<gml:posList>35.668744029661006 139.738576748805 16.998 35.66876041516663 139.73855198632035 16.998 35.6687899853059 139.73858136697126 16.998 35.668773599794314 139.73860612945904 16.998 35.668744029661006 139.738576748805 16.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aab766c3-1220-4420-b550-1395a765c511">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aab766c3-1220-4420-b550-1395a765c511">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aab766c3-1220-4420-b550-1395a765c511">
											<gml:posList>35.668744029661006 139.738576748805 22.086 35.66874563395622 139.73857655912653 22.086 35.66876057896128 139.73855395232115 22.086 35.66876041516663 139.73855198632035 22.086 35.668744029661006 139.738576748805 22.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41889268-5f9e-466f-b822-40ee53eb4779">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41889268-5f9e-466f-b822-40ee53eb4779">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41889268-5f9e-466f-b822-40ee53eb4779">
											<gml:posList>35.66876041516663 139.73855198632035 22.086 35.66876057896128 139.73855395232115 22.086 35.6687883900331 139.73858156768512 22.086 35.6687899853059 139.73858136697126 22.086 35.66876041516663 139.73855198632035 22.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-777f776e-8c9b-4b3e-b04a-2259cc1ff537">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-777f776e-8c9b-4b3e-b04a-2259cc1ff537">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-777f776e-8c9b-4b3e-b04a-2259cc1ff537">
											<gml:posList>35.6687883900331 139.73858156768512 21.76 35.66876057896128 139.73855395232115 21.76 35.66874563395622 139.73857655912653 21.76 35.668773426995465 139.7386041745145 21.76 35.6687883900331 139.73858156768512 21.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a51215e-f09b-47a7-9786-5e615a897037">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a51215e-f09b-47a7-9786-5e615a897037">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a51215e-f09b-47a7-9786-5e615a897037">
											<gml:posList>35.668773599794314 139.73860612945904 22.086 35.668773426995465 139.7386041745145 22.086 35.66874563395622 139.73857655912653 22.086 35.668744029661006 139.738576748805 22.086 35.668773599794314 139.73860612945904 22.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b23acc5-f609-4471-a5e7-c276943f034a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b23acc5-f609-4471-a5e7-c276943f034a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b23acc5-f609-4471-a5e7-c276943f034a">
											<gml:posList>35.6687899853059 139.73858136697126 22.086 35.6687883900331 139.73858156768512 22.086 35.668773426995465 139.7386041745145 22.086 35.668773599794314 139.73860612945904 22.086 35.6687899853059 139.73858136697126 22.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1745cf8c-8ebd-491e-9acf-9dcb8d037250">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1745cf8c-8ebd-491e-9acf-9dcb8d037250">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1745cf8c-8ebd-491e-9acf-9dcb8d037250">
											<gml:posList>35.668773426995465 139.7386041745145 22.086 35.668773426995465 139.7386041745145 21.76 35.66874563395622 139.73857655912653 21.76 35.66874563395622 139.73857655912653 22.086 35.668773426995465 139.7386041745145 22.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d6b7e32-1102-4013-b003-8e88932c6085">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d6b7e32-1102-4013-b003-8e88932c6085">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d6b7e32-1102-4013-b003-8e88932c6085">
											<gml:posList>35.66876057896128 139.73855395232115 22.086 35.66876057896128 139.73855395232115 21.76 35.6687883900331 139.73858156768512 21.76 35.6687883900331 139.73858156768512 22.086 35.66876057896128 139.73855395232115 22.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35e33b40-5627-45c4-b21a-9191611302b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35e33b40-5627-45c4-b21a-9191611302b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35e33b40-5627-45c4-b21a-9191611302b4">
											<gml:posList>35.66876041516663 139.73855198632035 16.998 35.668744029661006 139.738576748805 16.998 35.668744029661006 139.738576748805 22.086 35.66876041516663 139.73855198632035 22.086 35.66876041516663 139.73855198632035 16.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2f3e9d4-c50d-4898-ab9e-1227b350927c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2f3e9d4-c50d-4898-ab9e-1227b350927c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2f3e9d4-c50d-4898-ab9e-1227b350927c">
											<gml:posList>35.66874563395622 139.73857655912653 22.086 35.66874563395622 139.73857655912653 21.76 35.66876057896128 139.73855395232115 21.76 35.66876057896128 139.73855395232115 22.086 35.66874563395622 139.73857655912653 22.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-223ca960-4ffb-4d41-8fb0-70c6d1157c11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-223ca960-4ffb-4d41-8fb0-70c6d1157c11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-223ca960-4ffb-4d41-8fb0-70c6d1157c11">
											<gml:posList>35.6687899853059 139.73858136697126 16.998 35.66876041516663 139.73855198632035 16.998 35.66876041516663 139.73855198632035 22.086 35.6687899853059 139.73858136697126 22.086 35.6687899853059 139.73858136697126 16.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c176a3f4-2ec6-4d67-88dd-f9fa6ddeb4ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c176a3f4-2ec6-4d67-88dd-f9fa6ddeb4ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c176a3f4-2ec6-4d67-88dd-f9fa6ddeb4ff">
											<gml:posList>35.668744029661006 139.738576748805 16.998 35.668773599794314 139.73860612945904 16.998 35.668773599794314 139.73860612945904 22.086 35.668744029661006 139.738576748805 22.086 35.668744029661006 139.738576748805 16.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bb9d595-6451-4ba1-b721-a8a6b9d6a058">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bb9d595-6451-4ba1-b721-a8a6b9d6a058">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bb9d595-6451-4ba1-b721-a8a6b9d6a058">
											<gml:posList>35.6687883900331 139.73858156768512 22.086 35.6687883900331 139.73858156768512 21.76 35.668773426995465 139.7386041745145 21.76 35.668773426995465 139.7386041745145 22.086 35.6687883900331 139.73858156768512 22.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2dde3172-71fe-46b6-8777-d84405fbb12c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dde3172-71fe-46b6-8777-d84405fbb12c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dde3172-71fe-46b6-8777-d84405fbb12c">
											<gml:posList>35.668773599794314 139.73860612945904 16.998 35.6687899853059 139.73858136697126 16.998 35.6687899853059 139.73858136697126 22.086 35.668773599794314 139.73860612945904 22.086 35.668773599794314 139.73860612945904 16.998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4259</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>