<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1528f501-baf3-4404-bc10-d1fa3717af69">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">22.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66859990672124 139.7400514073569 0 35.668610476768315 139.74003582017806 0 35.668633182259484 139.7400589572601 0 35.668663163388686 139.7400142964515 0 35.66857719415774 139.73992613887705 0 35.66858556723927 139.7399136471293 0 35.668534870329346 139.73986245273142 0 35.668432409537715 139.7400113616711 0 35.668485270363746 139.74006343726072 0 35.66854667300807 139.73997179444004 0 35.66858238582398 139.74000719950917 0 35.66852144277615 139.74009874239522 0 35.66858314368163 139.7401594237161 0 35.66861964032672 139.74010124611956 0 35.66858733857662 139.74007080773 0 35.66859990672124 139.7400514073569 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66859990672124 139.7400514073569 11.24 35.66858733857662 139.74007080773 11.24 35.66861964032672 139.74010124611956 11.24 35.66858314368163 139.7401594237161 11.24 35.66852144277615 139.74009874239522 11.24 35.66858238582398 139.74000719950917 11.24 35.66854667300807 139.73997179444004 11.24 35.668485270363746 139.74006343726072 11.24 35.668432409537715 139.7400113616711 11.24 35.668534870329346 139.73986245273142 11.24 35.66858556723927 139.7399136471293 11.24 35.66857719415774 139.73992613887705 11.24 35.668663163388686 139.7400142964515 11.24 35.668633182259484 139.7400589572601 11.24 35.668610476768315 139.74003582017806 11.24 35.66859990672124 139.7400514073569 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66859990672124 139.7400514073569 11.24 35.668610476768315 139.74003582017806 11.24 35.668610476768315 139.74003582017806 24.31 35.66859990672124 139.7400514073569 24.31 35.66859990672124 139.7400514073569 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668610476768315 139.74003582017806 11.24 35.668633182259484 139.7400589572601 11.24 35.668633182259484 139.7400589572601 24.31 35.668610476768315 139.74003582017806 24.31 35.668610476768315 139.74003582017806 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668633182259484 139.7400589572601 11.24 35.668663163388686 139.7400142964515 11.24 35.668663163388686 139.7400142964515 24.31 35.668633182259484 139.7400589572601 24.31 35.668633182259484 139.7400589572601 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668663163388686 139.7400142964515 11.24 35.66857719415774 139.73992613887705 11.24 35.66857719415774 139.73992613887705 24.31 35.668663163388686 139.7400142964515 24.31 35.668663163388686 139.7400142964515 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857719415774 139.73992613887705 11.24 35.66858556723927 139.7399136471293 11.24 35.66858556723927 139.7399136471293 24.31 35.66857719415774 139.73992613887705 24.31 35.66857719415774 139.73992613887705 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858556723927 139.7399136471293 11.24 35.668534870329346 139.73986245273142 11.24 35.668534870329346 139.73986245273142 24.31 35.66858556723927 139.7399136471293 24.31 35.66858556723927 139.7399136471293 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668534870329346 139.73986245273142 11.24 35.668432409537715 139.7400113616711 11.24 35.668432409537715 139.7400113616711 24.31 35.668534870329346 139.73986245273142 24.31 35.668534870329346 139.73986245273142 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668432409537715 139.7400113616711 11.24 35.668485270363746 139.74006343726072 11.24 35.668485270363746 139.74006343726072 24.31 35.668432409537715 139.7400113616711 24.31 35.668432409537715 139.7400113616711 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668485270363746 139.74006343726072 11.24 35.66854667300807 139.73997179444004 11.24 35.66854667300807 139.73997179444004 24.31 35.668485270363746 139.74006343726072 24.31 35.668485270363746 139.74006343726072 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854667300807 139.73997179444004 11.24 35.66858238582398 139.74000719950917 11.24 35.66858238582398 139.74000719950917 24.31 35.66854667300807 139.73997179444004 24.31 35.66854667300807 139.73997179444004 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858238582398 139.74000719950917 11.24 35.66852144277615 139.74009874239522 11.24 35.66852144277615 139.74009874239522 24.31 35.66858238582398 139.74000719950917 24.31 35.66858238582398 139.74000719950917 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852144277615 139.74009874239522 11.24 35.66858314368163 139.7401594237161 11.24 35.66858314368163 139.7401594237161 24.31 35.66852144277615 139.74009874239522 24.31 35.66852144277615 139.74009874239522 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858314368163 139.7401594237161 11.24 35.66861964032672 139.74010124611956 11.24 35.66861964032672 139.74010124611956 24.31 35.66858314368163 139.7401594237161 24.31 35.66858314368163 139.7401594237161 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66861964032672 139.74010124611956 11.24 35.66858733857662 139.74007080773 11.24 35.66858733857662 139.74007080773 24.31 35.66861964032672 139.74010124611956 24.31 35.66861964032672 139.74010124611956 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858733857662 139.74007080773 11.24 35.66859990672124 139.7400514073569 11.24 35.66859990672124 139.7400514073569 24.31 35.66858733857662 139.74007080773 24.31 35.66858733857662 139.74007080773 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66859990672124 139.7400514073569 24.31 35.668610476768315 139.74003582017806 24.31 35.668633182259484 139.7400589572601 24.31 35.668663163388686 139.7400142964515 24.31 35.66857719415774 139.73992613887705 24.31 35.66858556723927 139.7399136471293 24.31 35.668534870329346 139.73986245273142 24.31 35.668432409537715 139.7400113616711 24.31 35.668485270363746 139.74006343726072 24.31 35.66854667300807 139.73997179444004 24.31 35.66858238582398 139.74000719950917 24.31 35.66852144277615 139.74009874239522 24.31 35.66858314368163 139.7401594237161 24.31 35.66861964032672 139.74010124611956 24.31 35.66858733857662 139.74007080773 24.31 35.66859990672124 139.7400514073569 24.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-dc7697b6-da06-4e3b-b4f9-762bdafcb781"/>
							<gml:surfaceMember xlink:href="#poly-b5a19e8f-64c3-437b-9073-ffed3390c74a"/>
							<gml:surfaceMember xlink:href="#poly-6e9e3170-4615-4ed8-a146-2b069f18cd15"/>
							<gml:surfaceMember xlink:href="#poly-f626e9e4-d1fc-48f2-9a36-c52a53a9ed64"/>
							<gml:surfaceMember xlink:href="#poly-bb6e8f4e-9bfc-4aa2-8599-2e04130229da"/>
							<gml:surfaceMember xlink:href="#poly-26a1dd1a-93b0-49b1-b000-e08d67f3f165"/>
							<gml:surfaceMember xlink:href="#poly-5b9dce0d-7003-44e3-9f44-65057305f9ba"/>
							<gml:surfaceMember xlink:href="#poly-784ae07f-aa70-4468-9efc-a805d155930b"/>
							<gml:surfaceMember xlink:href="#poly-de1ef809-d64a-4411-a90f-0c1ddbb2e70c"/>
							<gml:surfaceMember xlink:href="#poly-cccc2c01-f609-461c-8906-4e211ca56dc0"/>
							<gml:surfaceMember xlink:href="#poly-f01ba022-a131-4465-9dd6-915878b75ebc"/>
							<gml:surfaceMember xlink:href="#poly-864c5d11-a8eb-4aa2-8f02-195465758f47"/>
							<gml:surfaceMember xlink:href="#poly-5004026c-df60-4c3a-94ee-95d540da7bad"/>
							<gml:surfaceMember xlink:href="#poly-2da4e51c-4414-42b5-9db3-5f1030dc0501"/>
							<gml:surfaceMember xlink:href="#poly-effb663b-cd43-4d6c-8121-a6fc153c3663"/>
							<gml:surfaceMember xlink:href="#poly-d4f918b6-8e54-4b12-9a92-12ed886578f8"/>
							<gml:surfaceMember xlink:href="#poly-fc9fa9b3-1ce9-4894-965f-9820a94f6eee"/>
							<gml:surfaceMember xlink:href="#poly-5b90bd41-609e-4424-a520-1605e7db1256"/>
							<gml:surfaceMember xlink:href="#poly-c75a1ba2-3620-49e6-a761-651455c4f9cd"/>
							<gml:surfaceMember xlink:href="#poly-b16919b0-fcbc-42fa-bc36-7c541da99bf8"/>
							<gml:surfaceMember xlink:href="#poly-d30db9ee-05e6-4321-90fb-0890e07dff8d"/>
							<gml:surfaceMember xlink:href="#poly-aa4bc009-63c7-4c9f-a8dd-ee6c5fec0f86"/>
							<gml:surfaceMember xlink:href="#poly-79e97322-68c4-45c0-91f5-da6956840c1e"/>
							<gml:surfaceMember xlink:href="#poly-5f810233-64c9-4109-bc9f-90291fe0ab98"/>
							<gml:surfaceMember xlink:href="#poly-388aec40-d153-45cf-943e-ff81d4013e81"/>
							<gml:surfaceMember xlink:href="#poly-e4dd86a9-c025-42bc-a430-fb5acbb52f65"/>
							<gml:surfaceMember xlink:href="#poly-e9b4214a-81a8-4562-8395-9bfb5b8b05fd"/>
							<gml:surfaceMember xlink:href="#poly-ef9a730a-0699-421b-95e5-4b05400aa8e7"/>
							<gml:surfaceMember xlink:href="#poly-270d3c78-b7c2-4b4a-925c-4ce40346bbe2"/>
							<gml:surfaceMember xlink:href="#poly-47d7d5eb-88b5-437c-804a-bab57f8ca7d9"/>
							<gml:surfaceMember xlink:href="#poly-58ab2b4f-05ab-4388-93dc-8eee5942f011"/>
							<gml:surfaceMember xlink:href="#poly-f2291023-8526-4728-a4ec-4b1de0dd7600"/>
							<gml:surfaceMember xlink:href="#poly-dfe204a4-951d-48de-8c8f-cfaf61f0dbbf"/>
							<gml:surfaceMember xlink:href="#poly-8c4ae690-f1d1-4c54-8941-9f5d68542bc0"/>
							<gml:surfaceMember xlink:href="#poly-2fac018f-c402-4533-9b4f-ce7588e88366"/>
							<gml:surfaceMember xlink:href="#poly-0fc04e3e-ee16-47c7-9da2-420861ef6ee8"/>
							<gml:surfaceMember xlink:href="#poly-2b9d6f0c-5b21-4712-a268-7d15dfbb10d3"/>
							<gml:surfaceMember xlink:href="#poly-9c843eef-d485-46a6-8c5f-240e0ce32d8a"/>
							<gml:surfaceMember xlink:href="#poly-1837a051-5753-41a2-89f3-c90216a27deb"/>
							<gml:surfaceMember xlink:href="#poly-095c2951-7a5a-413c-b473-9003c6716c13"/>
							<gml:surfaceMember xlink:href="#poly-723d9a4b-1dde-49c0-93cb-d8c21a511fff"/>
							<gml:surfaceMember xlink:href="#poly-d69dba0d-3f79-40fb-b192-d6a69b70301d"/>
							<gml:surfaceMember xlink:href="#poly-37aae37c-d1cd-47bf-bd06-e63c0a270cec"/>
							<gml:surfaceMember xlink:href="#poly-44eaa263-bd4a-4065-8bd5-457247b7c87c"/>
							<gml:surfaceMember xlink:href="#poly-2029829a-5e6e-44ae-8be4-9aff7aefcb38"/>
							<gml:surfaceMember xlink:href="#poly-35e9ce53-cc39-4489-aa42-a9228fe62d40"/>
							<gml:surfaceMember xlink:href="#poly-2f62d124-0038-48e5-9a6b-0b0a056aaebd"/>
							<gml:surfaceMember xlink:href="#poly-c697c8e7-c776-45df-8db7-bacb2c9597c2"/>
							<gml:surfaceMember xlink:href="#poly-066d9b25-4936-4e45-928a-4e8815e6e1e2"/>
							<gml:surfaceMember xlink:href="#poly-72f76ba7-5165-408d-aff1-cf67d47c0f73"/>
							<gml:surfaceMember xlink:href="#poly-cb451580-2ee1-40dd-ae57-38048dc0503d"/>
							<gml:surfaceMember xlink:href="#poly-2d8cb238-9aa7-47e3-b283-102f7933027d"/>
							<gml:surfaceMember xlink:href="#poly-a8da57ec-261e-4213-884d-88faeea5f128"/>
							<gml:surfaceMember xlink:href="#poly-454b5b7c-9bc9-4de5-903c-2e8743f06366"/>
							<gml:surfaceMember xlink:href="#poly-a4df2d5b-9056-40b9-b442-0c2e4deb54cd"/>
							<gml:surfaceMember xlink:href="#poly-88f93625-db0b-433e-828e-49b6d5573cec"/>
							<gml:surfaceMember xlink:href="#poly-3965de1c-f9d5-4e3f-8d6c-68e567c42e09"/>
							<gml:surfaceMember xlink:href="#poly-4daf17e4-1774-4200-9fb1-398cb485ad24"/>
							<gml:surfaceMember xlink:href="#poly-1185485c-4dc3-40b3-b5b1-e16636425d5f"/>
							<gml:surfaceMember xlink:href="#poly-fefb2ff4-a4d0-4fa2-aea3-adf7c6c10381"/>
							<gml:surfaceMember xlink:href="#poly-85fdf2bd-d9c1-4509-802f-2339c53633b8"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1528f501-baf3-4404-bc10-d1fa3717af69_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfff8f67-7103-4459-86d9-c959e0aca9cf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66850673374614 139.7399144459208 23.932 35.66853175353234 139.73987658420475 23.932 35.66855134643917 139.73989601338744 23.932 35.66852632665552 139.7399338861527 23.932 35.66850673374614 139.7399144459208 23.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d21ce01-bbc4-42e2-bb98-016228a64298">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d21ce01-bbc4-42e2-bb98-016228a64298_0">
											<gml:posList>35.66853175353234 139.73987658420475 23.932 35.66853175353234 139.73987658420475 25.697 35.66855134643917 139.73989601338744 25.697 35.66855134643917 139.73989601338744 23.932 35.66853175353234 139.73987658420475 23.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40f7afbb-4a24-4b28-acc0-19c236f0caff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40f7afbb-4a24-4b28-acc0-19c236f0caff_0">
											<gml:posList>35.66850673374614 139.7399144459208 23.932 35.66850673374614 139.7399144459208 25.697 35.66853175353234 139.73987658420475 25.697 35.66853175353234 139.73987658420475 23.932 35.66850673374614 139.7399144459208 23.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8d82765-2b0d-4f1a-a91b-818a6294a25c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8d82765-2b0d-4f1a-a91b-818a6294a25c_0">
											<gml:posList>35.66850673374614 139.7399144459208 25.697 35.66852632665552 139.7399338861527 25.697 35.66855134643917 139.73989601338744 25.697 35.66853175353234 139.73987658420475 25.697 35.66850673374614 139.7399144459208 25.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60bc6f13-a748-4bfc-8c1d-2086069131ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60bc6f13-a748-4bfc-8c1d-2086069131ab_0">
											<gml:posList>35.66855134643917 139.73989601338744 23.932 35.66855134643917 139.73989601338744 25.697 35.66852632665552 139.7399338861527 25.697 35.66852632665552 139.7399338861527 23.932 35.66855134643917 139.73989601338744 23.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d45a96ff-332f-4848-8fec-6d016edbbbef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d45a96ff-332f-4848-8fec-6d016edbbbef_0">
											<gml:posList>35.66852632665552 139.7399338861527 23.932 35.66852632665552 139.7399338861527 25.697 35.66850673374614 139.7399144459208 25.697 35.66850673374614 139.7399144459208 23.932 35.66852632665552 139.7399338861527 23.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1528f501-baf3-4404-bc10-d1fa3717af69_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63101912-f8ca-42a4-8b4c-fc5c53afe2fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63101912-f8ca-42a4-8b4c-fc5c53afe2fa_0">
											<gml:posList>35.66857919035798 139.7399663771707 26.703 35.66856832137263 139.73996841124662 26.703 35.6685683855821 139.73996984715313 26.703 35.66857919035798 139.7399663771707 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0899648-41ad-480c-8111-0c25b35af1bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0899648-41ad-480c-8111-0c25b35af1bd_0">
											<gml:posList>35.66857919035798 139.7399663771707 26.703 35.668569947911244 139.7399736562074 26.703 35.66857948889007 139.73996776862052 26.703 35.66857919035798 139.7399663771707 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f58bc47-265b-4a5c-a6b5-53df153f7748">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f58bc47-265b-4a5c-a6b5-53df153f7748_0">
											<gml:posList>35.66857919035798 139.7399663771707 26.703 35.66856920791222 139.739972530376 26.703 35.668569947911244 139.7399736562074 26.703 35.66857919035798 139.7399663771707 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6c4f5dd-74c4-4407-991a-711c7fdca382">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a6c4f5dd-74c4-4407-991a-711c7fdca382_0">
											<gml:posList>35.668578933293595 139.73997196675174 26.703 35.668569947911244 139.7399736562074 26.703 35.668578285238866 139.7399731715215 26.703 35.668578933293595 139.73997196675174 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-785cbc65-6963-4cb2-a5c2-7a8e23d36f21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-785cbc65-6963-4cb2-a5c2-7a8e23d36f21_0">
											<gml:posList>35.66853560322771 139.74011022482134 42.257 35.66853560322771 139.74011022482134 42.473 35.668560154652575 139.7400727392617 42.257 35.66853560322771 139.74011022482134 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-849a1c3a-4d3a-4d59-828f-4cd221fae78a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-849a1c3a-4d3a-4d59-828f-4cd221fae78a_0">
											<gml:posList>35.668560154652575 139.7400727392617 42.257 35.66853560322771 139.74011022482134 42.473 35.668560154652575 139.7400727392617 42.714 35.668560154652575 139.7400727392617 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92cea313-5966-4289-bd4e-ba5c34093e20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92cea313-5966-4289-bd4e-ba5c34093e20_0">
											<gml:posList>35.668560154652575 139.7400727392617 42.714 35.66853560322771 139.74011022482134 42.473 35.668535486186116 139.74011040169347 42.714 35.668560154652575 139.7400727392617 42.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47a9a3f5-045b-424d-963d-34581815adcd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47a9a3f5-045b-424d-963d-34581815adcd_0">
											<gml:posList>35.66853560322771 139.74011022482134 42.473 35.668535486186116 139.74011040169347 42.473 35.668535486186116 139.74011040169347 42.714 35.66853560322771 139.74011022482134 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4cc21f43-6f1b-41a3-ac43-f3b9e9146787">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4cc21f43-6f1b-41a3-ac43-f3b9e9146787_0">
											<gml:posList>35.668535486186116 139.74011040169347 42.473 35.66857334564709 139.7401476379624 42.714 35.668535486186116 139.74011040169347 42.714 35.668535486186116 139.74011040169347 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81864587-8d1f-4f5c-887b-e80fec7d2653">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81864587-8d1f-4f5c-887b-e80fec7d2653_0">
											<gml:posList>35.668535486186116 139.74011040169347 42.473 35.66857334564709 139.7401476379624 42.473 35.66857334564709 139.7401476379624 42.714 35.668535486186116 139.74011040169347 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab91abb0-bc29-42d7-9365-ffed2fa61ef7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab91abb0-bc29-42d7-9365-ffed2fa61ef7_0">
											<gml:posList>35.66857346268875 139.7401474610902 42.258 35.66857346268875 139.7401474610902 42.473 35.66853560322771 139.74011022482134 42.473 35.66857346268875 139.7401474610902 42.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9069f2b-ba4d-452e-9b60-1bb91eef93da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9069f2b-ba4d-452e-9b60-1bb91eef93da_0">
											<gml:posList>35.66853560322771 139.74011022482134 42.257 35.66857346268875 139.7401474610902 42.258 35.66853560322771 139.74011022482134 42.473 35.66853560322771 139.74011022482134 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef46717c-b409-46d8-84a5-21c3a4093cc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef46717c-b409-46d8-84a5-21c3a4093cc1_0">
											<gml:posList>35.66855875009817 139.73997010138467 24.383 35.668570038311834 139.73995074667738 26.703 35.668570038311834 139.73995074667738 24.383 35.66855875009817 139.73997010138467 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ea17d3b-9a46-44f8-a6be-977cdafdbada">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ea17d3b-9a46-44f8-a6be-977cdafdbada_0">
											<gml:posList>35.66855875009817 139.73997010138467 24.383 35.66855875009817 139.73997010138467 26.703 35.668570038311834 139.73995074667738 26.703 35.66855875009817 139.73997010138467 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff02eee6-6ba3-4444-a111-e7d2a8790d94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff02eee6-6ba3-4444-a111-e7d2a8790d94_0">
											<gml:posList>35.66857368555715 139.74008604501262 42.257 35.668560154652575 139.7400727392617 42.714 35.66857368555715 139.74008604501262 42.714 35.66857368555715 139.74008604501262 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7887f0a2-ce33-4035-b146-1a44810d6273">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7887f0a2-ce33-4035-b146-1a44810d6273_0">
											<gml:posList>35.66857368555715 139.74008604501262 42.257 35.668560154652575 139.7400727392617 42.257 35.668560154652575 139.7400727392617 42.714 35.66857368555715 139.74008604501262 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e975d4f-06c3-4915-bcc8-2e6f7358efb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e975d4f-06c3-4915-bcc8-2e6f7358efb2_0">
											<gml:posList>35.66856832137263 139.73996841124662 28.42 35.6685683855821 139.73996984715313 26.703 35.6685683855821 139.73996984715313 28.42 35.66856832137263 139.73996841124662 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f39e220-fd8c-4f46-9bd0-b3283e86c4ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f39e220-fd8c-4f46-9bd0-b3283e86c4ec_0">
											<gml:posList>35.66856832137263 139.73996841124662 28.42 35.66856832137263 139.73996841124662 26.703 35.6685683855821 139.73996984715313 26.703 35.66856832137263 139.73996841124662 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e0e2f3c-4772-483f-8574-b30ae38188c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e0e2f3c-4772-483f-8574-b30ae38188c1_0">
											<gml:posList>35.66856851856975 139.73996698608175 28.42 35.66856832137263 139.73996841124662 26.703 35.66856832137263 139.73996841124662 28.42 35.66856851856975 139.73996698608175 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce8acd4e-d14d-4116-868e-5a1d9db12251">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce8acd4e-d14d-4116-868e-5a1d9db12251_0">
											<gml:posList>35.66856851856975 139.73996698608175 28.42 35.66856851856975 139.73996698608175 26.703 35.66856832137263 139.73996841124662 26.703 35.66856851856975 139.73996698608175 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5e4d6f9-5ead-4567-8f58-07a55a6be18e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5e4d6f9-5ead-4567-8f58-07a55a6be18e_0">
											<gml:posList>35.6685683855821 139.73996984715313 26.703 35.66856867510042 139.73997123861324 28.42 35.6685683855821 139.73996984715313 28.42 35.6685683855821 139.73996984715313 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-005d867d-adb1-4134-978e-a2a947be02cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-005d867d-adb1-4134-978e-a2a947be02cc_0">
											<gml:posList>35.6685683855821 139.73996984715313 26.703 35.66856867510042 139.73997123861324 26.703 35.66856867510042 139.73997123861324 28.42 35.6685683855821 139.73996984715313 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ceef032c-4ab4-4787-9ed6-5636f7591d55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ceef032c-4ab4-4787-9ed6-5636f7591d55_0">
											<gml:posList>35.66855875009817 139.73997010138467 24.383 35.66857840436484 139.73998731027712 26.703 35.66855875009817 139.73997010138467 26.703 35.66855875009817 139.73997010138467 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a29717a6-f09e-4e40-badc-8e149a5fe420">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a29717a6-f09e-4e40-badc-8e149a5fe420_0">
											<gml:posList>35.66855875009817 139.73997010138467 24.383 35.66857840436484 139.73998731027712 24.383 35.66857840436484 139.73998731027712 26.703 35.66855875009817 139.73997010138467 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98c1d053-0fe6-4141-a310-2e58102484b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98c1d053-0fe6-4141-a310-2e58102484b1_0">
											<gml:posList>35.6685689411785 139.73996564902245 28.42 35.66856851856975 139.73996698608175 26.703 35.66856851856975 139.73996698608175 28.42 35.6685689411785 139.73996564902245 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b47664d6-8163-4bc5-b65d-5409c509c689">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b47664d6-8163-4bc5-b65d-5409c509c689_0">
											<gml:posList>35.6685689411785 139.73996564902245 28.42 35.6685689411785 139.73996564902245 26.703 35.66856851856975 139.73996698608175 26.703 35.6685689411785 139.73996564902245 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e08c1de6-af59-4de6-91db-5bf465b12b44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e08c1de6-af59-4de6-91db-5bf465b12b44_0">
											<gml:posList>35.66856867510042 139.73997123861324 26.703 35.66856920791222 139.739972530376 28.42 35.66856867510042 139.73997123861324 28.42 35.66856867510042 139.73997123861324 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7930f948-97d1-4dc7-98e6-b54b707bd333">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7930f948-97d1-4dc7-98e6-b54b707bd333_0">
											<gml:posList>35.66856867510042 139.73997123861324 26.703 35.66856920791222 139.739972530376 26.703 35.66856920791222 139.739972530376 28.42 35.66856867510042 139.73997123861324 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b263787-2676-401f-8dde-12403151fd81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b263787-2676-401f-8dde-12403151fd81_0">
											<gml:posList>35.6685689411785 139.73996564902245 28.42 35.66856958923316 139.73996444425273 26.703 35.6685689411785 139.73996564902245 26.703 35.6685689411785 139.73996564902245 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c858739-4304-44e8-aaad-7cc3691f8205">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c858739-4304-44e8-aaad-7cc3691f8205_0">
											<gml:posList>35.6685689411785 139.73996564902245 28.42 35.66856958923316 139.73996444425273 28.42 35.66856958923316 139.73996444425273 26.703 35.6685689411785 139.73996564902245 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0524a8e-8cda-4250-8f6f-a9fe3e8aa4c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0524a8e-8cda-4250-8f6f-a9fe3e8aa4c5_0">
											<gml:posList>35.668569947911244 139.7399736562074 26.703 35.66856920791222 139.739972530376 28.42 35.66856920791222 139.739972530376 26.703 35.668569947911244 139.7399736562074 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cb92e20-d2e1-49b9-ab68-b09e287ff932">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cb92e20-d2e1-49b9-ab68-b09e287ff932_0">
											<gml:posList>35.668569947911244 139.7399736562074 26.703 35.668569947911244 139.7399736562074 28.42 35.66856920791222 139.739972530376 28.42 35.668569947911244 139.7399736562074 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb37946b-0113-492a-88a0-1ade01557215">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb37946b-0113-492a-88a0-1ade01557215_0">
											<gml:posList>35.66856958923316 139.73996444425273 28.42 35.66857041771646 139.73996343810109 26.703 35.66856958923316 139.73996444425273 26.703 35.66856958923316 139.73996444425273 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65714c3a-4f8d-46a9-8de8-eb2635bdbc8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65714c3a-4f8d-46a9-8de8-eb2635bdbc8a_0">
											<gml:posList>35.66856958923316 139.73996444425273 28.42 35.66857041771646 139.73996343810109 28.42 35.66857041771646 139.73996343810109 26.703 35.66856958923316 139.73996444425273 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-136664e7-1b8a-49d6-a3e5-676ca14246a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-136664e7-1b8a-49d6-a3e5-676ca14246a3_0">
											<gml:posList>35.668569947911244 139.7399736562074 26.703 35.66857084998602 139.73997456092994 28.42 35.668569947911244 139.7399736562074 28.42 35.668569947911244 139.7399736562074 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cc4b833-d9e9-4167-b948-686413f88339">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cc4b833-d9e9-4167-b948-686413f88339_0">
											<gml:posList>35.668569947911244 139.7399736562074 26.703 35.66857084998602 139.73997456092994 26.703 35.66857084998602 139.73997456092994 28.42 35.668569947911244 139.7399736562074 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98bb145e-7f55-4f58-ae06-1cfe422f0569">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98bb145e-7f55-4f58-ae06-1cfe422f0569_0">
											<gml:posList>35.668560154652575 139.7400727392617 42.714 35.668535486186116 139.74011040169347 42.714 35.66857368555715 139.74008604501262 42.714 35.668560154652575 139.7400727392617 42.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cad61cee-5199-427b-8cdb-c346e72dff79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cad61cee-5199-427b-8cdb-c346e72dff79_0">
											<gml:posList>35.66858396246758 139.74007602537446 42.714 35.668581689297845 139.74007381881597 42.714 35.66857368555715 139.74008604501262 42.714 35.66858396246758 139.74007602537446 42.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-578142be-71fe-490d-8a37-b8bdc30d7178">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-578142be-71fe-490d-8a37-b8bdc30d7178_0">
											<gml:posList>35.66858396246758 139.74007602537446 42.714 35.66857368555715 139.74008604501262 42.714 35.66860602686476 139.74009772722374 42.714 35.66858396246758 139.74007602537446 42.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68eaec26-4c8c-4db8-b826-e0590a239eb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68eaec26-4c8c-4db8-b826-e0590a239eb9_0">
											<gml:posList>35.66857368555715 139.74008604501262 42.714 35.668535486186116 139.74011040169347 42.714 35.66857334564709 139.7401476379624 42.714 35.66857368555715 139.74008604501262 42.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b684a3dc-53d7-41f1-87f3-47d59ef8ae64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b684a3dc-53d7-41f1-87f3-47d59ef8ae64_0">
											<gml:posList>35.66860602686476 139.74009772722374 42.714 35.66857368555715 139.74008604501262 42.714 35.66857334564709 139.7401476379624 42.714 35.66860602686476 139.74009772722374 42.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52ab2aef-02a8-4b24-9def-baa8255889b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52ab2aef-02a8-4b24-9def-baa8255889b4_0">
											<gml:posList>35.66857140861812 139.73996265268053 26.703 35.66857041771646 139.73996343810109 28.42 35.66857140861812 139.73996265268053 28.42 35.66857140861812 139.73996265268053 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01c97c8e-b40f-4dd0-8005-9eb3baa166be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01c97c8e-b40f-4dd0-8005-9eb3baa166be_0">
											<gml:posList>35.66857140861812 139.73996265268053 26.703 35.66857041771646 139.73996343810109 26.703 35.66857041771646 139.73996343810109 28.42 35.66857140861812 139.73996265268053 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33f87eef-786f-41a3-92a4-4d7e618d3dba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33f87eef-786f-41a3-92a4-4d7e618d3dba_0">
											<gml:posList>35.66857084998602 139.73997456092994 26.703 35.66857189609199 139.73997522247257 28.42 35.66857084998602 139.73997456092994 28.42 35.66857084998602 139.73997456092994 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48cf931a-46c6-46e4-a9ba-5c0d7282ce7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48cf931a-46c6-46e4-a9ba-5c0d7282ce7e_0">
											<gml:posList>35.66857084998602 139.73997456092994 26.703 35.66857189609199 139.73997522247257 26.703 35.66857189609199 139.73997522247257 28.42 35.66857084998602 139.73997456092994 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51f47ec3-070d-418d-a913-200d8e2c608b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51f47ec3-070d-418d-a913-200d8e2c608b_0">
											<gml:posList>35.66857250789862 139.73996214328395 26.703 35.66857140861812 139.73996265268053 28.42 35.66857250789862 139.73996214328395 28.42 35.66857250789862 139.73996214328395 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1be4752-df1c-4856-b0a6-d9491d71d244">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1be4752-df1c-4856-b0a6-d9491d71d244_0">
											<gml:posList>35.66857250789862 139.73996214328395 26.703 35.66857140861812 139.73996265268053 26.703 35.66857140861812 139.73996265268053 28.42 35.66857250789862 139.73996214328395 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97684f72-9ab6-457c-bd0a-2919a002cdd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97684f72-9ab6-457c-bd0a-2919a002cdd0_0">
											<gml:posList>35.66857303212112 139.73997560776021 26.703 35.66857189609199 139.73997522247257 28.42 35.66857189609199 139.73997522247257 26.703 35.66857303212112 139.73997560776021 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14a1bd4f-e223-4826-aee2-88c88ea70724">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14a1bd4f-e223-4826-aee2-88c88ea70724_0">
											<gml:posList>35.66857303212112 139.73997560776021 26.703 35.66857303212112 139.73997560776021 28.42 35.66857189609199 139.73997522247257 28.42 35.66857303212112 139.73997560776021 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3e82929-1890-4a52-846e-3e4a48db911f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3e82929-1890-4a52-846e-3e4a48db911f_0">
											<gml:posList>35.66857367050643 139.73996193205593 26.703 35.66857250789862 139.73996214328395 28.42 35.66857367050643 139.73996193205593 28.42 35.66857367050643 139.73996193205593 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f23c97e9-078b-43da-9800-4dbb206fb2f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f23c97e9-078b-43da-9800-4dbb206fb2f5_0">
											<gml:posList>35.66857367050643 139.73996193205593 26.703 35.66857250789862 139.73996214328395 26.703 35.66857250789862 139.73996214328395 28.42 35.66857367050643 139.73996193205593 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-266a1d6d-ebb3-4804-9b56-4d1d24b661a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-266a1d6d-ebb3-4804-9b56-4d1d24b661a3_0">
											<gml:posList>35.66857303212112 139.73997560776021 26.703 35.668574203965335 139.7399756837179 28.42 35.66857303212112 139.73997560776021 28.42 35.66857303212112 139.73997560776021 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d8e1976-5e35-4010-b55d-b0d57a903c42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d8e1976-5e35-4010-b55d-b0d57a903c42_0">
											<gml:posList>35.66857303212112 139.73997560776021 26.703 35.668574203965335 139.7399756837179 26.703 35.668574203965335 139.7399756837179 28.42 35.66857303212112 139.73997560776021 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3278e31c-78e4-46cf-a733-3bcf78109aeb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3278e31c-78e4-46cf-a733-3bcf78109aeb_0">
											<gml:posList>35.66857140861812 139.73996265268053 28.42 35.66857041771646 139.73996343810109 28.42 35.66857367050643 139.73996193205593 28.42 35.66857140861812 139.73996265268053 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a76ba162-166d-4f55-bd43-1c60ea5f9d50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a76ba162-166d-4f55-bd43-1c60ea5f9d50_0">
											<gml:posList>35.66857250789862 139.73996214328395 28.42 35.66857140861812 139.73996265268053 28.42 35.66857367050643 139.73996193205593 28.42 35.66857250789862 139.73996214328395 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4518a5e-bc02-4e62-8028-ecf10d711fbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4518a5e-bc02-4e62-8028-ecf10d711fbd_0">
											<gml:posList>35.66857041771646 139.73996343810109 28.42 35.66856958923316 139.73996444425273 28.42 35.66857367050643 139.73996193205593 28.42 35.66857041771646 139.73996343810109 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ceddb62-1bfa-4417-aa1a-8652d7457584">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ceddb62-1bfa-4417-aa1a-8652d7457584_0">
											<gml:posList>35.66856958923316 139.73996444425273 28.42 35.6685689411785 139.73996564902245 28.42 35.66856851856975 139.73996698608175 28.42 35.66856958923316 139.73996444425273 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84c51d0a-23c1-4e27-8a25-c5e90d1a47c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84c51d0a-23c1-4e27-8a25-c5e90d1a47c3_0">
											<gml:posList>35.66857484235068 139.7399620080134 28.42 35.66857367050643 139.73996193205593 28.42 35.66857597837984 139.7399623933009 28.42 35.66857484235068 139.7399620080134 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19867ba7-614d-461e-bc64-3047ade8fa72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19867ba7-614d-461e-bc64-3047ade8fa72_0">
											<gml:posList>35.66856832137263 139.73996841124662 28.42 35.6685683855821 139.73996984715313 28.42 35.66856851856975 139.73996698608175 28.42 35.66856832137263 139.73996841124662 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3adfd982-ab60-47f6-bc9c-594ab34f00ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3adfd982-ab60-47f6-bc9c-594ab34f00ff_0">
											<gml:posList>35.66857702448587 139.7399630548434 28.42 35.66857597837984 139.7399623933009 28.42 35.66857919035798 139.7399663771707 28.42 35.66857702448587 139.7399630548434 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7771bbbd-ec0d-4422-92b2-f3ac95e0b3c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7771bbbd-ec0d-4422-92b2-f3ac95e0b3c5_0">
											<gml:posList>35.66857792656074 139.73996395956587 28.42 35.66857702448587 139.7399630548434 28.42 35.66857919035798 139.7399663771707 28.42 35.66857792656074 139.73996395956587 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dbdc086-b4aa-4dc0-9bb5-90fc16aff18a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dbdc086-b4aa-4dc0-9bb5-90fc16aff18a_0">
											<gml:posList>35.66856867510042 139.73997123861324 28.42 35.66856920791222 139.739972530376 28.42 35.6685683855821 139.73996984715313 28.42 35.66856867510042 139.73997123861324 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbda36e9-405c-463c-bd94-181adde56870">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbda36e9-405c-463c-bd94-181adde56870_0">
											<gml:posList>35.668578666559824 139.73996508539733 28.42 35.66857792656074 139.73996395956587 28.42 35.66857919035798 139.7399663771707 28.42 35.668578666559824 139.73996508539733 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ee1944a-5c9d-4d59-a8b3-9b6b4c1a269d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ee1944a-5c9d-4d59-a8b3-9b6b4c1a269d_0">
											<gml:posList>35.66856920791222 139.739972530376 28.42 35.668569947911244 139.7399736562074 28.42 35.6685683855821 139.73996984715313 28.42 35.66856920791222 139.739972530376 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4497793a-d50a-4f3e-b6d8-0f33b1f20409">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4497793a-d50a-4f3e-b6d8-0f33b1f20409_0">
											<gml:posList>35.66857919035798 139.7399663771707 28.42 35.668579544085816 139.73996920453772 28.42 35.66857948889007 139.73996776862052 28.42 35.66857919035798 139.7399663771707 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f954c5b-b333-4e06-b88d-424453dd1e23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f954c5b-b333-4e06-b88d-424453dd1e23_0">
											<gml:posList>35.668569947911244 139.7399736562074 28.42 35.66857084998602 139.73997456092994 28.42 35.66857189609199 139.73997522247257 28.42 35.668569947911244 139.7399736562074 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c716d181-d275-43c9-a67d-149d8176b7b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c716d181-d275-43c9-a67d-149d8176b7b7_0">
											<gml:posList>35.66857935590239 139.7399706296923 28.42 35.668579544085816 139.73996920453772 28.42 35.66857744774175 139.73997417768365 28.42 35.66857935590239 139.7399706296923 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e709cd1-84e6-46c7-896f-92b6b80bfac5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e709cd1-84e6-46c7-896f-92b6b80bfac5_0">
											<gml:posList>35.66857303212112 139.73997560776021 28.42 35.668574203965335 139.7399756837179 28.42 35.66857189609199 139.73997522247257 28.42 35.66857303212112 139.73997560776021 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9397e33b-5b86-4115-9d48-4251a8bdecc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9397e33b-5b86-4115-9d48-4251a8bdecc3_0">
											<gml:posList>35.668578285238866 139.7399731715215 28.42 35.668578933293595 139.73997196675174 28.42 35.66857935590239 139.7399706296923 28.42 35.668578285238866 139.7399731715215 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c122af5-5970-4688-8121-5edf4c9d16b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c122af5-5970-4688-8121-5edf4c9d16b1_0">
											<gml:posList>35.6685753665732 139.73997547249007 28.42 35.66857744774175 139.73997417768365 28.42 35.668574203965335 139.7399756837179 28.42 35.6685753665732 139.73997547249007 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b3855b9-6e37-4772-8d10-0b004effc7c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b3855b9-6e37-4772-8d10-0b004effc7c2_0">
											<gml:posList>35.668578285238866 139.7399731715215 28.42 35.66857935590239 139.7399706296923 28.42 35.66857744774175 139.73997417768365 28.42 35.668578285238866 139.7399731715215 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49405c5f-8605-409e-9a75-44fa8afa3499">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49405c5f-8605-409e-9a75-44fa8afa3499_0">
											<gml:posList>35.6685753665732 139.73997547249007 28.42 35.66857646585373 139.73997496309366 28.42 35.66857744774175 139.73997417768365 28.42 35.6685753665732 139.73997547249007 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-656a1779-af14-453c-a6ac-791a8d2e931b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-656a1779-af14-453c-a6ac-791a8d2e931b_0">
											<gml:posList>35.66857367050643 139.73996193205593 28.42 35.66856958923316 139.73996444425273 28.42 35.6685683855821 139.73996984715313 28.42 35.66857367050643 139.73996193205593 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27134cb4-7419-43f3-ae80-2e1ba86c19e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27134cb4-7419-43f3-ae80-2e1ba86c19e6_0">
											<gml:posList>35.6685683855821 139.73996984715313 28.42 35.66856958923316 139.73996444425273 28.42 35.66856851856975 139.73996698608175 28.42 35.6685683855821 139.73996984715313 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21f11c96-7aaa-458f-b143-edf22a5029fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21f11c96-7aaa-458f-b143-edf22a5029fe_0">
											<gml:posList>35.66857919035798 139.7399663771707 28.42 35.66857597837984 139.7399623933009 28.42 35.66857367050643 139.73996193205593 28.42 35.66857919035798 139.7399663771707 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ded19034-7b6c-49b7-8442-b9e33b5224e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ded19034-7b6c-49b7-8442-b9e33b5224e5_0">
											<gml:posList>35.668569947911244 139.7399736562074 28.42 35.66857189609199 139.73997522247257 28.42 35.6685683855821 139.73996984715313 28.42 35.668569947911244 139.7399736562074 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffde3aa7-3c3a-447e-ae89-332c518aef15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffde3aa7-3c3a-447e-ae89-332c518aef15_0">
											<gml:posList>35.66857744774175 139.73997417768365 28.42 35.668579544085816 139.73996920453772 28.42 35.66857919035798 139.7399663771707 28.42 35.66857744774175 139.73997417768365 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e37c2224-57e9-4510-aa9d-5c23d8247593">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e37c2224-57e9-4510-aa9d-5c23d8247593_0">
											<gml:posList>35.66857189609199 139.73997522247257 28.42 35.668574203965335 139.7399756837179 28.42 35.6685683855821 139.73996984715313 28.42 35.66857189609199 139.73997522247257 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0099ec14-2159-4d00-82da-261f8f064ec7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0099ec14-2159-4d00-82da-261f8f064ec7_0">
											<gml:posList>35.668574203965335 139.7399756837179 28.42 35.66857744774175 139.73997417768365 28.42 35.6685683855821 139.73996984715313 28.42 35.668574203965335 139.7399756837179 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-438467af-bae4-45a7-890b-cfe4f59099f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-438467af-bae4-45a7-890b-cfe4f59099f1_0">
											<gml:posList>35.66857919035798 139.7399663771707 28.42 35.66857367050643 139.73996193205593 28.42 35.6685683855821 139.73996984715313 28.42 35.66857919035798 139.7399663771707 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cf01730-cc4d-4fdb-9d80-af793b8515c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cf01730-cc4d-4fdb-9d80-af793b8515c3_0">
											<gml:posList>35.66857744774175 139.73997417768365 28.42 35.66857919035798 139.7399663771707 28.42 35.6685683855821 139.73996984715313 28.42 35.66857744774175 139.73997417768365 28.42</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c4ed553-cb6c-435a-a9fe-5a77457ffd19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c4ed553-cb6c-435a-a9fe-5a77457ffd19_0">
											<gml:posList>35.66857484235068 139.7399620080134 26.703 35.66857367050643 139.73996193205593 28.42 35.66857484235068 139.7399620080134 28.42 35.66857484235068 139.7399620080134 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4e9a0f9-9b47-4fa2-afc4-8255afeba3cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4e9a0f9-9b47-4fa2-afc4-8255afeba3cf_0">
											<gml:posList>35.66857484235068 139.7399620080134 26.703 35.66857367050643 139.73996193205593 26.703 35.66857367050643 139.73996193205593 28.42 35.66857484235068 139.7399620080134 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73203c55-2d3d-408e-95dd-f5314de27be9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73203c55-2d3d-408e-95dd-f5314de27be9_0">
											<gml:posList>35.668578796600904 139.7399584245011 24.383 35.668570038311834 139.73995074667738 26.703 35.668578796600904 139.7399584245011 26.703 35.668578796600904 139.7399584245011 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc86e206-2465-4dfb-b538-bf7af3fffc34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc86e206-2465-4dfb-b538-bf7af3fffc34_0">
											<gml:posList>35.668578796600904 139.7399584245011 24.383 35.668570038311834 139.73995074667738 24.383 35.668570038311834 139.73995074667738 26.703 35.668578796600904 139.7399584245011 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51f7a05b-f534-4154-8f38-9490ab35f1fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51f7a05b-f534-4154-8f38-9490ab35f1fe_0">
											<gml:posList>35.668574203965335 139.7399756837179 26.703 35.6685753665732 139.73997547249007 28.42 35.668574203965335 139.7399756837179 28.42 35.668574203965335 139.7399756837179 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dedf5c0-2b1e-4871-b1a5-b53a7dcb35e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dedf5c0-2b1e-4871-b1a5-b53a7dcb35e5_0">
											<gml:posList>35.668574203965335 139.7399756837179 26.703 35.6685753665732 139.73997547249007 26.703 35.6685753665732 139.73997547249007 28.42 35.668574203965335 139.7399756837179 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a77ee33-e3af-4b20-a4d7-78ae37d55013">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a77ee33-e3af-4b20-a4d7-78ae37d55013_0">
											<gml:posList>35.66857597837984 139.7399623933009 26.703 35.66857484235068 139.7399620080134 28.42 35.66857597837984 139.7399623933009 28.42 35.66857597837984 139.7399623933009 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56d63c45-57d0-4bf7-94b2-ef6e3c05d03f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56d63c45-57d0-4bf7-94b2-ef6e3c05d03f_0">
											<gml:posList>35.66857597837984 139.7399623933009 26.703 35.66857484235068 139.7399620080134 26.703 35.66857484235068 139.7399620080134 28.42 35.66857597837984 139.7399623933009 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76d3f6a1-ef8a-49df-adbe-9e07bfd3dab7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76d3f6a1-ef8a-49df-adbe-9e07bfd3dab7_0">
											<gml:posList>35.66857840436484 139.73998731027712 26.703 35.668592537141315 139.7399630809635 26.703 35.668578933293595 139.73997196675174 26.703 35.66857840436484 139.73998731027712 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43376b64-a9be-42a0-b3ea-c12202a3d04d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43376b64-a9be-42a0-b3ea-c12202a3d04d_0">
											<gml:posList>35.668569947911244 139.7399736562074 26.703 35.66855875009817 139.73997010138467 26.703 35.66857840436484 139.73998731027712 26.703 35.668569947911244 139.7399736562074 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81d9aecc-9544-40b9-90c5-fae399f3ba12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81d9aecc-9544-40b9-90c5-fae399f3ba12_0">
											<gml:posList>35.668592537141315 139.7399630809635 26.703 35.668581641160614 139.73995354989745 26.703 35.668578933293595 139.73997196675174 26.703 35.668592537141315 139.7399630809635 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c73147d-e2b4-468b-9b3a-b795af267246">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c73147d-e2b4-468b-9b3a-b795af267246_0">
											<gml:posList>35.66856832137263 139.73996841124662 26.703 35.668570038311834 139.73995074667738 26.703 35.66855875009817 139.73997010138467 26.703 35.66856832137263 139.73996841124662 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f1b180a-5f0d-42ae-af27-ca83cff966ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f1b180a-5f0d-42ae-af27-ca83cff966ca_0">
											<gml:posList>35.668578796600904 139.7399584245011 26.703 35.66857919035798 139.7399663771707 26.703 35.668581641160614 139.73995354989745 26.703 35.668578796600904 139.7399584245011 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc1f8a82-0ada-4fc8-a74a-40c369265ca0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc1f8a82-0ada-4fc8-a74a-40c369265ca0_0">
											<gml:posList>35.66856832137263 139.73996841124662 26.703 35.668578796600904 139.7399584245011 26.703 35.668570038311834 139.73995074667738 26.703 35.66856832137263 139.73996841124662 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f19fbf0-e720-42cf-879a-2dde1d81e822">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f19fbf0-e720-42cf-879a-2dde1d81e822_0">
											<gml:posList>35.668578285238866 139.7399731715215 26.703 35.66857840436484 139.73998731027712 26.703 35.668578933293595 139.73997196675174 26.703 35.668578285238866 139.7399731715215 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-197552e2-b228-4ed2-ba85-2b3c946ad827">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-197552e2-b228-4ed2-ba85-2b3c946ad827_0">
											<gml:posList>35.668569947911244 139.7399736562074 26.703 35.66857840436484 139.73998731027712 26.703 35.668578285238866 139.7399731715215 26.703 35.668569947911244 139.7399736562074 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db4597d4-82b4-4904-b82d-4b4021296b2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db4597d4-82b4-4904-b82d-4b4021296b2a_0">
											<gml:posList>35.668569947911244 139.7399736562074 26.703 35.66856920791222 139.739972530376 26.703 35.66855875009817 139.73997010138467 26.703 35.668569947911244 139.7399736562074 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46dcd0bd-f749-4ec1-8d90-42da4a883035">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46dcd0bd-f749-4ec1-8d90-42da4a883035_0">
											<gml:posList>35.6685683855821 139.73996984715313 26.703 35.66856832137263 139.73996841124662 26.703 35.66855875009817 139.73997010138467 26.703 35.6685683855821 139.73996984715313 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d82d6db2-8219-4041-88c8-90afdaa3b3d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d82d6db2-8219-4041-88c8-90afdaa3b3d0_0">
											<gml:posList>35.66857919035798 139.7399663771707 26.703 35.66857948889007 139.73996776862052 26.703 35.668581641160614 139.73995354989745 26.703 35.66857919035798 139.7399663771707 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5de9cf3f-387b-426e-b05b-5c0dc2e56ef8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5de9cf3f-387b-426e-b05b-5c0dc2e56ef8_0">
											<gml:posList>35.66856832137263 139.73996841124662 26.703 35.66857919035798 139.7399663771707 26.703 35.668578796600904 139.7399584245011 26.703 35.66856832137263 139.73996841124662 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de5d0ac9-e99e-4063-bada-79893686e4fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de5d0ac9-e99e-4063-bada-79893686e4fb_0">
											<gml:posList>35.66856920791222 139.739972530376 26.703 35.6685683855821 139.73996984715313 26.703 35.66855875009817 139.73997010138467 26.703 35.66856920791222 139.739972530376 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ee4c207-6b75-49e5-94ab-e636c62f0692">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ee4c207-6b75-49e5-94ab-e636c62f0692_0">
											<gml:posList>35.668581641160614 139.73995354989745 26.703 35.66857948889007 139.73996776862052 26.703 35.668578933293595 139.73997196675174 26.703 35.668581641160614 139.73995354989745 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95f69cfb-4f4d-44eb-95cd-47f0aa0f0fb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95f69cfb-4f4d-44eb-95cd-47f0aa0f0fb5_0">
											<gml:posList>35.66856920791222 139.739972530376 26.703 35.66857919035798 139.7399663771707 26.703 35.6685683855821 139.73996984715313 26.703 35.66856920791222 139.739972530376 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e3b0194-0aa4-4239-bffc-4075a302c550">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e3b0194-0aa4-4239-bffc-4075a302c550_0">
											<gml:posList>35.66857948889007 139.73996776862052 26.703 35.668569947911244 139.7399736562074 26.703 35.668578933293595 139.73997196675174 26.703 35.66857948889007 139.73996776862052 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7a38a9a-fb23-4325-b729-48b8398da7bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7a38a9a-fb23-4325-b729-48b8398da7bb_0">
											<gml:posList>35.6685753665732 139.73997547249007 26.703 35.66857646585373 139.73997496309366 28.42 35.6685753665732 139.73997547249007 28.42 35.6685753665732 139.73997547249007 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6697e0a6-0e21-4197-8c60-4f25bf709939">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6697e0a6-0e21-4197-8c60-4f25bf709939_0">
											<gml:posList>35.6685753665732 139.73997547249007 26.703 35.66857646585373 139.73997496309366 26.703 35.66857646585373 139.73997496309366 28.42 35.6685753665732 139.73997547249007 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ee03aee-b043-405b-8397-a3c98d1853ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ee03aee-b043-405b-8397-a3c98d1853ed_0">
											<gml:posList>35.66857702448587 139.7399630548434 26.703 35.66857597837984 139.7399623933009 28.42 35.66857702448587 139.7399630548434 28.42 35.66857702448587 139.7399630548434 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-547c0a17-9bbc-40f9-979d-a2cdfb0a1030">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-547c0a17-9bbc-40f9-979d-a2cdfb0a1030_0">
											<gml:posList>35.66857702448587 139.7399630548434 26.703 35.66857597837984 139.7399623933009 26.703 35.66857597837984 139.7399623933009 28.42 35.66857702448587 139.7399630548434 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-058c8206-1a8a-4697-90a3-c9280a24194c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-058c8206-1a8a-4697-90a3-c9280a24194c_0">
											<gml:posList>35.66857646585373 139.73997496309366 26.703 35.66857744774175 139.73997417768365 28.42 35.66857646585373 139.73997496309366 28.42 35.66857646585373 139.73997496309366 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3d276ad-a058-461c-9e69-1d5a5ae4d13e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3d276ad-a058-461c-9e69-1d5a5ae4d13e_0">
											<gml:posList>35.66857646585373 139.73997496309366 26.703 35.66857744774175 139.73997417768365 26.703 35.66857744774175 139.73997417768365 28.42 35.66857646585373 139.73997496309366 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d68fa208-350f-4444-9e5b-cbb20810e024">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d68fa208-350f-4444-9e5b-cbb20810e024_0">
											<gml:posList>35.66857792656074 139.73996395956587 26.703 35.66857702448587 139.7399630548434 28.42 35.66857792656074 139.73996395956587 28.42 35.66857792656074 139.73996395956587 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8824c054-1494-4782-8086-a7f11a4bddce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8824c054-1494-4782-8086-a7f11a4bddce_0">
											<gml:posList>35.66857792656074 139.73996395956587 26.703 35.66857702448587 139.7399630548434 26.703 35.66857702448587 139.7399630548434 28.42 35.66857792656074 139.73996395956587 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba010df1-83e2-4e8e-91ca-37dc0003e318">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba010df1-83e2-4e8e-91ca-37dc0003e318_0">
											<gml:posList>35.66857368555715 139.74008604501262 42.257 35.668581689297845 139.74007381881597 42.714 35.668581698303015 139.74007380775947 42.257 35.66857368555715 139.74008604501262 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b39c14c-4111-4564-952c-868306ece4a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b39c14c-4111-4564-952c-868306ece4a7_0">
											<gml:posList>35.66857368555715 139.74008604501262 42.257 35.66857368555715 139.74008604501262 42.714 35.668581689297845 139.74007381881597 42.714 35.66857368555715 139.74008604501262 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-caf49504-b139-4af6-a425-e41ab6649813">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-caf49504-b139-4af6-a425-e41ab6649813_0">
											<gml:posList>35.668578285238866 139.7399731715215 26.703 35.66857744774175 139.73997417768365 28.42 35.66857744774175 139.73997417768365 26.703 35.668578285238866 139.7399731715215 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-324b7f74-1e3d-47cd-9266-810b22451d16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-324b7f74-1e3d-47cd-9266-810b22451d16_0">
											<gml:posList>35.668578285238866 139.7399731715215 26.703 35.668578285238866 139.7399731715215 28.42 35.66857744774175 139.73997417768365 28.42 35.668578285238866 139.7399731715215 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0552ac80-537c-4674-998c-804cfd10747d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0552ac80-537c-4674-998c-804cfd10747d_0">
											<gml:posList>35.66857792656074 139.73996395956587 26.703 35.668578666559824 139.73996508539733 28.42 35.668578666559824 139.73996508539733 26.703 35.66857792656074 139.73996395956587 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2dd2b8d-0037-4130-8344-7b8a430dbcad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2dd2b8d-0037-4130-8344-7b8a430dbcad_0">
											<gml:posList>35.66857792656074 139.73996395956587 26.703 35.66857792656074 139.73996395956587 28.42 35.668578666559824 139.73996508539733 28.42 35.66857792656074 139.73996395956587 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-361336db-1d5d-42ca-9fde-760989c2d9c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-361336db-1d5d-42ca-9fde-760989c2d9c9_0">
											<gml:posList>35.668578933293595 139.73997196675174 26.703 35.668578285238866 139.7399731715215 28.42 35.668578285238866 139.7399731715215 26.703 35.668578933293595 139.73997196675174 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a60e697d-658b-408b-a62c-e5fff7715836">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a60e697d-658b-408b-a62c-e5fff7715836_0">
											<gml:posList>35.668578933293595 139.73997196675174 26.703 35.668578933293595 139.73997196675174 28.42 35.668578285238866 139.7399731715215 28.42 35.668578933293595 139.73997196675174 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ab7b37a-16f9-4e54-b4cb-18f5ac8bff80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ab7b37a-16f9-4e54-b4cb-18f5ac8bff80_0">
											<gml:posList>35.66857919035798 139.7399663771707 26.703 35.668578666559824 139.73996508539733 28.42 35.66857919035798 139.7399663771707 28.42 35.66857919035798 139.7399663771707 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa6903ae-bd81-49a8-88a3-501a2385fd92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa6903ae-bd81-49a8-88a3-501a2385fd92_0">
											<gml:posList>35.66857919035798 139.7399663771707 26.703 35.668578666559824 139.73996508539733 26.703 35.668578666559824 139.73996508539733 28.42 35.66857919035798 139.7399663771707 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1aaff33-ab8c-4083-9258-a4a396d50891">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1aaff33-ab8c-4083-9258-a4a396d50891_0">
											<gml:posList>35.668578933293595 139.73997196675174 26.703 35.66857935590239 139.7399706296923 28.42 35.668578933293595 139.73997196675174 28.42 35.668578933293595 139.73997196675174 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5578f26-f01a-4cd1-b49f-c130d68a9b7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5578f26-f01a-4cd1-b49f-c130d68a9b7d_0">
											<gml:posList>35.668578933293595 139.73997196675174 26.703 35.66857935590239 139.7399706296923 26.703 35.66857935590239 139.7399706296923 28.42 35.668578933293595 139.73997196675174 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6dd929a3-d6e3-42d2-a061-1cbcaba126d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6dd929a3-d6e3-42d2-a061-1cbcaba126d7_0">
											<gml:posList>35.66857919035798 139.7399663771707 26.703 35.66857948889007 139.73996776862052 28.42 35.66857948889007 139.73996776862052 26.703 35.66857919035798 139.7399663771707 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-960b78da-0a5d-453d-826a-9563f83e49be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-960b78da-0a5d-453d-826a-9563f83e49be_0">
											<gml:posList>35.66857919035798 139.7399663771707 26.703 35.66857919035798 139.7399663771707 28.42 35.66857948889007 139.73996776862052 28.42 35.66857919035798 139.7399663771707 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf71724a-0b6a-437c-978d-3006b6d0f9ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf71724a-0b6a-437c-978d-3006b6d0f9ff_0">
											<gml:posList>35.66857935590239 139.7399706296923 26.703 35.668579544085816 139.73996920453772 28.42 35.66857935590239 139.7399706296923 28.42 35.66857935590239 139.7399706296923 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da2b1de9-6604-4ef0-9a10-a9df9d869bb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da2b1de9-6604-4ef0-9a10-a9df9d869bb5_0">
											<gml:posList>35.66857935590239 139.7399706296923 26.703 35.668579544085816 139.73996920453772 26.703 35.668579544085816 139.73996920453772 28.42 35.66857935590239 139.7399706296923 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d955e1e-edaf-41d8-b523-00f7310a4058">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d955e1e-edaf-41d8-b523-00f7310a4058_0">
											<gml:posList>35.668579544085816 139.73996920453772 26.703 35.66857948889007 139.73996776862052 28.42 35.668579544085816 139.73996920453772 28.42 35.668579544085816 139.73996920453772 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b46e66f-9be4-474f-ba18-395a75895dae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b46e66f-9be4-474f-ba18-395a75895dae_0">
											<gml:posList>35.668579544085816 139.73996920453772 26.703 35.66857948889007 139.73996776862052 26.703 35.66857948889007 139.73996776862052 28.42 35.668579544085816 139.73996920453772 26.703</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b0a4187-df26-4321-93d3-6e4868b64857">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b0a4187-df26-4321-93d3-6e4868b64857_0">
											<gml:posList>35.668578796600904 139.7399584245011 24.383 35.668581641160614 139.73995354989745 26.703 35.668581641160614 139.73995354989745 24.383 35.668578796600904 139.7399584245011 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bbbea04-997c-4e51-9389-99403205e077">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bbbea04-997c-4e51-9389-99403205e077_0">
											<gml:posList>35.668578796600904 139.7399584245011 24.383 35.668578796600904 139.7399584245011 26.703 35.668581641160614 139.73995354989745 26.703 35.668578796600904 139.7399584245011 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7553d38-701f-4344-ab83-3aeab4ad3883">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7553d38-701f-4344-ab83-3aeab4ad3883_0">
											<gml:posList>35.668581698303015 139.74007380775947 42.257 35.66858396246758 139.74007602537446 42.714 35.66858396246758 139.74007602537446 42.257 35.668581698303015 139.74007380775947 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10caa7e1-788e-4608-9e23-5f9546cd094b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10caa7e1-788e-4608-9e23-5f9546cd094b_0">
											<gml:posList>35.668581698303015 139.74007380775947 42.257 35.668581689297845 139.74007381881597 42.714 35.66858396246758 139.74007602537446 42.714 35.668581698303015 139.74007380775947 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68e315fe-a021-41ab-a139-991d351230bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68e315fe-a021-41ab-a139-991d351230bf_0">
											<gml:posList>35.66857840436484 139.73998731027712 24.383 35.668592537141315 139.7399630809635 26.703 35.66857840436484 139.73998731027712 26.703 35.66857840436484 139.73998731027712 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8aba1e82-0c2c-48a3-952b-662bf4e20652">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8aba1e82-0c2c-48a3-952b-662bf4e20652_0">
											<gml:posList>35.66857840436484 139.73998731027712 24.383 35.668592537141315 139.7399630809635 24.383 35.668592537141315 139.7399630809635 26.703 35.66857840436484 139.73998731027712 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-417a0d31-3bc8-47ad-949f-ff76e344a2a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-417a0d31-3bc8-47ad-949f-ff76e344a2a0_0">
											<gml:posList>35.668592537141315 139.7399630809635 24.383 35.668581641160614 139.73995354989745 26.703 35.668592537141315 139.7399630809635 26.703 35.668592537141315 139.7399630809635 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbc779a6-d3d4-4aab-883e-312f80191a00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbc779a6-d3d4-4aab-883e-312f80191a00_0">
											<gml:posList>35.668592537141315 139.7399630809635 24.383 35.668581641160614 139.73995354989745 24.383 35.668581641160614 139.73995354989745 26.703 35.668592537141315 139.7399630809635 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8c86759-09b1-4339-b927-296cf7da860c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8c86759-09b1-4339-b927-296cf7da860c_0">
											<gml:posList>35.66857334564709 139.7401476379624 42.714 35.66857334564709 139.7401476379624 42.473 35.66857346268875 139.7401474610902 42.473 35.66857334564709 139.7401476379624 42.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3921b76d-d4e3-414d-ab79-76188e4c78d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3921b76d-d4e3-414d-ab79-76188e4c78d4_0">
											<gml:posList>35.66857334564709 139.7401476379624 42.714 35.66857346268875 139.7401474610902 42.473 35.66860602686476 139.74009772722374 42.714 35.66857334564709 139.7401476379624 42.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad84bc40-9c64-45d3-9579-5e703535b43b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad84bc40-9c64-45d3-9579-5e703535b43b_0">
											<gml:posList>35.66857346268875 139.7401474610902 42.473 35.66860602686476 139.74009772722374 42.257 35.66860602686476 139.74009772722374 42.714 35.66857346268875 139.7401474610902 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-980ca6c6-21c2-4750-a315-74258c546e9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-980ca6c6-21c2-4750-a315-74258c546e9b_0">
											<gml:posList>35.66857346268875 139.7401474610902 42.473 35.66857346268875 139.7401474610902 42.258 35.66860602686476 139.74009772722374 42.257 35.66857346268875 139.7401474610902 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7a55cd7-5900-4ef0-b38c-31198b5ebf4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7a55cd7-5900-4ef0-b38c-31198b5ebf4a_0">
											<gml:posList>35.66858396246758 139.74007602537446 42.257 35.66860602686476 139.74009772722374 42.714 35.66860602686476 139.74009772722374 42.257 35.66858396246758 139.74007602537446 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15e9f783-b0ab-4963-8e25-fab2bfa515db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15e9f783-b0ab-4963-8e25-fab2bfa515db_0">
											<gml:posList>35.66858396246758 139.74007602537446 42.257 35.66858396246758 139.74007602537446 42.714 35.66860602686476 139.74009772722374 42.714 35.66858396246758 139.74007602537446 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8555de83-e0d6-4452-afad-6a0c7a08ca20">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668570038311834 139.73995074667738 24.383 35.668578796600904 139.7399584245011 24.383 35.66855875009817 139.73997010138467 24.383 35.668570038311834 139.73995074667738 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2e03f10-d436-4dd2-96d2-2cfee220f2a9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855875009817 139.73997010138467 24.383 35.668578796600904 139.7399584245011 24.383 35.66857840436484 139.73998731027712 24.383 35.66855875009817 139.73997010138467 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14ec94cd-1709-4e58-9fd2-c65c82df112c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857840436484 139.73998731027712 24.383 35.668578796600904 139.7399584245011 24.383 35.668592537141315 139.7399630809635 24.383 35.66857840436484 139.73998731027712 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a31e3c7e-4984-4b10-920a-b8b1cd21e00c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668578796600904 139.7399584245011 24.383 35.668581641160614 139.73995354989745 24.383 35.668592537141315 139.7399630809635 24.383 35.668578796600904 139.7399584245011 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f502f88c-395c-4831-b6a9-4d4c829472bc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668560154652575 139.7400727392617 42.257 35.66857368555715 139.74008604501262 42.257 35.66853560322771 139.74011022482134 42.257 35.668560154652575 139.7400727392617 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fd0440c-b236-41d9-a04c-164d3a411090">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853560322771 139.74011022482134 42.257 35.66857368555715 139.74008604501262 42.257 35.66857346268875 139.7401474610902 42.258 35.66853560322771 139.74011022482134 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b800521c-e852-430a-ba03-0f84431d46ff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857346268875 139.7401474610902 42.258 35.66857368555715 139.74008604501262 42.257 35.66860602686476 139.74009772722374 42.257 35.66857346268875 139.7401474610902 42.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-224803b7-821d-47f9-9f15-f0e14be3360c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857368555715 139.74008604501262 42.257 35.668581698303015 139.74007380775947 42.257 35.66858396246758 139.74007602537446 42.257 35.66857368555715 139.74008604501262 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b46970f6-d991-42ac-bd44-a981c5a59170">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860602686476 139.74009772722374 42.257 35.66857368555715 139.74008604501262 42.257 35.66858396246758 139.74007602537446 42.257 35.66860602686476 139.74009772722374 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dac5e6d6-7d43-4f1d-80a6-8c6bf122e36d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853560322771 139.74011022482134 42.473 35.66857334564709 139.7401476379624 42.473 35.668535486186116 139.74011040169347 42.473 35.66853560322771 139.74011022482134 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79a2d818-0133-4407-a6d5-4f86a4e0b5cd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853560322771 139.74011022482134 42.473 35.66857346268875 139.7401474610902 42.473 35.66857334564709 139.7401476379624 42.473 35.66853560322771 139.74011022482134 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1528f501-baf3-4404-bc10-d1fa3717af69_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65d0879a-b4d5-4d7a-ad66-f1308883fc94">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668602688992976 139.74004757115304 11.24 35.66862303099515 139.74006826981537 11.24 35.66860877085072 139.7400910080557 11.24 35.66858733857663 139.74007080772998 11.24 35.668602688992976 139.74004757115304 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5105fa8-d11d-4620-a176-583c59840a3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5105fa8-d11d-4620-a176-583c59840a3a_0">
											<gml:posList>35.66862303099515 139.74006826981537 11.24 35.668602688992976 139.74004757115304 11.24 35.668602688992976 139.74004757115304 42.473 35.66862303099515 139.74006826981537 40.797 35.66862303099515 139.74006826981537 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc401b6b-2076-4ae4-87c0-bb65f244b378">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc401b6b-2076-4ae4-87c0-bb65f244b378_0">
											<gml:posList>35.66858733857663 139.74007080772998 11.24 35.66858733857663 139.74007080772998 42.473 35.668602688992976 139.74004757115304 42.473 35.668602688992976 139.74004757115304 11.24 35.66858733857663 139.74007080772998 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78419604-dbe5-4148-9fe1-9210169b579c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78419604-dbe5-4148-9fe1-9210169b579c_0">
											<gml:posList>35.66858733857663 139.74007080772998 42.473 35.66860877085072 139.7400910080557 40.797 35.66862303099515 139.74006826981537 40.797 35.668602688992976 139.74004757115304 42.473 35.66858733857663 139.74007080772998 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efcbd9fb-5538-45be-9f03-82e305d9efb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efcbd9fb-5538-45be-9f03-82e305d9efb1_0">
											<gml:posList>35.66862303099515 139.74006826981537 11.24 35.66862303099515 139.74006826981537 40.797 35.66860877085072 139.7400910080557 40.797 35.66860877085072 139.7400910080557 11.24 35.66862303099515 139.74006826981537 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcfa18cc-dfe7-467c-999f-79889d0eb933">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcfa18cc-dfe7-467c-999f-79889d0eb933_0">
											<gml:posList>35.66860877085072 139.7400910080557 11.24 35.66860877085072 139.7400910080557 40.797 35.66858733857663 139.74007080772998 42.473 35.66858733857663 139.74007080772998 11.24 35.66860877085072 139.7400910080557 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-dc7697b6-da06-4e3b-b4f9-762bdafcb781">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc7697b6-da06-4e3b-b4f9-762bdafcb781">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc7697b6-da06-4e3b-b4f9-762bdafcb781">
											<gml:posList>35.668583143681616 139.7401594237161 11.24 35.66852144277615 139.74009874239522 11.24 35.66858238582398 139.74000719950914 11.24 35.66854667300803 139.73997179444 11.24 35.668485270363725 139.74006343726072 11.24 35.66843240953768 139.7400113616711 11.24 35.668534870329346 139.7398624527314 11.24 35.66858556723922 139.73991364712933 11.24 35.668577194157734 139.73992613887705 11.24 35.66866316338867 139.7400142964515 11.24 35.668633182259455 139.7400589572601 11.24 35.668610476768315 139.74003582017806 11.24 35.6685999067212 139.74005140735687 11.24 35.66858733857663 139.74007080772998 11.24 35.66861964032671 139.74010124611956 11.24 35.668583143681616 139.7401594237161 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b5a19e8f-64c3-437b-9073-ffed3390c74a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5a19e8f-64c3-437b-9073-ffed3390c74a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5a19e8f-64c3-437b-9073-ffed3390c74a">
											<gml:posList>35.668485270363725 139.74006343726072 24.242 35.668484970104416 139.74005981452254 24.242 35.66843541984806 139.7400110046958 24.242 35.66843240953768 139.7400113616711 24.242 35.668485270363725 139.74006343726072 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e9e3170-4615-4ed8-a146-2b069f18cd15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e9e3170-4615-4ed8-a146-2b069f18cd15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e9e3170-4615-4ed8-a146-2b069f18cd15">
											<gml:posList>35.66843240953768 139.7400113616711 24.242 35.66843541984806 139.7400110046958 24.242 35.66853514356199 139.73986608654857 24.242 35.668534870329346 139.7398624527314 24.242 35.66843240953768 139.7400113616711 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f626e9e4-d1fc-48f2-9a36-c52a53a9ed64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f626e9e4-d1fc-48f2-9a36-c52a53a9ed64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f626e9e4-d1fc-48f2-9a36-c52a53a9ed64">
											<gml:posList>35.66853688062264 139.73993244892443 23.932 35.66854258174363 139.73993817516072 23.932 35.66854815477953 139.73992983998014 23.932 35.66856242562206 139.73994417212194 23.932 35.66857555240016 139.739924517026 23.932 35.66858260199785 139.73991400405643 23.932 35.66853514356199 139.73986608654857 23.932 35.66843541984806 139.7400110046958 23.932 35.668484970104416 139.74005981452254 23.932 35.66853574883065 139.73998402404152 23.932 35.66853708131205 139.73998202316324 23.932 35.66853419467632 139.73997913247058 23.932 35.66850729282963 139.74001937123643 23.932 35.6684959356979 139.74000796288962 23.932 35.668513654186 139.73998146499963 23.932 35.66850794405331 139.73997573877278 23.932 35.66853688062264 139.73993244892443 23.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb6e8f4e-9bfc-4aa2-8599-2e04130229da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb6e8f4e-9bfc-4aa2-8599-2e04130229da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb6e8f4e-9bfc-4aa2-8599-2e04130229da">
											<gml:posList>35.668485270363725 139.74006343726072 24.242 35.66853872308599 139.73998366710669 24.242 35.66853708131205 139.73998202316324 24.242 35.66853574883065 139.73998402404152 24.242 35.668484970104416 139.74005981452254 24.242 35.668485270363725 139.74006343726072 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26a1dd1a-93b0-49b1-b000-e08d67f3f165">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26a1dd1a-93b0-49b1-b000-e08d67f3f165">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26a1dd1a-93b0-49b1-b000-e08d67f3f165">
											<gml:posList>35.66854258174363 139.73993817516072 25.737 35.66853688062264 139.73993244892443 25.737 35.66850794405331 139.73997573877278 25.737 35.668513654186 139.73998146499963 25.737 35.6684959356979 139.74000796288962 25.737 35.66850729282963 139.74001937123643 25.737 35.66853419467632 139.73997913247058 25.737 35.66853872308599 139.73998366710669 25.737 35.6685640493605 139.73994580504015 25.737 35.66854815477953 139.73992983998014 25.737 35.66854258174363 139.73993817516072 25.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b9dce0d-7003-44e3-9f44-65057305f9ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b9dce0d-7003-44e3-9f44-65057305f9ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b9dce0d-7003-44e3-9f44-65057305f9ba">
											<gml:posList>35.66852364191133 139.740098463688 42.473 35.66855644075797 139.74004916035392 42.473 35.6685552049363 139.74004794673078 42.473 35.66852140669559 139.74009870929916 42.473 35.66852364191133 139.740098463688 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-784ae07f-aa70-4468-9efc-a805d155930b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-784ae07f-aa70-4468-9efc-a805d155930b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-784ae07f-aa70-4468-9efc-a805d155930b">
											<gml:posList>35.668583143681616 139.7401594237161 42.473 35.66858288019807 139.74015672879543 42.473 35.66852364191133 139.740098463688 42.473 35.66852140669559 139.74009870929916 42.473 35.668583143681616 139.7401594237161 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de1ef809-d64a-4411-a90f-0c1ddbb2e70c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de1ef809-d64a-4411-a90f-0c1ddbb2e70c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de1ef809-d64a-4411-a90f-0c1ddbb2e70c">
											<gml:posList>35.668534870329346 139.7398624527314 24.242 35.66853514356199 139.73986608654857 24.242 35.66858260199785 139.73991400405643 24.242 35.66858556723922 139.73991364712933 24.242 35.668534870329346 139.7398624527314 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cccc2c01-f609-461c-8906-4e211ca56dc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cccc2c01-f609-461c-8906-4e211ca56dc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cccc2c01-f609-461c-8906-4e211ca56dc0">
											<gml:posList>35.66856242562206 139.73994417212194 24.242 35.6685640493605 139.73994580504015 24.242 35.668577194157734 139.73992613887705 24.242 35.66857555240016 139.739924517026 24.242 35.66856242562206 139.73994417212194 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f01ba022-a131-4465-9dd6-915878b75ebc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f01ba022-a131-4465-9dd6-915878b75ebc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f01ba022-a131-4465-9dd6-915878b75ebc">
											<gml:posList>35.66852364191133 139.740098463688 42.257 35.66858288019807 139.74015672879543 42.257 35.66861746828405 139.7401015910716 42.257 35.66858638426814 139.7400722890056 42.257 35.66858396246758 139.74007602537446 42.257 35.66855644075797 139.74004916035392 42.257 35.66852364191133 139.740098463688 42.257</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-864c5d11-a8eb-4aa2-8f02-195465758f47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-864c5d11-a8eb-4aa2-8f02-195465758f47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-864c5d11-a8eb-4aa2-8f02-195465758f47">
											<gml:posList>35.66857137477563 139.74002364878825 45.02 35.66855515991046 139.74004800201322 45.02 35.66858396246758 139.74007602537446 45.02 35.6685999067212 139.74005140735687 45.02 35.66857137477563 139.74002364878825 45.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5004026c-df60-4c3a-94ee-95d540da7bad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5004026c-df60-4c3a-94ee-95d540da7bad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5004026c-df60-4c3a-94ee-95d540da7bad">
											<gml:posList>35.668577194157734 139.73992613887705 24.242 35.66858556723922 139.73991364712933 24.242 35.66858260199785 139.73991400405643 24.242 35.66857555240016 139.739924517026 24.242 35.668577194157734 139.73992613887705 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2da4e51c-4414-42b5-9db3-5f1030dc0501">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2da4e51c-4414-42b5-9db3-5f1030dc0501">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2da4e51c-4414-42b5-9db3-5f1030dc0501">
											<gml:posList>35.66863323202965 139.73998360126242 24.383 35.668577194157734 139.73992613887705 24.383 35.6685640493605 139.73994580504015 24.383 35.66854667300803 139.73997179444 24.383 35.66858236778798 139.7400071884841 24.383 35.66860479362811 139.74003002763297 24.383 35.66863323202965 139.73998360126242 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-effb663b-cd43-4d6c-8121-a6fc153c3663">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-effb663b-cd43-4d6c-8121-a6fc153c3663">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-effb663b-cd43-4d6c-8121-a6fc153c3663">
											<gml:posList>35.6685999067212 139.74005140735687 42.473 35.668610476768315 139.74003582017806 42.473 35.6685823497434 139.7400071664131 42.473 35.668571410787735 139.7400235935163 42.473 35.6685999067212 139.74005140735687 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4f918b6-8e54-4b12-9a92-12ed886578f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4f918b6-8e54-4b12-9a92-12ed886578f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4f918b6-8e54-4b12-9a92-12ed886578f8">
											<gml:posList>35.66861964032671 139.74010124611956 42.473 35.66861746828405 139.7401015910716 42.473 35.66858288019807 139.74015672879543 42.473 35.668583143681616 139.7401594237161 42.473 35.66861964032671 139.74010124611956 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc9fa9b3-1ce9-4894-965f-9820a94f6eee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc9fa9b3-1ce9-4894-965f-9820a94f6eee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc9fa9b3-1ce9-4894-965f-9820a94f6eee">
											<gml:posList>35.66861746828405 139.7401015910716 42.473 35.66861964032671 139.74010124611956 42.473 35.66858733857663 139.74007080772998 42.473 35.66858638426814 139.7400722890056 42.473 35.66861746828405 139.7401015910716 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b90bd41-609e-4424-a520-1605e7db1256">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b90bd41-609e-4424-a520-1605e7db1256">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b90bd41-609e-4424-a520-1605e7db1256">
											<gml:posList>35.66860479362811 139.74003002763297 24.383 35.66866316338867 139.7400142964515 19.455 35.66863323202965 139.73998360126242 24.383 35.66860479362811 139.74003002763297 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c75a1ba2-3620-49e6-a761-651455c4f9cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c75a1ba2-3620-49e6-a761-651455c4f9cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c75a1ba2-3620-49e6-a761-651455c4f9cd">
											<gml:posList>35.66860479362811 139.74003002763297 24.383 35.668633182259455 139.7400589572601 19.455 35.66866316338867 139.7400142964515 19.455 35.66860479362811 139.74003002763297 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b16919b0-fcbc-42fa-bc36-7c541da99bf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b16919b0-fcbc-42fa-bc36-7c541da99bf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b16919b0-fcbc-42fa-bc36-7c541da99bf8">
											<gml:posList>35.66853708131205 139.73998202316324 24.242 35.66853708131205 139.73998202316324 23.932 35.66853574883065 139.73998402404152 23.932 35.66853574883065 139.73998402404152 24.242 35.66853708131205 139.73998202316324 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d30db9ee-05e6-4321-90fb-0890e07dff8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d30db9ee-05e6-4321-90fb-0890e07dff8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d30db9ee-05e6-4321-90fb-0890e07dff8d">
											<gml:posList>35.66853574883065 139.73998402404152 24.242 35.66853574883065 139.73998402404152 23.932 35.668484970104416 139.74005981452254 23.932 35.668484970104416 139.74005981452254 24.242 35.66853574883065 139.73998402404152 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa4bc009-63c7-4c9f-a8dd-ee6c5fec0f86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa4bc009-63c7-4c9f-a8dd-ee6c5fec0f86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa4bc009-63c7-4c9f-a8dd-ee6c5fec0f86">
											<gml:posList>35.66861746828405 139.7401015910716 42.473 35.66861746828405 139.7401015910716 42.257 35.66858288019807 139.74015672879543 42.257 35.66858288019807 139.74015672879543 42.473 35.66861746828405 139.7401015910716 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79e97322-68c4-45c0-91f5-da6956840c1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79e97322-68c4-45c0-91f5-da6956840c1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79e97322-68c4-45c0-91f5-da6956840c1e">
											<gml:posList>35.66843240953768 139.7400113616711 11.24 35.668485270363725 139.74006343726072 11.24 35.668485270363725 139.74006343726072 24.242 35.66843240953768 139.7400113616711 24.242 35.66843240953768 139.7400113616711 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f810233-64c9-4109-bc9f-90291fe0ab98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f810233-64c9-4109-bc9f-90291fe0ab98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f810233-64c9-4109-bc9f-90291fe0ab98">
											<gml:posList>35.668484970104416 139.74005981452254 24.242 35.668484970104416 139.74005981452254 23.932 35.66843541984806 139.7400110046958 23.932 35.66843541984806 139.7400110046958 24.242 35.668484970104416 139.74005981452254 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-388aec40-d153-45cf-943e-ff81d4013e81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-388aec40-d153-45cf-943e-ff81d4013e81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-388aec40-d153-45cf-943e-ff81d4013e81">
											<gml:posList>35.668534870329346 139.7398624527314 11.24 35.66843240953768 139.7400113616711 11.24 35.66843240953768 139.7400113616711 24.242 35.668534870329346 139.7398624527314 24.242 35.668534870329346 139.7398624527314 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4dd86a9-c025-42bc-a430-fb5acbb52f65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4dd86a9-c025-42bc-a430-fb5acbb52f65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4dd86a9-c025-42bc-a430-fb5acbb52f65">
											<gml:posList>35.66843541984806 139.7400110046958 24.242 35.66843541984806 139.7400110046958 23.932 35.66853514356199 139.73986608654857 23.932 35.66853514356199 139.73986608654857 24.242 35.66843541984806 139.7400110046958 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9b4214a-81a8-4562-8395-9bfb5b8b05fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9b4214a-81a8-4562-8395-9bfb5b8b05fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9b4214a-81a8-4562-8395-9bfb5b8b05fd">
											<gml:posList>35.6684959356979 139.74000796288962 23.932 35.66850729282963 139.74001937123643 23.932 35.66850729282963 139.74001937123643 25.737 35.6684959356979 139.74000796288962 25.737 35.6684959356979 139.74000796288962 23.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef9a730a-0699-421b-95e5-4b05400aa8e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef9a730a-0699-421b-95e5-4b05400aa8e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef9a730a-0699-421b-95e5-4b05400aa8e7">
											<gml:posList>35.66858556723922 139.73991364712933 11.24 35.668534870329346 139.7398624527314 11.24 35.668534870329346 139.7398624527314 24.242 35.66858556723922 139.73991364712933 24.242 35.66858556723922 139.73991364712933 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-270d3c78-b7c2-4b4a-925c-4ce40346bbe2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-270d3c78-b7c2-4b4a-925c-4ce40346bbe2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-270d3c78-b7c2-4b4a-925c-4ce40346bbe2">
											<gml:posList>35.66853514356199 139.73986608654857 24.242 35.66853514356199 139.73986608654857 23.932 35.66858260199785 139.73991400405643 23.932 35.66858260199785 139.73991400405643 24.242 35.66853514356199 139.73986608654857 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47d7d5eb-88b5-437c-804a-bab57f8ca7d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47d7d5eb-88b5-437c-804a-bab57f8ca7d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47d7d5eb-88b5-437c-804a-bab57f8ca7d9">
											<gml:posList>35.66858260199785 139.73991400405643 24.242 35.66858260199785 139.73991400405643 23.932 35.66857555240016 139.739924517026 23.932 35.66857555240016 139.739924517026 24.242 35.66858260199785 139.73991400405643 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58ab2b4f-05ab-4388-93dc-8eee5942f011">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58ab2b4f-05ab-4388-93dc-8eee5942f011">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58ab2b4f-05ab-4388-93dc-8eee5942f011">
											<gml:posList>35.668577194157734 139.73992613887705 11.24 35.66858556723922 139.73991364712933 11.24 35.66858556723922 139.73991364712933 24.242 35.668577194157734 139.73992613887705 24.242 35.668577194157734 139.73992613887705 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2291023-8526-4728-a4ec-4b1de0dd7600">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2291023-8526-4728-a4ec-4b1de0dd7600">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2291023-8526-4728-a4ec-4b1de0dd7600">
											<gml:posList>35.66854258174363 139.73993817516072 25.737 35.66854815477953 139.73992983998014 25.737 35.66854815477953 139.73992983998014 23.932 35.66854258174363 139.73993817516072 23.932 35.66854258174363 139.73993817516072 25.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dfe204a4-951d-48de-8c8f-cfaf61f0dbbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfe204a4-951d-48de-8c8f-cfaf61f0dbbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfe204a4-951d-48de-8c8f-cfaf61f0dbbf">
											<gml:posList>35.66857555240016 139.739924517026 24.242 35.66857555240016 139.739924517026 23.932 35.66856242562206 139.73994417212194 23.932 35.66856242562206 139.73994417212194 24.242 35.66857555240016 139.739924517026 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c4ae690-f1d1-4c54-8941-9f5d68542bc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c4ae690-f1d1-4c54-8941-9f5d68542bc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c4ae690-f1d1-4c54-8941-9f5d68542bc0">
											<gml:posList>35.66853688062264 139.73993244892443 25.737 35.66854258174363 139.73993817516072 25.737 35.66854258174363 139.73993817516072 23.932 35.66853688062264 139.73993244892443 23.932 35.66853688062264 139.73993244892443 25.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2fac018f-c402-4533-9b4f-ce7588e88366">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fac018f-c402-4533-9b4f-ce7588e88366">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fac018f-c402-4533-9b4f-ce7588e88366">
											<gml:posList>35.6685640493605 139.73994580504015 24.242 35.6685640493605 139.73994580504015 24.383 35.668577194157734 139.73992613887705 24.383 35.668577194157734 139.73992613887705 24.242 35.6685640493605 139.73994580504015 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fc04e3e-ee16-47c7-9da2-420861ef6ee8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fc04e3e-ee16-47c7-9da2-420861ef6ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fc04e3e-ee16-47c7-9da2-420861ef6ee8">
											<gml:posList>35.6685640493605 139.73994580504015 24.383 35.6685640493605 139.73994580504015 24.242 35.66856242562206 139.73994417212194 24.242 35.66856242562206 139.73994417212194 23.932 35.66854815477953 139.73992983998014 23.932 35.66854815477953 139.73992983998014 25.737 35.6685640493605 139.73994580504015 25.737 35.6685640493605 139.73994580504015 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b9d6f0c-5b21-4712-a268-7d15dfbb10d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b9d6f0c-5b21-4712-a268-7d15dfbb10d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b9d6f0c-5b21-4712-a268-7d15dfbb10d3">
											<gml:posList>35.66850794405331 139.73997573877278 25.737 35.66853688062264 139.73993244892443 25.737 35.66853688062264 139.73993244892443 23.932 35.66850794405331 139.73997573877278 23.932 35.66850794405331 139.73997573877278 25.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c843eef-d485-46a6-8c5f-240e0ce32d8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c843eef-d485-46a6-8c5f-240e0ce32d8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c843eef-d485-46a6-8c5f-240e0ce32d8a">
											<gml:posList>35.66863323202965 139.73998360126242 24.383 35.66866316338867 139.7400142964515 19.455 35.66866316338867 139.7400142964515 11.24 35.668577194157734 139.73992613887705 11.24 35.668577194157734 139.73992613887705 24.242 35.668577194157734 139.73992613887705 24.383 35.66863323202965 139.73998360126242 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1837a051-5753-41a2-89f3-c90216a27deb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1837a051-5753-41a2-89f3-c90216a27deb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1837a051-5753-41a2-89f3-c90216a27deb">
											<gml:posList>35.66850794405331 139.73997573877278 23.932 35.668513654186 139.73998146499963 23.932 35.668513654186 139.73998146499963 25.737 35.66850794405331 139.73997573877278 25.737 35.66850794405331 139.73997573877278 23.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-095c2951-7a5a-413c-b473-9003c6716c13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-095c2951-7a5a-413c-b473-9003c6716c13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-095c2951-7a5a-413c-b473-9003c6716c13">
											<gml:posList>35.66853872308599 139.73998366710669 25.737 35.66853419467632 139.73997913247058 25.737 35.66853419467632 139.73997913247058 23.932 35.66853708131205 139.73998202316324 23.932 35.66853708131205 139.73998202316324 24.242 35.66853872308599 139.73998366710669 24.242 35.66853872308599 139.73998366710669 25.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-723d9a4b-1dde-49c0-93cb-d8c21a511fff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-723d9a4b-1dde-49c0-93cb-d8c21a511fff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-723d9a4b-1dde-49c0-93cb-d8c21a511fff">
											<gml:posList>35.66854667300803 139.73997179444 11.24 35.66858238582398 139.74000719950914 11.24 35.66858236778798 139.7400071884841 24.383 35.66854667300803 139.73997179444 24.383 35.66854667300803 139.73997179444 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d69dba0d-3f79-40fb-b192-d6a69b70301d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d69dba0d-3f79-40fb-b192-d6a69b70301d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d69dba0d-3f79-40fb-b192-d6a69b70301d">
											<gml:posList>35.6684959356979 139.74000796288962 25.737 35.668513654186 139.73998146499963 25.737 35.668513654186 139.73998146499963 23.932 35.6684959356979 139.74000796288962 23.932 35.6684959356979 139.74000796288962 25.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37aae37c-d1cd-47bf-bd06-e63c0a270cec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37aae37c-d1cd-47bf-bd06-e63c0a270cec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37aae37c-d1cd-47bf-bd06-e63c0a270cec">
											<gml:posList>35.66850729282963 139.74001937123643 23.932 35.66853419467632 139.73997913247058 23.932 35.66853419467632 139.73997913247058 25.737 35.66850729282963 139.74001937123643 25.737 35.66850729282963 139.74001937123643 23.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44eaa263-bd4a-4065-8bd5-457247b7c87c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44eaa263-bd4a-4065-8bd5-457247b7c87c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44eaa263-bd4a-4065-8bd5-457247b7c87c">
											<gml:posList>35.66853872308599 139.73998366710669 24.242 35.668485270363725 139.74006343726072 24.242 35.668485270363725 139.74006343726072 11.24 35.66854667300803 139.73997179444 11.24 35.66854667300803 139.73997179444 24.383 35.6685640493605 139.73994580504015 24.383 35.6685640493605 139.73994580504015 25.737 35.66853872308599 139.73998366710669 25.737 35.66853872308599 139.73998366710669 24.242</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2029829a-5e6e-44ae-8be4-9aff7aefcb38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2029829a-5e6e-44ae-8be4-9aff7aefcb38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2029829a-5e6e-44ae-8be4-9aff7aefcb38">
											<gml:posList>35.6685823497434 139.7400071664131 42.473 35.668610476768315 139.74003582017806 42.473 35.66861044971003 139.7400357981175 23.426 35.66860479362811 139.74003002763297 24.383 35.66858236778798 139.7400071884841 24.383 35.6685823497434 139.7400071664131 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35e9ce53-cc39-4489-aa42-a9228fe62d40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35e9ce53-cc39-4489-aa42-a9228fe62d40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35e9ce53-cc39-4489-aa42-a9228fe62d40">
											<gml:posList>35.6685552049363 139.74004794673078 42.473 35.66855515991046 139.74004800201322 45.02 35.66857137477563 139.74002364878825 45.02 35.668571410787735 139.7400235935163 42.473 35.6685552049363 139.74004794673078 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f62d124-0038-48e5-9a6b-0b0a056aaebd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f62d124-0038-48e5-9a6b-0b0a056aaebd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f62d124-0038-48e5-9a6b-0b0a056aaebd">
											<gml:posList>35.668633182259455 139.7400589572601 11.24 35.66866316338867 139.7400142964515 11.24 35.66866316338867 139.7400142964515 19.455 35.668633182259455 139.7400589572601 19.455 35.668633182259455 139.7400589572601 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c697c8e7-c776-45df-8db7-bacb2c9597c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c697c8e7-c776-45df-8db7-bacb2c9597c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c697c8e7-c776-45df-8db7-bacb2c9597c2">
											<gml:posList>35.668571410787735 139.7400235935163 42.473 35.66857137477563 139.74002364878825 45.02 35.6685999067212 139.74005140735687 45.02 35.6685999067212 139.74005140735687 42.473 35.668571410787735 139.7400235935163 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-066d9b25-4936-4e45-928a-4e8815e6e1e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-066d9b25-4936-4e45-928a-4e8815e6e1e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-066d9b25-4936-4e45-928a-4e8815e6e1e2">
											<gml:posList>35.6685999067212 139.74005140735687 11.24 35.668610476768315 139.74003582017806 11.24 35.66861044971003 139.7400357981175 23.426 35.668610476768315 139.74003582017806 42.473 35.6685999067212 139.74005140735687 42.473 35.6685999067212 139.74005140735687 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72f76ba7-5165-408d-aff1-cf67d47c0f73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72f76ba7-5165-408d-aff1-cf67d47c0f73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72f76ba7-5165-408d-aff1-cf67d47c0f73">
											<gml:posList>35.668610476768315 139.74003582017806 11.24 35.668633182259455 139.7400589572601 11.24 35.668633182259455 139.7400589572601 19.455 35.66861044971003 139.7400357981175 23.426 35.668610476768315 139.74003582017806 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb451580-2ee1-40dd-ae57-38048dc0503d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb451580-2ee1-40dd-ae57-38048dc0503d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb451580-2ee1-40dd-ae57-38048dc0503d">
											<gml:posList>35.668571410787735 139.7400235935163 42.473 35.6685823497434 139.7400071664131 42.473 35.66858236778798 139.7400071884841 24.383 35.66852140669559 139.74009870929916 42.473 35.6685552049363 139.74004794673078 42.473 35.668571410787735 139.7400235935163 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d8cb238-9aa7-47e3-b283-102f7933027d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d8cb238-9aa7-47e3-b283-102f7933027d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d8cb238-9aa7-47e3-b283-102f7933027d">
											<gml:posList>35.66852144277615 139.74009874239522 11.24 35.66852140669559 139.74009870929916 42.473 35.66858236778798 139.7400071884841 24.383 35.66858238582398 139.74000719950914 11.24 35.66852144277615 139.74009874239522 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8da57ec-261e-4213-884d-88faeea5f128">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8da57ec-261e-4213-884d-88faeea5f128">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8da57ec-261e-4213-884d-88faeea5f128">
											<gml:posList>35.66855515991046 139.74004800201322 45.02 35.6685552049363 139.74004794673078 42.473 35.66855644075797 139.74004916035392 42.473 35.66855644075797 139.74004916035392 42.257 35.66858396246758 139.74007602537446 42.257 35.66858396246758 139.74007602537446 45.02 35.66855515991046 139.74004800201322 45.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-454b5b7c-9bc9-4de5-903c-2e8743f06366">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-454b5b7c-9bc9-4de5-903c-2e8743f06366">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-454b5b7c-9bc9-4de5-903c-2e8743f06366">
											<gml:posList>35.66858396246758 139.74007602537446 45.02 35.66858396246758 139.74007602537446 42.257 35.66858638426814 139.7400722890056 42.257 35.66858638426814 139.7400722890056 42.473 35.66858733857663 139.74007080772998 42.473 35.66858733857663 139.74007080772998 11.24 35.6685999067212 139.74005140735687 11.24 35.6685999067212 139.74005140735687 42.473 35.6685999067212 139.74005140735687 45.02 35.66858396246758 139.74007602537446 45.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4df2d5b-9056-40b9-b442-0c2e4deb54cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4df2d5b-9056-40b9-b442-0c2e4deb54cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4df2d5b-9056-40b9-b442-0c2e4deb54cd">
											<gml:posList>35.66852364191133 139.740098463688 42.473 35.66852364191133 139.740098463688 42.257 35.66855644075797 139.74004916035392 42.257 35.66855644075797 139.74004916035392 42.473 35.66852364191133 139.740098463688 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88f93625-db0b-433e-828e-49b6d5573cec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88f93625-db0b-433e-828e-49b6d5573cec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88f93625-db0b-433e-828e-49b6d5573cec">
											<gml:posList>35.66861964032671 139.74010124611956 11.24 35.66858733857663 139.74007080772998 11.24 35.66858733857663 139.74007080772998 42.473 35.66861964032671 139.74010124611956 42.473 35.66861964032671 139.74010124611956 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3965de1c-f9d5-4e3f-8d6c-68e567c42e09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3965de1c-f9d5-4e3f-8d6c-68e567c42e09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3965de1c-f9d5-4e3f-8d6c-68e567c42e09">
											<gml:posList>35.66858638426814 139.7400722890056 42.473 35.66858638426814 139.7400722890056 42.257 35.66861746828405 139.7401015910716 42.257 35.66861746828405 139.7401015910716 42.473 35.66858638426814 139.7400722890056 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4daf17e4-1774-4200-9fb1-398cb485ad24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4daf17e4-1774-4200-9fb1-398cb485ad24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4daf17e4-1774-4200-9fb1-398cb485ad24">
											<gml:posList>35.66858288019807 139.74015672879543 42.473 35.66858288019807 139.74015672879543 42.257 35.66852364191133 139.740098463688 42.257 35.66852364191133 139.740098463688 42.473 35.66858288019807 139.74015672879543 42.473</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1185485c-4dc3-40b3-b5b1-e16636425d5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1185485c-4dc3-40b3-b5b1-e16636425d5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1185485c-4dc3-40b3-b5b1-e16636425d5f">
											<gml:posList>35.66852144277615 139.74009874239522 11.24 35.668583143681616 139.7401594237161 11.24 35.668583143681616 139.7401594237161 42.473 35.66852140669559 139.74009870929916 42.473 35.66852144277615 139.74009874239522 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fefb2ff4-a4d0-4fa2-aea3-adf7c6c10381">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fefb2ff4-a4d0-4fa2-aea3-adf7c6c10381">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fefb2ff4-a4d0-4fa2-aea3-adf7c6c10381">
											<gml:posList>35.668583143681616 139.7401594237161 11.24 35.66861964032671 139.74010124611956 11.24 35.66861964032671 139.74010124611956 42.473 35.668583143681616 139.7401594237161 42.473 35.668583143681616 139.7401594237161 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85fdf2bd-d9c1-4509-802f-2339c53633b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85fdf2bd-d9c1-4509-802f-2339c53633b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85fdf2bd-d9c1-4509-802f-2339c53633b8">
											<gml:posList>35.66860479362811 139.74003002763297 24.383 35.66861044971003 139.7400357981175 23.426 35.668633182259455 139.7400589572601 19.455 35.66860479362811 139.74003002763297 24.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-723</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">130.24488</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>