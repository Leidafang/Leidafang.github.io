<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_15489671-3fbc-4b9f-a390-2d1653e2f141">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">30.5</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671246594959406 139.7386365677521 0 35.67123245698031 139.73853926587233 0 35.67119325398994 139.7385478179294 0 35.67119017227982 139.73852617068582 0 35.67115862964852 139.73853305673222 0 35.671175939461286 139.7386520056578 0 35.671246594959406 139.7386365677521 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671246594959406 139.7386365677521 15.73 35.671175939461286 139.7386520056578 15.73 35.67115862964852 139.73853305673222 15.73 35.67119017227982 139.73852617068582 15.73 35.67119325398994 139.7385478179294 15.73 35.67123245698031 139.73853926587233 15.73 35.671246594959406 139.7386365677521 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671246594959406 139.7386365677521 15.73 35.67123245698031 139.73853926587233 15.73 35.67123245698031 139.73853926587233 46.26 35.671246594959406 139.7386365677521 46.26 35.671246594959406 139.7386365677521 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67123245698031 139.73853926587233 15.73 35.67119325398994 139.7385478179294 15.73 35.67119325398994 139.7385478179294 46.26 35.67123245698031 139.73853926587233 46.26 35.67123245698031 139.73853926587233 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119325398994 139.7385478179294 15.73 35.67119017227982 139.73852617068582 15.73 35.67119017227982 139.73852617068582 46.26 35.67119325398994 139.7385478179294 46.26 35.67119325398994 139.7385478179294 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119017227982 139.73852617068582 15.73 35.67115862964852 139.73853305673222 15.73 35.67115862964852 139.73853305673222 46.26 35.67119017227982 139.73852617068582 46.26 35.67119017227982 139.73852617068582 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67115862964852 139.73853305673222 15.73 35.671175939461286 139.7386520056578 15.73 35.671175939461286 139.7386520056578 46.26 35.67115862964852 139.73853305673222 46.26 35.67115862964852 139.73853305673222 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671175939461286 139.7386520056578 15.73 35.671246594959406 139.7386365677521 15.73 35.671246594959406 139.7386365677521 46.26 35.671175939461286 139.7386520056578 46.26 35.671175939461286 139.7386520056578 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671246594959406 139.7386365677521 46.26 35.67123245698031 139.73853926587233 46.26 35.67119325398994 139.7385478179294 46.26 35.67119017227982 139.73852617068582 46.26 35.67115862964852 139.73853305673222 46.26 35.671175939461286 139.7386520056578 46.26 35.671246594959406 139.7386365677521 46.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-31a075dc-cab8-4805-82cd-079477bd8443"/>
							<gml:surfaceMember xlink:href="#poly-11161f6b-aa7b-4112-ad5f-c9f3815ebf35"/>
							<gml:surfaceMember xlink:href="#poly-bc888d9d-880b-4fb0-8776-e9779ae3cc55"/>
							<gml:surfaceMember xlink:href="#poly-1da07b81-ced2-444b-8bf6-27f88aeb42f8"/>
							<gml:surfaceMember xlink:href="#poly-6a70646c-3267-4bab-ae40-d449de6e5225"/>
							<gml:surfaceMember xlink:href="#poly-26309cbb-b258-4952-9706-3f00163c558c"/>
							<gml:surfaceMember xlink:href="#poly-4dd7891a-14dd-4587-ac45-6d15a431b902"/>
							<gml:surfaceMember xlink:href="#poly-08c2e60c-8041-42ee-98c8-965238a4b7e3"/>
							<gml:surfaceMember xlink:href="#poly-70909afd-2f51-474f-8a61-d4b749764dfd"/>
							<gml:surfaceMember xlink:href="#poly-db1bb4ec-5829-45e2-8aed-88e4af90a283"/>
							<gml:surfaceMember xlink:href="#poly-8fde4b5f-5c26-4c49-b63d-4f9ba461831c"/>
							<gml:surfaceMember xlink:href="#poly-cab892f0-7b35-4256-b604-77e6fe1224e0"/>
							<gml:surfaceMember xlink:href="#poly-7972e89d-fdf5-4479-9c83-d7a69e59283d"/>
							<gml:surfaceMember xlink:href="#poly-54be4406-de72-48b2-86a2-c582c621c257"/>
							<gml:surfaceMember xlink:href="#poly-8c7fda0e-f90c-4419-8e63-a2ed6dd57118"/>
							<gml:surfaceMember xlink:href="#poly-89c1324a-ec02-4848-8cd4-a5735529954e"/>
							<gml:surfaceMember xlink:href="#poly-e8083d03-3664-4369-bd5d-5161747c60ff"/>
							<gml:surfaceMember xlink:href="#poly-1674fa97-a2f9-42d9-9457-dfde159252c0"/>
							<gml:surfaceMember xlink:href="#poly-9090f89c-0213-4be5-8997-796e90cecac1"/>
							<gml:surfaceMember xlink:href="#poly-2113cca1-6dec-4ce0-b3d5-2f81dd412e0a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_15489671-3fbc-4b9f-a390-2d1653e2f141_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9aae923-0b02-4887-9684-12040f22ec39">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671188464997485 139.73857874238243 49.486 35.67120829208901 139.73857478644098 49.486 35.67120903562133 139.73858038607352 49.486 35.671189208529626 139.73858434201367 49.486 35.671188464997485 139.73857874238243 49.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2843e8f0-3fb8-4f55-81c5-d2ce6c6db08e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119783924877 139.73860161938612 49.486 35.67119630683042 139.7385900556456 49.486 35.67120572469995 139.73858817767942 49.486 35.671207266132214 139.73859974141058 49.486 35.67119783924877 139.73860161938612 49.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd90a0e4-e30f-4428-86f9-bfc64d4488c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd90a0e4-e30f-4428-86f9-bfc64d4488c0_0">
											<gml:posList>35.671188464997485 139.73857874238243 49.486 35.671189208529626 139.73858434201367 49.486 35.671189208529626 139.73858434201367 51.814 35.671188464997485 139.73857874238243 51.814 35.671188464997485 139.73857874238243 49.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53a6972a-9b6c-4f10-9b78-4fd27e7dc38b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53a6972a-9b6c-4f10-9b78-4fd27e7dc38b_0">
											<gml:posList>35.67119630683042 139.7385900556456 49.486 35.67119783924877 139.73860161938612 49.486 35.67119783924877 139.73860161938612 50.92 35.67119630683042 139.7385900556456 50.92 35.67119630683042 139.7385900556456 49.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c383ec04-db79-4c67-a4a7-3e7b1393b87a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c383ec04-db79-4c67-a4a7-3e7b1393b87a_0">
											<gml:posList>35.67120829208901 139.73857478644098 49.486 35.671188464997485 139.73857874238243 49.486 35.671188464997485 139.73857874238243 51.814 35.67120829208901 139.73857478644098 51.814 35.67120829208901 139.73857478644098 49.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-067c5f64-cc85-4f08-b6a6-89e8bde5caaa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-067c5f64-cc85-4f08-b6a6-89e8bde5caaa_0">
											<gml:posList>35.67120903562133 139.73858038607352 51.814 35.67120829208901 139.73857478644098 51.814 35.671188464997485 139.73857874238243 51.814 35.671189208529626 139.73858434201367 51.814 35.67120903562133 139.73858038607352 51.814</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3bd38d5-767f-46f7-b202-d54012bb88b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3bd38d5-767f-46f7-b202-d54012bb88b9_0">
											<gml:posList>35.671189208529626 139.73858434201367 49.486 35.67120903562133 139.73858038607352 49.486 35.67120903562133 139.73858038607352 51.814 35.671189208529626 139.73858434201367 51.814 35.671189208529626 139.73858434201367 49.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-826222ad-4e39-42ff-8d3c-c80ffb75ef6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-826222ad-4e39-42ff-8d3c-c80ffb75ef6b_0">
											<gml:posList>35.67120572469995 139.73858817767942 49.486 35.67119630683042 139.7385900556456 49.486 35.67119630683042 139.7385900556456 50.92 35.67120572469995 139.73858817767942 50.92 35.67120572469995 139.73858817767942 49.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1385113-2922-4e0c-b96a-c0f29dafa6c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1385113-2922-4e0c-b96a-c0f29dafa6c2_0">
											<gml:posList>35.67119783924877 139.73860161938612 50.92 35.671207266132214 139.73859974141058 50.92 35.67120572469995 139.73858817767942 50.92 35.67119630683042 139.7385900556456 50.92 35.67119783924877 139.73860161938612 50.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfedcd7a-a3a5-436c-b97b-944d5a9ea3e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfedcd7a-a3a5-436c-b97b-944d5a9ea3e9_0">
											<gml:posList>35.67119783924877 139.73860161938612 49.486 35.671207266132214 139.73859974141058 49.486 35.671207266132214 139.73859974141058 50.92 35.67119783924877 139.73860161938612 50.92 35.67119783924877 139.73860161938612 49.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07efbe0b-b9fe-4129-bdb1-27da273162cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07efbe0b-b9fe-4129-bdb1-27da273162cd_0">
											<gml:posList>35.67120572469995 139.73858817767942 49.486 35.67120572469995 139.73858817767942 50.92 35.671207266132214 139.73859974141058 50.92 35.671207266132214 139.73859974141058 49.486 35.67120572469995 139.73858817767942 49.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e01d53e3-6bb5-4109-9c3c-4a7e1da9a7b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e01d53e3-6bb5-4109-9c3c-4a7e1da9a7b6_0">
											<gml:posList>35.67120903562133 139.73858038607352 49.486 35.67120829208901 139.73857478644098 49.486 35.67120829208901 139.73857478644098 51.814 35.67120903562133 139.73858038607352 51.814 35.67120903562133 139.73858038607352 49.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-31a075dc-cab8-4805-82cd-079477bd8443">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31a075dc-cab8-4805-82cd-079477bd8443">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31a075dc-cab8-4805-82cd-079477bd8443">
											<gml:posList>35.67117593946128 139.7386520056578 15.73 35.67115862964849 139.73853305673222 15.73 35.671190172279815 139.73852617068584 15.73 35.671193253989934 139.7385478179294 15.73 35.6712324569803 139.73853926587233 15.73 35.6712465949594 139.7386365677521 15.73 35.67117593946128 139.7386520056578 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11161f6b-aa7b-4112-ad5f-c9f3815ebf35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11161f6b-aa7b-4112-ad5f-c9f3815ebf35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11161f6b-aa7b-4112-ad5f-c9f3815ebf35">
											<gml:posList>35.67117593946128 139.7386520056578 49.877 35.67117910791327 139.73864643454593 49.877 35.67116317561639 139.73853692863187 49.877 35.67115862964849 139.73853305673222 49.877 35.67117593946128 139.7386520056578 49.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc888d9d-880b-4fb0-8776-e9779ae3cc55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc888d9d-880b-4fb0-8776-e9779ae3cc55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc888d9d-880b-4fb0-8776-e9779ae3cc55">
											<gml:posList>35.67115862964849 139.73853305673222 49.877 35.67116317561639 139.73853692863187 49.877 35.67118700382469 139.73853173075688 49.877 35.671190172279815 139.73852617068584 49.877 35.67115862964849 139.73853305673222 49.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1da07b81-ced2-444b-8bf6-27f88aeb42f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1da07b81-ced2-444b-8bf6-27f88aeb42f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1da07b81-ced2-444b-8bf6-27f88aeb42f8">
											<gml:posList>35.671193253989934 139.7385478179294 49.877 35.671190172279815 139.73852617068584 49.877 35.67118700382469 139.73853173075688 49.877 35.67119008553384 139.73855337799978 49.877 35.671193253989934 139.7385478179294 49.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a70646c-3267-4bab-ae40-d449de6e5225">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a70646c-3267-4bab-ae40-d449de6e5225">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a70646c-3267-4bab-ae40-d449de6e5225">
											<gml:posList>35.67117910791327 139.73864643454593 49.486 35.67124205799978 139.73863268478576 49.486 35.671229297538325 139.7385448259351 49.486 35.67119008553384 139.73855337799978 49.486 35.67118700382469 139.73853173075688 49.486 35.67116317561639 139.73853692863187 49.486 35.67117910791327 139.73864643454593 49.486</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26309cbb-b258-4952-9706-3f00163c558c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26309cbb-b258-4952-9706-3f00163c558c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26309cbb-b258-4952-9706-3f00163c558c">
											<gml:posList>35.6712465949594 139.7386365677521 49.877 35.67124205799978 139.73863268478576 49.877 35.67117910791327 139.73864643454593 49.877 35.67117593946128 139.7386520056578 49.877 35.6712465949594 139.7386365677521 49.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4dd7891a-14dd-4587-ac45-6d15a431b902">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4dd7891a-14dd-4587-ac45-6d15a431b902">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4dd7891a-14dd-4587-ac45-6d15a431b902">
											<gml:posList>35.671193253989934 139.7385478179294 49.877 35.67119008553384 139.73855337799978 49.877 35.671229297538325 139.7385448259351 49.877 35.6712324569803 139.73853926587233 49.877 35.671193253989934 139.7385478179294 49.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08c2e60c-8041-42ee-98c8-965238a4b7e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08c2e60c-8041-42ee-98c8-965238a4b7e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08c2e60c-8041-42ee-98c8-965238a4b7e3">
											<gml:posList>35.6712324569803 139.73853926587233 49.877 35.671229297538325 139.7385448259351 49.877 35.67124205799978 139.73863268478576 49.877 35.6712465949594 139.7386365677521 49.877 35.6712324569803 139.73853926587233 49.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70909afd-2f51-474f-8a61-d4b749764dfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70909afd-2f51-474f-8a61-d4b749764dfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70909afd-2f51-474f-8a61-d4b749764dfd">
											<gml:posList>35.67115862964849 139.73853305673222 15.73 35.67117593946128 139.7386520056578 15.73 35.67117593946128 139.7386520056578 49.877 35.67115862964849 139.73853305673222 49.877 35.67115862964849 139.73853305673222 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db1bb4ec-5829-45e2-8aed-88e4af90a283">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db1bb4ec-5829-45e2-8aed-88e4af90a283">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db1bb4ec-5829-45e2-8aed-88e4af90a283">
											<gml:posList>35.67117910791327 139.73864643454593 49.877 35.67117910791327 139.73864643454593 49.486 35.67116317561639 139.73853692863187 49.486 35.67116317561639 139.73853692863187 49.877 35.67117910791327 139.73864643454593 49.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fde4b5f-5c26-4c49-b63d-4f9ba461831c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fde4b5f-5c26-4c49-b63d-4f9ba461831c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fde4b5f-5c26-4c49-b63d-4f9ba461831c">
											<gml:posList>35.671190172279815 139.73852617068584 15.73 35.67115862964849 139.73853305673222 15.73 35.67115862964849 139.73853305673222 49.877 35.671190172279815 139.73852617068584 49.877 35.671190172279815 139.73852617068584 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cab892f0-7b35-4256-b604-77e6fe1224e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cab892f0-7b35-4256-b604-77e6fe1224e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cab892f0-7b35-4256-b604-77e6fe1224e0">
											<gml:posList>35.67116317561639 139.73853692863187 49.877 35.67116317561639 139.73853692863187 49.486 35.67118700382469 139.73853173075688 49.486 35.67118700382469 139.73853173075688 49.877 35.67116317561639 139.73853692863187 49.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7972e89d-fdf5-4479-9c83-d7a69e59283d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7972e89d-fdf5-4479-9c83-d7a69e59283d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7972e89d-fdf5-4479-9c83-d7a69e59283d">
											<gml:posList>35.67118700382469 139.73853173075688 49.877 35.67118700382469 139.73853173075688 49.486 35.67119008553384 139.73855337799978 49.486 35.67119008553384 139.73855337799978 49.877 35.67118700382469 139.73853173075688 49.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54be4406-de72-48b2-86a2-c582c621c257">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54be4406-de72-48b2-86a2-c582c621c257">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54be4406-de72-48b2-86a2-c582c621c257">
											<gml:posList>35.671193253989934 139.7385478179294 15.73 35.671190172279815 139.73852617068584 15.73 35.671190172279815 139.73852617068584 49.877 35.671193253989934 139.7385478179294 49.877 35.671193253989934 139.7385478179294 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c7fda0e-f90c-4419-8e63-a2ed6dd57118">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c7fda0e-f90c-4419-8e63-a2ed6dd57118">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c7fda0e-f90c-4419-8e63-a2ed6dd57118">
											<gml:posList>35.67119008553384 139.73855337799978 49.877 35.67119008553384 139.73855337799978 49.486 35.671229297538325 139.7385448259351 49.486 35.671229297538325 139.7385448259351 49.877 35.67119008553384 139.73855337799978 49.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89c1324a-ec02-4848-8cd4-a5735529954e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89c1324a-ec02-4848-8cd4-a5735529954e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89c1324a-ec02-4848-8cd4-a5735529954e">
											<gml:posList>35.67124205799978 139.73863268478576 49.877 35.67124205799978 139.73863268478576 49.486 35.67117910791327 139.73864643454593 49.486 35.67117910791327 139.73864643454593 49.877 35.67124205799978 139.73863268478576 49.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8083d03-3664-4369-bd5d-5161747c60ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8083d03-3664-4369-bd5d-5161747c60ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8083d03-3664-4369-bd5d-5161747c60ff">
											<gml:posList>35.67117593946128 139.7386520056578 15.73 35.6712465949594 139.7386365677521 15.73 35.6712465949594 139.7386365677521 49.877 35.67117593946128 139.7386520056578 49.877 35.67117593946128 139.7386520056578 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1674fa97-a2f9-42d9-9457-dfde159252c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1674fa97-a2f9-42d9-9457-dfde159252c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1674fa97-a2f9-42d9-9457-dfde159252c0">
											<gml:posList>35.6712324569803 139.73853926587233 15.73 35.671193253989934 139.7385478179294 15.73 35.671193253989934 139.7385478179294 49.877 35.6712324569803 139.73853926587233 49.877 35.6712324569803 139.73853926587233 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9090f89c-0213-4be5-8997-796e90cecac1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9090f89c-0213-4be5-8997-796e90cecac1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9090f89c-0213-4be5-8997-796e90cecac1">
											<gml:posList>35.671229297538325 139.7385448259351 49.877 35.671229297538325 139.7385448259351 49.486 35.67124205799978 139.73863268478576 49.486 35.67124205799978 139.73863268478576 49.877 35.671229297538325 139.7385448259351 49.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2113cca1-6dec-4ce0-b3d5-2f81dd412e0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2113cca1-6dec-4ce0-b3d5-2f81dd412e0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2113cca1-6dec-4ce0-b3d5-2f81dd412e0a">
											<gml:posList>35.6712465949594 139.7386365677521 15.73 35.6712324569803 139.73853926587233 15.73 35.6712324569803 139.73853926587233 49.877 35.6712465949594 139.7386365677521 49.877 35.6712465949594 139.7386365677521 15.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3005</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>