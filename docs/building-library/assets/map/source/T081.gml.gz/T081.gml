<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_158213ff-e336-4c94-94be-a696db07fc2f">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">35.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671078239453195 139.741799161465 0 35.671023610782804 139.74174455545563 0 35.67101008759687 139.74176485199578 0 35.67106471628338 139.74181949114885 0 35.671078239453195 139.741799161465 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671078239453195 139.741799161465 7.697 35.67106471628338 139.74181949114885 7.697 35.67101008759687 139.74176485199578 7.697 35.671023610782804 139.74174455545563 7.697 35.671078239453195 139.741799161465 7.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671078239453195 139.741799161465 7.697 35.671023610782804 139.74174455545563 7.697 35.671023610782804 139.74174455545563 43.02 35.671078239453195 139.741799161465 43.02 35.671078239453195 139.741799161465 7.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671023610782804 139.74174455545563 7.697 35.67101008759687 139.74176485199578 7.697 35.67101008759687 139.74176485199578 43.02 35.671023610782804 139.74174455545563 43.02 35.671023610782804 139.74174455545563 7.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67101008759687 139.74176485199578 7.697 35.67106471628338 139.74181949114885 7.697 35.67106471628338 139.74181949114885 43.02 35.67101008759687 139.74176485199578 43.02 35.67101008759687 139.74176485199578 7.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67106471628338 139.74181949114885 7.697 35.671078239453195 139.741799161465 7.697 35.671078239453195 139.741799161465 43.02 35.67106471628338 139.74181949114885 43.02 35.67106471628338 139.74181949114885 7.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671078239453195 139.741799161465 43.02 35.671023610782804 139.74174455545563 43.02 35.67101008759687 139.74176485199578 43.02 35.67106471628338 139.74181949114885 43.02 35.671078239453195 139.741799161465 43.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-73ba9e52-c476-4e9a-b2c4-33ad8d3ebbc8"/>
							<gml:surfaceMember xlink:href="#poly-4ae92750-2bc1-47cf-8ea5-815ac4581b2b"/>
							<gml:surfaceMember xlink:href="#poly-549f0b62-75fb-4bd8-ae0f-b92cbc9426e4"/>
							<gml:surfaceMember xlink:href="#poly-ebe5fb0c-7222-4afe-ab5a-f0978d38a2a0"/>
							<gml:surfaceMember xlink:href="#poly-0992f163-9244-4674-91a3-22498385478e"/>
							<gml:surfaceMember xlink:href="#poly-37dc840b-c8ca-400c-8860-19b5c6125c7c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-73ba9e52-c476-4e9a-b2c4-33ad8d3ebbc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73ba9e52-c476-4e9a-b2c4-33ad8d3ebbc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73ba9e52-c476-4e9a-b2c4-33ad8d3ebbc8">
											<gml:posList>35.6710782394532 139.74179916146497 7.697 35.671064716283375 139.74181949114882 7.697 35.67101008759687 139.74176485199578 7.697 35.671023610782804 139.74174455545563 7.697 35.6710782394532 139.74179916146497 7.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ae92750-2bc1-47cf-8ea5-815ac4581b2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ae92750-2bc1-47cf-8ea5-815ac4581b2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ae92750-2bc1-47cf-8ea5-815ac4581b2b">
											<gml:posList>35.671023610782804 139.74174455545563 15.934 35.67101008759687 139.74176485199578 15.934 35.671064716283375 139.74181949114882 15.934 35.6710782394532 139.74179916146497 15.934 35.671023610782804 139.74174455545563 15.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-549f0b62-75fb-4bd8-ae0f-b92cbc9426e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-549f0b62-75fb-4bd8-ae0f-b92cbc9426e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-549f0b62-75fb-4bd8-ae0f-b92cbc9426e4">
											<gml:posList>35.671023610782804 139.74174455545563 15.934 35.671023610782804 139.74174455545563 7.697 35.67101008759687 139.74176485199578 7.697 35.67101008759687 139.74176485199578 15.934 35.671023610782804 139.74174455545563 15.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebe5fb0c-7222-4afe-ab5a-f0978d38a2a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebe5fb0c-7222-4afe-ab5a-f0978d38a2a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebe5fb0c-7222-4afe-ab5a-f0978d38a2a0">
											<gml:posList>35.6710782394532 139.74179916146497 15.934 35.6710782394532 139.74179916146497 7.697 35.671023610782804 139.74174455545563 7.697 35.671023610782804 139.74174455545563 15.934 35.6710782394532 139.74179916146497 15.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0992f163-9244-4674-91a3-22498385478e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0992f163-9244-4674-91a3-22498385478e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0992f163-9244-4674-91a3-22498385478e">
											<gml:posList>35.67101008759687 139.74176485199578 15.934 35.67101008759687 139.74176485199578 7.697 35.671064716283375 139.74181949114882 7.697 35.671064716283375 139.74181949114882 15.934 35.67101008759687 139.74176485199578 15.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37dc840b-c8ca-400c-8860-19b5c6125c7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37dc840b-c8ca-400c-8860-19b5c6125c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37dc840b-c8ca-400c-8860-19b5c6125c7c">
											<gml:posList>35.671064716283375 139.74181949114882 15.934 35.671064716283375 139.74181949114882 7.697 35.6710782394532 139.74179916146497 7.697 35.6710782394532 139.74179916146497 15.934 35.671064716283375 139.74181949114882 15.934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3384</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>