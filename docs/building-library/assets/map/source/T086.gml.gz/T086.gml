<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_15edc25a-9637-4d53-af95-033650753f60">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">17.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66893577646713 139.73869986251353 0 35.66898419576789 139.73862792860967 0 35.66885679345013 139.73849912750816 0 35.66881969125408 139.73855424696694 0 35.66884771007583 139.7385824144082 0 35.668836330016575 139.7385993172612 0 35.66893577646713 139.73869986251353 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893577646713 139.73869986251353 15.28 35.668836330016575 139.7385993172612 15.28 35.66884771007583 139.7385824144082 15.28 35.66881969125408 139.73855424696694 15.28 35.66885679345013 139.73849912750816 15.28 35.66898419576789 139.73862792860967 15.28 35.66893577646713 139.73869986251353 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893577646713 139.73869986251353 15.28 35.66898419576789 139.73862792860967 15.28 35.66898419576789 139.73862792860967 33.05 35.66893577646713 139.73869986251353 33.05 35.66893577646713 139.73869986251353 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898419576789 139.73862792860967 15.28 35.66885679345013 139.73849912750816 15.28 35.66885679345013 139.73849912750816 33.05 35.66898419576789 139.73862792860967 33.05 35.66898419576789 139.73862792860967 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66885679345013 139.73849912750816 15.28 35.66881969125408 139.73855424696694 15.28 35.66881969125408 139.73855424696694 33.05 35.66885679345013 139.73849912750816 33.05 35.66885679345013 139.73849912750816 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881969125408 139.73855424696694 15.28 35.66884771007583 139.7385824144082 15.28 35.66884771007583 139.7385824144082 33.05 35.66881969125408 139.73855424696694 33.05 35.66881969125408 139.73855424696694 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884771007583 139.7385824144082 15.28 35.668836330016575 139.7385993172612 15.28 35.668836330016575 139.7385993172612 33.05 35.66884771007583 139.7385824144082 33.05 35.66884771007583 139.7385824144082 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668836330016575 139.7385993172612 15.28 35.66893577646713 139.73869986251353 15.28 35.66893577646713 139.73869986251353 33.05 35.668836330016575 139.7385993172612 33.05 35.668836330016575 139.7385993172612 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893577646713 139.73869986251353 33.05 35.66898419576789 139.73862792860967 33.05 35.66885679345013 139.73849912750816 33.05 35.66881969125408 139.73855424696694 33.05 35.66884771007583 139.7385824144082 33.05 35.668836330016575 139.7385993172612 33.05 35.66893577646713 139.73869986251353 33.05</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5015c88e-d5dd-4446-9b6d-3f4ba4c81f95"/>
							<gml:surfaceMember xlink:href="#poly-88d15b32-22ef-4dc9-9195-33f1f7586b65"/>
							<gml:surfaceMember xlink:href="#poly-56c321e6-fd45-4405-abf4-37e0a4b7a275"/>
							<gml:surfaceMember xlink:href="#poly-0e3c7d05-d105-45a0-a2f9-1d21c0389132"/>
							<gml:surfaceMember xlink:href="#poly-bd735861-7b5b-4213-b75c-ca933b1898ed"/>
							<gml:surfaceMember xlink:href="#poly-0a744bc9-80dc-4802-8eae-90efd1ca2c21"/>
							<gml:surfaceMember xlink:href="#poly-2dbb5285-cdef-409e-8460-8504d536cdd1"/>
							<gml:surfaceMember xlink:href="#poly-2de183c1-3bcb-4c07-b0da-97cc1d5e60d7"/>
							<gml:surfaceMember xlink:href="#poly-2f0469f7-f937-4b3e-bd85-83025df49e10"/>
							<gml:surfaceMember xlink:href="#poly-7df5edad-c77f-4bcb-82cb-7f721a068ea2"/>
							<gml:surfaceMember xlink:href="#poly-48a054d0-6b45-47f5-b908-74fa1bf506d6"/>
							<gml:surfaceMember xlink:href="#poly-7e69aa11-5b5a-42d0-b40d-866e2a678df6"/>
							<gml:surfaceMember xlink:href="#poly-b1754127-dc43-4027-be78-b13d5d4fdbd4"/>
							<gml:surfaceMember xlink:href="#poly-5f3dd1f4-04d5-4887-a706-3118028f7c96"/>
							<gml:surfaceMember xlink:href="#poly-995f1b8c-d8f8-4005-8ea0-7918428a2f75"/>
							<gml:surfaceMember xlink:href="#poly-f9466cab-0170-4f80-8bf0-7f55dae6e859"/>
							<gml:surfaceMember xlink:href="#poly-84cbaf10-7ea1-42f0-b785-8f50db1b4380"/>
							<gml:surfaceMember xlink:href="#poly-589a299a-8de8-4600-9c29-7231f5dff20d"/>
							<gml:surfaceMember xlink:href="#poly-387654ed-c512-42de-bf82-7ab7df12b8b2"/>
							<gml:surfaceMember xlink:href="#poly-80817fa8-5e2b-4dba-99e1-b5c9778eb7d8"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_15edc25a-9637-4d53-af95-033650753f60_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21d20432-275f-4b10-bc51-98cfe2a0f5b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883633001654 139.73859931726116 15.28 35.668808374225215 139.73857106137515 15.28 35.66881969125405 139.73855424696694 15.28 35.668847710075816 139.7385824144082 15.28 35.66883633001654 139.73859931726116 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-104a0443-0c93-4f27-85db-58cd888633ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-104a0443-0c93-4f27-85db-58cd888633ef_0">
											<gml:posList>35.66881969125405 139.73855424696694 15.28 35.668808374225215 139.73857106137515 15.28 35.668808374225215 139.73857106137515 33.663 35.668814028228724 139.73856264865395 33.663 35.66881969125405 139.73855424696694 33.663 35.66881969125405 139.73855424696694 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d068c5bf-3e4a-4bfe-839f-5a46270e6426">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d068c5bf-3e4a-4bfe-839f-5a46270e6426_0">
											<gml:posList>35.668808374225215 139.73857106137515 15.28 35.66883633001654 139.73859931726116 15.28 35.66883633001654 139.73859931726116 32.936 35.668808374225215 139.73857106137515 33.663 35.668808374225215 139.73857106137515 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1b85684-4df2-4757-9d73-c72bd8e76331">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1b85684-4df2-4757-9d73-c72bd8e76331_0">
											<gml:posList>35.668814028228724 139.73856264865395 33.663 35.668808374225215 139.73857106137515 33.663 35.66883633001654 139.73859931726116 32.936 35.668842020050825 139.7385908713583 32.936 35.668814028228724 139.73856264865395 33.663</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80a6ec74-fe00-4629-9219-db3e4ebc9b35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80a6ec74-fe00-4629-9219-db3e4ebc9b35_0">
											<gml:posList>35.668814028228724 139.73856264865395 33.663 35.668842020050825 139.7385908713583 32.936 35.668842020050825 139.7385908713583 33.939 35.668814028228724 139.73856264865395 33.663</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-960e4d33-e338-4230-8807-0657b2d1b8ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-960e4d33-e338-4230-8807-0657b2d1b8ad_0">
											<gml:posList>35.66881969125405 139.73855424696694 33.663 35.668814028228724 139.73856264865395 33.663 35.668842020050825 139.7385908713583 33.939 35.668847710075816 139.7385824144082 33.939 35.66881969125405 139.73855424696694 33.663</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19477303-54fc-48d4-8b9a-dbe703135679">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19477303-54fc-48d4-8b9a-dbe703135679_0">
											<gml:posList>35.668847710075816 139.7385824144082 15.28 35.66881969125405 139.73855424696694 15.28 35.66881969125405 139.73855424696694 33.663 35.668847710075816 139.7385824144082 33.939 35.668847710075816 139.7385824144082 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70987710-501f-49e8-af00-4896b161bebb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70987710-501f-49e8-af00-4896b161bebb_0">
											<gml:posList>35.668842020050825 139.7385908713583 32.936 35.66883633001654 139.73859931726116 32.936 35.66883633001654 139.73859931726116 15.28 35.668847710075816 139.7385824144082 15.28 35.668847710075816 139.7385824144082 33.939 35.668842020050825 139.7385908713583 33.939 35.668842020050825 139.7385908713583 32.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_15edc25a-9637-4d53-af95-033650753f60_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e681ea0-2bed-4c2f-97ba-98bb80e28c93">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668895544979854 139.73855826643643 33.374 35.66889116942167 139.73856476668817 33.374 35.66885364242533 139.73852682367968 33.374 35.6688580179815 139.73852032342893 33.374 35.668895544979854 139.73855826643643 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e7917b3-c5be-4949-a9fc-a302c4d417ee">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668845387736354 139.73854067413785 33.374 35.66885239697397 139.73854774636868 33.374 35.66884748122752 139.73855505361752 33.374 35.66884047198165 139.73854797034045 33.374 35.668845387736354 139.73854067413785 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed289d1d-7bff-4c4e-b220-18dc79c17247">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887948480409 139.7386184643136 33.374 35.66888941534216 139.73860370610123 33.374 35.66890447123926 139.73861893187092 33.374 35.66889453168562 139.7386336900948 33.374 35.66887948480409 139.7386184643136 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec565b94-4d3e-40de-bf72-d6ed4d55f894">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec565b94-4d3e-40de-bf72-d6ed4d55f894_0">
											<gml:posList>35.66885364242533 139.73852682367968 34.948 35.6688580179815 139.73852032342893 34.948 35.6688580179815 139.73852032342893 33.374 35.66885364242533 139.73852682367968 33.374 35.66885364242533 139.73852682367968 34.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2a114a9-4900-4bf0-8368-e17fc6968df2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2a114a9-4900-4bf0-8368-e17fc6968df2_0">
											<gml:posList>35.6688580179815 139.73852032342893 33.374 35.6688580179815 139.73852032342893 34.948 35.668895544979854 139.73855826643643 34.948 35.668895544979854 139.73855826643643 33.374 35.6688580179815 139.73852032342893 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-136643b1-422a-4ee1-bba1-ac5f8cc1b5fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-136643b1-422a-4ee1-bba1-ac5f8cc1b5fc_0">
											<gml:posList>35.668895544979854 139.73855826643643 34.948 35.6688580179815 139.73852032342893 34.948 35.66885364242533 139.73852682367968 34.948 35.66889116942167 139.73856476668817 34.948 35.668895544979854 139.73855826643643 34.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2accc77a-d2a8-4a67-8979-76b7f36c76a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2accc77a-d2a8-4a67-8979-76b7f36c76a9_0">
											<gml:posList>35.66885239697397 139.73854774636868 33.374 35.668845387736354 139.73854067413785 33.374 35.668845387736354 139.73854067413785 35.422 35.66885239697397 139.73854774636868 35.422 35.66885239697397 139.73854774636868 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-692a5e27-5035-4269-bd04-cab1aa0c8052">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-692a5e27-5035-4269-bd04-cab1aa0c8052_0">
											<gml:posList>35.66884047198165 139.73854797034045 33.374 35.66884047198165 139.73854797034045 35.422 35.668845387736354 139.73854067413785 35.422 35.668845387736354 139.73854067413785 33.374 35.66884047198165 139.73854797034045 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43c98366-1432-4e3a-aa57-a2c3cb802965">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43c98366-1432-4e3a-aa57-a2c3cb802965_0">
											<gml:posList>35.66885364242533 139.73852682367968 33.374 35.66889116942167 139.73856476668817 33.374 35.66889116942167 139.73856476668817 34.948 35.66885364242533 139.73852682367968 34.948 35.66885364242533 139.73852682367968 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3743d10-b006-4fa5-9659-83252ee32caf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3743d10-b006-4fa5-9659-83252ee32caf_0">
											<gml:posList>35.66884748122752 139.73855505361752 35.422 35.66885239697397 139.73854774636868 35.422 35.668845387736354 139.73854067413785 35.422 35.66884047198165 139.73854797034045 35.422 35.66884748122752 139.73855505361752 35.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be6055a0-f504-489c-8810-08b60dcb0a5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be6055a0-f504-489c-8810-08b60dcb0a5e_0">
											<gml:posList>35.66885239697397 139.73854774636868 33.374 35.66885239697397 139.73854774636868 35.422 35.66884748122752 139.73855505361752 35.422 35.66884748122752 139.73855505361752 33.374 35.66885239697397 139.73854774636868 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95d4d730-556b-4672-9ce2-d9dc061006dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95d4d730-556b-4672-9ce2-d9dc061006dd_0">
											<gml:posList>35.66884047198165 139.73854797034045 33.374 35.66884748122752 139.73855505361752 33.374 35.66884748122752 139.73855505361752 35.422 35.66884047198165 139.73854797034045 35.422 35.66884047198165 139.73854797034045 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17cacb4d-a956-4a8d-a72e-8a1d97b27b46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17cacb4d-a956-4a8d-a72e-8a1d97b27b46_0">
											<gml:posList>35.66889116942167 139.73856476668817 33.374 35.668895544979854 139.73855826643643 33.374 35.668895544979854 139.73855826643643 34.948 35.66889116942167 139.73856476668817 34.948 35.66889116942167 139.73856476668817 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2510eed-6c21-4c87-b570-f96d943e3f28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2510eed-6c21-4c87-b570-f96d943e3f28_0">
											<gml:posList>35.66888941534216 139.73860370610123 33.374 35.66887948480409 139.7386184643136 33.374 35.66887948480409 139.7386184643136 35.466 35.66888941534216 139.73860370610123 35.466 35.66888941534216 139.73860370610123 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98b47906-c395-4f96-957d-1fab4e95e577">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98b47906-c395-4f96-957d-1fab4e95e577_0">
											<gml:posList>35.66890447123926 139.73861893187092 33.374 35.66888941534216 139.73860370610123 33.374 35.66888941534216 139.73860370610123 35.466 35.66890447123926 139.73861893187092 35.466 35.66890447123926 139.73861893187092 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38646855-a1fd-4fac-a499-7a423745120d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38646855-a1fd-4fac-a499-7a423745120d_0">
											<gml:posList>35.66890447123926 139.73861893187092 35.466 35.66888941534216 139.73860370610123 35.466 35.66887948480409 139.7386184643136 35.466 35.66889453168562 139.7386336900948 35.466 35.66890447123926 139.73861893187092 35.466</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-473a6921-a0a2-4dd5-8399-1372c71144f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-473a6921-a0a2-4dd5-8399-1372c71144f0_0">
											<gml:posList>35.66889453168562 139.7386336900948 33.374 35.66889453168562 139.7386336900948 35.466 35.66887948480409 139.7386184643136 35.466 35.66887948480409 139.7386184643136 33.374 35.66889453168562 139.7386336900948 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-118d80c7-5a18-44e3-b2cb-c711eaabcf42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-118d80c7-5a18-44e3-b2cb-c711eaabcf42_0">
											<gml:posList>35.66889453168562 139.7386336900948 33.374 35.66890447123926 139.73861893187092 33.374 35.66890447123926 139.73861893187092 35.466 35.66889453168562 139.7386336900948 35.466 35.66889453168562 139.7386336900948 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5015c88e-d5dd-4446-9b6d-3f4ba4c81f95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5015c88e-d5dd-4446-9b6d-3f4ba4c81f95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5015c88e-d5dd-4446-9b6d-3f4ba4c81f95">
											<gml:posList>35.66898419576788 139.73862792860967 15.28 35.668935776467116 139.7386998625135 15.28 35.66883633001654 139.73859931726116 15.28 35.668847710075816 139.7385824144082 15.28 35.66881969125405 139.73855424696694 15.28 35.66885679345012 139.7384991275082 15.28 35.66898419576788 139.73862792860967 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88d15b32-22ef-4dc9-9195-33f1f7586b65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88d15b32-22ef-4dc9-9195-33f1f7586b65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88d15b32-22ef-4dc9-9195-33f1f7586b65">
											<gml:posList>35.668847710075816 139.7385824144082 34.021 35.66885136030395 139.73858199034487 34.021 35.66882335049583 139.73855382289182 34.021 35.66881969125405 139.73855424696694 34.021 35.668847710075816 139.7385824144082 34.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56c321e6-fd45-4405-abf4-37e0a4b7a275">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56c321e6-fd45-4405-abf4-37e0a4b7a275">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56c321e6-fd45-4405-abf4-37e0a4b7a275">
											<gml:posList>35.66881969125405 139.73855424696694 34.021 35.66882335049583 139.73855382289182 34.021 35.66885714850855 139.73850360073826 34.021 35.66885679345012 139.7384991275082 34.021 35.66881969125405 139.73855424696694 34.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e3c7d05-d105-45a0-a2f9-1d21c0389132">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e3c7d05-d105-45a0-a2f9-1d21c0389132">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e3c7d05-d105-45a0-a2f9-1d21c0389132">
											<gml:posList>35.668847710075816 139.7385824144082 34.021 35.66883633001654 139.73859931726116 34.021 35.668839980244755 139.73859889319868 34.021 35.66885136030395 139.73858199034487 34.021 35.668847710075816 139.7385824144082 34.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd735861-7b5b-4213-b75c-ca933b1898ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd735861-7b5b-4213-b75c-ca933b1898ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd735861-7b5b-4213-b75c-ca933b1898ed">
											<gml:posList>35.66885136030395 139.73858199034487 33.374 35.668839980244755 139.73859889319868 33.374 35.66893543043838 139.7386954003136 33.374 35.66898055455338 139.73862835266095 33.374 35.66885714850855 139.73850360073826 33.374 35.66882335049583 139.73855382289182 33.374 35.66885136030395 139.73858199034487 33.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a744bc9-80dc-4802-8eae-90efd1ca2c21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a744bc9-80dc-4802-8eae-90efd1ca2c21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a744bc9-80dc-4802-8eae-90efd1ca2c21">
											<gml:posList>35.66885679345012 139.7384991275082 34.021 35.66885714850855 139.73850360073826 34.021 35.66898055455338 139.73862835266095 34.021 35.66898419576788 139.73862792860967 34.021 35.66885679345012 139.7384991275082 34.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2dbb5285-cdef-409e-8460-8504d536cdd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dbb5285-cdef-409e-8460-8504d536cdd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dbb5285-cdef-409e-8460-8504d536cdd1">
											<gml:posList>35.668935776467116 139.7386998625135 34.021 35.66893543043838 139.7386954003136 34.021 35.668839980244755 139.73859889319868 34.021 35.66883633001654 139.73859931726116 34.021 35.668935776467116 139.7386998625135 34.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2de183c1-3bcb-4c07-b0da-97cc1d5e60d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2de183c1-3bcb-4c07-b0da-97cc1d5e60d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2de183c1-3bcb-4c07-b0da-97cc1d5e60d7">
											<gml:posList>35.66898419576788 139.73862792860967 34.021 35.66898055455338 139.73862835266095 34.021 35.66893543043838 139.7386954003136 34.021 35.668935776467116 139.7386998625135 34.021 35.66898419576788 139.73862792860967 34.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f0469f7-f937-4b3e-bd85-83025df49e10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f0469f7-f937-4b3e-bd85-83025df49e10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f0469f7-f937-4b3e-bd85-83025df49e10">
											<gml:posList>35.66893543043838 139.7386954003136 34.021 35.66893543043838 139.7386954003136 33.374 35.668839980244755 139.73859889319868 33.374 35.668839980244755 139.73859889319868 34.021 35.66893543043838 139.7386954003136 34.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7df5edad-c77f-4bcb-82cb-7f721a068ea2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7df5edad-c77f-4bcb-82cb-7f721a068ea2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7df5edad-c77f-4bcb-82cb-7f721a068ea2">
											<gml:posList>35.66885679345012 139.7384991275082 15.28 35.66881969125405 139.73855424696694 15.28 35.66881969125405 139.73855424696694 34.021 35.66885679345012 139.7384991275082 34.021 35.66885679345012 139.7384991275082 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48a054d0-6b45-47f5-b908-74fa1bf506d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48a054d0-6b45-47f5-b908-74fa1bf506d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48a054d0-6b45-47f5-b908-74fa1bf506d6">
											<gml:posList>35.66882335049583 139.73855382289182 34.021 35.66882335049583 139.73855382289182 33.374 35.66885714850855 139.73850360073826 33.374 35.66885714850855 139.73850360073826 34.021 35.66882335049583 139.73855382289182 34.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e69aa11-5b5a-42d0-b40d-866e2a678df6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e69aa11-5b5a-42d0-b40d-866e2a678df6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e69aa11-5b5a-42d0-b40d-866e2a678df6">
											<gml:posList>35.66898419576788 139.73862792860967 15.28 35.66885679345012 139.7384991275082 15.28 35.66885679345012 139.7384991275082 34.021 35.66898419576788 139.73862792860967 34.021 35.66898419576788 139.73862792860967 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1754127-dc43-4027-be78-b13d5d4fdbd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1754127-dc43-4027-be78-b13d5d4fdbd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1754127-dc43-4027-be78-b13d5d4fdbd4">
											<gml:posList>35.66885714850855 139.73850360073826 34.021 35.66885714850855 139.73850360073826 33.374 35.66898055455338 139.73862835266095 33.374 35.66898055455338 139.73862835266095 34.021 35.66885714850855 139.73850360073826 34.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f3dd1f4-04d5-4887-a706-3118028f7c96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f3dd1f4-04d5-4887-a706-3118028f7c96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f3dd1f4-04d5-4887-a706-3118028f7c96">
											<gml:posList>35.66885136030395 139.73858199034487 34.021 35.66885136030395 139.73858199034487 33.374 35.66882335049583 139.73855382289182 33.374 35.66882335049583 139.73855382289182 34.021 35.66885136030395 139.73858199034487 34.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-995f1b8c-d8f8-4005-8ea0-7918428a2f75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-995f1b8c-d8f8-4005-8ea0-7918428a2f75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-995f1b8c-d8f8-4005-8ea0-7918428a2f75">
											<gml:posList>35.66881969125405 139.73855424696694 15.28 35.668847710075816 139.7385824144082 15.28 35.668847710075816 139.7385824144082 34.021 35.66881969125405 139.73855424696694 34.021 35.66881969125405 139.73855424696694 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9466cab-0170-4f80-8bf0-7f55dae6e859">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9466cab-0170-4f80-8bf0-7f55dae6e859">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9466cab-0170-4f80-8bf0-7f55dae6e859">
											<gml:posList>35.668839980244755 139.73859889319868 34.021 35.668839980244755 139.73859889319868 33.374 35.66885136030395 139.73858199034487 33.374 35.66885136030395 139.73858199034487 34.021 35.668839980244755 139.73859889319868 34.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84cbaf10-7ea1-42f0-b785-8f50db1b4380">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84cbaf10-7ea1-42f0-b785-8f50db1b4380">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84cbaf10-7ea1-42f0-b785-8f50db1b4380">
											<gml:posList>35.668847710075816 139.7385824144082 15.28 35.66883633001654 139.73859931726116 15.28 35.66883633001654 139.73859931726116 34.021 35.668847710075816 139.7385824144082 34.021 35.668847710075816 139.7385824144082 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-589a299a-8de8-4600-9c29-7231f5dff20d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-589a299a-8de8-4600-9c29-7231f5dff20d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-589a299a-8de8-4600-9c29-7231f5dff20d">
											<gml:posList>35.66883633001654 139.73859931726116 15.28 35.668935776467116 139.7386998625135 15.28 35.668935776467116 139.7386998625135 34.021 35.66883633001654 139.73859931726116 34.021 35.66883633001654 139.73859931726116 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-387654ed-c512-42de-bf82-7ab7df12b8b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-387654ed-c512-42de-bf82-7ab7df12b8b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-387654ed-c512-42de-bf82-7ab7df12b8b2">
											<gml:posList>35.66898055455338 139.73862835266095 34.021 35.66898055455338 139.73862835266095 33.374 35.66893543043838 139.7386954003136 33.374 35.66893543043838 139.7386954003136 34.021 35.66898055455338 139.73862835266095 34.021</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80817fa8-5e2b-4dba-99e1-b5c9778eb7d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80817fa8-5e2b-4dba-99e1-b5c9778eb7d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80817fa8-5e2b-4dba-99e1-b5c9778eb7d8">
											<gml:posList>35.668935776467116 139.7386998625135 15.28 35.66898419576788 139.73862792860967 15.28 35.66898419576788 139.73862792860967 34.021 35.668935776467116 139.7386998625135 34.021 35.668935776467116 139.7386998625135 15.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1743</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">164.1805</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>