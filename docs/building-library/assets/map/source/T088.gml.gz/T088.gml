<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_16cc9be9-bfa3-4f71-a684-1259e69511cc">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">22.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66854682859417 139.74962313266946 0 35.668536664885934 139.74965451393828 0 35.66863566907321 139.7497025712646 0 35.66865653625494 139.74963826164702 0 35.66858322992291 139.74960277000335 0 35.66854682859417 139.74962313266946 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854682859417 139.74962313266946 5.33 35.66858322992291 139.74960277000335 5.33 35.66865653625494 139.74963826164702 5.33 35.66863566907321 139.7497025712646 5.33 35.668536664885934 139.74965451393828 5.33 35.66854682859417 139.74962313266946 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854682859417 139.74962313266946 5.33 35.668536664885934 139.74965451393828 5.33 35.668536664885934 139.74965451393828 28.03 35.66854682859417 139.74962313266946 28.03 35.66854682859417 139.74962313266946 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668536664885934 139.74965451393828 5.33 35.66863566907321 139.7497025712646 5.33 35.66863566907321 139.7497025712646 28.03 35.668536664885934 139.74965451393828 28.03 35.668536664885934 139.74965451393828 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66863566907321 139.7497025712646 5.33 35.66865653625494 139.74963826164702 5.33 35.66865653625494 139.74963826164702 28.03 35.66863566907321 139.7497025712646 28.03 35.66863566907321 139.7497025712646 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865653625494 139.74963826164702 5.33 35.66858322992291 139.74960277000335 5.33 35.66858322992291 139.74960277000335 28.03 35.66865653625494 139.74963826164702 28.03 35.66865653625494 139.74963826164702 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858322992291 139.74960277000335 5.33 35.66854682859417 139.74962313266946 5.33 35.66854682859417 139.74962313266946 28.03 35.66858322992291 139.74960277000335 28.03 35.66858322992291 139.74960277000335 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854682859417 139.74962313266946 28.03 35.668536664885934 139.74965451393828 28.03 35.66863566907321 139.7497025712646 28.03 35.66865653625494 139.74963826164702 28.03 35.66858322992291 139.74960277000335 28.03 35.66854682859417 139.74962313266946 28.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a285bcff-004c-4abe-9f8b-bac2f1223a67"/>
							<gml:surfaceMember xlink:href="#poly-3ec06e21-ea4d-4363-9918-a733423154ed"/>
							<gml:surfaceMember xlink:href="#poly-42fa8979-402f-4a1c-bc18-278e39e893bd"/>
							<gml:surfaceMember xlink:href="#poly-af7b4f14-7d46-478c-867d-d26654591a45"/>
							<gml:surfaceMember xlink:href="#poly-18201537-5504-4f8e-a5f2-09b6f579f4fc"/>
							<gml:surfaceMember xlink:href="#poly-078cff94-f641-4a1b-a517-46dd7df59269"/>
							<gml:surfaceMember xlink:href="#poly-f3079f03-52be-4b54-b6a9-fdfdd084670a"/>
							<gml:surfaceMember xlink:href="#poly-285d18da-fee6-4dc2-b85b-eb3980fd5117"/>
							<gml:surfaceMember xlink:href="#poly-981a530d-4d38-450b-89d0-4a7316114c1e"/>
							<gml:surfaceMember xlink:href="#poly-10e2051a-4d17-4e9d-9840-c1487562bbfb"/>
							<gml:surfaceMember xlink:href="#poly-e6e8f9d7-e317-48a4-bbdf-2e591ddc3562"/>
							<gml:surfaceMember xlink:href="#poly-64286574-db9f-4166-a98d-0cb95a8926ce"/>
							<gml:surfaceMember xlink:href="#poly-889e353f-7c51-4595-9b08-5453fc148a0c"/>
							<gml:surfaceMember xlink:href="#poly-05d69043-04cd-4682-af40-4eb5139b91df"/>
							<gml:surfaceMember xlink:href="#poly-b9589612-03b8-4e82-9632-f026b877ed8f"/>
							<gml:surfaceMember xlink:href="#poly-97b22c2e-2d1a-40c2-ba9a-4d69e3288dba"/>
							<gml:surfaceMember xlink:href="#poly-097b0cd0-74cf-44db-8082-77120a0b9d89"/>
							<gml:surfaceMember xlink:href="#poly-3c3444bd-3d2d-4bb4-aa0d-caa30af6a010"/>
							<gml:surfaceMember xlink:href="#poly-4f5ee156-1450-4977-9fbb-8ca7d020f385"/>
							<gml:surfaceMember xlink:href="#poly-6a6828e5-73af-4df0-8007-ed09d89edebd"/>
							<gml:surfaceMember xlink:href="#poly-8b538bc2-d2a4-43aa-873c-d6fab13151dd"/>
							<gml:surfaceMember xlink:href="#poly-bcf8fe64-f0cb-4fc5-9b2f-b9020416fba4"/>
							<gml:surfaceMember xlink:href="#poly-8e27c9b3-e3ce-4e27-ac82-828b71a0fced"/>
							<gml:surfaceMember xlink:href="#poly-5c2c015a-18c9-48a7-9844-a6dcfabcf2de"/>
							<gml:surfaceMember xlink:href="#poly-ce498a91-9a6e-4443-b284-864aa5021dea"/>
							<gml:surfaceMember xlink:href="#poly-d16cfa8c-6deb-4366-86e7-57b43433f515"/>
							<gml:surfaceMember xlink:href="#poly-cbd7eb90-eace-4945-8a7b-2142e6128e9d"/>
							<gml:surfaceMember xlink:href="#poly-85084112-c9d1-44cc-bbfd-43610727a156"/>
							<gml:surfaceMember xlink:href="#poly-c3310fb2-e8c0-4697-9689-fa8f79f99ee7"/>
							<gml:surfaceMember xlink:href="#poly-b4a32a5c-613a-4455-b1dd-647d66b39b48"/>
							<gml:surfaceMember xlink:href="#poly-ce4a054c-bc7b-48ae-a672-d4b515bf64be"/>
							<gml:surfaceMember xlink:href="#poly-bf5cc832-a38c-4ec1-81d2-725b7ff6614f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_16cc9be9-bfa3-4f71-a684-1259e69511cc_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19469c91-ead0-47cb-8300-5c1407d0ab90">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855935217881 139.74964114668242 28.237 35.66857270606958 139.7496476940748 28.237 35.66856740822923 139.74966388200957 28.237 35.66855406335306 139.74965733460553 28.237 35.66855935217881 139.74964114668242 28.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd12dbb0-001d-47d9-930f-8773a10db496">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd12dbb0-001d-47d9-930f-8773a10db496_0">
											<gml:posList>35.66855935217881 139.74964114668242 28.237 35.66855935217881 139.74964114668242 30.824 35.66857270606958 139.7496476940748 30.824 35.66857270606958 139.7496476940748 28.237 35.66855935217881 139.74964114668242 28.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c531d08f-0f4d-4110-b0ab-fbe502c9d963">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c531d08f-0f4d-4110-b0ab-fbe502c9d963_0">
											<gml:posList>35.66855406335306 139.74965733460553 30.824 35.66855935217881 139.74964114668242 30.824 35.66855935217881 139.74964114668242 28.237 35.66855406335306 139.74965733460553 28.237 35.66855406335306 139.74965733460553 30.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6ca850e-32b9-412e-9fe5-d96fb9743207">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6ca850e-32b9-412e-9fe5-d96fb9743207_0">
											<gml:posList>35.66856740822923 139.74966388200957 30.824 35.66857270606958 139.7496476940748 30.824 35.66855935217881 139.74964114668242 30.824 35.66855406335306 139.74965733460553 30.824 35.66856740822923 139.74966388200957 30.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86aacaf5-6641-4b16-b494-b1a78bd3e1af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86aacaf5-6641-4b16-b494-b1a78bd3e1af_0">
											<gml:posList>35.66857270606958 139.7496476940748 30.824 35.66856740822923 139.74966388200957 30.824 35.66856740822923 139.74966388200957 28.237 35.66857270606958 139.7496476940748 28.237 35.66857270606958 139.7496476940748 30.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d636e05-e931-42ed-a0d4-afcfa560d4b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d636e05-e931-42ed-a0d4-afcfa560d4b4_0">
											<gml:posList>35.66856740822923 139.74966388200957 28.237 35.66856740822923 139.74966388200957 30.824 35.66855406335306 139.74965733460553 30.824 35.66855406335306 139.74965733460553 28.237 35.66856740822923 139.74966388200957 28.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a285bcff-004c-4abe-9f8b-bac2f1223a67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a285bcff-004c-4abe-9f8b-bac2f1223a67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a285bcff-004c-4abe-9f8b-bac2f1223a67">
											<gml:posList>35.66854682859416 139.74962313266946 5.33 35.66858322992291 139.74960277000332 5.33 35.668656536254936 139.74963826164702 5.33 35.668635669073225 139.7497025712646 5.33 35.66853666488591 139.74965451393828 5.33 35.66854682859416 139.74962313266946 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ec06e21-ea4d-4363-9918-a733423154ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ec06e21-ea4d-4363-9918-a733423154ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ec06e21-ea4d-4363-9918-a733423154ed">
											<gml:posList>35.66859300030854 139.7496798609791 28.5 35.66859384025806 139.7496822681339 28.5 35.66859439790442 139.74968053332793 28.5 35.66859300030854 139.7496798609791 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42fa8979-402f-4a1c-bc18-278e39e893bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42fa8979-402f-4a1c-bc18-278e39e893bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42fa8979-402f-4a1c-bc18-278e39e893bd">
											<gml:posList>35.66854682859416 139.74962313266946 28.5 35.66854801937375 139.74962452322328 28.5 35.66858328541853 139.74960480241174 28.5 35.66858322992291 139.74960277000332 28.5 35.66854682859416 139.74962313266946 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af7b4f14-7d46-478c-867d-d26654591a45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af7b4f14-7d46-478c-867d-d26654591a45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af7b4f14-7d46-478c-867d-d26654591a45">
											<gml:posList>35.66858322992291 139.74960277000332 28.5 35.66858328541853 139.74960480241174 28.5 35.6686545719917 139.74963931306948 28.5 35.668656536254936 139.74963826164702 28.5 35.66858322992291 139.74960277000332 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18201537-5504-4f8e-a5f2-09b6f579f4fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18201537-5504-4f8e-a5f2-09b6f579f4fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18201537-5504-4f8e-a5f2-09b6f579f4fc">
											<gml:posList>35.66854682859416 139.74962313266946 28.5 35.66853666488591 139.74965451393828 28.5 35.66853863817074 139.74965347355436 28.5 35.66854801937375 139.74962452322328 28.5 35.66854682859416 139.74962313266946 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-078cff94-f641-4a1b-a517-46dd7df59269">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-078cff94-f641-4a1b-a517-46dd7df59269">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-078cff94-f641-4a1b-a517-46dd7df59269">
											<gml:posList>35.668644579118194 139.74967008666906 28.237 35.6686545719917 139.74963931306948 28.237 35.66858328541853 139.74960480241174 28.237 35.66854801937375 139.74962452322328 28.237 35.66853863817074 139.74965347355436 28.237 35.66859300030854 139.7496798609791 28.237 35.66859439790442 139.74968053332793 28.237 35.668603563198886 139.74965217969003 28.237 35.66864402146432 139.7496718104302 28.237 35.668644579118194 139.74967008666906 28.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3079f03-52be-4b54-b6a9-fdfdd084670a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3079f03-52be-4b54-b6a9-fdfdd084670a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3079f03-52be-4b54-b6a9-fdfdd084670a">
											<gml:posList>35.668656536254936 139.74963826164702 28.5 35.6686545719917 139.74963931306948 28.5 35.668644579118194 139.74967008666906 28.5 35.668645428081625 139.7496724938159 28.5 35.668656536254936 139.74963826164702 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-285d18da-fee6-4dc2-b85b-eb3980fd5117">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-285d18da-fee6-4dc2-b85b-eb3980fd5117">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-285d18da-fee6-4dc2-b85b-eb3980fd5117">
											<gml:posList>35.668603563198886 139.74965217969003 32.49 35.66860410510489 139.7496537366127 32.49 35.668644166627914 139.74967316893935 32.49 35.668645428081625 139.7496724938159 32.49 35.668603563198886 139.74965217969003 32.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-981a530d-4d38-450b-89d0-4a7316114c1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-981a530d-4d38-450b-89d0-4a7316114c1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-981a530d-4d38-450b-89d0-4a7316114c1e">
											<gml:posList>35.66859384025806 139.7496822681339 32.49 35.66859511073324 139.74968160404762 32.49 35.66860410510489 139.7496537366127 32.49 35.668603563198886 139.74965217969003 32.49 35.66859384025806 139.7496822681339 32.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-10e2051a-4d17-4e9d-9840-c1487562bbfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10e2051a-4d17-4e9d-9840-c1487562bbfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10e2051a-4d17-4e9d-9840-c1487562bbfb">
											<gml:posList>35.66859384025806 139.7496822681339 28.5 35.66859300030854 139.7496798609791 28.5 35.66853863817074 139.74965347355436 28.5 35.66853666488591 139.74965451393828 28.5 35.66859384025806 139.7496822681339 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6e8f9d7-e317-48a4-bbdf-2e591ddc3562">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6e8f9d7-e317-48a4-bbdf-2e591ddc3562">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6e8f9d7-e317-48a4-bbdf-2e591ddc3562">
											<gml:posList>35.66864402146432 139.7496718104302 28.5 35.668645428081625 139.7496724938159 28.5 35.668644579118194 139.74967008666906 28.5 35.66864402146432 139.7496718104302 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64286574-db9f-4166-a98d-0cb95a8926ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64286574-db9f-4166-a98d-0cb95a8926ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64286574-db9f-4166-a98d-0cb95a8926ce">
											<gml:posList>35.668644166627914 139.74967316893935 32.233 35.66860410510489 139.7496537366127 32.233 35.66859511073324 139.74968160404762 32.233 35.668635127175534 139.74970102538703 32.233 35.668644166627914 139.74967316893935 32.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-889e353f-7c51-4595-9b08-5453fc148a0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-889e353f-7c51-4595-9b08-5453fc148a0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-889e353f-7c51-4595-9b08-5453fc148a0c">
											<gml:posList>35.668645428081625 139.7496724938159 32.49 35.668644166627914 139.74967316893935 32.49 35.668635127175534 139.74970102538703 32.49 35.668635669073225 139.7497025712646 32.49 35.668645428081625 139.7496724938159 32.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05d69043-04cd-4682-af40-4eb5139b91df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05d69043-04cd-4682-af40-4eb5139b91df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05d69043-04cd-4682-af40-4eb5139b91df">
											<gml:posList>35.668635669073225 139.7497025712646 32.49 35.668635127175534 139.74970102538703 32.49 35.66859511073324 139.74968160404762 32.49 35.66859384025806 139.7496822681339 32.49 35.668635669073225 139.7497025712646 32.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9589612-03b8-4e82-9632-f026b877ed8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9589612-03b8-4e82-9632-f026b877ed8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9589612-03b8-4e82-9632-f026b877ed8f">
											<gml:posList>35.66860410510489 139.7496537366127 32.49 35.66860410510489 139.7496537366127 32.233 35.668644166627914 139.74967316893935 32.233 35.668644166627914 139.74967316893935 32.49 35.66860410510489 139.7496537366127 32.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97b22c2e-2d1a-40c2-ba9a-4d69e3288dba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97b22c2e-2d1a-40c2-ba9a-4d69e3288dba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97b22c2e-2d1a-40c2-ba9a-4d69e3288dba">
											<gml:posList>35.66854682859416 139.74962313266946 5.33 35.66853666488591 139.74965451393828 5.33 35.66853666488591 139.74965451393828 28.5 35.66854682859416 139.74962313266946 28.5 35.66854682859416 139.74962313266946 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-097b0cd0-74cf-44db-8082-77120a0b9d89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-097b0cd0-74cf-44db-8082-77120a0b9d89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-097b0cd0-74cf-44db-8082-77120a0b9d89">
											<gml:posList>35.66853863817074 139.74965347355436 28.5 35.66853863817074 139.74965347355436 28.237 35.66854801937375 139.74962452322328 28.237 35.66854801937375 139.74962452322328 28.5 35.66853863817074 139.74965347355436 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c3444bd-3d2d-4bb4-aa0d-caa30af6a010">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c3444bd-3d2d-4bb4-aa0d-caa30af6a010">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c3444bd-3d2d-4bb4-aa0d-caa30af6a010">
											<gml:posList>35.66858322992291 139.74960277000332 5.33 35.66854682859416 139.74962313266946 5.33 35.66854682859416 139.74962313266946 28.5 35.66858322992291 139.74960277000332 28.5 35.66858322992291 139.74960277000332 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f5ee156-1450-4977-9fbb-8ca7d020f385">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f5ee156-1450-4977-9fbb-8ca7d020f385">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f5ee156-1450-4977-9fbb-8ca7d020f385">
											<gml:posList>35.66854801937375 139.74962452322328 28.5 35.66854801937375 139.74962452322328 28.237 35.66858328541853 139.74960480241174 28.237 35.66858328541853 139.74960480241174 28.5 35.66854801937375 139.74962452322328 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a6828e5-73af-4df0-8007-ed09d89edebd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a6828e5-73af-4df0-8007-ed09d89edebd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a6828e5-73af-4df0-8007-ed09d89edebd">
											<gml:posList>35.66859300030854 139.7496798609791 28.5 35.66859300030854 139.7496798609791 28.237 35.66853863817074 139.74965347355436 28.237 35.66853863817074 139.74965347355436 28.5 35.66859300030854 139.7496798609791 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b538bc2-d2a4-43aa-873c-d6fab13151dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b538bc2-d2a4-43aa-873c-d6fab13151dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b538bc2-d2a4-43aa-873c-d6fab13151dd">
											<gml:posList>35.668635669073225 139.7497025712646 5.33 35.668635669073225 139.7497025712646 32.49 35.66859384025806 139.7496822681339 32.49 35.66859384025806 139.7496822681339 28.5 35.66853666488591 139.74965451393828 28.5 35.66853666488591 139.74965451393828 5.33 35.668635669073225 139.7497025712646 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bcf8fe64-f0cb-4fc5-9b2f-b9020416fba4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcf8fe64-f0cb-4fc5-9b2f-b9020416fba4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcf8fe64-f0cb-4fc5-9b2f-b9020416fba4">
											<gml:posList>35.66859439790442 139.74968053332793 28.5 35.66859439790442 139.74968053332793 28.237 35.66859300030854 139.7496798609791 28.237 35.66859300030854 139.7496798609791 28.5 35.66859439790442 139.74968053332793 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e27c9b3-e3ce-4e27-ac82-828b71a0fced">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e27c9b3-e3ce-4e27-ac82-828b71a0fced">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e27c9b3-e3ce-4e27-ac82-828b71a0fced">
											<gml:posList>35.66859439790442 139.74968053332793 28.5 35.66859384025806 139.7496822681339 28.5 35.66859384025806 139.7496822681339 32.49 35.668603563198886 139.74965217969003 32.49 35.668603563198886 139.74965217969003 28.237 35.66859439790442 139.74968053332793 28.237 35.66859439790442 139.74968053332793 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c2c015a-18c9-48a7-9844-a6dcfabcf2de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c2c015a-18c9-48a7-9844-a6dcfabcf2de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c2c015a-18c9-48a7-9844-a6dcfabcf2de">
											<gml:posList>35.66859511073324 139.74968160404762 32.49 35.66859511073324 139.74968160404762 32.233 35.66860410510489 139.7496537366127 32.233 35.66860410510489 139.7496537366127 32.49 35.66859511073324 139.74968160404762 32.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce498a91-9a6e-4443-b284-864aa5021dea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce498a91-9a6e-4443-b284-864aa5021dea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce498a91-9a6e-4443-b284-864aa5021dea">
											<gml:posList>35.668635127175534 139.74970102538703 32.49 35.668635127175534 139.74970102538703 32.233 35.66859511073324 139.74968160404762 32.233 35.66859511073324 139.74968160404762 32.49 35.668635127175534 139.74970102538703 32.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d16cfa8c-6deb-4366-86e7-57b43433f515">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d16cfa8c-6deb-4366-86e7-57b43433f515">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d16cfa8c-6deb-4366-86e7-57b43433f515">
											<gml:posList>35.66858328541853 139.74960480241174 28.5 35.66858328541853 139.74960480241174 28.237 35.6686545719917 139.74963931306948 28.237 35.6686545719917 139.74963931306948 28.5 35.66858328541853 139.74960480241174 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbd7eb90-eace-4945-8a7b-2142e6128e9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbd7eb90-eace-4945-8a7b-2142e6128e9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbd7eb90-eace-4945-8a7b-2142e6128e9d">
											<gml:posList>35.668656536254936 139.74963826164702 5.33 35.66858322992291 139.74960277000332 5.33 35.66858322992291 139.74960277000332 28.5 35.668656536254936 139.74963826164702 28.5 35.668656536254936 139.74963826164702 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85084112-c9d1-44cc-bbfd-43610727a156">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85084112-c9d1-44cc-bbfd-43610727a156">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85084112-c9d1-44cc-bbfd-43610727a156">
											<gml:posList>35.668603563198886 139.74965217969003 28.237 35.668603563198886 139.74965217969003 32.49 35.668645428081625 139.7496724938159 32.49 35.668645428081625 139.7496724938159 28.5 35.66864402146432 139.7496718104302 28.5 35.66864402146432 139.7496718104302 28.237 35.668603563198886 139.74965217969003 28.237</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3310fb2-e8c0-4697-9689-fa8f79f99ee7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3310fb2-e8c0-4697-9689-fa8f79f99ee7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3310fb2-e8c0-4697-9689-fa8f79f99ee7">
											<gml:posList>35.668644166627914 139.74967316893935 32.49 35.668644166627914 139.74967316893935 32.233 35.668635127175534 139.74970102538703 32.233 35.668635127175534 139.74970102538703 32.49 35.668644166627914 139.74967316893935 32.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b4a32a5c-613a-4455-b1dd-647d66b39b48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4a32a5c-613a-4455-b1dd-647d66b39b48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4a32a5c-613a-4455-b1dd-647d66b39b48">
											<gml:posList>35.668644579118194 139.74967008666906 28.5 35.668644579118194 139.74967008666906 28.237 35.66864402146432 139.7496718104302 28.237 35.66864402146432 139.7496718104302 28.5 35.668644579118194 139.74967008666906 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce4a054c-bc7b-48ae-a672-d4b515bf64be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce4a054c-bc7b-48ae-a672-d4b515bf64be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce4a054c-bc7b-48ae-a672-d4b515bf64be">
											<gml:posList>35.668635669073225 139.7497025712646 5.33 35.668656536254936 139.74963826164702 5.33 35.668656536254936 139.74963826164702 28.5 35.668645428081625 139.7496724938159 28.5 35.668645428081625 139.7496724938159 32.49 35.668635669073225 139.7497025712646 32.49 35.668635669073225 139.7497025712646 5.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf5cc832-a38c-4ec1-81d2-725b7ff6614f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf5cc832-a38c-4ec1-81d2-725b7ff6614f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf5cc832-a38c-4ec1-81d2-725b7ff6614f">
											<gml:posList>35.6686545719917 139.74963931306948 28.5 35.6686545719917 139.74963931306948 28.237 35.668644579118194 139.74967008666906 28.237 35.668644579118194 139.74967008666906 28.5 35.6686545719917 139.74963931306948 28.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8640</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">69.0545</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>