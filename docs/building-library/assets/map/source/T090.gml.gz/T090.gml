<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_17c9cca1-6a1c-4569-bb88-24235bac9cba">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67094872174472 139.7384463702522 0 35.6709449212694 139.73842770644043 0 35.670875622292314 139.738448776493 0 35.67089227253375 139.7385312728718 0 35.67089344405665 139.73853094009667 0 35.67092656314104 139.7386947180768 0 35.67100901906771 139.73866965600493 0 35.671014447184696 139.73869494572975 0 35.67107842932377 139.73867542862027 0 35.67104295768576 139.73850027537927 0 35.67097852427998 139.73851901990957 0 35.67097590003646 139.7385059883302 0 35.671028166569734 139.73848935698945 0 35.67103033838908 139.73850017984213 0 35.67109990769798 139.7384789990096 0 35.67109909315636 139.73847480235713 0 35.671170915455 139.73845306649966 0 35.67114703179114 139.7383421892604 0 35.67113495645492 139.73834606979432 0 35.67112554775714 139.73830244781166 0 35.671142489193564 139.73829690454903 0 35.67112131962669 139.73819883795395 0 35.67106869293484 139.73821591178495 0 35.671070140452834 139.73822264834376 0 35.67106094881309 139.73822564176294 0 35.67107334296711 139.738283068105 0 35.67108154336053 139.7382804072578 0 35.671087966468306 139.73831000387884 0 35.671106268671934 139.738304072385 0 35.67111705242144 139.73835398915395 0 35.671087828373416 139.73836346840903 0 35.67109560848329 139.73839935985617 0 35.67108443434305 139.7384030183848 0 35.67108389134259 139.73840025743866 0 35.671014412184626 139.7384214382285 0 35.67101776032084 139.7384380037856 0 35.670990184601486 139.7384459897912 0 35.670987831806364 139.73843428345216 0 35.67094872174472 139.7384463702522 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67094872174472 139.7384463702522 15.2 35.670987831806364 139.73843428345216 15.2 35.670990184601486 139.7384459897912 15.2 35.67101776032084 139.7384380037856 15.2 35.671014412184626 139.7384214382285 15.2 35.67108389134259 139.73840025743866 15.2 35.67108443434305 139.7384030183848 15.2 35.67109560848329 139.73839935985617 15.2 35.671087828373416 139.73836346840903 15.2 35.67111705242144 139.73835398915395 15.2 35.671106268671934 139.738304072385 15.2 35.671087966468306 139.73831000387884 15.2 35.67108154336053 139.7382804072578 15.2 35.67107334296711 139.738283068105 15.2 35.67106094881309 139.73822564176294 15.2 35.671070140452834 139.73822264834376 15.2 35.67106869293484 139.73821591178495 15.2 35.67112131962669 139.73819883795395 15.2 35.671142489193564 139.73829690454903 15.2 35.67112554775714 139.73830244781166 15.2 35.67113495645492 139.73834606979432 15.2 35.67114703179114 139.7383421892604 15.2 35.671170915455 139.73845306649966 15.2 35.67109909315636 139.73847480235713 15.2 35.67109990769798 139.7384789990096 15.2 35.67103033838908 139.73850017984213 15.2 35.671028166569734 139.73848935698945 15.2 35.67097590003646 139.7385059883302 15.2 35.67097852427998 139.73851901990957 15.2 35.67104295768576 139.73850027537927 15.2 35.67107842932377 139.73867542862027 15.2 35.671014447184696 139.73869494572975 15.2 35.67100901906771 139.73866965600493 15.2 35.67092656314104 139.7386947180768 15.2 35.67089344405665 139.73853094009667 15.2 35.67089227253375 139.7385312728718 15.2 35.670875622292314 139.738448776493 15.2 35.6709449212694 139.73842770644043 15.2 35.67094872174472 139.7384463702522 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67094872174472 139.7384463702522 15.2 35.6709449212694 139.73842770644043 15.2 35.6709449212694 139.73842770644043 29.96 35.67094872174472 139.7384463702522 29.96 35.67094872174472 139.7384463702522 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709449212694 139.73842770644043 15.2 35.670875622292314 139.738448776493 15.2 35.670875622292314 139.738448776493 29.96 35.6709449212694 139.73842770644043 29.96 35.6709449212694 139.73842770644043 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670875622292314 139.738448776493 15.2 35.67089227253375 139.7385312728718 15.2 35.67089227253375 139.7385312728718 29.96 35.670875622292314 139.738448776493 29.96 35.670875622292314 139.738448776493 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089227253375 139.7385312728718 15.2 35.67089344405665 139.73853094009667 15.2 35.67089344405665 139.73853094009667 29.96 35.67089227253375 139.7385312728718 29.96 35.67089227253375 139.7385312728718 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089344405665 139.73853094009667 15.2 35.67092656314104 139.7386947180768 15.2 35.67092656314104 139.7386947180768 29.96 35.67089344405665 139.73853094009667 29.96 35.67089344405665 139.73853094009667 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67092656314104 139.7386947180768 15.2 35.67100901906771 139.73866965600493 15.2 35.67100901906771 139.73866965600493 29.96 35.67092656314104 139.7386947180768 29.96 35.67092656314104 139.7386947180768 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67100901906771 139.73866965600493 15.2 35.671014447184696 139.73869494572975 15.2 35.671014447184696 139.73869494572975 29.96 35.67100901906771 139.73866965600493 29.96 35.67100901906771 139.73866965600493 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671014447184696 139.73869494572975 15.2 35.67107842932377 139.73867542862027 15.2 35.67107842932377 139.73867542862027 29.96 35.671014447184696 139.73869494572975 29.96 35.671014447184696 139.73869494572975 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67107842932377 139.73867542862027 15.2 35.67104295768576 139.73850027537927 15.2 35.67104295768576 139.73850027537927 29.96 35.67107842932377 139.73867542862027 29.96 35.67107842932377 139.73867542862027 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67104295768576 139.73850027537927 15.2 35.67097852427998 139.73851901990957 15.2 35.67097852427998 139.73851901990957 29.96 35.67104295768576 139.73850027537927 29.96 35.67104295768576 139.73850027537927 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097852427998 139.73851901990957 15.2 35.67097590003646 139.7385059883302 15.2 35.67097590003646 139.7385059883302 29.96 35.67097852427998 139.73851901990957 29.96 35.67097852427998 139.73851901990957 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097590003646 139.7385059883302 15.2 35.671028166569734 139.73848935698945 15.2 35.671028166569734 139.73848935698945 29.96 35.67097590003646 139.7385059883302 29.96 35.67097590003646 139.7385059883302 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671028166569734 139.73848935698945 15.2 35.67103033838908 139.73850017984213 15.2 35.67103033838908 139.73850017984213 29.96 35.671028166569734 139.73848935698945 29.96 35.671028166569734 139.73848935698945 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67103033838908 139.73850017984213 15.2 35.67109990769798 139.7384789990096 15.2 35.67109990769798 139.7384789990096 29.96 35.67103033838908 139.73850017984213 29.96 35.67103033838908 139.73850017984213 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67109990769798 139.7384789990096 15.2 35.67109909315636 139.73847480235713 15.2 35.67109909315636 139.73847480235713 29.96 35.67109990769798 139.7384789990096 29.96 35.67109990769798 139.7384789990096 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67109909315636 139.73847480235713 15.2 35.671170915455 139.73845306649966 15.2 35.671170915455 139.73845306649966 29.96 35.67109909315636 139.73847480235713 29.96 35.67109909315636 139.73847480235713 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671170915455 139.73845306649966 15.2 35.67114703179114 139.7383421892604 15.2 35.67114703179114 139.7383421892604 29.96 35.671170915455 139.73845306649966 29.96 35.671170915455 139.73845306649966 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67114703179114 139.7383421892604 15.2 35.67113495645492 139.73834606979432 15.2 35.67113495645492 139.73834606979432 29.96 35.67114703179114 139.7383421892604 29.96 35.67114703179114 139.7383421892604 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67113495645492 139.73834606979432 15.2 35.67112554775714 139.73830244781166 15.2 35.67112554775714 139.73830244781166 29.96 35.67113495645492 139.73834606979432 29.96 35.67113495645492 139.73834606979432 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67112554775714 139.73830244781166 15.2 35.671142489193564 139.73829690454903 15.2 35.671142489193564 139.73829690454903 29.96 35.67112554775714 139.73830244781166 29.96 35.67112554775714 139.73830244781166 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671142489193564 139.73829690454903 15.2 35.67112131962669 139.73819883795395 15.2 35.67112131962669 139.73819883795395 29.96 35.671142489193564 139.73829690454903 29.96 35.671142489193564 139.73829690454903 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67112131962669 139.73819883795395 15.2 35.67106869293484 139.73821591178495 15.2 35.67106869293484 139.73821591178495 29.96 35.67112131962669 139.73819883795395 29.96 35.67112131962669 139.73819883795395 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67106869293484 139.73821591178495 15.2 35.671070140452834 139.73822264834376 15.2 35.671070140452834 139.73822264834376 29.96 35.67106869293484 139.73821591178495 29.96 35.67106869293484 139.73821591178495 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671070140452834 139.73822264834376 15.2 35.67106094881309 139.73822564176294 15.2 35.67106094881309 139.73822564176294 29.96 35.671070140452834 139.73822264834376 29.96 35.671070140452834 139.73822264834376 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67106094881309 139.73822564176294 15.2 35.67107334296711 139.738283068105 15.2 35.67107334296711 139.738283068105 29.96 35.67106094881309 139.73822564176294 29.96 35.67106094881309 139.73822564176294 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67107334296711 139.738283068105 15.2 35.67108154336053 139.7382804072578 15.2 35.67108154336053 139.7382804072578 29.96 35.67107334296711 139.738283068105 29.96 35.67107334296711 139.738283068105 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67108154336053 139.7382804072578 15.2 35.671087966468306 139.73831000387884 15.2 35.671087966468306 139.73831000387884 29.96 35.67108154336053 139.7382804072578 29.96 35.67108154336053 139.7382804072578 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671087966468306 139.73831000387884 15.2 35.671106268671934 139.738304072385 15.2 35.671106268671934 139.738304072385 29.96 35.671087966468306 139.73831000387884 29.96 35.671087966468306 139.73831000387884 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671106268671934 139.738304072385 15.2 35.67111705242144 139.73835398915395 15.2 35.67111705242144 139.73835398915395 29.96 35.671106268671934 139.738304072385 29.96 35.671106268671934 139.738304072385 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67111705242144 139.73835398915395 15.2 35.671087828373416 139.73836346840903 15.2 35.671087828373416 139.73836346840903 29.96 35.67111705242144 139.73835398915395 29.96 35.67111705242144 139.73835398915395 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671087828373416 139.73836346840903 15.2 35.67109560848329 139.73839935985617 15.2 35.67109560848329 139.73839935985617 29.96 35.671087828373416 139.73836346840903 29.96 35.671087828373416 139.73836346840903 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67109560848329 139.73839935985617 15.2 35.67108443434305 139.7384030183848 15.2 35.67108443434305 139.7384030183848 29.96 35.67109560848329 139.73839935985617 29.96 35.67109560848329 139.73839935985617 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67108443434305 139.7384030183848 15.2 35.67108389134259 139.73840025743866 15.2 35.67108389134259 139.73840025743866 29.96 35.67108443434305 139.7384030183848 29.96 35.67108443434305 139.7384030183848 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67108389134259 139.73840025743866 15.2 35.671014412184626 139.7384214382285 15.2 35.671014412184626 139.7384214382285 29.96 35.67108389134259 139.73840025743866 29.96 35.67108389134259 139.73840025743866 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671014412184626 139.7384214382285 15.2 35.67101776032084 139.7384380037856 15.2 35.67101776032084 139.7384380037856 29.96 35.671014412184626 139.7384214382285 29.96 35.671014412184626 139.7384214382285 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67101776032084 139.7384380037856 15.2 35.670990184601486 139.7384459897912 15.2 35.670990184601486 139.7384459897912 29.96 35.67101776032084 139.7384380037856 29.96 35.67101776032084 139.7384380037856 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670990184601486 139.7384459897912 15.2 35.670987831806364 139.73843428345216 15.2 35.670987831806364 139.73843428345216 29.96 35.670990184601486 139.7384459897912 29.96 35.670990184601486 139.7384459897912 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670987831806364 139.73843428345216 15.2 35.67094872174472 139.7384463702522 15.2 35.67094872174472 139.7384463702522 29.96 35.670987831806364 139.73843428345216 29.96 35.670987831806364 139.73843428345216 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67094872174472 139.7384463702522 29.96 35.6709449212694 139.73842770644043 29.96 35.670875622292314 139.738448776493 29.96 35.67089227253375 139.7385312728718 29.96 35.67089344405665 139.73853094009667 29.96 35.67092656314104 139.7386947180768 29.96 35.67100901906771 139.73866965600493 29.96 35.671014447184696 139.73869494572975 29.96 35.67107842932377 139.73867542862027 29.96 35.67104295768576 139.73850027537927 29.96 35.67097852427998 139.73851901990957 29.96 35.67097590003646 139.7385059883302 29.96 35.671028166569734 139.73848935698945 29.96 35.67103033838908 139.73850017984213 29.96 35.67109990769798 139.7384789990096 29.96 35.67109909315636 139.73847480235713 29.96 35.671170915455 139.73845306649966 29.96 35.67114703179114 139.7383421892604 29.96 35.67113495645492 139.73834606979432 29.96 35.67112554775714 139.73830244781166 29.96 35.671142489193564 139.73829690454903 29.96 35.67112131962669 139.73819883795395 29.96 35.67106869293484 139.73821591178495 29.96 35.671070140452834 139.73822264834376 29.96 35.67106094881309 139.73822564176294 29.96 35.67107334296711 139.738283068105 29.96 35.67108154336053 139.7382804072578 29.96 35.671087966468306 139.73831000387884 29.96 35.671106268671934 139.738304072385 29.96 35.67111705242144 139.73835398915395 29.96 35.671087828373416 139.73836346840903 29.96 35.67109560848329 139.73839935985617 29.96 35.67108443434305 139.7384030183848 29.96 35.67108389134259 139.73840025743866 29.96 35.671014412184626 139.7384214382285 29.96 35.67101776032084 139.7384380037856 29.96 35.670990184601486 139.7384459897912 29.96 35.670987831806364 139.73843428345216 29.96 35.67094872174472 139.7384463702522 29.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7f20633f-b4cc-4377-960f-cdb22eb07e63"/>
							<gml:surfaceMember xlink:href="#poly-99f82c73-405b-4019-a7c7-963caf4e8700"/>
							<gml:surfaceMember xlink:href="#poly-38858a43-642c-4f05-bc67-c348221b9033"/>
							<gml:surfaceMember xlink:href="#poly-caf7e55d-bc7f-4f35-8d3c-823694becb71"/>
							<gml:surfaceMember xlink:href="#poly-479ee1b9-f447-469b-999e-6a15e3f84943"/>
							<gml:surfaceMember xlink:href="#poly-986b65bf-22ca-48dd-999f-bf3687a95d46"/>
							<gml:surfaceMember xlink:href="#poly-b036be81-e2eb-4c30-8042-b9a3288b5cdd"/>
							<gml:surfaceMember xlink:href="#poly-e99f05f6-9d05-4007-ac14-0ce96abde230"/>
							<gml:surfaceMember xlink:href="#poly-931fe20f-801c-476a-b110-8510bea4e545"/>
							<gml:surfaceMember xlink:href="#poly-9c60798d-cad7-4e80-acb8-58c5b5907840"/>
							<gml:surfaceMember xlink:href="#poly-ecc3d8b7-f314-46d0-9f69-c5191405c2ad"/>
							<gml:surfaceMember xlink:href="#poly-1ceb981e-4351-4446-820f-af25389412cd"/>
							<gml:surfaceMember xlink:href="#poly-0ea3a070-ee3f-426b-95af-2091147de6d1"/>
							<gml:surfaceMember xlink:href="#poly-f5a465ee-d08b-4646-bb81-5aa396f51378"/>
							<gml:surfaceMember xlink:href="#poly-5ec7f9fc-2238-415a-8c44-c8ce7012b33e"/>
							<gml:surfaceMember xlink:href="#poly-498f07f0-871d-4206-a407-eb9764d4ad58"/>
							<gml:surfaceMember xlink:href="#poly-3a640f2e-2b98-4329-b90b-eabb2ea7cd10"/>
							<gml:surfaceMember xlink:href="#poly-eb6ba44a-aff3-4a8c-89f5-680b7a2d4136"/>
							<gml:surfaceMember xlink:href="#poly-522437b3-d8cf-437e-9ba6-11f400890a37"/>
							<gml:surfaceMember xlink:href="#poly-760fe3b5-d2b1-4255-9586-da0c1307f9db"/>
							<gml:surfaceMember xlink:href="#poly-cdc6bbe0-46d5-498c-9876-b868d74d5e1a"/>
							<gml:surfaceMember xlink:href="#poly-72ca80d0-c8ca-49f4-bb22-39da1fe3a895"/>
							<gml:surfaceMember xlink:href="#poly-7d9b4b6c-0355-4a45-9744-b19ac69ad09d"/>
							<gml:surfaceMember xlink:href="#poly-b8051a9e-68f9-4c98-941b-c5441596e282"/>
							<gml:surfaceMember xlink:href="#poly-6c63ae08-5091-4cae-a898-37f2d82e4993"/>
							<gml:surfaceMember xlink:href="#poly-ba09d6a8-224e-40b3-bf52-3ecb33fc5804"/>
							<gml:surfaceMember xlink:href="#poly-9cf3bda8-52f5-4d80-8dac-00ec5122ebe4"/>
							<gml:surfaceMember xlink:href="#poly-282fea9e-b047-49e3-b4d8-94ed469f5d09"/>
							<gml:surfaceMember xlink:href="#poly-11583e45-e244-4561-afd5-3fe6efc4695c"/>
							<gml:surfaceMember xlink:href="#poly-5b33f2a4-a5a9-4bba-82d1-17285ea00b30"/>
							<gml:surfaceMember xlink:href="#poly-17364499-4b05-45dd-afb1-8e4e1e87420f"/>
							<gml:surfaceMember xlink:href="#poly-6f5b4003-2246-400e-b3ce-9b0363177b13"/>
							<gml:surfaceMember xlink:href="#poly-eb3c910d-9eb0-4fb3-a60b-7c0ecfc76f68"/>
							<gml:surfaceMember xlink:href="#poly-9e7a969e-daa7-4e73-834a-17a2d442323f"/>
							<gml:surfaceMember xlink:href="#poly-b43f09ed-febe-4bd0-8184-19453b7e9fed"/>
							<gml:surfaceMember xlink:href="#poly-b48e73bb-349e-4cb7-a3f1-30ba6a04596e"/>
							<gml:surfaceMember xlink:href="#poly-fb48af7d-13ba-47dd-9be2-56dd832b6a47"/>
							<gml:surfaceMember xlink:href="#poly-cd71ecc1-285a-4add-8089-c1504b5433df"/>
							<gml:surfaceMember xlink:href="#poly-bed8216d-ac83-4ccc-b293-549eeb2d863c"/>
							<gml:surfaceMember xlink:href="#poly-7b2da31b-856d-4da1-b4ba-b02b789d07ba"/>
							<gml:surfaceMember xlink:href="#poly-9dcecf3b-b2aa-439e-9138-117715b45948"/>
							<gml:surfaceMember xlink:href="#poly-280fb528-b2a1-4c90-9bf6-21e2777acf9a"/>
							<gml:surfaceMember xlink:href="#poly-f07c9034-4fb3-4c7a-bc36-4f3a31c83e68"/>
							<gml:surfaceMember xlink:href="#poly-395adecc-760d-46b7-ba5c-99c406053259"/>
							<gml:surfaceMember xlink:href="#poly-de8f3628-520d-4e44-9b07-eb9c2a930279"/>
							<gml:surfaceMember xlink:href="#poly-0dc3d529-ee19-4354-963d-eb5878b43116"/>
							<gml:surfaceMember xlink:href="#poly-3842d76a-8556-4b3d-b473-a3d9e522e227"/>
							<gml:surfaceMember xlink:href="#poly-3dce6fa3-ecc4-41a9-83a5-be68b59b7370"/>
							<gml:surfaceMember xlink:href="#poly-448315c6-81c3-4c16-8c87-2549bfcb57bd"/>
							<gml:surfaceMember xlink:href="#poly-0271b615-0954-40c4-94bc-b7c74e6d9a1e"/>
							<gml:surfaceMember xlink:href="#poly-c3ca698e-66da-45b4-9375-592fed8d6d6b"/>
							<gml:surfaceMember xlink:href="#poly-08ae6f98-95fc-49bb-a48c-c53b125e30db"/>
							<gml:surfaceMember xlink:href="#poly-6dbdf25d-cb41-417b-a7db-5785e14cca06"/>
							<gml:surfaceMember xlink:href="#poly-738ce39a-1aa3-494f-bf0f-4c5af167b444"/>
							<gml:surfaceMember xlink:href="#poly-30580ed8-9164-4a0c-8d7c-711c0fda96e3"/>
							<gml:surfaceMember xlink:href="#poly-b60357bc-32df-4661-8263-2bb866b68c2b"/>
							<gml:surfaceMember xlink:href="#poly-d89352ed-5297-4968-8416-99e1fd649e3f"/>
							<gml:surfaceMember xlink:href="#poly-2b8472ae-3fc9-435e-a112-0abb687a1e88"/>
							<gml:surfaceMember xlink:href="#poly-ab37c212-e659-49a8-9e9d-f9892fe425d6"/>
							<gml:surfaceMember xlink:href="#poly-c160d8e9-dee8-4ebd-8597-bf180b91b407"/>
							<gml:surfaceMember xlink:href="#poly-cc09b0af-02d8-4949-a1ea-e8f2b08490a6"/>
							<gml:surfaceMember xlink:href="#poly-2e321eba-fbd3-4f9b-b43e-d8240be141cc"/>
							<gml:surfaceMember xlink:href="#poly-0eb8bb86-02ba-489a-8184-588328df4e62"/>
							<gml:surfaceMember xlink:href="#poly-26193ca5-1262-432e-81e6-68ef1d97923f"/>
							<gml:surfaceMember xlink:href="#poly-6dd77979-33b2-43a7-920d-b2c6c919021f"/>
							<gml:surfaceMember xlink:href="#poly-a9bbab5b-5cb2-44d3-93c6-445393f2eb46"/>
							<gml:surfaceMember xlink:href="#poly-43bb25a6-a257-4fea-b369-a904f5abcd78"/>
							<gml:surfaceMember xlink:href="#poly-ad1eb3b6-ae02-4d89-b098-ff3fd9cf79b8"/>
							<gml:surfaceMember xlink:href="#poly-a716bebe-7e6a-4c3d-902b-ce7d7ed89406"/>
							<gml:surfaceMember xlink:href="#poly-ad57d842-585a-4192-8183-7905cee2e0a8"/>
							<gml:surfaceMember xlink:href="#poly-3052316d-85eb-4b8b-a437-99df9ec0f828"/>
							<gml:surfaceMember xlink:href="#poly-cae6c7d5-a849-4a0b-8dac-6e54ce7119fc"/>
							<gml:surfaceMember xlink:href="#poly-70c1833f-103a-452f-8ef2-8d540e57aa46"/>
							<gml:surfaceMember xlink:href="#poly-624eec7b-d747-4eb4-a280-2cf9d4ac7089"/>
							<gml:surfaceMember xlink:href="#poly-2adf3dd7-3b16-46a1-90da-6248cc29d5ce"/>
							<gml:surfaceMember xlink:href="#poly-a547f394-1126-464c-bbb1-b4be613efccf"/>
							<gml:surfaceMember xlink:href="#poly-2db1e845-5a73-40ed-a1eb-8a23b4b4a840"/>
							<gml:surfaceMember xlink:href="#poly-60ac8900-7437-4781-a9ae-b2b1572e7213"/>
							<gml:surfaceMember xlink:href="#poly-4d7f2e8a-c9a7-47ec-ae09-a5138dedc67f"/>
							<gml:surfaceMember xlink:href="#poly-93f7751c-7583-49b4-b134-2ca7f28de319"/>
							<gml:surfaceMember xlink:href="#poly-731b43b0-0bfb-4627-8f7e-ec2199e1b287"/>
							<gml:surfaceMember xlink:href="#poly-48c6d626-912e-4294-8c8c-c2d2e52edd40"/>
							<gml:surfaceMember xlink:href="#poly-5e876146-4566-454a-8f95-c83c5b3a9dab"/>
							<gml:surfaceMember xlink:href="#poly-a14ba138-f612-41af-a605-67b483e01269"/>
							<gml:surfaceMember xlink:href="#poly-3b620706-5876-4612-84f1-6703cdec2b70"/>
							<gml:surfaceMember xlink:href="#poly-32c0983d-0c07-4278-bfd4-1f47597c807a"/>
							<gml:surfaceMember xlink:href="#poly-3c110b6d-83dc-48e2-a4d8-3aae6acd798f"/>
							<gml:surfaceMember xlink:href="#poly-35e4dc75-f54f-48e7-8d3d-b78c0dc077ff"/>
							<gml:surfaceMember xlink:href="#poly-157cabc0-62ab-478c-948a-c225b86bda1a"/>
							<gml:surfaceMember xlink:href="#poly-72dea51d-37b4-4545-a7bc-4f6696191645"/>
							<gml:surfaceMember xlink:href="#poly-6f446c99-579b-49e0-9e58-3f3ee761d29a"/>
							<gml:surfaceMember xlink:href="#poly-11b5d322-5781-4d36-866b-5c3d124a475a"/>
							<gml:surfaceMember xlink:href="#poly-b7b22550-c34c-4e06-8f6b-3f2f073eddf4"/>
							<gml:surfaceMember xlink:href="#poly-9bb635cf-667a-4309-a6ec-27d8beb9b742"/>
							<gml:surfaceMember xlink:href="#poly-e15192ef-ab0f-4124-842e-37f03adfd99b"/>
							<gml:surfaceMember xlink:href="#poly-c6c4813d-5d38-409e-9684-2f352eec6e66"/>
							<gml:surfaceMember xlink:href="#poly-12d33760-6523-4f4a-ba90-abf643ae808f"/>
							<gml:surfaceMember xlink:href="#poly-60912dd1-ab5e-42ef-8cdd-282fc408ed6f"/>
							<gml:surfaceMember xlink:href="#poly-aef03a9f-971a-4745-82cf-ff75cef2a21e"/>
							<gml:surfaceMember xlink:href="#poly-2b85bcea-a2c6-4e07-b4f6-ef82f6508bf0"/>
							<gml:surfaceMember xlink:href="#poly-95939089-db32-4f59-bd02-e5384ff72dca"/>
							<gml:surfaceMember xlink:href="#poly-9d80220a-af2a-4a1e-be33-cb24401ef815"/>
							<gml:surfaceMember xlink:href="#poly-f94d556b-5e4b-400f-a87d-355b27379dd5"/>
							<gml:surfaceMember xlink:href="#poly-6009a785-2e69-44a4-a6f0-a59a0fb209f0"/>
							<gml:surfaceMember xlink:href="#poly-c6432c56-b84a-45bc-852d-d6116627670b"/>
							<gml:surfaceMember xlink:href="#poly-4ca571fc-ea9a-4538-8b92-d40d6f8f30f0"/>
							<gml:surfaceMember xlink:href="#poly-3cf1b72e-f8d7-48e2-b61a-23e0c44e8105"/>
							<gml:surfaceMember xlink:href="#poly-95b6e70d-508c-423a-96f2-56069abc56cc"/>
							<gml:surfaceMember xlink:href="#poly-73bea7ae-788c-4b48-8d1f-217e7359bcc4"/>
							<gml:surfaceMember xlink:href="#poly-3f73a7fa-9473-4d5a-98bc-1b6a676dd34a"/>
							<gml:surfaceMember xlink:href="#poly-09d57b09-22c1-417f-8137-a47e3ab14714"/>
							<gml:surfaceMember xlink:href="#poly-ebf73332-296d-4f89-8b43-ec52758a05d6"/>
							<gml:surfaceMember xlink:href="#poly-c21abf33-2c31-4e5c-9b74-00bd6a243d4b"/>
							<gml:surfaceMember xlink:href="#poly-9b155a43-5cea-49a5-b3f4-e93ff608c7f4"/>
							<gml:surfaceMember xlink:href="#poly-70ffa5d2-7513-44ff-bb53-ac28350894f8"/>
							<gml:surfaceMember xlink:href="#poly-f6a61bbc-d9f7-4156-b71c-bae3eb1c256d"/>
							<gml:surfaceMember xlink:href="#poly-9c6b353c-a337-4802-9306-bf4c698d1c40"/>
							<gml:surfaceMember xlink:href="#poly-ab90d4e1-84c2-402b-a6f1-25e379ee6b14"/>
							<gml:surfaceMember xlink:href="#poly-c0c3e3bf-8c34-4211-b63f-6c5a865d58a7"/>
							<gml:surfaceMember xlink:href="#poly-e137bf9b-bb8a-476d-8306-564e0abe86d7"/>
							<gml:surfaceMember xlink:href="#poly-db08d727-e855-4b4e-8899-4a73872eb3cd"/>
							<gml:surfaceMember xlink:href="#poly-ce463342-9c77-4171-a61b-b512e8782a5c"/>
							<gml:surfaceMember xlink:href="#poly-b5652e26-db2c-4214-8ead-065d5ab2207d"/>
							<gml:surfaceMember xlink:href="#poly-b8a34046-3853-4df7-a547-bd348e0e65ba"/>
							<gml:surfaceMember xlink:href="#poly-db136b6e-8b10-4ebc-af15-eaa6f0a60465"/>
							<gml:surfaceMember xlink:href="#poly-2924c423-9e39-44ac-bca6-4c44169bcfc5"/>
							<gml:surfaceMember xlink:href="#poly-48c992c2-2105-4c8a-b047-54636697ab08"/>
							<gml:surfaceMember xlink:href="#poly-44f345ae-0a34-4f5a-8ba1-b6a30a5e4979"/>
							<gml:surfaceMember xlink:href="#poly-56b6a829-096f-4d79-8595-916d906cb291"/>
							<gml:surfaceMember xlink:href="#poly-6b951ff5-79c6-4be1-a46d-f9fc00a3495e"/>
							<gml:surfaceMember xlink:href="#poly-2c436db9-fddb-4c9b-b907-2c8edaacf0ca"/>
							<gml:surfaceMember xlink:href="#poly-4c458ec4-6f30-4cf0-a4a7-1306b3f9a955"/>
							<gml:surfaceMember xlink:href="#poly-9f44037b-c0ac-40d3-a82c-5c9d7fa596bf"/>
							<gml:surfaceMember xlink:href="#poly-29c62e55-9688-4b75-b114-02c0bf0ab074"/>
							<gml:surfaceMember xlink:href="#poly-ae90b036-b206-4f39-8ac7-aa98d026badf"/>
							<gml:surfaceMember xlink:href="#poly-58e6d24c-d86d-4551-aa1c-14e88d93e827"/>
							<gml:surfaceMember xlink:href="#poly-f0922905-06a0-4b85-ba1a-a418decfae73"/>
							<gml:surfaceMember xlink:href="#poly-576d5a78-78ee-448d-bc8d-722a2858c541"/>
							<gml:surfaceMember xlink:href="#poly-b6f6ff0d-0781-4422-a2b1-e014cb1e55fb"/>
							<gml:surfaceMember xlink:href="#poly-e696e962-44ac-44be-9ccd-6b8e7949c6b7"/>
							<gml:surfaceMember xlink:href="#poly-580743cc-1858-459f-9b41-171935597b56"/>
							<gml:surfaceMember xlink:href="#poly-34c6a0f4-3d10-430e-b39e-a8204ad6ce19"/>
							<gml:surfaceMember xlink:href="#poly-b1aa64b6-faee-4305-98b2-395673b08e76"/>
							<gml:surfaceMember xlink:href="#poly-2e5bcb5c-a572-4e59-8e3d-2b04fee8c74d"/>
							<gml:surfaceMember xlink:href="#poly-530400aa-0d4a-449c-8a68-3926c5db5097"/>
							<gml:surfaceMember xlink:href="#poly-b7139abe-60c7-45b6-98c9-6463c17be95a"/>
							<gml:surfaceMember xlink:href="#poly-73a92fde-d147-48bf-b901-11256e888b11"/>
							<gml:surfaceMember xlink:href="#poly-f3ac77dd-0dd9-4271-9d45-d870c24459b7"/>
							<gml:surfaceMember xlink:href="#poly-d3af9570-1522-4b00-82e3-6f5c6e99386b"/>
							<gml:surfaceMember xlink:href="#poly-89e51092-ff7f-4c3e-8d83-67b05732a049"/>
							<gml:surfaceMember xlink:href="#poly-7e19b7bc-783c-41bc-ab6e-36ab4fbf4934"/>
							<gml:surfaceMember xlink:href="#poly-df96f3ae-04da-47ab-96a5-8f50ade1f267"/>
							<gml:surfaceMember xlink:href="#poly-a5170ad1-0932-4bda-a090-17e3e1e8a437"/>
							<gml:surfaceMember xlink:href="#poly-d3e41d7c-abc1-4309-987a-bf69f20ec4bc"/>
							<gml:surfaceMember xlink:href="#poly-9c146a06-8854-42bb-8a0c-0d22bdbc2976"/>
							<gml:surfaceMember xlink:href="#poly-70775d81-5159-41dc-b8c8-6f5547e1dc35"/>
							<gml:surfaceMember xlink:href="#poly-36b56327-9a41-440d-8c3e-170c38918f8e"/>
							<gml:surfaceMember xlink:href="#poly-3a5e56a1-0a1c-4e65-a20c-73be769b8bcd"/>
							<gml:surfaceMember xlink:href="#poly-748b1afa-bab9-47d6-961a-0cdf8a83f7cf"/>
							<gml:surfaceMember xlink:href="#poly-93444dd5-cd4a-4bb6-b16b-b9701a8c636f"/>
							<gml:surfaceMember xlink:href="#poly-2967a9d3-3353-47fa-87dd-59f61a2f9c64"/>
							<gml:surfaceMember xlink:href="#poly-eb925025-21a9-4b03-a4ae-b9dd7b4b8e55"/>
							<gml:surfaceMember xlink:href="#poly-b321272d-bb53-44cb-bb29-e91d009a2783"/>
							<gml:surfaceMember xlink:href="#poly-99d2b095-8623-4428-8155-fa155c399178"/>
							<gml:surfaceMember xlink:href="#poly-39e6d595-4cbb-4cdf-99e7-4f3c6719ca45"/>
							<gml:surfaceMember xlink:href="#poly-e2507eff-16ac-42f6-b7ee-a6677f53f513"/>
							<gml:surfaceMember xlink:href="#poly-22d96077-221b-4ffa-b74a-b377ac9fd6fc"/>
							<gml:surfaceMember xlink:href="#poly-415672c1-173a-42b8-96e8-5184d025d71b"/>
							<gml:surfaceMember xlink:href="#poly-28fa450b-fb8f-40cf-a84c-8b8f7cbcceba"/>
							<gml:surfaceMember xlink:href="#poly-d5779ba7-e7c9-4d30-947f-66e083fe5bdc"/>
							<gml:surfaceMember xlink:href="#poly-63c3acf6-ae8e-417c-a941-daab9b54b3a0"/>
							<gml:surfaceMember xlink:href="#poly-69b9a279-f6d9-4fb2-a674-cfd4420f4007"/>
							<gml:surfaceMember xlink:href="#poly-3cc4caab-325b-451c-8247-3bfe4d61d291"/>
							<gml:surfaceMember xlink:href="#poly-51bbca06-1a21-47b9-b3a3-2138d2033a99"/>
							<gml:surfaceMember xlink:href="#poly-9976e36e-c128-4b34-8574-814ef7ec948e"/>
							<gml:surfaceMember xlink:href="#poly-6bce51d2-625d-44d6-8eeb-771d6fcd0dc9"/>
							<gml:surfaceMember xlink:href="#poly-10600363-2b92-4599-972d-d855d53b8c57"/>
							<gml:surfaceMember xlink:href="#poly-c8bb5ec1-9da6-4eff-bd23-c8132520fce6"/>
							<gml:surfaceMember xlink:href="#poly-a165f1b3-9321-411d-9c7e-29d343cd8788"/>
							<gml:surfaceMember xlink:href="#poly-26080e13-3f23-4ca7-a8b4-a6175b548aea"/>
							<gml:surfaceMember xlink:href="#poly-782e9c47-6974-4d36-8c51-22663d186f22"/>
							<gml:surfaceMember xlink:href="#poly-4deddd8d-2359-4575-a078-dedb70a4c435"/>
							<gml:surfaceMember xlink:href="#poly-affed224-6b43-4817-86c7-b66bc7633bd3"/>
							<gml:surfaceMember xlink:href="#poly-b0881da4-83ca-471c-9aea-8fc385d05399"/>
							<gml:surfaceMember xlink:href="#poly-a075dcb8-95e6-4062-aa75-954380180125"/>
							<gml:surfaceMember xlink:href="#poly-0199a10e-32dd-4eed-81fe-b34c9c9be122"/>
							<gml:surfaceMember xlink:href="#poly-4ede115d-4956-4727-a65e-555ab02d5585"/>
							<gml:surfaceMember xlink:href="#poly-036ea154-14d3-4526-807e-3cd78169d80f"/>
							<gml:surfaceMember xlink:href="#poly-f61ead21-677a-44e1-b735-f0c70d6e29cf"/>
							<gml:surfaceMember xlink:href="#poly-f16ca729-d3eb-4c1f-a9b0-2e06a494d7ea"/>
							<gml:surfaceMember xlink:href="#poly-0217b789-55b9-49fe-ad80-b46bdd94bb68"/>
							<gml:surfaceMember xlink:href="#poly-a7bd73b0-bb3f-42ca-84b0-fa4b7271ff58"/>
							<gml:surfaceMember xlink:href="#poly-58da9241-ef35-4c78-a6df-cc5311c31bb6"/>
							<gml:surfaceMember xlink:href="#poly-83667e41-a44e-48c3-9920-7ad8b370fb8f"/>
							<gml:surfaceMember xlink:href="#poly-6049cdf1-3424-4e3a-9761-879fa9675d30"/>
							<gml:surfaceMember xlink:href="#poly-ee9ba352-c092-4ec8-85b0-a2275d2dbf3e"/>
							<gml:surfaceMember xlink:href="#poly-961ff256-15cc-424e-b133-8be59b682e36"/>
							<gml:surfaceMember xlink:href="#poly-bffe9be3-f39f-4508-be38-9a4dc0e8db23"/>
							<gml:surfaceMember xlink:href="#poly-2ea2055f-12b4-4bd9-a18e-885089936674"/>
							<gml:surfaceMember xlink:href="#poly-bac33f3f-21c0-4eae-a6e6-5739683f749d"/>
							<gml:surfaceMember xlink:href="#poly-8b78791f-3c49-46cd-b95f-529e838e1c5b"/>
							<gml:surfaceMember xlink:href="#poly-af5505fe-5ed5-4327-ae4e-97f035b1a2a2"/>
							<gml:surfaceMember xlink:href="#poly-d66088e0-b6e8-45fe-874c-7218a46182c2"/>
							<gml:surfaceMember xlink:href="#poly-80c0d38f-3728-41d0-ac1e-27776808158d"/>
							<gml:surfaceMember xlink:href="#poly-670bb6b5-35e5-44bf-9e7b-2beb39761c81"/>
							<gml:surfaceMember xlink:href="#poly-5fd42490-51ac-4c28-b518-734cd1ad9a8c"/>
							<gml:surfaceMember xlink:href="#poly-d1df27dd-76ab-4ef9-988c-49a11ddad068"/>
							<gml:surfaceMember xlink:href="#poly-fcf19a55-923d-4418-be24-94186e52008d"/>
							<gml:surfaceMember xlink:href="#poly-41c38f53-5334-415f-bfde-22e26387ab4c"/>
							<gml:surfaceMember xlink:href="#poly-d29875ad-374e-444b-bdd5-5291c26f8d0d"/>
							<gml:surfaceMember xlink:href="#poly-452c3d40-734e-4c8c-ac20-8380da49925a"/>
							<gml:surfaceMember xlink:href="#poly-1241396e-76a2-4d85-a219-91730b5a9e64"/>
							<gml:surfaceMember xlink:href="#poly-f220fd0e-7395-44e7-8ac2-75788f967ee3"/>
							<gml:surfaceMember xlink:href="#poly-6b44d777-cb39-4b9d-82f5-8e6d43489c1e"/>
							<gml:surfaceMember xlink:href="#poly-60009b4b-9890-47f0-9246-a1bf567073e1"/>
							<gml:surfaceMember xlink:href="#poly-3be94091-815a-4150-8a22-8da2aa4027bd"/>
							<gml:surfaceMember xlink:href="#poly-77865395-3a22-4d9a-8497-5b2f83abd9a1"/>
							<gml:surfaceMember xlink:href="#poly-67f733ac-cdcc-4a60-a044-b12fbfff56eb"/>
							<gml:surfaceMember xlink:href="#poly-38f79f21-f650-4dd1-aa4e-09e3fe9ef22a"/>
							<gml:surfaceMember xlink:href="#poly-56109b23-6f09-41e4-a8a4-7f6a3a7e45af"/>
							<gml:surfaceMember xlink:href="#poly-181dd03c-f147-4ae4-bc81-4532519a72b7"/>
							<gml:surfaceMember xlink:href="#poly-07170b76-f8bc-4e6d-b13b-d348ba2ef2b7"/>
							<gml:surfaceMember xlink:href="#poly-a82ccb6f-0c40-446b-b05f-055ef1a03788"/>
							<gml:surfaceMember xlink:href="#poly-a61bf948-dbb1-4710-a641-17ec5c5d128b"/>
							<gml:surfaceMember xlink:href="#poly-6188ce4a-970f-4027-8b93-a185db0e6c73"/>
							<gml:surfaceMember xlink:href="#poly-a7931159-e73c-40f7-b768-57b1b792b03f"/>
							<gml:surfaceMember xlink:href="#poly-d02d725a-561e-44a3-a2b7-552f692871ef"/>
							<gml:surfaceMember xlink:href="#poly-57cc9daf-1347-4e11-aa1e-a014407e0510"/>
							<gml:surfaceMember xlink:href="#poly-b5b0ced0-d1a0-4665-9a9e-47a9ed57ce05"/>
							<gml:surfaceMember xlink:href="#poly-74a1c2d3-d203-4ed9-abbe-93e63d4e92e3"/>
							<gml:surfaceMember xlink:href="#poly-bbb64578-74df-4ec9-b35f-3d3466b35998"/>
							<gml:surfaceMember xlink:href="#poly-7f2d6de9-5215-4aa2-808e-d5323beff5c7"/>
							<gml:surfaceMember xlink:href="#poly-fa03fe1a-e3ee-4561-ba29-eb7e630d33ac"/>
							<gml:surfaceMember xlink:href="#poly-0b06ce0c-d479-4ce3-bfb6-976530787b80"/>
							<gml:surfaceMember xlink:href="#poly-80cadf31-1535-4457-9d9b-ca6ea6d7318c"/>
							<gml:surfaceMember xlink:href="#poly-327da49d-3002-4dfc-b367-ebcc682ffe0b"/>
							<gml:surfaceMember xlink:href="#poly-c3a924b6-e06a-4535-a7a7-4ef374df859a"/>
							<gml:surfaceMember xlink:href="#poly-d64f9ea2-a372-457e-8379-d632f1e290e3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_17c9cca1-6a1c-4569-bb88-24235bac9cba_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e99cacf-1a6e-4a7a-9414-ddcf68dcbb0a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671098239495116 139.73830667779586 15.2 35.671106268671934 139.738304072385 15.2 35.67111704340771 139.73835398916464 15.2 35.67110900521611 139.73835659458155 15.2 35.671098239495116 139.73830667779586 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d91cd8df-8f80-496b-9d03-dd0d342c32c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d91cd8df-8f80-496b-9d03-dd0d342c32c0_0">
											<gml:posList>35.671106268663216 139.73830406133865 27.223 35.671106268671934 139.738304072385 15.2 35.671098239495116 139.73830667779586 15.2 35.671098239486405 139.73830666674954 27.223 35.671106268663216 139.73830406133865 27.223</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8351d338-cff9-4bb3-a3a5-077411ebd1b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8351d338-cff9-4bb3-a3a5-077411ebd1b8_0">
											<gml:posList>35.671107453801994 139.73830956102094 27.223 35.671106268663216 139.73830406133865 27.223 35.671098239486405 139.73830666674954 27.223 35.67109942462507 139.7383121664313 27.223 35.671107453801994 139.73830956102094 27.223</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a04ae2a-0a87-4d71-a9a6-6b90beb52e98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a04ae2a-0a87-4d71-a9a6-6b90beb52e98_0">
											<gml:posList>35.671098239486405 139.73830666674954 27.223 35.671098239495116 139.73830667779586 15.2 35.67110900521611 139.73835659458155 15.2 35.67110900521611 139.73835659458155 29.423 35.671107711505286 139.7383505758482 29.423 35.67109942462507 139.7383121664313 27.223 35.671098239486405 139.73830666674954 27.223</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aca0a133-62f2-4e10-a9dd-e2cfc3273bb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aca0a133-62f2-4e10-a9dd-e2cfc3273bb8_0">
											<gml:posList>35.67111574969676 139.7383479704307 29.423 35.671107453801994 139.73830956102094 27.223 35.67109942462507 139.7383121664313 27.223 35.671107711505286 139.7383505758482 29.423 35.67111574969676 139.7383479704307 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9656e2aa-220c-4092-bfd9-bd3a83d1cb7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9656e2aa-220c-4092-bfd9-bd3a83d1cb7b_0">
											<gml:posList>35.67111704340771 139.73835398916464 29.423 35.67111704340771 139.73835398916464 15.2 35.671106268671934 139.738304072385 15.2 35.671106268663216 139.73830406133865 27.223 35.671107453801994 139.73830956102094 27.223 35.67111574969676 139.7383479704307 29.423 35.67111704340771 139.73835398916464 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2ffa6c2-48fb-4b5c-9121-5f700bed90b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2ffa6c2-48fb-4b5c-9121-5f700bed90b2_0">
											<gml:posList>35.67110900521611 139.73835659458155 29.423 35.67111704340771 139.73835398916464 29.423 35.67111574969676 139.7383479704307 29.423 35.671107711505286 139.7383505758482 29.423 35.67110900521611 139.73835659458155 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99864dd8-48fa-4982-b0fe-cd768d6e5662">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99864dd8-48fa-4982-b0fe-cd768d6e5662_0">
											<gml:posList>35.67110900521611 139.73835659458155 29.423 35.67110900521611 139.73835659458155 15.2 35.67111704340771 139.73835398916464 15.2 35.67111704340771 139.73835398916464 29.423 35.67110900521611 139.73835659458155 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_17c9cca1-6a1c-4569-bb88-24235bac9cba_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58c245e8-b342-41f9-94e4-cac639756cd2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6710634532892 139.73845245356563 30.29 35.671068103582826 139.73847433088972 30.29 35.67104686356756 139.73848111638654 30.29 35.67104221328386 139.73845925011418 30.29 35.6710634532892 139.73845245356563 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-502e8c36-b2d9-4ff3-8b78-a03e11d40701">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-502e8c36-b2d9-4ff3-8b78-a03e11d40701_0">
											<gml:posList>35.67104221328386 139.73845925011418 30.29 35.67104221328386 139.73845925011418 32.778 35.6710634532892 139.73845245356563 32.778 35.6710634532892 139.73845245356563 30.29 35.67104221328386 139.73845925011418 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-288814d3-2069-4b55-8fa6-d9087407634d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-288814d3-2069-4b55-8fa6-d9087407634d_0">
											<gml:posList>35.6710634532892 139.73845245356563 32.778 35.671068103582826 139.73847433088972 32.778 35.671068103582826 139.73847433088972 30.29 35.6710634532892 139.73845245356563 30.29 35.6710634532892 139.73845245356563 32.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56feed3f-f12e-47f8-80ea-8e023236a6f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56feed3f-f12e-47f8-80ea-8e023236a6f7_0">
											<gml:posList>35.67104686356756 139.73848111638654 32.778 35.671068103582826 139.73847433088972 32.778 35.6710634532892 139.73845245356563 32.778 35.67104221328386 139.73845925011418 32.778 35.67104686356756 139.73848111638654 32.778</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7e943c0-f174-4371-a8f1-23daeeb19ebc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7e943c0-f174-4371-a8f1-23daeeb19ebc_0">
											<gml:posList>35.67104686356756 139.73848111638654 30.29 35.67104686356756 139.73848111638654 32.778 35.67104221328386 139.73845925011418 32.778 35.67104221328386 139.73845925011418 30.29 35.67104686356756 139.73848111638654 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-874bd56f-9787-42be-a899-001013d35425">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-874bd56f-9787-42be-a899-001013d35425_0">
											<gml:posList>35.671068103582826 139.73847433088972 30.29 35.671068103582826 139.73847433088972 32.778 35.67104686356756 139.73848111638654 32.778 35.67104686356756 139.73848111638654 30.29 35.671068103582826 139.73847433088972 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_17c9cca1-6a1c-4569-bb88-24235bac9cba_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f48ec9fd-a05e-45ce-8006-ed8079a2c6f3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67111392201025 139.73845353161525 31.793 35.67111006716646 139.73843450329917 31.793 35.671126414156156 139.73842953518 31.793 35.671130269000734 139.73844856349973 31.793 35.67111392201025 139.73845353161525 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a24b13ee-6f78-4a3b-a88e-f4352c44ece5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671077722337145 139.73847573344287 30.29 35.67107593068453 139.7384669316176 30.29 35.67108721316546 139.7384634938972 30.29 35.671089004827024 139.73847230676998 30.29 35.671077722337145 139.73847573344287 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d5182e9-5be5-4e08-a83b-7b5e049e5d1b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67094449058447 139.73847596839653 31.088 35.670946002584856 139.73848448333362 31.088 35.67094465982751 139.73848484945125 31.088 35.67094303066618 139.73847635674556 31.088 35.67094449058447 139.73847596839653 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-871a5cb2-0e7a-4270-922d-bf547ca29c15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093746837447 139.73848675792857 30.872 35.67093595637424 139.73847824299233 30.872 35.67094303066618 139.73847635674556 30.872 35.67094465982751 139.73848484945125 30.872 35.67093746837447 139.73848675792857 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e80eb1a-daa0-4790-b4fc-4bbab2e7b455">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671030248243376 139.73848872488503 30.29 35.67102807652741 139.73847803458872 30.29 35.67103535787377 139.73847581670432 30.29 35.671037719643756 139.73848747885546 30.29 35.67103044730221 139.7384896856819 30.29 35.671030248243376 139.73848872488503 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0b52257-7e38-4a7d-9d3f-139f658982ec">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67102600386754 139.73847866668274 30.524 35.67102807652741 139.73847803458872 30.524 35.671030248243376 139.73848872488503 30.524 35.67103044730221 139.7384896856819 30.524 35.671028356614826 139.73849031779696 30.524 35.67102600386754 139.73847866668274 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fea994bd-7728-4f1e-92aa-cb4ee096f210">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67091876049159 139.73849262357004 30.872 35.67090894660227 139.73849524211332 30.872 35.670907398425946 139.7384865725741 30.872 35.67091722132879 139.73848395401913 30.872 35.67091876049159 139.73849262357004 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6b0de18-f404-4e4c-b5c8-dedfd1b1a61d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67093880833905 139.73849428994473 30.872 35.670929913657915 139.7384966643818 30.872 35.67092882722616 139.73849059018275 30.872 35.67091887816589 139.73849325307185 30.872 35.670917990879815 139.7384882501324 30.872 35.67093684364333 139.73848322384012 30.872 35.67093880833905 139.73849428994473 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f929d213-8a51-420b-8f82-470a9cb9c107">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67098808974312 139.73852142774672 32.135 35.67098713943176 139.73851651324796 32.135 35.67101184040505 139.73850932600388 32.135 35.671012790716716 139.7385142405041 32.135 35.67098808974312 139.73852142774672 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e31828b4-e9de-4177-87ef-a1d228e16ff3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097401366169 139.7385142532244 34.977 35.67097471661888 139.7385141087906 34.977 35.67097654739317 139.73852680991808 34.977 35.67097401366169 139.7385142532244 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5777a5b6-db39-4480-a091-5c18c2481258">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67101474562179 139.73852432350665 30.198 35.6709900446476 139.73853151074638 30.198 35.67098808974312 139.73852142774672 30.198 35.671012790716716 139.7385142405041 30.198 35.67101474562179 139.73852432350665 30.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45c6d2c8-a433-4cd1-9019-7600b0b8f0b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670954491828184 139.738562471486 33.714 35.670952736741064 139.73855431031672 33.714 35.67094777016738 139.7385199510321 33.714 35.67097401366169 139.7385142532244 33.714 35.67097654739317 139.73852680991808 33.714 35.670980879517955 139.73855674038228 33.714 35.670954491828184 139.738562471486 33.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d12e4168-4620-4fff-8cf1-50bde7c028a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097378304131 139.73855334649804 38.631 35.67097247657341 139.73855401082292 38.631 35.67097107969007 139.7385543217718 38.631 35.670969664501044 139.73855427925938 38.631 35.670968276074944 139.73855388323244 38.631 35.670967004548984 139.73855313358445 38.631 35.6709658769991 139.73855207446874 38.631 35.670964956564816 139.7385507610424 38.631 35.67096427031337 139.7385492264125 38.631 35.670963872396634 139.7385475588856 38.631 35.67096376286678 139.73854582473976 38.631 35.67096394178469 139.73854410129925 38.631 35.67096441822494 139.73854246587769 38.631 35.670965156184835 139.73854098479566 38.631 35.67096612867538 139.73853972436314 38.631 35.67096729968519 139.73853873985436 38.631 35.67096860615301 139.73853807552925 38.631 35.67097000302762 139.7385377535338 38.631 35.67097141821665 139.73853779604593 38.631 35.67097279763777 139.73853820312956 38.631 35.67097407816885 139.73853894172038 38.631 35.67097520571884 139.73854000083603 38.631 35.67097612616194 139.73854132530872 38.631 35.67097680339107 139.73854284890314 38.631 35.670977210321595 139.7385445164196 38.631 35.67097731985147 139.73854625056575 38.631 35.67097714093353 139.73854797400654 38.631 35.67097666449321 139.73854960942833 38.631 35.67097592653321 139.73855109051047 38.631 35.670974954051225 139.73855236198938 38.631 35.67097378304131 139.73855334649804 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d716ee6a-71b0-440c-a557-ee3aaebfdd79">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095393307309 139.7385625936562 34.977 35.670952736741064 139.73855431031672 34.977 35.670954491828184 139.738562471486 34.977 35.67095393307309 139.7385625936562 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22dff977-dce6-4ba6-bf12-3aaebb26bdd1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095902718319 139.7385757659172 33.714 35.670972797732745 139.7385726787594 33.714 35.670975470835955 139.73859053753384 33.714 35.67096169128092 139.73859363574567 33.714 35.67095902718319 139.7385757659172 33.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d188acc-4040-4b4c-a4d9-5c7a0864a86f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d188acc-4040-4b4c-a4d9-5c7a0864a86f_0">
											<gml:posList>35.67103044730221 139.7384896856819 30.29 35.67103044730221 139.7384896856819 30.524 35.671030248243376 139.73848872488503 30.524 35.671030248243376 139.73848872488503 30.29 35.67103044730221 139.7384896856819 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4248ed6-2c86-43cc-82be-127e04df77bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4248ed6-2c86-43cc-82be-127e04df77bf_0">
											<gml:posList>35.67107675451726 139.73822009983593 31.735 35.67108491886312 139.7382174500713 31.735 35.67107700684036 139.7382200222121 30.701 35.67107675451726 139.73822009983593 30.556 35.67107675451726 139.73822009983593 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77caba12-fe02-45ca-abd9-bab900898034">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77caba12-fe02-45ca-abd9-bab900898034_0">
											<gml:posList>35.67109554356435 139.7383056315872 30.701 35.67107700684036 139.7382200222121 30.701 35.67108491886312 139.7382174500713 31.735 35.67110341954275 139.7383030705433 31.735 35.67109554356435 139.7383056315872 30.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d36e22e6-d6f1-4134-901b-c0ffd09a30b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d36e22e6-d6f1-4134-901b-c0ffd09a30b8_0">
											<gml:posList>35.67108491886312 139.7382174500713 31.735 35.67107675451726 139.73822009983593 31.735 35.67109525519502 139.73830572029985 31.735 35.67110341954275 139.7383030705433 31.735 35.67108491886312 139.7382174500713 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-523f950d-df5c-4093-80a7-96041ef6af30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-523f950d-df5c-4093-80a7-96041ef6af30_0">
											<gml:posList>35.67109525519502 139.73830572029985 30.53 35.67107675451726 139.73822009983593 30.556 35.67107700684036 139.7382200222121 30.701 35.67109554356435 139.7383056315872 30.701 35.67109525519502 139.73830572029985 30.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4512f069-c3c2-44fa-84cd-3d347b3216d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4512f069-c3c2-44fa-84cd-3d347b3216d8_0">
											<gml:posList>35.67109525519502 139.73830572029985 31.735 35.67107675451726 139.73822009983593 31.735 35.67107675451726 139.73822009983593 30.556 35.67109525519502 139.73830572029985 30.53 35.67109525519502 139.73830572029985 31.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d1df0ca-15ed-4d76-9723-3827ad11634f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d1df0ca-15ed-4d76-9723-3827ad11634f_0">
											<gml:posList>35.67109554356435 139.7383056315872 30.701 35.67110341954275 139.7383030705433 31.735 35.67109525519502 139.73830572029985 31.735 35.67109525519502 139.73830572029985 30.53 35.67109554356435 139.7383056315872 30.701</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e59800c-d566-42cb-af84-ec655fe76857">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e59800c-d566-42cb-af84-ec655fe76857_0">
											<gml:posList>35.67111006716646 139.73843450329917 31.793 35.67111006716646 139.73843450329917 34.779 35.671126414156156 139.73842953518 34.779 35.671126414156156 139.73842953518 31.793 35.67111006716646 139.73843450329917 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43092713-d102-4e7a-8052-e67005992266">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43092713-d102-4e7a-8052-e67005992266_0">
											<gml:posList>35.671126414156156 139.73842953518 31.793 35.671126414156156 139.73842953518 34.779 35.671130269000734 139.73844856349973 34.779 35.671130269000734 139.73844856349973 31.793 35.671126414156156 139.73842953518 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1fbfee1-98c6-4876-8b34-ba552d117974">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1fbfee1-98c6-4876-8b34-ba552d117974_0">
											<gml:posList>35.671126414156156 139.73842953518 34.779 35.67111006716646 139.73843450329917 34.779 35.67111392201025 139.73845353161525 34.779 35.671130269000734 139.73844856349973 34.779 35.671126414156156 139.73842953518 34.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8688836c-489c-41fd-862a-fd154663167f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8688836c-489c-41fd-862a-fd154663167f_0">
											<gml:posList>35.67111006716646 139.73843450329917 31.793 35.67111392201025 139.73845353161525 31.793 35.67111392201025 139.73845353161525 34.779 35.67111006716646 139.73843450329917 34.779 35.67111006716646 139.73843450329917 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb51f044-b718-4837-9eef-b48776f5c59a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb51f044-b718-4837-9eef-b48776f5c59a_0">
											<gml:posList>35.67111392201025 139.73845353161525 31.793 35.671130269000734 139.73844856349973 31.793 35.671130269000734 139.73844856349973 34.779 35.67111392201025 139.73845353161525 34.779 35.67111392201025 139.73845353161525 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8fe1cca-2c05-4520-b223-8ecca63d99de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8fe1cca-2c05-4520-b223-8ecca63d99de_0">
											<gml:posList>35.67108721316546 139.7384634938972 30.29 35.67107593068453 139.7384669316176 30.29 35.67107593068453 139.7384669316176 31.428 35.67108721316546 139.7384634938972 31.428 35.67108721316546 139.7384634938972 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5dff903-60e2-4f7e-bbd8-39f024a6a947">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5dff903-60e2-4f7e-bbd8-39f024a6a947_0">
											<gml:posList>35.671089004827024 139.73847230676998 30.29 35.67108721316546 139.7384634938972 30.29 35.67108721316546 139.7384634938972 31.428 35.671089004827024 139.73847230676998 31.428 35.671089004827024 139.73847230676998 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fa7b675-3720-4f5e-9a2e-f2e3ce2dda48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fa7b675-3720-4f5e-9a2e-f2e3ce2dda48_0">
											<gml:posList>35.67108721316546 139.7384634938972 31.428 35.67107593068453 139.7384669316176 31.428 35.671077722337145 139.73847573344287 31.428 35.671089004827024 139.73847230676998 31.428 35.67108721316546 139.7384634938972 31.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-830d67b0-addd-4e3e-bd4b-9e4c9391ae42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-830d67b0-addd-4e3e-bd4b-9e4c9391ae42_0">
											<gml:posList>35.67107593068453 139.7384669316176 30.29 35.671077722337145 139.73847573344287 30.29 35.671077722337145 139.73847573344287 31.428 35.67107593068453 139.7384669316176 31.428 35.67107593068453 139.7384669316176 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c648be3-45a0-473e-af0e-317644aed8c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c648be3-45a0-473e-af0e-317644aed8c9_0">
											<gml:posList>35.671077722337145 139.73847573344287 30.29 35.671089004827024 139.73847230676998 30.29 35.671089004827024 139.73847230676998 31.428 35.671077722337145 139.73847573344287 31.428 35.671077722337145 139.73847573344287 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df9a91bf-c568-4b91-8dc3-7610a2c1e86b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df9a91bf-c568-4b91-8dc3-7610a2c1e86b_0">
											<gml:posList>35.67093595637424 139.73847824299233 30.872 35.67093595637424 139.73847824299233 32.262 35.67094449058447 139.73847596839653 32.262 35.67094449058447 139.73847596839653 31.088 35.67094303066618 139.73847635674556 31.088 35.67094303066618 139.73847635674556 30.872 35.67093595637424 139.73847824299233 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1488f6d9-2e51-4bca-8939-7a348b444c5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1488f6d9-2e51-4bca-8939-7a348b444c5c_0">
											<gml:posList>35.67102807652741 139.73847803458872 30.524 35.67102600386754 139.73847866668274 30.524 35.67102600386754 139.73847866668274 31.386 35.67103535787377 139.73847581670432 31.386 35.67103535787377 139.73847581670432 30.29 35.67102807652741 139.73847803458872 30.29 35.67102807652741 139.73847803458872 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f51ceed-ba48-44ad-a89b-284c23dff3c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f51ceed-ba48-44ad-a89b-284c23dff3c1_0">
											<gml:posList>35.670946002584856 139.73848448333362 31.088 35.67094449058447 139.73847596839653 31.088 35.67094449058447 139.73847596839653 32.262 35.670946002584856 139.73848448333362 32.262 35.670946002584856 139.73848448333362 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-722b1a64-ce99-49b5-ac56-b61f25173d6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-722b1a64-ce99-49b5-ac56-b61f25173d6b_0">
											<gml:posList>35.67094465982751 139.73848484945125 30.872 35.67094303066618 139.73847635674556 30.872 35.67094303066618 139.73847635674556 31.088 35.67094465982751 139.73848484945125 31.088 35.67094465982751 139.73848484945125 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0000c3a3-f582-44a0-b4c0-b3415e4b969b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0000c3a3-f582-44a0-b4c0-b3415e4b969b_0">
											<gml:posList>35.67094449058447 139.73847596839653 32.262 35.67093595637424 139.73847824299233 32.262 35.67093746837447 139.73848675792857 32.262 35.670946002584856 139.73848448333362 32.262 35.67094449058447 139.73847596839653 32.262</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dc5ee99-ba50-4d8f-bde7-0ed3f4dfc4b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dc5ee99-ba50-4d8f-bde7-0ed3f4dfc4b9_0">
											<gml:posList>35.67103535787377 139.73847581670432 30.29 35.67103535787377 139.73847581670432 31.386 35.671037719643756 139.73848747885546 31.386 35.671037719643756 139.73848747885546 30.29 35.67103535787377 139.73847581670432 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0c04d4e-4956-43ab-8d1a-1af51b261e47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0c04d4e-4956-43ab-8d1a-1af51b261e47_0">
											<gml:posList>35.67093746837447 139.73848675792857 30.872 35.67093746837447 139.73848675792857 32.262 35.67093595637424 139.73847824299233 32.262 35.67093595637424 139.73847824299233 30.872 35.67093746837447 139.73848675792857 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-696fcf1d-a4cd-4c09-8bbd-18668e5d731d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-696fcf1d-a4cd-4c09-8bbd-18668e5d731d_0">
											<gml:posList>35.671037719643756 139.73848747885546 31.386 35.67103535787377 139.73847581670432 31.386 35.67102600386754 139.73847866668274 31.386 35.671028356614826 139.73849031779696 31.386 35.671037719643756 139.73848747885546 31.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d477a4f4-6b82-4731-ae6e-96ab93d881cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d477a4f4-6b82-4731-ae6e-96ab93d881cc_0">
											<gml:posList>35.671030248243376 139.73848872488503 30.524 35.67102807652741 139.73847803458872 30.524 35.67102807652741 139.73847803458872 30.29 35.671030248243376 139.73848872488503 30.29 35.671030248243376 139.73848872488503 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0436ffc-eb95-4459-8bcd-907a6af345a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0436ffc-eb95-4459-8bcd-907a6af345a0_0">
											<gml:posList>35.67102600386754 139.73847866668274 30.524 35.671028356614826 139.73849031779696 30.524 35.671028356614826 139.73849031779696 31.386 35.67102600386754 139.73847866668274 31.386 35.67102600386754 139.73847866668274 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97c6d8a9-4d4c-498d-a3a9-4dafaf60ff07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97c6d8a9-4d4c-498d-a3a9-4dafaf60ff07_0">
											<gml:posList>35.67091722132879 139.73848395401913 30.872 35.670907398425946 139.7384865725741 30.872 35.670907398425946 139.7384865725741 31.939 35.67091722132879 139.73848395401913 31.939 35.67091722132879 139.73848395401913 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36cd32a0-9abd-4c01-a9a1-09cff7adac67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36cd32a0-9abd-4c01-a9a1-09cff7adac67_0">
											<gml:posList>35.67094465982751 139.73848484945125 31.088 35.670946002584856 139.73848448333362 31.088 35.670946002584856 139.73848448333362 32.262 35.67093746837447 139.73848675792857 32.262 35.67093746837447 139.73848675792857 30.872 35.67094465982751 139.73848484945125 30.872 35.67094465982751 139.73848484945125 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad291aaa-d308-4b3e-a652-d5dfff11ad47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad291aaa-d308-4b3e-a652-d5dfff11ad47_0">
											<gml:posList>35.670917990879815 139.7384882501324 30.872 35.670917990879815 139.7384882501324 31.939 35.67093684364333 139.73848322384012 31.939 35.67093684364333 139.73848322384012 30.872 35.670917990879815 139.7384882501324 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e95f581e-f09c-4844-b1ee-322a2e6ff08a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e95f581e-f09c-4844-b1ee-322a2e6ff08a_0">
											<gml:posList>35.67091722132879 139.73848395401913 30.872 35.67091722132879 139.73848395401913 31.939 35.67091876049159 139.73849262357004 31.939 35.67091876049159 139.73849262357004 30.872 35.67091722132879 139.73848395401913 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d10e19d-0e59-493d-86df-520f5f33da86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d10e19d-0e59-493d-86df-520f5f33da86_0">
											<gml:posList>35.67093880833905 139.73849428994473 31.939 35.67093880833905 139.73849428994473 30.872 35.67093684364333 139.73848322384012 30.872 35.67093684364333 139.73848322384012 31.939 35.67093880833905 139.73849428994473 31.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca0e7fe4-627c-4210-86b9-8cb388d80c67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca0e7fe4-627c-4210-86b9-8cb388d80c67_0">
											<gml:posList>35.671037719643756 139.73848747885546 30.29 35.671037719643756 139.73848747885546 31.386 35.671028356614826 139.73849031779696 31.386 35.671028356614826 139.73849031779696 30.524 35.67103044730221 139.7384896856819 30.524 35.67103044730221 139.7384896856819 30.29 35.671037719643756 139.73848747885546 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39f328ee-c4a0-43f0-a06d-f08da61b03a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39f328ee-c4a0-43f0-a06d-f08da61b03a9_0">
											<gml:posList>35.670907398425946 139.7384865725741 31.939 35.67090894660227 139.73849524211332 31.939 35.67091876049159 139.73849262357004 31.939 35.67091722132879 139.73848395401913 31.939 35.670907398425946 139.7384865725741 31.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ee52a75-00fe-414e-ac49-c105542129ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ee52a75-00fe-414e-ac49-c105542129ef_0">
											<gml:posList>35.67092882722616 139.73849059018275 31.939 35.670929913657915 139.7384966643818 31.939 35.67093880833905 139.73849428994473 31.939 35.67093684364333 139.73848322384012 31.939 35.670917990879815 139.7384882501324 31.939 35.67091887816589 139.73849325307185 31.939 35.67092882722616 139.73849059018275 31.939</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0644a4ad-c9b5-4c73-b824-ff2d422bd325">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0644a4ad-c9b5-4c73-b824-ff2d422bd325_0">
											<gml:posList>35.67091887816589 139.73849325307185 30.872 35.67091887816589 139.73849325307185 31.939 35.670917990879815 139.7384882501324 31.939 35.670917990879815 139.7384882501324 30.872 35.67091887816589 139.73849325307185 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-258ec1dd-8d84-484c-886f-d4e972a86ac9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-258ec1dd-8d84-484c-886f-d4e972a86ac9_0">
											<gml:posList>35.670907398425946 139.7384865725741 30.872 35.67090894660227 139.73849524211332 30.872 35.67090894660227 139.73849524211332 31.939 35.670907398425946 139.7384865725741 31.939 35.670907398425946 139.7384865725741 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f961aa9a-bba6-4261-bb04-12f41001a099">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f961aa9a-bba6-4261-bb04-12f41001a099_0">
											<gml:posList>35.67092882722616 139.73849059018275 30.872 35.67092882722616 139.73849059018275 31.939 35.67091887816589 139.73849325307185 31.939 35.67091887816589 139.73849325307185 30.872 35.67092882722616 139.73849059018275 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d57cbc4-f1bf-4d5a-a9f7-100e4c718592">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d57cbc4-f1bf-4d5a-a9f7-100e4c718592_0">
											<gml:posList>35.670929913657915 139.7384966643818 30.872 35.670929913657915 139.7384966643818 31.939 35.67092882722616 139.73849059018275 31.939 35.67092882722616 139.73849059018275 30.872 35.670929913657915 139.7384966643818 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1870148-d71b-4ef1-bc8a-aae4e1725f13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1870148-d71b-4ef1-bc8a-aae4e1725f13_0">
											<gml:posList>35.67090894660227 139.73849524211332 30.872 35.67091876049159 139.73849262357004 30.872 35.67091876049159 139.73849262357004 31.939 35.67090894660227 139.73849524211332 31.939 35.67090894660227 139.73849524211332 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-584695b8-d414-438d-9e9b-6ac45950d6a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-584695b8-d414-438d-9e9b-6ac45950d6a2_0">
											<gml:posList>35.67093880833905 139.73849428994473 30.872 35.67093880833905 139.73849428994473 31.939 35.670929913657915 139.7384966643818 31.939 35.670929913657915 139.7384966643818 30.872 35.67093880833905 139.73849428994473 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12a5e5ec-2bb2-49cf-bc74-569f20cbe985">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12a5e5ec-2bb2-49cf-bc74-569f20cbe985_0">
											<gml:posList>35.67101184040505 139.73850932600388 32.135 35.67098713943176 139.73851651324796 32.135 35.67098713943176 139.73851651324796 33.048 35.67101184040505 139.73850932600388 33.048 35.67101184040505 139.73850932600388 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65cfada7-4ee0-4d93-98dc-9108ec904a05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65cfada7-4ee0-4d93-98dc-9108ec904a05_0">
											<gml:posList>35.67101184040505 139.73850932600388 33.048 35.67101474562179 139.73852432350665 33.048 35.67101474562179 139.73852432350665 30.198 35.671012790716716 139.7385142405041 30.198 35.671012790716716 139.7385142405041 32.135 35.67101184040505 139.73850932600388 32.135 35.67101184040505 139.73850932600388 33.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f4b5a73-f3c7-49ab-b255-97fc820cebcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f4b5a73-f3c7-49ab-b255-97fc820cebcc_0">
											<gml:posList>35.67094777016738 139.7385199510321 33.714 35.67094777016738 139.7385199510321 38.631 35.67097471661888 139.7385141087906 38.631 35.67097471661888 139.7385141087906 34.977 35.67097401366169 139.7385142532244 34.977 35.67097401366169 139.7385142532244 33.714 35.67094777016738 139.7385199510321 33.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6371714a-2566-434c-a93f-e25c62e98251">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6371714a-2566-434c-a93f-e25c62e98251_0">
											<gml:posList>35.671012790716716 139.7385142405041 30.198 35.67098808974312 139.73852142774672 30.198 35.67098808974312 139.73852142774672 32.135 35.671012790716716 139.7385142405041 32.135 35.671012790716716 139.7385142405041 30.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5337b1b-2a56-40a7-ae6b-1c996b71946a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5337b1b-2a56-40a7-ae6b-1c996b71946a_0">
											<gml:posList>35.6709900446476 139.73853151074638 33.048 35.67101474562179 139.73852432350665 33.048 35.67101184040505 139.73850932600388 33.048 35.67098713943176 139.73851651324796 33.048 35.6709900446476 139.73853151074638 33.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f688bf84-44be-4aca-a764-194a89e306b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f688bf84-44be-4aca-a764-194a89e306b3_0">
											<gml:posList>35.67097401366169 139.7385142532244 34.977 35.67097654739317 139.73852680991808 34.977 35.67097654739317 139.73852680991808 33.714 35.67097401366169 139.7385142532244 33.714 35.67097401366169 139.7385142532244 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a474d75-6590-45e3-b52d-cc916b17d98e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a474d75-6590-45e3-b52d-cc916b17d98e_0">
											<gml:posList>35.67098808974312 139.73852142774672 32.135 35.67098808974312 139.73852142774672 30.198 35.6709900446476 139.73853151074638 30.198 35.6709900446476 139.73853151074638 33.048 35.67098713943176 139.73851651324796 33.048 35.67098713943176 139.73851651324796 32.135 35.67098808974312 139.73852142774672 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91216074-15d4-4271-a62d-7302c9e6e956">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91216074-15d4-4271-a62d-7302c9e6e956_0">
											<gml:posList>35.6709900446476 139.73853151074638 30.198 35.67101474562179 139.73852432350665 30.198 35.67101474562179 139.73852432350665 33.048 35.6709900446476 139.73853151074638 33.048 35.6709900446476 139.73853151074638 30.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3cd8440-60cd-4ef2-9920-5c47ce25f9af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3cd8440-60cd-4ef2-9920-5c47ce25f9af_0">
											<gml:posList>35.67097654739317 139.73852680991808 34.977 35.67097471661888 139.7385141087906 34.977 35.67097471661888 139.7385141087906 38.631 35.670980879517955 139.73855674038228 38.631 35.670980879517955 139.73855674038228 33.714 35.67097654739317 139.73852680991808 33.714 35.67097654739317 139.73852680991808 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b358fac9-1891-4689-848d-a19da66c7d0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b358fac9-1891-4689-848d-a19da66c7d0f_0">
											<gml:posList>35.67097141821665 139.73853779604593 38.631 35.67097000302762 139.7385377535338 38.631 35.67097000302762 139.7385377535338 39.691 35.67097141821665 139.73853779604593 39.691 35.67097141821665 139.73853779604593 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d90ae03c-5901-4fa1-b8c7-80bcf8661c13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d90ae03c-5901-4fa1-b8c7-80bcf8661c13_0">
											<gml:posList>35.67097000302762 139.7385377535338 38.631 35.67096860615301 139.73853807552925 38.631 35.67096860615301 139.73853807552925 39.691 35.67097000302762 139.7385377535338 39.691 35.67097000302762 139.7385377535338 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efe6a213-f648-4802-b948-8cc2e4be0fb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efe6a213-f648-4802-b948-8cc2e4be0fb3_0">
											<gml:posList>35.67097279763777 139.73853820312956 38.631 35.67097141821665 139.73853779604593 38.631 35.67097141821665 139.73853779604593 39.691 35.67097279763777 139.73853820312956 39.691 35.67097279763777 139.73853820312956 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b497337-b557-4729-bd44-c9e3f8601ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b497337-b557-4729-bd44-c9e3f8601ee8_0">
											<gml:posList>35.67095393307309 139.7385625936562 38.631 35.670980879517955 139.73855674038228 38.631 35.67097471661888 139.7385141087906 38.631 35.67094777016738 139.7385199510321 38.631 35.67095393307309 139.7385625936562 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e311c73-463a-4eed-b862-e3fe78b133cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e311c73-463a-4eed-b862-e3fe78b133cc_0">
											<gml:posList>35.67096860615301 139.73853807552925 38.631 35.67096729968519 139.73853873985436 38.631 35.67096729968519 139.73853873985436 39.691 35.67096860615301 139.73853807552925 39.691 35.67096860615301 139.73853807552925 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9309e06-938f-4baf-b97f-366bdf6552f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9309e06-938f-4baf-b97f-366bdf6552f0_0">
											<gml:posList>35.67097407816885 139.73853894172038 38.631 35.67097279763777 139.73853820312956 38.631 35.67097279763777 139.73853820312956 39.691 35.67097407816885 139.73853894172038 39.691 35.67097407816885 139.73853894172038 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf587969-682f-4fc2-af0c-0e23083da2bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf587969-682f-4fc2-af0c-0e23083da2bd_0">
											<gml:posList>35.67096729968519 139.73853873985436 38.631 35.67096612867538 139.73853972436314 38.631 35.67096612867538 139.73853972436314 39.691 35.67096729968519 139.73853873985436 39.691 35.67096729968519 139.73853873985436 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d23742a3-c1a5-45ca-8253-db6697c04665">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d23742a3-c1a5-45ca-8253-db6697c04665_0">
											<gml:posList>35.67097520571884 139.73854000083603 38.631 35.67097407816885 139.73853894172038 38.631 35.67097407816885 139.73853894172038 39.691 35.67097520571884 139.73854000083603 39.691 35.67097520571884 139.73854000083603 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da59213f-d900-45fd-8921-f9d4991d3c71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da59213f-d900-45fd-8921-f9d4991d3c71_0">
											<gml:posList>35.67096612867538 139.73853972436314 38.631 35.670965156184835 139.73854098479566 38.631 35.670965156184835 139.73854098479566 39.691 35.67096612867538 139.73853972436314 39.691 35.67096612867538 139.73853972436314 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17915b73-4de9-4a6b-9a67-a769dfb6ab18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17915b73-4de9-4a6b-9a67-a769dfb6ab18_0">
											<gml:posList>35.67097612616194 139.73854132530872 38.631 35.67097520571884 139.73854000083603 38.631 35.67097520571884 139.73854000083603 39.691 35.67097612616194 139.73854132530872 39.691 35.67097612616194 139.73854132530872 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da5c9636-95e8-44b2-9081-decea7e94620">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da5c9636-95e8-44b2-9081-decea7e94620_0">
											<gml:posList>35.670952736741064 139.73855431031672 34.977 35.67095393307309 139.7385625936562 34.977 35.67095393307309 139.7385625936562 38.631 35.67094777016738 139.7385199510321 38.631 35.67094777016738 139.7385199510321 33.714 35.670952736741064 139.73855431031672 33.714 35.670952736741064 139.73855431031672 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e59755f6-8393-4574-91ff-b7fbe6ca0014">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e59755f6-8393-4574-91ff-b7fbe6ca0014_0">
											<gml:posList>35.670965156184835 139.73854098479566 38.631 35.67096441822494 139.73854246587769 38.631 35.67096441822494 139.73854246587769 39.691 35.670965156184835 139.73854098479566 39.691 35.670965156184835 139.73854098479566 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa73a405-a92d-4e99-b5df-45f4c35d6f03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa73a405-a92d-4e99-b5df-45f4c35d6f03_0">
											<gml:posList>35.67097680339107 139.73854284890314 38.631 35.67097612616194 139.73854132530872 38.631 35.67097612616194 139.73854132530872 39.691 35.67097680339107 139.73854284890314 39.691 35.67097680339107 139.73854284890314 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4bc20f8-d4c0-4882-8957-763dfdaea939">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4bc20f8-d4c0-4882-8957-763dfdaea939_0">
											<gml:posList>35.67096441822494 139.73854246587769 38.631 35.67096394178469 139.73854410129925 38.631 35.67096394178469 139.73854410129925 39.691 35.67096441822494 139.73854246587769 39.691 35.67096441822494 139.73854246587769 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f96b92f5-15fe-4684-a2e7-ebd4c4ad1978">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f96b92f5-15fe-4684-a2e7-ebd4c4ad1978_0">
											<gml:posList>35.670977210321595 139.7385445164196 38.631 35.67097680339107 139.73854284890314 38.631 35.67097680339107 139.73854284890314 39.691 35.670977210321595 139.7385445164196 39.691 35.670977210321595 139.7385445164196 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d059d72-8940-42ac-b14c-05a65e099b7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d059d72-8940-42ac-b14c-05a65e099b7c_0">
											<gml:posList>35.67096394178469 139.73854410129925 38.631 35.67096376286678 139.73854582473976 38.631 35.67096376286678 139.73854582473976 39.691 35.67096394178469 139.73854410129925 39.691 35.67096394178469 139.73854410129925 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2032450-ed34-4479-9a27-b94025175f1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2032450-ed34-4479-9a27-b94025175f1f_0">
											<gml:posList>35.67097731985147 139.73854625056575 38.631 35.670977210321595 139.7385445164196 38.631 35.670977210321595 139.7385445164196 39.691 35.67097731985147 139.73854625056575 39.691 35.67097731985147 139.73854625056575 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5762879d-afb1-48a5-a552-d10e294404ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5762879d-afb1-48a5-a552-d10e294404ff_0">
											<gml:posList>35.670965156184835 139.73854098479566 39.691 35.67096441822494 139.73854246587769 39.691 35.67096394178469 139.73854410129925 39.691 35.67096376286678 139.73854582473976 39.691 35.670963872396634 139.7385475588856 39.691 35.67096427031337 139.7385492264125 39.691 35.670964956564816 139.7385507610424 39.691 35.6709658769991 139.73855207446874 39.691 35.670967004548984 139.73855313358445 39.691 35.670968276074944 139.73855388323244 39.691 35.670969664501044 139.73855427925938 39.691 35.67097107969007 139.7385543217718 39.691 35.67097247657341 139.73855401082292 39.691 35.67097378304131 139.73855334649804 39.691 35.670974954051225 139.73855236198938 39.691 35.67097592653321 139.73855109051047 39.691 35.67097666449321 139.73854960942833 39.691 35.67097714093353 139.73854797400654 39.691 35.67097731985147 139.73854625056575 39.691 35.670977210321595 139.7385445164196 39.691 35.67097680339107 139.73854284890314 39.691 35.67097612616194 139.73854132530872 39.691 35.67097520571884 139.73854000083603 39.691 35.67097407816885 139.73853894172038 39.691 35.67097279763777 139.73853820312956 39.691 35.67097141821665 139.73853779604593 39.691 35.67097000302762 139.7385377535338 39.691 35.67096860615301 139.73853807552925 39.691 35.67096729968519 139.73853873985436 39.691 35.67096612867538 139.73853972436314 39.691 35.670965156184835 139.73854098479566 39.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31e24ab7-f4cb-47c5-bb01-06f2acdf8c83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31e24ab7-f4cb-47c5-bb01-06f2acdf8c83_0">
											<gml:posList>35.67096376286678 139.73854582473976 38.631 35.670963872396634 139.7385475588856 38.631 35.670963872396634 139.7385475588856 39.691 35.67096376286678 139.73854582473976 39.691 35.67096376286678 139.73854582473976 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-083eedae-98c0-4de4-96b3-24342d103096">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-083eedae-98c0-4de4-96b3-24342d103096_0">
											<gml:posList>35.67097714093353 139.73854797400654 38.631 35.67097731985147 139.73854625056575 38.631 35.67097731985147 139.73854625056575 39.691 35.67097714093353 139.73854797400654 39.691 35.67097714093353 139.73854797400654 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59e15454-1e21-43a1-a643-a6d7d72be234">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59e15454-1e21-43a1-a643-a6d7d72be234_0">
											<gml:posList>35.670963872396634 139.7385475588856 38.631 35.67096427031337 139.7385492264125 38.631 35.67096427031337 139.7385492264125 39.691 35.670963872396634 139.7385475588856 39.691 35.670963872396634 139.7385475588856 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6289db47-3869-4dc3-b143-46e9bbdfba84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6289db47-3869-4dc3-b143-46e9bbdfba84_0">
											<gml:posList>35.67097666449321 139.73854960942833 38.631 35.67097714093353 139.73854797400654 38.631 35.67097714093353 139.73854797400654 39.691 35.67097666449321 139.73854960942833 39.691 35.67097666449321 139.73854960942833 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b67fd33e-8eba-45f2-abac-0e5948141c93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b67fd33e-8eba-45f2-abac-0e5948141c93_0">
											<gml:posList>35.67096427031337 139.7385492264125 38.631 35.670964956564816 139.7385507610424 38.631 35.670964956564816 139.7385507610424 39.691 35.67096427031337 139.7385492264125 39.691 35.67096427031337 139.7385492264125 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7981a00d-5295-4cbb-baff-f12852d6a3fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7981a00d-5295-4cbb-baff-f12852d6a3fb_0">
											<gml:posList>35.67097592653321 139.73855109051047 38.631 35.67097666449321 139.73854960942833 38.631 35.67097666449321 139.73854960942833 39.691 35.67097592653321 139.73855109051047 39.691 35.67097592653321 139.73855109051047 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c36ffd77-b427-4865-a4de-61f95a4850b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c36ffd77-b427-4865-a4de-61f95a4850b6_0">
											<gml:posList>35.670964956564816 139.7385507610424 38.631 35.6709658769991 139.73855207446874 38.631 35.6709658769991 139.73855207446874 39.691 35.670964956564816 139.7385507610424 39.691 35.670964956564816 139.7385507610424 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-392e0d12-e369-418a-84f3-0588d8b09560">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-392e0d12-e369-418a-84f3-0588d8b09560_0">
											<gml:posList>35.670974954051225 139.73855236198938 38.631 35.67097592653321 139.73855109051047 38.631 35.67097592653321 139.73855109051047 39.691 35.670974954051225 139.73855236198938 39.691 35.670974954051225 139.73855236198938 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d157a2cd-8cae-47c8-bf9a-5249405295e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d157a2cd-8cae-47c8-bf9a-5249405295e4_0">
											<gml:posList>35.6709658769991 139.73855207446874 38.631 35.670967004548984 139.73855313358445 38.631 35.670967004548984 139.73855313358445 39.691 35.6709658769991 139.73855207446874 39.691 35.6709658769991 139.73855207446874 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e00a61b1-556d-425a-88a9-2ddc563abbcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e00a61b1-556d-425a-88a9-2ddc563abbcb_0">
											<gml:posList>35.67097378304131 139.73855334649804 38.631 35.670974954051225 139.73855236198938 38.631 35.670974954051225 139.73855236198938 39.691 35.67097378304131 139.73855334649804 39.691 35.67097378304131 139.73855334649804 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be131eed-ff21-4466-92c1-116dd2345c34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be131eed-ff21-4466-92c1-116dd2345c34_0">
											<gml:posList>35.670967004548984 139.73855313358445 38.631 35.670968276074944 139.73855388323244 38.631 35.670968276074944 139.73855388323244 39.691 35.670967004548984 139.73855313358445 39.691 35.670967004548984 139.73855313358445 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3c571a8-1595-4b53-ad01-99b307146dec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3c571a8-1595-4b53-ad01-99b307146dec_0">
											<gml:posList>35.67097247657341 139.73855401082292 38.631 35.67097378304131 139.73855334649804 38.631 35.67097378304131 139.73855334649804 39.691 35.67097247657341 139.73855401082292 39.691 35.67097247657341 139.73855401082292 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe46c333-5301-4ab8-8f30-796f9fe5c5a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe46c333-5301-4ab8-8f30-796f9fe5c5a1_0">
											<gml:posList>35.670968276074944 139.73855388323244 38.631 35.670969664501044 139.73855427925938 38.631 35.670969664501044 139.73855427925938 39.691 35.670968276074944 139.73855388323244 39.691 35.670968276074944 139.73855388323244 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6d26e6f-35dc-4434-9b2d-520eca254035">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6d26e6f-35dc-4434-9b2d-520eca254035_0">
											<gml:posList>35.67097107969007 139.7385543217718 38.631 35.67097247657341 139.73855401082292 38.631 35.67097247657341 139.73855401082292 39.691 35.67097107969007 139.7385543217718 39.691 35.67097107969007 139.7385543217718 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b51e6397-144f-4ce9-84a4-5a214aa0aaa4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b51e6397-144f-4ce9-84a4-5a214aa0aaa4_0">
											<gml:posList>35.670969664501044 139.73855427925938 38.631 35.67097107969007 139.7385543217718 38.631 35.67097107969007 139.7385543217718 39.691 35.670969664501044 139.73855427925938 39.691 35.670969664501044 139.73855427925938 38.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-518c0b5c-7174-4892-af65-c4e826ffd393">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-518c0b5c-7174-4892-af65-c4e826ffd393_0">
											<gml:posList>35.670954491828184 139.738562471486 33.714 35.670954491828184 139.738562471486 34.977 35.670952736741064 139.73855431031672 34.977 35.670952736741064 139.73855431031672 33.714 35.670954491828184 139.738562471486 33.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31710e2e-73e9-462e-92f4-5725f0b67a9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31710e2e-73e9-462e-92f4-5725f0b67a9a_0">
											<gml:posList>35.670980879517955 139.73855674038228 33.714 35.670980879517955 139.73855674038228 38.631 35.67095393307309 139.7385625936562 38.631 35.67095393307309 139.7385625936562 34.977 35.670954491828184 139.738562471486 34.977 35.670954491828184 139.738562471486 33.714 35.670980879517955 139.73855674038228 33.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-989cf10e-6797-4972-af19-291ad3148841">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-989cf10e-6797-4972-af19-291ad3148841_0">
											<gml:posList>35.67095902718319 139.7385757659172 33.714 35.67095902718319 139.7385757659172 36.454 35.670972797732745 139.7385726787594 36.454 35.670972797732745 139.7385726787594 33.714 35.67095902718319 139.7385757659172 33.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-695d86ba-865f-446c-a95c-e8ac96408c9a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-695d86ba-865f-446c-a95c-e8ac96408c9a_0">
											<gml:posList>35.670975470835955 139.73859053753384 33.714 35.670972797732745 139.7385726787594 33.714 35.670972797732745 139.7385726787594 36.454 35.670975470835955 139.73859053753384 36.454 35.670975470835955 139.73859053753384 33.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d43d4334-e24e-48a4-88d8-47f669db13cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d43d4334-e24e-48a4-88d8-47f669db13cc_0">
											<gml:posList>35.67095902718319 139.7385757659172 36.454 35.67096169128092 139.73859363574567 36.454 35.670975470835955 139.73859053753384 36.454 35.670972797732745 139.7385726787594 36.454 35.67095902718319 139.7385757659172 36.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22f55627-f0a4-4e88-97ff-75127913ffdc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22f55627-f0a4-4e88-97ff-75127913ffdc_0">
											<gml:posList>35.67095902718319 139.7385757659172 33.714 35.67096169128092 139.73859363574567 33.714 35.67096169128092 139.73859363574567 36.454 35.67095902718319 139.7385757659172 36.454 35.67095902718319 139.7385757659172 33.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54fbc4e4-7166-40b1-8a7d-db058d21fa5e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54fbc4e4-7166-40b1-8a7d-db058d21fa5e_0">
											<gml:posList>35.67096169128092 139.73859363574567 33.714 35.670975470835955 139.73859053753384 33.714 35.670975470835955 139.73859053753384 36.454 35.67096169128092 139.73859363574567 36.454 35.67096169128092 139.73859363574567 33.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7f20633f-b4cc-4377-960f-cdb22eb07e63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f20633f-b4cc-4377-960f-cdb22eb07e63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f20633f-b4cc-4377-960f-cdb22eb07e63">
											<gml:posList>35.6711213196267 139.73819883795395 15.2 35.67114248919354 139.738296904549 15.2 35.671125547757136 139.73830244781163 15.2 35.67113495645493 139.73834606979432 15.2 35.671147031791136 139.7383421892604 15.2 35.671170915455 139.73845306649966 15.2 35.671099093156364 139.7384748023571 15.2 35.67109990769798 139.73847899900957 15.2 35.67103033838908 139.7385001798421 15.2 35.67102816656971 139.73848935698945 15.2 35.67097590003643 139.7385059883302 15.2 35.670978524279995 139.73851901990957 15.2 35.67104295768576 139.73850027537927 15.2 35.67107842932375 139.73867542862027 15.2 35.6710144471847 139.73869494572975 15.2 35.67100901906771 139.73866965600493 15.2 35.67092656314103 139.7386947180768 15.2 35.67089344405663 139.73853094009664 15.2 35.67089227253375 139.7385312728718 15.2 35.67087562229229 139.738448776493 15.2 35.67094492126938 139.73842770644043 15.2 35.67094872174471 139.73844637025223 15.2 35.67098783180639 139.73843428345216 15.2 35.67099018460151 139.7384459897912 15.2 35.67101776032082 139.7384380037856 15.2 35.67101441218462 139.7384214382285 15.2 35.67108389134256 139.73840025743866 15.2 35.67108443434303 139.7384030183848 15.2 35.67109560848327 139.73839935985617 15.2 35.67108782837342 139.73836346840903 15.2 35.671117052421444 139.73835398915395 15.2 35.671106268671934 139.738304072385 15.2 35.67108796646832 139.73831000387884 15.2 35.67108154336053 139.7382804072578 15.2 35.6710733429671 139.73828306810498 15.2 35.67106094881309 139.73822564176294 15.2 35.67107014045282 139.73822264834376 15.2 35.67106869293486 139.73821591178492 15.2 35.6711213196267 139.73819883795395 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99f82c73-405b-4019-a7c7-963caf4e8700">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99f82c73-405b-4019-a7c7-963caf4e8700">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99f82c73-405b-4019-a7c7-963caf4e8700">
											<gml:posList>35.67088214666775 139.73848111242125 27.145 35.67088542687921 139.738480114371 27.145 35.67087972592923 139.73845180937676 27.145 35.67087562229229 139.738448776493 27.145 35.67088214666775 139.73848111242125 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38858a43-642c-4f05-bc67-c348221b9033">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38858a43-642c-4f05-bc67-c348221b9033">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38858a43-642c-4f05-bc67-c348221b9033">
											<gml:posList>35.670889729745525 139.73851866097021 31.088 35.67089269072805 139.73851290233074 31.088 35.67088698985538 139.73848468570213 31.088 35.67088214666775 139.73848111242125 31.088 35.670889729745525 139.73851866097021 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-caf7e55d-bc7f-4f35-8d3c-823694becb71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-caf7e55d-bc7f-4f35-8d3c-823694becb71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-caf7e55d-bc7f-4f35-8d3c-823694becb71">
											<gml:posList>35.670889729745525 139.73851866097021 27.145 35.67089227253375 139.7385312728718 27.145 35.67089475639846 139.7385262880399 27.145 35.67089316327753 139.73851777320337 27.145 35.670889729745525 139.73851866097021 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-479ee1b9-f447-469b-999e-6a15e3f84943">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-479ee1b9-f447-469b-999e-6a15e3f84943">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-479ee1b9-f447-469b-999e-6a15e3f84943">
											<gml:posList>35.67089227253375 139.7385312728718 27.145 35.67089344405663 139.73853094009664 27.145 35.67089475639846 139.7385262880399 27.145 35.67089227253375 139.7385312728718 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-986b65bf-22ca-48dd-999f-bf3687a95d46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-986b65bf-22ca-48dd-999f-bf3687a95d46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-986b65bf-22ca-48dd-999f-bf3687a95d46">
											<gml:posList>35.67087562229229 139.738448776493 27.145 35.67087972592923 139.73845180937676 27.145 35.67094245546234 139.7384327243961 27.145 35.67094492126938 139.73842770644043 27.145 35.67087562229229 139.738448776493 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b036be81-e2eb-4c30-8042-b9a3288b5cdd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b036be81-e2eb-4c30-8042-b9a3288b5cdd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b036be81-e2eb-4c30-8042-b9a3288b5cdd">
											<gml:posList>35.67088214666775 139.73848111242125 31.088 35.67088698985538 139.73848468570213 31.088 35.67094146487879 139.73846821744803 31.088 35.67094442571091 139.73846227101544 31.088 35.67088214666775 139.73848111242125 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e99f05f6-9d05-4007-ac14-0ce96abde230">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e99f05f6-9d05-4007-ac14-0ce96abde230">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e99f05f6-9d05-4007-ac14-0ce96abde230">
											<gml:posList>35.67089269072805 139.73851290233074 30.872 35.670947338869084 139.73849878675972 30.872 35.67094146487879 139.73846821744803 30.872 35.67088698985538 139.73848468570213 30.872 35.67089269072805 139.73851290233074 30.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-931fe20f-801c-476a-b110-8510bea4e545">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-931fe20f-801c-476a-b110-8510bea4e545">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-931fe20f-801c-476a-b110-8510bea4e545">
											<gml:posList>35.67094245546234 139.7384327243961 26.815 35.67087972592923 139.73845180937676 26.815 35.67088542687921 139.738480114371 26.815 35.67094442571091 139.73846227101544 26.815 35.67095215515418 139.73850253681778 26.815 35.67089316327753 139.73851777320337 26.815 35.67089475639846 139.7385262880399 26.815 35.67095764841646 139.73850749012655 26.815 35.67094544153356 139.73844736830463 26.815 35.67094245546234 139.7384327243961 26.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c60798d-cad7-4e80-acb8-58c5b5907840">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c60798d-cad7-4e80-acb8-58c5b5907840">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c60798d-cad7-4e80-acb8-58c5b5907840">
											<gml:posList>35.67095215515418 139.73850253681778 31.088 35.670947338869084 139.73849878675972 31.088 35.67089269072805 139.73851290233074 31.088 35.670889729745525 139.73851866097021 31.088 35.67095215515418 139.73850253681778 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ecc3d8b7-f314-46d0-9f69-c5191405c2ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecc3d8b7-f314-46d0-9f69-c5191405c2ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecc3d8b7-f314-46d0-9f69-c5191405c2ad">
											<gml:posList>35.67089344405663 139.73853094009664 27.145 35.67096175206057 139.73851053406273 27.145 35.67095764841646 139.73850749012655 27.145 35.67089475639846 139.7385262880399 27.145 35.67089344405663 139.73853094009664 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ceb981e-4351-4446-820f-af25389412cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ceb981e-4351-4446-820f-af25389412cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ceb981e-4351-4446-820f-af25389412cd">
											<gml:posList>35.670964022421174 139.7386236679887 34.977 35.67094109745635 139.7385167113001 34.977 35.67089344405663 139.73853094009664 28.736 35.670964022421174 139.7386236679887 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ea3a070-ee3f-426b-95af-2091147de6d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ea3a070-ee3f-426b-95af-2091147de6d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ea3a070-ee3f-426b-95af-2091147de6d1">
											<gml:posList>35.670964022421174 139.7386236679887 34.977 35.67089344405663 139.73853094009664 28.736 35.67092656314103 139.7386947180768 28.736 35.670964022421174 139.7386236679887 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5a465ee-d08b-4646-bb81-5aa396f51378">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5a465ee-d08b-4646-bb81-5aa396f51378">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5a465ee-d08b-4646-bb81-5aa396f51378">
											<gml:posList>35.67094872174471 139.73844637025223 27.145 35.67094492126938 139.73842770644043 27.145 35.67094245546234 139.7384327243961 27.145 35.67094544153356 139.73844736830463 27.145 35.67094872174471 139.73844637025223 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ec7f9fc-2238-415a-8c44-c8ce7012b33e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ec7f9fc-2238-415a-8c44-c8ce7012b33e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ec7f9fc-2238-415a-8c44-c8ce7012b33e">
											<gml:posList>35.67094442571091 139.73846227101544 31.088 35.67094146487879 139.73846821744803 31.088 35.670947338869084 139.73849878675972 31.088 35.67095215515418 139.73850253681778 31.088 35.67094442571091 139.73846227101544 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-498f07f0-871d-4206-a407-eb9764d4ad58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-498f07f0-871d-4206-a407-eb9764d4ad58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-498f07f0-871d-4206-a407-eb9764d4ad58">
											<gml:posList>35.67096175206057 139.73851053406273 34.977 35.67094109745635 139.7385167113001 34.977 35.67094534536327 139.7385198102972 34.977 35.67096261159998 139.73851464228449 34.977 35.67096175206057 139.73851053406273 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a640f2e-2b98-4329-b90b-eabb2ea7cd10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a640f2e-2b98-4329-b90b-eabb2ea7cd10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a640f2e-2b98-4329-b90b-eabb2ea7cd10">
											<gml:posList>35.67094872174471 139.73844637025223 27.145 35.67094544153356 139.73844736830463 27.145 35.67095764841646 139.73850749012655 27.145 35.67096175206057 139.73851053406273 27.145 35.67094872174471 139.73844637025223 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eb6ba44a-aff3-4a8c-89f5-680b7a2d4136">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb6ba44a-aff3-4a8c-89f5-680b7a2d4136">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb6ba44a-aff3-4a8c-89f5-680b7a2d4136">
											<gml:posList>35.670964022421174 139.7386236679887 34.977 35.670966506185415 139.73861855059928 34.977 35.67094534536327 139.7385198102972 34.977 35.67094109745635 139.7385167113001 34.977 35.670964022421174 139.7386236679887 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-522437b3-d8cf-437e-9ba6-11f400890a37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-522437b3-d8cf-437e-9ba6-11f400890a37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-522437b3-d8cf-437e-9ba6-11f400890a37">
											<gml:posList>35.67096175206057 139.73851053406273 31.088 35.67096333589193 139.7385072514267 31.088 35.670955626287856 139.73846928323323 31.088 35.670952947550404 139.73846717655212 31.088 35.67096175206057 139.73851053406273 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-760fe3b5-d2b1-4255-9586-da0c1307f9db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-760fe3b5-d2b1-4255-9586-da0c1307f9db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-760fe3b5-d2b1-4255-9586-da0c1307f9db">
											<gml:posList>35.670964022421174 139.7386236679887 34.977 35.67092656314103 139.7386947180768 28.736 35.67100901906771 139.73866965600493 28.736 35.67100282964054 139.73863908702972 32.133 35.670997644604256 139.73861344354216 34.977 35.670964022421174 139.7386236679887 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cdc6bbe0-46d5-498c-9876-b868d74d5e1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdc6bbe0-46d5-498c-9876-b868d74d5e1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdc6bbe0-46d5-498c-9876-b868d74d5e1a">
											<gml:posList>35.67096175206057 139.73851053406273 34.977 35.67096261159998 139.73851464228449 34.977 35.670973389296705 139.73851118308 34.977 35.67097590003643 139.7385059883302 34.977 35.67096175206057 139.73851053406273 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72ca80d0-c8ca-49f4-bb22-39da1fe3a895">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72ca80d0-c8ca-49f4-bb22-39da1fe3a895">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72ca80d0-c8ca-49f4-bb22-39da1fe3a895">
											<gml:posList>35.67097590003643 139.7385059883302 31.088 35.67097534815508 139.73850339309274 31.088 35.67096333589193 139.7385072514267 31.088 35.67096175206057 139.73851053406273 31.088 35.67097590003643 139.7385059883302 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d9b4b6c-0355-4a45-9744-b19ac69ad09d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d9b4b6c-0355-4a45-9744-b19ac69ad09d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d9b4b6c-0355-4a45-9744-b19ac69ad09d">
											<gml:posList>35.670966506185415 139.73861855059928 33.714 35.67099345980451 139.73861035550985 33.714 35.670973389296705 139.73851118308 33.714 35.67096261159998 139.73851464228449 33.714 35.67094534536327 139.7385198102972 33.714 35.670966506185415 139.73861855059928 33.714</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8051a9e-68f9-4c98-941b-c5441596e282">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8051a9e-68f9-4c98-941b-c5441596e282">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8051a9e-68f9-4c98-941b-c5441596e282">
											<gml:posList>35.670997644604256 139.73861344354216 34.977 35.67099345980451 139.73861035550985 34.977 35.670966506185415 139.73861855059928 34.977 35.670964022421174 139.7386236679887 34.977 35.670997644604256 139.73861344354216 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c63ae08-5091-4cae-a898-37f2d82e4993">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c63ae08-5091-4cae-a898-37f2d82e4993">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c63ae08-5091-4cae-a898-37f2d82e4993">
											<gml:posList>35.67101967869864 139.73844747928104 27.173 35.67101776032082 139.7384380037856 27.173 35.67099018460151 139.7384459897912 27.173 35.67098783180639 139.73843428345216 27.173 35.67094872174471 139.73844637025223 27.173 35.670952947550404 139.73846717655212 27.173 35.67102052023887 139.73845162066542 27.173 35.67101967869864 139.73844747928104 27.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba09d6a8-224e-40b3-bf52-3ecb33fc5804">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba09d6a8-224e-40b3-bf52-3ecb33fc5804">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba09d6a8-224e-40b3-bf52-3ecb33fc5804">
											<gml:posList>35.67097590003643 139.7385059883302 34.977 35.670973389296705 139.73851118308 34.977 35.67099345980451 139.73861035550985 34.977 35.670997644604256 139.73861344354216 34.977 35.67097590003643 139.7385059883302 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9cf3bda8-52f5-4d80-8dac-00ec5122ebe4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cf3bda8-52f5-4d80-8dac-00ec5122ebe4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cf3bda8-52f5-4d80-8dac-00ec5122ebe4">
											<gml:posList>35.670952947550404 139.73846717655212 31.088 35.670955626287856 139.73846928323323 31.088 35.671018891192475 139.73845471557047 31.088 35.67102052023887 139.73845162066542 31.088 35.670952947550404 139.73846717655212 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-282fea9e-b047-49e3-b4d8-94ed469f5d09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-282fea9e-b047-49e3-b4d8-94ed469f5d09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-282fea9e-b047-49e3-b4d8-94ed469f5d09">
											<gml:posList>35.671018891192475 139.73845471557047 30.751 35.670955626287856 139.73846928323323 30.751 35.67096333589193 139.7385072514267 30.751 35.67097534815508 139.73850339309274 30.751 35.67102552402675 139.73848742700451 30.751 35.671018891192475 139.73845471557047 30.751</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11583e45-e244-4561-afd5-3fe6efc4695c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11583e45-e244-4561-afd5-3fe6efc4695c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11583e45-e244-4561-afd5-3fe6efc4695c">
											<gml:posList>35.671013020196014 139.73866842513632 32.135 35.67098352984388 139.73852275870013 32.135 35.670978524279995 139.73851901990957 32.135 35.67100282964054 139.73863908702972 32.133 35.67100901906771 139.73866965600493 32.135 35.671013020196014 139.73866842513632 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b33f2a4-a5a9-4bba-82d1-17285ea00b30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b33f2a4-a5a9-4bba-82d1-17285ea00b30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b33f2a4-a5a9-4bba-82d1-17285ea00b30">
											<gml:posList>35.67097590003643 139.7385059883302 31.088 35.67102816656971 139.73848935698945 31.088 35.67102552402675 139.73848742700451 31.088 35.67097534815508 139.73850339309274 31.088 35.67097590003643 139.7385059883302 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17364499-4b05-45dd-afb1-8e4e1e87420f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17364499-4b05-45dd-afb1-8e4e1e87420f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17364499-4b05-45dd-afb1-8e4e1e87420f">
											<gml:posList>35.670978524279995 139.73851901990957 32.135 35.67098352984388 139.73852275870013 32.135 35.67103993385145 139.73850634340215 32.135 35.67104295768576 139.73850027537927 32.135 35.670978524279995 139.73851901990957 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f5b4003-2246-400e-b3ce-9b0363177b13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f5b4003-2246-400e-b3ce-9b0363177b13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f5b4003-2246-400e-b3ce-9b0363177b13">
											<gml:posList>35.67102052023887 139.73845162066542 30.524 35.67102260192104 139.7384509996064 30.524 35.67102227616494 139.7384493982715 30.524 35.67101967869864 139.73844747928104 30.524 35.67102052023887 139.73845162066542 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eb3c910d-9eb0-4fb3-a60b-7c0ecfc76f68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb3c910d-9eb0-4fb3-a60b-7c0ecfc76f68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb3c910d-9eb0-4fb3-a60b-7c0ecfc76f68">
											<gml:posList>35.67103993385145 139.73850634340215 30.198 35.67098352984388 139.73852275870013 30.198 35.67100733747414 139.7386403188963 30.198 35.67106359673072 139.73862320792682 30.198 35.67103993385145 139.73850634340215 30.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e7a969e-daa7-4e73-834a-17a2d442323f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e7a969e-daa7-4e73-834a-17a2d442323f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e7a969e-daa7-4e73-834a-17a2d442323f">
											<gml:posList>35.67102052023887 139.73845162066542 31.088 35.671018891192475 139.73845471557047 31.088 35.67102552402675 139.73848742700451 31.088 35.67102816656971 139.73848935698945 31.088 35.67102052023887 139.73845162066542 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b43f09ed-febe-4bd0-8184-19453b7e9fed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b43f09ed-febe-4bd0-8184-19453b7e9fed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b43f09ed-febe-4bd0-8184-19453b7e9fed">
											<gml:posList>35.67102816656971 139.73848935698945 30.524 35.671030248243376 139.73848872488503 30.524 35.67102260192104 139.7384509996064 30.524 35.67102052023887 139.73845162066542 30.524 35.67102816656971 139.73848935698945 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b48e73bb-349e-4cb7-a3f1-30ba6a04596e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b48e73bb-349e-4cb7-a3f1-30ba6a04596e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b48e73bb-349e-4cb7-a3f1-30ba6a04596e">
											<gml:posList>35.67102816656971 139.73848935698945 30.524 35.67103033838908 139.7385001798421 30.524 35.67103191329341 139.73849700767713 30.524 35.671030248243376 139.73848872488503 30.524 35.67102816656971 139.73848935698945 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb48af7d-13ba-47dd-9be2-56dd832b6a47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb48af7d-13ba-47dd-9be2-56dd832b6a47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb48af7d-13ba-47dd-9be2-56dd832b6a47">
											<gml:posList>35.671013020196014 139.73866842513632 28.124 35.671017398884025 139.7386888336157 28.124 35.6710734237994 139.73867173400112 28.124 35.67106359673072 139.73862320792682 28.124 35.67100733747414 139.7386403188963 28.124 35.671013020196014 139.73866842513632 28.124</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd71ecc1-285a-4add-8089-c1504b5433df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd71ecc1-285a-4add-8089-c1504b5433df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd71ecc1-285a-4add-8089-c1504b5433df">
											<gml:posList>35.67101441218462 139.7384214382285 25.281 35.67101556141118 139.73842712573665 25.281 35.67108501343316 139.73840582347364 25.281 35.67108443434303 139.7384030183848 25.281 35.67108389134256 139.73840025743866 25.281 35.67101441218462 139.7384214382285 25.281</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bed8216d-ac83-4ccc-b293-549eeb2d863c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bed8216d-ac83-4ccc-b293-549eeb2d863c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bed8216d-ac83-4ccc-b293-549eeb2d863c">
											<gml:posList>35.67101967869864 139.73844747928104 26.705 35.67108916677037 139.7384261659455 26.705 35.67108501343316 139.73840582347364 26.705 35.67101556141118 139.73842712573665 26.705 35.67101776032082 139.7384380037856 26.705 35.67101967869864 139.73844747928104 26.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b2da31b-856d-4da1-b4ba-b02b789d07ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b2da31b-856d-4da1-b4ba-b02b789d07ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b2da31b-856d-4da1-b4ba-b02b789d07ba">
											<gml:posList>35.67101967869864 139.73844747928104 30.524 35.67102227616494 139.7384493982715 30.524 35.67108760990408 139.73842934913918 30.524 35.67108916677037 139.7384261659455 30.524 35.67101967869864 139.73844747928104 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9dcecf3b-b2aa-439e-9138-117715b45948">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dcecf3b-b2aa-439e-9138-117715b45948">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dcecf3b-b2aa-439e-9138-117715b45948">
											<gml:posList>35.67104295768576 139.73850027537927 32.135 35.67103993385145 139.73850634340215 32.135 35.6710734237994 139.73867173400112 32.135 35.67107842932375 139.73867542862027 32.135 35.67104295768576 139.73850027537927 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-280fb528-b2a1-4c90-9bf6-21e2777acf9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-280fb528-b2a1-4c90-9bf6-21e2777acf9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-280fb528-b2a1-4c90-9bf6-21e2777acf9a">
											<gml:posList>35.671030248243376 139.73848872488503 30.29 35.67103191329341 139.73849700767713 30.29 35.67109733727336 139.73847707998434 30.29 35.6710970114654 139.73847541236975 30.29 35.67108760990408 139.73842934913918 30.29 35.67102227616494 139.7384493982715 30.29 35.67102260192104 139.7384509996064 30.29 35.671030248243376 139.73848872488503 30.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f07c9034-4fb3-4c7a-bc36-4f3a31c83e68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f07c9034-4fb3-4c7a-bc36-4f3a31c83e68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f07c9034-4fb3-4c7a-bc36-4f3a31c83e68">
											<gml:posList>35.67109990769798 139.73847899900957 30.524 35.67109733727336 139.73847707998434 30.524 35.67103191329341 139.73849700767713 30.524 35.67103033838908 139.7385001798421 30.524 35.67109990769798 139.73847899900957 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-395adecc-760d-46b7-ba5c-99c406053259">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-395adecc-760d-46b7-ba5c-99c406053259">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-395adecc-760d-46b7-ba5c-99c406053259">
											<gml:posList>35.67107014045282 139.73822264834376 26.909 35.67106094881309 139.73822564176294 26.909 35.6710733429671 139.73828306810498 26.909 35.67108154336053 139.7382804072578 26.909 35.67107014045282 139.73822264834376 26.909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de8f3628-520d-4e44-9b07-eb9c2a930279">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de8f3628-520d-4e44-9b07-eb9c2a930279">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de8f3628-520d-4e44-9b07-eb9c2a930279">
											<gml:posList>35.67107330679078 139.7382144260997 29.344 35.67106869293486 139.73821591178492 29.344 35.67107014045282 139.73822264834376 29.344 35.67108154336053 139.7382804072578 29.344 35.67108796646832 139.73831000387884 29.344 35.67109364367423 139.73830817450127 29.344 35.67107330679078 139.7382144260997 29.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0dc3d529-ee19-4354-963d-eb5878b43116">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dc3d529-ee19-4354-963d-eb5878b43116">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dc3d529-ee19-4354-963d-eb5878b43116">
											<gml:posList>35.67107330679078 139.7382144260997 29.344 35.67109364367423 139.73830817450127 29.344 35.67109592353545 139.7383073985541 30.701 35.67107562269754 139.73821363906094 30.701 35.67107330679078 139.7382144260997 29.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3842d76a-8556-4b3d-b473-a3d9e522e227">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3842d76a-8556-4b3d-b473-a3d9e522e227">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3842d76a-8556-4b3d-b473-a3d9e522e227">
											<gml:posList>35.67109560848327 139.73839935985617 32.058 35.67108443434303 139.7384030183848 32.058 35.67108823127063 139.7384057423392 32.058 35.67109645868181 139.738403048333 32.058 35.67109560848327 139.73839935985617 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3dce6fa3-ecc4-41a9-83a5-be68b59b7370">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dce6fa3-ecc4-41a9-83a5-be68b59b7370">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dce6fa3-ecc4-41a9-83a5-be68b59b7370">
											<gml:posList>35.67110625965821 139.7383040723957 32.058 35.67108601288261 139.7382102907344 32.058 35.67107562269754 139.73821363906094 30.701 35.67109592353545 139.7383073985541 30.701 35.67110625965821 139.7383040723957 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-448315c6-81c3-4c16-8c87-2549bfcb57bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-448315c6-81c3-4c16-8c87-2549bfcb57bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-448315c6-81c3-4c16-8c87-2549bfcb57bd">
											<gml:posList>35.671099093156364 139.7384748023571 32.058 35.67110137897784 139.73847014913568 32.058 35.67108823127063 139.7384057423392 32.058 35.67108443434303 139.7384030183848 32.058 35.671099093156364 139.7384748023571 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0271b615-0954-40c4-94bc-b7c74e6d9a1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0271b615-0954-40c4-94bc-b7c74e6d9a1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0271b615-0954-40c4-94bc-b7c74e6d9a1e">
											<gml:posList>35.67109560848327 139.73839935985617 29.423 35.671098038016225 139.73839406577383 29.423 35.67109205819575 139.73836649010062 29.423 35.67108782837342 139.73836346840903 29.423 35.67109560848327 139.73839935985617 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3ca698e-66da-45b4-9375-592fed8d6d6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3ca698e-66da-45b4-9375-592fed8d6d6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3ca698e-66da-45b4-9375-592fed8d6d6b">
											<gml:posList>35.671099093156364 139.7384748023571 30.524 35.67108916677037 139.7384261659455 30.524 35.67108760990408 139.73842934913918 30.524 35.6710970114654 139.73847541236975 30.524 35.671099093156364 139.7384748023571 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08ae6f98-95fc-49bb-a48c-c53b125e30db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08ae6f98-95fc-49bb-a48c-c53b125e30db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08ae6f98-95fc-49bb-a48c-c53b125e30db">
											<gml:posList>35.67110625965821 139.7383040723957 32.058 35.671107200476335 139.73830836831436 32.058 35.67110891022398 139.73830474308198 32.058 35.67108896204484 139.73821240813595 32.058 35.67108601288261 139.7382102907344 32.058 35.67110625965821 139.7383040723957 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6dbdf25d-cb41-417b-a7db-5785e14cca06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dbdf25d-cb41-417b-a7db-5785e14cca06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dbdf25d-cb41-417b-a7db-5785e14cca06">
											<gml:posList>35.671099093156364 139.7384748023571 30.524 35.6710970114654 139.73847541236975 30.524 35.67109733727336 139.73847707998434 30.524 35.67109990769798 139.73847899900957 30.524 35.671099093156364 139.7384748023571 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-738ce39a-1aa3-494f-bf0f-4c5af167b444">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-738ce39a-1aa3-494f-bf0f-4c5af167b444">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-738ce39a-1aa3-494f-bf0f-4c5af167b444">
											<gml:posList>35.67108782837342 139.73836346840903 29.423 35.67109205819575 139.73836649010062 29.423 35.67111457774324 139.73835918387496 29.423 35.671117052421444 139.73835398915395 29.423 35.67108782837342 139.73836346840903 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-30580ed8-9164-4a0c-8d7c-711c0fda96e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30580ed8-9164-4a0c-8d7c-711c0fda96e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30580ed8-9164-4a0c-8d7c-711c0fda96e3">
											<gml:posList>35.67108601288261 139.7382102907344 32.058 35.67108896204484 139.73821240813595 32.058 35.67111959185481 139.7382024632105 32.058 35.6711213196267 139.73819883795395 32.058 35.67108601288261 139.7382102907344 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b60357bc-32df-4661-8263-2bb866b68c2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b60357bc-32df-4661-8263-2bb866b68c2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b60357bc-32df-4661-8263-2bb866b68c2b">
											<gml:posList>35.67111216362877 139.7383725970158 28.921 35.671115609062525 139.73836394363468 28.921 35.67111457774324 139.73835918387496 28.921 35.67109205819575 139.73836649010062 28.921 35.671098038016225 139.73839406577383 28.921 35.67111238385368 139.73838896746065 28.921 35.67111144217609 139.7383835779521 28.921 35.67111216362877 139.7383725970158 28.921</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d89352ed-5297-4968-8416-99e1fd649e3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d89352ed-5297-4968-8416-99e1fd649e3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d89352ed-5297-4968-8416-99e1fd649e3f">
											<gml:posList>35.671116460415966 139.7383919561969 29.423 35.67111238385368 139.73838896746065 29.423 35.671098038016225 139.73839406577383 29.423 35.67109560848327 139.73839935985617 29.423 35.671116460415966 139.7383919561969 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b8472ae-3fc9-435e-a112-0abb687a1e88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b8472ae-3fc9-435e-a112-0abb687a1e88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b8472ae-3fc9-435e-a112-0abb687a1e88">
											<gml:posList>35.671116460415966 139.7383919561969 32.058 35.67109560848327 139.73839935985617 32.058 35.67109645868181 139.738403048333 32.058 35.67112014013059 139.73839463610523 32.058 35.671116460415966 139.7383919561969 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab37c212-e659-49a8-9e9d-f9892fe425d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab37c212-e659-49a8-9e9d-f9892fe425d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab37c212-e659-49a8-9e9d-f9892fe425d6">
											<gml:posList>35.67111557171261 139.73837373075435 29.423 35.67111216362877 139.7383725970158 29.423 35.67111144217609 139.7383835779521 29.423 35.671114948304535 139.73838330868725 29.423 35.67111557171261 139.73837373075435 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c160d8e9-dee8-4ebd-8597-bf180b91b407">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c160d8e9-dee8-4ebd-8597-bf180b91b407">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c160d8e9-dee8-4ebd-8597-bf180b91b407">
											<gml:posList>35.671114948304535 139.73838330868725 29.423 35.67111144217609 139.7383835779521 29.423 35.67111238385368 139.73838896746065 29.423 35.671116460415966 139.7383919561969 29.423 35.671114948304535 139.73838330868725 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc09b0af-02d8-4949-a1ea-e8f2b08490a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc09b0af-02d8-4949-a1ea-e8f2b08490a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc09b0af-02d8-4949-a1ea-e8f2b08490a6">
											<gml:posList>35.67112492354369 139.7382995764974 31.681 35.67113953102781 139.7382947982 31.681 35.67111959185481 139.7382024632105 31.681 35.67108896204484 139.73821240813595 31.681 35.67110891022398 139.73830474308198 31.681 35.67112492354369 139.7382995764974 31.681</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2e321eba-fbd3-4f9b-b43e-d8240be141cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e321eba-fbd3-4f9b-b43e-d8240be141cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e321eba-fbd3-4f9b-b43e-d8240be141cc">
											<gml:posList>35.67111557171261 139.73837373075435 29.423 35.67111929601422 139.7383643700755 29.423 35.671115609062525 139.73836394363468 29.423 35.67111216362877 139.7383725970158 29.423 35.67111557171261 139.73837373075435 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0eb8bb86-02ba-489a-8184-588328df4e62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0eb8bb86-02ba-489a-8184-588328df4e62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0eb8bb86-02ba-489a-8184-588328df4e62">
											<gml:posList>35.671125547757136 139.73830244781163 32.058 35.67112492354369 139.7382995764974 32.058 35.67110891022398 139.73830474308198 32.058 35.671107200476335 139.73830836831436 32.058 35.671125547757136 139.73830244781163 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26193ca5-1262-432e-81e6-68ef1d97923f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26193ca5-1262-432e-81e6-68ef1d97923f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26193ca5-1262-432e-81e6-68ef1d97923f">
											<gml:posList>35.671114948304535 139.73838330868725 32.058 35.67111811190286 139.73838302878164 32.058 35.67111865522407 139.73837476546018 32.058 35.67111557171261 139.73837373075435 32.058 35.671114948304535 139.73838330868725 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6dd77979-33b2-43a7-920d-b2c6c919021f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dd77979-33b2-43a7-920d-b2c6c919021f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dd77979-33b2-43a7-920d-b2c6c919021f">
											<gml:posList>35.67111929601422 139.7383643700755 29.423 35.671117052421444 139.73835398915395 29.423 35.67111457774324 139.73835918387496 29.423 35.671115609062525 139.73836394363468 29.423 35.67111929601422 139.7383643700755 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9bbab5b-5cb2-44d3-93c6-445393f2eb46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9bbab5b-5cb2-44d3-93c6-445393f2eb46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9bbab5b-5cb2-44d3-93c6-445393f2eb46">
											<gml:posList>35.671116460415966 139.7383919561969 32.058 35.67112014013059 139.73839463610523 32.058 35.67111811190286 139.73838302878164 32.058 35.671114948304535 139.73838330868725 32.058 35.671116460415966 139.7383919561969 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43bb25a6-a257-4fea-b369-a904f5abcd78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43bb25a6-a257-4fea-b369-a904f5abcd78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43bb25a6-a257-4fea-b369-a904f5abcd78">
											<gml:posList>35.67111929601422 139.7383643700755 32.058 35.67111557171261 139.73837373075435 32.058 35.67111865522407 139.73837476546018 32.058 35.67112263140464 139.73836476379367 32.058 35.67111929601422 139.7383643700755 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad1eb3b6-ae02-4d89-b098-ff3fd9cf79b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad1eb3b6-ae02-4d89-b098-ff3fd9cf79b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad1eb3b6-ae02-4d89-b098-ff3fd9cf79b8">
											<gml:posList>35.67111929601422 139.7383643700755 32.058 35.67112263140464 139.73836476379367 32.058 35.67112047826277 139.73835478043353 32.058 35.67111663626543 139.7383520565338 32.058 35.67111929601422 139.7383643700755 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a716bebe-7e6a-4c3d-902b-ce7d7ed89406">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a716bebe-7e6a-4c3d-902b-ce7d7ed89406">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a716bebe-7e6a-4c3d-902b-ce7d7ed89406">
											<gml:posList>35.671125547757136 139.73830244781163 31.447 35.671107200476335 139.73830836831436 31.447 35.67111663626543 139.7383520565338 31.447 35.67113495645493 139.73834606979432 31.447 35.671125547757136 139.73830244781163 31.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad57d842-585a-4192-8183-7905cee2e0a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad57d842-585a-4192-8183-7905cee2e0a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad57d842-585a-4192-8183-7905cee2e0a8">
											<gml:posList>35.67112431927307 139.7383791110183 36.412 35.671126500375784 139.73837883227608 36.412 35.67112665095217 139.73837546295732 36.412 35.671124514142754 139.73837475852096 36.412 35.67112431927307 139.7383791110183 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3052316d-85eb-4b8b-a437-99df9ec0f828">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3052316d-85eb-4b8b-a437-99df9ec0f828">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3052316d-85eb-4b8b-a437-99df9ec0f828">
											<gml:posList>35.671126070432635 139.73837084626555 36.412 35.671124514142754 139.73837475852096 36.412 35.67112665095217 139.73837546295732 36.412 35.67112788338405 139.73837235746984 36.412 35.671126070432635 139.73837084626555 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cae6c7d5-a849-4a0b-8dac-6e54ce7119fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cae6c7d5-a849-4a0b-8dac-6e54ce7119fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cae6c7d5-a849-4a0b-8dac-6e54ce7119fc">
											<gml:posList>35.67113495645493 139.73834606979432 32.058 35.67111663626543 139.7383520565338 32.058 35.67112047826277 139.73835478043353 32.058 35.67113576160392 139.73834978041847 32.058 35.67113495645493 139.73834606979432 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-70c1833f-103a-452f-8ef2-8d540e57aa46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70c1833f-103a-452f-8ef2-8d540e57aa46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70c1833f-103a-452f-8ef2-8d540e57aa46">
											<gml:posList>35.67114050148203 139.73840522755034 31.793 35.67113979584274 139.7384019697085 31.793 35.67112992832631 139.73840516274453 31.793 35.67112431927307 139.7383791110183 31.793 35.671124514142754 139.73837475852096 31.793 35.671126070432635 139.73837084626555 31.793 35.67112851947281 139.73836743003886 31.793 35.67113208708551 139.73836511712327 31.793 35.67114764982626 139.73836008363938 31.793 35.67114480008309 139.7383468755631 31.793 35.67113576160392 139.73834978041847 31.793 35.67112047826277 139.73835478043353 31.793 35.67112263140464 139.73836476379367 31.793 35.67111865522407 139.73837476546018 31.793 35.67111811190286 139.73838302878164 31.793 35.67112014013059 139.73839463610523 31.793 35.67109645868181 139.738403048333 31.793 35.67108823127063 139.7384057423392 31.793 35.67110137897784 139.73847014913568 31.793 35.67116707339898 139.73845026526902 31.793 35.671157981333835 139.7384080568166 31.793 35.67114985302131 139.73841068442889 31.793 35.671146635358035 139.73841098649024 31.793 35.6711445975169 139.73841004996194 31.793 35.67114224346403 139.73840818591344 31.793 35.67114050148203 139.73840522755034 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-624eec7b-d747-4eb4-a280-2cf9d4ac7089">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-624eec7b-d747-4eb4-a280-2cf9d4ac7089">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-624eec7b-d747-4eb4-a280-2cf9d4ac7089">
											<gml:posList>35.67112431927307 139.7383791110183 36.412 35.67112992832631 139.73840516274453 36.412 35.67113147612597 139.73840191328125 36.412 35.671126500375784 139.73837883227608 36.412 35.67112431927307 139.7383791110183 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2adf3dd7-3b16-46a1-90da-6248cc29d5ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2adf3dd7-3b16-46a1-90da-6248cc29d5ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2adf3dd7-3b16-46a1-90da-6248cc29d5ce">
											<gml:posList>35.671126070432635 139.73837084626555 36.412 35.67112788338405 139.73837235746984 36.412 35.671129891239794 139.738369560362 36.412 35.67112851947281 139.73836743003886 36.412 35.671126070432635 139.73837084626555 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a547f394-1126-464c-bbb1-b4be613efccf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a547f394-1126-464c-bbb1-b4be613efccf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a547f394-1126-464c-bbb1-b4be613efccf">
											<gml:posList>35.67113208708551 139.73836511712327 36.412 35.67112851947281 139.73836743003886 36.412 35.671129891239794 139.738369560362 36.412 35.67113287325687 139.73836762371644 36.412 35.67113208708551 139.73836511712327 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2db1e845-5a73-40ed-a1eb-8a23b4b4a840">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2db1e845-5a73-40ed-a1eb-8a23b4b4a840">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2db1e845-5a73-40ed-a1eb-8a23b4b4a840">
											<gml:posList>35.6711213196267 139.73819883795395 32.058 35.67111959185481 139.7382024632105 32.058 35.67113953102781 139.7382947982 32.058 35.67114248919354 139.738296904549 32.058 35.6711213196267 139.73819883795395 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60ac8900-7437-4781-a9ae-b2b1572e7213">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60ac8900-7437-4781-a9ae-b2b1572e7213">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60ac8900-7437-4781-a9ae-b2b1572e7213">
											<gml:posList>35.671125547757136 139.73830244781163 32.058 35.67114248919354 139.738296904549 32.058 35.67113953102781 139.7382947982 32.058 35.67112492354369 139.7382995764974 32.058 35.671125547757136 139.73830244781163 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d7f2e8a-c9a7-47ec-ae09-a5138dedc67f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d7f2e8a-c9a7-47ec-ae09-a5138dedc67f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d7f2e8a-c9a7-47ec-ae09-a5138dedc67f">
											<gml:posList>35.671170915455 139.73845306649966 32.058 35.67116707339898 139.73845026526902 32.058 35.67110137897784 139.73847014913568 32.058 35.671099093156364 139.7384748023571 32.058 35.671170915455 139.73845306649966 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93f7751c-7583-49b4-b134-2ca7f28de319">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93f7751c-7583-49b4-b134-2ca7f28de319">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93f7751c-7583-49b4-b134-2ca7f28de319">
											<gml:posList>35.67113979584274 139.7384019697085 36.412 35.671141325614876 139.73839872026613 36.412 35.67113147612597 139.73840191328125 36.412 35.67112992832631 139.73840516274453 36.412 35.67113979584274 139.7384019697085 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-731b43b0-0bfb-4627-8f7e-ec2199e1b287">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-731b43b0-0bfb-4627-8f7e-ec2199e1b287">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-731b43b0-0bfb-4627-8f7e-ec2199e1b287">
											<gml:posList>35.67113495645493 139.73834606979432 32.058 35.67113576160392 139.73834978041847 32.058 35.67114480008309 139.7383468755631 32.058 35.671147031791136 139.7383421892604 32.058 35.67113495645493 139.73834606979432 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48c6d626-912e-4294-8c8c-c2d2e52edd40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48c6d626-912e-4294-8c8c-c2d2e52edd40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48c6d626-912e-4294-8c8c-c2d2e52edd40">
											<gml:posList>35.67113979584274 139.7384019697085 36.412 35.67114050148203 139.73840522755034 36.412 35.671142492608695 139.73840407637095 36.412 35.671141325614876 139.73839872026613 36.412 35.67113979584274 139.7384019697085 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e876146-4566-454a-8f95-c83c5b3a9dab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e876146-4566-454a-8f95-c83c5b3a9dab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e876146-4566-454a-8f95-c83c5b3a9dab">
											<gml:posList>35.67113208708551 139.73836511712327 36.412 35.67113287325687 139.73836762371644 36.412 35.671149120866275 139.73836236849442 36.412 35.6711506776698 139.73835910797257 36.412 35.67113208708551 139.73836511712327 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a14ba138-f612-41af-a605-67b483e01269">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a14ba138-f612-41af-a605-67b483e01269">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a14ba138-f612-41af-a605-67b483e01269">
											<gml:posList>35.67114224346403 139.73840818591344 36.412 35.67114375621909 139.7384062178695 36.412 35.671142492608695 139.73840407637095 36.412 35.67114050148203 139.73840522755034 36.412 35.67114224346403 139.73840818591344 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b620706-5876-4612-84f1-6703cdec2b70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b620706-5876-4612-84f1-6703cdec2b70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b620706-5876-4612-84f1-6703cdec2b70">
											<gml:posList>35.671141325614876 139.73839872026613 36.126 35.671142492608695 139.73840407637095 36.126 35.67114375621909 139.7384062178695 36.126 35.67114558715395 139.73840767382185 36.126 35.67114693969976 139.7384082908169 36.126 35.6711494723725 139.73840805584462 36.126 35.67115834863221 139.73840518432647 36.126 35.671149120866275 139.73836236849442 36.126 35.67113287325687 139.73836762371644 36.126 35.671129891239794 139.738369560362 36.126 35.67112788338405 139.73837235746984 36.126 35.67112665095217 139.73837546295732 36.126 35.671126500375784 139.73837883227608 36.126 35.67113147612597 139.73840191328125 36.126 35.671141325614876 139.73839872026613 36.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32c0983d-0c07-4278-bfd4-1f47597c807a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32c0983d-0c07-4278-bfd4-1f47597c807a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32c0983d-0c07-4278-bfd4-1f47597c807a">
											<gml:posList>35.6711445975169 139.73841004996194 36.412 35.67114558715395 139.73840767382185 36.412 35.67114375621909 139.7384062178695 36.412 35.67114224346403 139.73840818591344 36.412 35.6711445975169 139.73841004996194 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3c110b6d-83dc-48e2-a4d8-3aae6acd798f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c110b6d-83dc-48e2-a4d8-3aae6acd798f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c110b6d-83dc-48e2-a4d8-3aae6acd798f">
											<gml:posList>35.6711445975169 139.73841004996194 36.412 35.671146635358035 139.73841098649024 36.412 35.67114693969976 139.7384082908169 36.412 35.67114558715395 139.73840767382185 36.412 35.6711445975169 139.73841004996194 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35e4dc75-f54f-48e7-8d3d-b78c0dc077ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35e4dc75-f54f-48e7-8d3d-b78c0dc077ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35e4dc75-f54f-48e7-8d3d-b78c0dc077ff">
											<gml:posList>35.6711506776698 139.73835910797257 32.058 35.671147031791136 139.7383421892604 32.058 35.67114480008309 139.7383468755631 32.058 35.67114764982626 139.73836008363938 32.058 35.6711506776698 139.73835910797257 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-157cabc0-62ab-478c-948a-c225b86bda1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-157cabc0-62ab-478c-948a-c225b86bda1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-157cabc0-62ab-478c-948a-c225b86bda1a">
											<gml:posList>35.67114985302131 139.73841068442889 36.412 35.6711494723725 139.73840805584462 36.412 35.67114693969976 139.7384082908169 36.412 35.671146635358035 139.73841098649024 36.412 35.67114985302131 139.73841068442889 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72dea51d-37b4-4545-a7bc-4f6696191645">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72dea51d-37b4-4545-a7bc-4f6696191645">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72dea51d-37b4-4545-a7bc-4f6696191645">
											<gml:posList>35.6711506776698 139.73835910797257 36.412 35.671149120866275 139.73836236849442 36.412 35.67115834863221 139.73840518432647 36.412 35.67116100917776 139.73840708115145 36.412 35.6711506776698 139.73835910797257 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f446c99-579b-49e0-9e58-3f3ee761d29a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f446c99-579b-49e0-9e58-3f3ee761d29a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f446c99-579b-49e0-9e58-3f3ee761d29a">
											<gml:posList>35.67114985302131 139.73841068442889 36.412 35.67116100917776 139.73840708115145 36.412 35.67115834863221 139.73840518432647 36.412 35.6711494723725 139.73840805584462 36.412 35.67114985302131 139.73841068442889 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11b5d322-5781-4d36-866b-5c3d124a475a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11b5d322-5781-4d36-866b-5c3d124a475a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11b5d322-5781-4d36-866b-5c3d124a475a">
											<gml:posList>35.67116100917776 139.73840708115145 32.058 35.671157981333835 139.7384080568166 32.058 35.67116707339898 139.73845026526902 32.058 35.671170915455 139.73845306649966 32.058 35.67116100917776 139.73840708115145 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7b22550-c34c-4e06-8f6b-3f2f073eddf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7b22550-c34c-4e06-8f6b-3f2f073eddf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7b22550-c34c-4e06-8f6b-3f2f073eddf4">
											<gml:posList>35.67100901906771 139.73866965600493 32.135 35.6710144471847 139.73869494572975 32.135 35.671017398884025 139.7386888336157 32.135 35.671013020196014 139.73866842513632 32.135 35.67100901906771 139.73866965600493 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9bb635cf-667a-4309-a6ec-27d8beb9b742">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bb635cf-667a-4309-a6ec-27d8beb9b742">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bb635cf-667a-4309-a6ec-27d8beb9b742">
											<gml:posList>35.67107842932375 139.73867542862027 32.135 35.6710734237994 139.73867173400112 32.135 35.671017398884025 139.7386888336157 32.135 35.6710144471847 139.73869494572975 32.135 35.67107842932375 139.73867542862027 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e15192ef-ab0f-4124-842e-37f03adfd99b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e15192ef-ab0f-4124-842e-37f03adfd99b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e15192ef-ab0f-4124-842e-37f03adfd99b">
											<gml:posList>35.671115609062525 139.73836394363468 29.423 35.671115609062525 139.73836394363468 28.921 35.67111216362877 139.7383725970158 28.921 35.67111216362877 139.7383725970158 29.423 35.671115609062525 139.73836394363468 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6c4813d-5d38-409e-9684-2f352eec6e66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6c4813d-5d38-409e-9684-2f352eec6e66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6c4813d-5d38-409e-9684-2f352eec6e66">
											<gml:posList>35.67114375621909 139.7384062178695 36.412 35.67114375621909 139.7384062178695 36.126 35.671142492608695 139.73840407637095 36.126 35.671142492608695 139.73840407637095 36.412 35.67114375621909 139.7384062178695 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12d33760-6523-4f4a-ba90-abf643ae808f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12d33760-6523-4f4a-ba90-abf643ae808f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12d33760-6523-4f4a-ba90-abf643ae808f">
											<gml:posList>35.67114558715395 139.73840767382185 36.412 35.67114558715395 139.73840767382185 36.126 35.67114375621909 139.7384062178695 36.126 35.67114375621909 139.7384062178695 36.412 35.67114558715395 139.73840767382185 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60912dd1-ab5e-42ef-8cdd-282fc408ed6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60912dd1-ab5e-42ef-8cdd-282fc408ed6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60912dd1-ab5e-42ef-8cdd-282fc408ed6f">
											<gml:posList>35.67114693969976 139.7384082908169 36.412 35.67114693969976 139.7384082908169 36.126 35.67114558715395 139.73840767382185 36.126 35.67114558715395 139.73840767382185 36.412 35.67114693969976 139.7384082908169 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aef03a9f-971a-4745-82cf-ff75cef2a21e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aef03a9f-971a-4745-82cf-ff75cef2a21e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aef03a9f-971a-4745-82cf-ff75cef2a21e">
											<gml:posList>35.6710970114654 139.73847541236975 30.524 35.6710970114654 139.73847541236975 30.29 35.67109733727336 139.73847707998434 30.29 35.67109733727336 139.73847707998434 30.524 35.6710970114654 139.73847541236975 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b85bcea-a2c6-4e07-b4f6-ef82f6508bf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b85bcea-a2c6-4e07-b4f6-ef82f6508bf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b85bcea-a2c6-4e07-b4f6-ef82f6508bf0">
											<gml:posList>35.67088542687921 139.738480114371 27.145 35.67088542687921 139.738480114371 26.815 35.67087972592923 139.73845180937676 26.815 35.67087972592923 139.73845180937676 27.145 35.67088542687921 139.738480114371 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95939089-db32-4f59-bd02-e5384ff72dca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95939089-db32-4f59-bd02-e5384ff72dca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95939089-db32-4f59-bd02-e5384ff72dca">
											<gml:posList>35.670889729745525 139.73851866097021 27.145 35.670889729745525 139.73851866097021 31.088 35.67088214666775 139.73848111242125 31.088 35.67088214666775 139.73848111242125 27.145 35.67087562229229 139.738448776493 27.145 35.67087562229229 139.738448776493 15.2 35.67089227253375 139.7385312728718 15.2 35.67089227253375 139.7385312728718 27.145 35.670889729745525 139.73851866097021 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d80220a-af2a-4a1e-be33-cb24401ef815">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d80220a-af2a-4a1e-be33-cb24401ef815">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d80220a-af2a-4a1e-be33-cb24401ef815">
											<gml:posList>35.67089269072805 139.73851290233074 31.088 35.67089269072805 139.73851290233074 30.872 35.67088698985538 139.73848468570213 30.872 35.67088698985538 139.73848468570213 31.088 35.67089269072805 139.73851290233074 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f94d556b-5e4b-400f-a87d-355b27379dd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f94d556b-5e4b-400f-a87d-355b27379dd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f94d556b-5e4b-400f-a87d-355b27379dd5">
											<gml:posList>35.67089227253375 139.7385312728718 15.2 35.67089344405663 139.73853094009664 15.2 35.67089344405663 139.73853094009664 27.145 35.67089227253375 139.7385312728718 27.145 35.67089227253375 139.7385312728718 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6009a785-2e69-44a4-a6f0-a59a0fb209f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6009a785-2e69-44a4-a6f0-a59a0fb209f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6009a785-2e69-44a4-a6f0-a59a0fb209f0">
											<gml:posList>35.67089475639846 139.7385262880399 27.145 35.67089475639846 139.7385262880399 26.815 35.67089316327753 139.73851777320337 26.815 35.67089316327753 139.73851777320337 27.145 35.67089475639846 139.7385262880399 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6432c56-b84a-45bc-852d-d6116627670b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6432c56-b84a-45bc-852d-d6116627670b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6432c56-b84a-45bc-852d-d6116627670b">
											<gml:posList>35.67092656314103 139.7386947180768 28.736 35.67089344405663 139.73853094009664 28.736 35.67089344405663 139.73853094009664 27.145 35.67089344405663 139.73853094009664 15.2 35.67092656314103 139.7386947180768 15.2 35.67092656314103 139.7386947180768 28.736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ca571fc-ea9a-4538-8b92-d40d6f8f30f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ca571fc-ea9a-4538-8b92-d40d6f8f30f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ca571fc-ea9a-4538-8b92-d40d6f8f30f0">
											<gml:posList>35.67094492126938 139.73842770644043 15.2 35.67087562229229 139.738448776493 15.2 35.67087562229229 139.738448776493 27.145 35.67094492126938 139.73842770644043 27.145 35.67094492126938 139.73842770644043 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cf1b72e-f8d7-48e2-b61a-23e0c44e8105">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cf1b72e-f8d7-48e2-b61a-23e0c44e8105">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cf1b72e-f8d7-48e2-b61a-23e0c44e8105">
											<gml:posList>35.67087972592923 139.73845180937676 27.145 35.67087972592923 139.73845180937676 26.815 35.67094245546234 139.7384327243961 26.815 35.67094245546234 139.7384327243961 27.145 35.67087972592923 139.73845180937676 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95b6e70d-508c-423a-96f2-56069abc56cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95b6e70d-508c-423a-96f2-56069abc56cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95b6e70d-508c-423a-96f2-56069abc56cc">
											<gml:posList>35.67088542687921 139.738480114371 27.145 35.67088214666775 139.73848111242125 27.145 35.67088214666775 139.73848111242125 31.088 35.67094442571091 139.73846227101544 31.088 35.67094442571091 139.73846227101544 26.815 35.67088542687921 139.738480114371 26.815 35.67088542687921 139.738480114371 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73bea7ae-788c-4b48-8d1f-217e7359bcc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73bea7ae-788c-4b48-8d1f-217e7359bcc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73bea7ae-788c-4b48-8d1f-217e7359bcc4">
											<gml:posList>35.67088698985538 139.73848468570213 31.088 35.67088698985538 139.73848468570213 30.872 35.67094146487879 139.73846821744803 30.872 35.67094146487879 139.73846821744803 31.088 35.67088698985538 139.73848468570213 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f73a7fa-9473-4d5a-98bc-1b6a676dd34a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f73a7fa-9473-4d5a-98bc-1b6a676dd34a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f73a7fa-9473-4d5a-98bc-1b6a676dd34a">
											<gml:posList>35.670947338869084 139.73849878675972 31.088 35.670947338869084 139.73849878675972 30.872 35.67089269072805 139.73851290233074 30.872 35.67089269072805 139.73851290233074 31.088 35.670947338869084 139.73849878675972 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09d57b09-22c1-417f-8137-a47e3ab14714">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09d57b09-22c1-417f-8137-a47e3ab14714">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09d57b09-22c1-417f-8137-a47e3ab14714">
											<gml:posList>35.670889729745525 139.73851866097021 31.088 35.670889729745525 139.73851866097021 27.145 35.67089316327753 139.73851777320337 27.145 35.67089316327753 139.73851777320337 26.815 35.67095215515418 139.73850253681778 26.815 35.67095215515418 139.73850253681778 31.088 35.670889729745525 139.73851866097021 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebf73332-296d-4f89-8b43-ec52758a05d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebf73332-296d-4f89-8b43-ec52758a05d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebf73332-296d-4f89-8b43-ec52758a05d6">
											<gml:posList>35.67095764841646 139.73850749012655 27.145 35.67095764841646 139.73850749012655 26.815 35.67089475639846 139.7385262880399 26.815 35.67089475639846 139.7385262880399 27.145 35.67095764841646 139.73850749012655 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c21abf33-2c31-4e5c-9b74-00bd6a243d4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c21abf33-2c31-4e5c-9b74-00bd6a243d4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c21abf33-2c31-4e5c-9b74-00bd6a243d4b">
											<gml:posList>35.67089344405663 139.73853094009664 28.736 35.67094109745635 139.7385167113001 34.977 35.67096175206057 139.73851053406273 34.977 35.67096175206057 139.73851053406273 31.088 35.67096175206057 139.73851053406273 27.145 35.67089344405663 139.73853094009664 27.145 35.67089344405663 139.73853094009664 28.736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b155a43-5cea-49a5-b3f4-e93ff608c7f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b155a43-5cea-49a5-b3f4-e93ff608c7f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b155a43-5cea-49a5-b3f4-e93ff608c7f4">
											<gml:posList>35.67094245546234 139.7384327243961 27.145 35.67094245546234 139.7384327243961 26.815 35.67094544153356 139.73844736830463 26.815 35.67094544153356 139.73844736830463 27.145 35.67094245546234 139.7384327243961 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70ffa5d2-7513-44ff-bb53-ac28350894f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70ffa5d2-7513-44ff-bb53-ac28350894f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70ffa5d2-7513-44ff-bb53-ac28350894f8">
											<gml:posList>35.67094146487879 139.73846821744803 31.088 35.67094146487879 139.73846821744803 30.872 35.670947338869084 139.73849878675972 30.872 35.670947338869084 139.73849878675972 31.088 35.67094146487879 139.73846821744803 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6a61bbc-d9f7-4156-b71c-bae3eb1c256d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6a61bbc-d9f7-4156-b71c-bae3eb1c256d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6a61bbc-d9f7-4156-b71c-bae3eb1c256d">
											<gml:posList>35.67094872174471 139.73844637025223 15.2 35.67094492126938 139.73842770644043 15.2 35.67094492126938 139.73842770644043 27.145 35.67094872174471 139.73844637025223 27.145 35.67094872174471 139.73844637025223 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c6b353c-a337-4802-9306-bf4c698d1c40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c6b353c-a337-4802-9306-bf4c698d1c40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c6b353c-a337-4802-9306-bf4c698d1c40">
											<gml:posList>35.67094442571091 139.73846227101544 31.088 35.67095215515418 139.73850253681778 31.088 35.67095215515418 139.73850253681778 26.815 35.67094442571091 139.73846227101544 26.815 35.67094442571091 139.73846227101544 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab90d4e1-84c2-402b-a6f1-25e379ee6b14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab90d4e1-84c2-402b-a6f1-25e379ee6b14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab90d4e1-84c2-402b-a6f1-25e379ee6b14">
											<gml:posList>35.67094544153356 139.73844736830463 27.145 35.67094544153356 139.73844736830463 26.815 35.67095764841646 139.73850749012655 26.815 35.67095764841646 139.73850749012655 27.145 35.67094544153356 139.73844736830463 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0c3e3bf-8c34-4211-b63f-6c5a865d58a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0c3e3bf-8c34-4211-b63f-6c5a865d58a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0c3e3bf-8c34-4211-b63f-6c5a865d58a7">
											<gml:posList>35.67094534536327 139.7385198102972 34.977 35.67094534536327 139.7385198102972 33.714 35.67096261159998 139.73851464228449 33.714 35.67096261159998 139.73851464228449 34.977 35.67094534536327 139.7385198102972 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e137bf9b-bb8a-476d-8306-564e0abe86d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e137bf9b-bb8a-476d-8306-564e0abe86d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e137bf9b-bb8a-476d-8306-564e0abe86d7">
											<gml:posList>35.67096175206057 139.73851053406273 27.145 35.67096175206057 139.73851053406273 31.088 35.670952947550404 139.73846717655212 31.088 35.670952947550404 139.73846717655212 27.173 35.67094872174471 139.73844637025223 27.173 35.67094872174471 139.73844637025223 27.145 35.67096175206057 139.73851053406273 27.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db08d727-e855-4b4e-8899-4a73872eb3cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db08d727-e855-4b4e-8899-4a73872eb3cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db08d727-e855-4b4e-8899-4a73872eb3cd">
											<gml:posList>35.670966506185415 139.73861855059928 34.977 35.670966506185415 139.73861855059928 33.714 35.67094534536327 139.7385198102972 33.714 35.67094534536327 139.7385198102972 34.977 35.670966506185415 139.73861855059928 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce463342-9c77-4171-a61b-b512e8782a5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce463342-9c77-4171-a61b-b512e8782a5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce463342-9c77-4171-a61b-b512e8782a5c">
											<gml:posList>35.67096333589193 139.7385072514267 31.088 35.67096333589193 139.7385072514267 30.751 35.670955626287856 139.73846928323323 30.751 35.670955626287856 139.73846928323323 31.088 35.67096333589193 139.7385072514267 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5652e26-db2c-4214-8ead-065d5ab2207d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5652e26-db2c-4214-8ead-065d5ab2207d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5652e26-db2c-4214-8ead-065d5ab2207d">
											<gml:posList>35.67092656314103 139.7386947180768 15.2 35.67100901906771 139.73866965600493 15.2 35.67100901906771 139.73866965600493 28.736 35.67092656314103 139.7386947180768 28.736 35.67092656314103 139.7386947180768 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8a34046-3853-4df7-a547-bd348e0e65ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8a34046-3853-4df7-a547-bd348e0e65ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8a34046-3853-4df7-a547-bd348e0e65ba">
											<gml:posList>35.67096261159998 139.73851464228449 34.977 35.67096261159998 139.73851464228449 33.714 35.670973389296705 139.73851118308 33.714 35.670973389296705 139.73851118308 34.977 35.67096261159998 139.73851464228449 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db136b6e-8b10-4ebc-af15-eaa6f0a60465">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db136b6e-8b10-4ebc-af15-eaa6f0a60465">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db136b6e-8b10-4ebc-af15-eaa6f0a60465">
											<gml:posList>35.67098783180639 139.73843428345216 27.173 35.67098783180639 139.73843428345216 15.2 35.67094872174471 139.73844637025223 15.2 35.67094872174471 139.73844637025223 27.145 35.67094872174471 139.73844637025223 27.173 35.67098783180639 139.73843428345216 27.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2924c423-9e39-44ac-bca6-4c44169bcfc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2924c423-9e39-44ac-bca6-4c44169bcfc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2924c423-9e39-44ac-bca6-4c44169bcfc5">
											<gml:posList>35.67096175206057 139.73851053406273 31.088 35.67096175206057 139.73851053406273 34.977 35.67097590003643 139.7385059883302 34.977 35.67097590003643 139.7385059883302 31.088 35.67096175206057 139.73851053406273 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48c992c2-2105-4c8a-b047-54636697ab08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48c992c2-2105-4c8a-b047-54636697ab08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48c992c2-2105-4c8a-b047-54636697ab08">
											<gml:posList>35.67097534815508 139.73850339309274 31.088 35.67097534815508 139.73850339309274 30.751 35.67096333589193 139.7385072514267 30.751 35.67096333589193 139.7385072514267 31.088 35.67097534815508 139.73850339309274 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44f345ae-0a34-4f5a-8ba1-b6a30a5e4979">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44f345ae-0a34-4f5a-8ba1-b6a30a5e4979">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44f345ae-0a34-4f5a-8ba1-b6a30a5e4979">
											<gml:posList>35.67099345980451 139.73861035550985 34.977 35.67099345980451 139.73861035550985 33.714 35.670966506185415 139.73861855059928 33.714 35.670966506185415 139.73861855059928 34.977 35.67099345980451 139.73861035550985 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56b6a829-096f-4d79-8595-916d906cb291">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56b6a829-096f-4d79-8595-916d906cb291">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56b6a829-096f-4d79-8595-916d906cb291">
											<gml:posList>35.670973389296705 139.73851118308 34.977 35.670973389296705 139.73851118308 33.714 35.67099345980451 139.73861035550985 33.714 35.67099345980451 139.73861035550985 34.977 35.670973389296705 139.73851118308 34.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b951ff5-79c6-4be1-a46d-f9fc00a3495e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b951ff5-79c6-4be1-a46d-f9fc00a3495e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b951ff5-79c6-4be1-a46d-f9fc00a3495e">
											<gml:posList>35.670952947550404 139.73846717655212 31.088 35.67102052023887 139.73845162066542 31.088 35.67102052023887 139.73845162066542 30.524 35.67102052023887 139.73845162066542 27.173 35.670952947550404 139.73846717655212 27.173 35.670952947550404 139.73846717655212 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c436db9-fddb-4c9b-b907-2c8edaacf0ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c436db9-fddb-4c9b-b907-2c8edaacf0ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c436db9-fddb-4c9b-b907-2c8edaacf0ca">
											<gml:posList>35.670955626287856 139.73846928323323 31.088 35.670955626287856 139.73846928323323 30.751 35.671018891192475 139.73845471557047 30.751 35.671018891192475 139.73845471557047 31.088 35.670955626287856 139.73846928323323 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c458ec4-6f30-4cf0-a4a7-1306b3f9a955">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c458ec4-6f30-4cf0-a4a7-1306b3f9a955">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c458ec4-6f30-4cf0-a4a7-1306b3f9a955">
											<gml:posList>35.67099018460151 139.7384459897912 15.2 35.67098783180639 139.73843428345216 15.2 35.67098783180639 139.73843428345216 27.173 35.67099018460151 139.7384459897912 27.173 35.67099018460151 139.7384459897912 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f44037b-c0ac-40d3-a82c-5c9d7fa596bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f44037b-c0ac-40d3-a82c-5c9d7fa596bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f44037b-c0ac-40d3-a82c-5c9d7fa596bf">
											<gml:posList>35.670978524279995 139.73851901990957 32.135 35.670978524279995 139.73851901990957 15.2 35.67097590003643 139.7385059883302 15.2 35.67097590003643 139.7385059883302 31.088 35.67097590003643 139.7385059883302 34.977 35.670997644604256 139.73861344354216 34.977 35.67100282964054 139.73863908702972 32.133 35.670978524279995 139.73851901990957 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29c62e55-9688-4b75-b114-02c0bf0ab074">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29c62e55-9688-4b75-b114-02c0bf0ab074">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29c62e55-9688-4b75-b114-02c0bf0ab074">
											<gml:posList>35.67100733747414 139.7386403188963 30.198 35.67098352984388 139.73852275870013 30.198 35.67098352984388 139.73852275870013 32.135 35.671013020196014 139.73866842513632 32.135 35.671013020196014 139.73866842513632 28.124 35.67100733747414 139.7386403188963 28.124 35.67100733747414 139.7386403188963 30.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae90b036-b206-4f39-8ac7-aa98d026badf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae90b036-b206-4f39-8ac7-aa98d026badf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae90b036-b206-4f39-8ac7-aa98d026badf">
											<gml:posList>35.67102552402675 139.73848742700451 31.088 35.67102552402675 139.73848742700451 30.751 35.67097534815508 139.73850339309274 30.751 35.67097534815508 139.73850339309274 31.088 35.67102552402675 139.73848742700451 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58e6d24c-d86d-4551-aa1c-14e88d93e827">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58e6d24c-d86d-4551-aa1c-14e88d93e827">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58e6d24c-d86d-4551-aa1c-14e88d93e827">
											<gml:posList>35.67097590003643 139.7385059883302 31.088 35.67097590003643 139.7385059883302 15.2 35.67102816656971 139.73848935698945 15.2 35.67102816656971 139.73848935698945 30.524 35.67102816656971 139.73848935698945 31.088 35.67097590003643 139.7385059883302 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0922905-06a0-4b85-ba1a-a418decfae73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0922905-06a0-4b85-ba1a-a418decfae73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0922905-06a0-4b85-ba1a-a418decfae73">
											<gml:posList>35.67099018460151 139.7384459897912 15.2 35.67099018460151 139.7384459897912 27.173 35.67101776032082 139.7384380037856 27.173 35.67101776032082 139.7384380037856 26.705 35.67101776032082 139.7384380037856 15.2 35.67099018460151 139.7384459897912 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-576d5a78-78ee-448d-bc8d-722a2858c541">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-576d5a78-78ee-448d-bc8d-722a2858c541">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-576d5a78-78ee-448d-bc8d-722a2858c541">
											<gml:posList>35.67100901906771 139.73866965600493 32.135 35.67100282964054 139.73863908702972 32.133 35.67100901906771 139.73866965600493 28.736 35.67100901906771 139.73866965600493 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6f6ff0d-0781-4422-a2b1-e014cb1e55fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6f6ff0d-0781-4422-a2b1-e014cb1e55fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6f6ff0d-0781-4422-a2b1-e014cb1e55fb">
											<gml:posList>35.67104295768576 139.73850027537927 15.2 35.670978524279995 139.73851901990957 15.2 35.670978524279995 139.73851901990957 32.135 35.67104295768576 139.73850027537927 32.135 35.67104295768576 139.73850027537927 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e696e962-44ac-44be-9ccd-6b8e7949c6b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e696e962-44ac-44be-9ccd-6b8e7949c6b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e696e962-44ac-44be-9ccd-6b8e7949c6b7">
											<gml:posList>35.6710144471847 139.73869494572975 32.135 35.67100901906771 139.73866965600493 32.135 35.67100901906771 139.73866965600493 28.736 35.67100901906771 139.73866965600493 15.2 35.6710144471847 139.73869494572975 15.2 35.6710144471847 139.73869494572975 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-580743cc-1858-459f-9b41-171935597b56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-580743cc-1858-459f-9b41-171935597b56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-580743cc-1858-459f-9b41-171935597b56">
											<gml:posList>35.67098352984388 139.73852275870013 32.135 35.67098352984388 139.73852275870013 30.198 35.67103993385145 139.73850634340215 30.198 35.67103993385145 139.73850634340215 32.135 35.67098352984388 139.73852275870013 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34c6a0f4-3d10-430e-b39e-a8204ad6ce19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34c6a0f4-3d10-430e-b39e-a8204ad6ce19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34c6a0f4-3d10-430e-b39e-a8204ad6ce19">
											<gml:posList>35.671013020196014 139.73866842513632 32.135 35.671017398884025 139.7386888336157 32.135 35.671017398884025 139.7386888336157 28.124 35.671013020196014 139.73866842513632 28.124 35.671013020196014 139.73866842513632 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1aa64b6-faee-4305-98b2-395673b08e76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1aa64b6-faee-4305-98b2-395673b08e76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1aa64b6-faee-4305-98b2-395673b08e76">
											<gml:posList>35.67101441218462 139.7384214382285 15.2 35.67101776032082 139.7384380037856 15.2 35.67101776032082 139.7384380037856 26.705 35.67101556141118 139.73842712573665 26.705 35.67101556141118 139.73842712573665 25.281 35.67101441218462 139.7384214382285 25.281 35.67101441218462 139.7384214382285 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e5bcb5c-a572-4e59-8e3d-2b04fee8c74d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e5bcb5c-a572-4e59-8e3d-2b04fee8c74d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e5bcb5c-a572-4e59-8e3d-2b04fee8c74d">
											<gml:posList>35.67101967869864 139.73844747928104 27.173 35.67101967869864 139.73844747928104 26.705 35.67101776032082 139.7384380037856 26.705 35.67101776032082 139.7384380037856 27.173 35.67101967869864 139.73844747928104 27.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-530400aa-0d4a-449c-8a68-3926c5db5097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-530400aa-0d4a-449c-8a68-3926c5db5097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-530400aa-0d4a-449c-8a68-3926c5db5097">
											<gml:posList>35.67102052023887 139.73845162066542 30.524 35.67101967869864 139.73844747928104 30.524 35.67101967869864 139.73844747928104 27.173 35.67102052023887 139.73845162066542 27.173 35.67102052023887 139.73845162066542 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7139abe-60c7-45b6-98c9-6463c17be95a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7139abe-60c7-45b6-98c9-6463c17be95a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7139abe-60c7-45b6-98c9-6463c17be95a">
											<gml:posList>35.671018891192475 139.73845471557047 31.088 35.671018891192475 139.73845471557047 30.751 35.67102552402675 139.73848742700451 30.751 35.67102552402675 139.73848742700451 31.088 35.671018891192475 139.73845471557047 31.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73a92fde-d147-48bf-b901-11256e888b11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73a92fde-d147-48bf-b901-11256e888b11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73a92fde-d147-48bf-b901-11256e888b11">
											<gml:posList>35.67102260192104 139.7384509996064 30.524 35.67102260192104 139.7384509996064 30.29 35.67102227616494 139.7384493982715 30.29 35.67102227616494 139.7384493982715 30.524 35.67102260192104 139.7384509996064 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3ac77dd-0dd9-4271-9d45-d870c24459b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3ac77dd-0dd9-4271-9d45-d870c24459b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3ac77dd-0dd9-4271-9d45-d870c24459b7">
											<gml:posList>35.67102052023887 139.73845162066542 30.524 35.67102052023887 139.73845162066542 31.088 35.67102816656971 139.73848935698945 31.088 35.67102816656971 139.73848935698945 30.524 35.67102052023887 139.73845162066542 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3af9570-1522-4b00-82e3-6f5c6e99386b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3af9570-1522-4b00-82e3-6f5c6e99386b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3af9570-1522-4b00-82e3-6f5c6e99386b">
											<gml:posList>35.671030248243376 139.73848872488503 30.524 35.671030248243376 139.73848872488503 30.29 35.67102260192104 139.7384509996064 30.29 35.67102260192104 139.7384509996064 30.524 35.671030248243376 139.73848872488503 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-89e51092-ff7f-4c3e-8d83-67b05732a049">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89e51092-ff7f-4c3e-8d83-67b05732a049">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89e51092-ff7f-4c3e-8d83-67b05732a049">
											<gml:posList>35.67102816656971 139.73848935698945 15.2 35.67103033838908 139.7385001798421 15.2 35.67103033838908 139.7385001798421 30.524 35.67102816656971 139.73848935698945 30.524 35.67102816656971 139.73848935698945 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e19b7bc-783c-41bc-ab6e-36ab4fbf4934">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e19b7bc-783c-41bc-ab6e-36ab4fbf4934">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e19b7bc-783c-41bc-ab6e-36ab4fbf4934">
											<gml:posList>35.67103191329341 139.73849700767713 30.524 35.67103191329341 139.73849700767713 30.29 35.671030248243376 139.73848872488503 30.29 35.671030248243376 139.73848872488503 30.524 35.67103191329341 139.73849700767713 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df96f3ae-04da-47ab-96a5-8f50ade1f267">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df96f3ae-04da-47ab-96a5-8f50ade1f267">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df96f3ae-04da-47ab-96a5-8f50ade1f267">
											<gml:posList>35.67100733747414 139.7386403188963 30.198 35.67100733747414 139.7386403188963 28.124 35.67106359673072 139.73862320792682 28.124 35.67106359673072 139.73862320792682 30.198 35.67100733747414 139.7386403188963 30.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5170ad1-0932-4bda-a090-17e3e1e8a437">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5170ad1-0932-4bda-a090-17e3e1e8a437">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5170ad1-0932-4bda-a090-17e3e1e8a437">
											<gml:posList>35.671017398884025 139.7386888336157 32.135 35.6710734237994 139.73867173400112 32.135 35.6710734237994 139.73867173400112 28.124 35.671017398884025 139.7386888336157 28.124 35.671017398884025 139.7386888336157 32.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3e41d7c-abc1-4309-987a-bf69f20ec4bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3e41d7c-abc1-4309-987a-bf69f20ec4bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3e41d7c-abc1-4309-987a-bf69f20ec4bc">
											<gml:posList>35.6710144471847 139.73869494572975 15.2 35.67107842932375 139.73867542862027 15.2 35.67107842932375 139.73867542862027 32.135 35.6710144471847 139.73869494572975 32.135 35.6710144471847 139.73869494572975 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c146a06-8854-42bb-8a0c-0d22bdbc2976">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c146a06-8854-42bb-8a0c-0d22bdbc2976">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c146a06-8854-42bb-8a0c-0d22bdbc2976">
											<gml:posList>35.67108389134256 139.73840025743866 15.2 35.67101441218462 139.7384214382285 15.2 35.67101441218462 139.7384214382285 25.281 35.67108389134256 139.73840025743866 25.281 35.67108389134256 139.73840025743866 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70775d81-5159-41dc-b8c8-6f5547e1dc35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70775d81-5159-41dc-b8c8-6f5547e1dc35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70775d81-5159-41dc-b8c8-6f5547e1dc35">
											<gml:posList>35.67108501343316 139.73840582347364 26.705 35.67108501343316 139.73840582347364 25.281 35.67101556141118 139.73842712573665 25.281 35.67101556141118 139.73842712573665 26.705 35.67108501343316 139.73840582347364 26.705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36b56327-9a41-440d-8c3e-170c38918f8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36b56327-9a41-440d-8c3e-170c38918f8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36b56327-9a41-440d-8c3e-170c38918f8e">
											<gml:posList>35.67108916677037 139.7384261659455 30.524 35.67108916677037 139.7384261659455 26.705 35.67101967869864 139.73844747928104 26.705 35.67101967869864 139.73844747928104 27.173 35.67101967869864 139.73844747928104 30.524 35.67108916677037 139.7384261659455 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a5e56a1-0a1c-4e65-a20c-73be769b8bcd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a5e56a1-0a1c-4e65-a20c-73be769b8bcd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a5e56a1-0a1c-4e65-a20c-73be769b8bcd">
											<gml:posList>35.67102227616494 139.7384493982715 30.524 35.67102227616494 139.7384493982715 30.29 35.67108760990408 139.73842934913918 30.29 35.67108760990408 139.73842934913918 30.524 35.67102227616494 139.7384493982715 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-748b1afa-bab9-47d6-961a-0cdf8a83f7cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-748b1afa-bab9-47d6-961a-0cdf8a83f7cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-748b1afa-bab9-47d6-961a-0cdf8a83f7cf">
											<gml:posList>35.67106359673072 139.73862320792682 30.198 35.67106359673072 139.73862320792682 28.124 35.6710734237994 139.73867173400112 28.124 35.6710734237994 139.73867173400112 32.135 35.67103993385145 139.73850634340215 32.135 35.67103993385145 139.73850634340215 30.198 35.67106359673072 139.73862320792682 30.198</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93444dd5-cd4a-4bb6-b16b-b9701a8c636f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93444dd5-cd4a-4bb6-b16b-b9701a8c636f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93444dd5-cd4a-4bb6-b16b-b9701a8c636f">
											<gml:posList>35.67107842932375 139.73867542862027 15.2 35.67104295768576 139.73850027537927 15.2 35.67104295768576 139.73850027537927 32.135 35.67107842932375 139.73867542862027 32.135 35.67107842932375 139.73867542862027 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2967a9d3-3353-47fa-87dd-59f61a2f9c64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2967a9d3-3353-47fa-87dd-59f61a2f9c64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2967a9d3-3353-47fa-87dd-59f61a2f9c64">
											<gml:posList>35.67109733727336 139.73847707998434 30.524 35.67109733727336 139.73847707998434 30.29 35.67103191329341 139.73849700767713 30.29 35.67103191329341 139.73849700767713 30.524 35.67109733727336 139.73847707998434 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb925025-21a9-4b03-a4ae-b9dd7b4b8e55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb925025-21a9-4b03-a4ae-b9dd7b4b8e55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb925025-21a9-4b03-a4ae-b9dd7b4b8e55">
											<gml:posList>35.67103033838908 139.7385001798421 15.2 35.67109990769798 139.73847899900957 15.2 35.67109990769798 139.73847899900957 30.524 35.67103033838908 139.7385001798421 30.524 35.67103033838908 139.7385001798421 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b321272d-bb53-44cb-bb29-e91d009a2783">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b321272d-bb53-44cb-bb29-e91d009a2783">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b321272d-bb53-44cb-bb29-e91d009a2783">
											<gml:posList>35.67107014045282 139.73822264834376 15.2 35.67106094881309 139.73822564176294 15.2 35.67106094881309 139.73822564176294 26.909 35.67107014045282 139.73822264834376 26.909 35.67107014045282 139.73822264834376 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99d2b095-8623-4428-8155-fa155c399178">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99d2b095-8623-4428-8155-fa155c399178">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99d2b095-8623-4428-8155-fa155c399178">
											<gml:posList>35.67106094881309 139.73822564176294 15.2 35.6710733429671 139.73828306810498 15.2 35.6710733429671 139.73828306810498 26.909 35.67106094881309 139.73822564176294 26.909 35.67106094881309 139.73822564176294 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39e6d595-4cbb-4cdf-99e7-4f3c6719ca45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39e6d595-4cbb-4cdf-99e7-4f3c6719ca45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39e6d595-4cbb-4cdf-99e7-4f3c6719ca45">
											<gml:posList>35.67106869293486 139.73821591178492 29.344 35.67106869293486 139.73821591178492 15.2 35.67107014045282 139.73822264834376 15.2 35.67107014045282 139.73822264834376 26.909 35.67107014045282 139.73822264834376 29.344 35.67106869293486 139.73821591178492 29.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2507eff-16ac-42f6-b7ee-a6677f53f513">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2507eff-16ac-42f6-b7ee-a6677f53f513">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2507eff-16ac-42f6-b7ee-a6677f53f513">
											<gml:posList>35.67108154336053 139.7382804072578 26.909 35.67108154336053 139.7382804072578 29.344 35.67107014045282 139.73822264834376 29.344 35.67107014045282 139.73822264834376 26.909 35.67108154336053 139.7382804072578 26.909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22d96077-221b-4ffa-b74a-b377ac9fd6fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22d96077-221b-4ffa-b74a-b377ac9fd6fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22d96077-221b-4ffa-b74a-b377ac9fd6fc">
											<gml:posList>35.6710733429671 139.73828306810498 15.2 35.67108154336053 139.7382804072578 15.2 35.67108154336053 139.7382804072578 26.909 35.6710733429671 139.73828306810498 26.909 35.6710733429671 139.73828306810498 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-415672c1-173a-42b8-96e8-5184d025d71b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-415672c1-173a-42b8-96e8-5184d025d71b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-415672c1-173a-42b8-96e8-5184d025d71b">
											<gml:posList>35.67108443434303 139.7384030183848 15.2 35.67108389134256 139.73840025743866 15.2 35.67108389134256 139.73840025743866 25.281 35.67108443434303 139.7384030183848 25.281 35.67108443434303 139.7384030183848 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28fa450b-fb8f-40cf-a84c-8b8f7cbcceba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28fa450b-fb8f-40cf-a84c-8b8f7cbcceba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28fa450b-fb8f-40cf-a84c-8b8f7cbcceba">
											<gml:posList>35.67108796646832 139.73831000387884 29.344 35.67108154336053 139.7382804072578 29.344 35.67108154336053 139.7382804072578 26.909 35.67108154336053 139.7382804072578 15.2 35.67108796646832 139.73831000387884 15.2 35.67108796646832 139.73831000387884 29.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5779ba7-e7c9-4d30-947f-66e083fe5bdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5779ba7-e7c9-4d30-947f-66e083fe5bdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5779ba7-e7c9-4d30-947f-66e083fe5bdc">
											<gml:posList>35.67109560848327 139.73839935985617 29.423 35.67109560848327 139.73839935985617 15.2 35.67108443434303 139.7384030183848 15.2 35.67108443434303 139.7384030183848 25.281 35.67108443434303 139.7384030183848 32.058 35.67109560848327 139.73839935985617 32.058 35.67109560848327 139.73839935985617 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-63c3acf6-ae8e-417c-a941-daab9b54b3a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63c3acf6-ae8e-417c-a941-daab9b54b3a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63c3acf6-ae8e-417c-a941-daab9b54b3a0">
											<gml:posList>35.67108916677037 139.7384261659455 30.524 35.671099093156364 139.7384748023571 30.524 35.671099093156364 139.7384748023571 32.058 35.67108443434303 139.7384030183848 32.058 35.67108443434303 139.7384030183848 25.281 35.67108501343316 139.73840582347364 25.281 35.67108501343316 139.73840582347364 26.705 35.67108916677037 139.7384261659455 26.705 35.67108916677037 139.7384261659455 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69b9a279-f6d9-4fb2-a674-cfd4420f4007">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69b9a279-f6d9-4fb2-a674-cfd4420f4007">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69b9a279-f6d9-4fb2-a674-cfd4420f4007">
											<gml:posList>35.67108782837342 139.73836346840903 15.2 35.67109560848327 139.73839935985617 15.2 35.67109560848327 139.73839935985617 29.423 35.67108782837342 139.73836346840903 29.423 35.67108782837342 139.73836346840903 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cc4caab-325b-451c-8247-3bfe4d61d291">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cc4caab-325b-451c-8247-3bfe4d61d291">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cc4caab-325b-451c-8247-3bfe4d61d291">
											<gml:posList>35.67108760990408 139.73842934913918 30.524 35.67108760990408 139.73842934913918 30.29 35.6710970114654 139.73847541236975 30.29 35.6710970114654 139.73847541236975 30.524 35.67108760990408 139.73842934913918 30.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51bbca06-1a21-47b9-b3a3-2138d2033a99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51bbca06-1a21-47b9-b3a3-2138d2033a99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51bbca06-1a21-47b9-b3a3-2138d2033a99">
											<gml:posList>35.67108823127063 139.7384057423392 32.058 35.67108823127063 139.7384057423392 31.793 35.67109645868181 139.738403048333 31.793 35.67109645868181 139.738403048333 32.058 35.67108823127063 139.7384057423392 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9976e36e-c128-4b34-8574-814ef7ec948e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9976e36e-c128-4b34-8574-814ef7ec948e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9976e36e-c128-4b34-8574-814ef7ec948e">
											<gml:posList>35.67110137897784 139.73847014913568 32.058 35.67110137897784 139.73847014913568 31.793 35.67108823127063 139.7384057423392 31.793 35.67108823127063 139.7384057423392 32.058 35.67110137897784 139.73847014913568 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bce51d2-625d-44d6-8eeb-771d6fcd0dc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bce51d2-625d-44d6-8eeb-771d6fcd0dc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bce51d2-625d-44d6-8eeb-771d6fcd0dc9">
											<gml:posList>35.671098038016225 139.73839406577383 29.423 35.671098038016225 139.73839406577383 28.921 35.67109205819575 139.73836649010062 28.921 35.67109205819575 139.73836649010062 29.423 35.671098038016225 139.73839406577383 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10600363-2b92-4599-972d-d855d53b8c57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10600363-2b92-4599-972d-d855d53b8c57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10600363-2b92-4599-972d-d855d53b8c57">
											<gml:posList>35.67107330679078 139.7382144260997 29.344 35.67107562269754 139.73821363906094 30.701 35.67108601288261 139.7382102907344 32.058 35.6711213196267 139.73819883795395 32.058 35.6711213196267 139.73819883795395 15.2 35.67106869293486 139.73821591178492 15.2 35.67106869293486 139.73821591178492 29.344 35.67107330679078 139.7382144260997 29.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8bb5ec1-9da6-4eff-bd23-c8132520fce6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8bb5ec1-9da6-4eff-bd23-c8132520fce6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8bb5ec1-9da6-4eff-bd23-c8132520fce6">
											<gml:posList>35.67108796646832 139.73831000387884 15.2 35.671106268671934 139.738304072385 15.2 35.671106268671934 139.738304072385 29.344 35.67109364367423 139.73830817450127 29.344 35.67108796646832 139.73831000387884 29.344 35.67108796646832 139.73831000387884 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a165f1b3-9321-411d-9c7e-29d343cd8788">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a165f1b3-9321-411d-9c7e-29d343cd8788">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a165f1b3-9321-411d-9c7e-29d343cd8788">
											<gml:posList>35.67110891022398 139.73830474308198 32.058 35.67110891022398 139.73830474308198 31.681 35.67108896204484 139.73821240813595 31.681 35.67108896204484 139.73821240813595 32.058 35.67110891022398 139.73830474308198 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26080e13-3f23-4ca7-a8b4-a6175b548aea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26080e13-3f23-4ca7-a8b4-a6175b548aea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26080e13-3f23-4ca7-a8b4-a6175b548aea">
											<gml:posList>35.67109990769798 139.73847899900957 15.2 35.671099093156364 139.7384748023571 15.2 35.671099093156364 139.7384748023571 30.524 35.67109990769798 139.73847899900957 30.524 35.67109990769798 139.73847899900957 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-782e9c47-6974-4d36-8c51-22663d186f22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-782e9c47-6974-4d36-8c51-22663d186f22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-782e9c47-6974-4d36-8c51-22663d186f22">
											<gml:posList>35.671106268671934 139.738304072385 29.344 35.67110625965821 139.7383040723957 32.058 35.67109592353545 139.7383073985541 30.701 35.67109364367423 139.73830817450127 29.344 35.671106268671934 139.738304072385 29.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4deddd8d-2359-4575-a078-dedb70a4c435">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4deddd8d-2359-4575-a078-dedb70a4c435">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4deddd8d-2359-4575-a078-dedb70a4c435">
											<gml:posList>35.671117052421444 139.73835398915395 15.2 35.67108782837342 139.73836346840903 15.2 35.67108782837342 139.73836346840903 29.423 35.671117052421444 139.73835398915395 29.423 35.671117052421444 139.73835398915395 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-affed224-6b43-4817-86c7-b66bc7633bd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-affed224-6b43-4817-86c7-b66bc7633bd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-affed224-6b43-4817-86c7-b66bc7633bd3">
											<gml:posList>35.67109205819575 139.73836649010062 29.423 35.67109205819575 139.73836649010062 28.921 35.67111457774324 139.73835918387496 28.921 35.67111457774324 139.73835918387496 29.423 35.67109205819575 139.73836649010062 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0881da4-83ca-471c-9aea-8fc385d05399">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0881da4-83ca-471c-9aea-8fc385d05399">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0881da4-83ca-471c-9aea-8fc385d05399">
											<gml:posList>35.67108896204484 139.73821240813595 32.058 35.67108896204484 139.73821240813595 31.681 35.67111959185481 139.7382024632105 31.681 35.67111959185481 139.7382024632105 32.058 35.67108896204484 139.73821240813595 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a075dcb8-95e6-4062-aa75-954380180125">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a075dcb8-95e6-4062-aa75-954380180125">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a075dcb8-95e6-4062-aa75-954380180125">
											<gml:posList>35.67111238385368 139.73838896746065 29.423 35.67111238385368 139.73838896746065 28.921 35.671098038016225 139.73839406577383 28.921 35.671098038016225 139.73839406577383 29.423 35.67111238385368 139.73838896746065 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0199a10e-32dd-4eed-81fe-b34c9c9be122">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0199a10e-32dd-4eed-81fe-b34c9c9be122">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0199a10e-32dd-4eed-81fe-b34c9c9be122">
											<gml:posList>35.67109560848327 139.73839935985617 32.058 35.671116460415966 139.7383919561969 32.058 35.671116460415966 139.7383919561969 29.423 35.67109560848327 139.73839935985617 29.423 35.67109560848327 139.73839935985617 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ede115d-4956-4727-a65e-555ab02d5585">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ede115d-4956-4727-a65e-555ab02d5585">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ede115d-4956-4727-a65e-555ab02d5585">
											<gml:posList>35.67109645868181 139.738403048333 32.058 35.67109645868181 139.738403048333 31.793 35.67112014013059 139.73839463610523 31.793 35.67112014013059 139.73839463610523 32.058 35.67109645868181 139.738403048333 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-036ea154-14d3-4526-807e-3cd78169d80f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-036ea154-14d3-4526-807e-3cd78169d80f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-036ea154-14d3-4526-807e-3cd78169d80f">
											<gml:posList>35.67111216362877 139.7383725970158 29.423 35.67111216362877 139.7383725970158 28.921 35.67111144217609 139.7383835779521 28.921 35.67111144217609 139.7383835779521 29.423 35.67111216362877 139.7383725970158 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f61ead21-677a-44e1-b735-f0c70d6e29cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f61ead21-677a-44e1-b735-f0c70d6e29cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f61ead21-677a-44e1-b735-f0c70d6e29cf">
											<gml:posList>35.67111144217609 139.7383835779521 29.423 35.67111144217609 139.7383835779521 28.921 35.67111238385368 139.73838896746065 28.921 35.67111238385368 139.73838896746065 29.423 35.67111144217609 139.7383835779521 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f16ca729-d3eb-4c1f-a9b0-2e06a494d7ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f16ca729-d3eb-4c1f-a9b0-2e06a494d7ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f16ca729-d3eb-4c1f-a9b0-2e06a494d7ea">
											<gml:posList>35.67111929601422 139.7383643700755 32.058 35.67111663626543 139.7383520565338 32.058 35.67111663626543 139.7383520565338 31.447 35.671107200476335 139.73830836831436 31.447 35.671107200476335 139.73830836831436 32.058 35.67110625965821 139.7383040723957 32.058 35.671106268671934 139.738304072385 29.344 35.671106268671934 139.738304072385 15.2 35.671117052421444 139.73835398915395 15.2 35.671117052421444 139.73835398915395 29.423 35.67111929601422 139.7383643700755 29.423 35.67111929601422 139.7383643700755 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0217b789-55b9-49fe-ad80-b46bdd94bb68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0217b789-55b9-49fe-ad80-b46bdd94bb68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0217b789-55b9-49fe-ad80-b46bdd94bb68">
											<gml:posList>35.67111457774324 139.73835918387496 29.423 35.67111457774324 139.73835918387496 28.921 35.671115609062525 139.73836394363468 28.921 35.671115609062525 139.73836394363468 29.423 35.67111457774324 139.73835918387496 29.423</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7bd73b0-bb3f-42ca-84b0-fa4b7271ff58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7bd73b0-bb3f-42ca-84b0-fa4b7271ff58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7bd73b0-bb3f-42ca-84b0-fa4b7271ff58">
											<gml:posList>35.671114948304535 139.73838330868725 32.058 35.67111557171261 139.73837373075435 32.058 35.67111557171261 139.73837373075435 29.423 35.671114948304535 139.73838330868725 29.423 35.671114948304535 139.73838330868725 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58da9241-ef35-4c78-a6df-cc5311c31bb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58da9241-ef35-4c78-a6df-cc5311c31bb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58da9241-ef35-4c78-a6df-cc5311c31bb6">
											<gml:posList>35.671116460415966 139.7383919561969 32.058 35.671114948304535 139.73838330868725 32.058 35.671114948304535 139.73838330868725 29.423 35.671116460415966 139.7383919561969 29.423 35.671116460415966 139.7383919561969 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83667e41-a44e-48c3-9920-7ad8b370fb8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83667e41-a44e-48c3-9920-7ad8b370fb8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83667e41-a44e-48c3-9920-7ad8b370fb8f">
											<gml:posList>35.671107200476335 139.73830836831436 32.058 35.671107200476335 139.73830836831436 31.447 35.671125547757136 139.73830244781163 31.447 35.671125547757136 139.73830244781163 32.058 35.671107200476335 139.73830836831436 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6049cdf1-3424-4e3a-9761-879fa9675d30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6049cdf1-3424-4e3a-9761-879fa9675d30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6049cdf1-3424-4e3a-9761-879fa9675d30">
											<gml:posList>35.67112492354369 139.7382995764974 32.058 35.67112492354369 139.7382995764974 31.681 35.67110891022398 139.73830474308198 31.681 35.67110891022398 139.73830474308198 32.058 35.67112492354369 139.7382995764974 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee9ba352-c092-4ec8-85b0-a2275d2dbf3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee9ba352-c092-4ec8-85b0-a2275d2dbf3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee9ba352-c092-4ec8-85b0-a2275d2dbf3e">
											<gml:posList>35.67111557171261 139.73837373075435 32.058 35.67111929601422 139.7383643700755 32.058 35.67111929601422 139.7383643700755 29.423 35.67111557171261 139.73837373075435 29.423 35.67111557171261 139.73837373075435 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-961ff256-15cc-424e-b133-8be59b682e36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-961ff256-15cc-424e-b133-8be59b682e36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-961ff256-15cc-424e-b133-8be59b682e36">
											<gml:posList>35.67111811190286 139.73838302878164 32.058 35.67111811190286 139.73838302878164 31.793 35.67111865522407 139.73837476546018 31.793 35.67111865522407 139.73837476546018 32.058 35.67111811190286 139.73838302878164 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bffe9be3-f39f-4508-be38-9a4dc0e8db23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bffe9be3-f39f-4508-be38-9a4dc0e8db23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bffe9be3-f39f-4508-be38-9a4dc0e8db23">
											<gml:posList>35.67112014013059 139.73839463610523 32.058 35.67112014013059 139.73839463610523 31.793 35.67111811190286 139.73838302878164 31.793 35.67111811190286 139.73838302878164 32.058 35.67112014013059 139.73839463610523 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ea2055f-12b4-4bd9-a18e-885089936674">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ea2055f-12b4-4bd9-a18e-885089936674">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ea2055f-12b4-4bd9-a18e-885089936674">
											<gml:posList>35.67111865522407 139.73837476546018 32.058 35.67111865522407 139.73837476546018 31.793 35.67112263140464 139.73836476379367 31.793 35.67112263140464 139.73836476379367 32.058 35.67111865522407 139.73837476546018 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bac33f3f-21c0-4eae-a6e6-5739683f749d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bac33f3f-21c0-4eae-a6e6-5739683f749d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bac33f3f-21c0-4eae-a6e6-5739683f749d">
											<gml:posList>35.67112263140464 139.73836476379367 32.058 35.67112263140464 139.73836476379367 31.793 35.67112047826277 139.73835478043353 31.793 35.67112047826277 139.73835478043353 32.058 35.67112263140464 139.73836476379367 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b78791f-3c49-46cd-b95f-529e838e1c5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b78791f-3c49-46cd-b95f-529e838e1c5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b78791f-3c49-46cd-b95f-529e838e1c5b">
											<gml:posList>35.67112431927307 139.7383791110183 36.412 35.671124514142754 139.73837475852096 36.412 35.671124514142754 139.73837475852096 31.793 35.67112431927307 139.7383791110183 31.793 35.67112431927307 139.7383791110183 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af5505fe-5ed5-4327-ae4e-97f035b1a2a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af5505fe-5ed5-4327-ae4e-97f035b1a2a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af5505fe-5ed5-4327-ae4e-97f035b1a2a2">
											<gml:posList>35.671124514142754 139.73837475852096 36.412 35.671126070432635 139.73837084626555 36.412 35.671126070432635 139.73837084626555 31.793 35.671124514142754 139.73837475852096 31.793 35.671124514142754 139.73837475852096 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d66088e0-b6e8-45fe-874c-7218a46182c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d66088e0-b6e8-45fe-874c-7218a46182c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d66088e0-b6e8-45fe-874c-7218a46182c2">
											<gml:posList>35.67113495645493 139.73834606979432 32.058 35.67113495645493 139.73834606979432 31.447 35.67111663626543 139.7383520565338 31.447 35.67111663626543 139.7383520565338 32.058 35.67113495645493 139.73834606979432 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80c0d38f-3728-41d0-ac1e-27776808158d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80c0d38f-3728-41d0-ac1e-27776808158d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80c0d38f-3728-41d0-ac1e-27776808158d">
											<gml:posList>35.671126500375784 139.73837883227608 36.412 35.671126500375784 139.73837883227608 36.126 35.67112665095217 139.73837546295732 36.126 35.67112665095217 139.73837546295732 36.412 35.671126500375784 139.73837883227608 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-670bb6b5-35e5-44bf-9e7b-2beb39761c81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-670bb6b5-35e5-44bf-9e7b-2beb39761c81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-670bb6b5-35e5-44bf-9e7b-2beb39761c81">
											<gml:posList>35.67112431927307 139.7383791110183 31.793 35.67112992832631 139.73840516274453 31.793 35.67112992832631 139.73840516274453 36.412 35.67112431927307 139.7383791110183 36.412 35.67112431927307 139.7383791110183 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fd42490-51ac-4c28-b518-734cd1ad9a8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fd42490-51ac-4c28-b518-734cd1ad9a8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fd42490-51ac-4c28-b518-734cd1ad9a8c">
											<gml:posList>35.67112665095217 139.73837546295732 36.412 35.67112665095217 139.73837546295732 36.126 35.67112788338405 139.73837235746984 36.126 35.67112788338405 139.73837235746984 36.412 35.67112665095217 139.73837546295732 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1df27dd-76ab-4ef9-988c-49a11ddad068">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1df27dd-76ab-4ef9-988c-49a11ddad068">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1df27dd-76ab-4ef9-988c-49a11ddad068">
											<gml:posList>35.671126070432635 139.73837084626555 36.412 35.67112851947281 139.73836743003886 36.412 35.67112851947281 139.73836743003886 31.793 35.671126070432635 139.73837084626555 31.793 35.671126070432635 139.73837084626555 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcf19a55-923d-4418-be24-94186e52008d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcf19a55-923d-4418-be24-94186e52008d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcf19a55-923d-4418-be24-94186e52008d">
											<gml:posList>35.67112047826277 139.73835478043353 32.058 35.67112047826277 139.73835478043353 31.793 35.67113576160392 139.73834978041847 31.793 35.67113576160392 139.73834978041847 32.058 35.67112047826277 139.73835478043353 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41c38f53-5334-415f-bfde-22e26387ab4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41c38f53-5334-415f-bfde-22e26387ab4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41c38f53-5334-415f-bfde-22e26387ab4c">
											<gml:posList>35.67112788338405 139.73837235746984 36.412 35.67112788338405 139.73837235746984 36.126 35.671129891239794 139.738369560362 36.126 35.671129891239794 139.738369560362 36.412 35.67112788338405 139.73837235746984 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d29875ad-374e-444b-bdd5-5291c26f8d0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d29875ad-374e-444b-bdd5-5291c26f8d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d29875ad-374e-444b-bdd5-5291c26f8d0d">
											<gml:posList>35.67113147612597 139.73840191328125 36.412 35.67113147612597 139.73840191328125 36.126 35.671126500375784 139.73837883227608 36.126 35.671126500375784 139.73837883227608 36.412 35.67113147612597 139.73840191328125 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-452c3d40-734e-4c8c-ac20-8380da49925a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-452c3d40-734e-4c8c-ac20-8380da49925a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-452c3d40-734e-4c8c-ac20-8380da49925a">
											<gml:posList>35.67111959185481 139.7382024632105 32.058 35.67111959185481 139.7382024632105 31.681 35.67113953102781 139.7382947982 31.681 35.67113953102781 139.7382947982 32.058 35.67111959185481 139.7382024632105 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1241396e-76a2-4d85-a219-91730b5a9e64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1241396e-76a2-4d85-a219-91730b5a9e64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1241396e-76a2-4d85-a219-91730b5a9e64">
											<gml:posList>35.67113495645493 139.73834606979432 31.447 35.67113495645493 139.73834606979432 15.2 35.671125547757136 139.73830244781163 15.2 35.671125547757136 139.73830244781163 31.447 35.67113495645493 139.73834606979432 31.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f220fd0e-7395-44e7-8ac2-75788f967ee3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f220fd0e-7395-44e7-8ac2-75788f967ee3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f220fd0e-7395-44e7-8ac2-75788f967ee3">
											<gml:posList>35.67112851947281 139.73836743003886 36.412 35.67113208708551 139.73836511712327 36.412 35.67113208708551 139.73836511712327 31.793 35.67112851947281 139.73836743003886 31.793 35.67112851947281 139.73836743003886 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b44d777-cb39-4b9d-82f5-8e6d43489c1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b44d777-cb39-4b9d-82f5-8e6d43489c1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b44d777-cb39-4b9d-82f5-8e6d43489c1e">
											<gml:posList>35.671129891239794 139.738369560362 36.412 35.671129891239794 139.738369560362 36.126 35.67113287325687 139.73836762371644 36.126 35.67113287325687 139.73836762371644 36.412 35.671129891239794 139.738369560362 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60009b4b-9890-47f0-9246-a1bf567073e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60009b4b-9890-47f0-9246-a1bf567073e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60009b4b-9890-47f0-9246-a1bf567073e1">
											<gml:posList>35.67114248919354 139.738296904549 15.2 35.6711213196267 139.73819883795395 15.2 35.6711213196267 139.73819883795395 32.058 35.67114248919354 139.738296904549 32.058 35.67114248919354 139.738296904549 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3be94091-815a-4150-8a22-8da2aa4027bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3be94091-815a-4150-8a22-8da2aa4027bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3be94091-815a-4150-8a22-8da2aa4027bd">
											<gml:posList>35.67113953102781 139.7382947982 32.058 35.67113953102781 139.7382947982 31.681 35.67112492354369 139.7382995764974 31.681 35.67112492354369 139.7382995764974 32.058 35.67113953102781 139.7382947982 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77865395-3a22-4d9a-8497-5b2f83abd9a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77865395-3a22-4d9a-8497-5b2f83abd9a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77865395-3a22-4d9a-8497-5b2f83abd9a1">
											<gml:posList>35.67114248919354 139.738296904549 15.2 35.67114248919354 139.738296904549 32.058 35.671125547757136 139.73830244781163 32.058 35.671125547757136 139.73830244781163 31.447 35.671125547757136 139.73830244781163 15.2 35.67114248919354 139.738296904549 15.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67f733ac-cdcc-4a60-a044-b12fbfff56eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67f733ac-cdcc-4a60-a044-b12fbfff56eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67f733ac-cdcc-4a60-a044-b12fbfff56eb">
											<gml:posList>35.67116707339898 139.73845026526902 32.058 35.67116707339898 139.73845026526902 31.793 35.67110137897784 139.73847014913568 31.793 35.67110137897784 139.73847014913568 32.058 35.67116707339898 139.73845026526902 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38f79f21-f650-4dd1-aa4e-09e3fe9ef22a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38f79f21-f650-4dd1-aa4e-09e3fe9ef22a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38f79f21-f650-4dd1-aa4e-09e3fe9ef22a">
											<gml:posList>35.67112992832631 139.73840516274453 31.793 35.67113979584274 139.7384019697085 31.793 35.67113979584274 139.7384019697085 36.412 35.67112992832631 139.73840516274453 36.412 35.67112992832631 139.73840516274453 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56109b23-6f09-41e4-a8a4-7f6a3a7e45af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56109b23-6f09-41e4-a8a4-7f6a3a7e45af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56109b23-6f09-41e4-a8a4-7f6a3a7e45af">
											<gml:posList>35.671170915455 139.73845306649966 32.058 35.671099093156364 139.7384748023571 32.058 35.671099093156364 139.7384748023571 30.524 35.671099093156364 139.7384748023571 15.2 35.671170915455 139.73845306649966 15.2 35.671170915455 139.73845306649966 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-181dd03c-f147-4ae4-bc81-4532519a72b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-181dd03c-f147-4ae4-bc81-4532519a72b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-181dd03c-f147-4ae4-bc81-4532519a72b7">
											<gml:posList>35.671141325614876 139.73839872026613 36.412 35.671141325614876 139.73839872026613 36.126 35.67113147612597 139.73840191328125 36.126 35.67113147612597 139.73840191328125 36.412 35.671141325614876 139.73839872026613 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07170b76-f8bc-4e6d-b13b-d348ba2ef2b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07170b76-f8bc-4e6d-b13b-d348ba2ef2b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07170b76-f8bc-4e6d-b13b-d348ba2ef2b7">
											<gml:posList>35.67113979584274 139.7384019697085 31.793 35.67114050148203 139.73840522755034 31.793 35.67114050148203 139.73840522755034 36.412 35.67113979584274 139.7384019697085 36.412 35.67113979584274 139.7384019697085 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a82ccb6f-0c40-446b-b05f-055ef1a03788">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a82ccb6f-0c40-446b-b05f-055ef1a03788">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a82ccb6f-0c40-446b-b05f-055ef1a03788">
											<gml:posList>35.67113576160392 139.73834978041847 32.058 35.67113576160392 139.73834978041847 31.793 35.67114480008309 139.7383468755631 31.793 35.67114480008309 139.7383468755631 32.058 35.67113576160392 139.73834978041847 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a61bf948-dbb1-4710-a641-17ec5c5d128b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a61bf948-dbb1-4710-a641-17ec5c5d128b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a61bf948-dbb1-4710-a641-17ec5c5d128b">
											<gml:posList>35.67113287325687 139.73836762371644 36.412 35.67113287325687 139.73836762371644 36.126 35.671149120866275 139.73836236849442 36.126 35.671149120866275 139.73836236849442 36.412 35.67113287325687 139.73836762371644 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6188ce4a-970f-4027-8b93-a185db0e6c73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6188ce4a-970f-4027-8b93-a185db0e6c73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6188ce4a-970f-4027-8b93-a185db0e6c73">
											<gml:posList>35.671147031791136 139.7383421892604 32.058 35.671147031791136 139.7383421892604 15.2 35.67113495645493 139.73834606979432 15.2 35.67113495645493 139.73834606979432 31.447 35.67113495645493 139.73834606979432 32.058 35.671147031791136 139.7383421892604 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7931159-e73c-40f7-b768-57b1b792b03f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7931159-e73c-40f7-b768-57b1b792b03f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7931159-e73c-40f7-b768-57b1b792b03f">
											<gml:posList>35.67114050148203 139.73840522755034 31.793 35.67114224346403 139.73840818591344 31.793 35.67114224346403 139.73840818591344 36.412 35.67114050148203 139.73840522755034 36.412 35.67114050148203 139.73840522755034 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d02d725a-561e-44a3-a2b7-552f692871ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d02d725a-561e-44a3-a2b7-552f692871ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d02d725a-561e-44a3-a2b7-552f692871ef">
											<gml:posList>35.67113208708551 139.73836511712327 31.793 35.67113208708551 139.73836511712327 36.412 35.6711506776698 139.73835910797257 36.412 35.6711506776698 139.73835910797257 32.058 35.67114764982626 139.73836008363938 32.058 35.67114764982626 139.73836008363938 31.793 35.67113208708551 139.73836511712327 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57cc9daf-1347-4e11-aa1e-a014407e0510">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57cc9daf-1347-4e11-aa1e-a014407e0510">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57cc9daf-1347-4e11-aa1e-a014407e0510">
											<gml:posList>35.671142492608695 139.73840407637095 36.412 35.671142492608695 139.73840407637095 36.126 35.671141325614876 139.73839872026613 36.126 35.671141325614876 139.73839872026613 36.412 35.671142492608695 139.73840407637095 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5b0ced0-d1a0-4665-9a9e-47a9ed57ce05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5b0ced0-d1a0-4665-9a9e-47a9ed57ce05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5b0ced0-d1a0-4665-9a9e-47a9ed57ce05">
											<gml:posList>35.67114224346403 139.73840818591344 31.793 35.6711445975169 139.73841004996194 31.793 35.6711445975169 139.73841004996194 36.412 35.67114224346403 139.73840818591344 36.412 35.67114224346403 139.73840818591344 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74a1c2d3-d203-4ed9-abbe-93e63d4e92e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74a1c2d3-d203-4ed9-abbe-93e63d4e92e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74a1c2d3-d203-4ed9-abbe-93e63d4e92e3">
											<gml:posList>35.6711445975169 139.73841004996194 31.793 35.671146635358035 139.73841098649024 31.793 35.671146635358035 139.73841098649024 36.412 35.6711445975169 139.73841004996194 36.412 35.6711445975169 139.73841004996194 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bbb64578-74df-4ec9-b35f-3d3466b35998">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbb64578-74df-4ec9-b35f-3d3466b35998">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbb64578-74df-4ec9-b35f-3d3466b35998">
											<gml:posList>35.67114480008309 139.7383468755631 32.058 35.67114480008309 139.7383468755631 31.793 35.67114764982626 139.73836008363938 31.793 35.67114764982626 139.73836008363938 32.058 35.67114480008309 139.7383468755631 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f2d6de9-5215-4aa2-808e-d5323beff5c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f2d6de9-5215-4aa2-808e-d5323beff5c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f2d6de9-5215-4aa2-808e-d5323beff5c7">
											<gml:posList>35.6711494723725 139.73840805584462 36.412 35.6711494723725 139.73840805584462 36.126 35.67114693969976 139.7384082908169 36.126 35.67114693969976 139.7384082908169 36.412 35.6711494723725 139.73840805584462 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa03fe1a-e3ee-4561-ba29-eb7e630d33ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa03fe1a-e3ee-4561-ba29-eb7e630d33ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa03fe1a-e3ee-4561-ba29-eb7e630d33ac">
											<gml:posList>35.671146635358035 139.73841098649024 31.793 35.67114985302131 139.73841068442889 31.793 35.67114985302131 139.73841068442889 36.412 35.671146635358035 139.73841098649024 36.412 35.671146635358035 139.73841098649024 31.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b06ce0c-d479-4ce3-bfb6-976530787b80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b06ce0c-d479-4ce3-bfb6-976530787b80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b06ce0c-d479-4ce3-bfb6-976530787b80">
											<gml:posList>35.671149120866275 139.73836236849442 36.412 35.671149120866275 139.73836236849442 36.126 35.67115834863221 139.73840518432647 36.126 35.67115834863221 139.73840518432647 36.412 35.671149120866275 139.73836236849442 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80cadf31-1535-4457-9d9b-ca6ea6d7318c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80cadf31-1535-4457-9d9b-ca6ea6d7318c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80cadf31-1535-4457-9d9b-ca6ea6d7318c">
											<gml:posList>35.67115834863221 139.73840518432647 36.412 35.67115834863221 139.73840518432647 36.126 35.6711494723725 139.73840805584462 36.126 35.6711494723725 139.73840805584462 36.412 35.67115834863221 139.73840518432647 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-327da49d-3002-4dfc-b367-ebcc682ffe0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-327da49d-3002-4dfc-b367-ebcc682ffe0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-327da49d-3002-4dfc-b367-ebcc682ffe0b">
											<gml:posList>35.67116100917776 139.73840708115145 36.412 35.67114985302131 139.73841068442889 36.412 35.67114985302131 139.73841068442889 31.793 35.671157981333835 139.7384080568166 31.793 35.671157981333835 139.7384080568166 32.058 35.67116100917776 139.73840708115145 32.058 35.67116100917776 139.73840708115145 36.412</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3a924b6-e06a-4535-a7a7-4ef374df859a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3a924b6-e06a-4535-a7a7-4ef374df859a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3a924b6-e06a-4535-a7a7-4ef374df859a">
											<gml:posList>35.6711506776698 139.73835910797257 32.058 35.6711506776698 139.73835910797257 36.412 35.67116100917776 139.73840708115145 36.412 35.67116100917776 139.73840708115145 32.058 35.671170915455 139.73845306649966 32.058 35.671170915455 139.73845306649966 15.2 35.671147031791136 139.7383421892604 15.2 35.671147031791136 139.7383421892604 32.058 35.6711506776698 139.73835910797257 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d64f9ea2-a372-457e-8379-d632f1e290e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d64f9ea2-a372-457e-8379-d632f1e290e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d64f9ea2-a372-457e-8379-d632f1e290e3">
											<gml:posList>35.671157981333835 139.7384080568166 32.058 35.671157981333835 139.7384080568166 31.793 35.67116707339898 139.73845026526902 31.793 35.67116707339898 139.73845026526902 32.058 35.671157981333835 139.7384080568166 32.058</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9701</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">152.4774</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>