<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_17d6faf3-869e-4586-8475-16ad8f1aaae2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">36.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67057183714215 139.74985884502902 0 35.67055163935333 139.74984870347626 0 35.67055298865489 139.74984472540902 0 35.67042197364481 139.74977913655167 0 35.67039336791759 139.74986267610404 0 35.670546834937916 139.74993961939052 0 35.67054930857866 139.74993220476128 0 35.6705499832079 139.7499301825896 0 35.67055994069352 139.74990028098392 0 35.670563493743636 139.74988963971356 0 35.67056142888113 139.74988860351175 0 35.67057183714215 139.74985884502902 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057183714215 139.74985884502902 6.489 35.67056142888113 139.74988860351175 6.489 35.670563493743636 139.74988963971356 6.489 35.67055994069352 139.74990028098392 6.489 35.6705499832079 139.7499301825896 6.489 35.67054930857866 139.74993220476128 6.489 35.670546834937916 139.74993961939052 6.489 35.67039336791759 139.74986267610404 6.489 35.67042197364481 139.74977913655167 6.489 35.67055298865489 139.74984472540902 6.489 35.67055163935333 139.74984870347626 6.489 35.67057183714215 139.74985884502902 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057183714215 139.74985884502902 6.489 35.67055163935333 139.74984870347626 6.489 35.67055163935333 139.74984870347626 38.98 35.67057183714215 139.74985884502902 38.98 35.67057183714215 139.74985884502902 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055163935333 139.74984870347626 6.489 35.67055298865489 139.74984472540902 6.489 35.67055298865489 139.74984472540902 38.98 35.67055163935333 139.74984870347626 38.98 35.67055163935333 139.74984870347626 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055298865489 139.74984472540902 6.489 35.67042197364481 139.74977913655167 6.489 35.67042197364481 139.74977913655167 38.98 35.67055298865489 139.74984472540902 38.98 35.67055298865489 139.74984472540902 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67042197364481 139.74977913655167 6.489 35.67039336791759 139.74986267610404 6.489 35.67039336791759 139.74986267610404 38.98 35.67042197364481 139.74977913655167 38.98 35.67042197364481 139.74977913655167 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039336791759 139.74986267610404 6.489 35.670546834937916 139.74993961939052 6.489 35.670546834937916 139.74993961939052 38.98 35.67039336791759 139.74986267610404 38.98 35.67039336791759 139.74986267610404 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670546834937916 139.74993961939052 6.489 35.67054930857866 139.74993220476128 6.489 35.67054930857866 139.74993220476128 38.98 35.670546834937916 139.74993961939052 38.98 35.670546834937916 139.74993961939052 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054930857866 139.74993220476128 6.489 35.6705499832079 139.7499301825896 6.489 35.6705499832079 139.7499301825896 38.98 35.67054930857866 139.74993220476128 38.98 35.67054930857866 139.74993220476128 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6705499832079 139.7499301825896 6.489 35.67055994069352 139.74990028098392 6.489 35.67055994069352 139.74990028098392 38.98 35.6705499832079 139.7499301825896 38.98 35.6705499832079 139.7499301825896 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67055994069352 139.74990028098392 6.489 35.670563493743636 139.74988963971356 6.489 35.670563493743636 139.74988963971356 38.98 35.67055994069352 139.74990028098392 38.98 35.67055994069352 139.74990028098392 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670563493743636 139.74988963971356 6.489 35.67056142888113 139.74988860351175 6.489 35.67056142888113 139.74988860351175 38.98 35.670563493743636 139.74988963971356 38.98 35.670563493743636 139.74988963971356 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056142888113 139.74988860351175 6.489 35.67057183714215 139.74985884502902 6.489 35.67057183714215 139.74985884502902 38.98 35.67056142888113 139.74988860351175 38.98 35.67056142888113 139.74988860351175 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67057183714215 139.74985884502902 38.98 35.67055163935333 139.74984870347626 38.98 35.67055298865489 139.74984472540902 38.98 35.67042197364481 139.74977913655167 38.98 35.67039336791759 139.74986267610404 38.98 35.670546834937916 139.74993961939052 38.98 35.67054930857866 139.74993220476128 38.98 35.6705499832079 139.7499301825896 38.98 35.67055994069352 139.74990028098392 38.98 35.670563493743636 139.74988963971356 38.98 35.67056142888113 139.74988860351175 38.98 35.67057183714215 139.74985884502902 38.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7e6b59d6-7cba-4c2c-83cd-57b1e655e44f"/>
							<gml:surfaceMember xlink:href="#poly-e3c0aed2-fdaa-46e5-afad-4ee532b94132"/>
							<gml:surfaceMember xlink:href="#poly-2883dced-fc29-46bc-af82-8a0aecb73dc8"/>
							<gml:surfaceMember xlink:href="#poly-8bcec6c8-2759-473b-b88c-a77d2e954729"/>
							<gml:surfaceMember xlink:href="#poly-340f4569-1df7-41a2-89f4-9229019a7d4c"/>
							<gml:surfaceMember xlink:href="#poly-7843d00e-f501-4e57-8030-36da5abb5f02"/>
							<gml:surfaceMember xlink:href="#poly-da81770d-7fc8-43df-9de1-cdbbb46ed4f2"/>
							<gml:surfaceMember xlink:href="#poly-282be212-7910-4773-8487-df3a25b08815"/>
							<gml:surfaceMember xlink:href="#poly-ed4f7717-602d-46ef-8833-39ac8cf30da2"/>
							<gml:surfaceMember xlink:href="#poly-74bd4e89-d25f-4665-ba9f-05615351d80f"/>
							<gml:surfaceMember xlink:href="#poly-61b6895e-640e-4865-b8f7-e09cdae7b587"/>
							<gml:surfaceMember xlink:href="#poly-f960f8a7-3ea5-4e68-9e3f-99edf317768d"/>
							<gml:surfaceMember xlink:href="#poly-12203b0e-36d4-4dce-8ef5-6080dddf1681"/>
							<gml:surfaceMember xlink:href="#poly-cbfbb6c9-26e1-4d68-9347-59d540387809"/>
							<gml:surfaceMember xlink:href="#poly-75d49d8c-2290-4b46-ad2e-45783c0d7ee4"/>
							<gml:surfaceMember xlink:href="#poly-0c4299a0-07ca-4194-bbd0-6e631e79fcd8"/>
							<gml:surfaceMember xlink:href="#poly-c3fd856e-c76a-4455-b7e3-13e8401a98f1"/>
							<gml:surfaceMember xlink:href="#poly-46f1cf8c-7383-4eae-9cf0-8339760ef8fa"/>
							<gml:surfaceMember xlink:href="#poly-148e568e-ab74-4477-83e3-ae5880a674c5"/>
							<gml:surfaceMember xlink:href="#poly-0727ec83-a01d-48c6-8dd2-60610a9bbff8"/>
							<gml:surfaceMember xlink:href="#poly-6f18579b-c73c-4e81-90a5-d98a43ea3151"/>
							<gml:surfaceMember xlink:href="#poly-240e0cd6-b088-438f-8210-4519186fc7de"/>
							<gml:surfaceMember xlink:href="#poly-56cc5805-dd9a-4ae8-bbb0-19e8bb186186"/>
							<gml:surfaceMember xlink:href="#poly-5f685c43-94b5-4576-97e8-f8c1b2c6b64a"/>
							<gml:surfaceMember xlink:href="#poly-c4a140d1-a498-4b5b-b5ac-12533ecaf6bb"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7e6b59d6-7cba-4c2c-83cd-57b1e655e44f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e6b59d6-7cba-4c2c-83cd-57b1e655e44f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e6b59d6-7cba-4c2c-83cd-57b1e655e44f">
											<gml:posList>35.67056142888109 139.74988860351172 6.489 35.670563493743614 139.74988963971353 6.489 35.670559949707226 139.74990028097454 6.489 35.67054998320788 139.7499301825896 6.489 35.67054930857866 139.74993220476128 6.489 35.6705468349379 139.7499396193905 6.489 35.67039336791758 139.74986267610402 6.489 35.670421973644785 139.74977913655164 6.489 35.670552988654876 139.74984472540902 6.489 35.67055163935333 139.74984870347626 6.489 35.67057183714215 139.74985884502902 6.489 35.67056142888109 139.74988860351172 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e3c0aed2-fdaa-46e5-afad-4ee532b94132">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3c0aed2-fdaa-46e5-afad-4ee532b94132">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3c0aed2-fdaa-46e5-afad-4ee532b94132">
											<gml:posList>35.67047856124983 139.74985624685013 39 35.670431890956515 139.74979530899847 39 35.67040957431172 139.74986225052018 39 35.67047005196081 139.7498817836459 39 35.67047856124983 139.74985624685013 39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2883dced-fc29-46bc-af82-8a0aecb73dc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2883dced-fc29-46bc-af82-8a0aecb73dc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2883dced-fc29-46bc-af82-8a0aecb73dc8">
											<gml:posList>35.6705468349379 139.7499396193905 37 35.67054930857866 139.74993220476128 37 35.67040957431172 139.74986225052018 37 35.670431890956515 139.74979530899847 37 35.67055129223691 139.74985507754351 37 35.67054316974224 139.7498794651466 37 35.67056142888109 139.74988860351172 37 35.67057183714215 139.74985884502902 37 35.67055163935333 139.74984870347626 37 35.670552988654876 139.74984472540902 37 35.670421973644785 139.74977913655164 37 35.67039336791758 139.74986267610402 37 35.6705468349379 139.7499396193905 37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8bcec6c8-2759-473b-b88c-a77d2e954729">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bcec6c8-2759-473b-b88c-a77d2e954729">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bcec6c8-2759-473b-b88c-a77d2e954729">
											<gml:posList>35.670498707544986 139.74989613607227 39 35.67047005196081 139.7498817836459 39 35.67040957431172 139.74986225052018 39 35.67054930857866 139.74993220476128 39 35.67054998320788 139.7499301825896 39 35.67051102136674 139.74991068225268 39 35.67052098786133 139.74988078064973 39 35.670559949707226 139.74990028097454 39 35.670563493743614 139.74988963971353 39 35.67054316974224 139.7498794651466 39 35.67055129223691 139.74985507754351 39 35.670431890956515 139.74979530899847 39 35.67047856124983 139.74985624685013 39 35.67050721682934 139.74987058822262 39 35.670498707544986 139.74989613607227 39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-340f4569-1df7-41a2-89f4-9229019a7d4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-340f4569-1df7-41a2-89f4-9229019a7d4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-340f4569-1df7-41a2-89f4-9229019a7d4c">
											<gml:posList>35.670498707544986 139.74989613607227 41.25 35.67050721682934 139.74987058822262 41.25 35.67047856124983 139.74985624685013 41.25 35.67047005196081 139.7498817836459 41.25 35.670498707544986 139.74989613607227 41.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7843d00e-f501-4e57-8030-36da5abb5f02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7843d00e-f501-4e57-8030-36da5abb5f02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7843d00e-f501-4e57-8030-36da5abb5f02">
											<gml:posList>35.670559949707226 139.74990028097454 43.25 35.67052098786133 139.74988078064973 43.25 35.67051102136674 139.74991068225268 43.25 35.67054998320788 139.7499301825896 43.25 35.670559949707226 139.74990028097454 43.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da81770d-7fc8-43df-9de1-cdbbb46ed4f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da81770d-7fc8-43df-9de1-cdbbb46ed4f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da81770d-7fc8-43df-9de1-cdbbb46ed4f2">
											<gml:posList>35.670552988654876 139.74984472540902 6.489 35.670421973644785 139.74977913655164 6.489 35.670421973644785 139.74977913655164 37 35.670552988654876 139.74984472540902 37 35.670552988654876 139.74984472540902 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-282be212-7910-4773-8487-df3a25b08815">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-282be212-7910-4773-8487-df3a25b08815">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-282be212-7910-4773-8487-df3a25b08815">
											<gml:posList>35.670421973644785 139.74977913655164 6.489 35.67039336791758 139.74986267610402 6.489 35.67039336791758 139.74986267610402 37 35.670421973644785 139.74977913655164 37 35.670421973644785 139.74977913655164 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed4f7717-602d-46ef-8833-39ac8cf30da2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed4f7717-602d-46ef-8833-39ac8cf30da2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed4f7717-602d-46ef-8833-39ac8cf30da2">
											<gml:posList>35.670431890956515 139.74979530899847 37 35.670431890956515 139.74979530899847 39 35.67055129223691 139.74985507754351 39 35.67055129223691 139.74985507754351 37 35.670431890956515 139.74979530899847 37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74bd4e89-d25f-4665-ba9f-05615351d80f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74bd4e89-d25f-4665-ba9f-05615351d80f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74bd4e89-d25f-4665-ba9f-05615351d80f">
											<gml:posList>35.67040957431172 139.74986225052018 37 35.67040957431172 139.74986225052018 39 35.670431890956515 139.74979530899847 39 35.670431890956515 139.74979530899847 37 35.67040957431172 139.74986225052018 37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61b6895e-640e-4865-b8f7-e09cdae7b587">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61b6895e-640e-4865-b8f7-e09cdae7b587">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61b6895e-640e-4865-b8f7-e09cdae7b587">
											<gml:posList>35.67055163935333 139.74984870347626 6.489 35.670552988654876 139.74984472540902 6.489 35.670552988654876 139.74984472540902 37 35.67055163935333 139.74984870347626 37 35.67055163935333 139.74984870347626 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f960f8a7-3ea5-4e68-9e3f-99edf317768d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f960f8a7-3ea5-4e68-9e3f-99edf317768d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f960f8a7-3ea5-4e68-9e3f-99edf317768d">
											<gml:posList>35.67039336791758 139.74986267610402 6.489 35.6705468349379 139.7499396193905 6.489 35.6705468349379 139.7499396193905 37 35.67039336791758 139.74986267610402 37 35.67039336791758 139.74986267610402 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12203b0e-36d4-4dce-8ef5-6080dddf1681">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12203b0e-36d4-4dce-8ef5-6080dddf1681">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12203b0e-36d4-4dce-8ef5-6080dddf1681">
											<gml:posList>35.67047005196081 139.7498817836459 39 35.67047005196081 139.7498817836459 41.25 35.67047856124983 139.74985624685013 41.25 35.67047856124983 139.74985624685013 39 35.67047005196081 139.7498817836459 39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbfbb6c9-26e1-4d68-9347-59d540387809">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbfbb6c9-26e1-4d68-9347-59d540387809">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbfbb6c9-26e1-4d68-9347-59d540387809">
											<gml:posList>35.67054930857866 139.74993220476128 37 35.67054930857866 139.74993220476128 39 35.67040957431172 139.74986225052018 39 35.67040957431172 139.74986225052018 37 35.67054930857866 139.74993220476128 37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75d49d8c-2290-4b46-ad2e-45783c0d7ee4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75d49d8c-2290-4b46-ad2e-45783c0d7ee4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75d49d8c-2290-4b46-ad2e-45783c0d7ee4">
											<gml:posList>35.670498707544986 139.74989613607227 39 35.670498707544986 139.74989613607227 41.25 35.67047005196081 139.7498817836459 41.25 35.67047005196081 139.7498817836459 39 35.670498707544986 139.74989613607227 39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c4299a0-07ca-4194-bbd0-6e631e79fcd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c4299a0-07ca-4194-bbd0-6e631e79fcd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c4299a0-07ca-4194-bbd0-6e631e79fcd8">
											<gml:posList>35.67047856124983 139.74985624685013 39 35.67047856124983 139.74985624685013 41.25 35.67050721682934 139.74987058822262 41.25 35.67050721682934 139.74987058822262 39 35.67047856124983 139.74985624685013 39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3fd856e-c76a-4455-b7e3-13e8401a98f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3fd856e-c76a-4455-b7e3-13e8401a98f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3fd856e-c76a-4455-b7e3-13e8401a98f1">
											<gml:posList>35.67050721682934 139.74987058822262 39 35.67050721682934 139.74987058822262 41.25 35.670498707544986 139.74989613607227 41.25 35.670498707544986 139.74989613607227 39 35.67050721682934 139.74987058822262 39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46f1cf8c-7383-4eae-9cf0-8339760ef8fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46f1cf8c-7383-4eae-9cf0-8339760ef8fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46f1cf8c-7383-4eae-9cf0-8339760ef8fa">
											<gml:posList>35.67051102136674 139.74991068225268 39 35.67051102136674 139.74991068225268 43.25 35.67052098786133 139.74988078064973 43.25 35.67052098786133 139.74988078064973 39 35.67051102136674 139.74991068225268 39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-148e568e-ab74-4477-83e3-ae5880a674c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-148e568e-ab74-4477-83e3-ae5880a674c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-148e568e-ab74-4477-83e3-ae5880a674c5">
											<gml:posList>35.67054998320788 139.7499301825896 39 35.67054998320788 139.7499301825896 43.25 35.67051102136674 139.74991068225268 43.25 35.67051102136674 139.74991068225268 39 35.67054998320788 139.7499301825896 39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0727ec83-a01d-48c6-8dd2-60610a9bbff8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0727ec83-a01d-48c6-8dd2-60610a9bbff8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0727ec83-a01d-48c6-8dd2-60610a9bbff8">
											<gml:posList>35.67052098786133 139.74988078064973 39 35.67052098786133 139.74988078064973 43.25 35.670559949707226 139.74990028097454 43.25 35.670559949707226 139.74990028097454 39 35.67052098786133 139.74988078064973 39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f18579b-c73c-4e81-90a5-d98a43ea3151">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f18579b-c73c-4e81-90a5-d98a43ea3151">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f18579b-c73c-4e81-90a5-d98a43ea3151">
											<gml:posList>35.67055129223691 139.74985507754351 37 35.67055129223691 139.74985507754351 39 35.67054316974224 139.7498794651466 39 35.67054316974224 139.7498794651466 37 35.67055129223691 139.74985507754351 37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-240e0cd6-b088-438f-8210-4519186fc7de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-240e0cd6-b088-438f-8210-4519186fc7de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-240e0cd6-b088-438f-8210-4519186fc7de">
											<gml:posList>35.670563493743614 139.74988963971353 6.489 35.67056142888109 139.74988860351172 6.489 35.67056142888109 139.74988860351172 37 35.67054316974224 139.7498794651466 37 35.67054316974224 139.7498794651466 39 35.670563493743614 139.74988963971353 39 35.670563493743614 139.74988963971353 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56cc5805-dd9a-4ae8-bbb0-19e8bb186186">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56cc5805-dd9a-4ae8-bbb0-19e8bb186186">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56cc5805-dd9a-4ae8-bbb0-19e8bb186186">
											<gml:posList>35.670559949707226 139.74990028097454 39 35.670559949707226 139.74990028097454 43.25 35.67054998320788 139.7499301825896 43.25 35.67054998320788 139.7499301825896 39 35.67054930857866 139.74993220476128 39 35.67054930857866 139.74993220476128 37 35.6705468349379 139.7499396193905 37 35.6705468349379 139.7499396193905 6.489 35.67054930857866 139.74993220476128 6.489 35.67054998320788 139.7499301825896 6.489 35.670559949707226 139.74990028097454 6.489 35.670563493743614 139.74988963971353 6.489 35.670563493743614 139.74988963971353 39 35.670559949707226 139.74990028097454 39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f685c43-94b5-4576-97e8-f8c1b2c6b64a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f685c43-94b5-4576-97e8-f8c1b2c6b64a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f685c43-94b5-4576-97e8-f8c1b2c6b64a">
											<gml:posList>35.67057183714215 139.74985884502902 6.489 35.67055163935333 139.74984870347626 6.489 35.67055163935333 139.74984870347626 37 35.67057183714215 139.74985884502902 37 35.67057183714215 139.74985884502902 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4a140d1-a498-4b5b-b5ac-12533ecaf6bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4a140d1-a498-4b5b-b5ac-12533ecaf6bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4a140d1-a498-4b5b-b5ac-12533ecaf6bb">
											<gml:posList>35.67056142888109 139.74988860351172 6.489 35.67057183714215 139.74985884502902 6.489 35.67057183714215 139.74985884502902 37 35.67056142888109 139.74988860351172 37 35.67056142888109 139.74988860351172 6.489</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4463</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">148.89585</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>8</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>