<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_187bf82a-ffaf-44ea-adb0-e2af3653a167">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66925457139683 139.73981545207704 0 35.66925348828826 139.73980196604714 0 35.66922839641372 139.7398049998563 0 35.66922947952195 139.739818485882 0 35.66925457139683 139.73981545207704 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925457139683 139.73981545207704 10.26 35.66922947952195 139.739818485882 10.26 35.66922839641372 139.7398049998563 10.26 35.66925348828826 139.73980196604714 10.26 35.66925457139683 139.73981545207704 10.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925457139683 139.73981545207704 10.26 35.66925348828826 139.73980196604714 10.26 35.66925348828826 139.73980196604714 13.26 35.66925457139683 139.73981545207704 13.26 35.66925457139683 139.73981545207704 10.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925348828826 139.73980196604714 10.26 35.66922839641372 139.7398049998563 10.26 35.66922839641372 139.7398049998563 13.26 35.66925348828826 139.73980196604714 13.26 35.66925348828826 139.73980196604714 10.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922839641372 139.7398049998563 10.26 35.66922947952195 139.739818485882 10.26 35.66922947952195 139.739818485882 13.26 35.66922839641372 139.7398049998563 13.26 35.66922839641372 139.7398049998563 10.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922947952195 139.739818485882 10.26 35.66925457139683 139.73981545207704 10.26 35.66925457139683 139.73981545207704 13.26 35.66922947952195 139.739818485882 13.26 35.66922947952195 139.739818485882 10.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925457139683 139.73981545207704 13.26 35.66925348828826 139.73980196604714 13.26 35.66922839641372 139.7398049998563 13.26 35.66922947952195 139.739818485882 13.26 35.66925457139683 139.73981545207704 13.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c3b3c0ac-78ff-4d03-a94d-bd05af13afa4"/>
							<gml:surfaceMember xlink:href="#poly-4997cec5-3573-48b6-8bfd-354c6e0866ca"/>
							<gml:surfaceMember xlink:href="#poly-23ab8007-be17-4601-a109-99859aade697"/>
							<gml:surfaceMember xlink:href="#poly-099cd5a0-b394-457b-b974-c38fb6bcc4f5"/>
							<gml:surfaceMember xlink:href="#poly-f15ddd4f-1cd4-4696-8908-8f3242689261"/>
							<gml:surfaceMember xlink:href="#poly-3530afd2-e21a-447f-ab66-40c7d1a87aa4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c3b3c0ac-78ff-4d03-a94d-bd05af13afa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3b3c0ac-78ff-4d03-a94d-bd05af13afa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3b3c0ac-78ff-4d03-a94d-bd05af13afa4">
											<gml:posList>35.669254571396856 139.73981545207704 10.26 35.66922947952195 139.739818485882 10.26 35.669228396413715 139.7398049998563 10.26 35.66925348828826 139.73980196604714 10.26 35.669254571396856 139.73981545207704 10.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4997cec5-3573-48b6-8bfd-354c6e0866ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4997cec5-3573-48b6-8bfd-354c6e0866ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4997cec5-3573-48b6-8bfd-354c6e0866ca">
											<gml:posList>35.66922947952195 139.739818485882 13.191 35.669254571396856 139.73981545207704 13.191 35.66925348828826 139.73980196604714 13.191 35.669228396413715 139.7398049998563 13.191 35.66922947952195 139.739818485882 13.191</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23ab8007-be17-4601-a109-99859aade697">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23ab8007-be17-4601-a109-99859aade697">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23ab8007-be17-4601-a109-99859aade697">
											<gml:posList>35.66925348828826 139.73980196604714 10.26 35.669228396413715 139.7398049998563 10.26 35.669228396413715 139.7398049998563 13.191 35.66925348828826 139.73980196604714 13.191 35.66925348828826 139.73980196604714 10.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-099cd5a0-b394-457b-b974-c38fb6bcc4f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-099cd5a0-b394-457b-b974-c38fb6bcc4f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-099cd5a0-b394-457b-b974-c38fb6bcc4f5">
											<gml:posList>35.669254571396856 139.73981545207704 10.26 35.66925348828826 139.73980196604714 10.26 35.66925348828826 139.73980196604714 13.191 35.669254571396856 139.73981545207704 13.191 35.669254571396856 139.73981545207704 10.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f15ddd4f-1cd4-4696-8908-8f3242689261">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f15ddd4f-1cd4-4696-8908-8f3242689261">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f15ddd4f-1cd4-4696-8908-8f3242689261">
											<gml:posList>35.669228396413715 139.7398049998563 10.26 35.66922947952195 139.739818485882 10.26 35.66922947952195 139.739818485882 13.191 35.669228396413715 139.7398049998563 13.191 35.669228396413715 139.7398049998563 10.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3530afd2-e21a-447f-ab66-40c7d1a87aa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3530afd2-e21a-447f-ab66-40c7d1a87aa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3530afd2-e21a-447f-ab66-40c7d1a87aa4">
											<gml:posList>35.66922947952195 139.739818485882 10.26 35.669254571396856 139.73981545207704 10.26 35.669254571396856 139.73981545207704 13.191 35.66922947952195 139.739818485882 13.191 35.66922947952195 139.739818485882 10.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9292</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.85</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>