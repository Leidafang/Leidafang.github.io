<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_18d6444c-a844-4f22-9b3c-3759d0434ce3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">31.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66919679840786 139.7415913341068 0 35.66922333321446 139.74158920498698 0 35.66924430418478 139.74156031752437 0 35.66928227337874 139.74160020574726 0 35.66939324270297 139.74161369865965 0 35.66940359477024 139.74159568163398 0 35.669369258074966 139.7414848178724 0 35.66923836749828 139.7413520832 0 35.66921673683726 139.74135509046087 0 35.66913574414226 139.74152661865733 0 35.66919679840786 139.7415913341068 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919679840786 139.7415913341068 9.946 35.66913574414226 139.74152661865733 9.946 35.66921673683726 139.74135509046087 9.946 35.66923836749828 139.7413520832 9.946 35.669369258074966 139.7414848178724 9.946 35.66940359477024 139.74159568163398 9.946 35.66939324270297 139.74161369865965 9.946 35.66928227337874 139.74160020574726 9.946 35.66924430418478 139.74156031752437 9.946 35.66922333321446 139.74158920498698 9.946 35.66919679840786 139.7415913341068 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919679840786 139.7415913341068 9.946 35.66922333321446 139.74158920498698 9.946 35.66922333321446 139.74158920498698 41.23 35.66919679840786 139.7415913341068 41.23 35.66919679840786 139.7415913341068 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66922333321446 139.74158920498698 9.946 35.66924430418478 139.74156031752437 9.946 35.66924430418478 139.74156031752437 41.23 35.66922333321446 139.74158920498698 41.23 35.66922333321446 139.74158920498698 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924430418478 139.74156031752437 9.946 35.66928227337874 139.74160020574726 9.946 35.66928227337874 139.74160020574726 41.23 35.66924430418478 139.74156031752437 41.23 35.66924430418478 139.74156031752437 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66928227337874 139.74160020574726 9.946 35.66939324270297 139.74161369865965 9.946 35.66939324270297 139.74161369865965 41.23 35.66928227337874 139.74160020574726 41.23 35.66928227337874 139.74160020574726 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66939324270297 139.74161369865965 9.946 35.66940359477024 139.74159568163398 9.946 35.66940359477024 139.74159568163398 41.23 35.66939324270297 139.74161369865965 41.23 35.66939324270297 139.74161369865965 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66940359477024 139.74159568163398 9.946 35.669369258074966 139.7414848178724 9.946 35.669369258074966 139.7414848178724 41.23 35.66940359477024 139.74159568163398 41.23 35.66940359477024 139.74159568163398 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669369258074966 139.7414848178724 9.946 35.66923836749828 139.7413520832 9.946 35.66923836749828 139.7413520832 41.23 35.669369258074966 139.7414848178724 41.23 35.669369258074966 139.7414848178724 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923836749828 139.7413520832 9.946 35.66921673683726 139.74135509046087 9.946 35.66921673683726 139.74135509046087 41.23 35.66923836749828 139.7413520832 41.23 35.66923836749828 139.7413520832 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921673683726 139.74135509046087 9.946 35.66913574414226 139.74152661865733 9.946 35.66913574414226 139.74152661865733 41.23 35.66921673683726 139.74135509046087 41.23 35.66921673683726 139.74135509046087 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913574414226 139.74152661865733 9.946 35.66919679840786 139.7415913341068 9.946 35.66919679840786 139.7415913341068 41.23 35.66913574414226 139.74152661865733 41.23 35.66913574414226 139.74152661865733 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919679840786 139.7415913341068 41.23 35.66922333321446 139.74158920498698 41.23 35.66924430418478 139.74156031752437 41.23 35.66928227337874 139.74160020574726 41.23 35.66939324270297 139.74161369865965 41.23 35.66940359477024 139.74159568163398 41.23 35.669369258074966 139.7414848178724 41.23 35.66923836749828 139.7413520832 41.23 35.66921673683726 139.74135509046087 41.23 35.66913574414226 139.74152661865733 41.23 35.66919679840786 139.7415913341068 41.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9ad05aa0-7feb-4b1b-bb1d-177fb4b16521"/>
							<gml:surfaceMember xlink:href="#poly-a689952b-ff12-4772-99af-bff123f38ad3"/>
							<gml:surfaceMember xlink:href="#poly-17319fb6-5ef3-4d61-85d3-c34bb93700d9"/>
							<gml:surfaceMember xlink:href="#poly-e1b535f9-7612-4016-9704-d48ae8d0f773"/>
							<gml:surfaceMember xlink:href="#poly-fb5d8a5a-9ba7-4103-b3d3-30cee0e80c1a"/>
							<gml:surfaceMember xlink:href="#poly-dd1ace8d-c9da-452f-acf8-ddbb125c7992"/>
							<gml:surfaceMember xlink:href="#poly-5d24d501-ca18-48db-89b7-e31b26b6ed40"/>
							<gml:surfaceMember xlink:href="#poly-bbd304d9-75ca-4a18-80c1-ee7f0cc66a55"/>
							<gml:surfaceMember xlink:href="#poly-f85cfabf-b28a-4bad-8ef9-7e0d99f0f6f3"/>
							<gml:surfaceMember xlink:href="#poly-5e023da7-6965-4d1f-9081-3337c4c28697"/>
							<gml:surfaceMember xlink:href="#poly-91c568a5-3fa5-478e-841d-ea8034d47526"/>
							<gml:surfaceMember xlink:href="#poly-0eec8743-89e1-4867-bf38-b6c1172c9439"/>
							<gml:surfaceMember xlink:href="#poly-73aad5eb-3202-42fb-8a6c-9d05baa77537"/>
							<gml:surfaceMember xlink:href="#poly-36862ba6-84fa-477a-baec-3c0942923987"/>
							<gml:surfaceMember xlink:href="#poly-8c175bf4-500e-4c4f-b904-5c31ddffe513"/>
							<gml:surfaceMember xlink:href="#poly-5e3fb1a0-1a45-4de3-9533-dca0bb12e8e2"/>
							<gml:surfaceMember xlink:href="#poly-887df0a1-047f-424a-b24f-1b3e78ce941c"/>
							<gml:surfaceMember xlink:href="#poly-3879bea7-bc2b-40e2-a115-68bc5d0246bf"/>
							<gml:surfaceMember xlink:href="#poly-27fd2fd4-ad0f-4918-92a6-ca46a23e8482"/>
							<gml:surfaceMember xlink:href="#poly-69693d4b-b40f-4d21-85b5-73e5e5cf4d1c"/>
							<gml:surfaceMember xlink:href="#poly-994889cb-7b31-4f11-bf09-c4e7ec42f5ec"/>
							<gml:surfaceMember xlink:href="#poly-1a3542fd-fd18-4cc3-825b-49fddf8e80d1"/>
							<gml:surfaceMember xlink:href="#poly-4f20cb1e-422f-4539-a3f3-c0f00aaed101"/>
							<gml:surfaceMember xlink:href="#poly-4c4ce89e-3e4b-4d92-bc9a-ac90c6a04557"/>
							<gml:surfaceMember xlink:href="#poly-a52ad4de-b0ae-49f7-8537-e00e40e7dbe3"/>
							<gml:surfaceMember xlink:href="#poly-95d7333a-1d81-4652-93ea-621ff3c93097"/>
							<gml:surfaceMember xlink:href="#poly-364e49da-759d-496f-8e1f-deac7070780e"/>
							<gml:surfaceMember xlink:href="#poly-7dcdcacd-4f5e-4b78-a5ef-ee67251d27b8"/>
							<gml:surfaceMember xlink:href="#poly-403269cf-6a91-4a1b-bc26-ee76fc4a5650"/>
							<gml:surfaceMember xlink:href="#poly-11484bd6-ceb7-45ef-ada2-5b9baf4c585f"/>
							<gml:surfaceMember xlink:href="#poly-875da2c5-af6d-44d8-899a-60c1637909c8"/>
							<gml:surfaceMember xlink:href="#poly-47578756-9d2f-484d-abc6-27d966b1a697"/>
							<gml:surfaceMember xlink:href="#poly-47757b25-40b7-443f-95d1-e1fdf4df80fc"/>
							<gml:surfaceMember xlink:href="#poly-5077e302-c231-4253-97dc-36e8a5cabbc5"/>
							<gml:surfaceMember xlink:href="#poly-3db36de8-215e-471f-9df6-71369440adda"/>
							<gml:surfaceMember xlink:href="#poly-4509c934-bf31-40e5-a444-c630d72b22a9"/>
							<gml:surfaceMember xlink:href="#poly-a5df5fca-4132-4458-b068-85ebdc275bd0"/>
							<gml:surfaceMember xlink:href="#poly-b68cd6f9-f96e-4f03-a1ad-747720b9223c"/>
							<gml:surfaceMember xlink:href="#poly-8ec93d82-f3f4-42fb-9f56-31aec7d217ce"/>
							<gml:surfaceMember xlink:href="#poly-a8ee8382-cfb6-41a5-a516-3ad13d3b9db7"/>
							<gml:surfaceMember xlink:href="#poly-ecb6994d-358a-490d-8d79-f6c084740076"/>
							<gml:surfaceMember xlink:href="#poly-72073436-d34a-48f3-a099-a13d98b1fc27"/>
							<gml:surfaceMember xlink:href="#poly-76e8ee8a-fd90-45b8-90a5-7b46372065c4"/>
							<gml:surfaceMember xlink:href="#poly-a00f24a6-edfa-463f-bbd4-af85054258bc"/>
							<gml:surfaceMember xlink:href="#poly-8849e962-fd6b-4fdb-9c89-1981c52b7f78"/>
							<gml:surfaceMember xlink:href="#poly-4112e56f-c596-4dff-ba35-355e76b7d689"/>
							<gml:surfaceMember xlink:href="#poly-4fe1c58e-6d42-4467-b38c-4a2d06ede6e0"/>
							<gml:surfaceMember xlink:href="#poly-34f8fd06-37e9-4743-8e2c-5670dc81921a"/>
							<gml:surfaceMember xlink:href="#poly-f9b36eae-959f-4f6e-841a-6b5f6619d30d"/>
							<gml:surfaceMember xlink:href="#poly-c555705a-f212-4353-a768-17c5de05c59f"/>
							<gml:surfaceMember xlink:href="#poly-42dfa64c-4be1-4eaa-b244-10e763a2b460"/>
							<gml:surfaceMember xlink:href="#poly-cd80d7e7-c61d-4106-9873-4c5b8c28b52e"/>
							<gml:surfaceMember xlink:href="#poly-455e311c-365b-4ba4-9d91-58a786ca6663"/>
							<gml:surfaceMember xlink:href="#poly-9d37f936-7f42-4cc8-942c-efb4b4460969"/>
							<gml:surfaceMember xlink:href="#poly-7123e3b9-e021-40cf-b20b-d1e48539f508"/>
							<gml:surfaceMember xlink:href="#poly-18b017a9-5f13-4784-82c0-a7536543ee23"/>
							<gml:surfaceMember xlink:href="#poly-fe20aebc-e1a5-4dc3-b9db-e52e98a6d9fb"/>
							<gml:surfaceMember xlink:href="#poly-7762a224-0d6c-4342-84c6-07e51f5d0bb0"/>
							<gml:surfaceMember xlink:href="#poly-26bcfeae-1ea7-48b5-bdc9-eb967ad3bafd"/>
							<gml:surfaceMember xlink:href="#poly-60726b06-3a26-4c7a-80ba-cb29549f847f"/>
							<gml:surfaceMember xlink:href="#poly-5509853a-986e-4742-8d7e-a2a3e7fe4b77"/>
							<gml:surfaceMember xlink:href="#poly-4386efc2-d618-445a-822e-0ca22270c95c"/>
							<gml:surfaceMember xlink:href="#poly-975305ef-bacc-44f3-a69b-fde1173bd6fe"/>
							<gml:surfaceMember xlink:href="#poly-ce3a5127-5f55-440b-bab9-19240c30e41d"/>
							<gml:surfaceMember xlink:href="#poly-6b23a2ae-ba8f-4668-9140-53ae72097011"/>
							<gml:surfaceMember xlink:href="#poly-f1933888-48db-41a3-855a-3883242ce666"/>
							<gml:surfaceMember xlink:href="#poly-bd82c002-a1ff-449b-9586-ff8cb80f457f"/>
							<gml:surfaceMember xlink:href="#poly-bbbd9899-fe96-4fa5-9320-2288a56922bc"/>
							<gml:surfaceMember xlink:href="#poly-4d59f1b7-c2a2-4143-9d86-12f3cd5d7fec"/>
							<gml:surfaceMember xlink:href="#poly-dfabed3d-5b96-4100-b0b4-40207f5b6a4e"/>
							<gml:surfaceMember xlink:href="#poly-51548dc5-550d-4bb1-b05a-29815c8ce7ff"/>
							<gml:surfaceMember xlink:href="#poly-c0e64c9d-fd61-45ad-8edc-5d2031bd84dd"/>
							<gml:surfaceMember xlink:href="#poly-c7926ea9-5dba-43da-93a8-d65e906ab74f"/>
							<gml:surfaceMember xlink:href="#poly-c0bc594d-bc11-43ab-8b05-bd8e90b84a63"/>
							<gml:surfaceMember xlink:href="#poly-ffe97263-30df-48a8-9020-de29eeb0bf52"/>
							<gml:surfaceMember xlink:href="#poly-d4d34202-4606-4a19-8978-1ad2498df5f6"/>
							<gml:surfaceMember xlink:href="#poly-af4eddff-ed07-46e4-9706-3734c24397f5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_18d6444c-a844-4f22-9b3c-3759d0434ce3_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f007012-351f-4c12-aede-b696f310f5ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f007012-351f-4c12-aede-b696f310f5ff_0">
											<gml:posList>35.66916072898483 139.74151319114085 41.67 35.66914880594188 139.741504158047 43.5 35.66914880594188 139.741504158047 41.67 35.66916072898483 139.74151319114085 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a12e5246-d11c-42d7-94a2-f7a32e0b6db6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a12e5246-d11c-42d7-94a2-f7a32e0b6db6_0">
											<gml:posList>35.66916072898483 139.74151319114085 41.67 35.66916072898483 139.74151319114085 43.5 35.66914880594188 139.741504158047 43.5 35.66916072898483 139.74151319114085 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58273907-db76-4b40-96d3-abc2b186d554">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58273907-db76-4b40-96d3-abc2b186d554_0">
											<gml:posList>35.66917368015703 139.74148750518881 43.5 35.66916072898483 139.74151319114085 41.67 35.66917368015703 139.74148750518881 41.67 35.66917368015703 139.74148750518881 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef773f99-38aa-4ca4-97f5-4ed7dc39b747">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef773f99-38aa-4ca4-97f5-4ed7dc39b747_0">
											<gml:posList>35.66917368015703 139.74148750518881 43.5 35.66916072898483 139.74151319114085 43.5 35.66916072898483 139.74151319114085 41.67 35.66917368015703 139.74148750518881 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81dc7ebd-17ca-4960-a1c1-ddb4f208c17a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81dc7ebd-17ca-4960-a1c1-ddb4f208c17a_0">
											<gml:posList>35.669177413995946 139.7414903287118 41.67 35.66917368015703 139.74148750518881 43.5 35.66917368015703 139.74148750518881 41.67 35.669177413995946 139.7414903287118 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da332be6-d768-4ed1-805b-1247a6cd5658">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da332be6-d768-4ed1-805b-1247a6cd5658_0">
											<gml:posList>35.669177413995946 139.7414903287118 41.67 35.669177413995946 139.7414903287118 43.5 35.66917368015703 139.74148750518881 43.5 35.669177413995946 139.7414903287118 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3fd8068-2257-4c7f-b21e-6960a8022f57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3fd8068-2257-4c7f-b21e-6960a8022f57_0">
											<gml:posList>35.66921251771514 139.74137778398742 41.67 35.66914880594188 139.741504158047 43.5 35.66921251771514 139.74137778398742 43.5 35.66921251771514 139.74137778398742 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f51e4fc-f6f2-442b-a4ed-ff9d6501c463">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f51e4fc-f6f2-442b-a4ed-ff9d6501c463_0">
											<gml:posList>35.66921251771514 139.74137778398742 41.67 35.66914880594188 139.741504158047 41.67 35.66914880594188 139.741504158047 43.5 35.66921251771514 139.74137778398742 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc525cd4-e323-45f9-ae89-dcd4a6099755">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc525cd4-e323-45f9-ae89-dcd4a6099755_0">
											<gml:posList>35.669177413995946 139.7414903287118 41.67 35.6692036133311 139.74143837099777 43.5 35.669177413995946 139.7414903287118 43.5 35.669177413995946 139.7414903287118 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec779a48-519f-4f71-835c-244b952ccba1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec779a48-519f-4f71-835c-244b952ccba1_0">
											<gml:posList>35.669177413995946 139.7414903287118 41.67 35.6692036133311 139.74143837099777 41.67 35.6692036133311 139.74143837099777 43.5 35.669177413995946 139.7414903287118 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb83c82f-ec89-456a-94cd-78ccf901593e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb83c82f-ec89-456a-94cd-78ccf901593e_0">
											<gml:posList>35.66916072898483 139.74151319114085 43.5 35.66917368015703 139.74148750518881 43.5 35.66914880594188 139.741504158047 43.5 35.66916072898483 139.74151319114085 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-075a3f92-e306-427b-9c27-b1d825f01fed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-075a3f92-e306-427b-9c27-b1d825f01fed_0">
											<gml:posList>35.669212866773826 139.74144538571124 43.5 35.669237437067906 139.74139665528932 43.5 35.6692036133311 139.74143837099777 43.5 35.669212866773826 139.74144538571124 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2f592e4-3a09-4a28-9da8-738d155f0f46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2f592e4-3a09-4a28-9da8-738d155f0f46_0">
											<gml:posList>35.66917368015703 139.74148750518881 43.5 35.669177413995946 139.7414903287118 43.5 35.6692036133311 139.74143837099777 43.5 35.66917368015703 139.74148750518881 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fc41e8e-0db8-453a-bcd3-7388eb6fabb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fc41e8e-0db8-453a-bcd3-7388eb6fabb5_0">
											<gml:posList>35.66914880594188 139.741504158047 43.5 35.6692036133311 139.74143837099777 43.5 35.66921251771514 139.74137778398742 43.5 35.66914880594188 139.741504158047 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5235000c-917f-4171-8a3b-159c05aa0295">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5235000c-917f-4171-8a3b-159c05aa0295_0">
											<gml:posList>35.6692036133311 139.74143837099777 43.5 35.669237437067906 139.74139665528932 43.5 35.66921251771514 139.74137778398742 43.5 35.6692036133311 139.74143837099777 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80cbb5bf-df15-439f-a4c4-81763be8ef2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80cbb5bf-df15-439f-a4c4-81763be8ef2f_0">
											<gml:posList>35.66914880594188 139.741504158047 43.5 35.66917368015703 139.74148750518881 43.5 35.6692036133311 139.74143837099777 43.5 35.66914880594188 139.741504158047 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f078a775-b5c6-4460-b137-debbaeac9b3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f078a775-b5c6-4460-b137-debbaeac9b3d_0">
											<gml:posList>35.6692036133311 139.74143837099777 41.67 35.669212866773826 139.74144538571124 43.5 35.6692036133311 139.74143837099777 43.5 35.6692036133311 139.74143837099777 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7dbeea4-74ed-45a4-8164-75061194bbaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7dbeea4-74ed-45a4-8164-75061194bbaf_0">
											<gml:posList>35.6692036133311 139.74143837099777 41.67 35.669212866773826 139.74144538571124 41.67 35.669212866773826 139.74144538571124 43.5 35.6692036133311 139.74143837099777 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc06abcf-05e6-4b3c-bbcb-e085b48b815e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc06abcf-05e6-4b3c-bbcb-e085b48b815e_0">
											<gml:posList>35.66923341132273 139.74156653790115 37.26 35.6692097122468 139.7415402974029 40.315 35.6692097122468 139.7415402974029 37.26 35.66923341132273 139.74156653790115 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73b103ad-2dd4-4eea-8dc1-feadd666fb8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73b103ad-2dd4-4eea-8dc1-feadd666fb8e_0">
											<gml:posList>35.66923341132273 139.74156653790115 37.26 35.66923342033646 139.74156653789083 40.315 35.6692097122468 139.7415402974029 40.315 35.66923341132273 139.74156653790115 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61cbeee3-5309-4514-8eaa-41dbd3cdf44f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61cbeee3-5309-4514-8eaa-41dbd3cdf44f_0">
											<gml:posList>35.6692097122468 139.7415402974029 37.26 35.66923438435895 139.74150683260785 40.315 35.66923438435895 139.74150683260785 37.26 35.6692097122468 139.7415402974029 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2973514-4103-4eee-a0b9-ce9d68d114a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2973514-4103-4eee-a0b9-ce9d68d114a6_0">
											<gml:posList>35.6692097122468 139.7415402974029 37.26 35.6692097122468 139.7415402974029 40.315 35.66923438435895 139.74150683260785 40.315 35.6692097122468 139.7415402974029 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c59aa0da-f580-4390-8b13-6f62db6acdec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c59aa0da-f580-4390-8b13-6f62db6acdec_0">
											<gml:posList>35.66921251771514 139.74137778398742 41.67 35.669237437067906 139.74139665528932 43.5 35.669237437067906 139.74139665528932 41.67 35.66921251771514 139.74137778398742 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b548ad8-d6ac-422c-95a8-80cc5a46e43b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b548ad8-d6ac-422c-95a8-80cc5a46e43b_0">
											<gml:posList>35.66921251771514 139.74137778398742 41.67 35.66921251771514 139.74137778398742 43.5 35.669237437067906 139.74139665528932 43.5 35.66921251771514 139.74137778398742 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2577aa44-83b5-4e66-9f61-ba77b45a70af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2577aa44-83b5-4e66-9f61-ba77b45a70af_0">
											<gml:posList>35.669237437067906 139.74139665528932 43.5 35.669212866773826 139.74144538571124 41.67 35.669237437067906 139.74139665528932 41.67 35.669237437067906 139.74139665528932 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5797779f-78f7-43c2-b3e8-159611fac5e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5797779f-78f7-43c2-b3e8-159611fac5e5_0">
											<gml:posList>35.669237437067906 139.74139665528932 43.5 35.669212866773826 139.74144538571124 43.5 35.669212866773826 139.74144538571124 41.67 35.669237437067906 139.74139665528932 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87470725-5dc8-4931-8ad8-0ed11fe99d92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87470725-5dc8-4931-8ad8-0ed11fe99d92_0">
											<gml:posList>35.66925781181768 139.74153148277614 40.315 35.6692097122468 139.7415402974029 40.315 35.66923342033646 139.74156653789083 40.315 35.66925781181768 139.74153148277614 40.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f26a788-f3c2-4731-9072-f69a5e3ba48d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f26a788-f3c2-4731-9072-f69a5e3ba48d_0">
											<gml:posList>35.66925781181768 139.74153148277614 40.315 35.66923438435895 139.74150683260785 40.315 35.6692097122468 139.7415402974029 40.315 35.66925781181768 139.74153148277614 40.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3adeb07-9534-4e26-a352-3c0910b8e7fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3adeb07-9534-4e26-a352-3c0910b8e7fd_0">
											<gml:posList>35.6692412981287 139.74136541248393 43.5 35.669228008650414 139.74138478049565 41.67 35.669228008650414 139.74138478049565 43.5 35.6692412981287 139.74136541248393 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed20cb03-cca9-49d9-b7cb-777999cb6c23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed20cb03-cca9-49d9-b7cb-777999cb6c23_0">
											<gml:posList>35.6692412981287 139.74136541248393 43.5 35.6692412981287 139.74136541248393 41.67 35.669228008650414 139.74138478049565 41.67 35.6692412981287 139.74136541248393 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57c35931-918b-47b4-9791-d3beaf8affff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57c35931-918b-47b4-9791-d3beaf8affff_0">
											<gml:posList>35.669228008650414 139.74138478049565 41.67 35.66925418710777 139.74141176924653 43.5 35.669228008650414 139.74138478049565 43.5 35.669228008650414 139.74138478049565 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41f272be-bc33-41ab-83de-e3d9ba8b41b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41f272be-bc33-41ab-83de-e3d9ba8b41b4_0">
											<gml:posList>35.669228008650414 139.74138478049565 41.67 35.66925418710777 139.74141176924653 41.67 35.66925418710777 139.74141176924653 43.5 35.669228008650414 139.74138478049565 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afaf5805-8bd1-467b-84a3-76c69f38c8b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afaf5805-8bd1-467b-84a3-76c69f38c8b1_0">
											<gml:posList>35.66923438435895 139.74150683260785 37.26 35.66925781181768 139.74153148277614 40.315 35.66925781181768 139.74153148277614 37.26 35.66923438435895 139.74150683260785 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29b98500-595a-43b7-abb9-d7aa1902e2f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29b98500-595a-43b7-abb9-d7aa1902e2f2_0">
											<gml:posList>35.66923438435895 139.74150683260785 37.26 35.66923438435895 139.74150683260785 40.315 35.66925781181768 139.74153148277614 40.315 35.66923438435895 139.74150683260785 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fb10bef-81df-4656-82c0-3dd96fc59ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fb10bef-81df-4656-82c0-3dd96fc59ee8_0">
											<gml:posList>35.6692412981287 139.74136541248393 43.5 35.669228008650414 139.74138478049565 43.5 35.66925418710777 139.74141176924653 43.5 35.6692412981287 139.74136541248393 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ecfe71b3-ba03-4863-a06f-4e71d7c1c8d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ecfe71b3-ba03-4863-a06f-4e71d7c1c8d3_0">
											<gml:posList>35.66926748560407 139.7413924012226 43.5 35.6692412981287 139.74136541248393 43.5 35.66925418710777 139.74141176924653 43.5 35.66926748560407 139.7413924012226 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e516f3bd-d4bd-4697-a2f3-1e61f55ea0a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e516f3bd-d4bd-4697-a2f3-1e61f55ea0a5_0">
											<gml:posList>35.66926748560407 139.7413924012226 43.5 35.6692412981287 139.74136541248393 41.67 35.6692412981287 139.74136541248393 43.5 35.66926748560407 139.7413924012226 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b666de1-2e05-4630-80bd-8d72912e6e64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b666de1-2e05-4630-80bd-8d72912e6e64_0">
											<gml:posList>35.66926748560407 139.7413924012226 43.5 35.66926748560407 139.7413924012226 41.67 35.6692412981287 139.74136541248393 41.67 35.66926748560407 139.7413924012226 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b243b458-3c7e-4d0a-8e26-9c599197c76a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b243b458-3c7e-4d0a-8e26-9c599197c76a_0">
											<gml:posList>35.66926748560407 139.7413924012226 41.67 35.66925418710777 139.74141176924653 43.5 35.66925418710777 139.74141176924653 41.67 35.66926748560407 139.7413924012226 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1da00ea2-b27b-4b68-8814-a163001c2e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1da00ea2-b27b-4b68-8814-a163001c2e8f_0">
											<gml:posList>35.66926748560407 139.7413924012226 41.67 35.66926748560407 139.7413924012226 43.5 35.66925418710777 139.74141176924653 43.5 35.66926748560407 139.7413924012226 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1512624b-efeb-43b8-a2de-bc4ea666797e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1512624b-efeb-43b8-a2de-bc4ea666797e_0">
											<gml:posList>35.66930489270358 139.741498853889 41.67 35.66932076913199 139.74151492989253 43.793 35.66930489270358 139.741498853889 43.793 35.66930489270358 139.741498853889 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9517774b-c532-47f7-bc8d-ece06ddcae47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9517774b-c532-47f7-bc8d-ece06ddcae47_0">
											<gml:posList>35.66930489270358 139.741498853889 41.67 35.66932076913199 139.74151492989253 41.67 35.66932076913199 139.74151492989253 43.793 35.66930489270358 139.741498853889 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f51a3fef-2969-4799-8857-aee8560da1c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f51a3fef-2969-4799-8857-aee8560da1c5_0">
											<gml:posList>35.669329094236026 139.74146295943535 43.793 35.66930489270358 139.741498853889 41.67 35.66930489270358 139.741498853889 43.793 35.669329094236026 139.74146295943535 43.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44c2c0b7-f867-48eb-9bad-002583c01c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44c2c0b7-f867-48eb-9bad-002583c01c0a_0">
											<gml:posList>35.669329094236026 139.74146295943535 43.793 35.669329094236026 139.74146295943535 41.67 35.66930489270358 139.741498853889 41.67 35.669329094236026 139.74146295943535 43.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75a0323d-c19b-4ba2-aff1-4605ee7c05a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75a0323d-c19b-4ba2-aff1-4605ee7c05a4_0">
											<gml:posList>35.66930489270358 139.741498853889 43.793 35.66932076913199 139.74151492989253 43.793 35.66934497067758 139.7414790464827 43.793 35.66930489270358 139.741498853889 43.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1c5ed81-ec46-4967-8088-7fe300a3eabc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1c5ed81-ec46-4967-8088-7fe300a3eabc_0">
											<gml:posList>35.669329094236026 139.74146295943535 43.793 35.66930489270358 139.741498853889 43.793 35.66934497067758 139.7414790464827 43.793 35.669329094236026 139.74146295943535 43.793</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3769705-24e4-461c-83be-be3080f85909">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3769705-24e4-461c-83be-be3080f85909_0">
											<gml:posList>35.66932076913199 139.74151492989253 41.67 35.66934497067758 139.7414790464827 43.793 35.66932076913199 139.74151492989253 43.793 35.66932076913199 139.74151492989253 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-815d6632-612b-443e-b537-e8384798b3e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-815d6632-612b-443e-b537-e8384798b3e4_0">
											<gml:posList>35.66932076913199 139.74151492989253 41.67 35.66934497067758 139.7414790464827 41.67 35.66934497067758 139.7414790464827 43.793 35.66932076913199 139.74151492989253 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-629df637-0dc2-45ca-a7bf-f2cc108d105b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-629df637-0dc2-45ca-a7bf-f2cc108d105b_0">
											<gml:posList>35.669329094236026 139.74146295943535 41.67 35.66934497067758 139.7414790464827 43.793 35.66934497067758 139.7414790464827 41.67 35.669329094236026 139.74146295943535 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-469f601e-279d-4ce0-b203-592bcd674bbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-469f601e-279d-4ce0-b203-592bcd674bbd_0">
											<gml:posList>35.669329094236026 139.74146295943535 41.67 35.669329094236026 139.74146295943535 43.793 35.66934497067758 139.7414790464827 43.793 35.669329094236026 139.74146295943535 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6e1762b-6e12-43ab-afb1-97c1b846a9eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6e1762b-6e12-43ab-afb1-97c1b846a9eb_0">
											<gml:posList>35.66923341132273 139.74156653790115 37.26 35.66924825854592 139.7415449920526 37.26 35.66923342033646 139.74156653789083 40.315 35.66923341132273 139.74156653790115 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50bcd428-9e4a-4a7b-b3a4-a4cccdad7098">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50bcd428-9e4a-4a7b-b3a4-a4cccdad7098_0">
											<gml:posList>35.66923342033646 139.74156653789083 40.315 35.66924825854592 139.7415449920526 37.26 35.66925781181768 139.74153148277614 40.315 35.66923342033646 139.74156653789083 40.315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64da2edf-409c-41a4-8b37-2a9275c4b297">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64da2edf-409c-41a4-8b37-2a9275c4b297_0">
											<gml:posList>35.66924825854592 139.7415449920526 37.26 35.66925781181768 139.74153148277614 37.26 35.66925781181768 139.74153148277614 40.315 35.66924825854592 139.7415449920526 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57fbe401-85aa-46bd-a0ab-440b05bc521b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916072898483 139.74151319114085 41.67 35.66914880594188 139.741504158047 41.67 35.66917368015703 139.74148750518881 41.67 35.66916072898483 139.74151319114085 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7b3f58c-e1c5-4352-af4c-dcfb432fb05f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669212866773826 139.74144538571124 41.67 35.6692036133311 139.74143837099777 41.67 35.669237437067906 139.74139665528932 41.67 35.669212866773826 139.74144538571124 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-837e06a8-b52f-4d21-90df-68454bcd1e87">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914880594188 139.741504158047 41.67 35.66921251771514 139.74137778398742 41.67 35.6692036133311 139.74143837099777 41.67 35.66914880594188 139.741504158047 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3224969-15ff-4272-8fb0-95052c696fdb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692036133311 139.74143837099777 41.67 35.669177413995946 139.7414903287118 41.67 35.66917368015703 139.74148750518881 41.67 35.6692036133311 139.74143837099777 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1277023-c060-4ee4-8129-a4a2c8001706">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921251771514 139.74137778398742 41.67 35.669237437067906 139.74139665528932 41.67 35.6692036133311 139.74143837099777 41.67 35.66921251771514 139.74137778398742 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65ea594c-aef6-4d85-b299-70a2b2e3e5cb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914880594188 139.741504158047 41.67 35.6692036133311 139.74143837099777 41.67 35.66917368015703 139.74148750518881 41.67 35.66914880594188 139.741504158047 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76499e79-3d3c-4cd1-a5fa-284067829459">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692412981287 139.74136541248393 41.67 35.66926748560407 139.7413924012226 41.67 35.66925418710777 139.74141176924653 41.67 35.6692412981287 139.74136541248393 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c015006b-e737-44d2-b15d-d52886667243">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669228008650414 139.74138478049565 41.67 35.6692412981287 139.74136541248393 41.67 35.66925418710777 139.74141176924653 41.67 35.669228008650414 139.74138478049565 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f86dba0-4390-4626-9480-82e9c7caffcc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930489270358 139.741498853889 41.67 35.669329094236026 139.74146295943535 41.67 35.66934497067758 139.7414790464827 41.67 35.66930489270358 139.741498853889 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d2e05f9-7fac-40c1-94f1-6de18a1a5dfb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66932076913199 139.74151492989253 41.67 35.66930489270358 139.741498853889 41.67 35.66934497067758 139.7414790464827 41.67 35.66932076913199 139.74151492989253 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73197905-9fb8-4711-9ee7-5a2baddf77dc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925781181768 139.74153148277614 37.26 35.669248204413044 139.74154492583799 37.26 35.66923438435895 139.74150683260785 37.26 35.66925781181768 139.74153148277614 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c600f148-1621-4903-9596-051408a7fd76">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923438435895 139.74150683260785 37.26 35.669248204413044 139.74154492583799 37.26 35.6692097122468 139.7415402974029 37.26 35.66923438435895 139.74150683260785 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2819b13d-1800-48ab-941d-e97b5b7f3dcc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669248204413044 139.74154492583799 37.26 35.66923341132273 139.74156653790115 37.26 35.6692097122468 139.7415402974029 37.26 35.669248204413044 139.74154492583799 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_18d6444c-a844-4f22-9b3c-3759d0434ce3_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80cc5168-570e-416f-b0e9-a0017497463d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66936609433958 139.74155585909318 41.67 35.66936552284082 139.74156291821788 41.67 35.66934804359579 139.74156079527694 41.67 35.66932632749603 139.74155814697292 41.67 35.66932689900295 139.74155109889773 41.67 35.66936609433958 139.74155585909318 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e34c69c-a441-411c-be91-de67ed9221c8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6692204334461 139.74159268782637 10.02 35.66924430418474 139.74156031752437 10.02 35.66928227337875 139.74160020574726 10.02 35.6692204334461 139.74159268782637 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08386226-1ea0-4563-8a51-9734ea6b8416">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08386226-1ea0-4563-8a51-9734ea6b8416_0">
											<gml:posList>35.66932689900295 139.74155109889773 41.67 35.66932689900295 139.74155109889773 45.862 35.66936609433958 139.74155585909318 45.862 35.66936609433958 139.74155585909318 41.67 35.66932689900295 139.74155109889773 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adee753b-83f5-4928-8dab-498b8b684c2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adee753b-83f5-4928-8dab-498b8b684c2d_0">
											<gml:posList>35.66932689900295 139.74155109889773 45.862 35.66932689900295 139.74155109889773 41.67 35.66932632749603 139.74155814697292 41.67 35.66932632749603 139.74155814697292 45.862 35.66932689900295 139.74155109889773 45.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5792e81-295e-4868-8886-d8a057ce4a43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5792e81-295e-4868-8886-d8a057ce4a43_0">
											<gml:posList>35.66936609433958 139.74155585909318 45.862 35.66932689900295 139.74155109889773 45.862 35.66932632749603 139.74155814697292 45.862 35.66936552284082 139.74156291821788 45.862 35.66936609433958 139.74155585909318 45.862</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6107aafa-cae5-476a-ae10-22e580598d08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6107aafa-cae5-476a-ae10-22e580598d08_0">
											<gml:posList>35.66936552284082 139.74156291821788 44.744 35.66936552284082 139.74156291821788 41.67 35.66936609433958 139.74155585909318 41.67 35.66936609433958 139.74155585909318 45.862 35.66936552284082 139.74156291821788 45.862 35.66936552284082 139.74156291821788 44.744</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-082eec3a-4c16-41cb-9dcc-5572d2d5c5fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-082eec3a-4c16-41cb-9dcc-5572d2d5c5fb_0">
											<gml:posList>35.66934804359579 139.74156079527694 42.429 35.66936552284082 139.74156291821788 44.744 35.66936552284082 139.74156291821788 45.862 35.66932632749603 139.74155814697292 45.862 35.66932632749603 139.74155814697292 41.67 35.66934804359579 139.74156079527694 41.67 35.66934804359579 139.74156079527694 42.429</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d22d9c1a-7b17-4e85-a89b-8c5d27cce6a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d22d9c1a-7b17-4e85-a89b-8c5d27cce6a6_0">
											<gml:posList>35.66936552284082 139.74156291821788 41.67 35.66936552284082 139.74156291821788 44.744 35.66934804359579 139.74156079527694 42.429 35.66934804359579 139.74156079527694 41.67 35.66936552284082 139.74156291821788 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ae49fa8-98f9-4fa6-8950-797f5696b750">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ae49fa8-98f9-4fa6-8950-797f5696b750_0">
											<gml:posList>35.66924430418474 139.74156031752437 38.9 35.66924430418474 139.74156031752437 10.02 35.6692204334461 139.74159268782637 10.02 35.6692204334461 139.74159268782637 38.9 35.66924430418474 139.74156031752437 38.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b607501a-6f0e-40f7-84d5-d21911ca5055">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b607501a-6f0e-40f7-84d5-d21911ca5055_0">
											<gml:posList>35.66928227337875 139.74160020574726 38.9 35.66928227337875 139.74160020574726 10.02 35.66924430418474 139.74156031752437 10.02 35.66924430418474 139.74156031752437 38.9 35.66928227337875 139.74160020574726 38.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b57674ad-85c3-4546-aceb-e3c3128395c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b57674ad-85c3-4546-aceb-e3c3128395c8_0">
											<gml:posList>35.6692204334461 139.74159268782637 38.9 35.66928227337875 139.74160020574726 38.9 35.66924430418474 139.74156031752437 38.9 35.6692204334461 139.74159268782637 38.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18dc5c6c-191c-419f-9b36-a63e79efac0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18dc5c6c-191c-419f-9b36-a63e79efac0a_0">
											<gml:posList>35.6692204334461 139.74159268782637 38.9 35.6692204334461 139.74159268782637 10.02 35.66928227337875 139.74160020574726 10.02 35.66928227337875 139.74160020574726 38.9 35.6692204334461 139.74159268782637 38.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_18d6444c-a844-4f22-9b3c-3759d0434ce3_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94079f02-c088-4d9c-8f58-de7a67771992">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929900255884 139.74146974308772 41.67 35.669294211892044 139.74147582393687 41.67 35.66928627263472 139.7414664217476 41.67 35.66929106330104 139.74146034089847 41.67 35.66929900255884 139.74146974308772 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-412e7fe1-931c-48aa-9de9-5b31f0402907">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669251288126354 139.7414398959508 41.67 35.66929719367595 139.74148533122184 41.67 35.66927528860667 139.741518560913 41.67 35.66922939208317 139.74147312562494 41.67 35.669251288126354 139.7414398959508 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7dd2002-b796-4ebb-8464-16701161498d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669211300292936 139.74148333085483 41.67 35.669206168578235 139.7414913451543 41.67 35.66919203369965 139.74147776360084 41.67 35.66919716541346 139.74146974930193 41.67 35.669211300292936 139.74148333085483 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-988595da-1724-4453-9862-cc107cb65d93">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669193460212085 139.74149265210409 41.67 35.669203455001075 139.7415025821436 41.67 35.66919826007108 139.7415104418681 41.67 35.66918826528275 139.74150051182826 41.67 35.669193460212085 139.74149265210409 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcbdc1bf-b856-471e-9dc4-985e43b0e1ad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66928655456732 139.7415051601284 41.67 35.66930022047627 139.74151841085634 41.67 35.6692950706982 139.74152638099872 41.67 35.6692814047901 139.74151313027025 41.67 35.66928655456732 139.7415051601284 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d037f1e3-2b63-4c54-9bce-4df110e46bab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66933780742429 139.7415416419818 41.67 35.6693279925174 139.7415311925475 41.67 35.66934953919759 139.7415007910545 41.67 35.66935935410708 139.7415112404879 41.67 35.66933780742429 139.7415416419818 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a745026-7888-4fde-ad16-eece2af562d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927802649142 139.74153920295313 41.67 35.669272207712794 139.7415327476422 41.67 35.66927985249072 139.74152241077857 41.67 35.6692856712699 139.74152886608942 41.67 35.66927802649142 139.74153920295313 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a6dc240-4504-4905-a0d6-febcd65db9cb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669304270097946 139.7415216316836 41.67 35.669318512933955 139.74153494803346 41.67 35.66931413761097 139.7415419673243 41.67 35.66929989477572 139.74152865097395 41.67 35.669304270097946 139.7415216316836 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1edfcf9b-2a27-44d6-bb68-9b10be1b6076">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66930392542309 139.74154245399808 41.67 35.66929018397584 139.74156017664262 41.67 35.669285005501145 139.74155415139444 41.67 35.669298746939106 139.7415364177039 41.67 35.66930392542309 139.74154245399808 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7876235-8c09-4148-9dd5-9360713e0586">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66931416880141 139.7415947235228 46.937 35.66931536997432 139.74157414324023 46.937 35.66935352764602 139.7415774796845 46.937 35.66935232647255 139.7415980599768 46.937 35.66931416880141 139.7415947235228 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3edc6c6-2121-4eb6-8615-c47376891ee7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3edc6c6-2121-4eb6-8615-c47376891ee7_0">
											<gml:posList>35.6692856712699 139.74152886608942 41.67 35.66927985249072 139.74152241077857 41.67 35.66927985249072 139.74152241077857 43.139 35.6692856712699 139.74152886608942 43.139 35.6692856712699 139.74152886608942 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2049e79c-5675-4426-bc73-8b9d27456e09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2049e79c-5675-4426-bc73-8b9d27456e09_0">
											<gml:posList>35.66930392542309 139.74154245399808 41.67 35.669298746939106 139.7415364177039 41.67 35.669298746939106 139.7415364177039 43.139 35.66930392542309 139.74154245399808 43.139 35.66930392542309 139.74154245399808 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a955202d-2973-47b5-bf9f-bb9323955f92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a955202d-2973-47b5-bf9f-bb9323955f92_0">
											<gml:posList>35.669251288126354 139.7414398959508 41.67 35.66922939208317 139.74147312562494 41.67 35.66922939208317 139.74147312562494 42.284 35.669251288126354 139.7414398959508 42.284 35.669251288126354 139.7414398959508 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b290199-f511-4331-a8a9-dcd6b1884c39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b290199-f511-4331-a8a9-dcd6b1884c39_0">
											<gml:posList>35.66929719367595 139.74148533122184 41.67 35.669251288126354 139.7414398959508 41.67 35.669251288126354 139.7414398959508 42.284 35.66929719367595 139.74148533122184 42.284 35.66929719367595 139.74148533122184 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2f6820b-d161-497c-86f1-3e43b7abe943">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2f6820b-d161-497c-86f1-3e43b7abe943_0">
											<gml:posList>35.66929106330104 139.74146034089847 41.67 35.66928627263472 139.7414664217476 41.67 35.66928627263472 139.7414664217476 43.555 35.66929106330104 139.74146034089847 43.555 35.66929106330104 139.74146034089847 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a342535-c863-4bce-9f1f-270ddfb18959">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a342535-c863-4bce-9f1f-270ddfb18959_0">
											<gml:posList>35.66929106330104 139.74146034089847 41.67 35.66929106330104 139.74146034089847 43.555 35.66929900255884 139.74146974308772 43.555 35.66929900255884 139.74146974308772 41.67 35.66929106330104 139.74146034089847 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47477b76-7e00-469d-ab71-74723ecd3609">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47477b76-7e00-469d-ab71-74723ecd3609_0">
											<gml:posList>35.66929900255884 139.74146974308772 43.555 35.66929106330104 139.74146034089847 43.555 35.66928627263472 139.7414664217476 43.555 35.669294211892044 139.74147582393687 43.555 35.66929900255884 139.74146974308772 43.555</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ea0a299-6679-4ffc-aceb-f64070889561">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ea0a299-6679-4ffc-aceb-f64070889561_0">
											<gml:posList>35.66928627263472 139.7414664217476 41.67 35.669294211892044 139.74147582393687 41.67 35.669294211892044 139.74147582393687 43.555 35.66928627263472 139.7414664217476 43.555 35.66928627263472 139.7414664217476 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26945dc0-f1fb-4a93-a9b9-d4f66f506c71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26945dc0-f1fb-4a93-a9b9-d4f66f506c71_0">
											<gml:posList>35.669294211892044 139.74147582393687 41.67 35.66929900255884 139.74146974308772 41.67 35.66929900255884 139.74146974308772 43.555 35.669294211892044 139.74147582393687 43.555 35.669294211892044 139.74147582393687 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-555c203c-407f-4420-845e-7509085a7e27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-555c203c-407f-4420-845e-7509085a7e27_0">
											<gml:posList>35.66919716541346 139.74146974930193 41.67 35.66919203369965 139.74147776360084 41.67 35.66919203369965 139.74147776360084 43.044 35.66919716541346 139.74146974930193 43.044 35.66919716541346 139.74146974930193 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-093117c3-754d-414e-bb7d-2598c70410de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-093117c3-754d-414e-bb7d-2598c70410de_0">
											<gml:posList>35.669211300292936 139.74148333085483 41.67 35.66919716541346 139.74146974930193 41.67 35.66919716541346 139.74146974930193 43.044 35.669211300292936 139.74148333085483 43.044 35.669211300292936 139.74148333085483 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59097f01-dc09-4631-a3f8-8400ac4ba3fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59097f01-dc09-4631-a3f8-8400ac4ba3fe_0">
											<gml:posList>35.66927528860667 139.741518560913 42.284 35.66929719367595 139.74148533122184 42.284 35.669251288126354 139.7414398959508 42.284 35.66922939208317 139.74147312562494 42.284 35.66927528860667 139.741518560913 42.284</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-908f724e-06c4-40f3-ad86-2d0dff6c4187">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-908f724e-06c4-40f3-ad86-2d0dff6c4187_0">
											<gml:posList>35.66919203369965 139.74147776360084 43.044 35.669206168578235 139.7414913451543 43.044 35.669211300292936 139.74148333085483 43.044 35.66919716541346 139.74146974930193 43.044 35.66919203369965 139.74147776360084 43.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb8a1390-845b-4f88-9944-8ff372398e2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb8a1390-845b-4f88-9944-8ff372398e2f_0">
											<gml:posList>35.66919203369965 139.74147776360084 41.67 35.669206168578235 139.7414913451543 41.67 35.669206168578235 139.7414913451543 43.044 35.66919203369965 139.74147776360084 43.044 35.66919203369965 139.74147776360084 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2923b59-936c-4617-bebf-3f7e5f455722">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2923b59-936c-4617-bebf-3f7e5f455722_0">
											<gml:posList>35.669206168578235 139.7414913451543 41.67 35.669211300292936 139.74148333085483 41.67 35.669211300292936 139.74148333085483 43.044 35.669206168578235 139.7414913451543 43.044 35.669206168578235 139.7414913451543 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f86da89-d9eb-4c5b-aa7e-9d6fd5bfcbb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f86da89-d9eb-4c5b-aa7e-9d6fd5bfcbb3_0">
											<gml:posList>35.66927528860667 139.741518560913 41.67 35.66927528860667 139.741518560913 42.284 35.66922939208317 139.74147312562494 42.284 35.66922939208317 139.74147312562494 41.67 35.66927528860667 139.741518560913 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66cd1b7c-0380-4ac2-8d2c-c12322000dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66cd1b7c-0380-4ac2-8d2c-c12322000dc2_0">
											<gml:posList>35.669193460212085 139.74149265210409 41.67 35.66918826528275 139.74150051182826 41.67 35.66918826528275 139.74150051182826 43.044 35.669193460212085 139.74149265210409 43.044 35.669193460212085 139.74149265210409 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76a953df-f99e-459a-9553-3e155d5ccba9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76a953df-f99e-459a-9553-3e155d5ccba9_0">
											<gml:posList>35.669193460212085 139.74149265210409 41.67 35.669193460212085 139.74149265210409 43.044 35.669203455001075 139.7415025821436 43.044 35.669203455001075 139.7415025821436 41.67 35.669193460212085 139.74149265210409 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00dd4773-9bbd-42fd-ad0d-c6d9c77ddd22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00dd4773-9bbd-42fd-ad0d-c6d9c77ddd22_0">
											<gml:posList>35.66919826007108 139.7415104418681 43.044 35.669203455001075 139.7415025821436 43.044 35.669193460212085 139.74149265210409 43.044 35.66918826528275 139.74150051182826 43.044 35.66919826007108 139.7415104418681 43.044</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0894cf7f-93c2-4dac-8f5c-1145c6804dd9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0894cf7f-93c2-4dac-8f5c-1145c6804dd9_0">
											<gml:posList>35.66929719367595 139.74148533122184 41.67 35.66929719367595 139.74148533122184 42.284 35.66927528860667 139.741518560913 42.284 35.66927528860667 139.741518560913 41.67 35.66929719367595 139.74148533122184 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bb0242f-f7b8-43aa-948e-6cdcafa26893">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bb0242f-f7b8-43aa-948e-6cdcafa26893_0">
											<gml:posList>35.66918826528275 139.74150051182826 41.67 35.66919826007108 139.7415104418681 41.67 35.66919826007108 139.7415104418681 43.044 35.66918826528275 139.74150051182826 43.044 35.66918826528275 139.74150051182826 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-195e498f-cb9e-44bb-ad8c-c4401c412bda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-195e498f-cb9e-44bb-ad8c-c4401c412bda_0">
											<gml:posList>35.66935935410708 139.7415112404879 41.67 35.66934953919759 139.7415007910545 41.67 35.66934953919759 139.7415007910545 42.501 35.66935935410708 139.7415112404879 42.501 35.66935935410708 139.7415112404879 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0463ab71-300c-4bc4-ac26-780d223d791e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0463ab71-300c-4bc4-ac26-780d223d791e_0">
											<gml:posList>35.66919826007108 139.7415104418681 41.67 35.669203455001075 139.7415025821436 41.67 35.669203455001075 139.7415025821436 43.044 35.66919826007108 139.7415104418681 43.044 35.66919826007108 139.7415104418681 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5966dd8-bae8-4923-9d4c-f6f6968c2107">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5966dd8-bae8-4923-9d4c-f6f6968c2107_0">
											<gml:posList>35.66928655456732 139.7415051601284 41.67 35.6692814047901 139.74151313027025 41.67 35.6692814047901 139.74151313027025 43.139 35.66928655456732 139.7415051601284 43.139 35.66928655456732 139.7415051601284 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-758f8c70-c9f4-418c-9d12-c589e2809427">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-758f8c70-c9f4-418c-9d12-c589e2809427_0">
											<gml:posList>35.66930022047627 139.74151841085634 41.67 35.66928655456732 139.7415051601284 41.67 35.66928655456732 139.7415051601284 43.139 35.66930022047627 139.74151841085634 43.139 35.66930022047627 139.74151841085634 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e65454e-f127-4fc3-8f55-0bf345e317f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e65454e-f127-4fc3-8f55-0bf345e317f1_0">
											<gml:posList>35.6692950706982 139.74152638099872 43.139 35.66930022047627 139.74151841085634 43.139 35.66928655456732 139.7415051601284 43.139 35.6692814047901 139.74151313027025 43.139 35.6692950706982 139.74152638099872 43.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59f9ef50-ecdd-458a-aa5d-2d77e8037237">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59f9ef50-ecdd-458a-aa5d-2d77e8037237_0">
											<gml:posList>35.6693279925174 139.7415311925475 41.67 35.6693279925174 139.7415311925475 42.501 35.66934953919759 139.7415007910545 42.501 35.66934953919759 139.7415007910545 41.67 35.6693279925174 139.7415311925475 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a48c9d72-0c8a-4ca1-96c1-b8c4bac6fdea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a48c9d72-0c8a-4ca1-96c1-b8c4bac6fdea_0">
											<gml:posList>35.6692950706982 139.74152638099872 41.67 35.6692950706982 139.74152638099872 43.139 35.6692814047901 139.74151313027025 43.139 35.6692814047901 139.74151313027025 41.67 35.6692950706982 139.74152638099872 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8473474a-068d-4dae-a4f0-db07c6d9c639">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8473474a-068d-4dae-a4f0-db07c6d9c639_0">
											<gml:posList>35.66934953919759 139.7415007910545 42.501 35.6693279925174 139.7415311925475 42.501 35.66933780742429 139.7415416419818 42.501 35.66935935410708 139.7415112404879 42.501 35.66934953919759 139.7415007910545 42.501</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-687490eb-04ad-401e-96c0-c0d2ab359796">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-687490eb-04ad-401e-96c0-c0d2ab359796_0">
											<gml:posList>35.66930022047627 139.74151841085634 41.67 35.66930022047627 139.74151841085634 43.139 35.6692950706982 139.74152638099872 43.139 35.6692950706982 139.74152638099872 41.67 35.66930022047627 139.74151841085634 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9265aba6-1074-4b11-82e8-1ca98ff83e8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9265aba6-1074-4b11-82e8-1ca98ff83e8e_0">
											<gml:posList>35.669304270097946 139.7415216316836 41.67 35.66929989477572 139.74152865097395 41.67 35.66929989477572 139.74152865097395 43.139 35.669304270097946 139.7415216316836 43.139 35.669304270097946 139.7415216316836 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1aba66ec-689d-4b9f-a3a0-df681d5d0b16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1aba66ec-689d-4b9f-a3a0-df681d5d0b16_0">
											<gml:posList>35.66933780742429 139.7415416419818 41.67 35.66935935410708 139.7415112404879 41.67 35.66935935410708 139.7415112404879 42.501 35.66933780742429 139.7415416419818 42.501 35.66933780742429 139.7415416419818 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-275936e3-58a8-488f-aa23-aa3bb65fe5fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-275936e3-58a8-488f-aa23-aa3bb65fe5fd_0">
											<gml:posList>35.66927985249072 139.74152241077857 41.67 35.669272207712794 139.7415327476422 41.67 35.669272207712794 139.7415327476422 43.139 35.66927985249072 139.74152241077857 43.139 35.66927985249072 139.74152241077857 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0752c386-9165-4f1b-adc5-db7c60215c32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0752c386-9165-4f1b-adc5-db7c60215c32_0">
											<gml:posList>35.669318512933955 139.74153494803346 41.67 35.669304270097946 139.7415216316836 41.67 35.669304270097946 139.7415216316836 43.139 35.669318512933955 139.74153494803346 43.139 35.669318512933955 139.74153494803346 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-970300b8-50d3-4e59-bfb9-d8a614dc1d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-970300b8-50d3-4e59-bfb9-d8a614dc1d9b_0">
											<gml:posList>35.66927985249072 139.74152241077857 43.139 35.669272207712794 139.7415327476422 43.139 35.66927802649142 139.74153920295313 43.139 35.6692856712699 139.74152886608942 43.139 35.66927985249072 139.74152241077857 43.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d709778d-a81a-4eb7-bb7c-b98463987f50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d709778d-a81a-4eb7-bb7c-b98463987f50_0">
											<gml:posList>35.66931413761097 139.7415419673243 43.139 35.669318512933955 139.74153494803346 43.139 35.669304270097946 139.7415216316836 43.139 35.66929989477572 139.74152865097395 43.139 35.66931413761097 139.7415419673243 43.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e682a77-d49e-4d00-854b-1fa9650fe581">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e682a77-d49e-4d00-854b-1fa9650fe581_0">
											<gml:posList>35.66927802649142 139.74153920295313 41.67 35.6692856712699 139.74152886608942 41.67 35.6692856712699 139.74152886608942 43.139 35.66927802649142 139.74153920295313 43.139 35.66927802649142 139.74153920295313 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9771d08e-74cd-4ca7-8b25-204a47430512">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9771d08e-74cd-4ca7-8b25-204a47430512_0">
											<gml:posList>35.66931413761097 139.7415419673243 43.139 35.66929989477572 139.74152865097395 43.139 35.66929989477572 139.74152865097395 41.67 35.66931413761097 139.7415419673243 41.67 35.66931413761097 139.7415419673243 43.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4407f2cb-088c-4693-9323-1940aff77179">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4407f2cb-088c-4693-9323-1940aff77179_0">
											<gml:posList>35.669272207712794 139.7415327476422 41.67 35.66927802649142 139.74153920295313 41.67 35.66927802649142 139.74153920295313 43.139 35.669272207712794 139.7415327476422 43.139 35.669272207712794 139.7415327476422 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-500e4f30-a2a7-4ffa-902c-3bc5def94707">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-500e4f30-a2a7-4ffa-902c-3bc5def94707_0">
											<gml:posList>35.6693279925174 139.7415311925475 41.67 35.66933780742429 139.7415416419818 41.67 35.66933780742429 139.7415416419818 42.501 35.6693279925174 139.7415311925475 42.501 35.6693279925174 139.7415311925475 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08fbb515-95ee-4aac-8c8e-f88f966aeb20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08fbb515-95ee-4aac-8c8e-f88f966aeb20_0">
											<gml:posList>35.66931413761097 139.7415419673243 41.67 35.669318512933955 139.74153494803346 41.67 35.669318512933955 139.74153494803346 43.139 35.66931413761097 139.7415419673243 43.139 35.66931413761097 139.7415419673243 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a6cb4ae-5910-4a4b-a986-4a0c262f9fbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a6cb4ae-5910-4a4b-a986-4a0c262f9fbf_0">
											<gml:posList>35.669298746939106 139.7415364177039 41.67 35.669285005501145 139.74155415139444 41.67 35.669285005501145 139.74155415139444 43.139 35.669298746939106 139.7415364177039 43.139 35.669298746939106 139.7415364177039 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d309492-8e1a-4ef8-b402-8c187647a66f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d309492-8e1a-4ef8-b402-8c187647a66f_0">
											<gml:posList>35.66930392542309 139.74154245399808 43.139 35.669298746939106 139.7415364177039 43.139 35.669285005501145 139.74155415139444 43.139 35.66929018397584 139.74156017664262 43.139 35.66930392542309 139.74154245399808 43.139</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a50c7dc-af9c-4660-a228-e58f57853f8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a50c7dc-af9c-4660-a228-e58f57853f8c_0">
											<gml:posList>35.66930392542309 139.74154245399808 41.67 35.66930392542309 139.74154245399808 43.139 35.66929018397584 139.74156017664262 43.139 35.66929018397584 139.74156017664262 41.67 35.66930392542309 139.74154245399808 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0792ab75-502d-4fff-8025-420483537347">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0792ab75-502d-4fff-8025-420483537347_0">
											<gml:posList>35.669285005501145 139.74155415139444 41.67 35.66929018397584 139.74156017664262 41.67 35.66929018397584 139.74156017664262 43.139 35.669285005501145 139.74155415139444 43.139 35.669285005501145 139.74155415139444 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a9c0fef-2c31-4517-901c-836e5f2ce28e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a9c0fef-2c31-4517-901c-836e5f2ce28e_0">
											<gml:posList>35.66931536997432 139.74157414324023 46.937 35.66931536997432 139.74157414324023 47.461 35.66935352764602 139.7415774796845 47.461 35.66935352764602 139.7415774796845 46.937 35.66931536997432 139.74157414324023 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a91abfe6-bcdc-41d8-a411-ef38a47cd37a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a91abfe6-bcdc-41d8-a411-ef38a47cd37a_0">
											<gml:posList>35.66931536997432 139.74157414324023 46.937 35.66931416880141 139.7415947235228 46.937 35.66931416880141 139.7415947235228 47.461 35.66931536997432 139.74157414324023 47.461 35.66931536997432 139.74157414324023 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e264f2e-4c3c-4924-8035-49f869f44a76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e264f2e-4c3c-4924-8035-49f869f44a76_0">
											<gml:posList>35.66931416880141 139.7415947235228 47.461 35.66935232647255 139.7415980599768 47.461 35.66935352764602 139.7415774796845 47.461 35.66931536997432 139.74157414324023 47.461 35.66931416880141 139.7415947235228 47.461</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4c4c8d3-4608-4c11-863c-3715c5acc49e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4c4c8d3-4608-4c11-863c-3715c5acc49e_0">
											<gml:posList>35.66935232647255 139.7415980599768 46.937 35.66935352764602 139.7415774796845 46.937 35.66935352764602 139.7415774796845 47.461 35.66935232647255 139.7415980599768 47.461 35.66935232647255 139.7415980599768 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e47c82c-fb25-4b26-93a0-ec513ab6a361">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e47c82c-fb25-4b26-93a0-ec513ab6a361_0">
											<gml:posList>35.66935232647255 139.7415980599768 46.937 35.66935232647255 139.7415980599768 47.461 35.66931416880141 139.7415947235228 47.461 35.66931416880141 139.7415947235228 46.937 35.66935232647255 139.7415980599768 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9ad05aa0-7feb-4b1b-bb1d-177fb4b16521">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ad05aa0-7feb-4b1b-bb1d-177fb4b16521">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ad05aa0-7feb-4b1b-bb1d-177fb4b16521">
											<gml:posList>35.66924430418474 139.74156031752437 9.946 35.66922333321446 139.74158920498695 9.946 35.66919679840786 139.74159133410677 9.946 35.66913574414225 139.74152661865733 9.946 35.66921673683724 139.74135509046087 9.946 35.66923836749826 139.7413520832 9.946 35.66936925807495 139.7414848178724 9.946 35.66940359477022 139.74159568163398 9.946 35.66939324270295 139.74161369865965 9.946 35.66928227337875 139.74160020574726 9.946 35.66924430418474 139.74156031752437 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a689952b-ff12-4772-99af-bff123f38ad3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a689952b-ff12-4772-99af-bff123f38ad3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a689952b-ff12-4772-99af-bff123f38ad3">
											<gml:posList>35.66914294349913 139.74151136681118 37.784 35.66913574414225 139.74152661865733 37.784 35.6691383667235 139.74152607439618 37.784 35.66914453118658 139.74151303295247 37.784 35.66914294349913 139.74151136681118 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17319fb6-5ef3-4d61-85d3-c34bb93700d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17319fb6-5ef3-4d61-85d3-c34bb93700d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17319fb6-5ef3-4d61-85d3-c34bb93700d9">
											<gml:posList>35.66914294349913 139.74151136681118 43.5 35.66917985722845 139.74155010737493 43.5 35.66917965625744 139.74154660599314 43.5 35.66914555707502 139.74151083360587 43.5 35.66914294349913 139.74151136681118 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1b535f9-7612-4016-9704-d48ae8d0f773">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1b535f9-7612-4016-9704-d48ae8d0f773">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1b535f9-7612-4016-9704-d48ae8d0f773">
											<gml:posList>35.66919679840786 139.74159133410677 37.784 35.6691975085312 139.74158875955374 37.784 35.6691383667235 139.74152607439618 37.784 35.66913574414225 139.74152661865733 37.784 35.66919679840786 139.74159133410677 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb5d8a5a-9ba7-4103-b3d3-30cee0e80c1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb5d8a5a-9ba7-4103-b3d3-30cee0e80c1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb5d8a5a-9ba7-4103-b3d3-30cee0e80c1a">
											<gml:posList>35.66914555707502 139.74151083360587 43.5 35.6692179915337 139.74135743079464 43.5 35.66921673683724 139.74135509046087 43.5 35.66914294349913 139.74151136681118 43.5 35.66914555707502 139.74151083360587 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd1ace8d-c9da-452f-acf8-ddbb125c7992">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd1ace8d-c9da-452f-acf8-ddbb125c7992">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd1ace8d-c9da-452f-acf8-ddbb125c7992">
											<gml:posList>35.66922101507588 139.7414924990352 43.5 35.66922082312534 139.74148900868752 43.5 35.66917965625744 139.74154660599314 43.5 35.66917985722845 139.74155010737493 43.5 35.66922101507588 139.7414924990352 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d24d501-ca18-48db-89b7-e31b26b6ed40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d24d501-ca18-48db-89b7-e31b26b6ed40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d24d501-ca18-48db-89b7-e31b26b6ed40">
											<gml:posList>35.66922333321446 139.74158920498695 37.784 35.66922235787222 139.74158676491487 37.784 35.6691975085312 139.74158875955374 37.784 35.66919679840786 139.74159133410677 37.784 35.66922333321446 139.74158920498695 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbd304d9-75ca-4a18-80c1-ee7f0cc66a55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbd304d9-75ca-4a18-80c1-ee7f0cc66a55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbd304d9-75ca-4a18-80c1-ee7f0cc66a55">
											<gml:posList>35.66917985722845 139.74155010737493 37.26 35.66914453118658 139.74151303295247 37.26 35.6691383667235 139.74152607439618 37.26 35.6691975085312 139.74158875955374 37.26 35.66922235787222 139.74158676491487 37.26 35.66924411221933 139.74155680508332 37.26 35.66928311881753 139.74159777463618 37.26 35.66930104879041 139.74159995229837 37.26 35.66930195064321 139.74158875051003 37.26 35.66928744612956 139.74158688926786 37.26 35.66924845680576 139.74154493659515 37.26 35.669258073224114 139.74153149352296 37.26 35.66922101507588 139.7414924990352 37.26 35.66917985722845 139.74155010737493 37.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f85cfabf-b28a-4bad-8ef9-7e0d99f0f6f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f85cfabf-b28a-4bad-8ef9-7e0d99f0f6f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f85cfabf-b28a-4bad-8ef9-7e0d99f0f6f3">
											<gml:posList>35.66923836749826 139.7413520832 43.5 35.66921673683724 139.74135509046087 43.5 35.6692179915337 139.74135743079464 43.5 35.66923773852882 139.74135469080164 43.5 35.66923836749826 139.7413520832 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e023da7-6965-4d1f-9081-3337c4c28697">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e023da7-6965-4d1f-9081-3337c4c28697">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e023da7-6965-4d1f-9081-3337c4c28697">
											<gml:posList>35.66924430418474 139.74156031752437 37.784 35.66924411221933 139.74155680508332 37.784 35.66922235787222 139.74158676491487 37.784 35.66922333321446 139.74158920498695 37.784 35.66924430418474 139.74156031752437 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-91c568a5-3fa5-478e-841d-ea8034d47526">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91c568a5-3fa5-478e-841d-ea8034d47526">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91c568a5-3fa5-478e-841d-ea8034d47526">
											<gml:posList>35.669260966444455 139.74153124719606 43.5 35.66922082312534 139.74148900868752 43.5 35.66922101507588 139.7414924990352 43.5 35.669258073224114 139.74153149352296 43.5 35.669260966444455 139.74153124719606 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0eec8743-89e1-4867-bf38-b6c1172c9439">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0eec8743-89e1-4867-bf38-b6c1172c9439">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0eec8743-89e1-4867-bf38-b6c1172c9439">
											<gml:posList>35.669258073224114 139.74153149352296 43.5 35.66924845680576 139.74154493659515 43.5 35.669251341020825 139.74154470132518 43.5 35.669260966444455 139.74153124719606 43.5 35.669258073224114 139.74153149352296 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73aad5eb-3202-42fb-8a6c-9d05baa77537">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73aad5eb-3202-42fb-8a6c-9d05baa77537">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73aad5eb-3202-42fb-8a6c-9d05baa77537">
											<gml:posList>35.66924430418474 139.74156031752437 37.784 35.66928227337875 139.74160020574726 37.784 35.66928311881753 139.74159777463618 37.784 35.66924411221933 139.74155680508332 37.784 35.66924430418474 139.74156031752437 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36862ba6-84fa-477a-baec-3c0942923987">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36862ba6-84fa-477a-baec-3c0942923987">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36862ba6-84fa-477a-baec-3c0942923987">
											<gml:posList>35.66928744612956 139.74158688926786 43.5 35.66928830060706 139.74158449128447 43.5 35.669251341020825 139.74154470132518 43.5 35.66924845680576 139.74154493659515 43.5 35.66928744612956 139.74158688926786 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c175bf4-500e-4c4f-b904-5c31ddffe513">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c175bf4-500e-4c4f-b904-5c31ddffe513">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c175bf4-500e-4c4f-b904-5c31ddffe513">
											<gml:posList>35.669391473867115 139.7415635623292 41.67 35.66936754662161 139.74148633315133 41.67 35.66923773852882 139.74135469080164 41.67 35.6692179915337 139.74135743079464 41.67 35.66914555707502 139.74151083360587 41.67 35.66917965625744 139.74154660599314 41.67 35.66922082312534 139.74148900868752 41.67 35.669260966444455 139.74153124719606 41.67 35.669251341020825 139.74154470132518 41.67 35.66928830060706 139.74158449128447 41.67 35.6693001277752 139.7415860021142 41.67 35.669302156048396 139.74158624280778 41.67 35.66930370087785 139.74156715335988 41.67 35.669307517654474 139.74156053237064 41.67 35.669310733819884 139.7415582531904 41.67 35.66931691629202 139.74155700894926 41.67 35.669391962561285 139.74156612447052 41.67 35.669391473867115 139.7415635623292 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e3fb1a0-1a45-4de3-9533-dca0bb12e8e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e3fb1a0-1a45-4de3-9533-dca0bb12e8e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e3fb1a0-1a45-4de3-9533-dca0bb12e8e2">
											<gml:posList>35.66930084338494 139.74160246000056 37.784 35.66930104879041 139.74159995229837 37.784 35.66928311881753 139.74159777463618 37.784 35.66928227337875 139.74160020574726 37.784 35.66930084338494 139.74160246000056 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-887df0a1-047f-424a-b24f-1b3e78ce941c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-887df0a1-047f-424a-b24f-1b3e78ce941c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-887df0a1-047f-424a-b24f-1b3e78ce941c">
											<gml:posList>35.66928744612956 139.74158688926786 43.5 35.66930195064321 139.74158875051003 43.5 35.6693001277752 139.7415860021142 43.5 35.66928830060706 139.74158449128447 43.5 35.66928744612956 139.74158688926786 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3879bea7-bc2b-40e2-a115-68bc5d0246bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3879bea7-bc2b-40e2-a115-68bc5d0246bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3879bea7-bc2b-40e2-a115-68bc5d0246bf">
											<gml:posList>35.6693001277752 139.7415860021142 43.5 35.66930195064321 139.74158875051003 43.5 35.669302156048396 139.74158624280778 43.5 35.6693001277752 139.7415860021142 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27fd2fd4-ad0f-4918-92a6-ca46a23e8482">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27fd2fd4-ad0f-4918-92a6-ca46a23e8482">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27fd2fd4-ad0f-4918-92a6-ca46a23e8482">
											<gml:posList>35.66930370087785 139.74156715335988 47.6 35.66930084338494 139.74160246000056 47.6 35.66930289695739 139.7416004141206 47.6 35.669305513284684 139.74156800183619 47.6 35.66930370087785 139.74156715335988 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69693d4b-b40f-4d21-85b5-73e5e5cf4d1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69693d4b-b40f-4d21-85b5-73e5e5cf4d1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69693d4b-b40f-4d21-85b5-73e5e5cf4d1c">
											<gml:posList>35.66923773852882 139.74135469080164 43.5 35.66936754662161 139.74148633315133 43.5 35.66936925807495 139.7414848178724 43.5 35.66923836749826 139.7413520832 43.5 35.66923773852882 139.74135469080164 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-994889cb-7b31-4f11-bf09-c4e7ec42f5ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-994889cb-7b31-4f11-bf09-c4e7ec42f5ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-994889cb-7b31-4f11-bf09-c4e7ec42f5ec">
											<gml:posList>35.669307517654474 139.74156053237064 47.6 35.66930370087785 139.74156715335988 47.6 35.669305513284684 139.74156800183619 47.6 35.66930881695253 139.74156226512306 47.6 35.669307517654474 139.74156053237064 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a3542fd-fd18-4cc3-825b-49fddf8e80d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a3542fd-fd18-4cc3-825b-49fddf8e80d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a3542fd-fd18-4cc3-825b-49fddf8e80d1">
											<gml:posList>35.669310733819884 139.7415582531904 47.6 35.669307517654474 139.74156053237064 47.6 35.66930881695253 139.74156226512306 47.6 35.66931138448339 139.74156045062196 47.6 35.669310733819884 139.7415582531904 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f20cb1e-422f-4539-a3f3-c0f00aaed101">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f20cb1e-422f-4539-a3f3-c0f00aaed101">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f20cb1e-422f-4539-a3f3-c0f00aaed101">
											<gml:posList>35.66931691629202 139.74155700894926 47.6 35.669310733819884 139.7415582531904 47.6 35.66931138448339 139.74156045062196 47.6 35.66931697214233 139.74155932856908 47.6 35.66931691629202 139.74155700894926 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c4ce89e-3e4b-4d92-bc9a-ac90c6a04557">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c4ce89e-3e4b-4d92-bc9a-ac90c6a04557">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c4ce89e-3e4b-4d92-bc9a-ac90c6a04557">
											<gml:posList>35.66939324270295 139.74161369865965 47.6 35.669392348509994 139.74161129162763 47.6 35.66930289695739 139.7416004141206 47.6 35.66930084338494 139.74160246000056 47.6 35.66939324270295 139.74161369865965 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a52ad4de-b0ae-49f7-8537-e00e40e7dbe3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a52ad4de-b0ae-49f7-8537-e00e40e7dbe3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a52ad4de-b0ae-49f7-8537-e00e40e7dbe3">
											<gml:posList>35.66939319931876 139.74156858634058 46.937 35.66931697214233 139.74155932856908 46.937 35.66931138448339 139.74156045062196 46.937 35.66930881695253 139.74156226512306 46.937 35.669305513284684 139.74156800183619 46.937 35.66930289695739 139.7416004141206 46.937 35.669392348509994 139.74161129162763 46.937 35.66940149432837 139.7415953636996 46.937 35.66939319931876 139.74156858634058 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95d7333a-1d81-4652-93ea-621ff3c93097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95d7333a-1d81-4652-93ea-621ff3c93097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95d7333a-1d81-4652-93ea-621ff3c93097">
											<gml:posList>35.66931691629202 139.74155700894926 47.6 35.66931697214233 139.74155932856908 47.6 35.66939319931876 139.74156858634058 47.6 35.6693945407306 139.74156644185734 47.6 35.66931691629202 139.74155700894926 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-364e49da-759d-496f-8e1f-deac7070780e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-364e49da-759d-496f-8e1f-deac7070780e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-364e49da-759d-496f-8e1f-deac7070780e">
											<gml:posList>35.66936925807495 139.7414848178724 43.5 35.66936754662161 139.74148633315133 43.5 35.669391473867115 139.7415635623292 43.5 35.6693945407306 139.74156644185734 43.5 35.66936925807495 139.7414848178724 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7dcdcacd-4f5e-4b78-a5ef-ee67251d27b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dcdcacd-4f5e-4b78-a5ef-ee67251d27b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dcdcacd-4f5e-4b78-a5ef-ee67251d27b8">
											<gml:posList>35.669391962561285 139.74156612447052 43.5 35.6693945407306 139.74156644185734 43.5 35.669391473867115 139.7415635623292 43.5 35.669391962561285 139.74156612447052 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-403269cf-6a91-4a1b-bc26-ee76fc4a5650">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-403269cf-6a91-4a1b-bc26-ee76fc4a5650">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-403269cf-6a91-4a1b-bc26-ee76fc4a5650">
											<gml:posList>35.66940359477022 139.74159568163398 47.6 35.66940149432837 139.7415953636996 47.6 35.669392348509994 139.74161129162763 47.6 35.66939324270295 139.74161369865965 47.6 35.66940359477022 139.74159568163398 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11484bd6-ceb7-45ef-ada2-5b9baf4c585f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11484bd6-ceb7-45ef-ada2-5b9baf4c585f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11484bd6-ceb7-45ef-ada2-5b9baf4c585f">
											<gml:posList>35.66940359477022 139.74159568163398 47.6 35.6693945407306 139.74156644185734 47.6 35.66939319931876 139.74156858634058 47.6 35.66940149432837 139.7415953636996 47.6 35.66940359477022 139.74159568163398 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-875da2c5-af6d-44d8-899a-60c1637909c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-875da2c5-af6d-44d8-899a-60c1637909c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-875da2c5-af6d-44d8-899a-60c1637909c8">
											<gml:posList>35.66922082312534 139.74148900868752 41.67 35.66917965625744 139.74154660599314 41.67 35.66917965625744 139.74154660599314 43.5 35.66922082312534 139.74148900868752 43.5 35.66922082312534 139.74148900868752 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47578756-9d2f-484d-abc6-27d966b1a697">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47578756-9d2f-484d-abc6-27d966b1a697">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47578756-9d2f-484d-abc6-27d966b1a697">
											<gml:posList>35.669260966444455 139.74153124719606 41.67 35.66922082312534 139.74148900868752 41.67 35.66922082312534 139.74148900868752 43.5 35.669260966444455 139.74153124719606 43.5 35.669260966444455 139.74153124719606 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47757b25-40b7-443f-95d1-e1fdf4df80fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47757b25-40b7-443f-95d1-e1fdf4df80fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47757b25-40b7-443f-95d1-e1fdf4df80fc">
											<gml:posList>35.66921673683724 139.74135509046087 9.946 35.66921673683724 139.74135509046087 43.5 35.66923836749826 139.7413520832 43.5 35.66923836749826 139.7413520832 9.946 35.66921673683724 139.74135509046087 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5077e302-c231-4253-97dc-36e8a5cabbc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5077e302-c231-4253-97dc-36e8a5cabbc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5077e302-c231-4253-97dc-36e8a5cabbc5">
											<gml:posList>35.6692179915337 139.74135743079464 41.67 35.66923773852882 139.74135469080164 41.67 35.66923773852882 139.74135469080164 43.5 35.6692179915337 139.74135743079464 43.5 35.6692179915337 139.74135743079464 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3db36de8-215e-471f-9df6-71369440adda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3db36de8-215e-471f-9df6-71369440adda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3db36de8-215e-471f-9df6-71369440adda">
											<gml:posList>35.66923836749826 139.7413520832 9.946 35.66923836749826 139.7413520832 43.5 35.66936925807495 139.7414848178724 43.5 35.66936925807495 139.7414848178724 9.946 35.66923836749826 139.7413520832 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4509c934-bf31-40e5-a444-c630d72b22a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4509c934-bf31-40e5-a444-c630d72b22a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4509c934-bf31-40e5-a444-c630d72b22a9">
											<gml:posList>35.66923773852882 139.74135469080164 41.67 35.66936754662161 139.74148633315133 41.67 35.66936754662161 139.74148633315133 43.5 35.66923773852882 139.74135469080164 43.5 35.66923773852882 139.74135469080164 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5df5fca-4132-4458-b068-85ebdc275bd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5df5fca-4132-4458-b068-85ebdc275bd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5df5fca-4132-4458-b068-85ebdc275bd0">
											<gml:posList>35.66914555707502 139.74151083360587 41.67 35.6692179915337 139.74135743079464 41.67 35.6692179915337 139.74135743079464 43.5 35.66914555707502 139.74151083360587 43.5 35.66914555707502 139.74151083360587 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b68cd6f9-f96e-4f03-a1ad-747720b9223c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b68cd6f9-f96e-4f03-a1ad-747720b9223c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b68cd6f9-f96e-4f03-a1ad-747720b9223c">
											<gml:posList>35.66921673683724 139.74135509046087 43.5 35.66921673683724 139.74135509046087 9.946 35.66913574414225 139.74152661865733 9.946 35.66913574414225 139.74152661865733 37.784 35.66914294349913 139.74151136681118 37.784 35.66914294349913 139.74151136681118 43.5 35.66921673683724 139.74135509046087 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ec93d82-f3f4-42fb-9f56-31aec7d217ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ec93d82-f3f4-42fb-9f56-31aec7d217ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ec93d82-f3f4-42fb-9f56-31aec7d217ce">
											<gml:posList>35.66922101507588 139.7414924990352 43.5 35.66922101507588 139.7414924990352 37.26 35.669258073224114 139.74153149352296 37.26 35.669258073224114 139.74153149352296 43.5 35.66922101507588 139.7414924990352 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8ee8382-cfb6-41a5-a516-3ad13d3b9db7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8ee8382-cfb6-41a5-a516-3ad13d3b9db7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8ee8382-cfb6-41a5-a516-3ad13d3b9db7">
											<gml:posList>35.6691383667235 139.74152607439618 37.784 35.6691383667235 139.74152607439618 37.26 35.66914453118658 139.74151303295247 37.26 35.66914453118658 139.74151303295247 37.784 35.6691383667235 139.74152607439618 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecb6994d-358a-490d-8d79-f6c084740076">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecb6994d-358a-490d-8d79-f6c084740076">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecb6994d-358a-490d-8d79-f6c084740076">
											<gml:posList>35.66917985722845 139.74155010737493 43.5 35.66917985722845 139.74155010737493 37.26 35.66922101507588 139.7414924990352 37.26 35.66922101507588 139.7414924990352 43.5 35.66917985722845 139.74155010737493 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72073436-d34a-48f3-a099-a13d98b1fc27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72073436-d34a-48f3-a099-a13d98b1fc27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72073436-d34a-48f3-a099-a13d98b1fc27">
											<gml:posList>35.66936754662161 139.74148633315133 41.67 35.669391473867115 139.7415635623292 41.67 35.669391473867115 139.7415635623292 43.5 35.66936754662161 139.74148633315133 43.5 35.66936754662161 139.74148633315133 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76e8ee8a-fd90-45b8-90a5-7b46372065c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76e8ee8a-fd90-45b8-90a5-7b46372065c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76e8ee8a-fd90-45b8-90a5-7b46372065c4">
											<gml:posList>35.66917965625744 139.74154660599314 41.67 35.66914555707502 139.74151083360587 41.67 35.66914555707502 139.74151083360587 43.5 35.66917965625744 139.74154660599314 43.5 35.66917965625744 139.74154660599314 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a00f24a6-edfa-463f-bbd4-af85054258bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a00f24a6-edfa-463f-bbd4-af85054258bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a00f24a6-edfa-463f-bbd4-af85054258bc">
											<gml:posList>35.66917985722845 139.74155010737493 43.5 35.66914294349913 139.74151136681118 43.5 35.66914294349913 139.74151136681118 37.784 35.66914453118658 139.74151303295247 37.784 35.66914453118658 139.74151303295247 37.26 35.66917985722845 139.74155010737493 37.26 35.66917985722845 139.74155010737493 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8849e962-fd6b-4fdb-9c89-1981c52b7f78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8849e962-fd6b-4fdb-9c89-1981c52b7f78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8849e962-fd6b-4fdb-9c89-1981c52b7f78">
											<gml:posList>35.669251341020825 139.74154470132518 41.67 35.669260966444455 139.74153124719606 41.67 35.669260966444455 139.74153124719606 43.5 35.669251341020825 139.74154470132518 43.5 35.669251341020825 139.74154470132518 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4112e56f-c596-4dff-ba35-355e76b7d689">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4112e56f-c596-4dff-ba35-355e76b7d689">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4112e56f-c596-4dff-ba35-355e76b7d689">
											<gml:posList>35.669258073224114 139.74153149352296 43.5 35.669258073224114 139.74153149352296 37.26 35.66924845680576 139.74154493659515 37.26 35.66924845680576 139.74154493659515 43.5 35.669258073224114 139.74153149352296 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fe1c58e-6d42-4467-b38c-4a2d06ede6e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fe1c58e-6d42-4467-b38c-4a2d06ede6e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fe1c58e-6d42-4467-b38c-4a2d06ede6e0">
											<gml:posList>35.66940359477022 139.74159568163398 9.946 35.66936925807495 139.7414848178724 9.946 35.66936925807495 139.7414848178724 43.5 35.6693945407306 139.74156644185734 43.5 35.6693945407306 139.74156644185734 47.6 35.66940359477022 139.74159568163398 47.6 35.66940359477022 139.74159568163398 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34f8fd06-37e9-4743-8e2c-5670dc81921a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34f8fd06-37e9-4743-8e2c-5670dc81921a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34f8fd06-37e9-4743-8e2c-5670dc81921a">
											<gml:posList>35.6691975085312 139.74158875955374 37.784 35.6691975085312 139.74158875955374 37.26 35.6691383667235 139.74152607439618 37.26 35.6691383667235 139.74152607439618 37.784 35.6691975085312 139.74158875955374 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9b36eae-959f-4f6e-841a-6b5f6619d30d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9b36eae-959f-4f6e-841a-6b5f6619d30d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9b36eae-959f-4f6e-841a-6b5f6619d30d">
											<gml:posList>35.66931691629202 139.74155700894926 47.6 35.66931691629202 139.74155700894926 41.67 35.669310733819884 139.7415582531904 41.67 35.669310733819884 139.7415582531904 47.6 35.66931691629202 139.74155700894926 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c555705a-f212-4353-a768-17c5de05c59f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c555705a-f212-4353-a768-17c5de05c59f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c555705a-f212-4353-a768-17c5de05c59f">
											<gml:posList>35.66919679840786 139.74159133410677 9.946 35.66919679840786 139.74159133410677 37.784 35.66913574414225 139.74152661865733 37.784 35.66913574414225 139.74152661865733 9.946 35.66919679840786 139.74159133410677 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42dfa64c-4be1-4eaa-b244-10e763a2b460">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42dfa64c-4be1-4eaa-b244-10e763a2b460">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42dfa64c-4be1-4eaa-b244-10e763a2b460">
											<gml:posList>35.669310733819884 139.7415582531904 47.6 35.669310733819884 139.7415582531904 41.67 35.669307517654474 139.74156053237064 41.67 35.669307517654474 139.74156053237064 47.6 35.669310733819884 139.7415582531904 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd80d7e7-c61d-4106-9873-4c5b8c28b52e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd80d7e7-c61d-4106-9873-4c5b8c28b52e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd80d7e7-c61d-4106-9873-4c5b8c28b52e">
											<gml:posList>35.66931138448339 139.74156045062196 46.937 35.66931697214233 139.74155932856908 46.937 35.66931697214233 139.74155932856908 47.6 35.66931138448339 139.74156045062196 47.6 35.66931138448339 139.74156045062196 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-455e311c-365b-4ba4-9d91-58a786ca6663">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-455e311c-365b-4ba4-9d91-58a786ca6663">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-455e311c-365b-4ba4-9d91-58a786ca6663">
											<gml:posList>35.66930881695253 139.74156226512306 46.937 35.66931138448339 139.74156045062196 46.937 35.66931138448339 139.74156045062196 47.6 35.66930881695253 139.74156226512306 47.6 35.66930881695253 139.74156226512306 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d37f936-7f42-4cc8-942c-efb4b4460969">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d37f936-7f42-4cc8-942c-efb4b4460969">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d37f936-7f42-4cc8-942c-efb4b4460969">
											<gml:posList>35.66931691629202 139.74155700894926 41.67 35.66931691629202 139.74155700894926 47.6 35.6693945407306 139.74156644185734 47.6 35.6693945407306 139.74156644185734 43.5 35.669391962561285 139.74156612447052 43.5 35.669391962561285 139.74156612447052 41.67 35.66931691629202 139.74155700894926 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7123e3b9-e021-40cf-b20b-d1e48539f508">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7123e3b9-e021-40cf-b20b-d1e48539f508">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7123e3b9-e021-40cf-b20b-d1e48539f508">
											<gml:posList>35.669307517654474 139.74156053237064 47.6 35.669307517654474 139.74156053237064 41.67 35.66930370087785 139.74156715335988 41.67 35.66930370087785 139.74156715335988 47.6 35.669307517654474 139.74156053237064 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18b017a9-5f13-4784-82c0-a7536543ee23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18b017a9-5f13-4784-82c0-a7536543ee23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18b017a9-5f13-4784-82c0-a7536543ee23">
											<gml:posList>35.66931697214233 139.74155932856908 46.937 35.66939319931876 139.74156858634058 46.937 35.66939319931876 139.74156858634058 47.6 35.66931697214233 139.74155932856908 47.6 35.66931697214233 139.74155932856908 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe20aebc-e1a5-4dc3-b9db-e52e98a6d9fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe20aebc-e1a5-4dc3-b9db-e52e98a6d9fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe20aebc-e1a5-4dc3-b9db-e52e98a6d9fb">
											<gml:posList>35.66928830060706 139.74158449128447 41.67 35.669251341020825 139.74154470132518 41.67 35.669251341020825 139.74154470132518 43.5 35.66928830060706 139.74158449128447 43.5 35.66928830060706 139.74158449128447 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7762a224-0d6c-4342-84c6-07e51f5d0bb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7762a224-0d6c-4342-84c6-07e51f5d0bb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7762a224-0d6c-4342-84c6-07e51f5d0bb0">
											<gml:posList>35.669391473867115 139.7415635623292 41.67 35.669391962561285 139.74156612447052 41.67 35.669391962561285 139.74156612447052 43.5 35.669391473867115 139.7415635623292 43.5 35.669391473867115 139.7415635623292 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26bcfeae-1ea7-48b5-bdc9-eb967ad3bafd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26bcfeae-1ea7-48b5-bdc9-eb967ad3bafd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26bcfeae-1ea7-48b5-bdc9-eb967ad3bafd">
											<gml:posList>35.669305513284684 139.74156800183619 46.937 35.66930881695253 139.74156226512306 46.937 35.66930881695253 139.74156226512306 47.6 35.669305513284684 139.74156800183619 47.6 35.669305513284684 139.74156800183619 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60726b06-3a26-4c7a-80ba-cb29549f847f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60726b06-3a26-4c7a-80ba-cb29549f847f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60726b06-3a26-4c7a-80ba-cb29549f847f">
											<gml:posList>35.66924845680576 139.74154493659515 43.5 35.66924845680576 139.74154493659515 37.26 35.66928744612956 139.74158688926786 37.26 35.66928744612956 139.74158688926786 43.5 35.66924845680576 139.74154493659515 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5509853a-986e-4742-8d7e-a2a3e7fe4b77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5509853a-986e-4742-8d7e-a2a3e7fe4b77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5509853a-986e-4742-8d7e-a2a3e7fe4b77">
											<gml:posList>35.66924411221933 139.74155680508332 37.784 35.66924411221933 139.74155680508332 37.26 35.66922235787222 139.74158676491487 37.26 35.66922235787222 139.74158676491487 37.784 35.66924411221933 139.74155680508332 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4386efc2-d618-445a-822e-0ca22270c95c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4386efc2-d618-445a-822e-0ca22270c95c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4386efc2-d618-445a-822e-0ca22270c95c">
											<gml:posList>35.66924430418474 139.74156031752437 37.784 35.66922333321446 139.74158920498695 37.784 35.66922333321446 139.74158920498695 9.946 35.66924430418474 139.74156031752437 9.946 35.66924430418474 139.74156031752437 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-975305ef-bacc-44f3-a69b-fde1173bd6fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-975305ef-bacc-44f3-a69b-fde1173bd6fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-975305ef-bacc-44f3-a69b-fde1173bd6fe">
											<gml:posList>35.66928311881753 139.74159777463618 37.784 35.66928311881753 139.74159777463618 37.26 35.66924411221933 139.74155680508332 37.26 35.66924411221933 139.74155680508332 37.784 35.66928311881753 139.74159777463618 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce3a5127-5f55-440b-bab9-19240c30e41d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce3a5127-5f55-440b-bab9-19240c30e41d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce3a5127-5f55-440b-bab9-19240c30e41d">
											<gml:posList>35.66928227337875 139.74160020574726 9.946 35.66928227337875 139.74160020574726 37.784 35.66924430418474 139.74156031752437 37.784 35.66924430418474 139.74156031752437 9.946 35.66928227337875 139.74160020574726 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b23a2ae-ba8f-4668-9140-53ae72097011">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b23a2ae-ba8f-4668-9140-53ae72097011">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b23a2ae-ba8f-4668-9140-53ae72097011">
											<gml:posList>35.66939319931876 139.74156858634058 46.937 35.66940149432837 139.7415953636996 46.937 35.66940149432837 139.7415953636996 47.6 35.66939319931876 139.74156858634058 47.6 35.66939319931876 139.74156858634058 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1933888-48db-41a3-855a-3883242ce666">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1933888-48db-41a3-855a-3883242ce666">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1933888-48db-41a3-855a-3883242ce666">
											<gml:posList>35.66930289695739 139.7416004141206 46.937 35.669305513284684 139.74156800183619 46.937 35.669305513284684 139.74156800183619 47.6 35.66930289695739 139.7416004141206 47.6 35.66930289695739 139.7416004141206 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd82c002-a1ff-449b-9586-ff8cb80f457f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd82c002-a1ff-449b-9586-ff8cb80f457f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd82c002-a1ff-449b-9586-ff8cb80f457f">
											<gml:posList>35.66930370087785 139.74156715335988 41.67 35.669302156048396 139.74158624280778 41.67 35.669302156048396 139.74158624280778 43.5 35.66930195064321 139.74158875051003 43.5 35.66930195064321 139.74158875051003 37.26 35.66930104879041 139.74159995229837 37.26 35.66930104879041 139.74159995229837 37.784 35.66930084338494 139.74160246000056 37.784 35.66930084338494 139.74160246000056 47.6 35.66930370087785 139.74156715335988 47.6 35.66930370087785 139.74156715335988 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bbbd9899-fe96-4fa5-9320-2288a56922bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbbd9899-fe96-4fa5-9320-2288a56922bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbbd9899-fe96-4fa5-9320-2288a56922bc">
											<gml:posList>35.6693001277752 139.7415860021142 41.67 35.66928830060706 139.74158449128447 41.67 35.66928830060706 139.74158449128447 43.5 35.6693001277752 139.7415860021142 43.5 35.6693001277752 139.7415860021142 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d59f1b7-c2a2-4143-9d86-12f3cd5d7fec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d59f1b7-c2a2-4143-9d86-12f3cd5d7fec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d59f1b7-c2a2-4143-9d86-12f3cd5d7fec">
											<gml:posList>35.669302156048396 139.74158624280778 41.67 35.6693001277752 139.7415860021142 41.67 35.6693001277752 139.7415860021142 43.5 35.669302156048396 139.74158624280778 43.5 35.669302156048396 139.74158624280778 41.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dfabed3d-5b96-4100-b0b4-40207f5b6a4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfabed3d-5b96-4100-b0b4-40207f5b6a4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfabed3d-5b96-4100-b0b4-40207f5b6a4e">
											<gml:posList>35.66922235787222 139.74158676491487 37.784 35.66922235787222 139.74158676491487 37.26 35.6691975085312 139.74158875955374 37.26 35.6691975085312 139.74158875955374 37.784 35.66922235787222 139.74158676491487 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51548dc5-550d-4bb1-b05a-29815c8ce7ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51548dc5-550d-4bb1-b05a-29815c8ce7ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51548dc5-550d-4bb1-b05a-29815c8ce7ff">
											<gml:posList>35.66928744612956 139.74158688926786 43.5 35.66928744612956 139.74158688926786 37.26 35.66930195064321 139.74158875051003 37.26 35.66930195064321 139.74158875051003 43.5 35.66928744612956 139.74158688926786 43.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0e64c9d-fd61-45ad-8edc-5d2031bd84dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0e64c9d-fd61-45ad-8edc-5d2031bd84dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0e64c9d-fd61-45ad-8edc-5d2031bd84dd">
											<gml:posList>35.66922333321446 139.74158920498695 9.946 35.66922333321446 139.74158920498695 37.784 35.66919679840786 139.74159133410677 37.784 35.66919679840786 139.74159133410677 9.946 35.66922333321446 139.74158920498695 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7926ea9-5dba-43da-93a8-d65e906ab74f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7926ea9-5dba-43da-93a8-d65e906ab74f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7926ea9-5dba-43da-93a8-d65e906ab74f">
											<gml:posList>35.66930104879041 139.74159995229837 37.784 35.66930104879041 139.74159995229837 37.26 35.66928311881753 139.74159777463618 37.26 35.66928311881753 139.74159777463618 37.784 35.66930104879041 139.74159995229837 37.784</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0bc594d-bc11-43ab-8b05-bd8e90b84a63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0bc594d-bc11-43ab-8b05-bd8e90b84a63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0bc594d-bc11-43ab-8b05-bd8e90b84a63">
											<gml:posList>35.66940149432837 139.7415953636996 46.937 35.669392348509994 139.74161129162763 46.937 35.669392348509994 139.74161129162763 47.6 35.66940149432837 139.7415953636996 47.6 35.66940149432837 139.7415953636996 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffe97263-30df-48a8-9020-de29eeb0bf52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffe97263-30df-48a8-9020-de29eeb0bf52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffe97263-30df-48a8-9020-de29eeb0bf52">
											<gml:posList>35.66939324270295 139.74161369865965 9.946 35.66940359477022 139.74159568163398 9.946 35.66940359477022 139.74159568163398 47.6 35.66939324270295 139.74161369865965 47.6 35.66939324270295 139.74161369865965 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4d34202-4606-4a19-8978-1ad2498df5f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4d34202-4606-4a19-8978-1ad2498df5f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4d34202-4606-4a19-8978-1ad2498df5f6">
											<gml:posList>35.669392348509994 139.74161129162763 46.937 35.66930289695739 139.7416004141206 46.937 35.66930289695739 139.7416004141206 47.6 35.669392348509994 139.74161129162763 47.6 35.669392348509994 139.74161129162763 46.937</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af4eddff-ed07-46e4-9706-3734c24397f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af4eddff-ed07-46e4-9706-3734c24397f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af4eddff-ed07-46e4-9706-3734c24397f5">
											<gml:posList>35.66939324270295 139.74161369865965 9.946 35.66939324270295 139.74161369865965 47.6 35.66930084338494 139.74160246000056 47.6 35.66930084338494 139.74160246000056 37.784 35.66928227337875 139.74160020574726 37.784 35.66928227337875 139.74160020574726 9.946 35.66939324270295 139.74161369865965 9.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6931</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">308.29715</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>