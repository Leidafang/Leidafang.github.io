<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_18d765e3-af6e-4212-ba67-1f3da6482519">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">23.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672777965658085 139.7377598690464 0 35.6728886126346 139.7377074867 0 35.67286737668778 139.73763990682667 0 35.67275672974037 139.73769228925232 0 35.672777965658085 139.7377598690464 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672777965658085 139.7377598690464 8.758 35.67275672974037 139.73769228925232 8.758 35.67286737668778 139.73763990682667 8.758 35.6728886126346 139.7377074867 8.758 35.672777965658085 139.7377598690464 8.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672777965658085 139.7377598690464 8.758 35.6728886126346 139.7377074867 8.758 35.6728886126346 139.7377074867 32.25 35.672777965658085 139.7377598690464 32.25 35.672777965658085 139.7377598690464 8.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6728886126346 139.7377074867 8.758 35.67286737668778 139.73763990682667 8.758 35.67286737668778 139.73763990682667 32.25 35.6728886126346 139.7377074867 32.25 35.6728886126346 139.7377074867 8.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286737668778 139.73763990682667 8.758 35.67275672974037 139.73769228925232 8.758 35.67275672974037 139.73769228925232 32.25 35.67286737668778 139.73763990682667 32.25 35.67286737668778 139.73763990682667 8.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67275672974037 139.73769228925232 8.758 35.672777965658085 139.7377598690464 8.758 35.672777965658085 139.7377598690464 32.25 35.67275672974037 139.73769228925232 32.25 35.67275672974037 139.73769228925232 8.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672777965658085 139.7377598690464 32.25 35.6728886126346 139.7377074867 32.25 35.67286737668778 139.73763990682667 32.25 35.67275672974037 139.73769228925232 32.25 35.672777965658085 139.7377598690464 32.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-230c372b-6a50-42b1-88ca-f5996342abb9"/>
							<gml:surfaceMember xlink:href="#poly-b808a646-a496-4139-8243-c82b28876b0c"/>
							<gml:surfaceMember xlink:href="#poly-379639dc-888a-421c-a217-a06d587565ac"/>
							<gml:surfaceMember xlink:href="#poly-27965cb9-9447-4908-94a5-c6f98d78638d"/>
							<gml:surfaceMember xlink:href="#poly-2c9cab7e-5eb5-41f3-b34f-2ad0dd7add39"/>
							<gml:surfaceMember xlink:href="#poly-fdf1192f-4d32-411c-a5aa-1a9d4b88a361"/>
							<gml:surfaceMember xlink:href="#poly-ac8dc330-9ac9-4cbd-84fb-bb9f1fa2936a"/>
							<gml:surfaceMember xlink:href="#poly-4b436828-ed06-4bf1-9428-cb54ca1d1556"/>
							<gml:surfaceMember xlink:href="#poly-2f0a95f9-4932-48b6-b47a-ebd6336b6e55"/>
							<gml:surfaceMember xlink:href="#poly-6bdcac84-ecbf-4ada-95be-71dd935cc01e"/>
							<gml:surfaceMember xlink:href="#poly-0e72a055-c761-4444-b6ec-06d314e19aaf"/>
							<gml:surfaceMember xlink:href="#poly-05c907eb-908e-4a7f-96d0-4efae318a773"/>
							<gml:surfaceMember xlink:href="#poly-0703f5c3-98bf-4f3b-8a0b-02f4f9eae10b"/>
							<gml:surfaceMember xlink:href="#poly-077b2f84-82bc-48af-8df9-4c6d074529e9"/>
							<gml:surfaceMember xlink:href="#poly-e89e2dfa-7c1a-4f48-a681-f5052e2e2f8a"/>
							<gml:surfaceMember xlink:href="#poly-9af8c2c2-56bd-4f62-88b1-c5d875560355"/>
							<gml:surfaceMember xlink:href="#poly-a3b600c5-4773-4073-a9dd-4e25d65ffc3c"/>
							<gml:surfaceMember xlink:href="#poly-458ded32-47f6-426a-af9f-100c1d281be2"/>
							<gml:surfaceMember xlink:href="#poly-1eea37bd-8742-4e4e-8291-d3003988b072"/>
							<gml:surfaceMember xlink:href="#poly-e13fd9d2-ca1f-4efb-ad61-f6d207a001f2"/>
							<gml:surfaceMember xlink:href="#poly-a50f2581-c4ec-4204-98c4-23f877fb9255"/>
							<gml:surfaceMember xlink:href="#poly-7645fcd8-1c76-4960-8a0f-8dddab0d59d1"/>
							<gml:surfaceMember xlink:href="#poly-5d93a1d2-7305-4e2c-a633-5dad60c39bf2"/>
							<gml:surfaceMember xlink:href="#poly-6f68797f-81de-4e59-afa2-6a049f0ecb70"/>
							<gml:surfaceMember xlink:href="#poly-0ecd006a-e16d-4391-8486-14a1b180584a"/>
							<gml:surfaceMember xlink:href="#poly-5d6253e0-5800-4a4b-b874-95ee4a9680f8"/>
							<gml:surfaceMember xlink:href="#poly-4ff327cc-eb7f-4566-9daa-a0b04294804a"/>
							<gml:surfaceMember xlink:href="#poly-65ffee8a-a059-4395-ae2d-25d86e219fea"/>
							<gml:surfaceMember xlink:href="#poly-1f8a5ab8-38f9-4ea0-9467-39aa05f18737"/>
							<gml:surfaceMember xlink:href="#poly-dd58017f-72ca-4fdc-8467-ce5e859b19b9"/>
							<gml:surfaceMember xlink:href="#poly-b46b7711-97b7-4d6b-90ea-ed826fed7319"/>
							<gml:surfaceMember xlink:href="#poly-8ff65d09-5d65-4a44-bfef-4cf80f0b4e45"/>
							<gml:surfaceMember xlink:href="#poly-64c3153f-f480-40a7-85e6-739c1be6b99e"/>
							<gml:surfaceMember xlink:href="#poly-476abe4f-6784-462d-a6c3-f5aabe959bef"/>
							<gml:surfaceMember xlink:href="#poly-24b1ebad-a4a6-48c0-8b02-eb96bc6e5c82"/>
							<gml:surfaceMember xlink:href="#poly-547561e6-cd9c-452b-9518-8470a22562b4"/>
							<gml:surfaceMember xlink:href="#poly-3cd8a1de-3e87-4220-b046-b169e71345e5"/>
							<gml:surfaceMember xlink:href="#poly-95534539-5ddc-4a39-81ad-625d0d17d2c3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_18d765e3-af6e-4212-ba67-1f3da6482519_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c874529f-7f8d-4e18-a524-ff6ba7e96e2e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67288514044934 139.73770509372844 31.372 35.672865317708435 139.73771448489146 31.372 35.67285678727215 139.73768744194135 31.372 35.672876619024684 139.7376780507619 31.372 35.67288514044934 139.73770509372844 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b30d6ee2-ee09-442d-b551-ebe3fc27172d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b30d6ee2-ee09-442d-b551-ebe3fc27172d_0">
											<gml:posList>35.67285678727215 139.73768744194135 31.372 35.67285678727215 139.73768744194135 33.445 35.672876619024684 139.7376780507619 33.445 35.672876619024684 139.7376780507619 31.372 35.67285678727215 139.73768744194135 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1e877da-daff-45df-b39d-8242631ed259">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1e877da-daff-45df-b39d-8242631ed259_0">
											<gml:posList>35.672876619024684 139.7376780507619 33.445 35.67288514044934 139.73770509372844 33.445 35.67288514044934 139.73770509372844 31.372 35.672876619024684 139.7376780507619 31.372 35.672876619024684 139.7376780507619 33.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9913db2-42ec-4b1d-b6e6-433deed5f6ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9913db2-42ec-4b1d-b6e6-433deed5f6ff_0">
											<gml:posList>35.67288514044934 139.73770509372844 33.445 35.672876619024684 139.7376780507619 33.445 35.67285678727215 139.73768744194135 33.445 35.672865317708435 139.73771448489146 33.445 35.67288514044934 139.73770509372844 33.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c5e71fa-a601-4984-971e-673aebf1e90d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c5e71fa-a601-4984-971e-673aebf1e90d_0">
											<gml:posList>35.672865317708435 139.73771448489146 33.445 35.67285678727215 139.73768744194135 33.445 35.67285678727215 139.73768744194135 31.372 35.672865317708435 139.73771448489146 31.372 35.672865317708435 139.73771448489146 33.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e56a87ed-7d63-4e73-accd-56e31e272598">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e56a87ed-7d63-4e73-accd-56e31e272598_0">
											<gml:posList>35.67288514044934 139.73770509372844 31.372 35.67288514044934 139.73770509372844 33.445 35.672865317708435 139.73771448489146 33.445 35.672865317708435 139.73771448489146 31.372 35.67288514044934 139.73770509372844 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_18d765e3-af6e-4212-ba67-1f3da6482519_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73a1d2b5-d5b3-43a2-9bae-c72808f98d98">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67284111102088 139.73768570423454 31.372 35.672843984631 139.73769482529664 31.372 35.67283270368467 139.73770016321396 31.372 35.67282983007495 139.73769104215296 31.372 35.67284111102088 139.73768570423454 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1be6797-e2f4-421f-9294-0dafd3b11cf0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672786838368374 139.73771848898662 31.372 35.672777323451825 139.73772299629644 31.372 35.67276723872698 139.73769100635778 31.372 35.67277675364235 139.7376864990447 31.372 35.672786838368374 139.73771848898662 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97f0c871-3884-48fc-a40a-e35f781a470f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67280600663498 139.737713539345 31.372 35.67279105848152 139.73772061594565 31.372 35.67278445281174 139.73769966844165 31.372 35.67279940096397 139.7376925918377 31.372 35.67280600663498 139.737713539345 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c37b0d8a-8b80-401f-8f96-b3a189d5f015">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67278785094269 139.73773366579485 31.372 35.672833236578 139.73771287721158 31.372 35.672837899796654 139.73772816014102 31.372 35.672792514158715 139.73774894871687 31.372 35.67278785094269 139.73773366579485 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd64cb12-3f0f-4a4c-9f91-a6258882825e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd64cb12-3f0f-4a4c-9f91-a6258882825e_0">
											<gml:posList>35.67284111102088 139.73768570423454 35.17 35.67284111102088 139.73768570423454 31.372 35.67282983007495 139.73769104215296 31.372 35.67282983007495 139.73769104215296 35.17 35.67284111102088 139.73768570423454 35.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4707a061-922f-45ae-b5f3-73b73401d4e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4707a061-922f-45ae-b5f3-73b73401d4e4_0">
											<gml:posList>35.67276723872698 139.73769100635778 31.372 35.67276723872698 139.73769100635778 33.441 35.67277675364235 139.7376864990447 33.441 35.67277675364235 139.7376864990447 31.372 35.67276723872698 139.73769100635778 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8510dc85-05e5-416e-8b6d-266bf0dfe5de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8510dc85-05e5-416e-8b6d-266bf0dfe5de_0">
											<gml:posList>35.67284111102088 139.73768570423454 31.372 35.67284111102088 139.73768570423454 35.17 35.672843984631 139.73769482529664 35.17 35.672843984631 139.73769482529664 31.372 35.67284111102088 139.73768570423454 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db13f1de-aa8b-4776-b504-bc00bebc747d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db13f1de-aa8b-4776-b504-bc00bebc747d_0">
											<gml:posList>35.67283270368467 139.73770016321396 35.17 35.672843984631 139.73769482529664 35.17 35.67284111102088 139.73768570423454 35.17 35.67282983007495 139.73769104215296 35.17 35.67283270368467 139.73770016321396 35.17</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26335803-60ab-41b6-a7a0-7452aa2c776f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26335803-60ab-41b6-a7a0-7452aa2c776f_0">
											<gml:posList>35.67282983007495 139.73769104215296 31.372 35.67283270368467 139.73770016321396 31.372 35.67283270368467 139.73770016321396 35.17 35.67282983007495 139.73769104215296 35.17 35.67282983007495 139.73769104215296 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9c17e31-8a07-4b1c-981e-4afc98431598">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9c17e31-8a07-4b1c-981e-4afc98431598_0">
											<gml:posList>35.67278445281174 139.73769966844165 31.372 35.67278445281174 139.73769966844165 33.441 35.67279940096397 139.7376925918377 33.441 35.67279940096397 139.7376925918377 31.372 35.67278445281174 139.73769966844165 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9bc0b2e-aa67-4ccf-afa3-affc95a47ccb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9bc0b2e-aa67-4ccf-afa3-affc95a47ccb_0">
											<gml:posList>35.67283270368467 139.73770016321396 31.372 35.672843984631 139.73769482529664 31.372 35.672843984631 139.73769482529664 35.17 35.67283270368467 139.73770016321396 35.17 35.67283270368467 139.73770016321396 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d83fa8d6-93dc-44b9-9693-b16870b5f925">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d83fa8d6-93dc-44b9-9693-b16870b5f925_0">
											<gml:posList>35.67277675364235 139.7376864990447 31.372 35.67277675364235 139.7376864990447 33.441 35.672786838368374 139.73771848898662 33.441 35.672786838368374 139.73771848898662 31.372 35.67277675364235 139.7376864990447 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b69a32a-5e2d-46ff-b1eb-9448394408ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b69a32a-5e2d-46ff-b1eb-9448394408ae_0">
											<gml:posList>35.67279940096397 139.7376925918377 31.372 35.67279940096397 139.7376925918377 33.441 35.67280600663498 139.737713539345 33.441 35.67280600663498 139.737713539345 31.372 35.67279940096397 139.7376925918377 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a4d0eaf-9c98-491e-9259-be2222fd494f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a4d0eaf-9c98-491e-9259-be2222fd494f_0">
											<gml:posList>35.672786838368374 139.73771848898662 33.441 35.67277675364235 139.7376864990447 33.441 35.67276723872698 139.73769100635778 33.441 35.672777323451825 139.73772299629644 33.441 35.672786838368374 139.73771848898662 33.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce9f546b-7edc-40f5-86fa-1ec9f4b77e79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce9f546b-7edc-40f5-86fa-1ec9f4b77e79_0">
											<gml:posList>35.67280600663498 139.737713539345 33.441 35.67279940096397 139.7376925918377 33.441 35.67278445281174 139.73769966844165 33.441 35.67279105848152 139.73772061594565 33.441 35.67280600663498 139.737713539345 33.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e14b21c1-d185-43aa-af61-ac27f0e975fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e14b21c1-d185-43aa-af61-ac27f0e975fc_0">
											<gml:posList>35.672777323451825 139.73772299629644 31.372 35.672777323451825 139.73772299629644 33.441 35.67276723872698 139.73769100635778 33.441 35.67276723872698 139.73769100635778 31.372 35.672777323451825 139.73772299629644 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05423efe-5880-4535-a3a3-da1d7209c575">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05423efe-5880-4535-a3a3-da1d7209c575_0">
											<gml:posList>35.67278445281174 139.73769966844165 31.372 35.67279105848152 139.73772061594565 31.372 35.67279105848152 139.73772061594565 33.441 35.67278445281174 139.73769966844165 33.441 35.67278445281174 139.73769966844165 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-179faa44-8a4c-4d3c-9577-777469eecace">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-179faa44-8a4c-4d3c-9577-777469eecace_0">
											<gml:posList>35.67280600663498 139.737713539345 31.372 35.67280600663498 139.737713539345 33.441 35.67279105848152 139.73772061594565 33.441 35.67279105848152 139.73772061594565 31.372 35.67280600663498 139.737713539345 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07722093-a1de-4c17-98c3-961548395284">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07722093-a1de-4c17-98c3-961548395284_0">
											<gml:posList>35.672837899796654 139.73772816014102 31.372 35.672833236578 139.73771287721158 31.372 35.672833236578 139.73771287721158 33.441 35.672837899796654 139.73772816014102 33.441 35.672837899796654 139.73772816014102 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e10f73f5-8543-4cf5-81a2-7df4032b7d1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e10f73f5-8543-4cf5-81a2-7df4032b7d1d_0">
											<gml:posList>35.672777323451825 139.73772299629644 31.372 35.672786838368374 139.73771848898662 31.372 35.672786838368374 139.73771848898662 33.441 35.672777323451825 139.73772299629644 33.441 35.672777323451825 139.73772299629644 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7d9686a-330f-49f4-9601-ad2e90887c30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7d9686a-330f-49f4-9601-ad2e90887c30_0">
											<gml:posList>35.67278785094269 139.73773366579485 31.372 35.67278785094269 139.73773366579485 33.441 35.672833236578 139.73771287721158 33.441 35.672833236578 139.73771287721158 31.372 35.67278785094269 139.73773366579485 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2802820-eb1d-4db7-a06c-072b084638bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2802820-eb1d-4db7-a06c-072b084638bd_0">
											<gml:posList>35.672837899796654 139.73772816014102 33.441 35.672833236578 139.73771287721158 33.441 35.67278785094269 139.73773366579485 33.441 35.672792514158715 139.73774894871687 33.441 35.672837899796654 139.73772816014102 33.441</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5f5facb-5c87-4d1a-91b4-32ddd45a9169">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5f5facb-5c87-4d1a-91b4-32ddd45a9169_0">
											<gml:posList>35.672792514158715 139.73774894871687 31.372 35.672837899796654 139.73772816014102 31.372 35.672837899796654 139.73772816014102 33.441 35.672792514158715 139.73774894871687 33.441 35.672792514158715 139.73774894871687 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b6ddfec-418d-42a6-9d3b-37c6646fb710">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b6ddfec-418d-42a6-9d3b-37c6646fb710_0">
											<gml:posList>35.672792514158715 139.73774894871687 31.372 35.672792514158715 139.73774894871687 33.441 35.67278785094269 139.73773366579485 33.441 35.67278785094269 139.73773366579485 31.372 35.672792514158715 139.73774894871687 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-230c372b-6a50-42b1-88ca-f5996342abb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-230c372b-6a50-42b1-88ca-f5996342abb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-230c372b-6a50-42b1-88ca-f5996342abb9">
											<gml:posList>35.672777965658085 139.7377598690464 8.758 35.67275672974037 139.73769228925232 8.758 35.67286737668775 139.73763990682667 8.758 35.672888612634594 139.7377074867 8.758 35.672777965658085 139.7377598690464 8.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b808a646-a496-4139-8243-c82b28876b0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b808a646-a496-4139-8243-c82b28876b0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b808a646-a496-4139-8243-c82b28876b0c">
											<gml:posList>35.67286627939322 139.73764290176547 31.756 35.67286737668775 139.73763990682667 31.756 35.67286046575565 139.73764317382302 31.756 35.67286114349635 139.73764532710126 31.756 35.67286627939322 139.73764290176547 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-379639dc-888a-421c-a217-a06d587565ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-379639dc-888a-421c-a217-a06d587565ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-379639dc-888a-421c-a217-a06d587565ac">
											<gml:posList>35.67285901773363 139.7376471854674 33.899 35.67286046575565 139.73764317382302 33.899 35.67283326354923 139.73765605348368 33.899 35.67283417623447 139.73765894660295 33.899 35.67285901773363 139.7376471854674 33.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27965cb9-9447-4908-94a5-c6f98d78638d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27965cb9-9447-4908-94a5-c6f98d78638d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27965cb9-9447-4908-94a5-c6f98d78638d">
											<gml:posList>35.67286046575565 139.73764317382302 33.899 35.67285901773363 139.7376471854674 33.899 35.67286634633545 139.737670429817 33.899 35.67286961972813 139.737672204414 33.899 35.67286046575565 139.73764317382302 33.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c9cab7e-5eb5-41f3-b34f-2ad0dd7add39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c9cab7e-5eb5-41f3-b34f-2ad0dd7add39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c9cab7e-5eb5-41f3-b34f-2ad0dd7add39">
											<gml:posList>35.67280136695808 139.7376711591024 36.108 35.67280402716343 139.73767261407843 36.108 35.67283207633653 139.73765932469325 36.108 35.67283326354923 139.73765605348368 36.108 35.67280136695808 139.7376711591024 36.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fdf1192f-4d32-411c-a5aa-1a9d4b88a361">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdf1192f-4d32-411c-a5aa-1a9d4b88a361">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdf1192f-4d32-411c-a5aa-1a9d4b88a361">
											<gml:posList>35.67283417623447 139.73765894660295 33.649 35.672841495820315 139.7376821909572 33.649 35.67286634633545 139.737670429817 33.649 35.67285901773363 139.7376471854674 33.649 35.67283417623447 139.73765894660295 33.649</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ac8dc330-9ac9-4cbd-84fb-bb9f1fa2936a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac8dc330-9ac9-4cbd-84fb-bb9f1fa2936a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac8dc330-9ac9-4cbd-84fb-bb9f1fa2936a">
											<gml:posList>35.67283326354923 139.73765605348368 36.108 35.67283207633653 139.73765932469325 36.108 35.67283973929478 139.7376836401573 36.108 35.67284240850492 139.73768508407707 36.108 35.67283326354923 139.73765605348368 36.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4b436828-ed06-4bf1-9428-cb54ca1d1556">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b436828-ed06-4bf1-9428-cb54ca1d1556">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b436828-ed06-4bf1-9428-cb54ca1d1556">
											<gml:posList>35.67286737668775 139.73763990682667 31.756 35.67286627939322 139.73764290176547 31.756 35.6728861598417 139.73770615298653 31.756 35.672888612634594 139.7377074867 31.756 35.67286737668775 139.73763990682667 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f0a95f9-4932-48b6-b47a-ebd6336b6e55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f0a95f9-4932-48b6-b47a-ebd6336b6e55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f0a95f9-4932-48b6-b47a-ebd6336b6e55">
											<gml:posList>35.67286634633545 139.737670429817 33.899 35.672841495820315 139.7376821909572 33.899 35.67284240850492 139.73768508407707 33.899 35.67286961972813 139.737672204414 33.899 35.67286634633545 139.737670429817 33.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6bdcac84-ecbf-4ada-95be-71dd935cc01e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bdcac84-ecbf-4ada-95be-71dd935cc01e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bdcac84-ecbf-4ada-95be-71dd935cc01e">
											<gml:posList>35.67283973929478 139.7376836401573 35.671 35.67283207633653 139.73765932469325 35.671 35.67280402716343 139.73767261407843 35.671 35.67281169913275 139.73769692952447 35.671 35.67283973929478 139.7376836401573 35.671</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e72a055-c761-4444-b6ec-06d314e19aaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e72a055-c761-4444-b6ec-06d314e19aaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e72a055-c761-4444-b6ec-06d314e19aaf">
											<gml:posList>35.67276613849178 139.7376903006887 31.756 35.67280205372079 139.73767332341512 31.756 35.67280136695808 139.7376711591024 31.756 35.67276369472993 139.7376889890602 31.756 35.67276613849178 139.7376903006887 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05c907eb-908e-4a7f-96d0-4efae318a773">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05c907eb-908e-4a7f-96d0-4efae318a773">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05c907eb-908e-4a7f-96d0-4efae318a773">
											<gml:posList>35.67281052092388 139.7377001896752 36.108 35.67281169913275 139.73769692952447 36.108 35.67280402716343 139.73767261407843 36.108 35.67280136695808 139.7376711591024 36.108 35.67281052092388 139.7377001896752 36.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0703f5c3-98bf-4f3b-8a0b-02f4f9eae10b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0703f5c3-98bf-4f3b-8a0b-02f4f9eae10b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0703f5c3-98bf-4f3b-8a0b-02f4f9eae10b">
											<gml:posList>35.67284240850492 139.73768508407707 36.108 35.67283973929478 139.7376836401573 36.108 35.67281169913275 139.73769692952447 36.108 35.67281052092388 139.7377001896752 36.108 35.67284240850492 139.73768508407707 36.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-077b2f84-82bc-48af-8df9-4c6d074529e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-077b2f84-82bc-48af-8df9-4c6d074529e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-077b2f84-82bc-48af-8df9-4c6d074529e9">
											<gml:posList>35.6728861598417 139.73770615298653 31.372 35.67286627939322 139.73764290176547 31.372 35.67286114349635 139.73764532710126 31.372 35.67286961972813 139.737672204414 31.372 35.67281052092388 139.7377001896752 31.372 35.67280205372079 139.73767332341512 31.372 35.67276613849178 139.7376903006887 31.372 35.67278606397543 139.73775354074232 31.372 35.6728861598417 139.73770615298653 31.372</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e89e2dfa-7c1a-4f48-a681-f5052e2e2f8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e89e2dfa-7c1a-4f48-a681-f5052e2e2f8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e89e2dfa-7c1a-4f48-a681-f5052e2e2f8a">
											<gml:posList>35.672784984714255 139.73775654670163 31.756 35.67278606397543 139.73775354074232 31.756 35.67276613849178 139.7376903006887 31.756 35.67276369472993 139.7376889890602 31.756 35.672784984714255 139.73775654670163 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9af8c2c2-56bd-4f62-88b1-c5d875560355">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9af8c2c2-56bd-4f62-88b1-c5d875560355">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9af8c2c2-56bd-4f62-88b1-c5d875560355">
											<gml:posList>35.67276369472993 139.7376889890602 30.639 35.67275672974037 139.73769228925232 30.639 35.672777965658085 139.7377598690464 30.639 35.672784984714255 139.73775654670163 30.639 35.67276369472993 139.7376889890602 30.639</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3b600c5-4773-4073-a9dd-4e25d65ffc3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3b600c5-4773-4073-a9dd-4e25d65ffc3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3b600c5-4773-4073-a9dd-4e25d65ffc3c">
											<gml:posList>35.672888612634594 139.7377074867 31.756 35.6728861598417 139.73770615298653 31.756 35.67278606397543 139.73775354074232 31.756 35.672784984714255 139.73775654670163 31.756 35.672888612634594 139.7377074867 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-458ded32-47f6-426a-af9f-100c1d281be2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-458ded32-47f6-426a-af9f-100c1d281be2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-458ded32-47f6-426a-af9f-100c1d281be2">
											<gml:posList>35.67280402716343 139.73767261407843 36.108 35.67280402716343 139.73767261407843 35.671 35.67283207633653 139.73765932469325 35.671 35.67283207633653 139.73765932469325 36.108 35.67280402716343 139.73767261407843 36.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1eea37bd-8742-4e4e-8291-d3003988b072">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1eea37bd-8742-4e4e-8291-d3003988b072">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1eea37bd-8742-4e4e-8291-d3003988b072">
											<gml:posList>35.67286634633545 139.737670429817 33.899 35.67286634633545 139.737670429817 33.649 35.672841495820315 139.7376821909572 33.649 35.672841495820315 139.7376821909572 33.899 35.67286634633545 139.737670429817 33.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e13fd9d2-ca1f-4efb-ad61-f6d207a001f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e13fd9d2-ca1f-4efb-ad61-f6d207a001f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e13fd9d2-ca1f-4efb-ad61-f6d207a001f2">
											<gml:posList>35.67283973929478 139.7376836401573 36.108 35.67283973929478 139.7376836401573 35.671 35.67281169913275 139.73769692952447 35.671 35.67281169913275 139.73769692952447 36.108 35.67283973929478 139.7376836401573 36.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a50f2581-c4ec-4204-98c4-23f877fb9255">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a50f2581-c4ec-4204-98c4-23f877fb9255">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a50f2581-c4ec-4204-98c4-23f877fb9255">
											<gml:posList>35.67275672974037 139.73769228925232 8.758 35.672777965658085 139.7377598690464 8.758 35.672777965658085 139.7377598690464 30.639 35.67275672974037 139.73769228925232 30.639 35.67275672974037 139.73769228925232 8.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7645fcd8-1c76-4960-8a0f-8dddab0d59d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7645fcd8-1c76-4960-8a0f-8dddab0d59d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7645fcd8-1c76-4960-8a0f-8dddab0d59d1">
											<gml:posList>35.672784984714255 139.73775654670163 30.639 35.672784984714255 139.73775654670163 31.756 35.67276369472993 139.7376889890602 31.756 35.67276369472993 139.7376889890602 30.639 35.672784984714255 139.73775654670163 30.639</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d93a1d2-7305-4e2c-a633-5dad60c39bf2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d93a1d2-7305-4e2c-a633-5dad60c39bf2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d93a1d2-7305-4e2c-a633-5dad60c39bf2">
											<gml:posList>35.67278606397543 139.73775354074232 31.756 35.67278606397543 139.73775354074232 31.372 35.67276613849178 139.7376903006887 31.372 35.67276613849178 139.7376903006887 31.756 35.67278606397543 139.73775354074232 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f68797f-81de-4e59-afa2-6a049f0ecb70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f68797f-81de-4e59-afa2-6a049f0ecb70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f68797f-81de-4e59-afa2-6a049f0ecb70">
											<gml:posList>35.67276613849178 139.7376903006887 31.756 35.67276613849178 139.7376903006887 31.372 35.67280205372079 139.73767332341512 31.372 35.67280205372079 139.73767332341512 31.756 35.67276613849178 139.7376903006887 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ecd006a-e16d-4391-8486-14a1b180584a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ecd006a-e16d-4391-8486-14a1b180584a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ecd006a-e16d-4391-8486-14a1b180584a">
											<gml:posList>35.67280136695808 139.7376711591024 36.108 35.67280136695808 139.7376711591024 31.756 35.67280205372079 139.73767332341512 31.756 35.67280205372079 139.73767332341512 31.372 35.67281052092388 139.7377001896752 31.372 35.67281052092388 139.7377001896752 36.108 35.67280136695808 139.7376711591024 36.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d6253e0-5800-4a4b-b874-95ee4a9680f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d6253e0-5800-4a4b-b874-95ee4a9680f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d6253e0-5800-4a4b-b874-95ee4a9680f8">
											<gml:posList>35.67281169913275 139.73769692952447 36.108 35.67281169913275 139.73769692952447 35.671 35.67280402716343 139.73767261407843 35.671 35.67280402716343 139.73767261407843 36.108 35.67281169913275 139.73769692952447 36.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ff327cc-eb7f-4566-9daa-a0b04294804a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ff327cc-eb7f-4566-9daa-a0b04294804a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ff327cc-eb7f-4566-9daa-a0b04294804a">
											<gml:posList>35.67275672974037 139.73769228925232 8.758 35.67275672974037 139.73769228925232 30.639 35.67276369472993 139.7376889890602 30.639 35.67276369472993 139.7376889890602 31.756 35.67280136695808 139.7376711591024 31.756 35.67280136695808 139.7376711591024 36.108 35.67283326354923 139.73765605348368 36.108 35.67283326354923 139.73765605348368 33.899 35.67286046575565 139.73764317382302 33.899 35.67286046575565 139.73764317382302 31.756 35.67286737668775 139.73763990682667 31.756 35.67286737668775 139.73763990682667 8.758 35.67275672974037 139.73769228925232 8.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65ffee8a-a059-4395-ae2d-25d86e219fea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65ffee8a-a059-4395-ae2d-25d86e219fea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65ffee8a-a059-4395-ae2d-25d86e219fea">
											<gml:posList>35.672888612634594 139.7377074867 8.758 35.672888612634594 139.7377074867 31.756 35.672784984714255 139.73775654670163 31.756 35.672784984714255 139.73775654670163 30.639 35.672777965658085 139.7377598690464 30.639 35.672777965658085 139.7377598690464 8.758 35.672888612634594 139.7377074867 8.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f8a5ab8-38f9-4ea0-9467-39aa05f18737">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f8a5ab8-38f9-4ea0-9467-39aa05f18737">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f8a5ab8-38f9-4ea0-9467-39aa05f18737">
											<gml:posList>35.67283207633653 139.73765932469325 36.108 35.67283207633653 139.73765932469325 35.671 35.67283973929478 139.7376836401573 35.671 35.67283973929478 139.7376836401573 36.108 35.67283207633653 139.73765932469325 36.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd58017f-72ca-4fdc-8467-ce5e859b19b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd58017f-72ca-4fdc-8467-ce5e859b19b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd58017f-72ca-4fdc-8467-ce5e859b19b9">
											<gml:posList>35.6728861598417 139.73770615298653 31.756 35.6728861598417 139.73770615298653 31.372 35.67278606397543 139.73775354074232 31.372 35.67278606397543 139.73775354074232 31.756 35.6728861598417 139.73770615298653 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b46b7711-97b7-4d6b-90ea-ed826fed7319">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b46b7711-97b7-4d6b-90ea-ed826fed7319">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b46b7711-97b7-4d6b-90ea-ed826fed7319">
											<gml:posList>35.67283326354923 139.73765605348368 36.108 35.67284240850492 139.73768508407707 36.108 35.67284240850492 139.73768508407707 33.899 35.672841495820315 139.7376821909572 33.899 35.672841495820315 139.7376821909572 33.649 35.67283417623447 139.73765894660295 33.649 35.67283417623447 139.73765894660295 33.899 35.67283326354923 139.73765605348368 33.899 35.67283326354923 139.73765605348368 36.108</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ff65d09-5d65-4a44-bfef-4cf80f0b4e45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ff65d09-5d65-4a44-bfef-4cf80f0b4e45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ff65d09-5d65-4a44-bfef-4cf80f0b4e45">
											<gml:posList>35.67284240850492 139.73768508407707 33.899 35.67284240850492 139.73768508407707 36.108 35.67281052092388 139.7377001896752 36.108 35.67281052092388 139.7377001896752 31.372 35.67286961972813 139.737672204414 31.372 35.67286961972813 139.737672204414 33.899 35.67284240850492 139.73768508407707 33.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64c3153f-f480-40a7-85e6-739c1be6b99e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64c3153f-f480-40a7-85e6-739c1be6b99e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64c3153f-f480-40a7-85e6-739c1be6b99e">
											<gml:posList>35.67283417623447 139.73765894660295 33.899 35.67283417623447 139.73765894660295 33.649 35.67285901773363 139.7376471854674 33.649 35.67285901773363 139.7376471854674 33.899 35.67283417623447 139.73765894660295 33.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-476abe4f-6784-462d-a6c3-f5aabe959bef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-476abe4f-6784-462d-a6c3-f5aabe959bef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-476abe4f-6784-462d-a6c3-f5aabe959bef">
											<gml:posList>35.67285901773363 139.7376471854674 33.899 35.67285901773363 139.7376471854674 33.649 35.67286634633545 139.737670429817 33.649 35.67286634633545 139.737670429817 33.899 35.67285901773363 139.7376471854674 33.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24b1ebad-a4a6-48c0-8b02-eb96bc6e5c82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24b1ebad-a4a6-48c0-8b02-eb96bc6e5c82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24b1ebad-a4a6-48c0-8b02-eb96bc6e5c82">
											<gml:posList>35.67286114349635 139.73764532710126 31.756 35.67286114349635 139.73764532710126 31.372 35.67286627939322 139.73764290176547 31.372 35.67286627939322 139.73764290176547 31.756 35.67286114349635 139.73764532710126 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-547561e6-cd9c-452b-9518-8470a22562b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-547561e6-cd9c-452b-9518-8470a22562b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-547561e6-cd9c-452b-9518-8470a22562b4">
											<gml:posList>35.67286114349635 139.73764532710126 31.756 35.67286046575565 139.73764317382302 31.756 35.67286046575565 139.73764317382302 33.899 35.67286961972813 139.737672204414 33.899 35.67286961972813 139.737672204414 31.372 35.67286114349635 139.73764532710126 31.372 35.67286114349635 139.73764532710126 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cd8a1de-3e87-4220-b046-b169e71345e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cd8a1de-3e87-4220-b046-b169e71345e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cd8a1de-3e87-4220-b046-b169e71345e5">
											<gml:posList>35.67286627939322 139.73764290176547 31.756 35.67286627939322 139.73764290176547 31.372 35.6728861598417 139.73770615298653 31.372 35.6728861598417 139.73770615298653 31.756 35.67286627939322 139.73764290176547 31.756</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95534539-5ddc-4a39-81ad-625d0d17d2c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95534539-5ddc-4a39-81ad-625d0d17d2c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95534539-5ddc-4a39-81ad-625d0d17d2c3">
											<gml:posList>35.672888612634594 139.7377074867 8.758 35.67286737668775 139.73763990682667 8.758 35.67286737668775 139.73763990682667 31.756 35.672888612634594 139.7377074867 31.756 35.672888612634594 139.7377074867 8.758</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6479</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">62.02868</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>