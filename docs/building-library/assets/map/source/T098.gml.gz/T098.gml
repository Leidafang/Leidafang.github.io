<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_18de1e10-1908-4146-ab6c-2407d63d55f3">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">8.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67203445429492 139.74087030841264 0 35.67196095351217 139.7409723079803 0 35.67201052537 139.74102632341206 0 35.67208402619787 139.74092432383065 0 35.67203445429492 139.74087030841264 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67203445429492 139.74087030841264 7.264 35.67208402619787 139.74092432383065 7.264 35.67201052537 139.74102632341206 7.264 35.67196095351217 139.7409723079803 7.264 35.67203445429492 139.74087030841264 7.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67203445429492 139.74087030841264 7.264 35.67196095351217 139.7409723079803 7.264 35.67196095351217 139.7409723079803 15.399999999999999 35.67203445429492 139.74087030841264 15.399999999999999 35.67203445429492 139.74087030841264 7.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67196095351217 139.7409723079803 7.264 35.67201052537 139.74102632341206 7.264 35.67201052537 139.74102632341206 15.399999999999999 35.67196095351217 139.7409723079803 15.399999999999999 35.67196095351217 139.7409723079803 7.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67201052537 139.74102632341206 7.264 35.67208402619787 139.74092432383065 7.264 35.67208402619787 139.74092432383065 15.399999999999999 35.67201052537 139.74102632341206 15.399999999999999 35.67201052537 139.74102632341206 7.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67208402619787 139.74092432383065 7.264 35.67203445429492 139.74087030841264 7.264 35.67203445429492 139.74087030841264 15.399999999999999 35.67208402619787 139.74092432383065 15.399999999999999 35.67208402619787 139.74092432383065 7.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67203445429492 139.74087030841264 15.399999999999999 35.67196095351217 139.7409723079803 15.399999999999999 35.67201052537 139.74102632341206 15.399999999999999 35.67208402619787 139.74092432383065 15.399999999999999 35.67203445429492 139.74087030841264 15.399999999999999</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7a982bfe-b4f2-4114-9442-b0fd812c2129"/>
							<gml:surfaceMember xlink:href="#poly-88b8806d-07d3-4c6b-808c-e30022756f5a"/>
							<gml:surfaceMember xlink:href="#poly-74b95d1f-4bdc-4c89-b87a-ec7b8f8f9662"/>
							<gml:surfaceMember xlink:href="#poly-9b89a6bf-bc04-436a-b08b-f51193ba44f0"/>
							<gml:surfaceMember xlink:href="#poly-cbe220e4-6829-4951-b2e3-cc2b409c6998"/>
							<gml:surfaceMember xlink:href="#poly-d6586139-60dc-4e2a-aeea-f857d9001ae5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7a982bfe-b4f2-4114-9442-b0fd812c2129">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a982bfe-b4f2-4114-9442-b0fd812c2129">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a982bfe-b4f2-4114-9442-b0fd812c2129">
											<gml:posList>35.672034454294916 139.74087030841264 7.264 35.67208402619787 139.74092432383063 7.264 35.67201052536998 139.74102632341206 7.264 35.67196095351215 139.7409723079803 7.264 35.672034454294916 139.74087030841264 7.264</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88b8806d-07d3-4c6b-808c-e30022756f5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88b8806d-07d3-4c6b-808c-e30022756f5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88b8806d-07d3-4c6b-808c-e30022756f5a">
											<gml:posList>35.67196095351215 139.7409723079803 15.427 35.67201052536998 139.74102632341206 15.427 35.67208402619787 139.74092432383063 15.427 35.672034454294916 139.74087030841264 15.427 35.67196095351215 139.7409723079803 15.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74b95d1f-4bdc-4c89-b87a-ec7b8f8f9662">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74b95d1f-4bdc-4c89-b87a-ec7b8f8f9662">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74b95d1f-4bdc-4c89-b87a-ec7b8f8f9662">
											<gml:posList>35.672034454294916 139.74087030841264 15.427 35.672034454294916 139.74087030841264 7.264 35.67196095351215 139.7409723079803 7.264 35.67196095351215 139.7409723079803 15.427 35.672034454294916 139.74087030841264 15.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b89a6bf-bc04-436a-b08b-f51193ba44f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b89a6bf-bc04-436a-b08b-f51193ba44f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b89a6bf-bc04-436a-b08b-f51193ba44f0">
											<gml:posList>35.67196095351215 139.7409723079803 15.427 35.67196095351215 139.7409723079803 7.264 35.67201052536998 139.74102632341206 7.264 35.67201052536998 139.74102632341206 15.427 35.67196095351215 139.7409723079803 15.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbe220e4-6829-4951-b2e3-cc2b409c6998">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbe220e4-6829-4951-b2e3-cc2b409c6998">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbe220e4-6829-4951-b2e3-cc2b409c6998">
											<gml:posList>35.67201052536998 139.74102632341206 15.427 35.67201052536998 139.74102632341206 7.264 35.67208402619787 139.74092432383063 7.264 35.67208402619787 139.74092432383063 15.427 35.67201052536998 139.74102632341206 15.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6586139-60dc-4e2a-aeea-f857d9001ae5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6586139-60dc-4e2a-aeea-f857d9001ae5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6586139-60dc-4e2a-aeea-f857d9001ae5">
											<gml:posList>35.67208402619787 139.74092432383063 15.427 35.67208402619787 139.74092432383063 7.264 35.672034454294916 139.74087030841264 7.264 35.672034454294916 139.74087030841264 15.427 35.67208402619787 139.74092432383063 15.427</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3102</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.62</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>