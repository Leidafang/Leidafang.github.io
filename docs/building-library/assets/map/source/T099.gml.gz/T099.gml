<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_18f80ea4-70c9-4ac2-b2ce-d090975dc2aa">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66924862016699 139.73781458994395 0 35.66928704684146 139.73778193605406 0 35.66926707143445 139.73774663441233 0 35.669221303528154 139.73778552705986 0 35.66924862016699 139.73781458994395 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924862016699 139.73781458994395 21.37 35.669221303528154 139.73778552705986 21.37 35.66926707143445 139.73774663441233 21.37 35.66928704684146 139.73778193605406 21.37 35.66924862016699 139.73781458994395 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924862016699 139.73781458994395 21.37 35.66928704684146 139.73778193605406 21.37 35.66928704684146 139.73778193605406 24.71 35.66924862016699 139.73781458994395 24.71 35.66924862016699 139.73781458994395 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66928704684146 139.73778193605406 21.37 35.66926707143445 139.73774663441233 21.37 35.66926707143445 139.73774663441233 24.71 35.66928704684146 139.73778193605406 24.71 35.66928704684146 139.73778193605406 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66926707143445 139.73774663441233 21.37 35.669221303528154 139.73778552705986 21.37 35.669221303528154 139.73778552705986 24.71 35.66926707143445 139.73774663441233 24.71 35.66926707143445 139.73774663441233 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669221303528154 139.73778552705986 21.37 35.66924862016699 139.73781458994395 21.37 35.66924862016699 139.73781458994395 24.71 35.669221303528154 139.73778552705986 24.71 35.669221303528154 139.73778552705986 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924862016699 139.73781458994395 24.71 35.66928704684146 139.73778193605406 24.71 35.66926707143445 139.73774663441233 24.71 35.669221303528154 139.73778552705986 24.71 35.66924862016699 139.73781458994395 24.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-80fefbd3-6054-4e33-bc7a-4345f7aeea36"/>
							<gml:surfaceMember xlink:href="#poly-f1d64a59-a45c-4121-8828-1a7d7ed95117"/>
							<gml:surfaceMember xlink:href="#poly-876b716a-f428-4f39-acf5-1ff31711cdb2"/>
							<gml:surfaceMember xlink:href="#poly-1ee11788-86be-41f4-9f92-52237c74c4ce"/>
							<gml:surfaceMember xlink:href="#poly-883443a4-7c86-432f-a1ef-ddacbd55826e"/>
							<gml:surfaceMember xlink:href="#poly-1e304c84-5da2-4f21-8c50-cd99aeed464c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-80fefbd3-6054-4e33-bc7a-4345f7aeea36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80fefbd3-6054-4e33-bc7a-4345f7aeea36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80fefbd3-6054-4e33-bc7a-4345f7aeea36">
											<gml:posList>35.669248620166954 139.73781458994392 21.37 35.669221303528154 139.73778552705986 21.37 35.66926707143442 139.73774663441233 21.37 35.66928704684145 139.73778193605406 21.37 35.669248620166954 139.73781458994392 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1d64a59-a45c-4121-8828-1a7d7ed95117">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1d64a59-a45c-4121-8828-1a7d7ed95117">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1d64a59-a45c-4121-8828-1a7d7ed95117">
											<gml:posList>35.669248620166954 139.73781458994392 25.56 35.66928704684145 139.73778193605406 25.56 35.66926707143442 139.73774663441233 25.56 35.669221303528154 139.73778552705986 25.56 35.669248620166954 139.73781458994392 25.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-876b716a-f428-4f39-acf5-1ff31711cdb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-876b716a-f428-4f39-acf5-1ff31711cdb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-876b716a-f428-4f39-acf5-1ff31711cdb2">
											<gml:posList>35.66928704684145 139.73778193605406 21.37 35.66926707143442 139.73774663441233 21.37 35.66926707143442 139.73774663441233 25.56 35.66928704684145 139.73778193605406 25.56 35.66928704684145 139.73778193605406 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ee11788-86be-41f4-9f92-52237c74c4ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ee11788-86be-41f4-9f92-52237c74c4ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ee11788-86be-41f4-9f92-52237c74c4ce">
											<gml:posList>35.669221303528154 139.73778552705986 25.56 35.66926707143442 139.73774663441233 25.56 35.66926707143442 139.73774663441233 21.37 35.669221303528154 139.73778552705986 21.37 35.669221303528154 139.73778552705986 25.56</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-883443a4-7c86-432f-a1ef-ddacbd55826e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-883443a4-7c86-432f-a1ef-ddacbd55826e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-883443a4-7c86-432f-a1ef-ddacbd55826e">
											<gml:posList>35.669248620166954 139.73781458994392 21.37 35.66928704684145 139.73778193605406 21.37 35.66928704684145 139.73778193605406 25.56 35.669248620166954 139.73781458994392 25.56 35.669248620166954 139.73781458994392 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e304c84-5da2-4f21-8c50-cd99aeed464c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e304c84-5da2-4f21-8c50-cd99aeed464c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e304c84-5da2-4f21-8c50-cd99aeed464c">
											<gml:posList>35.669221303528154 139.73778552705986 21.37 35.669248620166954 139.73781458994392 21.37 35.669248620166954 139.73781458994392 25.56 35.669221303528154 139.73778552705986 25.56 35.669221303528154 139.73778552705986 21.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7613</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>