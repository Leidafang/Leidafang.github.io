<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1948f046-bbd8-4cb2-80cb-961780785ce9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">12.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671274504881296 139.73989861713102 0 35.67126515030429 139.73991239182385 0 35.67129581221818 139.73994365050635 0 35.67129295813268 139.7399478625036 0 35.67133200943488 139.7399876723947 0 35.67139155818665 139.73989992779656 0 35.67131526871086 139.7398221617581 0 35.671267928666836 139.73989190859479 0 35.671274504881296 139.73989861713102 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671274504881296 139.73989861713102 15.03 35.671267928666836 139.73989190859479 15.03 35.67131526871086 139.7398221617581 15.03 35.67139155818665 139.73989992779656 15.03 35.67133200943488 139.7399876723947 15.03 35.67129295813268 139.7399478625036 15.03 35.67129581221818 139.73994365050635 15.03 35.67126515030429 139.73991239182385 15.03 35.671274504881296 139.73989861713102 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671274504881296 139.73989861713102 15.03 35.67126515030429 139.73991239182385 15.03 35.67126515030429 139.73991239182385 27.6 35.671274504881296 139.73989861713102 27.6 35.671274504881296 139.73989861713102 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67126515030429 139.73991239182385 15.03 35.67129581221818 139.73994365050635 15.03 35.67129581221818 139.73994365050635 27.6 35.67126515030429 139.73991239182385 27.6 35.67126515030429 139.73991239182385 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129581221818 139.73994365050635 15.03 35.67129295813268 139.7399478625036 15.03 35.67129295813268 139.7399478625036 27.6 35.67129581221818 139.73994365050635 27.6 35.67129581221818 139.73994365050635 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129295813268 139.7399478625036 15.03 35.67133200943488 139.7399876723947 15.03 35.67133200943488 139.7399876723947 27.6 35.67129295813268 139.7399478625036 27.6 35.67129295813268 139.7399478625036 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67133200943488 139.7399876723947 15.03 35.67139155818665 139.73989992779656 15.03 35.67139155818665 139.73989992779656 27.6 35.67133200943488 139.7399876723947 27.6 35.67133200943488 139.7399876723947 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67139155818665 139.73989992779656 15.03 35.67131526871086 139.7398221617581 15.03 35.67131526871086 139.7398221617581 27.6 35.67139155818665 139.73989992779656 27.6 35.67139155818665 139.73989992779656 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67131526871086 139.7398221617581 15.03 35.671267928666836 139.73989190859479 15.03 35.671267928666836 139.73989190859479 27.6 35.67131526871086 139.7398221617581 27.6 35.67131526871086 139.7398221617581 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671267928666836 139.73989190859479 15.03 35.671274504881296 139.73989861713102 15.03 35.671274504881296 139.73989861713102 27.6 35.671267928666836 139.73989190859479 27.6 35.671267928666836 139.73989190859479 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671274504881296 139.73989861713102 27.6 35.67126515030429 139.73991239182385 27.6 35.67129581221818 139.73994365050635 27.6 35.67129295813268 139.7399478625036 27.6 35.67133200943488 139.7399876723947 27.6 35.67139155818665 139.73989992779656 27.6 35.67131526871086 139.7398221617581 27.6 35.671267928666836 139.73989190859479 27.6 35.671274504881296 139.73989861713102 27.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6f84631d-1186-440b-bfc0-fd943a9f930e"/>
							<gml:surfaceMember xlink:href="#poly-4f6e7741-a880-4832-ba28-eb9ff10e26d3"/>
							<gml:surfaceMember xlink:href="#poly-f5b8b1e0-4abd-4ce2-bd69-961913ba2757"/>
							<gml:surfaceMember xlink:href="#poly-eacf4ead-48c8-4d15-92a0-3a78a683a539"/>
							<gml:surfaceMember xlink:href="#poly-314cdb92-0789-42f9-a71f-ed784ee78d50"/>
							<gml:surfaceMember xlink:href="#poly-666f82dd-8184-4fd7-b4df-73e5940968a0"/>
							<gml:surfaceMember xlink:href="#poly-c885dfca-c825-4069-9510-63e8c5711898"/>
							<gml:surfaceMember xlink:href="#poly-a6e49afd-5cec-45da-bcf8-dbd8b4e04cad"/>
							<gml:surfaceMember xlink:href="#poly-273e462b-8314-4d1b-92eb-165e89591ff1"/>
							<gml:surfaceMember xlink:href="#poly-b653bec9-0ea7-4e5a-8b08-dcd10b91bb4a"/>
							<gml:surfaceMember xlink:href="#poly-a0023ba8-3a80-43a6-bae9-4c3c26ff2439"/>
							<gml:surfaceMember xlink:href="#poly-a944b8f1-e272-4187-82e9-458bed8a201c"/>
							<gml:surfaceMember xlink:href="#poly-9da788fe-e83f-40e4-a24d-b8556208b466"/>
							<gml:surfaceMember xlink:href="#poly-2c6503a9-045b-47bf-bcaa-5ac636b304af"/>
							<gml:surfaceMember xlink:href="#poly-6c7fb20e-5ea9-45bc-86e6-3715fb108779"/>
							<gml:surfaceMember xlink:href="#poly-755ff0c7-d482-4db5-967d-15ab9063b1d2"/>
							<gml:surfaceMember xlink:href="#poly-34c97639-615d-4605-9cbe-f81b5077999b"/>
							<gml:surfaceMember xlink:href="#poly-32fc59b5-9ceb-4c3c-9393-78aab2a5ec46"/>
							<gml:surfaceMember xlink:href="#poly-0b938849-5dfd-448e-9108-4d1763f22a75"/>
							<gml:surfaceMember xlink:href="#poly-8cf93966-9bd9-4dec-95af-97415ec3dba4"/>
							<gml:surfaceMember xlink:href="#poly-7e8b7074-4c52-49e9-ace9-5cf895453e68"/>
							<gml:surfaceMember xlink:href="#poly-1a93d898-8ccd-4689-8a73-71addda97624"/>
							<gml:surfaceMember xlink:href="#poly-2b90b418-062e-4150-b951-0fc630126e93"/>
							<gml:surfaceMember xlink:href="#poly-cb845ad1-1b46-43f7-881e-cf66578c1375"/>
							<gml:surfaceMember xlink:href="#poly-d5412db9-f9e9-408c-b962-59d27b95a6d6"/>
							<gml:surfaceMember xlink:href="#poly-3767bc40-5078-4649-a534-3aec8ff4b220"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6f84631d-1186-440b-bfc0-fd943a9f930e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f84631d-1186-440b-bfc0-fd943a9f930e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f84631d-1186-440b-bfc0-fd943a9f930e">
											<gml:posList>35.67129581221817 139.73994365050635 15.03 35.671265150304265 139.73991239182382 15.03 35.67127450488127 139.73989861713102 15.03 35.671267928666836 139.73989190859479 15.03 35.67131526871086 139.73982216175807 15.03 35.67139155818664 139.73989992779653 15.03 35.67133200943484 139.73998767239468 15.03 35.67129295813266 139.7399478625036 15.03 35.67129581221817 139.73994365050635 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4f6e7741-a880-4832-ba28-eb9ff10e26d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f6e7741-a880-4832-ba28-eb9ff10e26d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f6e7741-a880-4832-ba28-eb9ff10e26d3">
											<gml:posList>35.67127450488127 139.73989861713102 27.816 35.671265150304265 139.73991239182382 27.816 35.671271405286866 139.73991168861335 27.816 35.67128075986378 139.7398979139194 27.816 35.67127450488127 139.73989861713102 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5b8b1e0-4abd-4ce2-bd69-961913ba2757">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5b8b1e0-4abd-4ce2-bd69-961913ba2757">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5b8b1e0-4abd-4ce2-bd69-961913ba2757">
											<gml:posList>35.67127450488127 139.73989861713102 27.816 35.67128075986378 139.7398979139194 27.816 35.67127417463558 139.73989120539318 27.816 35.671267928666836 139.73989190859479 27.816 35.67127450488127 139.73989861713102 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eacf4ead-48c8-4d15-92a0-3a78a683a539">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eacf4ead-48c8-4d15-92a0-3a78a683a539">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eacf4ead-48c8-4d15-92a0-3a78a683a539">
											<gml:posList>35.67129581221817 139.73994365050635 27.816 35.67130206719236 139.73994293625165 27.816 35.671271405286866 139.73991168861335 27.816 35.671265150304265 139.73991239182382 27.816 35.67129581221817 139.73994365050635 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-314cdb92-0789-42f9-a71f-ed784ee78d50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-314cdb92-0789-42f9-a71f-ed784ee78d50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-314cdb92-0789-42f9-a71f-ed784ee78d50">
											<gml:posList>35.671267928666836 139.73989190859479 27.816 35.67127417463558 139.73989120539318 27.816 35.67131583350627 139.73982981624644 27.816 35.67131526871086 139.73982216175807 27.816 35.671267928666836 139.73989190859479 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-666f82dd-8184-4fd7-b4df-73e5940968a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-666f82dd-8184-4fd7-b4df-73e5940968a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-666f82dd-8184-4fd7-b4df-73e5940968a0">
											<gml:posList>35.67129581221817 139.73994365050635 27.816 35.67129295813266 139.7399478625036 27.816 35.67129920409315 139.73994714825977 27.816 35.67130206719236 139.73994293625165 27.816 35.67129581221817 139.73994365050635 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c885dfca-c825-4069-9510-63e8c5711898">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c885dfca-c825-4069-9510-63e8c5711898">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c885dfca-c825-4069-9510-63e8c5711898">
											<gml:posList>35.67133200943484 139.73998767239468 27.816 35.671331426613456 139.73998000687828 27.816 35.67129920409315 139.73994714825977 27.816 35.67129295813266 139.7399478625036 27.816 35.67133200943484 139.73998767239468 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6e49afd-5cec-45da-bcf8-dbd8b4e04cad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6e49afd-5cec-45da-bcf8-dbd8b4e04cad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6e49afd-5cec-45da-bcf8-dbd8b4e04cad">
											<gml:posList>35.67131583350627 139.73982981624644 27.298 35.67127417463558 139.73989120539318 27.298 35.67128075986378 139.7398979139194 27.298 35.671271405286866 139.73991168861335 27.298 35.67130206719236 139.73994293625165 27.298 35.67129920409315 139.73994714825977 27.298 35.671331426613456 139.73998000687828 27.298 35.67138530320423 139.739900631009 27.298 35.67131583350627 139.73982981624644 27.298</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-273e462b-8314-4d1b-92eb-165e89591ff1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-273e462b-8314-4d1b-92eb-165e89591ff1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-273e462b-8314-4d1b-92eb-165e89591ff1">
											<gml:posList>35.67131526871086 139.73982216175807 27.816 35.67131583350627 139.73982981624644 27.816 35.67138530320423 139.739900631009 27.816 35.67139155818664 139.73989992779653 27.816 35.67131526871086 139.73982216175807 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b653bec9-0ea7-4e5a-8b08-dcd10b91bb4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b653bec9-0ea7-4e5a-8b08-dcd10b91bb4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b653bec9-0ea7-4e5a-8b08-dcd10b91bb4a">
											<gml:posList>35.67139155818664 139.73989992779653 27.816 35.67138530320423 139.739900631009 27.816 35.671331426613456 139.73998000687828 27.816 35.67133200943484 139.73998767239468 27.816 35.67139155818664 139.73989992779653 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0023ba8-3a80-43a6-bae9-4c3c26ff2439">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0023ba8-3a80-43a6-bae9-4c3c26ff2439">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0023ba8-3a80-43a6-bae9-4c3c26ff2439">
											<gml:posList>35.67131526871086 139.73982216175807 15.03 35.671267928666836 139.73989190859479 15.03 35.671267928666836 139.73989190859479 27.816 35.67131526871086 139.73982216175807 27.816 35.67131526871086 139.73982216175807 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a944b8f1-e272-4187-82e9-458bed8a201c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a944b8f1-e272-4187-82e9-458bed8a201c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a944b8f1-e272-4187-82e9-458bed8a201c">
											<gml:posList>35.67127417463558 139.73989120539318 27.816 35.67127417463558 139.73989120539318 27.298 35.67131583350627 139.73982981624644 27.298 35.67131583350627 139.73982981624644 27.816 35.67127417463558 139.73989120539318 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9da788fe-e83f-40e4-a24d-b8556208b466">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9da788fe-e83f-40e4-a24d-b8556208b466">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9da788fe-e83f-40e4-a24d-b8556208b466">
											<gml:posList>35.67139155818664 139.73989992779653 15.03 35.67131526871086 139.73982216175807 15.03 35.67131526871086 139.73982216175807 27.816 35.67139155818664 139.73989992779653 27.816 35.67139155818664 139.73989992779653 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c6503a9-045b-47bf-bcaa-5ac636b304af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c6503a9-045b-47bf-bcaa-5ac636b304af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c6503a9-045b-47bf-bcaa-5ac636b304af">
											<gml:posList>35.67131583350627 139.73982981624644 27.816 35.67131583350627 139.73982981624644 27.298 35.67138530320423 139.739900631009 27.298 35.67138530320423 139.739900631009 27.816 35.67131583350627 139.73982981624644 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c7fb20e-5ea9-45bc-86e6-3715fb108779">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c7fb20e-5ea9-45bc-86e6-3715fb108779">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c7fb20e-5ea9-45bc-86e6-3715fb108779">
											<gml:posList>35.67128075986378 139.7398979139194 27.816 35.67128075986378 139.7398979139194 27.298 35.67127417463558 139.73989120539318 27.298 35.67127417463558 139.73989120539318 27.816 35.67128075986378 139.7398979139194 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-755ff0c7-d482-4db5-967d-15ab9063b1d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-755ff0c7-d482-4db5-967d-15ab9063b1d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-755ff0c7-d482-4db5-967d-15ab9063b1d2">
											<gml:posList>35.671267928666836 139.73989190859479 15.03 35.67127450488127 139.73989861713102 15.03 35.67127450488127 139.73989861713102 27.816 35.671267928666836 139.73989190859479 27.816 35.671267928666836 139.73989190859479 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34c97639-615d-4605-9cbe-f81b5077999b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34c97639-615d-4605-9cbe-f81b5077999b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34c97639-615d-4605-9cbe-f81b5077999b">
											<gml:posList>35.671271405286866 139.73991168861335 27.816 35.671271405286866 139.73991168861335 27.298 35.67128075986378 139.7398979139194 27.298 35.67128075986378 139.7398979139194 27.816 35.671271405286866 139.73991168861335 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32fc59b5-9ceb-4c3c-9393-78aab2a5ec46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32fc59b5-9ceb-4c3c-9393-78aab2a5ec46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32fc59b5-9ceb-4c3c-9393-78aab2a5ec46">
											<gml:posList>35.67127450488127 139.73989861713102 15.03 35.671265150304265 139.73991239182382 15.03 35.671265150304265 139.73991239182382 27.816 35.67127450488127 139.73989861713102 27.816 35.67127450488127 139.73989861713102 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b938849-5dfd-448e-9108-4d1763f22a75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b938849-5dfd-448e-9108-4d1763f22a75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b938849-5dfd-448e-9108-4d1763f22a75">
											<gml:posList>35.67130206719236 139.73994293625165 27.816 35.67130206719236 139.73994293625165 27.298 35.671271405286866 139.73991168861335 27.298 35.671271405286866 139.73991168861335 27.816 35.67130206719236 139.73994293625165 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cf93966-9bd9-4dec-95af-97415ec3dba4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cf93966-9bd9-4dec-95af-97415ec3dba4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cf93966-9bd9-4dec-95af-97415ec3dba4">
											<gml:posList>35.671265150304265 139.73991239182382 15.03 35.67129581221817 139.73994365050635 15.03 35.67129581221817 139.73994365050635 27.816 35.671265150304265 139.73991239182382 27.816 35.671265150304265 139.73991239182382 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e8b7074-4c52-49e9-ace9-5cf895453e68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e8b7074-4c52-49e9-ace9-5cf895453e68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e8b7074-4c52-49e9-ace9-5cf895453e68">
											<gml:posList>35.67138530320423 139.739900631009 27.816 35.67138530320423 139.739900631009 27.298 35.671331426613456 139.73998000687828 27.298 35.671331426613456 139.73998000687828 27.816 35.67138530320423 139.739900631009 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a93d898-8ccd-4689-8a73-71addda97624">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a93d898-8ccd-4689-8a73-71addda97624">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a93d898-8ccd-4689-8a73-71addda97624">
											<gml:posList>35.67133200943484 139.73998767239468 15.03 35.67139155818664 139.73989992779653 15.03 35.67139155818664 139.73989992779653 27.816 35.67133200943484 139.73998767239468 27.816 35.67133200943484 139.73998767239468 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b90b418-062e-4150-b951-0fc630126e93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b90b418-062e-4150-b951-0fc630126e93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b90b418-062e-4150-b951-0fc630126e93">
											<gml:posList>35.67129920409315 139.73994714825977 27.816 35.67129920409315 139.73994714825977 27.298 35.67130206719236 139.73994293625165 27.298 35.67130206719236 139.73994293625165 27.816 35.67129920409315 139.73994714825977 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb845ad1-1b46-43f7-881e-cf66578c1375">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb845ad1-1b46-43f7-881e-cf66578c1375">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb845ad1-1b46-43f7-881e-cf66578c1375">
											<gml:posList>35.67129581221817 139.73994365050635 15.03 35.67129295813266 139.7399478625036 15.03 35.67129295813266 139.7399478625036 27.816 35.67129581221817 139.73994365050635 27.816 35.67129581221817 139.73994365050635 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5412db9-f9e9-408c-b962-59d27b95a6d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5412db9-f9e9-408c-b962-59d27b95a6d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5412db9-f9e9-408c-b962-59d27b95a6d6">
											<gml:posList>35.671331426613456 139.73998000687828 27.816 35.671331426613456 139.73998000687828 27.298 35.67129920409315 139.73994714825977 27.298 35.67129920409315 139.73994714825977 27.816 35.671331426613456 139.73998000687828 27.816</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3767bc40-5078-4649-a534-3aec8ff4b220">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3767bc40-5078-4649-a534-3aec8ff4b220">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3767bc40-5078-4649-a534-3aec8ff4b220">
											<gml:posList>35.67129295813266 139.7399478625036 15.03 35.67133200943484 139.73998767239468 15.03 35.67133200943484 139.73998767239468 27.816 35.67129295813266 139.7399478625036 27.816 35.67129295813266 139.7399478625036 15.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7680</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">73.3873</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>