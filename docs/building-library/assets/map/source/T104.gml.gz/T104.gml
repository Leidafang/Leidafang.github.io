<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1a2425b3-10ab-4473-8266-c083beef3894">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">35</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66860899884653 139.74945837166115 0 35.66861477847973 139.74947394049948 0 35.668923246380494 139.74962925686467 0 35.66892892257143 139.74962571619983 0 35.66904603852714 139.74927709021998 0 35.66904314596061 139.74926538441167 0 35.66873521687668 139.7491078594428 0 35.66872233188219 139.74911450059662 0 35.66860899884653 139.74945837166115 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860899884653 139.74945837166115 5.25 35.66872233188219 139.74911450059662 5.25 35.66873521687668 139.7491078594428 5.25 35.66904314596061 139.74926538441167 5.25 35.66904603852714 139.74927709021998 5.25 35.66892892257143 139.74962571619983 5.25 35.668923246380494 139.74962925686467 5.25 35.66861477847973 139.74947394049948 5.25 35.66860899884653 139.74945837166115 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860899884653 139.74945837166115 5.25 35.66861477847973 139.74947394049948 5.25 35.66861477847973 139.74947394049948 31.7 35.66860899884653 139.74945837166115 31.7 35.66860899884653 139.74945837166115 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66861477847973 139.74947394049948 5.25 35.668923246380494 139.74962925686467 5.25 35.668923246380494 139.74962925686467 31.7 35.66861477847973 139.74947394049948 31.7 35.66861477847973 139.74947394049948 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668923246380494 139.74962925686467 5.25 35.66892892257143 139.74962571619983 5.25 35.66892892257143 139.74962571619983 31.7 35.668923246380494 139.74962925686467 31.7 35.668923246380494 139.74962925686467 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66892892257143 139.74962571619983 5.25 35.66904603852714 139.74927709021998 5.25 35.66904603852714 139.74927709021998 31.7 35.66892892257143 139.74962571619983 31.7 35.66892892257143 139.74962571619983 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904603852714 139.74927709021998 5.25 35.66904314596061 139.74926538441167 5.25 35.66904314596061 139.74926538441167 31.7 35.66904603852714 139.74927709021998 31.7 35.66904603852714 139.74927709021998 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904314596061 139.74926538441167 5.25 35.66873521687668 139.7491078594428 5.25 35.66873521687668 139.7491078594428 31.7 35.66904314596061 139.74926538441167 31.7 35.66904314596061 139.74926538441167 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66873521687668 139.7491078594428 5.25 35.66872233188219 139.74911450059662 5.25 35.66872233188219 139.74911450059662 31.7 35.66873521687668 139.7491078594428 31.7 35.66873521687668 139.7491078594428 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872233188219 139.74911450059662 5.25 35.66860899884653 139.74945837166115 5.25 35.66860899884653 139.74945837166115 31.7 35.66872233188219 139.74911450059662 31.7 35.66872233188219 139.74911450059662 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860899884653 139.74945837166115 31.7 35.66861477847973 139.74947394049948 31.7 35.668923246380494 139.74962925686467 31.7 35.66892892257143 139.74962571619983 31.7 35.66904603852714 139.74927709021998 31.7 35.66904314596061 139.74926538441167 31.7 35.66873521687668 139.7491078594428 31.7 35.66872233188219 139.74911450059662 31.7 35.66860899884653 139.74945837166115 31.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a84af072-2095-41a5-a13c-534a1cb24713"/>
							<gml:surfaceMember xlink:href="#poly-3188bb3b-4349-4510-bc3a-4e6ecf9a7af0"/>
							<gml:surfaceMember xlink:href="#poly-d3dbb9b1-761e-420a-8f95-95631b2328fa"/>
							<gml:surfaceMember xlink:href="#poly-28b2ac5d-f786-48a6-aeb0-9bc355c9e079"/>
							<gml:surfaceMember xlink:href="#poly-4e60ddc3-3f3b-4a18-a178-a1dc8c6beb73"/>
							<gml:surfaceMember xlink:href="#poly-0079d2d3-3bae-4e93-8d6d-7e2e54348e9d"/>
							<gml:surfaceMember xlink:href="#poly-7038c189-f827-485c-80c6-ef8829753522"/>
							<gml:surfaceMember xlink:href="#poly-8e6ee670-14c6-414d-9075-b1e5faabf9e9"/>
							<gml:surfaceMember xlink:href="#poly-32a081d3-cf1e-4d5c-9c18-8eb004411cf4"/>
							<gml:surfaceMember xlink:href="#poly-aa276a31-9ca4-4c18-be53-f081e83456b3"/>
							<gml:surfaceMember xlink:href="#poly-341c5c71-0192-47b4-835d-b13233792a5c"/>
							<gml:surfaceMember xlink:href="#poly-e16b9578-2f7d-44bb-9496-75d8ddd93d1c"/>
							<gml:surfaceMember xlink:href="#poly-c0c89ea9-1655-4f6d-99a3-1d9d98b51c12"/>
							<gml:surfaceMember xlink:href="#poly-4ca464d8-1f64-4153-ab1c-d44b9b49c41f"/>
							<gml:surfaceMember xlink:href="#poly-5131e9de-4e7d-4a34-a1bb-25747ecd69cb"/>
							<gml:surfaceMember xlink:href="#poly-12d75eff-8e65-469f-b4e4-cfe93e55bf44"/>
							<gml:surfaceMember xlink:href="#poly-77a45a30-0a44-434d-ab77-062985210852"/>
							<gml:surfaceMember xlink:href="#poly-97e4a802-de73-4b12-b07b-e0afc7b7e0db"/>
							<gml:surfaceMember xlink:href="#poly-4d852a88-abbe-4651-9a65-44ff4bedcdad"/>
							<gml:surfaceMember xlink:href="#poly-0dc5e885-4cd9-457a-b9f2-5b94591cad64"/>
							<gml:surfaceMember xlink:href="#poly-8d47fddb-126e-4935-bf3a-85f2afc82f3b"/>
							<gml:surfaceMember xlink:href="#poly-9bccd58c-fd63-4f60-b277-ae5a3cc42886"/>
							<gml:surfaceMember xlink:href="#poly-faa0e55e-c22f-40bb-a07d-32c5b37e4476"/>
							<gml:surfaceMember xlink:href="#poly-c4b97f9a-c675-4eb6-8135-7fdc8c5092ff"/>
							<gml:surfaceMember xlink:href="#poly-e76a90e8-52cb-4dc3-ad22-5534be9f272e"/>
							<gml:surfaceMember xlink:href="#poly-82e3a2ef-2524-4bd0-98f7-fb1e862f6239"/>
							<gml:surfaceMember xlink:href="#poly-2919c0e3-36da-448c-9ec7-96b84a300db1"/>
							<gml:surfaceMember xlink:href="#poly-00745628-6def-4abf-b18d-9ad9d2661713"/>
							<gml:surfaceMember xlink:href="#poly-87f3d9af-d532-47df-9e0b-dc2fc25be6a9"/>
							<gml:surfaceMember xlink:href="#poly-aee1b46f-574a-4abc-85ca-f4fafb4762c5"/>
							<gml:surfaceMember xlink:href="#poly-c7038a64-ac29-4bbb-9e02-58cd5050b4e5"/>
							<gml:surfaceMember xlink:href="#poly-32105048-8a77-4d90-b055-033fc9cab7ec"/>
							<gml:surfaceMember xlink:href="#poly-6093f327-2a06-4d35-bfcd-7b900c1905b8"/>
							<gml:surfaceMember xlink:href="#poly-7871b1cb-c564-4543-8a39-c934c8d1eccb"/>
							<gml:surfaceMember xlink:href="#poly-70112314-6126-4721-953f-07c6c7fa0a31"/>
							<gml:surfaceMember xlink:href="#poly-61f5e477-1c00-4eeb-95c3-95ae47e98f56"/>
							<gml:surfaceMember xlink:href="#poly-ceccc064-96da-4e9c-968c-eb0c32923267"/>
							<gml:surfaceMember xlink:href="#poly-b6585667-83fb-4839-bdd2-829e15abd903"/>
							<gml:surfaceMember xlink:href="#poly-b788ae31-bf5d-4afa-889f-b1082bd986e6"/>
							<gml:surfaceMember xlink:href="#poly-13ec4229-fcf0-4046-9760-624119179624"/>
							<gml:surfaceMember xlink:href="#poly-2088e657-87eb-4c44-84d2-87fc424e9cb0"/>
							<gml:surfaceMember xlink:href="#poly-2e379ef2-a6b8-4b79-9bff-a77c297e4cfa"/>
							<gml:surfaceMember xlink:href="#poly-0c2927d8-dd82-417e-8466-03b17f8ef8fa"/>
							<gml:surfaceMember xlink:href="#poly-d8174660-1c6e-41e2-966a-8cbca20eecdb"/>
							<gml:surfaceMember xlink:href="#poly-a18945e4-4fc0-4503-ba80-20edbfe6ac4c"/>
							<gml:surfaceMember xlink:href="#poly-7f02f8ae-dc5c-4417-8f3d-19f5ab350b73"/>
							<gml:surfaceMember xlink:href="#poly-06614947-7947-4772-b38f-787113ca6043"/>
							<gml:surfaceMember xlink:href="#poly-5d99771e-7a31-4ecb-9ea1-373d4aaca4c7"/>
							<gml:surfaceMember xlink:href="#poly-126bf6ac-c0e5-4ea5-9e60-68d7e0fff1b8"/>
							<gml:surfaceMember xlink:href="#poly-3380a126-2ac0-4354-a7bc-b4555a73b334"/>
							<gml:surfaceMember xlink:href="#poly-74db8ccc-657f-40f0-a5c3-f64cfaee30fe"/>
							<gml:surfaceMember xlink:href="#poly-f4582b5d-9643-4e8a-a434-a193c5ac3aac"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1a2425b3-10ab-4473-8266-c083beef3894_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-043bd7b8-4009-4cc7-a06f-2a42b6bdc8c5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862361246855 139.74946175854825 28.594 35.668734791148765 139.74913065890334 28.594 35.668877357536836 139.74920254050147 28.594 35.66887657496325 139.74920486099376 28.594 35.66873628083137 139.74913411474753 28.594 35.668626883182164 139.749459932534 28.594 35.66883633673203 139.74956555666682 28.594 35.66885203317254 139.74951881547787 28.594 35.66885490052191 139.74952022637504 28.594 35.66883820564718 139.74956997313348 28.594 35.66862361246855 139.74946175854825 28.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b99dbc8a-1108-4a93-bd17-d8422d154049">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66899306916706 139.74936084181527 35.352 35.66894121451202 139.74951803740032 35.352 35.668874030007096 139.74948474854972 35.352 35.66887495639806 139.74948184246907 35.352 35.668939895709144 139.74951401801238 35.352 35.66898987947087 139.74936251311215 35.352 35.66892341627611 139.74932958813605 35.352 35.66892430667775 139.74932678150407 35.352 35.66899306916706 139.74936084181527 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6c46269-43de-413b-a7a3-bbeb64b5f581">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6c46269-43de-413b-a7a3-bbeb64b5f581_0">
											<gml:posList>35.668877357536836 139.74920254050147 29.975 35.668877357536836 139.74920254050147 28.594 35.668734791148765 139.74913065890334 28.594 35.668734791148765 139.74913065890334 29.975 35.668877357536836 139.74920254050147 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a08626c-a689-45e4-8cd2-dae79ebd03f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a08626c-a689-45e4-8cd2-dae79ebd03f0_0">
											<gml:posList>35.66873628083137 139.74913411474753 29.975 35.66873628083137 139.74913411474753 28.594 35.66887657496325 139.74920486099376 28.594 35.66887657496325 139.74920486099376 29.975 35.66873628083137 139.74913411474753 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05051e60-54cd-4989-8eac-e5f6b5ab52e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05051e60-54cd-4989-8eac-e5f6b5ab52e0_0">
											<gml:posList>35.66887657496325 139.74920486099376 29.975 35.66887657496325 139.74920486099376 28.594 35.668877357536836 139.74920254050147 28.594 35.668877357536836 139.74920254050147 29.975 35.66887657496325 139.74920486099376 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e70034b7-ddd0-4bce-bee8-110b510bacf7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e70034b7-ddd0-4bce-bee8-110b510bacf7_0">
											<gml:posList>35.668734791148765 139.74913065890334 29.975 35.668734791148765 139.74913065890334 28.594 35.66862361246855 139.74946175854825 28.594 35.66862361246855 139.74946175854825 29.975 35.668734791148765 139.74913065890334 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd9b4cac-8255-42bb-96e1-5f5c31457839">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd9b4cac-8255-42bb-96e1-5f5c31457839_0">
											<gml:posList>35.668626883182164 139.749459932534 29.975 35.668626883182164 139.749459932534 28.594 35.66873628083137 139.74913411474753 28.594 35.66873628083137 139.74913411474753 29.975 35.668626883182164 139.749459932534 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34453d6f-6ddf-4aeb-a3a6-bb32f6c47227">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34453d6f-6ddf-4aeb-a3a6-bb32f6c47227_0">
											<gml:posList>35.66892430667775 139.74932678150407 37.494 35.66892430667775 139.74932678150407 35.352 35.66892341627611 139.74932958813605 35.352 35.66892341627611 139.74932958813605 37.494 35.66892430667775 139.74932678150407 37.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bf5cddb-5e2e-412b-9361-63159049979a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bf5cddb-5e2e-412b-9361-63159049979a_0">
											<gml:posList>35.66899306916706 139.74936084181527 37.494 35.66899306916706 139.74936084181527 35.352 35.66892430667775 139.74932678150407 35.352 35.66892430667775 139.74932678150407 37.494 35.66899306916706 139.74936084181527 37.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf8fef5c-f48f-4643-8030-326a7c89c0b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf8fef5c-f48f-4643-8030-326a7c89c0b0_0">
											<gml:posList>35.66892341627611 139.74932958813605 37.494 35.66892341627611 139.74932958813605 35.352 35.66898987947087 139.74936251311215 35.352 35.66898987947087 139.74936251311215 37.494 35.66892341627611 139.74932958813605 37.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f9f6ded-8057-45c9-badf-445f77c2a3c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f9f6ded-8057-45c9-badf-445f77c2a3c3_0">
											<gml:posList>35.66862361246855 139.74946175854825 29.975 35.66883820564718 139.74956997313348 29.975 35.66885490052191 139.74952022637504 29.975 35.66885203317254 139.74951881547787 29.975 35.66883633673203 139.74956555666682 29.975 35.668626883182164 139.749459932534 29.975 35.66873628083137 139.74913411474753 29.975 35.66887657496325 139.74920486099376 29.975 35.668877357536836 139.74920254050147 29.975 35.668734791148765 139.74913065890334 29.975 35.66862361246855 139.74946175854825 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb90cd2a-8b7e-478d-8d73-97046e378542">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb90cd2a-8b7e-478d-8d73-97046e378542_0">
											<gml:posList>35.66899306916706 139.74936084181527 37.494 35.66892430667775 139.74932678150407 37.494 35.66892341627611 139.74932958813605 37.494 35.66898987947087 139.74936251311215 37.494 35.668939895709144 139.74951401801238 37.494 35.66887495639806 139.74948184246907 37.494 35.668874030007096 139.74948474854972 37.494 35.66894121451202 139.74951803740032 37.494 35.66899306916706 139.74936084181527 37.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-850f1373-493b-4e75-bd92-dc3cb5fe9608">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-850f1373-493b-4e75-bd92-dc3cb5fe9608_0">
											<gml:posList>35.66898987947087 139.74936251311215 37.494 35.66898987947087 139.74936251311215 35.352 35.668939895709144 139.74951401801238 35.352 35.668939895709144 139.74951401801238 37.494 35.66898987947087 139.74936251311215 37.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63b754a6-0559-4824-a208-483fb37c0dc0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63b754a6-0559-4824-a208-483fb37c0dc0_0">
											<gml:posList>35.66894121451202 139.74951803740032 37.494 35.66894121451202 139.74951803740032 35.352 35.66899306916706 139.74936084181527 35.352 35.66899306916706 139.74936084181527 37.494 35.66894121451202 139.74951803740032 37.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c381b23b-a78e-4881-885a-06993d16a744">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c381b23b-a78e-4881-885a-06993d16a744_0">
											<gml:posList>35.66887495639806 139.74948184246907 37.494 35.66887495639806 139.74948184246907 35.352 35.668874030007096 139.74948474854972 35.352 35.668874030007096 139.74948474854972 37.494 35.66887495639806 139.74948184246907 37.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5d2eb74-325e-462d-8a9e-ce8d705d5c05">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5d2eb74-325e-462d-8a9e-ce8d705d5c05_0">
											<gml:posList>35.668939895709144 139.74951401801238 37.494 35.668939895709144 139.74951401801238 35.352 35.66887495639806 139.74948184246907 35.352 35.66887495639806 139.74948184246907 37.494 35.668939895709144 139.74951401801238 37.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2ae2d64-bc97-4486-983b-313e7ac4794c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2ae2d64-bc97-4486-983b-313e7ac4794c_0">
											<gml:posList>35.668874030007096 139.74948474854972 37.494 35.668874030007096 139.74948474854972 35.352 35.66894121451202 139.74951803740032 35.352 35.66894121451202 139.74951803740032 37.494 35.668874030007096 139.74948474854972 37.494</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72c7d1ad-6c6f-42be-a39e-dfaa897d0ab3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72c7d1ad-6c6f-42be-a39e-dfaa897d0ab3_0">
											<gml:posList>35.66883633673203 139.74956555666682 29.975 35.66883633673203 139.74956555666682 28.594 35.668626883182164 139.749459932534 28.594 35.668626883182164 139.749459932534 29.975 35.66883633673203 139.74956555666682 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-166bb9ba-7599-4fc6-a7c6-069a8260bda3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-166bb9ba-7599-4fc6-a7c6-069a8260bda3_0">
											<gml:posList>35.66862361246855 139.74946175854825 29.975 35.66862361246855 139.74946175854825 28.594 35.66883820564718 139.74956997313348 28.594 35.66883820564718 139.74956997313348 29.975 35.66862361246855 139.74946175854825 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ceccf0ee-2d63-4add-9f9f-e3dbd18bc65a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ceccf0ee-2d63-4add-9f9f-e3dbd18bc65a_0">
											<gml:posList>35.66885490052191 139.74952022637504 29.975 35.66885490052191 139.74952022637504 28.594 35.66885203317254 139.74951881547787 28.594 35.66885203317254 139.74951881547787 29.975 35.66885490052191 139.74952022637504 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a635c5a2-8416-4ae5-b0d2-386df2b23f97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a635c5a2-8416-4ae5-b0d2-386df2b23f97_0">
											<gml:posList>35.66885203317254 139.74951881547787 29.975 35.66885203317254 139.74951881547787 28.594 35.66883633673203 139.74956555666682 28.594 35.66883633673203 139.74956555666682 29.975 35.66885203317254 139.74951881547787 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc844665-8a65-4b5c-8569-73767f2c5070">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc844665-8a65-4b5c-8569-73767f2c5070_0">
											<gml:posList>35.66883820564718 139.74956997313348 29.975 35.66883820564718 139.74956997313348 28.594 35.66885490052191 139.74952022637504 28.594 35.66885490052191 139.74952022637504 29.975 35.66883820564718 139.74956997313348 29.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1a2425b3-10ab-4473-8266-c083beef3894_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c854ecf-238e-4fbf-9ba3-4276d3cddef3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668952168272455 139.74923659434268 28.594 35.66893903551843 139.7492756890831 28.594 35.668865286207215 139.749238474927 28.594 35.66887841894936 139.7491993802165 28.594 35.668952168272455 139.74923659434268 28.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5233e4c7-8a6b-4d40-af38-801c113778ff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879136190177 139.74945433687756 35.352 35.668847646519374 139.74927747493498 35.352 35.668927805349426 139.74931578700858 35.352 35.66887152066882 139.74949263805527 35.352 35.66879136190177 139.74945433687756 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a30d213b-182c-4690-b2ef-08c7124e3305">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a30d213b-182c-4690-b2ef-08c7124e3305_0">
											<gml:posList>35.668847646519374 139.74927747493498 44.142 35.668847646519374 139.74927747493498 35.352 35.66879136190177 139.74945433687756 35.352 35.66879136190177 139.74945433687756 44.142 35.668847646519374 139.74927747493498 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80d69c49-a943-4762-8ca5-9eda07931bec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80d69c49-a943-4762-8ca5-9eda07931bec_0">
											<gml:posList>35.668847646519374 139.74927747493498 44.142 35.66879136190177 139.74945433687756 44.142 35.66881888854243 139.74943952847332 44.142 35.66885973043769 139.7493112079525 44.142 35.668847646519374 139.74927747493498 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18e8cd35-b8df-4a81-bcc9-60415953e9fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18e8cd35-b8df-4a81-bcc9-60415953e9fc_0">
											<gml:posList>35.66879136190177 139.74945433687756 44.142 35.66879136190177 139.74945433687756 35.352 35.66887152066882 139.74949263805527 35.352 35.66887152066882 139.74949263805527 44.142 35.66879136190177 139.74945433687756 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18ecf5a3-ac0b-4e90-9f64-5615dfe0ef17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18ecf5a3-ac0b-4e90-9f64-5615dfe0ef17_0">
											<gml:posList>35.66879136190177 139.74945433687756 44.142 35.66887152066882 139.74949263805527 44.142 35.668859436801306 139.74945890500533 44.142 35.66881888854243 139.74943952847332 44.142 35.66879136190177 139.74945433687756 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffee6bf0-7603-481d-a83c-c0273bbca6b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffee6bf0-7603-481d-a83c-c0273bbca6b9_0">
											<gml:posList>35.66881888854243 139.74943952847332 44.142 35.668859436801306 139.74945890500533 44.142 35.668859436801306 139.74945890500533 40.794 35.66881888854243 139.74943952847332 40.794 35.66881888854243 139.74943952847332 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c76e428-d224-4386-87e1-968f0957abc0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c76e428-d224-4386-87e1-968f0957abc0_0">
											<gml:posList>35.66885973043769 139.7493112079525 44.142 35.66881888854243 139.74943952847332 44.142 35.66881888854243 139.74943952847332 40.794 35.66885973043769 139.7493112079525 40.794 35.66885973043769 139.7493112079525 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b848abdc-4d03-450e-b03b-2a57abde1311">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b848abdc-4d03-450e-b03b-2a57abde1311_0">
											<gml:posList>35.668859436801306 139.74945890500533 40.794 35.66890027872457 139.7493305954755 40.794 35.66885973043769 139.7493112079525 40.794 35.66881888854243 139.74943952847332 40.794 35.668859436801306 139.74945890500533 40.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bd61f21-0816-42b9-896d-64ad2218f93f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bd61f21-0816-42b9-896d-64ad2218f93f_0">
											<gml:posList>35.66887841894936 139.7491993802165 31.373 35.66887841894936 139.7491993802165 28.594 35.668865286207215 139.749238474927 28.594 35.668865286207215 139.749238474927 31.373 35.66887841894936 139.7491993802165 31.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f92df83f-20d1-4d01-8dee-1f169788d8b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f92df83f-20d1-4d01-8dee-1f169788d8b4_0">
											<gml:posList>35.668859436801306 139.74945890500533 44.142 35.66890027872457 139.7493305954755 44.142 35.66890027872457 139.7493305954755 40.794 35.668859436801306 139.74945890500533 40.794 35.668859436801306 139.74945890500533 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-718b05d3-520a-4a09-aef8-47ca3f3d1883">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-718b05d3-520a-4a09-aef8-47ca3f3d1883_0">
											<gml:posList>35.66890027872457 139.7493305954755 44.142 35.66885973043769 139.7493112079525 44.142 35.66885973043769 139.7493112079525 40.794 35.66890027872457 139.7493305954755 40.794 35.66890027872457 139.7493305954755 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d387a65f-712c-440d-bc9f-12038a807855">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d387a65f-712c-440d-bc9f-12038a807855_0">
											<gml:posList>35.668927805349426 139.74931578700858 44.142 35.668847646519374 139.74927747493498 44.142 35.66885973043769 139.7493112079525 44.142 35.66890027872457 139.7493305954755 44.142 35.668927805349426 139.74931578700858 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a904b5d5-3f19-4c90-ada0-19d533bc58f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a904b5d5-3f19-4c90-ada0-19d533bc58f0_0">
											<gml:posList>35.668927805349426 139.74931578700858 44.142 35.668927805349426 139.74931578700858 35.352 35.668847646519374 139.74927747493498 35.352 35.668847646519374 139.74927747493498 44.142 35.668927805349426 139.74931578700858 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e086fd9d-c39d-47cc-a887-b780e76713c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e086fd9d-c39d-47cc-a887-b780e76713c4_0">
											<gml:posList>35.66887152066882 139.74949263805527 44.142 35.668927805349426 139.74931578700858 44.142 35.66890027872457 139.7493305954755 44.142 35.668859436801306 139.74945890500533 44.142 35.66887152066882 139.74949263805527 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bd6484e-a493-4663-9593-06427244fa96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bd6484e-a493-4663-9593-06427244fa96_0">
											<gml:posList>35.66887152066882 139.74949263805527 44.142 35.66887152066882 139.74949263805527 35.352 35.668927805349426 139.74931578700858 35.352 35.668927805349426 139.74931578700858 44.142 35.66887152066882 139.74949263805527 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76a9df33-adb1-454d-81bf-74c88a022268">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76a9df33-adb1-454d-81bf-74c88a022268_0">
											<gml:posList>35.668865286207215 139.749238474927 31.373 35.668865286207215 139.749238474927 28.594 35.66893903551843 139.7492756890831 28.594 35.66893903551843 139.7492756890831 31.373 35.668865286207215 139.749238474927 31.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f950a6c-ed3c-4acb-8d4e-a5f141c38a1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f950a6c-ed3c-4acb-8d4e-a5f141c38a1a_0">
											<gml:posList>35.668952168272455 139.74923659434268 31.373 35.66887841894936 139.7491993802165 31.373 35.668865286207215 139.749238474927 31.373 35.66893903551843 139.7492756890831 31.373 35.668952168272455 139.74923659434268 31.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e7a137e-5f37-4e72-bec7-484f43f2a1cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e7a137e-5f37-4e72-bec7-484f43f2a1cc_0">
											<gml:posList>35.668952168272455 139.74923659434268 31.373 35.668952168272455 139.74923659434268 28.594 35.66887841894936 139.7491993802165 28.594 35.66887841894936 139.7491993802165 31.373 35.668952168272455 139.74923659434268 31.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9afc5a5c-5551-470a-b98b-2d999519b2c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9afc5a5c-5551-470a-b98b-2d999519b2c8_0">
											<gml:posList>35.66893903551843 139.7492756890831 31.373 35.66893903551843 139.7492756890831 28.594 35.668952168272455 139.74923659434268 28.594 35.668952168272455 139.74923659434268 31.373 35.66893903551843 139.7492756890831 31.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1a2425b3-10ab-4473-8266-c083beef3894_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69dbbdfa-e522-45da-86e1-c0294052d93f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69dbbdfa-e522-45da-86e1-c0294052d93f_0">
											<gml:posList>35.668727990646246 139.74942170691367 35.352 35.668725193303764 139.74943021528597 35.352 35.668725193303764 139.74943021528597 37.55 35.668727990646246 139.74942170691367 37.55 35.668727990646246 139.74942170691367 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-158dcda8-f0fb-40d1-a51c-1725600d296f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-158dcda8-f0fb-40d1-a51c-1725600d296f_0">
											<gml:posList>35.668734650789276 139.74940732905404 35.352 35.66873215959892 139.74941538421976 35.352 35.66873215959892 139.74941538421976 37.55 35.668734650789276 139.74940732905404 37.55 35.668734650789276 139.74940732905404 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de2144fa-97f3-4c5e-928e-098bdebf98a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de2144fa-97f3-4c5e-928e-098bdebf98a5_0">
											<gml:posList>35.668741441123515 139.74938576008725 35.352 35.66873918360622 139.74939283191267 35.352 35.66873918360622 139.74939283191267 37.55 35.668741441123515 139.74938576008725 37.55 35.668741441123515 139.74938576008725 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44376a69-d145-427e-b3e4-7ed6b7c4ad19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44376a69-d145-427e-b3e4-7ed6b7c4ad19_0">
											<gml:posList>35.6687496244281 139.74937115970658 35.352 35.668747546716425 139.74937755753672 35.352 35.668747546716425 139.74937755753672 37.55 35.6687496244281 139.74937115970658 37.55 35.6687496244281 139.74937115970658 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6560882-d604-4d31-b3be-43c653a4cbb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6560882-d604-4d31-b3be-43c653a4cbb4_0">
											<gml:posList>35.668725193303764 139.74943021528597 35.352 35.66877937548344 139.7494569894201 35.352 35.66877937548344 139.7494569894201 37.55 35.668725193303764 139.74943021528597 37.55 35.668725193303764 139.74943021528597 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0bf9d37-b771-4cf1-ad58-f42b1a22c00c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0bf9d37-b771-4cf1-ad58-f42b1a22c00c_0">
											<gml:posList>35.668758586755956 139.74934914661628 35.352 35.668755933322416 139.74935720195612 35.352 35.668755933322416 139.74935720195612 37.55 35.668758586755956 139.74934914661628 37.55 35.668758586755956 139.74934914661628 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23a13a59-a201-4dc7-a374-4b433c74e978">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23a13a59-a201-4dc7-a374-4b433c74e978_0">
											<gml:posList>35.66878289895515 139.74942982352133 35.352 35.668734650789276 139.74940732905404 35.352 35.668734650789276 139.74940732905404 37.55 35.66878289895515 139.74942982352133 37.55 35.66878289895515 139.74942982352133 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c9dbc87-31ee-407c-b36b-1552515a3dff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c9dbc87-31ee-407c-b36b-1552515a3dff_0">
											<gml:posList>35.668760133363705 139.74933084171283 35.352 35.668757605907835 139.74933858763248 35.352 35.668757605907835 139.74933858763248 37.55 35.668760133363705 139.74933084171283 37.55 35.668760133363705 139.74933084171283 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fceb94d7-eeae-44d8-aec1-343f0f1f9cf7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fceb94d7-eeae-44d8-aec1-343f0f1f9cf7_0">
											<gml:posList>35.66876635470176 139.7493076716535 35.352 35.66876371016912 139.74931556129562 35.352 35.66876371016912 139.74931556129562 37.55 35.66876635470176 139.7493076716535 37.55 35.66876635470176 139.7493076716535 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2581a528-175b-439d-a049-cf6ee62429e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2581a528-175b-439d-a049-cf6ee62429e4_0">
											<gml:posList>35.668755933322416 139.74935720195612 35.352 35.66879940355201 139.74937874039617 35.352 35.66879940355201 139.74937874039617 37.55 35.668755933322416 139.74935720195612 37.55 35.668755933322416 139.74935720195612 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51aad62f-76ad-41a6-82a6-d1935bbddeb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51aad62f-76ad-41a6-82a6-d1935bbddeb6_0">
											<gml:posList>35.66878122884978 139.74929688617738 35.352 35.668778503433266 139.7493051183333 35.352 35.668778503433266 139.7493051183333 37.55 35.66878122884978 139.74929688617738 37.55 35.66878122884978 139.74929688617738 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-379d59f5-27b8-492e-8988-3164935ce3aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-379d59f5-27b8-492e-8988-3164935ce3aa_0">
											<gml:posList>35.66880205699467 139.74937069609868 35.352 35.668758586755956 139.74934914661628 35.352 35.668758586755956 139.74934914661628 37.55 35.66880205699467 139.74937069609868 37.55 35.66880205699467 139.74937069609868 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b774eea1-0b56-4738-ae59-45a65381e135">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b774eea1-0b56-4738-ae59-45a65381e135_0">
											<gml:posList>35.66878944374173 139.7492759011355 35.352 35.66878704222717 139.74928328240833 35.352 35.66878704222717 139.74928328240833 37.55 35.66878944374173 139.7492759011355 37.55 35.66878944374173 139.7492759011355 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-783c4e0e-135c-43c7-bf92-e081019bf0f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-783c4e0e-135c-43c7-bf92-e081019bf0f5_0">
											<gml:posList>35.66879213203184 139.7492403190176 35.352 35.66878985632596 139.74924714785774 35.352 35.66878985632596 139.74924714785774 37.55 35.66879213203184 139.7492403190176 37.55 35.66879213203184 139.7492403190176 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ea4f3bd-0a71-4070-919c-14179e85b0a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ea4f3bd-0a71-4070-919c-14179e85b0a4_0">
											<gml:posList>35.66879422186168 139.74945807849394 41.983 35.66878902821588 139.74945558752148 41.983 35.66878902821588 139.74945558752148 35.352 35.66879422186168 139.74945807849394 35.352 35.66879422186168 139.74945807849394 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05d1dc75-c9bc-4a6c-8e3a-f7e138a410f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05d1dc75-c9bc-4a6c-8e3a-f7e138a410f6_0">
											<gml:posList>35.66879220208413 139.749418259627 35.352 35.66879445058916 139.74941118780706 35.352 35.66879445058916 139.74941118780706 37.55 35.66879220208413 139.749418259627 37.55 35.66879220208413 139.749418259627 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3803041-ea5c-4c98-831d-4891ca17b9af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3803041-ea5c-4c98-831d-4891ca17b9af_0">
											<gml:posList>35.668798212121914 139.7494022807599 35.352 35.66880028984258 139.7493958939724 35.352 35.66880028984258 139.7493958939724 37.55 35.668798212121914 139.7494022807599 37.55 35.668798212121914 139.7494022807599 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c99723f-e8d3-47cf-a0e2-f86a77fa9f2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c99723f-e8d3-47cf-a0e2-f86a77fa9f2e_0">
											<gml:posList>35.668778503433266 139.7493051183333 35.352 35.66882245166153 139.7493270318159 35.352 35.66882245166153 139.7493270318159 37.55 35.668778503433266 139.7493051183333 37.55 35.668778503433266 139.7493051183333 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a5c8eb1-063c-4289-baab-774132db93be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a5c8eb1-063c-4289-baab-774132db93be_0">
											<gml:posList>35.66879940355201 139.74937874039617 35.352 35.66880205699467 139.74937069609868 35.352 35.66880205699467 139.74937069609868 37.55 35.66879940355201 139.74937874039617 37.55 35.66879940355201 139.74937874039617 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58e3f1f1-140b-4db5-a60a-f690600e0de7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58e3f1f1-140b-4db5-a60a-f690600e0de7_0">
											<gml:posList>35.66881078711394 139.749364688955 35.352 35.66881331457147 139.74935694303105 35.352 35.66881331457147 139.74935694303105 37.55 35.66881078711394 139.749364688955 37.55 35.66881078711394 139.749364688955 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d766cd92-4f6f-49c4-ba2f-d5000f5acaca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d766cd92-4f6f-49c4-ba2f-d5000f5acaca_0">
											<gml:posList>35.66878902821588 139.74945558752148 41.983 35.66884661695738 139.7492746150876 41.983 35.66884661695738 139.7492746150876 35.352 35.66878902821588 139.74945558752148 35.352 35.66878902821588 139.74945558752148 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa229bcd-0856-4e4f-acf2-16adf5c4601a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa229bcd-0856-4e4f-acf2-16adf5c4601a_0">
											<gml:posList>35.66884353730013 139.7492660576285 35.352 35.66879213203184 139.7492403190176 35.352 35.66879213203184 139.7492403190176 37.55 35.66884353730013 139.7492660576285 37.55 35.66884353730013 139.7492660576285 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f1cf13a-a701-4e33-bdd1-07ad35b84575">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f1cf13a-a701-4e33-bdd1-07ad35b84575_0">
											<gml:posList>35.66881732468626 139.74934259001876 35.352 35.668819969220635 139.7493347003722 35.352 35.668819969220635 139.7493347003722 37.55 35.66881732468626 139.74934259001876 37.55 35.66881732468626 139.74934259001876 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab3bc26f-5d2d-44ec-9c6c-24e3693d2282">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab3bc26f-5d2d-44ec-9c6c-24e3693d2282_0">
											<gml:posList>35.66882245166153 139.7493270318159 35.352 35.668825186093244 139.74931879964674 35.352 35.668825186093244 139.74931879964674 37.55 35.66882245166153 139.7493270318159 37.55 35.66882245166153 139.7493270318159 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c02bb072-9875-47d7-8083-ca51362cff7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c02bb072-9875-47d7-8083-ca51362cff7d_0">
											<gml:posList>35.668830422054945 139.74930442325365 35.352 35.66883281455706 139.7492970419869 35.352 35.66883281455706 139.7492970419869 37.55 35.668830422054945 139.74930442325365 37.55 35.668830422054945 139.74930442325365 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac5b7003-84ab-4c7c-b1f2-670fece53003">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac5b7003-84ab-4c7c-b1f2-670fece53003_0">
											<gml:posList>35.66883519731259 139.7492886113554 35.352 35.668837463960806 139.74928171624578 35.352 35.668837463960806 139.74928171624578 37.55 35.66883519731259 139.7492886113554 37.55 35.66883519731259 139.7492886113554 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f915967f-62cf-4ab5-a1e5-7d58c2a21759">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f915967f-62cf-4ab5-a1e5-7d58c2a21759_0">
											<gml:posList>35.66879136190177 139.74945433687756 41.983 35.668847646519374 139.74927747493498 41.983 35.66884661695738 139.7492746150876 41.983 35.66878902821588 139.74945558752148 41.983 35.66879136190177 139.74945433687756 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44b6b7b8-db95-4c38-8133-88ed0312967b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44b6b7b8-db95-4c38-8133-88ed0312967b_0">
											<gml:posList>35.66879136190177 139.74945433687756 35.352 35.668847646519374 139.74927747493498 35.352 35.668847646519374 139.74927747493498 41.983 35.66879136190177 139.74945433687756 41.983 35.66879136190177 139.74945433687756 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f804c5b-47e2-40ee-bf27-0cab953b242e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f804c5b-47e2-40ee-bf27-0cab953b242e_0">
											<gml:posList>35.66890575134318 139.74937120609428 44.142 35.668893732032046 139.74936546368534 44.142 35.668893732032046 139.74936546368534 45.478 35.66890575134318 139.74937120609428 45.478 35.66890575134318 139.74937120609428 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-883447c9-1ebd-4c63-b62d-faff90a3917a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-883447c9-1ebd-4c63-b62d-faff90a3917a_0">
											<gml:posList>35.668893732032046 139.74936546368534 44.142 35.66888861441986 139.74938153000826 44.142 35.66888861441986 139.74938153000826 45.478 35.668893732032046 139.74936546368534 45.478 35.668893732032046 139.74936546368534 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27fd829f-4e3b-4d86-90a2-9166965083b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27fd829f-4e3b-4d86-90a2-9166965083b9_0">
											<gml:posList>35.668893732032046 139.74936546368534 45.478 35.66888861441986 139.74938153000826 45.478 35.66890063373024 139.74938727241926 45.478 35.66890575134318 139.74937120609428 45.478 35.668893732032046 139.74936546368534 45.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d566575-677a-4511-91d1-adaf8f293af4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d566575-677a-4511-91d1-adaf8f293af4_0">
											<gml:posList>35.66890063373024 139.74938727241926 44.142 35.66890575134318 139.74937120609428 44.142 35.66890575134318 139.74937120609428 45.478 35.66890063373024 139.74938727241926 45.478 35.66890063373024 139.74938727241926 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b97f91b-4d3b-4232-8c0c-fd3f31e349d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b97f91b-4d3b-4232-8c0c-fd3f31e349d8_0">
											<gml:posList>35.66886568595467 139.7493850777052 40.794 35.66884196291385 139.74937373615873 40.794 35.66884196291385 139.74937373615873 43.698 35.66886568595467 139.7493850777052 43.698 35.66886568595467 139.7493850777052 40.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aed710aa-e11d-4563-b068-7c353721b6a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aed710aa-e11d-4563-b068-7c353721b6a4_0">
											<gml:posList>35.66880028984258 139.7493958939724 35.352 35.6687496244281 139.74937115970658 35.352 35.6687496244281 139.74937115970658 37.55 35.66880028984258 139.7493958939724 37.55 35.66880028984258 139.7493958939724 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e5854ca-2dba-4493-aa8c-44e1e9e33a9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e5854ca-2dba-4493-aa8c-44e1e9e33a9d_0">
											<gml:posList>35.66888861441986 139.74938153000826 44.142 35.66890063373024 139.74938727241926 44.142 35.66890063373024 139.74938727241926 45.478 35.66888861441986 139.74938153000826 45.478 35.66888861441986 139.74938153000826 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7220134-20ff-44a5-bf63-4671384df96d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7220134-20ff-44a5-bf63-4671384df96d_0">
											<gml:posList>35.668798212121914 139.7494022807599 37.55 35.66880028984258 139.7493958939724 37.55 35.6687496244281 139.74937115970658 37.55 35.668747546716425 139.74937755753672 37.55 35.668798212121914 139.7494022807599 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45cc6f92-2cb9-4f7c-8383-08a04f5ad7c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45cc6f92-2cb9-4f7c-8383-08a04f5ad7c7_0">
											<gml:posList>35.668747546716425 139.74937755753672 35.352 35.668798212121914 139.7494022807599 35.352 35.668798212121914 139.7494022807599 37.55 35.668747546716425 139.74937755753672 37.55 35.668747546716425 139.74937755753672 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe345102-e540-411c-87a1-3e15581e7c55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe345102-e540-411c-87a1-3e15581e7c55_0">
											<gml:posList>35.66884196291385 139.74937373615873 40.794 35.66883144889077 139.7494067748484 40.794 35.66883144889077 139.7494067748484 43.698 35.66884196291385 139.74937373615873 43.698 35.66884196291385 139.74937373615873 40.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c120ac3d-82dd-4c22-bcde-88f1c2ab512f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c120ac3d-82dd-4c22-bcde-88f1c2ab512f_0">
											<gml:posList>35.66885516291481 139.7494181164126 43.698 35.66886568595467 139.7493850777052 43.698 35.66884196291385 139.74937373615873 43.698 35.66883144889077 139.7494067748484 43.698 35.66885516291481 139.7494181164126 43.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d9f7757-4ced-4a0a-980f-f4adb12ef584">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d9f7757-4ced-4a0a-980f-f4adb12ef584_0">
											<gml:posList>35.66879445058916 139.74941118780706 35.352 35.668741441123515 139.74938576008725 35.352 35.668741441123515 139.74938576008725 37.55 35.66879445058916 139.74941118780706 37.55 35.66879445058916 139.74941118780706 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e514289f-3959-45cc-bfc3-73d7b86e5951">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e514289f-3959-45cc-bfc3-73d7b86e5951_0">
											<gml:posList>35.66885516291481 139.7494181164126 40.794 35.66886568595467 139.7493850777052 40.794 35.66886568595467 139.7493850777052 43.698 35.66885516291481 139.7494181164126 43.698 35.66885516291481 139.7494181164126 40.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eaccc1c2-c518-409d-acee-30c20fd4dec3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eaccc1c2-c518-409d-acee-30c20fd4dec3_0">
											<gml:posList>35.66873918360622 139.74939283191267 37.55 35.66879220208413 139.749418259627 37.55 35.66879445058916 139.74941118780706 37.55 35.668741441123515 139.74938576008725 37.55 35.66873918360622 139.74939283191267 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2905eb14-abc5-49a6-b82a-80f2652c72ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2905eb14-abc5-49a6-b82a-80f2652c72ef_0">
											<gml:posList>35.66873918360622 139.74939283191267 35.352 35.66879220208413 139.749418259627 35.352 35.66879220208413 139.749418259627 37.55 35.66873918360622 139.74939283191267 37.55 35.66873918360622 139.74939283191267 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-180ccb4c-8f6e-44d4-b67c-b931635df633">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-180ccb4c-8f6e-44d4-b67c-b931635df633_0">
											<gml:posList>35.66883144889077 139.7494067748484 40.794 35.66885516291481 139.7494181164126 40.794 35.66885516291481 139.7494181164126 43.698 35.66883144889077 139.7494067748484 43.698 35.66883144889077 139.7494067748484 40.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f1c91dc-0907-4b8b-a092-e401cda84928">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f1c91dc-0907-4b8b-a092-e401cda84928_0">
											<gml:posList>35.66873215959892 139.74941538421976 37.55 35.668780398741895 139.74943786765462 37.55 35.66878289895515 139.74942982352133 37.55 35.668734650789276 139.74940732905404 37.55 35.66873215959892 139.74941538421976 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f1544d3-3d2b-4d80-88bd-9d150859ec56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f1544d3-3d2b-4d80-88bd-9d150859ec56_0">
											<gml:posList>35.668780398741895 139.74943786765462 35.352 35.66878289895515 139.74942982352133 35.352 35.66878289895515 139.74942982352133 37.55 35.668780398741895 139.74943786765462 37.55 35.668780398741895 139.74943786765462 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff6e91b1-c224-4d8b-9023-98e73550340a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff6e91b1-c224-4d8b-9023-98e73550340a_0">
											<gml:posList>35.668782172835485 139.749448492089 35.352 35.668727990646246 139.74942170691367 35.352 35.668727990646246 139.74942170691367 37.55 35.668782172835485 139.749448492089 37.55 35.668782172835485 139.749448492089 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62312ba6-611e-452b-885a-bc2224704d3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62312ba6-611e-452b-885a-bc2224704d3a_0">
											<gml:posList>35.668725193303764 139.74943021528597 37.55 35.66877937548344 139.7494569894201 37.55 35.668782172835485 139.749448492089 37.55 35.668727990646246 139.74942170691367 37.55 35.668725193303764 139.74943021528597 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-472349d9-f06b-4c86-bbaa-1cb4997ffb1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-472349d9-f06b-4c86-bbaa-1cb4997ffb1d_0">
											<gml:posList>35.66877937548344 139.7494569894201 35.352 35.668782172835485 139.749448492089 35.352 35.668782172835485 139.749448492089 37.55 35.66877937548344 139.7494569894201 37.55 35.66877937548344 139.7494569894201 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99f37e7f-40ec-42d2-bfdd-49bdffbc5574">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99f37e7f-40ec-42d2-bfdd-49bdffbc5574_0">
											<gml:posList>35.66872065439498 139.74943597501797 41.983 35.66879009323147 139.74947053170118 41.983 35.66879009323147 139.74947053170118 35.352 35.66872065439498 139.74943597501797 35.352 35.66872065439498 139.74943597501797 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6cdde1e-1dbe-4f25-a3c1-738ce580d911">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6cdde1e-1dbe-4f25-a3c1-738ce580d911_0">
											<gml:posList>35.668718302658704 139.74943719254213 41.983 35.6687910867493 139.74947341367888 41.983 35.66879009323147 139.74947053170118 41.983 35.66872065439498 139.74943597501797 41.983 35.668718302658704 139.74943719254213 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd032096-83b5-434c-bbdf-05200be43005">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd032096-83b5-434c-bbdf-05200be43005_0">
											<gml:posList>35.668718302658704 139.74943719254213 35.352 35.6687910867493 139.74947341367888 35.352 35.6687910867493 139.74947341367888 41.983 35.668718302658704 139.74943719254213 41.983 35.668718302658704 139.74943719254213 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-196c960b-8290-43ab-bf35-2ecb3eb6f64b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-196c960b-8290-43ab-bf35-2ecb3eb6f64b_0">
											<gml:posList>35.66879658258878 139.74945682782172 35.352 35.66879136190177 139.74945433687756 35.352 35.66879136190177 139.74945433687756 41.983 35.66879658258878 139.74945682782172 41.983 35.66879658258878 139.74945682782172 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7713ca11-95bd-4f8d-9132-04f1b1f2619e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7713ca11-95bd-4f8d-9132-04f1b1f2619e_0">
											<gml:posList>35.66879658258878 139.74945682782172 41.983 35.66879136190177 139.74945433687756 41.983 35.66878902821588 139.74945558752148 41.983 35.66879422186168 139.74945807849394 41.983 35.66879658258878 139.74945682782172 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7915280f-1fa1-4019-b07a-0d1105a21516">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7915280f-1fa1-4019-b07a-0d1105a21516_0">
											<gml:posList>35.66879009323147 139.74947053170118 41.983 35.66879422186168 139.74945807849394 41.983 35.66879422186168 139.74945807849394 35.352 35.66879009323147 139.74947053170118 35.352 35.66879009323147 139.74947053170118 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-989f6bc6-62f3-4c79-a92e-8cc5b7302c8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-989f6bc6-62f3-4c79-a92e-8cc5b7302c8c_0">
											<gml:posList>35.6687910867493 139.74947341367888 35.352 35.66879658258878 139.74945682782172 35.352 35.66879658258878 139.74945682782172 41.983 35.6687910867493 139.74947341367888 41.983 35.6687910867493 139.74947341367888 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-384bb745-139e-44a8-b19b-a07ffd181d5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-384bb745-139e-44a8-b19b-a07ffd181d5c_0">
											<gml:posList>35.6687910867493 139.74947341367888 41.983 35.66879658258878 139.74945682782172 41.983 35.66879422186168 139.74945807849394 41.983 35.66879009323147 139.74947053170118 41.983 35.6687910867493 139.74947341367888 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6491842-9e29-4ca5-8c67-10f531250db0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6491842-9e29-4ca5-8c67-10f531250db0_0">
											<gml:posList>35.668811516407054 139.74946698560652 35.352 35.66880941163374 139.74947336137535 35.352 35.66880941163374 139.74947336137535 39.345 35.668811516407054 139.74946698560652 39.345 35.668811516407054 139.74946698560652 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-273e7ec6-4e8e-491b-a031-7f9c8625cfac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-273e7ec6-4e8e-491b-a031-7f9c8625cfac_0">
											<gml:posList>35.66887971087793 139.74950088089338 35.352 35.668811516407054 139.74946698560652 35.352 35.668811516407054 139.74946698560652 39.345 35.66887971087793 139.74950088089338 39.345 35.66887971087793 139.74950088089338 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d62bec9-5a20-4e02-b206-947d46322f81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d62bec9-5a20-4e02-b206-947d46322f81_0">
											<gml:posList>35.66880941163374 139.74947336137535 39.345 35.66887759708913 139.74950725667617 39.345 35.66887971087793 139.74950088089338 39.345 35.668811516407054 139.74946698560652 39.345 35.66880941163374 139.74947336137535 39.345</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cd0fa45-818b-42a3-8067-9bfb6208f189">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cd0fa45-818b-42a3-8067-9bfb6208f189_0">
											<gml:posList>35.66880941163374 139.74947336137535 35.352 35.66887759708913 139.74950725667617 35.352 35.66887759708913 139.74950725667617 39.345 35.66880941163374 139.74947336137535 39.345 35.66880941163374 139.74947336137535 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed1a8549-8dce-4efb-9835-a1371c02fa25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed1a8549-8dce-4efb-9835-a1371c02fa25_0">
											<gml:posList>35.66887759708913 139.74950725667617 35.352 35.66887971087793 139.74950088089338 35.352 35.66887971087793 139.74950088089338 39.345 35.66887759708913 139.74950725667617 39.345 35.66887759708913 139.74950725667617 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-806ecc88-f9e1-47d4-818a-c30c65074aa5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-806ecc88-f9e1-47d4-818a-c30c65074aa5_0">
											<gml:posList>35.66886106870636 139.74926561949766 35.352 35.668787310740036 139.74922892455987 35.352 35.668787310740036 139.74922892455987 41.983 35.66886106870636 139.74926561949766 41.983 35.66886106870636 139.74926561949766 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c2d16b9-f423-48c6-86f4-220ac22adcb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c2d16b9-f423-48c6-86f4-220ac22adcb7_0">
											<gml:posList>35.66886106870636 139.74926561949766 41.983 35.668787310740036 139.74922892455987 41.983 35.66878830426364 139.74923180653445 41.983 35.66885871697187 139.74926683702893 41.983 35.66886106870636 139.74926561949766 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66738892-d32e-444e-b04a-d5a0b43df2b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66738892-d32e-444e-b04a-d5a0b43df2b0_0">
											<gml:posList>35.66885871697187 139.74926683702893 41.983 35.66878830426364 139.74923180653445 41.983 35.66878830426364 139.74923180653445 35.352 35.66885871697187 139.74926683702893 35.352 35.66885871697187 139.74926683702893 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-264d2e0b-4114-48f2-91a2-ce6a1d053201">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-264d2e0b-4114-48f2-91a2-ce6a1d053201_0">
											<gml:posList>35.66878985632596 139.74924714785774 37.55 35.66884126158511 139.74927287542627 37.55 35.66884353730013 139.7492660576285 37.55 35.66879213203184 139.7492403190176 37.55 35.66878985632596 139.74924714785774 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3e3b5d0-98f5-4611-aaec-405c9c28e51b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3e3b5d0-98f5-4611-aaec-405c9c28e51b_0">
											<gml:posList>35.66878985632596 139.74924714785774 35.352 35.66884126158511 139.74927287542627 35.352 35.66884126158511 139.74927287542627 37.55 35.66878985632596 139.74924714785774 37.55 35.66878985632596 139.74924714785774 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c09076dc-2ba2-4b73-9dba-fdf52795e562">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c09076dc-2ba2-4b73-9dba-fdf52795e562_0">
											<gml:posList>35.66879421916535 139.74926033225637 35.352 35.668791952518326 139.7492672273629 35.352 35.668791952518326 139.7492672273629 37.55 35.66879421916535 139.74926033225637 37.55 35.66879421916535 139.74926033225637 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef8dee31-1385-4fbe-b828-dabe9745e7e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef8dee31-1385-4fbe-b828-dabe9745e7e4_0">
											<gml:posList>35.66884126158511 139.74927287542627 35.352 35.66884353730013 139.7492660576285 35.352 35.66884353730013 139.7492660576285 37.55 35.66884126158511 139.74927287542627 37.55 35.66884126158511 139.74927287542627 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-262df59d-8264-4ba5-a6f6-11ab0b462666">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-262df59d-8264-4ba5-a6f6-11ab0b462666_0">
											<gml:posList>35.668854840221556 139.7492785388606 41.983 35.66885871697187 139.74926683702893 41.983 35.66885871697187 139.74926683702893 35.352 35.668854840221556 139.7492785388606 35.352 35.668854840221556 139.7492785388606 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d01ff93-8d4f-4e3f-9261-501c0b550a3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d01ff93-8d4f-4e3f-9261-501c0b550a3e_0">
											<gml:posList>35.668855842734565 139.74928138769062 35.352 35.66886106870636 139.74926561949766 35.352 35.66886106870636 139.74926561949766 41.983 35.668855842734565 139.74928138769062 41.983 35.668855842734565 139.74928138769062 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59b5aeea-d52b-4774-a1b2-94bcd8851658">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59b5aeea-d52b-4774-a1b2-94bcd8851658_0">
											<gml:posList>35.668855842734565 139.74928138769062 41.983 35.66886106870636 139.74926561949766 41.983 35.66885871697187 139.74926683702893 41.983 35.668854840221556 139.7492785388606 41.983 35.668855842734565 139.74928138769062 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-268421e5-3dfd-4285-b215-8d72af682ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-268421e5-3dfd-4285-b215-8d72af682ee8_0">
											<gml:posList>35.668791952518326 139.7492672273629 37.55 35.66883519731259 139.7492886113554 37.55 35.668837463960806 139.74928171624578 37.55 35.66879421916535 139.74926033225637 37.55 35.668791952518326 139.7492672273629 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b77ea748-ebea-4b5a-b0b1-65dc9b4cced2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b77ea748-ebea-4b5a-b0b1-65dc9b4cced2_0">
											<gml:posList>35.66884661695738 139.7492746150876 41.983 35.668854840221556 139.7492785388606 41.983 35.668854840221556 139.7492785388606 35.352 35.66884661695738 139.7492746150876 35.352 35.66884661695738 139.7492746150876 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8127eca4-ed43-42b1-9ec9-9837598b259f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8127eca4-ed43-42b1-9ec9-9837598b259f_0">
											<gml:posList>35.668847646519374 139.74927747493498 41.983 35.668855842734565 139.74928138769062 41.983 35.668854840221556 139.7492785388606 41.983 35.66884661695738 139.7492746150876 41.983 35.668847646519374 139.74927747493498 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8af177ca-3bc0-4ae8-a474-5a8212ed6c29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8af177ca-3bc0-4ae8-a474-5a8212ed6c29_0">
											<gml:posList>35.668847646519374 139.74927747493498 35.352 35.668855842734565 139.74928138769062 35.352 35.668855842734565 139.74928138769062 41.983 35.668847646519374 139.74927747493498 41.983 35.668847646519374 139.74927747493498 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e16c8898-292d-4a9a-a88e-57c954baf48e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e16c8898-292d-4a9a-a88e-57c954baf48e_0">
											<gml:posList>35.66878704222717 139.74928328240833 37.55 35.668830422054945 139.74930442325365 37.55 35.66883281455706 139.7492970419869 37.55 35.66878944374173 139.7492759011355 37.55 35.66878704222717 139.74928328240833 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41c7891a-8f09-4be8-a8f9-7f68ed3b2ea0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41c7891a-8f09-4be8-a8f9-7f68ed3b2ea0_0">
											<gml:posList>35.668825186093244 139.74931879964674 35.352 35.66878122884978 139.74929688617738 35.352 35.66878122884978 139.74929688617738 37.55 35.668825186093244 139.74931879964674 37.55 35.668825186093244 139.74931879964674 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b48dc8d-f3a2-46fd-80f6-112e8df000a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b48dc8d-f3a2-46fd-80f6-112e8df000a3_0">
											<gml:posList>35.668778503433266 139.7493051183333 37.55 35.66882245166153 139.7493270318159 37.55 35.668825186093244 139.74931879964674 37.55 35.66878122884978 139.74929688617738 37.55 35.668778503433266 139.7493051183333 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ca76b3e-37df-4ae9-8c9c-c2501c3ed7d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ca76b3e-37df-4ae9-8c9c-c2501c3ed7d7_0">
											<gml:posList>35.668819969220635 139.7493347003722 35.352 35.66876635470176 139.7493076716535 35.352 35.66876635470176 139.7493076716535 37.55 35.668819969220635 139.7493347003722 37.55 35.668819969220635 139.7493347003722 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-331bfe57-8b45-485f-988c-f11a6f42166b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-331bfe57-8b45-485f-988c-f11a6f42166b_0">
											<gml:posList>35.66876371016912 139.74931556129562 37.55 35.66881732468626 139.74934259001876 37.55 35.668819969220635 139.7493347003722 37.55 35.66876635470176 139.7493076716535 37.55 35.66876371016912 139.74931556129562 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-509bda2c-3b6d-4afc-9ba3-6be668d3693b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-509bda2c-3b6d-4afc-9ba3-6be668d3693b_0">
											<gml:posList>35.66876371016912 139.74931556129562 35.352 35.66881732468626 139.74934259001876 35.352 35.66881732468626 139.74934259001876 37.55 35.66876371016912 139.74931556129562 37.55 35.66876371016912 139.74931556129562 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6432ef3-386b-41a7-9ab9-488a5da00c13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6432ef3-386b-41a7-9ab9-488a5da00c13_0">
											<gml:posList>35.668787310740036 139.74922892455987 35.352 35.668718302658704 139.74943719254213 35.352 35.668718302658704 139.74943719254213 41.983 35.668787310740036 139.74922892455987 41.983 35.668787310740036 139.74922892455987 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ca06045-bd2d-438d-9053-e8db2194fcfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ca06045-bd2d-438d-9053-e8db2194fcfa_0">
											<gml:posList>35.668787310740036 139.74922892455987 41.983 35.668718302658704 139.74943719254213 41.983 35.66872065439498 139.74943597501797 41.983 35.66878830426364 139.74923180653445 41.983 35.668787310740036 139.74922892455987 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b08b1ed9-e48b-4502-bfb6-8c3391429777">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b08b1ed9-e48b-4502-bfb6-8c3391429777_0">
											<gml:posList>35.66878830426364 139.74923180653445 41.983 35.66872065439498 139.74943597501797 41.983 35.66872065439498 139.74943597501797 35.352 35.66878830426364 139.74923180653445 35.352 35.66878830426364 139.74923180653445 41.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d402acf3-64c1-4922-b632-76b94b4ccbb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d402acf3-64c1-4922-b632-76b94b4ccbb8_0">
											<gml:posList>35.66899069186966 139.7493383324166 35.352 35.66897882543602 139.74933208172726 35.352 35.66897882543602 139.74933208172726 38.053 35.66899069186966 139.7493383324166 38.053 35.66899069186966 139.7493383324166 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a9462cc-7bd9-4bc6-b776-be8f2bbbc08a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a9462cc-7bd9-4bc6-b776-be8f2bbbc08a_0">
											<gml:posList>35.66897882543602 139.74933208172726 35.352 35.66897559593424 139.7493412975303 35.352 35.66897559593424 139.7493412975303 38.053 35.66897882543602 139.74933208172726 38.053 35.66897882543602 139.74933208172726 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-accbd47b-3b9a-414d-998f-ea5f315eba74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-accbd47b-3b9a-414d-998f-ea5f315eba74_0">
											<gml:posList>35.66897559593424 139.7493412975303 38.053 35.66898745335369 139.7493475482302 38.053 35.66899069186966 139.7493383324166 38.053 35.66897882543602 139.74933208172726 38.053 35.66897559593424 139.7493412975303 38.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4695b13-18e0-477f-aa2d-e62966b88f1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4695b13-18e0-477f-aa2d-e62966b88f1c_0">
											<gml:posList>35.66898745335369 139.7493475482302 35.352 35.66899069186966 139.7493383324166 35.352 35.66899069186966 139.7493383324166 38.053 35.66898745335369 139.7493475482302 38.053 35.66898745335369 139.7493475482302 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e31e52e-917e-4681-b679-4db684fd5c44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e31e52e-917e-4681-b679-4db684fd5c44_0">
											<gml:posList>35.66881331457147 139.74935694303105 35.352 35.668760133363705 139.74933084171283 35.352 35.668760133363705 139.74933084171283 37.55 35.66881331457147 139.74935694303105 37.55 35.66881331457147 139.74935694303105 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27faa4a1-24fa-4b39-8240-2d18a9e8c088">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27faa4a1-24fa-4b39-8240-2d18a9e8c088_0">
											<gml:posList>35.66897559593424 139.7493412975303 35.352 35.66898745335369 139.7493475482302 35.352 35.66898745335369 139.7493475482302 38.053 35.66897559593424 139.7493412975303 38.053 35.66897559593424 139.7493412975303 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c46d08c0-c0f3-4de0-a7b3-19c7f6ab1a14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c46d08c0-c0f3-4de0-a7b3-19c7f6ab1a14_0">
											<gml:posList>35.668757605907835 139.74933858763248 37.55 35.66881078711394 139.749364688955 37.55 35.66881331457147 139.74935694303105 37.55 35.668760133363705 139.74933084171283 37.55 35.668757605907835 139.74933858763248 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4478c6b2-860e-428d-8509-a2bc382a62e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4478c6b2-860e-428d-8509-a2bc382a62e4_0">
											<gml:posList>35.668757605907835 139.74933858763248 35.352 35.66881078711394 139.749364688955 35.352 35.66881078711394 139.749364688955 37.55 35.668757605907835 139.74933858763248 37.55 35.668757605907835 139.74933858763248 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8adf76f4-9ba3-46c4-9be8-8ca57c139806">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8adf76f4-9ba3-46c4-9be8-8ca57c139806_0">
											<gml:posList>35.66879940355201 139.74937874039617 37.55 35.66880205699467 139.74937069609868 37.55 35.668758586755956 139.74934914661628 37.55 35.668755933322416 139.74935720195612 37.55 35.66879940355201 139.74937874039617 37.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6a4edbb-3b9c-4c2b-9452-b5efdea616fa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872065439498 139.74943597501797 35.352 35.668718302658704 139.74943719254213 35.352 35.668787310740036 139.74922892455987 35.352 35.66878830426364 139.74923180653445 35.352 35.66872065439498 139.74943597501797 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad00b6b2-3749-4adb-a9f0-05ae8900576f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877937548344 139.7494569894201 35.352 35.668725193303764 139.74943021528597 35.352 35.668727990646246 139.74942170691367 35.352 35.668782172835485 139.749448492089 35.352 35.66877937548344 139.7494569894201 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32546a09-aeb2-4395-9ed0-d88209f4c824">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66873215959892 139.74941538421976 35.352 35.668780398741895 139.74943786765462 35.352 35.668780398741895 139.74943786765462 37.55 35.66873215959892 139.74941538421976 37.55 35.66873215959892 139.74941538421976 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c735aec5-81d6-4927-b289-6171c9e7ed6c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668780398741895 139.74943786765462 35.352 35.66873215959892 139.74941538421976 35.352 35.668734650789276 139.74940732905404 35.352 35.66878289895515 139.74942982352133 35.352 35.668780398741895 139.74943786765462 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9f2d460-151b-4c33-b2c6-829dccbb77d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66879220208413 139.749418259627 35.352 35.66873918360622 139.74939283191267 35.352 35.668741441123515 139.74938576008725 35.352 35.66879445058916 139.74941118780706 35.352 35.66879220208413 139.749418259627 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e291a0f7-defb-4310-b44e-8380594315d9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880028984258 139.7493958939724 35.352 35.668798212121914 139.7494022807599 35.352 35.668747546716425 139.74937755753672 35.352 35.6687496244281 139.74937115970658 35.352 35.66880028984258 139.7493958939724 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58b971b2-8528-4bad-aa0f-59b5028dd5b1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880205699467 139.74937069609868 35.352 35.66879940355201 139.74937874039617 35.352 35.668755933322416 139.74935720195612 35.352 35.668758586755956 139.74934914661628 35.352 35.66880205699467 139.74937069609868 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3517faf2-6637-4c26-a0ae-d269b0b2fc81">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881078711394 139.749364688955 35.352 35.668757605907835 139.74933858763248 35.352 35.668760133363705 139.74933084171283 35.352 35.66881331457147 139.74935694303105 35.352 35.66881078711394 139.749364688955 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f25c8885-5342-4924-9665-bb66dc628709">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66885871697187 139.74926683702893 35.352 35.66878830426364 139.74923180653445 35.352 35.668787310740036 139.74922892455987 35.352 35.66886106870636 139.74926561949766 35.352 35.668855842734565 139.74928138769062 35.352 35.668847646519374 139.74927747493498 35.352 35.66879136190177 139.74945433687756 35.352 35.66879658258878 139.74945682782172 35.352 35.6687910867493 139.74947341367888 35.352 35.668718302658704 139.74943719254213 35.352 35.66872065439498 139.74943597501797 35.352 35.66879009323147 139.74947053170118 35.352 35.66879422186168 139.74945807849394 35.352 35.66878902821588 139.74945558752148 35.352 35.66884661695738 139.7492746150876 35.352 35.668854840221556 139.7492785388606 35.352 35.66885871697187 139.74926683702893 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-278a1ef1-2f3c-4a44-8937-3e90b7b9f1a2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881732468626 139.74934259001876 35.352 35.66876371016912 139.74931556129562 35.352 35.66876635470176 139.7493076716535 35.352 35.668819969220635 139.7493347003722 35.352 35.66881732468626 139.74934259001876 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0dd9a18-7cee-48ee-b951-873adb3cc801">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882245166153 139.7493270318159 35.352 35.668778503433266 139.7493051183333 35.352 35.66878122884978 139.74929688617738 35.352 35.668825186093244 139.74931879964674 35.352 35.66882245166153 139.7493270318159 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-108ab394-5081-41ce-adf4-9f2215693281">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66878704222717 139.74928328240833 35.352 35.668830422054945 139.74930442325365 35.352 35.668830422054945 139.74930442325365 37.55 35.66878704222717 139.74928328240833 37.55 35.66878704222717 139.74928328240833 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-113217cc-e7db-468b-9302-f1e25e1595c1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668830422054945 139.74930442325365 35.352 35.66878704222717 139.74928328240833 35.352 35.66878944374173 139.7492759011355 35.352 35.66883281455706 139.7492970419869 35.352 35.668830422054945 139.74930442325365 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31911059-6ca4-4ac7-b6e0-96ed8cbc1005">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883281455706 139.7492970419869 35.352 35.66878944374173 139.7492759011355 35.352 35.66878944374173 139.7492759011355 37.55 35.66883281455706 139.7492970419869 37.55 35.66883281455706 139.7492970419869 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa47d644-8843-48cb-89bc-9169a9ca7bdc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668791952518326 139.7492672273629 35.352 35.66883519731259 139.7492886113554 35.352 35.66883519731259 139.7492886113554 37.55 35.668791952518326 139.7492672273629 37.55 35.668791952518326 139.7492672273629 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e78cc90-41c7-4846-9536-f6406b08404e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66883519731259 139.7492886113554 35.352 35.668791952518326 139.7492672273629 35.352 35.66879421916535 139.74926033225637 35.352 35.668837463960806 139.74928171624578 35.352 35.66883519731259 139.7492886113554 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5a2724c-43a2-42b2-9b19-e99495c636a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668837463960806 139.74928171624578 35.352 35.66879421916535 139.74926033225637 35.352 35.66879421916535 139.74926033225637 37.55 35.668837463960806 139.74928171624578 37.55 35.668837463960806 139.74928171624578 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b1057f5-0217-4f57-869a-f3b6c21a54b8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884126158511 139.74927287542627 35.352 35.66878985632596 139.74924714785774 35.352 35.66879213203184 139.7492403190176 35.352 35.66884353730013 139.7492660576285 35.352 35.66884126158511 139.74927287542627 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fcc5a75-3797-41c7-a2c5-623f5c30187c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66887759708913 139.74950725667617 35.352 35.66880941163374 139.74947336137535 35.352 35.668811516407054 139.74946698560652 35.352 35.66887971087793 139.74950088089338 35.352 35.66887759708913 139.74950725667617 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0777ddf2-b21d-44bd-85ff-06fff752b2aa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66886568595467 139.7493850777052 40.794 35.66885516291481 139.7494181164126 40.794 35.66883144889077 139.7494067748484 40.794 35.66884196291385 139.74937373615873 40.794 35.66886568595467 139.7493850777052 40.794</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5952293b-b33e-4bbb-b4c7-3f1af17120ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66888861441986 139.74938153000826 44.142 35.668893732032046 139.74936546368534 44.142 35.66890575134318 139.74937120609428 44.142 35.66890063373024 139.74938727241926 44.142 35.66888861441986 139.74938153000826 44.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef7a278b-4593-4d2e-ac89-9184a591ffed">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898745335369 139.7493475482302 35.352 35.66897559593424 139.7493412975303 35.352 35.66897882543602 139.74933208172726 35.352 35.66899069186966 139.7493383324166 35.352 35.66898745335369 139.7493475482302 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a84af072-2095-41a5-a13c-534a1cb24713">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a84af072-2095-41a5-a13c-534a1cb24713">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a84af072-2095-41a5-a13c-534a1cb24713">
											<gml:posList>35.66860899884651 139.74945837166115 5.25 35.668722331882165 139.7491145005966 5.25 35.66873521687664 139.74910785944277 5.25 35.66904314596058 139.74926538441167 5.25 35.669046038527135 139.74927709021998 5.25 35.66892892257142 139.7496257161998 5.25 35.66892324638049 139.74962925686467 5.25 35.66861477847973 139.74947394049948 5.25 35.66860899884651 139.74945837166115 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3188bb3b-4349-4510-bc3a-4e6ecf9a7af0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3188bb3b-4349-4510-bc3a-4e6ecf9a7af0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3188bb3b-4349-4510-bc3a-4e6ecf9a7af0">
											<gml:posList>35.668722331882165 139.7491145005966 29.232 35.66872621105274 139.74911916899387 29.232 35.668735221543095 139.7491145312422 29.232 35.66873521687664 139.74910785944277 29.232 35.668722331882165 139.7491145005966 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3dbb9b1-761e-420a-8f95-95631b2328fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3dbb9b1-761e-420a-8f95-95631b2328fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3dbb9b1-761e-420a-8f95-95631b2328fa">
											<gml:posList>35.66860899884651 139.74945837166115 29.232 35.668614470071404 139.74945821129376 29.232 35.66872621105274 139.74911916899387 29.232 35.668722331882165 139.7491145005966 29.232 35.66860899884651 139.74945837166115 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28b2ac5d-f786-48a6-aeb0-9bc355c9e079">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28b2ac5d-f786-48a6-aeb0-9bc355c9e079">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28b2ac5d-f786-48a6-aeb0-9bc355c9e079">
											<gml:posList>35.66870159644888 139.7494447323679 35.959 35.668706272903485 139.74944233048683 35.959 35.66878286682768 139.7492158175714 35.959 35.66878093390057 139.74921010879655 35.959 35.66870159644888 139.7494447323679 35.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e60ddc3-3f3b-4a18-a178-a1dc8c6beb73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e60ddc3-3f3b-4a18-a178-a1dc8c6beb73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e60ddc3-3f3b-4a18-a178-a1dc8c6beb73">
											<gml:posList>35.66861477847973 139.74947394049948 29.232 35.6686185338808 139.74946916469227 29.232 35.668614470071404 139.74945821129376 29.232 35.66860899884651 139.74945837166115 29.232 35.66861477847973 139.74947394049948 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0079d2d3-3bae-4e93-8d6d-7e2e54348e9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0079d2d3-3bae-4e93-8d6d-7e2e54348e9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0079d2d3-3bae-4e93-8d6d-7e2e54348e9d">
											<gml:posList>35.66861477847973 139.74947394049948 29.232 35.668842274708815 139.74958849310593 29.232 35.66883953795661 139.7495804544413 29.232 35.6686185338808 139.74946916469227 29.232 35.66861477847973 139.74947394049948 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7038c189-f827-485c-80c6-ef8829753522">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7038c189-f827-485c-80c6-ef8829753522">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7038c189-f827-485c-80c6-ef8829753522">
											<gml:posList>35.66872621105274 139.74911916899387 28.594 35.668614470071404 139.74945821129376 28.594 35.6686185338808 139.74946916469227 28.594 35.66883953795661 139.7495804544413 28.594 35.66885714130021 139.74952794522207 28.594 35.66885901218846 139.74952224350446 28.594 35.66870159644888 139.7494447323679 28.594 35.66878093390057 139.74921010879655 28.594 35.66893686332545 139.74928876989705 28.594 35.66893877928641 139.74928309021308 28.594 35.66895746250378 139.7492282269193 28.594 35.668735221543095 139.7491145312422 28.594 35.66872621105274 139.74911916899387 28.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e6ee670-14c6-414d-9075-b1e5faabf9e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e6ee670-14c6-414d-9075-b1e5faabf9e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e6ee670-14c6-414d-9075-b1e5faabf9e9">
											<gml:posList>35.66894881975535 139.74956647748328 35.959 35.668946859834456 139.7495608129006 35.959 35.668706272903485 139.74944233048683 35.959 35.66870159644888 139.7494447323679 35.959 35.66894881975535 139.74956647748328 35.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32a081d3-cf1e-4d5c-9c18-8eb004411cf4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32a081d3-cf1e-4d5c-9c18-8eb004411cf4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32a081d3-cf1e-4d5c-9c18-8eb004411cf4">
											<gml:posList>35.66873521687664 139.74910785944277 29.232 35.668735221543095 139.7491145312422 29.232 35.66895746250378 139.7492282269193 29.232 35.668964031203835 139.74922491725567 29.232 35.66873521687664 139.74910785944277 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa276a31-9ca4-4c18-be53-f081e83456b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa276a31-9ca4-4c18-be53-f081e83456b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa276a31-9ca4-4c18-be53-f081e83456b3">
											<gml:posList>35.668863709954834 139.74952455826485 29.232 35.66885714130021 139.74952794522207 29.232 35.66883953795661 139.7495804544413 29.232 35.668842274708815 139.74958849310593 29.232 35.668863709954834 139.74952455826485 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-341c5c71-0192-47b4-835d-b13233792a5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-341c5c71-0192-47b4-835d-b13233792a5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-341c5c71-0192-47b4-835d-b13233792a5c">
											<gml:posList>35.66885714130021 139.74952794522207 29.232 35.668863709954834 139.74952455826485 29.232 35.66885901218846 139.74952224350446 29.232 35.66885714130021 139.74952794522207 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e16b9578-2f7d-44bb-9496-75d8ddd93d1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e16b9578-2f7d-44bb-9496-75d8ddd93d1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e16b9578-2f7d-44bb-9496-75d8ddd93d1c">
											<gml:posList>35.668946859834456 139.7495608129006 35.352 35.66902221165527 139.74933655411817 35.352 35.66878286682768 139.7492158175714 35.352 35.668706272903485 139.74944233048683 35.352 35.668946859834456 139.7495608129006 35.352</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c0c89ea9-1655-4f6d-99a3-1d9d98b51c12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0c89ea9-1655-4f6d-99a3-1d9d98b51c12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0c89ea9-1655-4f6d-99a3-1d9d98b51c12">
											<gml:posList>35.668926999468454 139.7496211451386 21.004 35.66894547450996 139.7495648240687 21.004 35.668863709954834 139.74952455826485 21.004 35.66884315623339 139.74958587427173 21.004 35.668921810564115 139.7496254695652 21.004 35.668926999468454 139.7496211451386 21.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ca464d8-1f64-4153-ab1c-d44b9b49c41f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ca464d8-1f64-4153-ab1c-d44b9b49c41f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ca464d8-1f64-4153-ab1c-d44b9b49c41f">
											<gml:posList>35.66892892257142 139.7496257161998 21.5 35.66894881975535 139.74956647748328 21.5 35.66894547450996 139.7495648240687 21.5 35.668926999468454 139.7496211451386 21.5 35.668921810564115 139.7496254695652 21.5 35.66884315623339 139.74958587427173 21.5 35.668842274708815 139.74958849310593 21.5 35.66892324638049 139.74962925686467 21.5 35.66892892257142 139.7496257161998 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5131e9de-4e7d-4a34-a1bb-25747ecd69cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5131e9de-4e7d-4a34-a1bb-25747ecd69cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5131e9de-4e7d-4a34-a1bb-25747ecd69cb">
											<gml:posList>35.66878093390057 139.74921010879655 35.959 35.66878286682768 139.7492158175714 35.959 35.66902221165527 139.74933655411817 35.959 35.66902686108169 139.74933417434164 35.959 35.66878093390057 139.74921010879655 35.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-12d75eff-8e65-469f-b4e4-cfe93e55bf44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12d75eff-8e65-469f-b4e4-cfe93e55bf44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12d75eff-8e65-469f-b4e4-cfe93e55bf44">
											<gml:posList>35.66893686332545 139.74928876989705 29.232 35.668941489001824 139.7492911068137 29.232 35.66893877928641 139.74928309021308 29.232 35.66893686332545 139.74928876989705 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77a45a30-0a44-434d-ab77-062985210852">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77a45a30-0a44-434d-ab77-062985210852">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77a45a30-0a44-434d-ab77-062985210852">
											<gml:posList>35.668964031203835 139.74922491725567 29.232 35.66895746250378 139.7492282269193 29.232 35.66893877928641 139.74928309021308 29.232 35.668941489001824 139.7492911068137 29.232 35.668964031203835 139.74922491725567 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97e4a802-de73-4b12-b07b-e0afc7b7e0db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97e4a802-de73-4b12-b07b-e0afc7b7e0db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97e4a802-de73-4b12-b07b-e0afc7b7e0db">
											<gml:posList>35.66902686108169 139.74933417434164 35.959 35.66902221165527 139.74933655411817 35.959 35.668946859834456 139.7495608129006 35.959 35.66894881975535 139.74956647748328 35.959 35.66902686108169 139.74933417434164 35.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d852a88-abbe-4651-9a65-44ff4bedcdad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d852a88-abbe-4651-9a65-44ff4bedcdad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d852a88-abbe-4651-9a65-44ff4bedcdad">
											<gml:posList>35.6690400021441 139.74926821550324 13.638 35.66896274487953 139.74922869635924 13.638 35.668941489001824 139.7492911068137 13.638 35.66902390353901 139.74933268622007 13.638 35.66904209152488 139.74927854139366 13.638 35.6690400021441 139.74926821550324 13.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0dc5e885-4cd9-457a-b9f2-5b94591cad64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dc5e885-4cd9-457a-b9f2-5b94591cad64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dc5e885-4cd9-457a-b9f2-5b94591cad64">
											<gml:posList>35.66904314596058 139.74926538441167 14.3 35.668964031203835 139.74922491725567 14.3 35.66896274487953 139.74922869635924 14.3 35.6690400021441 139.74926821550324 14.3 35.66904209152488 139.74927854139366 14.3 35.66902390353901 139.74933268622007 14.3 35.66902686108169 139.74933417434164 14.3 35.669046038527135 139.74927709021998 14.3 35.66904314596058 139.74926538441167 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d47fddb-126e-4935-bf3a-85f2afc82f3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d47fddb-126e-4935-bf3a-85f2afc82f3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d47fddb-126e-4935-bf3a-85f2afc82f3b">
											<gml:posList>35.66860899884651 139.74945837166115 5.25 35.66861477847973 139.74947394049948 5.25 35.66861477847973 139.74947394049948 29.232 35.66860899884651 139.74945837166115 29.232 35.66860899884651 139.74945837166115 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bccd58c-fd63-4f60-b277-ae5a3cc42886">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bccd58c-fd63-4f60-b277-ae5a3cc42886">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bccd58c-fd63-4f60-b277-ae5a3cc42886">
											<gml:posList>35.6686185338808 139.74946916469227 29.232 35.6686185338808 139.74946916469227 28.594 35.668614470071404 139.74945821129376 28.594 35.668614470071404 139.74945821129376 29.232 35.6686185338808 139.74946916469227 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-faa0e55e-c22f-40bb-a07d-32c5b37e4476">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faa0e55e-c22f-40bb-a07d-32c5b37e4476">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faa0e55e-c22f-40bb-a07d-32c5b37e4476">
											<gml:posList>35.668722331882165 139.7491145005966 5.25 35.66860899884651 139.74945837166115 5.25 35.66860899884651 139.74945837166115 29.232 35.668722331882165 139.7491145005966 29.232 35.668722331882165 139.7491145005966 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4b97f9a-c675-4eb6-8135-7fdc8c5092ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4b97f9a-c675-4eb6-8135-7fdc8c5092ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4b97f9a-c675-4eb6-8135-7fdc8c5092ff">
											<gml:posList>35.668614470071404 139.74945821129376 29.232 35.668614470071404 139.74945821129376 28.594 35.66872621105274 139.74911916899387 28.594 35.66872621105274 139.74911916899387 29.232 35.668614470071404 139.74945821129376 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e76a90e8-52cb-4dc3-ad22-5534be9f272e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e76a90e8-52cb-4dc3-ad22-5534be9f272e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e76a90e8-52cb-4dc3-ad22-5534be9f272e">
											<gml:posList>35.66883953795661 139.7495804544413 29.232 35.66883953795661 139.7495804544413 28.594 35.6686185338808 139.74946916469227 28.594 35.6686185338808 139.74946916469227 29.232 35.66883953795661 139.7495804544413 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82e3a2ef-2524-4bd0-98f7-fb1e862f6239">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82e3a2ef-2524-4bd0-98f7-fb1e862f6239">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82e3a2ef-2524-4bd0-98f7-fb1e862f6239">
											<gml:posList>35.66873521687664 139.74910785944277 5.25 35.668722331882165 139.7491145005966 5.25 35.668722331882165 139.7491145005966 29.232 35.66873521687664 139.74910785944277 29.232 35.66873521687664 139.74910785944277 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2919c0e3-36da-448c-9ec7-96b84a300db1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2919c0e3-36da-448c-9ec7-96b84a300db1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2919c0e3-36da-448c-9ec7-96b84a300db1">
											<gml:posList>35.66872621105274 139.74911916899387 29.232 35.66872621105274 139.74911916899387 28.594 35.668735221543095 139.7491145312422 28.594 35.668735221543095 139.7491145312422 29.232 35.66872621105274 139.74911916899387 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00745628-6def-4abf-b18d-9ad9d2661713">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00745628-6def-4abf-b18d-9ad9d2661713">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00745628-6def-4abf-b18d-9ad9d2661713">
											<gml:posList>35.66870159644888 139.7494447323679 35.959 35.66878093390057 139.74921010879655 35.959 35.66878093390057 139.74921010879655 28.594 35.66870159644888 139.7494447323679 28.594 35.66870159644888 139.7494447323679 35.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87f3d9af-d532-47df-9e0b-dc2fc25be6a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87f3d9af-d532-47df-9e0b-dc2fc25be6a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87f3d9af-d532-47df-9e0b-dc2fc25be6a9">
											<gml:posList>35.668706272903485 139.74944233048683 35.959 35.668706272903485 139.74944233048683 35.352 35.66878286682768 139.7492158175714 35.352 35.66878286682768 139.7492158175714 35.959 35.668706272903485 139.74944233048683 35.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aee1b46f-574a-4abc-85ca-f4fafb4762c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aee1b46f-574a-4abc-85ca-f4fafb4762c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aee1b46f-574a-4abc-85ca-f4fafb4762c5">
											<gml:posList>35.668842274708815 139.74958849310593 21.5 35.668842274708815 139.74958849310593 29.232 35.66861477847973 139.74947394049948 29.232 35.66861477847973 139.74947394049948 5.25 35.66892324638049 139.74962925686467 5.25 35.66892324638049 139.74962925686467 21.5 35.668842274708815 139.74958849310593 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7038a64-ac29-4bbb-9e02-58cd5050b4e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7038a64-ac29-4bbb-9e02-58cd5050b4e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7038a64-ac29-4bbb-9e02-58cd5050b4e5">
											<gml:posList>35.66894547450996 139.7495648240687 21.5 35.66894881975535 139.74956647748328 21.5 35.66894881975535 139.74956647748328 35.959 35.66870159644888 139.7494447323679 35.959 35.66870159644888 139.7494447323679 28.594 35.66885901218846 139.74952224350446 28.594 35.66885901218846 139.74952224350446 29.232 35.668863709954834 139.74952455826485 29.232 35.668863709954834 139.74952455826485 21.004 35.66894547450996 139.7495648240687 21.004 35.66894547450996 139.7495648240687 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32105048-8a77-4d90-b055-033fc9cab7ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32105048-8a77-4d90-b055-033fc9cab7ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32105048-8a77-4d90-b055-033fc9cab7ec">
											<gml:posList>35.668946859834456 139.7495608129006 35.959 35.668946859834456 139.7495608129006 35.352 35.668706272903485 139.74944233048683 35.352 35.668706272903485 139.74944233048683 35.959 35.668946859834456 139.7495608129006 35.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6093f327-2a06-4d35-bfcd-7b900c1905b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6093f327-2a06-4d35-bfcd-7b900c1905b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6093f327-2a06-4d35-bfcd-7b900c1905b8">
											<gml:posList>35.668735221543095 139.7491145312422 29.232 35.668735221543095 139.7491145312422 28.594 35.66895746250378 139.7492282269193 28.594 35.66895746250378 139.7492282269193 29.232 35.668735221543095 139.7491145312422 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7871b1cb-c564-4543-8a39-c934c8d1eccb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7871b1cb-c564-4543-8a39-c934c8d1eccb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7871b1cb-c564-4543-8a39-c934c8d1eccb">
											<gml:posList>35.66885714130021 139.74952794522207 29.232 35.66885714130021 139.74952794522207 28.594 35.66883953795661 139.7495804544413 28.594 35.66883953795661 139.7495804544413 29.232 35.66885714130021 139.74952794522207 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70112314-6126-4721-953f-07c6c7fa0a31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70112314-6126-4721-953f-07c6c7fa0a31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70112314-6126-4721-953f-07c6c7fa0a31">
											<gml:posList>35.668842274708815 139.74958849310593 29.232 35.668842274708815 139.74958849310593 21.5 35.66884315623339 139.74958587427173 21.5 35.66884315623339 139.74958587427173 21.004 35.668863709954834 139.74952455826485 21.004 35.668863709954834 139.74952455826485 29.232 35.668842274708815 139.74958849310593 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61f5e477-1c00-4eeb-95c3-95ae47e98f56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61f5e477-1c00-4eeb-95c3-95ae47e98f56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61f5e477-1c00-4eeb-95c3-95ae47e98f56">
											<gml:posList>35.66885901218846 139.74952224350446 29.232 35.66885901218846 139.74952224350446 28.594 35.66885714130021 139.74952794522207 28.594 35.66885714130021 139.74952794522207 29.232 35.66885901218846 139.74952224350446 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ceccc064-96da-4e9c-968c-eb0c32923267">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceccc064-96da-4e9c-968c-eb0c32923267">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceccc064-96da-4e9c-968c-eb0c32923267">
											<gml:posList>35.668921810564115 139.7496254695652 21.5 35.668921810564115 139.7496254695652 21.004 35.66884315623339 139.74958587427173 21.004 35.66884315623339 139.74958587427173 21.5 35.668921810564115 139.7496254695652 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6585667-83fb-4839-bdd2-829e15abd903">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6585667-83fb-4839-bdd2-829e15abd903">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6585667-83fb-4839-bdd2-829e15abd903">
											<gml:posList>35.66873521687664 139.74910785944277 5.25 35.66873521687664 139.74910785944277 29.232 35.668964031203835 139.74922491725567 29.232 35.668964031203835 139.74922491725567 14.3 35.66904314596058 139.74926538441167 14.3 35.66904314596058 139.74926538441167 5.25 35.66873521687664 139.74910785944277 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b788ae31-bf5d-4afa-889f-b1082bd986e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b788ae31-bf5d-4afa-889f-b1082bd986e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b788ae31-bf5d-4afa-889f-b1082bd986e6">
											<gml:posList>35.66878286682768 139.7492158175714 35.959 35.66878286682768 139.7492158175714 35.352 35.66902221165527 139.74933655411817 35.352 35.66902221165527 139.74933655411817 35.959 35.66878286682768 139.7492158175714 35.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13ec4229-fcf0-4046-9760-624119179624">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13ec4229-fcf0-4046-9760-624119179624">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13ec4229-fcf0-4046-9760-624119179624">
											<gml:posList>35.66902390353901 139.74933268622007 14.3 35.66902390353901 139.74933268622007 13.638 35.668941489001824 139.7492911068137 13.638 35.668941489001824 139.7492911068137 29.232 35.66893686332545 139.74928876989705 29.232 35.66893686332545 139.74928876989705 28.594 35.66878093390057 139.74921010879655 28.594 35.66878093390057 139.74921010879655 35.959 35.66902686108169 139.74933417434164 35.959 35.66902686108169 139.74933417434164 14.3 35.66902390353901 139.74933268622007 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2088e657-87eb-4c44-84d2-87fc424e9cb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2088e657-87eb-4c44-84d2-87fc424e9cb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2088e657-87eb-4c44-84d2-87fc424e9cb0">
											<gml:posList>35.668926999468454 139.7496211451386 21.5 35.668926999468454 139.7496211451386 21.004 35.668921810564115 139.7496254695652 21.004 35.668921810564115 139.7496254695652 21.5 35.668926999468454 139.7496211451386 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e379ef2-a6b8-4b79-9bff-a77c297e4cfa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e379ef2-a6b8-4b79-9bff-a77c297e4cfa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e379ef2-a6b8-4b79-9bff-a77c297e4cfa">
											<gml:posList>35.66892324638049 139.74962925686467 5.25 35.66892892257142 139.7496257161998 5.25 35.66892892257142 139.7496257161998 21.5 35.66892324638049 139.74962925686467 21.5 35.66892324638049 139.74962925686467 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c2927d8-dd82-417e-8466-03b17f8ef8fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c2927d8-dd82-417e-8466-03b17f8ef8fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c2927d8-dd82-417e-8466-03b17f8ef8fa">
											<gml:posList>35.66894547450996 139.7495648240687 21.5 35.66894547450996 139.7495648240687 21.004 35.668926999468454 139.7496211451386 21.004 35.668926999468454 139.7496211451386 21.5 35.66894547450996 139.7495648240687 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8174660-1c6e-41e2-966a-8cbca20eecdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8174660-1c6e-41e2-966a-8cbca20eecdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8174660-1c6e-41e2-966a-8cbca20eecdb">
											<gml:posList>35.66893877928641 139.74928309021308 29.232 35.66893877928641 139.74928309021308 28.594 35.66893686332545 139.74928876989705 28.594 35.66893686332545 139.74928876989705 29.232 35.66893877928641 139.74928309021308 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a18945e4-4fc0-4503-ba80-20edbfe6ac4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a18945e4-4fc0-4503-ba80-20edbfe6ac4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a18945e4-4fc0-4503-ba80-20edbfe6ac4c">
											<gml:posList>35.66895746250378 139.7492282269193 29.232 35.66895746250378 139.7492282269193 28.594 35.66893877928641 139.74928309021308 28.594 35.66893877928641 139.74928309021308 29.232 35.66895746250378 139.7492282269193 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f02f8ae-dc5c-4417-8f3d-19f5ab350b73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f02f8ae-dc5c-4417-8f3d-19f5ab350b73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f02f8ae-dc5c-4417-8f3d-19f5ab350b73">
											<gml:posList>35.668964031203835 139.74922491725567 29.232 35.668941489001824 139.7492911068137 29.232 35.668941489001824 139.7492911068137 13.638 35.66896274487953 139.74922869635924 13.638 35.66896274487953 139.74922869635924 14.3 35.668964031203835 139.74922491725567 14.3 35.668964031203835 139.74922491725567 29.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06614947-7947-4772-b38f-787113ca6043">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06614947-7947-4772-b38f-787113ca6043">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06614947-7947-4772-b38f-787113ca6043">
											<gml:posList>35.66902221165527 139.74933655411817 35.959 35.66902221165527 139.74933655411817 35.352 35.668946859834456 139.7495608129006 35.352 35.668946859834456 139.7495608129006 35.959 35.66902221165527 139.74933655411817 35.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d99771e-7a31-4ecb-9ea1-373d4aaca4c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d99771e-7a31-4ecb-9ea1-373d4aaca4c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d99771e-7a31-4ecb-9ea1-373d4aaca4c7">
											<gml:posList>35.66894881975535 139.74956647748328 21.5 35.66892892257142 139.7496257161998 21.5 35.66892892257142 139.7496257161998 5.25 35.669046038527135 139.74927709021998 5.25 35.669046038527135 139.74927709021998 14.3 35.66902686108169 139.74933417434164 14.3 35.66902686108169 139.74933417434164 35.959 35.66894881975535 139.74956647748328 35.959 35.66894881975535 139.74956647748328 21.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-126bf6ac-c0e5-4ea5-9e60-68d7e0fff1b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-126bf6ac-c0e5-4ea5-9e60-68d7e0fff1b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-126bf6ac-c0e5-4ea5-9e60-68d7e0fff1b8">
											<gml:posList>35.66896274487953 139.74922869635924 14.3 35.66896274487953 139.74922869635924 13.638 35.6690400021441 139.74926821550324 13.638 35.6690400021441 139.74926821550324 14.3 35.66896274487953 139.74922869635924 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3380a126-2ac0-4354-a7bc-b4555a73b334">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3380a126-2ac0-4354-a7bc-b4555a73b334">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3380a126-2ac0-4354-a7bc-b4555a73b334">
											<gml:posList>35.66904209152488 139.74927854139366 14.3 35.66904209152488 139.74927854139366 13.638 35.66902390353901 139.74933268622007 13.638 35.66902390353901 139.74933268622007 14.3 35.66904209152488 139.74927854139366 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74db8ccc-657f-40f0-a5c3-f64cfaee30fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74db8ccc-657f-40f0-a5c3-f64cfaee30fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74db8ccc-657f-40f0-a5c3-f64cfaee30fe">
											<gml:posList>35.6690400021441 139.74926821550324 14.3 35.6690400021441 139.74926821550324 13.638 35.66904209152488 139.74927854139366 13.638 35.66904209152488 139.74927854139366 14.3 35.6690400021441 139.74926821550324 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4582b5d-9643-4e8a-a434-a193c5ac3aac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4582b5d-9643-4e8a-a434-a193c5ac3aac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4582b5d-9643-4e8a-a434-a193c5ac3aac">
											<gml:posList>35.669046038527135 139.74927709021998 5.25 35.66904314596058 139.74926538441167 5.25 35.66904314596058 139.74926538441167 14.3 35.669046038527135 139.74927709021998 14.3 35.669046038527135 139.74927709021998 5.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9313</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1377.2449</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>