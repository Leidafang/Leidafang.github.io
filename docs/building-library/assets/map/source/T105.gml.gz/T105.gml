<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1b244f68-d038-4a8a-b559-7833b3808a10">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">21.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67379815882272 139.73778461262992 0 35.67372400257626 139.7378182830425 0 35.67378609452316 139.73802986438082 0 35.673864394951316 139.7379934275245 0 35.67384983903276 139.73793810068167 0 35.6739417459417 139.73789634506937 0 35.67384865541134 139.7375825076239 0 35.67375981046415 139.73762072493963 0 35.67379650110616 139.73774020675157 0 35.67378604896562 139.73774496930812 0 35.67379815882272 139.73778461262992 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67379815882272 139.73778461262992 8.98 35.67378604896562 139.73774496930812 8.98 35.67379650110616 139.73774020675157 8.98 35.67375981046415 139.73762072493963 8.98 35.67384865541134 139.7375825076239 8.98 35.6739417459417 139.73789634506937 8.98 35.67384983903276 139.73793810068167 8.98 35.673864394951316 139.7379934275245 8.98 35.67378609452316 139.73802986438082 8.98 35.67372400257626 139.7378182830425 8.98 35.67379815882272 139.73778461262992 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67379815882272 139.73778461262992 8.98 35.67372400257626 139.7378182830425 8.98 35.67372400257626 139.7378182830425 29.38 35.67379815882272 139.73778461262992 29.38 35.67379815882272 139.73778461262992 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67372400257626 139.7378182830425 8.98 35.67378609452316 139.73802986438082 8.98 35.67378609452316 139.73802986438082 29.38 35.67372400257626 139.7378182830425 29.38 35.67372400257626 139.7378182830425 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67378609452316 139.73802986438082 8.98 35.673864394951316 139.7379934275245 8.98 35.673864394951316 139.7379934275245 29.38 35.67378609452316 139.73802986438082 29.38 35.67378609452316 139.73802986438082 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673864394951316 139.7379934275245 8.98 35.67384983903276 139.73793810068167 8.98 35.67384983903276 139.73793810068167 29.38 35.673864394951316 139.7379934275245 29.38 35.673864394951316 139.7379934275245 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67384983903276 139.73793810068167 8.98 35.6739417459417 139.73789634506937 8.98 35.6739417459417 139.73789634506937 29.38 35.67384983903276 139.73793810068167 29.38 35.67384983903276 139.73793810068167 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6739417459417 139.73789634506937 8.98 35.67384865541134 139.7375825076239 8.98 35.67384865541134 139.7375825076239 29.38 35.6739417459417 139.73789634506937 29.38 35.6739417459417 139.73789634506937 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67384865541134 139.7375825076239 8.98 35.67375981046415 139.73762072493963 8.98 35.67375981046415 139.73762072493963 29.38 35.67384865541134 139.7375825076239 29.38 35.67384865541134 139.7375825076239 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67375981046415 139.73762072493963 8.98 35.67379650110616 139.73774020675157 8.98 35.67379650110616 139.73774020675157 29.38 35.67375981046415 139.73762072493963 29.38 35.67375981046415 139.73762072493963 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67379650110616 139.73774020675157 8.98 35.67378604896562 139.73774496930812 8.98 35.67378604896562 139.73774496930812 29.38 35.67379650110616 139.73774020675157 29.38 35.67379650110616 139.73774020675157 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67378604896562 139.73774496930812 8.98 35.67379815882272 139.73778461262992 8.98 35.67379815882272 139.73778461262992 29.38 35.67378604896562 139.73774496930812 29.38 35.67378604896562 139.73774496930812 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67379815882272 139.73778461262992 29.38 35.67372400257626 139.7378182830425 29.38 35.67378609452316 139.73802986438082 29.38 35.673864394951316 139.7379934275245 29.38 35.67384983903276 139.73793810068167 29.38 35.6739417459417 139.73789634506937 29.38 35.67384865541134 139.7375825076239 29.38 35.67375981046415 139.73762072493963 29.38 35.67379650110616 139.73774020675157 29.38 35.67378604896562 139.73774496930812 29.38 35.67379815882272 139.73778461262992 29.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7d02c88d-3f12-4efe-9acf-0af6d07fd060"/>
							<gml:surfaceMember xlink:href="#poly-a65200a7-58b7-4745-b922-50130023f7b5"/>
							<gml:surfaceMember xlink:href="#poly-3aaddfe8-c79c-4234-8437-2313c1a331fb"/>
							<gml:surfaceMember xlink:href="#poly-b8ee965c-a359-4e63-8c52-09f1eb4aedba"/>
							<gml:surfaceMember xlink:href="#poly-bc1b58ec-2db9-46ab-a22a-f0861b33909f"/>
							<gml:surfaceMember xlink:href="#poly-7debfb40-3149-46d9-bc50-9b5863a1d7c3"/>
							<gml:surfaceMember xlink:href="#poly-2663f214-88d5-49a4-bfa9-b4060a5e10c9"/>
							<gml:surfaceMember xlink:href="#poly-a2e3ea0d-f680-4ba2-89ee-41810a89cf63"/>
							<gml:surfaceMember xlink:href="#poly-0637bea6-e8dc-49bd-bf46-df5f6d089c3d"/>
							<gml:surfaceMember xlink:href="#poly-d654397b-ae19-4b89-9a94-1b09670a71b9"/>
							<gml:surfaceMember xlink:href="#poly-cec38973-0c2d-4247-860b-80d37ed9e586"/>
							<gml:surfaceMember xlink:href="#poly-e8be3c39-b0f1-416c-aebc-4fbbf3773f2a"/>
							<gml:surfaceMember xlink:href="#poly-e0201ba1-9db8-4b0d-8283-e2ff45566a7a"/>
							<gml:surfaceMember xlink:href="#poly-08564f3a-30b1-407d-98be-cfe9d90498ec"/>
							<gml:surfaceMember xlink:href="#poly-605e712e-fe19-479a-99bd-e2fdaabb3738"/>
							<gml:surfaceMember xlink:href="#poly-959776db-636a-46d4-bf58-8f38bcb959fd"/>
							<gml:surfaceMember xlink:href="#poly-45a8b57c-220e-4d40-9016-d7e1036306e3"/>
							<gml:surfaceMember xlink:href="#poly-ef3dd19a-adeb-4268-a5fb-36e7ff781c46"/>
							<gml:surfaceMember xlink:href="#poly-c44146cb-dc7b-41b9-b43b-8eb96231e7a6"/>
							<gml:surfaceMember xlink:href="#poly-b9613ead-fe46-4044-a51f-ef9d0221fcd8"/>
							<gml:surfaceMember xlink:href="#poly-138c367b-e677-4e6e-83be-1436a8e47db0"/>
							<gml:surfaceMember xlink:href="#poly-e5958eec-f5a1-41f1-9d7c-c6a20e178e61"/>
							<gml:surfaceMember xlink:href="#poly-e494e394-2b1b-43a3-97a2-9b9e885a57b2"/>
							<gml:surfaceMember xlink:href="#poly-d599b0b3-3158-481f-a275-e6c4aee04105"/>
							<gml:surfaceMember xlink:href="#poly-f0024778-4815-47e6-912c-663b5678e256"/>
							<gml:surfaceMember xlink:href="#poly-8d2e9258-9841-4be1-80bb-84c394e3dccf"/>
							<gml:surfaceMember xlink:href="#poly-44d28c04-b413-469f-adb2-227eafc14a5a"/>
							<gml:surfaceMember xlink:href="#poly-e8303338-eba8-42ff-916e-168f706b1d0e"/>
							<gml:surfaceMember xlink:href="#poly-df19f1db-3151-4d2d-9034-2195dcab6897"/>
							<gml:surfaceMember xlink:href="#poly-eb21800b-c59a-492a-9998-e79e81dcda02"/>
							<gml:surfaceMember xlink:href="#poly-7b893c43-50d2-4bf8-8d82-0a9da999aac0"/>
							<gml:surfaceMember xlink:href="#poly-67a59aea-4833-40d6-afe6-e1bd25c267b4"/>
							<gml:surfaceMember xlink:href="#poly-575baa4e-2070-45c2-a08b-aa2014dc28fd"/>
							<gml:surfaceMember xlink:href="#poly-29199d9c-5a30-4b3d-b4fc-35fc51780062"/>
							<gml:surfaceMember xlink:href="#poly-c52c5386-7300-4378-9427-8a2aab1501eb"/>
							<gml:surfaceMember xlink:href="#poly-58d25e92-2dbb-4972-bdc8-2f63d9576acc"/>
							<gml:surfaceMember xlink:href="#poly-de256013-5e03-4cc2-9bf8-1ca2dc181c83"/>
							<gml:surfaceMember xlink:href="#poly-ba27bc15-5ea8-4c53-8a33-03bc231b5cd0"/>
							<gml:surfaceMember xlink:href="#poly-666ae572-f348-42e7-81c5-73a5c1332b13"/>
							<gml:surfaceMember xlink:href="#poly-43bf9669-5b69-4358-9f51-7c2d77b39418"/>
							<gml:surfaceMember xlink:href="#poly-86db31c9-5f61-40f9-b77d-4377a7b5ddd7"/>
							<gml:surfaceMember xlink:href="#poly-33523739-e7ea-4628-ad49-60bb7b0e83ee"/>
							<gml:surfaceMember xlink:href="#poly-5057bdc5-b73e-4e68-9a1e-b03f23a4dd68"/>
							<gml:surfaceMember xlink:href="#poly-83eb662c-8539-4078-b8a4-3ee1f8f386f5"/>
							<gml:surfaceMember xlink:href="#poly-9ad500c9-8fc2-4b94-a67d-c80684096c36"/>
							<gml:surfaceMember xlink:href="#poly-8d78a438-afab-4485-80bf-b4cdc69606ad"/>
							<gml:surfaceMember xlink:href="#poly-f1b01511-b624-478a-bcf7-90bf2a721c58"/>
							<gml:surfaceMember xlink:href="#poly-f16fd098-a654-42f4-bd8a-4a939094d609"/>
							<gml:surfaceMember xlink:href="#poly-2a49dd51-164e-460c-be11-a6473d38d564"/>
							<gml:surfaceMember xlink:href="#poly-32a0a7d9-b081-4ff9-897b-edcce6ff9710"/>
							<gml:surfaceMember xlink:href="#poly-edd85fa2-3d90-46e0-ab1a-2449f49aba22"/>
							<gml:surfaceMember xlink:href="#poly-16d77788-0fce-40f6-9a82-fe6d4ed7cdc9"/>
							<gml:surfaceMember xlink:href="#poly-b0c44a56-3816-42b5-997e-1b457b6472a5"/>
							<gml:surfaceMember xlink:href="#poly-8b91836d-c42e-435a-838a-73e54680e6c0"/>
							<gml:surfaceMember xlink:href="#poly-d7714f17-9bd5-4a79-9437-425a4b7c7a2c"/>
							<gml:surfaceMember xlink:href="#poly-a8a3f567-f111-484c-bc57-fba9e223723c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1b244f68-d038-4a8a-b559-7833b3808a10_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3da824f9-f87c-44be-b315-f314d19ed14d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3da824f9-f87c-44be-b315-f314d19ed14d_0">
											<gml:posList>35.673810439743825 139.7378808592137 31.004 35.67376854124864 139.73790019668442 34.851 35.67376854124864 139.73790019668442 31.004 35.673810439743825 139.7378808592137 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d571356-22fe-425a-ade5-680267f0eb22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d571356-22fe-425a-ade5-680267f0eb22_0">
											<gml:posList>35.673810439743825 139.7378808592137 31.004 35.673810439743825 139.7378808592137 34.851 35.67376854124864 139.73790019668442 34.851 35.673810439743825 139.7378808592137 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80e753ac-5b1d-45fe-8b95-f32bffdae4d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80e753ac-5b1d-45fe-8b95-f32bffdae4d8_0">
											<gml:posList>35.673817007785594 139.7378998628204 31.004 35.673866849258644 139.737871534881 34.851 35.673817007785594 139.7378998628204 34.851 35.673817007785594 139.7378998628204 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-023af708-26e7-4b23-a4c0-67fdc65bc962">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-023af708-26e7-4b23-a4c0-67fdc65bc962_0">
											<gml:posList>35.673817007785594 139.7378998628204 31.004 35.673866849258644 139.737871534881 31.004 35.673866849258644 139.737871534881 34.851 35.673817007785594 139.7378998628204 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04019f82-da9f-45bd-a28d-e6f65587a83e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04019f82-da9f-45bd-a28d-e6f65587a83e_0">
											<gml:posList>35.67385498682639 139.73765529806465 30.977 35.67385920376237 139.737653426133 29.374 35.67385498682639 139.73765529806465 29.374 35.67385498682639 139.73765529806465 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0458ea72-8540-495d-9916-e869b0f94548">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0458ea72-8540-495d-9916-e869b0f94548_0">
											<gml:posList>35.67385498682639 139.73765529806465 30.977 35.67385920376237 139.737653426133 30.977 35.67385920376237 139.737653426133 29.374 35.67385498682639 139.73765529806465 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0bd2642-a0e8-4114-9780-5c9caef42b3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0bd2642-a0e8-4114-9780-5c9caef42b3c_0">
											<gml:posList>35.67385920376237 139.737653426133 30.977 35.67386300872775 139.73766624685578 29.374 35.67385920376237 139.737653426133 29.374 35.67385920376237 139.737653426133 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5c31480-2757-41ac-b5a3-55c14a8dad16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5c31480-2757-41ac-b5a3-55c14a8dad16_0">
											<gml:posList>35.67385920376237 139.737653426133 30.977 35.67386300872775 139.73766624685578 30.977 35.67386300872775 139.73766624685578 29.374 35.67385920376237 139.737653426133 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96e33b7c-7cc7-4487-8a1a-b5a068bbf8de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96e33b7c-7cc7-4487-8a1a-b5a068bbf8de_0">
											<gml:posList>35.67387178480522 139.73766210490206 30.977 35.67387178480522 139.73766210490206 30.186 35.67386709041424 139.73766431985223 30.186 35.67387178480522 139.73766210490206 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19da42b7-d0d2-443e-9281-a5974855ffb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19da42b7-d0d2-443e-9281-a5974855ffb9_0">
											<gml:posList>35.67387178480522 139.73766210490206 30.977 35.67386709041424 139.73766431985223 30.186 35.67386300872775 139.73766624685578 30.977 35.67387178480522 139.73766210490206 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90c6cb93-5e26-4d2a-8de8-130a350cd10b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90c6cb93-5e26-4d2a-8de8-130a350cd10b_0">
											<gml:posList>35.67386709041424 139.73766431985223 30.186 35.67386300872775 139.73766624685578 29.374 35.67386300872775 139.73766624685578 30.977 35.67386709041424 139.73766431985223 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbea8169-9181-4374-8368-87a2b4583bc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbea8169-9181-4374-8368-87a2b4583bc9_0">
											<gml:posList>35.67386709041424 139.73766431985223 30.186 35.67386709041424 139.73766431985223 29.374 35.67386300872775 139.73766624685578 29.374 35.67386709041424 139.73766431985223 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a30c1cbf-a119-4aaa-9673-6c201c134cc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a30c1cbf-a119-4aaa-9673-6c201c134cc6_0">
											<gml:posList>35.67387178480522 139.73766210490206 30.977 35.673874902901765 139.7376726287248 30.186 35.67387178480522 139.73766210490206 30.186 35.67387178480522 139.73766210490206 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5869360b-6f19-4b07-a6b0-27417d2d044d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5869360b-6f19-4b07-a6b0-27417d2d044d_0">
											<gml:posList>35.67387178480522 139.73766210490206 30.977 35.673874902901765 139.7376726287248 30.977 35.673874902901765 139.7376726287248 30.186 35.67387178480522 139.73766210490206 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b8e3430-2a2e-407b-aada-3028ea184ed3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b8e3430-2a2e-407b-aada-3028ea184ed3_0">
											<gml:posList>35.673870208510586 139.73767484367445 29.374 35.67386709041424 139.73766431985223 30.186 35.673870208510586 139.73767484367445 30.186 35.673870208510586 139.73767484367445 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b224fdf-919c-407a-b373-99ef79ca4e3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b224fdf-919c-407a-b373-99ef79ca4e3c_0">
											<gml:posList>35.673870208510586 139.73767484367445 29.374 35.67386709041424 139.73766431985223 29.374 35.67386709041424 139.73766431985223 30.186 35.673870208510586 139.73767484367445 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a08d8086-9343-4b5c-8beb-bba4cd10c11f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a08d8086-9343-4b5c-8beb-bba4cd10c11f_0">
											<gml:posList>35.67386300872775 139.73766624685578 30.977 35.67385498682639 139.73765529806465 30.977 35.67386520872209 139.73768975169173 30.977 35.67386300872775 139.73766624685578 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-923c20d0-089c-4a29-bcde-a2879d87bd2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-923c20d0-089c-4a29-bcde-a2879d87bd2d_0">
											<gml:posList>35.67386520872209 139.73768975169173 30.977 35.67386942565859 139.73768787976167 30.977 35.67386612682392 139.73767677067755 30.977 35.67386520872209 139.73768975169173 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd667d80-aa19-452b-b649-db3a1696368a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd667d80-aa19-452b-b649-db3a1696368a_0">
											<gml:posList>35.67386300872775 139.73766624685578 30.977 35.67385920376237 139.737653426133 30.977 35.67385498682639 139.73765529806465 30.977 35.67386300872775 139.73766624685578 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e887165-c381-4c68-b8f1-e386aafa266c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e887165-c381-4c68-b8f1-e386aafa266c_0">
											<gml:posList>35.673874902901765 139.7376726287248 30.977 35.67387178480522 139.73766210490206 30.977 35.67386300872775 139.73766624685578 30.977 35.673874902901765 139.7376726287248 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f66f4e3-991d-4f32-b2d5-e7fb3eb73e85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f66f4e3-991d-4f32-b2d5-e7fb3eb73e85_0">
											<gml:posList>35.673874902901765 139.7376726287248 30.977 35.67386300872775 139.73766624685578 30.977 35.67386612682392 139.73767677067755 30.977 35.673874902901765 139.7376726287248 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-300a72a4-8a3d-42de-a738-dbcddd283979">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-300a72a4-8a3d-42de-a738-dbcddd283979_0">
											<gml:posList>35.67386300872775 139.73766624685578 30.977 35.67386520872209 139.73768975169173 30.977 35.67386612682392 139.73767677067755 30.977 35.67386300872775 139.73766624685578 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e93aeda8-12c6-4e4b-a7cd-0ec03a71e45a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e93aeda8-12c6-4e4b-a7cd-0ec03a71e45a_0">
											<gml:posList>35.67386520872209 139.73768975169173 30.977 35.67385498682639 139.73765529806465 29.374 35.67386520872209 139.73768975169173 29.374 35.67386520872209 139.73768975169173 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d00a1d3a-528c-47f1-92f5-896af6a8fe51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d00a1d3a-528c-47f1-92f5-896af6a8fe51_0">
											<gml:posList>35.67386520872209 139.73768975169173 30.977 35.67385498682639 139.73765529806465 30.977 35.67385498682639 139.73765529806465 29.374 35.67386520872209 139.73768975169173 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-648d30ce-d141-47b7-9cfc-884e2e7e6cde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-648d30ce-d141-47b7-9cfc-884e2e7e6cde_0">
											<gml:posList>35.67386612682392 139.73767677067755 30.977 35.67386612682392 139.73767677067755 29.374 35.673870208510586 139.73767484367445 30.186 35.67386612682392 139.73767677067755 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04008b68-dc66-46b2-a4b4-cbcd2f14beb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04008b68-dc66-46b2-a4b4-cbcd2f14beb3_0">
											<gml:posList>35.67386612682392 139.73767677067755 29.374 35.673870208510586 139.73767484367445 29.374 35.673870208510586 139.73767484367445 30.186 35.67386612682392 139.73767677067755 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-125c2f6d-4414-47a2-957c-19c63b671d33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-125c2f6d-4414-47a2-957c-19c63b671d33_0">
											<gml:posList>35.673874902901765 139.7376726287248 30.977 35.67386612682392 139.73767677067755 30.977 35.673870208510586 139.73767484367445 30.186 35.673874902901765 139.7376726287248 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50ec59c2-3d6d-44d0-85e6-df34a6543ef1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50ec59c2-3d6d-44d0-85e6-df34a6543ef1_0">
											<gml:posList>35.673874902901765 139.7376726287248 30.186 35.673874902901765 139.7376726287248 30.977 35.673870208510586 139.73767484367445 30.186 35.673874902901765 139.7376726287248 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9817ebe2-dc23-4324-bb21-00b5073dc8f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9817ebe2-dc23-4324-bb21-00b5073dc8f1_0">
											<gml:posList>35.67378417664691 139.7376800609658 31.949 35.67379776436479 139.73767379230415 29.374 35.67378417664691 139.7376800609658 29.374 35.67378417664691 139.7376800609658 31.949</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76fae985-567a-44a0-b763-8c335fd76499">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76fae985-567a-44a0-b763-8c335fd76499_0">
											<gml:posList>35.67378417664691 139.7376800609658 31.949 35.67379776436479 139.73767379230415 31.949 35.67379776436479 139.73767379230415 29.374 35.67378417664691 139.7376800609658 31.949</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23cbe536-2d0f-45d9-90d5-45df16276eee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23cbe536-2d0f-45d9-90d5-45df16276eee_0">
											<gml:posList>35.67386612682392 139.73767677067755 30.977 35.67386942565859 139.73768787976167 29.374 35.67386612682392 139.73767677067755 29.374 35.67386612682392 139.73767677067755 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2aad0844-ca54-468b-b3a6-e1e9d6997bac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2aad0844-ca54-468b-b3a6-e1e9d6997bac_0">
											<gml:posList>35.67386612682392 139.73767677067755 30.977 35.67386942565859 139.73768787976167 30.977 35.67386942565859 139.73768787976167 29.374 35.67386612682392 139.73767677067755 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5132535c-d412-4d37-8dd6-fed85acafd43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5132535c-d412-4d37-8dd6-fed85acafd43_0">
											<gml:posList>35.67379776436479 139.73767379230415 31.949 35.67380354810546 139.73769262007883 29.374 35.67379776436479 139.73767379230415 29.374 35.67379776436479 139.73767379230415 31.949</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19ccf25f-037e-4f2b-91ac-b9452537f379">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19ccf25f-037e-4f2b-91ac-b9452537f379_0">
											<gml:posList>35.67379776436479 139.73767379230415 31.949 35.67380354810546 139.73769262007883 31.949 35.67380354810546 139.73769262007883 29.374 35.67379776436479 139.73767379230415 31.949</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fee9d3f9-7cd4-4128-8717-240541abe90d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fee9d3f9-7cd4-4128-8717-240541abe90d_0">
											<gml:posList>35.67380354810546 139.73769262007883 31.949 35.67379776436479 139.73767379230415 31.949 35.67378417664691 139.7376800609658 31.949 35.67380354810546 139.73769262007883 31.949</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c14c74bb-2de2-46f5-8456-5f37007b2ce6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c14c74bb-2de2-46f5-8456-5f37007b2ce6_0">
											<gml:posList>35.6737899513729 139.7376988887485 31.949 35.67380354810546 139.73769262007883 31.949 35.67378417664691 139.7376800609658 31.949 35.6737899513729 139.7376988887485 31.949</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d04ef785-fc9c-4c03-9bd9-a97c48cba96e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d04ef785-fc9c-4c03-9bd9-a97c48cba96e_0">
											<gml:posList>35.67386942565859 139.73768787976167 30.977 35.67386520872209 139.73768975169173 29.374 35.67386942565859 139.73768787976167 29.374 35.67386942565859 139.73768787976167 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cfaa8d6-29ec-4083-9afc-4a803a1b7297">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cfaa8d6-29ec-4083-9afc-4a803a1b7297_0">
											<gml:posList>35.67386942565859 139.73768787976167 30.977 35.67386520872209 139.73768975169173 30.977 35.67386520872209 139.73768975169173 29.374 35.67386942565859 139.73768787976167 30.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25acba10-722f-48f7-a0a4-3ff70f57d797">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25acba10-722f-48f7-a0a4-3ff70f57d797_0">
											<gml:posList>35.67378417664691 139.7376800609658 31.949 35.6737899513729 139.7376988887485 29.374 35.6737899513729 139.7376988887485 31.949 35.67378417664691 139.7376800609658 31.949</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e29226b-65cc-4522-bf14-ff9f5d7a0fec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e29226b-65cc-4522-bf14-ff9f5d7a0fec_0">
											<gml:posList>35.67378417664691 139.7376800609658 31.949 35.67378417664691 139.7376800609658 29.374 35.6737899513729 139.7376988887485 29.374 35.67378417664691 139.7376800609658 31.949</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-316e07b3-a740-49f8-b9cb-85ea4536c867">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-316e07b3-a740-49f8-b9cb-85ea4536c867_0">
											<gml:posList>35.6737899513729 139.7376988887485 31.949 35.67380354810546 139.73769262007883 29.374 35.67380354810546 139.73769262007883 31.949 35.6737899513729 139.7376988887485 31.949</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc461b28-756d-40e7-8e08-f89f946e4b0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc461b28-756d-40e7-8e08-f89f946e4b0b_0">
											<gml:posList>35.6737899513729 139.7376988887485 31.949 35.6737899513729 139.7376988887485 29.374 35.67380354810546 139.73769262007883 29.374 35.6737899513729 139.7376988887485 31.949</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d6759bb-9f67-4f78-8fc7-991398438b58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d6759bb-9f67-4f78-8fc7-991398438b58_0">
											<gml:posList>35.67387975533694 139.73771051325735 29.374 35.67388205999297 139.73771826532104 30.723 35.67388205999297 139.73771826532104 29.374 35.67387975533694 139.73771051325735 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16d5be09-6035-4ac5-aef2-4634e1067d66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16d5be09-6035-4ac5-aef2-4634e1067d66_0">
											<gml:posList>35.67387975533694 139.73771051325735 29.374 35.67387975533694 139.73771051325735 30.723 35.67388205999297 139.73771826532104 30.723 35.67387975533694 139.73771051325735 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0a2205c-d2b9-4258-a2a1-292262c398a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0a2205c-d2b9-4258-a2a1-292262c398a5_0">
											<gml:posList>35.67385861662274 139.73771993924586 29.374 35.67387975533694 139.73771051325735 30.723 35.67387975533694 139.73771051325735 29.374 35.67385861662274 139.73771993924586 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c933bb51-d395-48f8-ab73-7afb8346c109">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c933bb51-d395-48f8-ab73-7afb8346c109_0">
											<gml:posList>35.67385861662274 139.73771993924586 29.374 35.67385861662274 139.73771993924586 30.723 35.67387975533694 139.73771051325735 30.723 35.67385861662274 139.73771993924586 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3862372e-ac47-4f88-9fea-14697e93be4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3862372e-ac47-4f88-9fea-14697e93be4d_0">
											<gml:posList>35.67387975533694 139.73771051325735 30.723 35.67386091225569 139.7377276802718 30.723 35.67388205999297 139.73771826532104 30.723 35.67387975533694 139.73771051325735 30.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cef4484f-a612-4a46-8d5f-e087df904cd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cef4484f-a612-4a46-8d5f-e087df904cd4_0">
											<gml:posList>35.67387975533694 139.73771051325735 30.723 35.67385861662274 139.73771993924586 30.723 35.67386091225569 139.7377276802718 30.723 35.67387975533694 139.73771051325735 30.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fae75d4d-224d-4c10-8fc0-cb9975215e01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fae75d4d-224d-4c10-8fc0-cb9975215e01_0">
											<gml:posList>35.67388205999297 139.73771826532104 29.374 35.67386091225569 139.7377276802718 30.723 35.67386091225569 139.7377276802718 29.374 35.67388205999297 139.73771826532104 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01253625-1db6-4b14-8e1f-d6e340bfb40d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01253625-1db6-4b14-8e1f-d6e340bfb40d_0">
											<gml:posList>35.67388205999297 139.73771826532104 29.374 35.67388205999297 139.73771826532104 30.723 35.67386091225569 139.7377276802718 30.723 35.67388205999297 139.73771826532104 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27217fda-0388-4143-bf87-52946daa9e89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27217fda-0388-4143-bf87-52946daa9e89_0">
											<gml:posList>35.67386091225569 139.7377276802718 29.374 35.67385861662274 139.73771993924586 30.723 35.67385861662274 139.73771993924586 29.374 35.67386091225569 139.7377276802718 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c76e0e08-a5ee-4477-84f8-8662e7626a81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c76e0e08-a5ee-4477-84f8-8662e7626a81_0">
											<gml:posList>35.67386091225569 139.7377276802718 29.374 35.67386091225569 139.7377276802718 30.723 35.67385861662274 139.73771993924586 30.723 35.67386091225569 139.7377276802718 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfe6b748-dcfe-4a19-9606-0a28b0bbaed7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfe6b748-dcfe-4a19-9606-0a28b0bbaed7_0">
											<gml:posList>35.67381951085168 139.73781682154825 39.196 35.67381128431633 139.73782059828542 35.526 35.67381128431633 139.73782059828542 39.196 35.67381951085168 139.73781682154825 39.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-348b6586-54b4-4afd-a8f1-a6be6edd9422">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-348b6586-54b4-4afd-a8f1-a6be6edd9422_0">
											<gml:posList>35.67381951085168 139.73781682154825 39.196 35.67381951085168 139.73781682154825 35.526 35.67381128431633 139.73782059828542 35.526 35.67381951085168 139.73781682154825 39.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b01e42a-3aca-49bd-a94a-99be7bb35074">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b01e42a-3aca-49bd-a94a-99be7bb35074_0">
											<gml:posList>35.67381951085168 139.73781682154825 39.196 35.67382194185065 139.73782477229983 35.526 35.67381951085168 139.73781682154825 35.526 35.67381951085168 139.73781682154825 39.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9582a07-a4f7-493c-a4af-4b5f0f8d46fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9582a07-a4f7-493c-a4af-4b5f0f8d46fd_0">
											<gml:posList>35.67381951085168 139.73781682154825 39.196 35.67382194185065 139.73782477229983 39.196 35.67382194185065 139.73782477229983 35.526 35.67381951085168 139.73781682154825 39.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ddec6fe-0e0e-4df0-9ddf-5b7963128e3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ddec6fe-0e0e-4df0-9ddf-5b7963128e3b_0">
											<gml:posList>35.67381371531505 139.73782854903632 39.196 35.67381951085168 139.73781682154825 39.196 35.67381128431633 139.73782059828542 39.196 35.67381371531505 139.73782854903632 39.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f134b2b5-ab22-4fd8-b01d-a38cda439322">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f134b2b5-ab22-4fd8-b01d-a38cda439322_0">
											<gml:posList>35.67381371531505 139.73782854903632 39.196 35.67382194185065 139.73782477229983 39.196 35.67381951085168 139.73781682154825 39.196 35.67381371531505 139.73782854903632 39.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38d93627-2c17-412b-a91e-91febc72746a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38d93627-2c17-412b-a91e-91febc72746a_0">
											<gml:posList>35.67381371531505 139.73782854903632 39.196 35.67381128431633 139.73782059828542 35.526 35.67381371531505 139.73782854903632 35.526 35.67381371531505 139.73782854903632 39.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a10b1f6f-18d5-4e9e-b12e-9efb2f32a216">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a10b1f6f-18d5-4e9e-b12e-9efb2f32a216_0">
											<gml:posList>35.67381371531505 139.73782854903632 39.196 35.67381128431633 139.73782059828542 39.196 35.67381128431633 139.73782059828542 35.526 35.67381371531505 139.73782854903632 39.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fc1c3b9-a7cf-4804-90aa-3feb5f3736c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fc1c3b9-a7cf-4804-90aa-3feb5f3736c7_0">
											<gml:posList>35.67382194185065 139.73782477229983 39.196 35.67381371531505 139.73782854903632 35.526 35.67382194185065 139.73782477229983 35.526 35.67382194185065 139.73782477229983 39.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b50b9d5d-84d7-4a49-bc1b-0dbd2390585f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b50b9d5d-84d7-4a49-bc1b-0dbd2390585f_0">
											<gml:posList>35.67382194185065 139.73782477229983 39.196 35.67381371531505 139.73782854903632 39.196 35.67381371531505 139.73782854903632 35.526 35.67382194185065 139.73782477229983 39.196</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81cb18f9-96c5-4c67-91f0-d333d443d3d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81cb18f9-96c5-4c67-91f0-d333d443d3d6_0">
											<gml:posList>35.673771324515926 139.7378408614035 31 35.67377886620224 139.73783732851408 29.374 35.673771324515926 139.7378408614035 29.374 35.673771324515926 139.7378408614035 31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4eb43e2-4806-4d8f-aa87-1802c77066fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4eb43e2-4806-4d8f-aa87-1802c77066fe_0">
											<gml:posList>35.673771324515926 139.7378408614035 31 35.67377886620224 139.73783732851408 31 35.67377886620224 139.73783732851408 29.374 35.673771324515926 139.7378408614035 31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71a5d445-1e52-45a3-90ca-73124f3a643c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71a5d445-1e52-45a3-90ca-73124f3a643c_0">
											<gml:posList>35.67377886620224 139.73783732851408 31 35.673789466306786 139.73787138399916 29.374 35.67377886620224 139.73783732851408 29.374 35.67377886620224 139.73783732851408 31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f98572c-bcc3-4876-b7b1-a8fc6c59fa01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f98572c-bcc3-4876-b7b1-a8fc6c59fa01_0">
											<gml:posList>35.67377886620224 139.73783732851408 31 35.673789466306786 139.73787138399916 31 35.673789466306786 139.73787138399916 29.374 35.67377886620224 139.73783732851408 31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90fbdb28-b363-478c-b8f2-0c6148fa482b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90fbdb28-b363-478c-b8f2-0c6148fa482b_0">
											<gml:posList>35.673771324515926 139.7378408614035 31 35.673781924610736 139.73787490583913 31 35.673789466306786 139.73787138399916 31 35.673771324515926 139.7378408614035 31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8af4e80-10c5-4b85-9e01-56e9a4939ce5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8af4e80-10c5-4b85-9e01-56e9a4939ce5_0">
											<gml:posList>35.67377886620224 139.73783732851408 31 35.673771324515926 139.7378408614035 31 35.673789466306786 139.73787138399916 31 35.67377886620224 139.73783732851408 31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d88f96c9-8a57-4307-b52d-bafc1662aca8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d88f96c9-8a57-4307-b52d-bafc1662aca8_0">
											<gml:posList>35.673781924610736 139.73787490583913 31 35.673771324515926 139.7378408614035 29.374 35.673781924610736 139.73787490583913 29.374 35.673781924610736 139.73787490583913 31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eb763c7-184e-4532-9719-a2b41ab9b9af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eb763c7-184e-4532-9719-a2b41ab9b9af_0">
											<gml:posList>35.673781924610736 139.73787490583913 31 35.673771324515926 139.7378408614035 31 35.673771324515926 139.7378408614035 29.374 35.673781924610736 139.73787490583913 31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61beda6b-cd1e-4f20-9642-e317d9e63ddd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61beda6b-cd1e-4f20-9642-e317d9e63ddd_0">
											<gml:posList>35.67376842560356 139.7378566506281 31.73 35.67376169494973 139.73785992847468 29.374 35.67376169494973 139.73785992847468 31.73 35.67376842560356 139.7378566506281 31.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe9a8226-d566-4116-a8e5-beb26a0141ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe9a8226-d566-4116-a8e5-beb26a0141ec_0">
											<gml:posList>35.67376842560356 139.7378566506281 31.73 35.67376842560356 139.7378566506281 29.374 35.67376169494973 139.73785992847468 29.374 35.67376842560356 139.7378566506281 31.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-346fa53a-0130-4be8-95a0-98ed779d1a41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-346fa53a-0130-4be8-95a0-98ed779d1a41_0">
											<gml:posList>35.67391485796219 139.73785082029755 34.851 35.67386589133485 139.73786842084115 29.374 35.67386589133485 139.73786842084115 34.851 35.67391485796219 139.73785082029755 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54b28795-49d7-4086-9c58-12e77ec6acf6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54b28795-49d7-4086-9c58-12e77ec6acf6_0">
											<gml:posList>35.67391485796219 139.73785082029755 34.851 35.67391485796219 139.73785082029755 29.374 35.67386589133485 139.73786842084115 29.374 35.67391485796219 139.73785082029755 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22cf0f1b-ebd5-403d-91d8-3bbdbb8f7ea4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22cf0f1b-ebd5-403d-91d8-3bbdbb8f7ea4_0">
											<gml:posList>35.673913211658096 139.7378548653674 34.851 35.673866849258644 139.737871534881 31.004 35.673913211658096 139.7378548653674 31.004 35.673913211658096 139.7378548653674 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d341c0c-634c-46ac-be91-edcef84653c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d341c0c-634c-46ac-be91-edcef84653c0_0">
											<gml:posList>35.673913211658096 139.7378548653674 34.851 35.673866849258644 139.737871534881 34.851 35.673866849258644 139.737871534881 31.004 35.673913211658096 139.7378548653674 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-380d3fac-223b-42bb-98a0-623fc9aee682">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-380d3fac-223b-42bb-98a0-623fc9aee682_0">
											<gml:posList>35.67376842560356 139.7378566506281 31.73 35.67377578978127 139.73787934288166 29.374 35.67376842560356 139.7378566506281 29.374 35.67376842560356 139.7378566506281 31.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc7c8f4e-d409-4ff2-b96e-54b398aecbaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc7c8f4e-d409-4ff2-b96e-54b398aecbaf_0">
											<gml:posList>35.67376842560356 139.7378566506281 31.73 35.67377578978127 139.73787934288166 31.73 35.67377578978127 139.73787934288166 29.374 35.67376842560356 139.7378566506281 31.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86d02b7b-15ed-4eef-8fab-dd7a2882c289">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86d02b7b-15ed-4eef-8fab-dd7a2882c289_0">
											<gml:posList>35.67376842560356 139.7378566506281 31.73 35.673769059126826 139.73788262072665 31.73 35.67377578978127 139.73787934288166 31.73 35.67376842560356 139.7378566506281 31.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02d3ac97-694b-4b22-a03f-f0c068c2b499">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02d3ac97-694b-4b22-a03f-f0c068c2b499_0">
											<gml:posList>35.67376842560356 139.7378566506281 31.73 35.67376169494973 139.73785992847468 31.73 35.673769059126826 139.73788262072665 31.73 35.67376842560356 139.7378566506281 31.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6983ad90-a696-491a-97f7-c50347811278">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6983ad90-a696-491a-97f7-c50347811278_0">
											<gml:posList>35.67391485796219 139.73785082029755 34.851 35.67392642537637 139.7378884648835 29.374 35.67391485796219 139.73785082029755 29.374 35.67391485796219 139.73785082029755 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43140875-007a-4b4d-b8fd-51c7da9e2a44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43140875-007a-4b4d-b8fd-51c7da9e2a44_0">
											<gml:posList>35.67391485796219 139.73785082029755 34.851 35.67392642537637 139.7378884648835 34.851 35.67392642537637 139.7378884648835 29.374 35.67391485796219 139.73785082029755 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01f9dd8a-82eb-4030-a930-8ef4a11bf65b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01f9dd8a-82eb-4030-a930-8ef4a11bf65b_0">
											<gml:posList>35.673913211658096 139.7378548653674 31.004 35.67392294454932 139.7378865358469 34.851 35.673913211658096 139.7378548653674 34.851 35.673913211658096 139.7378548653674 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d1792dd-8658-48b0-8ab1-2e5fd05cd78e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d1792dd-8658-48b0-8ab1-2e5fd05cd78e_0">
											<gml:posList>35.673913211658096 139.7378548653674 31.004 35.67392294454932 139.7378865358469 31.004 35.67392294454932 139.7378865358469 34.851 35.673913211658096 139.7378548653674 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77521b4a-6079-47b4-994c-1518672d3faa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77521b4a-6079-47b4-994c-1518672d3faa_0">
											<gml:posList>35.673769059126826 139.73788262072665 31.73 35.67376169494973 139.73785992847468 29.374 35.673769059126826 139.73788262072665 29.374 35.673769059126826 139.73788262072665 31.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56ff78e9-d33c-47f2-addb-35ac973307fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56ff78e9-d33c-47f2-addb-35ac973307fe_0">
											<gml:posList>35.673769059126826 139.73788262072665 31.73 35.67376169494973 139.73785992847468 31.73 35.67376169494973 139.73785992847468 29.374 35.673769059126826 139.73788262072665 31.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5eaa8305-d777-4635-8e30-dbd8d9c57cad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5eaa8305-d777-4635-8e30-dbd8d9c57cad_0">
											<gml:posList>35.673781924610736 139.73787490583913 31 35.673789466306786 139.73787138399916 29.374 35.673789466306786 139.73787138399916 31 35.673781924610736 139.73787490583913 31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c658a13a-9660-459c-8c4b-ee78012c4a7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c658a13a-9660-459c-8c4b-ee78012c4a7f_0">
											<gml:posList>35.673781924610736 139.73787490583913 31 35.673781924610736 139.73787490583913 29.374 35.673789466306786 139.73787138399916 29.374 35.673781924610736 139.73787490583913 31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f72cf42a-07f9-44b6-83cf-fc8b4347cd11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f72cf42a-07f9-44b6-83cf-fc8b4347cd11_0">
											<gml:posList>35.67381841039691 139.73789540931733 34.851 35.67386589133485 139.73786842084115 29.374 35.67381841039691 139.73789540931733 29.374 35.67381841039691 139.73789540931733 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1285d8a1-fbc3-449d-9f2c-eb6572a7a6b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1285d8a1-fbc3-449d-9f2c-eb6572a7a6b8_0">
											<gml:posList>35.67381841039691 139.73789540931733 34.851 35.67386589133485 139.73786842084115 34.851 35.67386589133485 139.73786842084115 29.374 35.67381841039691 139.73789540931733 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0c7dcb9-60f7-449c-bee3-c3d90dd29bc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0c7dcb9-60f7-449c-bee3-c3d90dd29bc7_0">
											<gml:posList>35.67381841039691 139.73789540931733 34.851 35.6738119236618 139.7378766375952 29.374 35.6738119236618 139.7378766375952 34.851 35.67381841039691 139.73789540931733 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e6d770a-3511-4450-9e49-9ab9a1bf3f65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e6d770a-3511-4450-9e49-9ab9a1bf3f65_0">
											<gml:posList>35.67381841039691 139.73789540931733 34.851 35.67381841039691 139.73789540931733 29.374 35.6738119236618 139.7378766375952 29.374 35.67381841039691 139.73789540931733 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a6e8776-d8ae-4376-839a-a3f5e3b7b1c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a6e8776-d8ae-4376-839a-a3f5e3b7b1c8_0">
											<gml:posList>35.67376506041293 139.73789825660438 34.851 35.6738119236618 139.7378766375952 29.374 35.67376506041293 139.73789825660438 29.374 35.67376506041293 139.73789825660438 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bd32f58-1127-4279-885a-babb75e6785d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bd32f58-1127-4279-885a-babb75e6785d_0">
											<gml:posList>35.67376506041293 139.73789825660438 34.851 35.6738119236618 139.7378766375952 34.851 35.6738119236618 139.7378766375952 29.374 35.67376506041293 139.73789825660438 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d0dfbd0-7cce-454d-8fda-cbc08a071812">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d0dfbd0-7cce-454d-8fda-cbc08a071812_0">
											<gml:posList>35.673810439743825 139.7378808592137 31.004 35.673817007785594 139.7378998628204 34.851 35.673810439743825 139.7378808592137 34.851 35.673810439743825 139.7378808592137 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-592fca24-df29-4618-b554-4349630e6872">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-592fca24-df29-4618-b554-4349630e6872_0">
											<gml:posList>35.673810439743825 139.7378808592137 31.004 35.673817007785594 139.7378998628204 31.004 35.673817007785594 139.7378998628204 34.851 35.673810439743825 139.7378808592137 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bde02ae-3359-4339-b0b2-c7b0d1864708">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bde02ae-3359-4339-b0b2-c7b0d1864708_0">
											<gml:posList>35.673913211658096 139.7378548653674 31.004 35.673866849258644 139.737871534881 31.004 35.67392294454932 139.7378865358469 31.004 35.673913211658096 139.7378548653674 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80df1ec5-4e58-44dc-bf01-7b62cee1e155">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80df1ec5-4e58-44dc-bf01-7b62cee1e155_0">
											<gml:posList>35.67392294454932 139.7378865358469 31.004 35.673817007785594 139.7378998628204 31.004 35.67378403974852 139.73795062864224 31.004 35.67392294454932 139.7378865358469 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86c25c84-6050-4c2b-a57f-1fc8a1dde373">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86c25c84-6050-4c2b-a57f-1fc8a1dde373_0">
											<gml:posList>35.673817007785594 139.7378998628204 31.004 35.67376854124864 139.73790019668442 31.004 35.67378403974852 139.73795062864224 31.004 35.673817007785594 139.7378998628204 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c173cdf2-2603-4313-9610-bce2ae28484a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c173cdf2-2603-4313-9610-bce2ae28484a_0">
											<gml:posList>35.673817007785594 139.7378998628204 31.004 35.673810439743825 139.7378808592137 31.004 35.67376854124864 139.73790019668442 31.004 35.673817007785594 139.7378998628204 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56003519-530e-4dc9-a4c0-a7932fbc66db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56003519-530e-4dc9-a4c0-a7932fbc66db_0">
											<gml:posList>35.67392294454932 139.7378865358469 31.004 35.673866849258644 139.737871534881 31.004 35.673817007785594 139.7378998628204 31.004 35.67392294454932 139.7378865358469 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f2360d0-3880-4cf9-93fb-b5a95b035458">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f2360d0-3880-4cf9-93fb-b5a95b035458_0">
											<gml:posList>35.673782456712054 139.73795489456273 34.851 35.67392642537637 139.7378884648835 34.851 35.67378403974852 139.73795062864224 34.851 35.673782456712054 139.73795489456273 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52becf4c-5ea0-4d0e-8ce0-7e3335489a8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52becf4c-5ea0-4d0e-8ce0-7e3335489a8f_0">
											<gml:posList>35.67376506041293 139.73789825660438 34.851 35.673782456712054 139.73795489456273 34.851 35.67376854124864 139.73790019668442 34.851 35.67376506041293 139.73789825660438 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea9354f8-7844-4d15-9af5-0ea49b3e3de0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea9354f8-7844-4d15-9af5-0ea49b3e3de0_0">
											<gml:posList>35.67392642537637 139.7378884648835 34.851 35.67391485796219 139.73785082029755 34.851 35.67392294454932 139.7378865358469 34.851 35.67392642537637 139.7378884648835 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1b48c13-b0ee-4db1-8c35-a364393fe8c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1b48c13-b0ee-4db1-8c35-a364393fe8c5_0">
											<gml:posList>35.67376854124864 139.73790019668442 34.851 35.6738119236618 139.7378766375952 34.851 35.67376506041293 139.73789825660438 34.851 35.67376854124864 139.73790019668442 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97d2feb9-94fb-45c2-b50e-657d119e5fad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97d2feb9-94fb-45c2-b50e-657d119e5fad_0">
											<gml:posList>35.673913211658096 139.7378548653674 34.851 35.67391485796219 139.73785082029755 34.851 35.67386589133485 139.73786842084115 34.851 35.673913211658096 139.7378548653674 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29e8d760-1a7e-47bb-a88e-df4c13969c83">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29e8d760-1a7e-47bb-a88e-df4c13969c83_0">
											<gml:posList>35.673810439743825 139.7378808592137 34.851 35.67381841039691 139.73789540931733 34.851 35.6738119236618 139.7378766375952 34.851 35.673810439743825 139.7378808592137 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ae77aa0-411f-4462-98c1-24ae973aedd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ae77aa0-411f-4462-98c1-24ae973aedd1_0">
											<gml:posList>35.673866849258644 139.737871534881 34.851 35.67386589133485 139.73786842084115 34.851 35.67381841039691 139.73789540931733 34.851 35.673866849258644 139.737871534881 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fe5f6dd-ff9a-467f-8723-64b40d4a4e59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fe5f6dd-ff9a-467f-8723-64b40d4a4e59_0">
											<gml:posList>35.67392642537637 139.7378884648835 34.851 35.67392294454932 139.7378865358469 34.851 35.67378403974852 139.73795062864224 34.851 35.67392642537637 139.7378884648835 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dadfbda-ce3a-4f8e-af42-2150d36af304">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dadfbda-ce3a-4f8e-af42-2150d36af304_0">
											<gml:posList>35.67376854124864 139.73790019668442 34.851 35.673782456712054 139.73795489456273 34.851 35.67378403974852 139.73795062864224 34.851 35.67376854124864 139.73790019668442 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f226d154-acc1-47a8-9cff-46d0fe5ee35d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f226d154-acc1-47a8-9cff-46d0fe5ee35d_0">
											<gml:posList>35.67392294454932 139.7378865358469 34.851 35.67391485796219 139.73785082029755 34.851 35.673913211658096 139.7378548653674 34.851 35.67392294454932 139.7378865358469 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd756c01-f555-4151-900d-5042b0b6148f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd756c01-f555-4151-900d-5042b0b6148f_0">
											<gml:posList>35.67376854124864 139.73790019668442 34.851 35.673810439743825 139.7378808592137 34.851 35.6738119236618 139.7378766375952 34.851 35.67376854124864 139.73790019668442 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bac6c97f-db32-4394-b0d1-a741506507ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bac6c97f-db32-4394-b0d1-a741506507ef_0">
											<gml:posList>35.673913211658096 139.7378548653674 34.851 35.67386589133485 139.73786842084115 34.851 35.673866849258644 139.737871534881 34.851 35.673913211658096 139.7378548653674 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f006178-ef2d-4309-962f-e3b0e32ae320">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f006178-ef2d-4309-962f-e3b0e32ae320_0">
											<gml:posList>35.673810439743825 139.7378808592137 34.851 35.673817007785594 139.7378998628204 34.851 35.67381841039691 139.73789540931733 34.851 35.673810439743825 139.7378808592137 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-601acbf2-d8c8-484f-a52d-d32c00805fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-601acbf2-d8c8-484f-a52d-d32c00805fd5_0">
											<gml:posList>35.673817007785594 139.7378998628204 34.851 35.673866849258644 139.737871534881 34.851 35.67381841039691 139.73789540931733 34.851 35.673817007785594 139.7378998628204 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4599ba0a-6154-40dd-8307-83c230f98916">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4599ba0a-6154-40dd-8307-83c230f98916_0">
											<gml:posList>35.67376506041293 139.73789825660438 34.851 35.673782456712054 139.73795489456273 29.374 35.673782456712054 139.73795489456273 34.851 35.67376506041293 139.73789825660438 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e63467c3-a75e-43f2-9c27-5f082f58898a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e63467c3-a75e-43f2-9c27-5f082f58898a_0">
											<gml:posList>35.67376506041293 139.73789825660438 34.851 35.67376506041293 139.73789825660438 29.374 35.673782456712054 139.73795489456273 29.374 35.67376506041293 139.73789825660438 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8b1aa99-bf04-4c1a-8bdb-f129787ff0d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8b1aa99-bf04-4c1a-8bdb-f129787ff0d1_0">
											<gml:posList>35.67376854124864 139.73790019668442 31.004 35.67378403974852 139.73795062864224 34.851 35.67378403974852 139.73795062864224 31.004 35.67376854124864 139.73790019668442 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa692974-6596-4d1a-8fed-d251395944e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa692974-6596-4d1a-8fed-d251395944e0_0">
											<gml:posList>35.67376854124864 139.73790019668442 31.004 35.67376854124864 139.73790019668442 34.851 35.67378403974852 139.73795062864224 34.851 35.67376854124864 139.73790019668442 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99963f1c-ba46-46a9-9cb1-d87f05bd0ff6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99963f1c-ba46-46a9-9cb1-d87f05bd0ff6_0">
											<gml:posList>35.67378403974852 139.73795062864224 31.004 35.67392294454932 139.7378865358469 34.851 35.67392294454932 139.7378865358469 31.004 35.67378403974852 139.73795062864224 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cd247a4-e32a-447b-8038-dfdb9821cb4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cd247a4-e32a-447b-8038-dfdb9821cb4d_0">
											<gml:posList>35.67378403974852 139.73795062864224 31.004 35.67378403974852 139.73795062864224 34.851 35.67392294454932 139.7378865358469 34.851 35.67378403974852 139.73795062864224 31.004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61eee8c9-d749-4622-a61b-d6dd715c9a81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61eee8c9-d749-4622-a61b-d6dd715c9a81_0">
											<gml:posList>35.67392642537637 139.7378884648835 34.851 35.673782456712054 139.73795489456273 29.374 35.67392642537637 139.7378884648835 29.374 35.67392642537637 139.7378884648835 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-565b8624-04a9-4555-8e7d-fd6a7d729587">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-565b8624-04a9-4555-8e7d-fd6a7d729587_0">
											<gml:posList>35.67392642537637 139.7378884648835 34.851 35.673782456712054 139.73795489456273 34.851 35.673782456712054 139.73795489456273 29.374 35.67392642537637 139.7378884648835 34.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dd175d8-3633-4129-9cc3-82c4adb26401">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673769059126826 139.73788262072665 29.374 35.67376842560356 139.7378566506281 29.374 35.67377578978127 139.73787934288166 29.374 35.673769059126826 139.73788262072665 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68db7927-3497-45a5-ba87-9fe25d6c8c50">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673769059126826 139.73788262072665 29.374 35.67376169494973 139.73785992847468 29.374 35.67376842560356 139.7378566506281 29.374 35.673769059126826 139.73788262072665 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ce69b5a-7b29-4259-a010-18eeabce698b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67377578978127 139.73787934288166 31.73 35.673769059126826 139.73788262072665 29.374 35.67377578978127 139.73787934288166 29.374 35.67377578978127 139.73787934288166 31.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddcee215-c19f-4611-905a-0f26d002cd67">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67377578978127 139.73787934288166 31.73 35.673769059126826 139.73788262072665 31.73 35.673769059126826 139.73788262072665 29.374 35.67377578978127 139.73787934288166 31.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d799be18-b012-47b6-a382-8909222c9067">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673789466306786 139.73787138399916 29.374 35.673781924610736 139.73787490583913 29.374 35.673771324515926 139.7378408614035 29.374 35.673789466306786 139.73787138399916 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8eb8839-cfc8-49e3-aa37-c3fa613605ed">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67377886620224 139.73783732851408 29.374 35.673789466306786 139.73787138399916 29.374 35.673771324515926 139.7378408614035 29.374 35.67377886620224 139.73783732851408 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6cf9ea6-7478-494f-81cd-303e4606845c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67380354810546 139.73769262007883 29.374 35.6737899513729 139.7376988887485 29.374 35.67378417664691 139.7376800609658 29.374 35.67380354810546 139.73769262007883 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-845333e3-3d64-4171-bf30-94cfdbf91580">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67379776436479 139.73767379230415 29.374 35.67380354810546 139.73769262007883 29.374 35.67378417664691 139.7376800609658 29.374 35.67379776436479 139.73767379230415 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a6c9246-2acb-4e61-8b19-5ac5a574ba6e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67381951085168 139.73781682154825 35.526 35.67381371531505 139.73782854903632 35.526 35.67381128431633 139.73782059828542 35.526 35.67381951085168 139.73781682154825 35.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcea15ad-7e40-41aa-8f54-962fe2de50d5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67381951085168 139.73781682154825 35.526 35.67382194185065 139.73782477229983 35.526 35.67381371531505 139.73782854903632 35.526 35.67381951085168 139.73781682154825 35.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6563f957-64ea-4ce3-8069-4d7ede09a5e7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67391485796219 139.73785082029755 29.374 35.67392642537637 139.7378884648835 29.374 35.67386589133485 139.73786842084115 29.374 35.67391485796219 139.73785082029755 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5fdc607-2cc1-493d-86ab-d4e625735e42">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67392642537637 139.7378884648835 29.374 35.673782456712054 139.73795489456273 29.374 35.67381841039691 139.73789540931733 29.374 35.67392642537637 139.7378884648835 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a60d9e41-523b-4067-b3a3-f0891ade9216">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67381841039691 139.73789540931733 29.374 35.67376506041293 139.73789825660438 29.374 35.6738119236618 139.7378766375952 29.374 35.67381841039691 139.73789540931733 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8619cdf-b43a-41de-8d24-96816d94772b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67381841039691 139.73789540931733 29.374 35.673782456712054 139.73795489456273 29.374 35.67376506041293 139.73789825660438 29.374 35.67381841039691 139.73789540931733 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b841acd2-1158-4217-8923-c3b694c1f015">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67386589133485 139.73786842084115 29.374 35.67392642537637 139.7378884648835 29.374 35.67381841039691 139.73789540931733 29.374 35.67386589133485 139.73786842084115 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdf7aacf-0529-41ca-a713-fa5a2126e46d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67386300872775 139.73766624685578 29.374 35.67386709041424 139.73766431985223 29.374 35.673870208510586 139.73767484367445 29.374 35.67386300872775 139.73766624685578 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42a5fcff-3110-4667-8358-48dba74f694e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67385920376237 139.737653426133 29.374 35.67386300872775 139.73766624685578 29.374 35.67385498682639 139.73765529806465 29.374 35.67385920376237 139.737653426133 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e51b780f-d471-4d93-b838-c9ce41df77de">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67386612682392 139.73767677067755 29.374 35.67386942565859 139.73768787976167 29.374 35.67386520872209 139.73768975169173 29.374 35.67386612682392 139.73767677067755 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-194ad3cc-274b-4e99-b5ba-8c793211935c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67386300872775 139.73766624685578 29.374 35.673870208510586 139.73767484367445 29.374 35.67386612682392 139.73767677067755 29.374 35.67386300872775 139.73766624685578 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd9fb2d7-c568-4d24-aa84-e21fb6aa49a5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67385498682639 139.73765529806465 29.374 35.67386300872775 139.73766624685578 29.374 35.67386520872209 139.73768975169173 29.374 35.67385498682639 139.73765529806465 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2ce6ca4-8b01-4589-ac71-d706ee9c2f2a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67386300872775 139.73766624685578 29.374 35.67386612682392 139.73767677067755 29.374 35.67386520872209 139.73768975169173 29.374 35.67386300872775 139.73766624685578 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9205ae30-0349-4510-8929-9fc6c9048774">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67386091225569 139.7377276802718 29.374 35.67387975533694 139.73771051325735 29.374 35.67388205999297 139.73771826532104 29.374 35.67386091225569 139.7377276802718 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-925c2fbb-c099-4262-a59c-30efb9f8f81f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67386091225569 139.7377276802718 29.374 35.67385861662274 139.73771993924586 29.374 35.67387975533694 139.73771051325735 29.374 35.67386091225569 139.7377276802718 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54e4f573-1fa0-46b0-901a-39030336eedd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67386709041424 139.73766431985223 30.186 35.673874902901765 139.7376726287248 30.186 35.673870208510586 139.73767484367445 30.186 35.67386709041424 139.73766431985223 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbed3d1e-bb0e-4e34-ad69-22bb84365778">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67386709041424 139.73766431985223 30.186 35.67387178480522 139.73766210490206 30.186 35.673874902901765 139.7376726287248 30.186 35.67386709041424 139.73766431985223 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1b244f68-d038-4a8a-b559-7833b3808a10_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bafe432-b68c-4e30-aa29-29d70c33661c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67379093487153 139.7379729127379 23.692 35.67379902568711 139.73797986255377 23.692 35.673798160917634 139.7379919376584 23.692 35.67378918729655 139.73799705191928 23.692 35.673781096473206 139.73799009105576 23.692 35.67378196125125 139.73797802700042 23.692 35.67379093487153 139.7379729127379 23.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93f191d9-9e03-4fcb-b749-a55cbc0b6467">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673782042641456 139.7379442239162 29.374 35.67376948191463 139.73790428285332 29.374 35.673801288462634 139.73788926562506 29.374 35.673813849194396 139.7379292067014 29.374 35.673782042641456 139.7379442239162 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed72d2e5-4497-4b88-9183-a00c3c1ac9dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed72d2e5-4497-4b88-9183-a00c3c1ac9dd_0">
											<gml:posList>35.67376948191463 139.73790428285332 32.38 35.67376948191463 139.73790428285332 29.374 35.673782042641456 139.7379442239162 29.374 35.673782042641456 139.7379442239162 32.38 35.67376948191463 139.73790428285332 32.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a31c428a-1b31-428c-a6c3-f65d94fe9125">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a31c428a-1b31-428c-a6c3-f65d94fe9125_0">
											<gml:posList>35.673781096473206 139.73799009105576 25.357 35.67378196125125 139.73797802700042 25.357 35.67378196125125 139.73797802700042 23.692 35.673781096473206 139.73799009105576 23.692 35.673781096473206 139.73799009105576 25.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b892c6b7-14e4-4964-ae0b-968ff181fac7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b892c6b7-14e4-4964-ae0b-968ff181fac7_0">
											<gml:posList>35.67378918729655 139.73799705191928 25.357 35.673781096473206 139.73799009105576 25.357 35.673781096473206 139.73799009105576 23.692 35.67378918729655 139.73799705191928 23.692 35.67378918729655 139.73799705191928 25.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75c37df1-b4f4-45c2-ad37-c540d9f63df3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75c37df1-b4f4-45c2-ad37-c540d9f63df3_0">
											<gml:posList>35.67376948191463 139.73790428285332 32.38 35.673801288462634 139.73788926562506 32.38 35.673801288462634 139.73788926562506 29.374 35.67376948191463 139.73790428285332 29.374 35.67376948191463 139.73790428285332 32.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dec6f6a-148a-4788-8731-0c063b9dd112">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dec6f6a-148a-4788-8731-0c063b9dd112_0">
											<gml:posList>35.67379093487153 139.7379729127379 23.692 35.67378196125125 139.73797802700042 23.692 35.67378196125125 139.73797802700042 25.357 35.67379093487153 139.7379729127379 25.357 35.67379093487153 139.7379729127379 23.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a386e21-49ea-46c1-b758-0a064bd8fd7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a386e21-49ea-46c1-b758-0a064bd8fd7b_0">
											<gml:posList>35.67378196125125 139.73797802700042 25.357 35.673781096473206 139.73799009105576 25.357 35.67378918729655 139.73799705191928 25.357 35.673798160917634 139.7379919376584 25.357 35.67379902568711 139.73797986255377 25.357 35.67379093487153 139.7379729127379 25.357 35.67378196125125 139.73797802700042 25.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3adc5ba-65ea-4e4a-948b-6dd6cfa8a125">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3adc5ba-65ea-4e4a-948b-6dd6cfa8a125_0">
											<gml:posList>35.673801288462634 139.73788926562506 32.38 35.67376948191463 139.73790428285332 32.38 35.673782042641456 139.7379442239162 32.38 35.673813849194396 139.7379292067014 32.38 35.673801288462634 139.73788926562506 32.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ccfd735-a990-4179-b3b6-76dc02485a88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ccfd735-a990-4179-b3b6-76dc02485a88_0">
											<gml:posList>35.673798160917634 139.7379919376584 25.357 35.67378918729655 139.73799705191928 25.357 35.67378918729655 139.73799705191928 23.692 35.673798160917634 139.7379919376584 23.692 35.673798160917634 139.7379919376584 25.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9fe0efb-8704-4278-b9d3-209e9c012d80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9fe0efb-8704-4278-b9d3-209e9c012d80_0">
											<gml:posList>35.67379093487153 139.7379729127379 25.357 35.67379902568711 139.73797986255377 25.357 35.67379902568711 139.73797986255377 23.692 35.67379093487153 139.7379729127379 23.692 35.67379093487153 139.7379729127379 25.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26f95e10-0947-447d-a387-29e315ee6fb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26f95e10-0947-447d-a387-29e315ee6fb3_0">
											<gml:posList>35.673782042641456 139.7379442239162 32.38 35.673782042641456 139.7379442239162 29.374 35.673813849194396 139.7379292067014 29.374 35.673813849194396 139.7379292067014 32.38 35.673782042641456 139.7379442239162 32.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2e17465-09ec-4614-b6a3-d1281f84cd10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2e17465-09ec-4614-b6a3-d1281f84cd10_0">
											<gml:posList>35.67379902568711 139.73797986255377 25.357 35.673798160917634 139.7379919376584 25.357 35.673798160917634 139.7379919376584 23.692 35.67379902568711 139.73797986255377 23.692 35.67379902568711 139.73797986255377 25.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2246ecc-ebe4-4201-92b9-5a7c649a8778">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2246ecc-ebe4-4201-92b9-5a7c649a8778_0">
											<gml:posList>35.673801288462634 139.73788926562506 32.38 35.673813849194396 139.7379292067014 32.38 35.673813849194396 139.7379292067014 29.374 35.673801288462634 139.73788926562506 29.374 35.673801288462634 139.73788926562506 32.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7d02c88d-3f12-4efe-9acf-0af6d07fd060">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d02c88d-3f12-4efe-9acf-0af6d07fd060">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d02c88d-3f12-4efe-9acf-0af6d07fd060">
											<gml:posList>35.673796501106146 139.73774020675157 8.98 35.67375981046414 139.73762072493963 8.98 35.673848655411334 139.73758250762387 8.98 35.67394174594168 139.73789634506937 8.98 35.67384983903275 139.73793810068167 8.98 35.673864394951316 139.7379934275245 8.98 35.67378609452316 139.73802986438082 8.98 35.67372400257625 139.7378182830425 8.98 35.6737981588227 139.73778461262992 8.98 35.6737860489656 139.73774496930812 8.98 35.673796501106146 139.73774020675157 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a65200a7-58b7-4745-b922-50130023f7b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a65200a7-58b7-4745-b922-50130023f7b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a65200a7-58b7-4745-b922-50130023f7b5">
											<gml:posList>35.67375981046414 139.73762072493963 23.686 35.673765771244284 139.7376241312612 23.686 35.67384588486996 139.7375896581716 23.686 35.673848655411334 139.73758250762387 23.686 35.67375981046414 139.73762072493963 23.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3aaddfe8-c79c-4234-8437-2313c1a331fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3aaddfe8-c79c-4234-8437-2313c1a331fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3aaddfe8-c79c-4234-8437-2313c1a331fb">
											<gml:posList>35.67384588486996 139.7375896581716 23.686 35.67385998381 139.73763686614083 23.686 35.67386419163538 139.73763487270483 23.686 35.673848655411334 139.73758250762387 23.686 35.67384588486996 139.7375896581716 23.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8ee965c-a359-4e63-8c52-09f1eb4aedba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8ee965c-a359-4e63-8c52-09f1eb4aedba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8ee965c-a359-4e63-8c52-09f1eb4aedba">
											<gml:posList>35.67378117938905 139.73767414349595 23.357 35.67385998381 139.73763686614083 23.357 35.67384588486996 139.7375896581716 23.357 35.673765771244284 139.7376241312612 23.357 35.67378117938905 139.73767414349595 23.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc1b58ec-2db9-46ab-a22a-f0861b33909f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc1b58ec-2db9-46ab-a22a-f0861b33909f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc1b58ec-2db9-46ab-a22a-f0861b33909f">
											<gml:posList>35.673765771244284 139.7376241312612 23.686 35.67375981046414 139.73762072493963 23.686 35.67377684541481 139.73767619231197 23.686 35.67378117938905 139.73767414349595 23.686 35.673765771244284 139.7376241312612 23.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7debfb40-3149-46d9-bc50-9b5863a1d7c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7debfb40-3149-46d9-bc50-9b5863a1d7c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7debfb40-3149-46d9-bc50-9b5863a1d7c3">
											<gml:posList>35.67377684541481 139.73767619231197 30.186 35.673783879203036 139.73768007236743 30.186 35.67386094461932 139.73764360350452 30.186 35.67386419163538 139.73763487270483 30.186 35.67377684541481 139.73767619231197 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2663f214-88d5-49a4-bfa9-b4060a5e10c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2663f214-88d5-49a4-bfa9-b4060a5e10c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2663f214-88d5-49a4-bfa9-b4060a5e10c9">
											<gml:posList>35.673796501106146 139.73774020675157 30.186 35.67380075146722 139.73773502076676 30.186 35.673783879203036 139.73768007236743 30.186 35.67377684541481 139.73767619231197 30.186 35.673796501106146 139.73774020675157 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2e3ea0d-f680-4ba2-89ee-41810a89cf63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2e3ea0d-f680-4ba2-89ee-41810a89cf63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2e3ea0d-f680-4ba2-89ee-41810a89cf63">
											<gml:posList>35.673796501106146 139.73774020675157 30.186 35.6737860489656 139.73774496930812 30.186 35.67378710631533 139.73774842567343 30.186 35.67380266735671 139.73774129302515 30.186 35.67380075146722 139.73773502076676 30.186 35.673796501106146 139.73774020675157 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0637bea6-e8dc-49bd-bf46-df5f6d089c3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0637bea6-e8dc-49bd-bf46-df5f6d089c3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0637bea6-e8dc-49bd-bf46-df5f6d089c3d">
											<gml:posList>35.67386419163538 139.73763487270483 30.186 35.67386094461932 139.73764360350452 30.186 35.6739347301092 139.73789236554518 30.186 35.67394174594168 139.73789634506937 30.186 35.67386419163538 139.73763487270483 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d654397b-ae19-4b89-9a94-1b09670a71b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d654397b-ae19-4b89-9a94-1b09670a71b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d654397b-ae19-4b89-9a94-1b09670a71b9">
											<gml:posList>35.673809542323184 139.73773813650888 34.255 35.67378710631533 139.73774842567343 34.255 35.67380406012753 139.73780394842223 34.255 35.67382636999188 139.737793714655 34.255 35.673809542323184 139.73773813650888 34.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cec38973-0c2d-4247-860b-80d37ed9e586">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cec38973-0c2d-4247-860b-80d37ed9e586">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cec38973-0c2d-4247-860b-80d37ed9e586">
											<gml:posList>35.67379783391031 139.7378068058979 35.526 35.673802775618114 139.73780956169207 35.526 35.67382971685056 139.7377972014345 35.526 35.6738319744902 139.73779114513337 35.526 35.67379783391031 139.7378068058979 35.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8be3c39-b0f1-416c-aebc-4fbbf3773f2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8be3c39-b0f1-416c-aebc-4fbbf3773f2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8be3c39-b0f1-416c-aebc-4fbbf3773f2a">
											<gml:posList>35.67373099137026 139.73782226258197 30.186 35.6738000747096 139.73779088488928 30.186 35.6737981588227 139.73778461262992 30.186 35.67372400257625 139.7378182830425 30.186 35.67373099137026 139.73782226258197 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0201ba1-9db8-4b0d-8283-e2ff45566a7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0201ba1-9db8-4b0d-8283-e2ff45566a7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0201ba1-9db8-4b0d-8283-e2ff45566a7a">
											<gml:posList>35.6739347301092 139.73789236554518 29.374 35.67386094461932 139.73764360350452 29.374 35.673783879203036 139.73768007236743 29.374 35.67380075146722 139.73773502076676 29.374 35.67380266735671 139.73774129302515 29.374 35.673809542323184 139.73773813650888 29.374 35.67382636999188 139.737793714655 29.374 35.6738319744902 139.73779114513337 29.374 35.673852751018394 139.73785919036953 29.374 35.673818610429734 139.73787485110918 29.374 35.67379783391031 139.7378068058979 29.374 35.67380406012753 139.73780394842223 29.374 35.6738000747096 139.73779088488928 29.374 35.67373099137026 139.73782226258197 29.374 35.67377285600847 139.73796490327268 29.374 35.673847923136016 139.73793180632143 29.374 35.6739347301092 139.73789236554518 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08564f3a-30b1-407d-98be-cfe9d90498ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08564f3a-30b1-407d-98be-cfe9d90498ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08564f3a-30b1-407d-98be-cfe9d90498ec">
											<gml:posList>35.6738319744902 139.73779114513337 35.526 35.67382971685056 139.7377972014345 35.526 35.67384780931175 139.73785643457057 35.526 35.673852751018394 139.73785919036953 35.526 35.6738319744902 139.73779114513337 35.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-605e712e-fe19-479a-99bd-e2fdaabb3738">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-605e712e-fe19-479a-99bd-e2fdaabb3738">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-605e712e-fe19-479a-99bd-e2fdaabb3738">
											<gml:posList>35.67384780931175 139.73785643457057 35.526 35.67382971685056 139.7377972014345 35.526 35.673802775618114 139.73780956169207 35.526 35.673820868073285 139.73786879481108 35.526 35.67384780931175 139.73785643457057 35.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-959776db-636a-46d4-bf58-8f38bcb959fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-959776db-636a-46d4-bf58-8f38bcb959fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-959776db-636a-46d4-bf58-8f38bcb959fd">
											<gml:posList>35.673818610429734 139.73787485110918 35.526 35.673820868073285 139.73786879481108 35.526 35.673802775618114 139.73780956169207 35.526 35.67379783391031 139.7378068058979 35.526 35.673818610429734 139.73787485110918 35.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45a8b57c-220e-4d40-9016-d7e1036306e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45a8b57c-220e-4d40-9016-d7e1036306e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45a8b57c-220e-4d40-9016-d7e1036306e3">
											<gml:posList>35.673852751018394 139.73785919036953 35.526 35.67384780931175 139.73785643457057 35.526 35.673820868073285 139.73786879481108 35.526 35.673818610429734 139.73787485110918 35.526 35.673852751018394 139.73785919036953 35.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef3dd19a-adeb-4268-a5fb-36e7ff781c46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef3dd19a-adeb-4268-a5fb-36e7ff781c46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef3dd19a-adeb-4268-a5fb-36e7ff781c46">
											<gml:posList>35.673769554772356 139.73797349050614 30.186 35.67377285600847 139.73796490327268 30.186 35.67373099137026 139.73782226258197 30.186 35.67372400257625 139.7378182830425 30.186 35.673769554772356 139.73797349050614 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c44146cb-dc7b-41b9-b43b-8eb96231e7a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c44146cb-dc7b-41b9-b43b-8eb96231e7a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c44146cb-dc7b-41b9-b43b-8eb96231e7a6">
											<gml:posList>35.67384983903275 139.73793810068167 30.186 35.67394174594168 139.73789634506937 30.186 35.6739347301092 139.73789236554518 30.186 35.673847923136016 139.73793180632143 30.186 35.67384983903275 139.73793810068167 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9613ead-fe46-4044-a51f-ef9d0221fcd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9613ead-fe46-4044-a51f-ef9d0221fcd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9613ead-fe46-4044-a51f-ef9d0221fcd8">
											<gml:posList>35.67384983903275 139.73793810068167 30.186 35.673847923136016 139.73793180632143 30.186 35.67377285600847 139.73796490327268 30.186 35.673769554772356 139.73797349050614 30.186 35.67384983903275 139.73793810068167 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-138c367b-e677-4e6e-83be-1436a8e47db0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-138c367b-e677-4e6e-83be-1436a8e47db0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-138c367b-e677-4e6e-83be-1436a8e47db0">
											<gml:posList>35.67385846113534 139.7379899106718 24.251 35.673864394951316 139.7379934275245 24.251 35.67384983903275 139.73793810068167 24.251 35.67384518957395 139.7379401498606 24.251 35.67385846113534 139.7379899106718 24.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5958eec-f5a1-41f1-9d7c-c6a20e178e61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5958eec-f5a1-41f1-9d7c-c6a20e178e61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5958eec-f5a1-41f1-9d7c-c6a20e178e61">
											<gml:posList>35.67385846113534 139.7379899106718 23.692 35.67384518957395 139.7379401498606 23.692 35.67377406006481 139.73797150778296 23.692 35.673788945855655 139.7380222608417 23.692 35.67385846113534 139.7379899106718 23.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e494e394-2b1b-43a3-97a2-9b9e885a57b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e494e394-2b1b-43a3-97a2-9b9e885a57b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e494e394-2b1b-43a3-97a2-9b9e885a57b2">
											<gml:posList>35.673788945855655 139.7380222608417 24.251 35.67377406006481 139.73797150778296 24.251 35.673769554772356 139.73797349050614 24.251 35.67378609452316 139.73802986438082 24.251 35.673788945855655 139.7380222608417 24.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d599b0b3-3158-481f-a275-e6c4aee04105">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d599b0b3-3158-481f-a275-e6c4aee04105">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d599b0b3-3158-481f-a275-e6c4aee04105">
											<gml:posList>35.673864394951316 139.7379934275245 24.251 35.67385846113534 139.7379899106718 24.251 35.673788945855655 139.7380222608417 24.251 35.67378609452316 139.73802986438082 24.251 35.673864394951316 139.7379934275245 24.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f0024778-4815-47e6-912c-663b5678e256">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0024778-4815-47e6-912c-663b5678e256">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0024778-4815-47e6-912c-663b5678e256">
											<gml:posList>35.673848655411334 139.73758250762387 8.98 35.67375981046414 139.73762072493963 8.98 35.67375981046414 139.73762072493963 23.686 35.673848655411334 139.73758250762387 23.686 35.673848655411334 139.73758250762387 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d2e9258-9841-4be1-80bb-84c394e3dccf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d2e9258-9841-4be1-80bb-84c394e3dccf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d2e9258-9841-4be1-80bb-84c394e3dccf">
											<gml:posList>35.673765771244284 139.7376241312612 23.686 35.673765771244284 139.7376241312612 23.357 35.67384588486996 139.7375896581716 23.357 35.67384588486996 139.7375896581716 23.686 35.673765771244284 139.7376241312612 23.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44d28c04-b413-469f-adb2-227eafc14a5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44d28c04-b413-469f-adb2-227eafc14a5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44d28c04-b413-469f-adb2-227eafc14a5a">
											<gml:posList>35.67384588486996 139.7375896581716 23.686 35.67384588486996 139.7375896581716 23.357 35.67385998381 139.73763686614083 23.357 35.67385998381 139.73763686614083 23.686 35.67384588486996 139.7375896581716 23.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8303338-eba8-42ff-916e-168f706b1d0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8303338-eba8-42ff-916e-168f706b1d0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8303338-eba8-42ff-916e-168f706b1d0e">
											<gml:posList>35.67378117938905 139.73767414349595 23.686 35.67378117938905 139.73767414349595 23.357 35.673765771244284 139.7376241312612 23.357 35.673765771244284 139.7376241312612 23.686 35.67378117938905 139.73767414349595 23.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df19f1db-3151-4d2d-9034-2195dcab6897">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df19f1db-3151-4d2d-9034-2195dcab6897">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df19f1db-3151-4d2d-9034-2195dcab6897">
											<gml:posList>35.67377684541481 139.73767619231197 30.186 35.67386419163538 139.73763487270483 30.186 35.67386419163538 139.73763487270483 23.686 35.67385998381 139.73763686614083 23.686 35.67385998381 139.73763686614083 23.357 35.67378117938905 139.73767414349595 23.357 35.67378117938905 139.73767414349595 23.686 35.67377684541481 139.73767619231197 23.686 35.67377684541481 139.73767619231197 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb21800b-c59a-492a-9998-e79e81dcda02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb21800b-c59a-492a-9998-e79e81dcda02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb21800b-c59a-492a-9998-e79e81dcda02">
											<gml:posList>35.673783879203036 139.73768007236743 30.186 35.673783879203036 139.73768007236743 29.374 35.67386094461932 139.73764360350452 29.374 35.67386094461932 139.73764360350452 30.186 35.673783879203036 139.73768007236743 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b893c43-50d2-4bf8-8d82-0a9da999aac0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b893c43-50d2-4bf8-8d82-0a9da999aac0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b893c43-50d2-4bf8-8d82-0a9da999aac0">
											<gml:posList>35.67377684541481 139.73767619231197 23.686 35.67375981046414 139.73762072493963 23.686 35.67375981046414 139.73762072493963 8.98 35.673796501106146 139.73774020675157 8.98 35.673796501106146 139.73774020675157 30.186 35.67377684541481 139.73767619231197 30.186 35.67377684541481 139.73767619231197 23.686</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67a59aea-4833-40d6-afe6-e1bd25c267b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67a59aea-4833-40d6-afe6-e1bd25c267b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67a59aea-4833-40d6-afe6-e1bd25c267b4">
											<gml:posList>35.67380075146722 139.73773502076676 30.186 35.67380075146722 139.73773502076676 29.374 35.673783879203036 139.73768007236743 29.374 35.673783879203036 139.73768007236743 30.186 35.67380075146722 139.73773502076676 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-575baa4e-2070-45c2-a08b-aa2014dc28fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-575baa4e-2070-45c2-a08b-aa2014dc28fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-575baa4e-2070-45c2-a08b-aa2014dc28fd">
											<gml:posList>35.67380266735671 139.73774129302515 30.186 35.67380266735671 139.73774129302515 29.374 35.67380075146722 139.73773502076676 29.374 35.67380075146722 139.73773502076676 30.186 35.67380266735671 139.73774129302515 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29199d9c-5a30-4b3d-b4fc-35fc51780062">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29199d9c-5a30-4b3d-b4fc-35fc51780062">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29199d9c-5a30-4b3d-b4fc-35fc51780062">
											<gml:posList>35.673848655411334 139.73758250762387 8.98 35.673848655411334 139.73758250762387 23.686 35.67386419163538 139.73763487270483 23.686 35.67386419163538 139.73763487270483 30.186 35.67394174594168 139.73789634506937 30.186 35.67394174594168 139.73789634506937 8.98 35.673848655411334 139.73758250762387 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c52c5386-7300-4378-9427-8a2aab1501eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c52c5386-7300-4378-9427-8a2aab1501eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c52c5386-7300-4378-9427-8a2aab1501eb">
											<gml:posList>35.673796501106146 139.73774020675157 8.98 35.6737860489656 139.73774496930812 8.98 35.6737860489656 139.73774496930812 30.186 35.673796501106146 139.73774020675157 30.186 35.673796501106146 139.73774020675157 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58d25e92-2dbb-4972-bdc8-2f63d9576acc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58d25e92-2dbb-4972-bdc8-2f63d9576acc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58d25e92-2dbb-4972-bdc8-2f63d9576acc">
											<gml:posList>35.67380266735671 139.73774129302515 30.186 35.67378710631533 139.73774842567343 30.186 35.67378710631533 139.73774842567343 34.255 35.673809542323184 139.73773813650888 34.255 35.673809542323184 139.73773813650888 29.374 35.67380266735671 139.73774129302515 29.374 35.67380266735671 139.73774129302515 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de256013-5e03-4cc2-9bf8-1ca2dc181c83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de256013-5e03-4cc2-9bf8-1ca2dc181c83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de256013-5e03-4cc2-9bf8-1ca2dc181c83">
											<gml:posList>35.673809542323184 139.73773813650888 34.255 35.67382636999188 139.737793714655 34.255 35.67382636999188 139.737793714655 29.374 35.673809542323184 139.73773813650888 29.374 35.673809542323184 139.73773813650888 34.255</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba27bc15-5ea8-4c53-8a33-03bc231b5cd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba27bc15-5ea8-4c53-8a33-03bc231b5cd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba27bc15-5ea8-4c53-8a33-03bc231b5cd0">
											<gml:posList>35.67386094461932 139.73764360350452 30.186 35.67386094461932 139.73764360350452 29.374 35.6739347301092 139.73789236554518 29.374 35.6739347301092 139.73789236554518 30.186 35.67386094461932 139.73764360350452 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-666ae572-f348-42e7-81c5-73a5c1332b13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-666ae572-f348-42e7-81c5-73a5c1332b13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-666ae572-f348-42e7-81c5-73a5c1332b13">
											<gml:posList>35.67380406012753 139.73780394842223 29.374 35.67380406012753 139.73780394842223 34.255 35.67378710631533 139.73774842567343 34.255 35.67378710631533 139.73774842567343 30.186 35.6737860489656 139.73774496930812 30.186 35.6737860489656 139.73774496930812 8.98 35.6737981588227 139.73778461262992 8.98 35.6737981588227 139.73778461262992 30.186 35.6738000747096 139.73779088488928 30.186 35.6738000747096 139.73779088488928 29.374 35.67380406012753 139.73780394842223 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43bf9669-5b69-4358-9f51-7c2d77b39418">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43bf9669-5b69-4358-9f51-7c2d77b39418">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43bf9669-5b69-4358-9f51-7c2d77b39418">
											<gml:posList>35.6738319744902 139.73779114513337 35.526 35.6738319744902 139.73779114513337 29.374 35.67382636999188 139.737793714655 29.374 35.67382636999188 139.737793714655 34.255 35.67380406012753 139.73780394842223 34.255 35.67380406012753 139.73780394842223 29.374 35.67379783391031 139.7378068058979 29.374 35.67379783391031 139.7378068058979 35.526 35.6738319744902 139.73779114513337 35.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86db31c9-5f61-40f9-b77d-4377a7b5ddd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86db31c9-5f61-40f9-b77d-4377a7b5ddd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86db31c9-5f61-40f9-b77d-4377a7b5ddd7">
											<gml:posList>35.6737981588227 139.73778461262992 8.98 35.67372400257625 139.7378182830425 8.98 35.67372400257625 139.7378182830425 30.186 35.6737981588227 139.73778461262992 30.186 35.6737981588227 139.73778461262992 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33523739-e7ea-4628-ad49-60bb7b0e83ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33523739-e7ea-4628-ad49-60bb7b0e83ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33523739-e7ea-4628-ad49-60bb7b0e83ee">
											<gml:posList>35.67373099137026 139.73782226258197 30.186 35.67373099137026 139.73782226258197 29.374 35.6738000747096 139.73779088488928 29.374 35.6738000747096 139.73779088488928 30.186 35.67373099137026 139.73782226258197 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5057bdc5-b73e-4e68-9a1e-b03f23a4dd68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5057bdc5-b73e-4e68-9a1e-b03f23a4dd68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5057bdc5-b73e-4e68-9a1e-b03f23a4dd68">
											<gml:posList>35.6738319744902 139.73779114513337 35.526 35.673852751018394 139.73785919036953 35.526 35.673852751018394 139.73785919036953 29.374 35.6738319744902 139.73779114513337 29.374 35.6738319744902 139.73779114513337 35.526</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83eb662c-8539-4078-b8a4-3ee1f8f386f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83eb662c-8539-4078-b8a4-3ee1f8f386f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83eb662c-8539-4078-b8a4-3ee1f8f386f5">
											<gml:posList>35.67379783391031 139.7378068058979 29.374 35.673818610429734 139.73787485110918 29.374 35.673818610429734 139.73787485110918 35.526 35.67379783391031 139.7378068058979 35.526 35.67379783391031 139.7378068058979 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ad500c9-8fc2-4b94-a67d-c80684096c36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ad500c9-8fc2-4b94-a67d-c80684096c36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ad500c9-8fc2-4b94-a67d-c80684096c36">
											<gml:posList>35.673818610429734 139.73787485110918 29.374 35.673852751018394 139.73785919036953 29.374 35.673852751018394 139.73785919036953 35.526 35.673818610429734 139.73787485110918 35.526 35.673818610429734 139.73787485110918 29.374</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d78a438-afab-4485-80bf-b4cdc69606ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d78a438-afab-4485-80bf-b4cdc69606ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d78a438-afab-4485-80bf-b4cdc69606ad">
											<gml:posList>35.67377285600847 139.73796490327268 30.186 35.67377285600847 139.73796490327268 29.374 35.67373099137026 139.73782226258197 29.374 35.67373099137026 139.73782226258197 30.186 35.67377285600847 139.73796490327268 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1b01511-b624-478a-bcf7-90bf2a721c58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1b01511-b624-478a-bcf7-90bf2a721c58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1b01511-b624-478a-bcf7-90bf2a721c58">
											<gml:posList>35.6739347301092 139.73789236554518 30.186 35.6739347301092 139.73789236554518 29.374 35.673847923136016 139.73793180632143 29.374 35.673847923136016 139.73793180632143 30.186 35.6739347301092 139.73789236554518 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f16fd098-a654-42f4-bd8a-4a939094d609">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f16fd098-a654-42f4-bd8a-4a939094d609">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f16fd098-a654-42f4-bd8a-4a939094d609">
											<gml:posList>35.67394174594168 139.73789634506937 30.186 35.67384983903275 139.73793810068167 30.186 35.67384983903275 139.73793810068167 24.251 35.67384983903275 139.73793810068167 8.98 35.67394174594168 139.73789634506937 8.98 35.67394174594168 139.73789634506937 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a49dd51-164e-460c-be11-a6473d38d564">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a49dd51-164e-460c-be11-a6473d38d564">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a49dd51-164e-460c-be11-a6473d38d564">
											<gml:posList>35.67378609452316 139.73802986438082 8.98 35.67378609452316 139.73802986438082 24.251 35.673769554772356 139.73797349050614 24.251 35.673769554772356 139.73797349050614 30.186 35.67372400257625 139.7378182830425 30.186 35.67372400257625 139.7378182830425 8.98 35.67378609452316 139.73802986438082 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32a0a7d9-b081-4ff9-897b-edcce6ff9710">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32a0a7d9-b081-4ff9-897b-edcce6ff9710">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32a0a7d9-b081-4ff9-897b-edcce6ff9710">
											<gml:posList>35.673847923136016 139.73793180632143 30.186 35.673847923136016 139.73793180632143 29.374 35.67377285600847 139.73796490327268 29.374 35.67377285600847 139.73796490327268 30.186 35.673847923136016 139.73793180632143 30.186</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edd85fa2-3d90-46e0-ab1a-2449f49aba22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edd85fa2-3d90-46e0-ab1a-2449f49aba22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edd85fa2-3d90-46e0-ab1a-2449f49aba22">
											<gml:posList>35.67377406006481 139.73797150778296 24.251 35.67377406006481 139.73797150778296 23.692 35.67384518957395 139.7379401498606 23.692 35.67384518957395 139.7379401498606 24.251 35.67384983903275 139.73793810068167 24.251 35.67384983903275 139.73793810068167 30.186 35.673769554772356 139.73797349050614 30.186 35.673769554772356 139.73797349050614 24.251 35.67377406006481 139.73797150778296 24.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16d77788-0fce-40f6-9a82-fe6d4ed7cdc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16d77788-0fce-40f6-9a82-fe6d4ed7cdc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16d77788-0fce-40f6-9a82-fe6d4ed7cdc9">
											<gml:posList>35.67384518957395 139.7379401498606 24.251 35.67384518957395 139.7379401498606 23.692 35.67385846113534 139.7379899106718 23.692 35.67385846113534 139.7379899106718 24.251 35.67384518957395 139.7379401498606 24.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0c44a56-3816-42b5-997e-1b457b6472a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0c44a56-3816-42b5-997e-1b457b6472a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0c44a56-3816-42b5-997e-1b457b6472a5">
											<gml:posList>35.67384983903275 139.73793810068167 24.251 35.673864394951316 139.7379934275245 24.251 35.673864394951316 139.7379934275245 8.98 35.67384983903275 139.73793810068167 8.98 35.67384983903275 139.73793810068167 24.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b91836d-c42e-435a-838a-73e54680e6c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b91836d-c42e-435a-838a-73e54680e6c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b91836d-c42e-435a-838a-73e54680e6c0">
											<gml:posList>35.673788945855655 139.7380222608417 24.251 35.673788945855655 139.7380222608417 23.692 35.67377406006481 139.73797150778296 23.692 35.67377406006481 139.73797150778296 24.251 35.673788945855655 139.7380222608417 24.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7714f17-9bd5-4a79-9437-425a4b7c7a2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7714f17-9bd5-4a79-9437-425a4b7c7a2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7714f17-9bd5-4a79-9437-425a4b7c7a2c">
											<gml:posList>35.67385846113534 139.7379899106718 24.251 35.67385846113534 139.7379899106718 23.692 35.673788945855655 139.7380222608417 23.692 35.673788945855655 139.7380222608417 24.251 35.67385846113534 139.7379899106718 24.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8a3f567-f111-484c-bc57-fba9e223723c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8a3f567-f111-484c-bc57-fba9e223723c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8a3f567-f111-484c-bc57-fba9e223723c">
											<gml:posList>35.67378609452316 139.73802986438082 8.98 35.673864394951316 139.7379934275245 8.98 35.673864394951316 139.7379934275245 24.251 35.67378609452316 139.73802986438082 24.251 35.67378609452316 139.73802986438082 8.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9098</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">518.0313</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>