<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1b3569ef-7863-4e25-add1-fa042a6d45c4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>霞が関三丁目南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:measuredHeight uom="m">23.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671178001791326 139.7474116638636 0 35.671195019596226 139.74738623896957 0 35.67106007905528 139.7472530541341 0 35.671041980183915 139.74727925341844 0 35.671019158962196 139.7472561910453 0 35.6710040319347 139.74727863136826 0 35.671174875200265 139.74745121321746 0 35.671191983071985 139.74742567777258 0 35.671178001791326 139.7474116638636 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671178001791326 139.7474116638636 7.4 35.671191983071985 139.74742567777258 7.4 35.671174875200265 139.74745121321746 7.4 35.6710040319347 139.74727863136826 7.4 35.671019158962196 139.7472561910453 7.4 35.671041980183915 139.74727925341844 7.4 35.67106007905528 139.7472530541341 7.4 35.671195019596226 139.74738623896957 7.4 35.671178001791326 139.7474116638636 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671178001791326 139.7474116638636 7.4 35.671195019596226 139.74738623896957 7.4 35.671195019596226 139.74738623896957 31.339999999999996 35.671178001791326 139.7474116638636 31.339999999999996 35.671178001791326 139.7474116638636 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671195019596226 139.74738623896957 7.4 35.67106007905528 139.7472530541341 7.4 35.67106007905528 139.7472530541341 31.339999999999996 35.671195019596226 139.74738623896957 31.339999999999996 35.671195019596226 139.74738623896957 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67106007905528 139.7472530541341 7.4 35.671041980183915 139.74727925341844 7.4 35.671041980183915 139.74727925341844 31.339999999999996 35.67106007905528 139.7472530541341 31.339999999999996 35.67106007905528 139.7472530541341 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671041980183915 139.74727925341844 7.4 35.671019158962196 139.7472561910453 7.4 35.671019158962196 139.7472561910453 31.339999999999996 35.671041980183915 139.74727925341844 31.339999999999996 35.671041980183915 139.74727925341844 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671019158962196 139.7472561910453 7.4 35.6710040319347 139.74727863136826 7.4 35.6710040319347 139.74727863136826 31.339999999999996 35.671019158962196 139.7472561910453 31.339999999999996 35.671019158962196 139.7472561910453 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6710040319347 139.74727863136826 7.4 35.671174875200265 139.74745121321746 7.4 35.671174875200265 139.74745121321746 31.339999999999996 35.6710040319347 139.74727863136826 31.339999999999996 35.6710040319347 139.74727863136826 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671174875200265 139.74745121321746 7.4 35.671191983071985 139.74742567777258 7.4 35.671191983071985 139.74742567777258 31.339999999999996 35.671174875200265 139.74745121321746 31.339999999999996 35.671174875200265 139.74745121321746 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671191983071985 139.74742567777258 7.4 35.671178001791326 139.7474116638636 7.4 35.671178001791326 139.7474116638636 31.339999999999996 35.671191983071985 139.74742567777258 31.339999999999996 35.671191983071985 139.74742567777258 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671178001791326 139.7474116638636 31.339999999999996 35.671195019596226 139.74738623896957 31.339999999999996 35.67106007905528 139.7472530541341 31.339999999999996 35.671041980183915 139.74727925341844 31.339999999999996 35.671019158962196 139.7472561910453 31.339999999999996 35.6710040319347 139.74727863136826 31.339999999999996 35.671174875200265 139.74745121321746 31.339999999999996 35.671191983071985 139.74742567777258 31.339999999999996 35.671178001791326 139.7474116638636 31.339999999999996</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d70d574b-5cb8-47e9-a4d3-ff8f8b5d97c0"/>
							<gml:surfaceMember xlink:href="#poly-8cad3f70-8b35-44a0-a345-76c368cff20e"/>
							<gml:surfaceMember xlink:href="#poly-e5c32f20-87f9-4c46-abe8-dac1d5f21db5"/>
							<gml:surfaceMember xlink:href="#poly-e2a7883f-e8a3-4301-9161-446474f0ec7e"/>
							<gml:surfaceMember xlink:href="#poly-0b18edd8-5db7-4c09-b791-a79e2ce28152"/>
							<gml:surfaceMember xlink:href="#poly-e2ab6187-ad8d-452f-96a8-ea78c4b7c511"/>
							<gml:surfaceMember xlink:href="#poly-69a69cdd-c158-44db-a88e-5d6c1c56000a"/>
							<gml:surfaceMember xlink:href="#poly-fe2708e1-a4ee-4bea-9434-7f91d6f9056a"/>
							<gml:surfaceMember xlink:href="#poly-2bac3a1d-54cd-4959-9566-f2a5143c1ed7"/>
							<gml:surfaceMember xlink:href="#poly-11e4db7b-f783-442a-a435-aec223dce62d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d70d574b-5cb8-47e9-a4d3-ff8f8b5d97c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d70d574b-5cb8-47e9-a4d3-ff8f8b5d97c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d70d574b-5cb8-47e9-a4d3-ff8f8b5d97c0">
											<gml:posList>35.671041980183894 139.74727925341844 7.4 35.67106007905527 139.7472530541341 7.4 35.671195019596226 139.74738623896954 7.4 35.67117800179133 139.74741166386357 7.4 35.67119198307198 139.74742567777258 7.4 35.67117487520027 139.74745121321746 7.4 35.671004031934665 139.74727863136826 7.4 35.671019158962196 139.7472561910453 7.4 35.671041980183894 139.74727925341844 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8cad3f70-8b35-44a0-a345-76c368cff20e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cad3f70-8b35-44a0-a345-76c368cff20e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cad3f70-8b35-44a0-a345-76c368cff20e">
											<gml:posList>35.67117800179133 139.74741166386357 18.6 35.671195019596226 139.74738623896954 18.6 35.67106007905527 139.7472530541341 18.6 35.671041980183894 139.74727925341844 18.6 35.671019158962196 139.7472561910453 18.6 35.671004031934665 139.74727863136826 18.6 35.67117487520027 139.74745121321746 18.6 35.67119198307198 139.74742567777258 18.6 35.67117800179133 139.74741166386357 18.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5c32f20-87f9-4c46-abe8-dac1d5f21db5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5c32f20-87f9-4c46-abe8-dac1d5f21db5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5c32f20-87f9-4c46-abe8-dac1d5f21db5">
											<gml:posList>35.67106007905527 139.7472530541341 7.4 35.671041980183894 139.74727925341844 7.4 35.671041980183894 139.74727925341844 18.6 35.67106007905527 139.7472530541341 18.6 35.67106007905527 139.7472530541341 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2a7883f-e8a3-4301-9161-446474f0ec7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2a7883f-e8a3-4301-9161-446474f0ec7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2a7883f-e8a3-4301-9161-446474f0ec7e">
											<gml:posList>35.671019158962196 139.7472561910453 7.4 35.671004031934665 139.74727863136826 7.4 35.671004031934665 139.74727863136826 18.6 35.671019158962196 139.7472561910453 18.6 35.671019158962196 139.7472561910453 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b18edd8-5db7-4c09-b791-a79e2ce28152">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b18edd8-5db7-4c09-b791-a79e2ce28152">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b18edd8-5db7-4c09-b791-a79e2ce28152">
											<gml:posList>35.671041980183894 139.74727925341844 7.4 35.671019158962196 139.7472561910453 7.4 35.671019158962196 139.7472561910453 18.6 35.671041980183894 139.74727925341844 18.6 35.671041980183894 139.74727925341844 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2ab6187-ad8d-452f-96a8-ea78c4b7c511">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2ab6187-ad8d-452f-96a8-ea78c4b7c511">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2ab6187-ad8d-452f-96a8-ea78c4b7c511">
											<gml:posList>35.671195019596226 139.74738623896954 7.4 35.67106007905527 139.7472530541341 7.4 35.67106007905527 139.7472530541341 18.6 35.671195019596226 139.74738623896954 18.6 35.671195019596226 139.74738623896954 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69a69cdd-c158-44db-a88e-5d6c1c56000a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69a69cdd-c158-44db-a88e-5d6c1c56000a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69a69cdd-c158-44db-a88e-5d6c1c56000a">
											<gml:posList>35.671004031934665 139.74727863136826 7.4 35.67117487520027 139.74745121321746 7.4 35.67117487520027 139.74745121321746 18.6 35.671004031934665 139.74727863136826 18.6 35.671004031934665 139.74727863136826 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe2708e1-a4ee-4bea-9434-7f91d6f9056a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe2708e1-a4ee-4bea-9434-7f91d6f9056a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe2708e1-a4ee-4bea-9434-7f91d6f9056a">
											<gml:posList>35.67117800179133 139.74741166386357 7.4 35.671195019596226 139.74738623896954 7.4 35.671195019596226 139.74738623896954 18.6 35.67117800179133 139.74741166386357 18.6 35.67117800179133 139.74741166386357 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2bac3a1d-54cd-4959-9566-f2a5143c1ed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bac3a1d-54cd-4959-9566-f2a5143c1ed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bac3a1d-54cd-4959-9566-f2a5143c1ed7">
											<gml:posList>35.67119198307198 139.74742567777258 7.4 35.67117800179133 139.74741166386357 7.4 35.67117800179133 139.74741166386357 18.6 35.67119198307198 139.74742567777258 18.6 35.67119198307198 139.74742567777258 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11e4db7b-f783-442a-a435-aec223dce62d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11e4db7b-f783-442a-a435-aec223dce62d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11e4db7b-f783-442a-a435-aec223dce62d">
											<gml:posList>35.67117487520027 139.74745121321746 7.4 35.67119198307198 139.74742567777258 7.4 35.67119198307198 139.74742567777258 18.6 35.67117487520027 139.74745121321746 18.6 35.67117487520027 139.74745121321746 7.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-3907</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>