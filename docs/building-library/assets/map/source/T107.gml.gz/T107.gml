<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1be33173-fd3c-4abe-ae19-240edfa40992">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">12.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67079081235616 139.74183832845804 0 35.67082628948121 139.7417896841599 0 35.670748075225276 139.74170394363256 0 35.67071259813436 139.74175258792104 0 35.67079081235616 139.74183832845804 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67079081235616 139.74183832845804 8.27 35.67071259813436 139.74175258792104 8.27 35.670748075225276 139.74170394363256 8.27 35.67082628948121 139.7417896841599 8.27 35.67079081235616 139.74183832845804 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67079081235616 139.74183832845804 8.27 35.67082628948121 139.7417896841599 8.27 35.67082628948121 139.7417896841599 21.09 35.67079081235616 139.74183832845804 21.09 35.67079081235616 139.74183832845804 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67082628948121 139.7417896841599 8.27 35.670748075225276 139.74170394363256 8.27 35.670748075225276 139.74170394363256 21.09 35.67082628948121 139.7417896841599 21.09 35.67082628948121 139.7417896841599 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670748075225276 139.74170394363256 8.27 35.67071259813436 139.74175258792104 8.27 35.67071259813436 139.74175258792104 21.09 35.670748075225276 139.74170394363256 21.09 35.670748075225276 139.74170394363256 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071259813436 139.74175258792104 8.27 35.67079081235616 139.74183832845804 8.27 35.67079081235616 139.74183832845804 21.09 35.67071259813436 139.74175258792104 21.09 35.67071259813436 139.74175258792104 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67079081235616 139.74183832845804 21.09 35.67082628948121 139.7417896841599 21.09 35.670748075225276 139.74170394363256 21.09 35.67071259813436 139.74175258792104 21.09 35.67079081235616 139.74183832845804 21.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b87c4fa2-30e9-4625-87a6-0e24748f4be1"/>
							<gml:surfaceMember xlink:href="#poly-5c43d6cc-9dc6-4c33-849a-bdbb64fea7af"/>
							<gml:surfaceMember xlink:href="#poly-118b3b4a-acd4-45aa-808a-0427c180b9b3"/>
							<gml:surfaceMember xlink:href="#poly-e543c2b7-17d6-479a-a65d-0adb70d2551c"/>
							<gml:surfaceMember xlink:href="#poly-240326f2-034d-499b-b965-79661f49bfe4"/>
							<gml:surfaceMember xlink:href="#poly-f104debd-03df-41da-b7b6-bd43bcd9ae1b"/>
							<gml:surfaceMember xlink:href="#poly-d3dbccf4-11ca-43f3-ab66-cbb598901695"/>
							<gml:surfaceMember xlink:href="#poly-5fa9fff6-98a0-4658-9300-e4110b796a68"/>
							<gml:surfaceMember xlink:href="#poly-89620a77-cada-4c9d-9f3a-62a193d5bf7f"/>
							<gml:surfaceMember xlink:href="#poly-f8ec3ce5-e436-4b0d-adaf-60e1e7b35d55"/>
							<gml:surfaceMember xlink:href="#poly-0c31450d-0995-4d3e-8ae8-372fb7a75bf5"/>
							<gml:surfaceMember xlink:href="#poly-323577db-6511-42fe-914e-7d0643093415"/>
							<gml:surfaceMember xlink:href="#poly-35f35403-e174-4e74-bc56-938927442759"/>
							<gml:surfaceMember xlink:href="#poly-aff25675-d630-4716-81a3-5d5096120814"/>
							<gml:surfaceMember xlink:href="#poly-69a8af5e-f9d5-4472-8258-9a27976ce196"/>
							<gml:surfaceMember xlink:href="#poly-069f01b8-c80e-4272-8af8-4c6475a9cce3"/>
							<gml:surfaceMember xlink:href="#poly-e5186d38-aa0d-4810-b942-957a6b334758"/>
							<gml:surfaceMember xlink:href="#poly-a49b4a5f-d488-488f-a63c-b3401d30f3eb"/>
							<gml:surfaceMember xlink:href="#poly-4b5654ca-9275-47b7-9a56-f9f5bc2ec0f7"/>
							<gml:surfaceMember xlink:href="#poly-9c049eb1-30a8-4eb8-8f7d-718de07365a7"/>
							<gml:surfaceMember xlink:href="#poly-08975948-b78c-4bff-889d-69de8820af7a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1be33173-fd3c-4abe-ae19-240edfa40992_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7712f7e-d1c2-45d9-8299-6e508b3ecfc3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670766237514904 139.7417982583868 21.55 35.67079071133921 139.74176472696888 21.55 35.670750115701864 139.74172022356234 21.55 35.670725641889774 139.7417537549768 21.55 35.670735475054826 139.74176453598855 21.55 35.670734394533746 139.74176601742792 21.55 35.67072297363469 139.7417535039595 21.55 35.67074960848772 139.74171700966556 21.55 35.67079339765531 139.7417650221514 21.55 35.670766636730164 139.7418016933343 21.55 35.67075867999313 139.74179297583171 21.55 35.6707598955776 139.74179130645072 21.55 35.670766237514904 139.7417982583868 21.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5387dfa-8c0b-46f1-ac0c-bdd211773840">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5387dfa-8c0b-46f1-ac0c-bdd211773840_0">
											<gml:posList>35.67074960848772 139.74171700966556 22.962 35.67074960848772 139.74171700966556 21.55 35.67072297363469 139.7417535039595 21.55 35.67072297363469 139.7417535039595 22.962 35.67074960848772 139.74171700966556 22.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51052ad6-bef3-43fa-9a0f-2f8e7518cffa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51052ad6-bef3-43fa-9a0f-2f8e7518cffa_0">
											<gml:posList>35.670750115701864 139.74172022356234 21.55 35.670750115701864 139.74172022356234 22.962 35.670725641889774 139.7417537549768 22.962 35.670725641889774 139.7417537549768 21.55 35.670750115701864 139.74172022356234 21.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-384b2b26-dacf-4a7f-904c-97f51b5045d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-384b2b26-dacf-4a7f-904c-97f51b5045d4_0">
											<gml:posList>35.67074960848772 139.74171700966556 21.55 35.67074960848772 139.74171700966556 22.962 35.67079339765531 139.7417650221514 22.962 35.67079339765531 139.7417650221514 21.55 35.67074960848772 139.74171700966556 21.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-233c9c67-f36d-413e-9331-9afb94a8a281">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-233c9c67-f36d-413e-9331-9afb94a8a281_0">
											<gml:posList>35.67079071133921 139.74176472696888 22.962 35.670750115701864 139.74172022356234 22.962 35.670750115701864 139.74172022356234 21.55 35.67079071133921 139.74176472696888 21.55 35.67079071133921 139.74176472696888 22.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd853720-bec5-4c0b-85a9-c9c397c8549e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd853720-bec5-4c0b-85a9-c9c397c8549e_0">
											<gml:posList>35.670735475054826 139.74176453598855 22.962 35.670735475054826 139.74176453598855 21.55 35.670725641889774 139.7417537549768 21.55 35.670725641889774 139.7417537549768 22.962 35.670735475054826 139.74176453598855 22.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f21113d-3239-4b3f-9ccf-859a182a0dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f21113d-3239-4b3f-9ccf-859a182a0dc2_0">
											<gml:posList>35.67075867999313 139.74179297583171 22.962 35.670766636730164 139.7418016933343 22.962 35.67079339765531 139.7417650221514 22.962 35.67074960848772 139.74171700966556 22.962 35.67072297363469 139.7417535039595 22.962 35.670734394533746 139.74176601742792 22.962 35.670735475054826 139.74176453598855 22.962 35.670725641889774 139.7417537549768 22.962 35.670750115701864 139.74172022356234 22.962 35.67079071133921 139.74176472696888 22.962 35.670766237514904 139.7417982583868 22.962 35.6707598955776 139.74179130645072 22.962 35.67075867999313 139.74179297583171 22.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea1590bc-3975-4246-83d4-d68d15d36f71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea1590bc-3975-4246-83d4-d68d15d36f71_0">
											<gml:posList>35.670734394533746 139.74176601742792 22.962 35.67072297363469 139.7417535039595 22.962 35.67072297363469 139.7417535039595 21.55 35.670734394533746 139.74176601742792 21.55 35.670734394533746 139.74176601742792 22.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cbbec74-fa1b-4a89-98c9-698157f15bb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cbbec74-fa1b-4a89-98c9-698157f15bb3_0">
											<gml:posList>35.670735475054826 139.74176453598855 21.55 35.670735475054826 139.74176453598855 22.962 35.670734394533746 139.74176601742792 22.962 35.670734394533746 139.74176601742792 21.55 35.670735475054826 139.74176453598855 21.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b143e629-ca40-4d09-bbb9-c0b066410a89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b143e629-ca40-4d09-bbb9-c0b066410a89_0">
											<gml:posList>35.670766237514904 139.7417982583868 21.55 35.670766237514904 139.7417982583868 22.962 35.67079071133921 139.74176472696888 22.962 35.67079071133921 139.74176472696888 21.55 35.670766237514904 139.7417982583868 21.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93a69fd6-a0ac-4021-994e-19fe5b13f451">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93a69fd6-a0ac-4021-994e-19fe5b13f451_0">
											<gml:posList>35.67079339765531 139.7417650221514 22.962 35.670766636730164 139.7418016933343 22.962 35.670766636730164 139.7418016933343 21.55 35.67079339765531 139.7417650221514 21.55 35.67079339765531 139.7417650221514 22.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fed8c69-56ef-4746-bda9-7ebe6895f1b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fed8c69-56ef-4746-bda9-7ebe6895f1b2_0">
											<gml:posList>35.67075867999313 139.74179297583171 21.55 35.67075867999313 139.74179297583171 22.962 35.6707598955776 139.74179130645072 22.962 35.6707598955776 139.74179130645072 21.55 35.67075867999313 139.74179297583171 21.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e120831-3b4a-4cf1-ad43-e388946c8e82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e120831-3b4a-4cf1-ad43-e388946c8e82_0">
											<gml:posList>35.6707598955776 139.74179130645072 21.55 35.6707598955776 139.74179130645072 22.962 35.670766237514904 139.7417982583868 22.962 35.670766237514904 139.7417982583868 21.55 35.6707598955776 139.74179130645072 21.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7397d3d2-e292-4c0d-a44b-09f023793ec1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7397d3d2-e292-4c0d-a44b-09f023793ec1_0">
											<gml:posList>35.670766636730164 139.7418016933343 22.962 35.67075867999313 139.74179297583171 22.962 35.67075867999313 139.74179297583171 21.55 35.670766636730164 139.7418016933343 21.55 35.670766636730164 139.7418016933343 22.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b87c4fa2-30e9-4625-87a6-0e24748f4be1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b87c4fa2-30e9-4625-87a6-0e24748f4be1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b87c4fa2-30e9-4625-87a6-0e24748f4be1">
											<gml:posList>35.670790812356145 139.74183832845804 8.27 35.67071259813436 139.741752587921 8.27 35.670748075225255 139.74170394363256 8.27 35.670826289481205 139.7417896841599 8.27 35.670790812356145 139.74183832845804 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c43d6cc-9dc6-4c33-849a-bdbb64fea7af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c43d6cc-9dc6-4c33-849a-bdbb64fea7af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c43d6cc-9dc6-4c33-849a-bdbb64fea7af">
											<gml:posList>35.67071259813436 139.741752587921 21.925 35.67071596909855 139.74175236314446 21.925 35.67074826764872 139.7417080636864 21.925 35.670748075225255 139.74170394363256 21.925 35.67071259813436 139.741752587921 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-118b3b4a-acd4-45aa-808a-0427c180b9b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-118b3b4a-acd4-45aa-808a-0427c180b9b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-118b3b4a-acd4-45aa-808a-0427c180b9b3">
											<gml:posList>35.670748075225255 139.74170394363256 21.925 35.67074826764872 139.7417080636864 21.925 35.670798777654745 139.74176344742995 21.925 35.670802148618904 139.7417632226536 21.925 35.670748075225255 139.74170394363256 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e543c2b7-17d6-479a-a65d-0adb70d2551c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e543c2b7-17d6-479a-a65d-0adb70d2551c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e543c2b7-17d6-479a-a65d-0adb70d2551c">
											<gml:posList>35.67071596909855 139.74175236314446 21.55 35.67073689840741 139.74177531556026 21.55 35.67074950450641 139.74175805787402 21.55 35.6707687558591 139.74177916748263 21.55 35.67075615877085 139.7417964251594 21.55 35.67076647906768 139.74180772480108 21.55 35.670798777654745 139.74176344742995 21.55 35.67074826764872 139.7417080636864 21.55 35.67071596909855 139.74175236314446 21.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-240326f2-034d-499b-b965-79661f49bfe4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-240326f2-034d-499b-b965-79661f49bfe4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-240326f2-034d-499b-b965-79661f49bfe4">
											<gml:posList>35.67071596909855 139.74175236314446 21.925 35.67071259813436 139.741752587921 21.925 35.670735313646894 139.74177749349278 21.925 35.67073689840741 139.74177531556026 21.925 35.67071596909855 139.74175236314446 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f104debd-03df-41da-b7b6-bd43bcd9ae1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f104debd-03df-41da-b7b6-bd43bcd9ae1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f104debd-03df-41da-b7b6-bd43bcd9ae1b">
											<gml:posList>35.670754574009955 139.741798603092 24.65 35.6707687558591 139.74177916748263 24.65 35.67074950450641 139.74175805787402 24.65 35.670735313646894 139.74177749349278 24.65 35.670754574009955 139.741798603092 24.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3dbccf4-11ca-43f3-ab66-cbb598901695">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3dbccf4-11ca-43f3-ab66-cbb598901695">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3dbccf4-11ca-43f3-ab66-cbb598901695">
											<gml:posList>35.670802148618904 139.7417632226536 21.925 35.670798777654745 139.74176344742995 21.925 35.67076647906768 139.74180772480108 21.925 35.67076666248228 139.74181185591274 21.925 35.670802148618904 139.7417632226536 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5fa9fff6-98a0-4658-9300-e4110b796a68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fa9fff6-98a0-4658-9300-e4110b796a68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fa9fff6-98a0-4658-9300-e4110b796a68">
											<gml:posList>35.67076666248228 139.74181185591274 21.925 35.670790812356145 139.74183832845804 16.696 35.670826289481205 139.7417896841599 16.696 35.670802148618904 139.7417632226536 21.925 35.67076666248228 139.74181185591274 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89620a77-cada-4c9d-9f3a-62a193d5bf7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89620a77-cada-4c9d-9f3a-62a193d5bf7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89620a77-cada-4c9d-9f3a-62a193d5bf7f">
											<gml:posList>35.67076647906768 139.74180772480108 21.925 35.67075615877085 139.7417964251594 21.925 35.670754574009955 139.741798603092 21.925 35.67076666248228 139.74181185591274 21.925 35.67076647906768 139.74180772480108 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8ec3ce5-e436-4b0d-adaf-60e1e7b35d55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8ec3ce5-e436-4b0d-adaf-60e1e7b35d55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8ec3ce5-e436-4b0d-adaf-60e1e7b35d55">
											<gml:posList>35.67074826764872 139.7417080636864 21.925 35.67074826764872 139.7417080636864 21.55 35.670798777654745 139.74176344742995 21.55 35.670798777654745 139.74176344742995 21.925 35.67074826764872 139.7417080636864 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c31450d-0995-4d3e-8ae8-372fb7a75bf5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c31450d-0995-4d3e-8ae8-372fb7a75bf5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c31450d-0995-4d3e-8ae8-372fb7a75bf5">
											<gml:posList>35.67073689840741 139.74177531556026 21.925 35.67073689840741 139.74177531556026 21.55 35.67071596909855 139.74175236314446 21.55 35.67071596909855 139.74175236314446 21.925 35.67073689840741 139.74177531556026 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-323577db-6511-42fe-914e-7d0643093415">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-323577db-6511-42fe-914e-7d0643093415">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-323577db-6511-42fe-914e-7d0643093415">
											<gml:posList>35.670748075225255 139.74170394363256 8.27 35.67071259813436 139.741752587921 8.27 35.67071259813436 139.741752587921 21.925 35.670748075225255 139.74170394363256 21.925 35.670748075225255 139.74170394363256 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35f35403-e174-4e74-bc56-938927442759">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35f35403-e174-4e74-bc56-938927442759">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35f35403-e174-4e74-bc56-938927442759">
											<gml:posList>35.67071596909855 139.74175236314446 21.925 35.67071596909855 139.74175236314446 21.55 35.67074826764872 139.7417080636864 21.55 35.67074826764872 139.7417080636864 21.925 35.67071596909855 139.74175236314446 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aff25675-d630-4716-81a3-5d5096120814">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aff25675-d630-4716-81a3-5d5096120814">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aff25675-d630-4716-81a3-5d5096120814">
											<gml:posList>35.67073689840741 139.74177531556026 21.925 35.670735313646894 139.74177749349278 21.925 35.670735313646894 139.74177749349278 24.65 35.67074950450641 139.74175805787402 24.65 35.67074950450641 139.74175805787402 21.55 35.67073689840741 139.74177531556026 21.55 35.67073689840741 139.74177531556026 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69a8af5e-f9d5-4472-8258-9a27976ce196">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69a8af5e-f9d5-4472-8258-9a27976ce196">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69a8af5e-f9d5-4472-8258-9a27976ce196">
											<gml:posList>35.670754574009955 139.741798603092 21.925 35.670754574009955 139.741798603092 24.65 35.670735313646894 139.74177749349278 24.65 35.670735313646894 139.74177749349278 21.925 35.67071259813436 139.741752587921 21.925 35.67071259813436 139.741752587921 8.27 35.670790812356145 139.74183832845804 8.27 35.670790812356145 139.74183832845804 16.696 35.67076666248228 139.74181185591274 21.925 35.670754574009955 139.741798603092 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-069f01b8-c80e-4272-8af8-4c6475a9cce3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-069f01b8-c80e-4272-8af8-4c6475a9cce3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-069f01b8-c80e-4272-8af8-4c6475a9cce3">
											<gml:posList>35.67074950450641 139.74175805787402 24.65 35.6707687558591 139.74177916748263 24.65 35.6707687558591 139.74177916748263 21.55 35.67074950450641 139.74175805787402 21.55 35.67074950450641 139.74175805787402 24.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5186d38-aa0d-4810-b942-957a6b334758">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5186d38-aa0d-4810-b942-957a6b334758">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5186d38-aa0d-4810-b942-957a6b334758">
											<gml:posList>35.67076647906768 139.74180772480108 21.925 35.67076647906768 139.74180772480108 21.55 35.67075615877085 139.7417964251594 21.55 35.67075615877085 139.7417964251594 21.925 35.67076647906768 139.74180772480108 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a49b4a5f-d488-488f-a63c-b3401d30f3eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a49b4a5f-d488-488f-a63c-b3401d30f3eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a49b4a5f-d488-488f-a63c-b3401d30f3eb">
											<gml:posList>35.670754574009955 139.741798603092 24.65 35.670754574009955 139.741798603092 21.925 35.67075615877085 139.7417964251594 21.925 35.67075615877085 139.7417964251594 21.55 35.6707687558591 139.74177916748263 21.55 35.6707687558591 139.74177916748263 24.65 35.670754574009955 139.741798603092 24.65</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b5654ca-9275-47b7-9a56-f9f5bc2ec0f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b5654ca-9275-47b7-9a56-f9f5bc2ec0f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b5654ca-9275-47b7-9a56-f9f5bc2ec0f7">
											<gml:posList>35.670798777654745 139.74176344742995 21.925 35.670798777654745 139.74176344742995 21.55 35.67076647906768 139.74180772480108 21.55 35.67076647906768 139.74180772480108 21.925 35.670798777654745 139.74176344742995 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c049eb1-30a8-4eb8-8f7d-718de07365a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c049eb1-30a8-4eb8-8f7d-718de07365a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c049eb1-30a8-4eb8-8f7d-718de07365a7">
											<gml:posList>35.670748075225255 139.74170394363256 21.925 35.670802148618904 139.7417632226536 21.925 35.670826289481205 139.7417896841599 16.696 35.670826289481205 139.7417896841599 8.27 35.670748075225255 139.74170394363256 8.27 35.670748075225255 139.74170394363256 21.925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08975948-b78c-4bff-889d-69de8820af7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08975948-b78c-4bff-889d-69de8820af7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08975948-b78c-4bff-889d-69de8820af7a">
											<gml:posList>35.670790812356145 139.74183832845804 8.27 35.670826289481205 139.7417896841599 8.27 35.670826289481205 139.7417896841599 16.696 35.670790812356145 139.74183832845804 16.696 35.670790812356145 139.74183832845804 8.27</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1492</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">68.7618</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>