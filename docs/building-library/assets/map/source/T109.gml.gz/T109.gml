<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1cdbaf0f-72fa-4ebc-a91a-86f66e6f02ae">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">40</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66901773718654 139.74947356324404 0 35.668996664998176 139.74946337871444 0 35.668952589625654 139.74959545841588 0 35.668964374684066 139.74960136679914 0 35.66895999412329 139.74961449409844 0 35.66902771986815 139.7496484342468 0 35.66903257717726 139.74963389254302 0 35.669044461415346 139.74963984501858 0 35.669090119960416 139.74950303581159 0 35.66909527761161 139.7495056152027 0 35.66910881261854 139.7494615824028 0 35.66903427005848 139.74942422522838 0 35.66901773718654 139.74947356324404 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66901773718654 139.74947356324404 6.154 35.66903427005848 139.74942422522838 6.154 35.66910881261854 139.7494615824028 6.154 35.66909527761161 139.7495056152027 6.154 35.669090119960416 139.74950303581159 6.154 35.669044461415346 139.74963984501858 6.154 35.66903257717726 139.74963389254302 6.154 35.66902771986815 139.7496484342468 6.154 35.66895999412329 139.74961449409844 6.154 35.668964374684066 139.74960136679914 6.154 35.668952589625654 139.74959545841588 6.154 35.668996664998176 139.74946337871444 6.154 35.66901773718654 139.74947356324404 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66901773718654 139.74947356324404 6.154 35.668996664998176 139.74946337871444 6.154 35.668996664998176 139.74946337871444 46.14 35.66901773718654 139.74947356324404 46.14 35.66901773718654 139.74947356324404 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668996664998176 139.74946337871444 6.154 35.668952589625654 139.74959545841588 6.154 35.668952589625654 139.74959545841588 46.14 35.668996664998176 139.74946337871444 46.14 35.668996664998176 139.74946337871444 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668952589625654 139.74959545841588 6.154 35.668964374684066 139.74960136679914 6.154 35.668964374684066 139.74960136679914 46.14 35.668952589625654 139.74959545841588 46.14 35.668952589625654 139.74959545841588 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668964374684066 139.74960136679914 6.154 35.66895999412329 139.74961449409844 6.154 35.66895999412329 139.74961449409844 46.14 35.668964374684066 139.74960136679914 46.14 35.668964374684066 139.74960136679914 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895999412329 139.74961449409844 6.154 35.66902771986815 139.7496484342468 6.154 35.66902771986815 139.7496484342468 46.14 35.66895999412329 139.74961449409844 46.14 35.66895999412329 139.74961449409844 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902771986815 139.7496484342468 6.154 35.66903257717726 139.74963389254302 6.154 35.66903257717726 139.74963389254302 46.14 35.66902771986815 139.7496484342468 46.14 35.66902771986815 139.7496484342468 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903257717726 139.74963389254302 6.154 35.669044461415346 139.74963984501858 6.154 35.669044461415346 139.74963984501858 46.14 35.66903257717726 139.74963389254302 46.14 35.66903257717726 139.74963389254302 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669044461415346 139.74963984501858 6.154 35.669090119960416 139.74950303581159 6.154 35.669090119960416 139.74950303581159 46.14 35.669044461415346 139.74963984501858 46.14 35.669044461415346 139.74963984501858 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669090119960416 139.74950303581159 6.154 35.66909527761161 139.7495056152027 6.154 35.66909527761161 139.7495056152027 46.14 35.669090119960416 139.74950303581159 46.14 35.669090119960416 139.74950303581159 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909527761161 139.7495056152027 6.154 35.66910881261854 139.7494615824028 6.154 35.66910881261854 139.7494615824028 46.14 35.66909527761161 139.7495056152027 46.14 35.66909527761161 139.7495056152027 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910881261854 139.7494615824028 6.154 35.66903427005848 139.74942422522838 6.154 35.66903427005848 139.74942422522838 46.14 35.66910881261854 139.7494615824028 46.14 35.66910881261854 139.7494615824028 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903427005848 139.74942422522838 6.154 35.66901773718654 139.74947356324404 6.154 35.66901773718654 139.74947356324404 46.14 35.66903427005848 139.74942422522838 46.14 35.66903427005848 139.74942422522838 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66901773718654 139.74947356324404 46.14 35.668996664998176 139.74946337871444 46.14 35.668952589625654 139.74959545841588 46.14 35.668964374684066 139.74960136679914 46.14 35.66895999412329 139.74961449409844 46.14 35.66902771986815 139.7496484342468 46.14 35.66903257717726 139.74963389254302 46.14 35.669044461415346 139.74963984501858 46.14 35.669090119960416 139.74950303581159 46.14 35.66909527761161 139.7495056152027 46.14 35.66910881261854 139.7494615824028 46.14 35.66903427005848 139.74942422522838 46.14 35.66901773718654 139.74947356324404 46.14</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-585a24b8-07e4-4513-8a79-d0c12455213c"/>
							<gml:surfaceMember xlink:href="#poly-21498f40-92a0-44db-b52b-acbb2aea2356"/>
							<gml:surfaceMember xlink:href="#poly-0ab221f4-e048-4b49-8c3d-24726f90ace8"/>
							<gml:surfaceMember xlink:href="#poly-dea04f18-46c3-4cda-810d-b83209347e17"/>
							<gml:surfaceMember xlink:href="#poly-d06c8461-d1be-4263-92cf-0fb348ee332a"/>
							<gml:surfaceMember xlink:href="#poly-4379a6d2-5c73-4401-8c88-e22826615cab"/>
							<gml:surfaceMember xlink:href="#poly-b3a53519-2637-4cde-8cab-21f014d04257"/>
							<gml:surfaceMember xlink:href="#poly-852ba381-a2b1-4058-8a2c-2ac221dd97c4"/>
							<gml:surfaceMember xlink:href="#poly-c307c311-4182-4b24-8014-439a15617cee"/>
							<gml:surfaceMember xlink:href="#poly-7530e35d-7cd8-43a2-80f6-93ca840238be"/>
							<gml:surfaceMember xlink:href="#poly-872d5b9f-b5bc-43c8-b61a-7baac78965f1"/>
							<gml:surfaceMember xlink:href="#poly-37827ae1-788e-4cd7-8d77-4d602fce4793"/>
							<gml:surfaceMember xlink:href="#poly-35ac8806-4f46-4237-87a5-767dec1e2d6d"/>
							<gml:surfaceMember xlink:href="#poly-9ad5d7c9-28a5-4ca9-bb2b-f048dc91da7c"/>
							<gml:surfaceMember xlink:href="#poly-6bccc5fb-4800-4c22-9828-af2d6d713e98"/>
							<gml:surfaceMember xlink:href="#poly-67d8fff7-ea89-4a98-8fb3-b6191c3cd885"/>
							<gml:surfaceMember xlink:href="#poly-46553d03-b6ba-482a-81fd-e21b3de6c1b2"/>
							<gml:surfaceMember xlink:href="#poly-4026424e-7663-4e53-ac7f-95b387e0ef64"/>
							<gml:surfaceMember xlink:href="#poly-cb860580-3fe7-4ca1-88c0-86f832326c5e"/>
							<gml:surfaceMember xlink:href="#poly-aab14de4-cabd-4c71-ad9c-ad65bfe27a4c"/>
							<gml:surfaceMember xlink:href="#poly-07d2b766-9ab5-4c68-8b2f-975975a11aa2"/>
							<gml:surfaceMember xlink:href="#poly-18c52315-d383-436d-b0b9-4dd96902b445"/>
							<gml:surfaceMember xlink:href="#poly-30d4819b-8c02-4ce6-9dd3-9101e6ccb766"/>
							<gml:surfaceMember xlink:href="#poly-ea9c2f5f-49e5-4156-96ea-681e416aab09"/>
							<gml:surfaceMember xlink:href="#poly-a94800ee-3a28-4c1d-b428-bd9bf59bfb73"/>
							<gml:surfaceMember xlink:href="#poly-d4eeead0-5a25-47db-9f58-ebe582bcb857"/>
							<gml:surfaceMember xlink:href="#poly-6638a61d-ee17-4f95-9184-4179f0920432"/>
							<gml:surfaceMember xlink:href="#poly-a4e1a063-dfd6-41f4-9e93-40dbdd22af11"/>
							<gml:surfaceMember xlink:href="#poly-6fcdec94-7727-4038-9428-8854c7d87750"/>
							<gml:surfaceMember xlink:href="#poly-7f5df795-b5fe-4aa3-97dd-6750f9517e05"/>
							<gml:surfaceMember xlink:href="#poly-667f3966-db7d-4414-b12f-aa2ca0314dea"/>
							<gml:surfaceMember xlink:href="#poly-446391ec-1759-4eea-b764-a44b3fbff2fd"/>
							<gml:surfaceMember xlink:href="#poly-011de64d-7dbd-49b8-9bc8-aafdd3904d36"/>
							<gml:surfaceMember xlink:href="#poly-61a78e37-818c-4888-aa24-ff6a2c05c1e2"/>
							<gml:surfaceMember xlink:href="#poly-8e5b7d72-5272-4aad-846f-005a559ee00d"/>
							<gml:surfaceMember xlink:href="#poly-7a88e934-fcbe-46b0-bba1-d497424c7779"/>
							<gml:surfaceMember xlink:href="#poly-473fbb3c-e09c-4fa8-a8d9-c3b943215ed7"/>
							<gml:surfaceMember xlink:href="#poly-4acedbf2-903d-48de-ba73-b9958d282e22"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1cdbaf0f-72fa-4ebc-a91a-86f66e6f02ae_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0924561a-fde3-4152-a3f0-e630cfc8f59a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669003618114765 139.74950727957236 45.638 35.66902060614309 139.74951612076273 45.638 35.66900463877753 139.74956212224686 45.638 35.66898765975856 139.74955326999302 45.638 35.669003618114765 139.74950727957236 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-437d5360-f029-4c28-bd8b-85dafe0ce686">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-437d5360-f029-4c28-bd8b-85dafe0ce686_0">
											<gml:posList>35.66898765975856 139.74955326999302 45.638 35.66898765975856 139.74955326999302 49.086 35.669003618114765 139.74950727957236 49.086 35.669003618114765 139.74950727957236 45.638 35.66898765975856 139.74955326999302 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3401a77d-bde0-44b5-b771-de4093fcde9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3401a77d-bde0-44b5-b771-de4093fcde9e_0">
											<gml:posList>35.66900463877753 139.74956212224686 45.638 35.66900463877753 139.74956212224686 49.086 35.66898765975856 139.74955326999302 49.086 35.66898765975856 139.74955326999302 45.638 35.66900463877753 139.74956212224686 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43b2eca9-d510-48a4-a0f5-a41ef2826f4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43b2eca9-d510-48a4-a0f5-a41ef2826f4d_0">
											<gml:posList>35.66900463877753 139.74956212224686 49.086 35.66902060614309 139.74951612076273 49.086 35.669003618114765 139.74950727957236 49.086 35.66898765975856 139.74955326999302 49.086 35.66900463877753 139.74956212224686 49.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c34c0346-f6c0-4a46-a443-fa9407f5cff2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c34c0346-f6c0-4a46-a443-fa9407f5cff2_0">
											<gml:posList>35.669003618114765 139.74950727957236 45.638 35.669003618114765 139.74950727957236 49.086 35.66902060614309 139.74951612076273 49.086 35.66902060614309 139.74951612076273 45.638 35.669003618114765 139.74950727957236 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38559490-0db2-4d62-9ede-44076d9a69ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38559490-0db2-4d62-9ede-44076d9a69ab_0">
											<gml:posList>35.66902060614309 139.74951612076273 45.638 35.66902060614309 139.74951612076273 49.086 35.66900463877753 139.74956212224686 49.086 35.66900463877753 139.74956212224686 45.638 35.66902060614309 139.74951612076273 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1cdbaf0f-72fa-4ebc-a91a-86f66e6f02ae_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2212878a-f761-40fe-8ebc-0587289b2482">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66900989742546 139.74941201168681 6.154 35.66903427005849 139.74942422522838 6.154 35.66901773718656 139.749473563244 6.154 35.668996664998176 139.74946337871444 6.154 35.66899331072229 139.74946170322048 6.154 35.66900989742546 139.74941201168681 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c047ade7-f7f6-4b4d-b57b-27e5ad028bb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c047ade7-f7f6-4b4d-b57b-27e5ad028bb4_0">
											<gml:posList>35.66903427005849 139.74942422522838 43.986 35.66903427005849 139.74942422522838 6.154 35.66900989742546 139.74941201168681 6.154 35.66900989742546 139.74941201168681 43.986 35.66903427005849 139.74942422522838 43.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53be8f62-5830-4188-bd43-85a71cccaaf8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53be8f62-5830-4188-bd43-85a71cccaaf8_0">
											<gml:posList>35.66903257000473 139.7494293082018 43.986 35.66903427005849 139.74942422522838 43.986 35.66900989742546 139.74941201168681 43.986 35.66900819737222 139.74941709465895 43.986 35.66902038819551 139.74942320142472 43.986 35.66903257000473 139.7494293082018 43.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ac569ec-4dd9-4e8f-86ad-56dd14b31e17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ac569ec-4dd9-4e8f-86ad-56dd14b31e17_0">
											<gml:posList>35.66899331072229 139.74946170322048 46.163 35.668995982228616 139.74945370307165 46.163 35.668995982228616 139.74945370307165 41.485 35.66900819737222 139.74941709465895 43.986 35.66900989742546 139.74941201168681 43.986 35.66900989742546 139.74941201168681 6.154 35.66899331072229 139.74946170322048 6.154 35.66899331072229 139.74946170322048 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-969b43ed-22b1-4424-b70b-dac344388376">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-969b43ed-22b1-4424-b70b-dac344388376_0">
											<gml:posList>35.66902038819551 139.74942320142472 43.986 35.66900819737222 139.74941709465895 43.986 35.668995982228616 139.74945370307165 41.485 35.669008146001204 139.7494597988243 41.485 35.66902038819551 139.74942320142472 43.986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de0fdc10-f833-4360-91d9-46af1e5c736c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de0fdc10-f833-4360-91d9-46af1e5c736c_0">
											<gml:posList>35.669008146001204 139.7494597988243 46.163 35.66902038819551 139.74942320142472 43.986 35.669008146001204 139.7494597988243 41.485 35.669008146001204 139.7494597988243 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53da6bb0-f13b-4085-b317-87952fc7f3f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53da6bb0-f13b-4085-b317-87952fc7f3f7_0">
											<gml:posList>35.669008146001204 139.7494597988243 46.163 35.669020309773465 139.7494658945788 46.163 35.66903257000473 139.7494293082018 43.986 35.66902038819551 139.74942320142472 43.986 35.669008146001204 139.7494597988243 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4907481-7ce6-4b87-a389-7219d120a8f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4907481-7ce6-4b87-a389-7219d120a8f8_0">
											<gml:posList>35.66901773718656 139.749473563244 46.163 35.66901773718656 139.749473563244 6.154 35.66903427005849 139.74942422522838 6.154 35.66903427005849 139.74942422522838 43.986 35.66903257000473 139.7494293082018 43.986 35.669020309773465 139.7494658945788 46.163 35.66901773718656 139.749473563244 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57c7a957-6ccc-42e2-b16b-eb59db8973ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57c7a957-6ccc-42e2-b16b-eb59db8973ec_0">
											<gml:posList>35.668995982228616 139.74945370307165 46.163 35.669008146001204 139.7494597988243 46.163 35.669008146001204 139.7494597988243 41.485 35.668995982228616 139.74945370307165 41.485 35.668995982228616 139.74945370307165 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d8375ec-3577-40d6-b4a0-568a37bce31c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d8375ec-3577-40d6-b4a0-568a37bce31c_0">
											<gml:posList>35.66899331072229 139.74946170322048 46.163 35.66899331072229 139.74946170322048 6.154 35.668996664998176 139.74946337871444 6.154 35.668996664998176 139.74946337871444 46.163 35.66899331072229 139.74946170322048 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-938902ac-dd6a-4cc9-9056-638d3ea33fc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-938902ac-dd6a-4cc9-9056-638d3ea33fc8_0">
											<gml:posList>35.668995982228616 139.74945370307165 46.163 35.66899331072229 139.74946170322048 46.163 35.668996664998176 139.74946337871444 46.163 35.66901773718656 139.749473563244 46.163 35.669020309773465 139.7494658945788 46.163 35.669008146001204 139.7494597988243 46.163 35.668995982228616 139.74945370307165 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a6025f3-8c28-44bc-82fe-a6b756fb08b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a6025f3-8c28-44bc-82fe-a6b756fb08b7_0">
											<gml:posList>35.668996664998176 139.74946337871444 46.163 35.668996664998176 139.74946337871444 6.154 35.66901773718656 139.749473563244 6.154 35.66901773718656 139.749473563244 46.163 35.668996664998176 139.74946337871444 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1cdbaf0f-72fa-4ebc-a91a-86f66e6f02ae_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a794003-8975-4515-8ed0-b747fcf19634">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66900426007236 139.74947129080272 46.163 35.66899994103548 139.74946919656668 46.163 35.669000948495714 139.74946621307396 46.163 35.66900526752495 139.7494682962638 46.163 35.66900426007236 139.74947129080272 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2712f930-7285-46b5-8d34-3203b542a4eb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669027099229844 139.749455990195 46.163 35.66901958837758 139.7494784105339 46.163 35.669017081676884 139.74947714285707 46.163 35.66902462859151 139.74945473352713 46.163 35.669027099229844 139.749455990195 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f54ef36d-3510-4676-8220-4b6724c3878d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66896495145825 139.74958825451722 45.638 35.66903769086215 139.74962509452897 45.638 35.66907381548007 139.74951794297434 45.638 35.66907617791456 139.74951914452762 45.638 35.66909322373346 139.74946857983366 45.638 35.66905598387706 139.74944971894496 45.638 35.66904805916387 139.74947324433305 45.638 35.66902794243831 139.74946306984637 45.638 35.669022302470914 139.7494797884546 45.638 35.66901958837758 139.7494784105339 45.638 35.669027099229844 139.749455990195 45.638 35.6690455388181 139.7494653269322 45.638 35.669053301636666 139.74944230983303 45.638 35.66909917067749 139.74946553594046 45.638 35.66907872468293 139.74952617821907 45.638 35.6690762360179 139.7495249215671 45.638 35.66904020133909 139.74963179687603 45.638 35.66895909424878 139.74959072390715 45.638 35.66899994103548 139.74946919656668 45.638 35.66900426007236 139.74947129080272 45.638 35.66896495145825 139.74958825451722 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf6ae306-d248-4630-905a-ab9f83c2d307">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690606582321 139.74950902045035 45.638 35.66903580241975 139.74957963085532 45.638 35.66902864288522 139.7495758495304 45.638 35.66905348967399 139.7495052280939 45.638 35.6690606582321 139.74950902045035 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1354b6de-670e-45e3-a0ad-cd3c7d08e671">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903580241975 139.74957963085532 45.638 35.6690606582321 139.74950902045035 45.638 35.6690606582321 139.74950902045035 48.216 35.66903580241975 139.74957963085532 48.216 35.66903580241975 139.74957963085532 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1fad6f0-95f4-4f48-95d5-0978006b054f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669063949457346 139.74951076229007 45.638 35.669039102657706 139.749581372688 45.638 35.669039102657706 139.749581372688 48.216 35.669063949457346 139.74951076229007 48.216 35.669063949457346 139.74951076229007 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b602938-ec35-47af-a6c8-2a0f27f02cae">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904693847508 139.74958551782805 45.638 35.669039102657706 139.749581372688 45.638 35.669063949457346 139.74951076229007 45.638 35.66907179429083 139.74951490741512 45.638 35.66904693847508 139.74958551782805 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eaea9dc8-2a6d-4e06-bc62-c5aea189ff57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eaea9dc8-2a6d-4e06-bc62-c5aea189ff57_0">
											<gml:posList>35.669053301636666 139.74944230983303 45.638 35.6690455388181 139.7494653269322 45.638 35.6690455388181 139.7494653269322 48.216 35.669053301636666 139.74944230983303 48.216 35.669053301636666 139.74944230983303 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a732d81-044c-4852-b14e-d2b9bdf77cdb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a732d81-044c-4852-b14e-d2b9bdf77cdb_0">
											<gml:posList>35.66909917067749 139.74946553594046 45.638 35.669053301636666 139.74944230983303 45.638 35.669053301636666 139.74944230983303 48.216 35.66909917067749 139.74946553594046 48.216 35.66909917067749 139.74946553594046 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5980b441-d60c-4b57-98a8-ca33e674a69b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5980b441-d60c-4b57-98a8-ca33e674a69b_0">
											<gml:posList>35.66909322373346 139.74946857983366 45.638 35.66909322373346 139.74946857983366 48.216 35.66905598387706 139.74944971894496 48.216 35.66905598387706 139.74944971894496 45.638 35.66909322373346 139.74946857983366 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c212ec77-5336-449a-b9c6-5f4b04cd7441">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c212ec77-5336-449a-b9c6-5f4b04cd7441_0">
											<gml:posList>35.66902462859151 139.74945473352713 48.216 35.6690455388181 139.7494653269322 48.216 35.6690455388181 139.7494653269322 45.638 35.669027099229844 139.749455990195 45.638 35.669027099229844 139.749455990195 46.163 35.66902462859151 139.74945473352713 46.163 35.66902462859151 139.74945473352713 48.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70c33fce-6c9a-4087-bb7e-6d16be296533">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70c33fce-6c9a-4087-bb7e-6d16be296533_0">
											<gml:posList>35.66904805916387 139.74947324433305 45.638 35.66905598387706 139.74944971894496 45.638 35.66905598387706 139.74944971894496 48.216 35.66904805916387 139.74947324433305 48.216 35.66904805916387 139.74947324433305 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc851aa1-87ef-4add-96c5-dee60814e537">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc851aa1-87ef-4add-96c5-dee60814e537_0">
											<gml:posList>35.669017081676884 139.74947714285707 48.216 35.66902462859151 139.74945473352713 48.216 35.66902462859151 139.74945473352713 46.163 35.669017081676884 139.74947714285707 46.163 35.669017081676884 139.74947714285707 48.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8b66370-9909-46ef-93ee-24d536476a61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8b66370-9909-46ef-93ee-24d536476a61_0">
											<gml:posList>35.669027099229844 139.749455990195 45.638 35.66901958837758 139.7494784105339 45.638 35.66901958837758 139.7494784105339 46.163 35.669027099229844 139.749455990195 46.163 35.669027099229844 139.749455990195 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc323316-1d0d-4088-a760-d9a17bf5eb47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc323316-1d0d-4088-a760-d9a17bf5eb47_0">
											<gml:posList>35.66900526752495 139.7494682962638 46.163 35.669000948495714 139.74946621307396 46.163 35.669000948495714 139.74946621307396 48.216 35.66900526752495 139.7494682962638 48.216 35.66900526752495 139.7494682962638 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5723670-67b2-4ae8-a7d1-843b37e075da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5723670-67b2-4ae8-a7d1-843b37e075da_0">
											<gml:posList>35.66904805916387 139.74947324433305 45.638 35.66904805916387 139.74947324433305 48.216 35.66902794243831 139.74946306984637 48.216 35.66902794243831 139.74946306984637 45.638 35.66904805916387 139.74947324433305 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-808f9c73-7609-4972-9e9f-1f2556e6f814">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-808f9c73-7609-4972-9e9f-1f2556e6f814_0">
											<gml:posList>35.66899994103548 139.74946919656668 46.163 35.66900426007236 139.74947129080272 46.163 35.66900426007236 139.74947129080272 45.638 35.66899994103548 139.74946919656668 45.638 35.66899994103548 139.74946919656668 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29682a89-371b-4062-afa7-56e585feb753">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29682a89-371b-4062-afa7-56e585feb753_0">
											<gml:posList>35.669022302470914 139.7494797884546 45.638 35.66902794243831 139.74946306984637 45.638 35.66902794243831 139.74946306984637 48.216 35.669022302470914 139.7494797884546 48.216 35.669022302470914 139.7494797884546 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a46d36f9-a90a-41ad-8018-24f0fd93d045">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a46d36f9-a90a-41ad-8018-24f0fd93d045_0">
											<gml:posList>35.669022302470914 139.7494797884546 45.638 35.669022302470914 139.7494797884546 48.216 35.669017081676884 139.74947714285707 48.216 35.669017081676884 139.74947714285707 46.163 35.66901958837758 139.7494784105339 46.163 35.66901958837758 139.7494784105339 45.638 35.669022302470914 139.7494797884546 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08541c73-e949-4fb9-800c-8665b124a7df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08541c73-e949-4fb9-800c-8665b124a7df_0">
											<gml:posList>35.66907617791456 139.74951914452762 45.638 35.66907617791456 139.74951914452762 48.216 35.66909322373346 139.74946857983366 48.216 35.66909322373346 139.74946857983366 45.638 35.66907617791456 139.74951914452762 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a34257fa-13be-45e6-9620-7a7a47ead0fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a34257fa-13be-45e6-9620-7a7a47ead0fb_0">
											<gml:posList>35.66909917067749 139.74946553594046 45.638 35.66909917067749 139.74946553594046 48.216 35.66907872468293 139.74952617821907 48.216 35.66907872468293 139.74952617821907 45.638 35.66909917067749 139.74946553594046 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfe1f8b6-6aec-4282-b113-8fdab411c021">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfe1f8b6-6aec-4282-b113-8fdab411c021_0">
											<gml:posList>35.66905348967399 139.7495052280939 45.638 35.66905348967399 139.7495052280939 48.216 35.6690606582321 139.74950902045035 48.216 35.6690606582321 139.74950902045035 45.638 35.66905348967399 139.7495052280939 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-136fc81d-2e03-427f-9bbd-db5047e7c2bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-136fc81d-2e03-427f-9bbd-db5047e7c2bc_0">
											<gml:posList>35.66907179429083 139.74951490741512 45.638 35.669063949457346 139.74951076229007 45.638 35.669063949457346 139.74951076229007 48.216 35.66907179429083 139.74951490741512 48.216 35.66907179429083 139.74951490741512 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce6d7e0c-5f0c-4fdd-bc33-364709728c6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce6d7e0c-5f0c-4fdd-bc33-364709728c6a_0">
											<gml:posList>35.66907617791456 139.74951914452762 45.638 35.66907381548007 139.74951794297434 45.638 35.66907381548007 139.74951794297434 48.216 35.66907617791456 139.74951914452762 48.216 35.66907617791456 139.74951914452762 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4641bf5b-2a50-420c-a6c6-62946314326d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4641bf5b-2a50-420c-a6c6-62946314326d_0">
											<gml:posList>35.6690762360179 139.7495249215671 45.638 35.66907872468293 139.74952617821907 45.638 35.66907872468293 139.74952617821907 48.216 35.6690762360179 139.7495249215671 48.216 35.6690762360179 139.7495249215671 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7a143ce-a5a9-46af-8f7a-772ce02ceaac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7a143ce-a5a9-46af-8f7a-772ce02ceaac_0">
											<gml:posList>35.66900526752495 139.7494682962638 48.216 35.66896495145825 139.74958825451722 48.216 35.66896495145825 139.74958825451722 45.638 35.66900426007236 139.74947129080272 45.638 35.66900426007236 139.74947129080272 46.163 35.66900526752495 139.7494682962638 46.163 35.66900526752495 139.7494682962638 48.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f583e687-b4a6-4c9b-b298-95c1118c969f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f583e687-b4a6-4c9b-b298-95c1118c969f_0">
											<gml:posList>35.66899994103548 139.74946919656668 46.163 35.66899994103548 139.74946919656668 45.638 35.66895909424878 139.74959072390715 45.638 35.66895909424878 139.74959072390715 48.216 35.669000948495714 139.74946621307396 48.216 35.669000948495714 139.74946621307396 46.163 35.66899994103548 139.74946919656668 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98dc2380-ce9f-4d25-a069-f9be75922eee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98dc2380-ce9f-4d25-a069-f9be75922eee_0">
											<gml:posList>35.669000948495714 139.74946621307396 48.216 35.66895909424878 139.74959072390715 48.216 35.66904020133909 139.74963179687603 48.216 35.6690762360179 139.7495249215671 48.216 35.66907872468293 139.74952617821907 48.216 35.66909917067749 139.74946553594046 48.216 35.669053301636666 139.74944230983303 48.216 35.6690455388181 139.7494653269322 48.216 35.66902462859151 139.74945473352713 48.216 35.669017081676884 139.74947714285707 48.216 35.669022302470914 139.7494797884546 48.216 35.66902794243831 139.74946306984637 48.216 35.66904805916387 139.74947324433305 48.216 35.66905598387706 139.74944971894496 48.216 35.66909322373346 139.74946857983366 48.216 35.66907617791456 139.74951914452762 48.216 35.66907381548007 139.74951794297434 48.216 35.66903769086215 139.74962509452897 48.216 35.66896495145825 139.74958825451722 48.216 35.66900526752495 139.7494682962638 48.216 35.669000948495714 139.74946621307396 48.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23fa80ce-7a2d-44c5-b254-f98ecf097772">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23fa80ce-7a2d-44c5-b254-f98ecf097772_0">
											<gml:posList>35.66902864288522 139.7495758495304 45.638 35.66902864288522 139.7495758495304 48.216 35.66905348967399 139.7495052280939 48.216 35.66905348967399 139.7495052280939 45.638 35.66902864288522 139.7495758495304 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9901ac91-c3ab-4e1c-8db9-cdd2628f9086">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9901ac91-c3ab-4e1c-8db9-cdd2628f9086_0">
											<gml:posList>35.6690606582321 139.74950902045035 48.216 35.66905348967399 139.7495052280939 48.216 35.66902864288522 139.7495758495304 48.216 35.66903580241975 139.74957963085532 48.216 35.6690606582321 139.74950902045035 48.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d10a03a6-c860-4ab3-b5d2-c4a8ef424e2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d10a03a6-c860-4ab3-b5d2-c4a8ef424e2b_0">
											<gml:posList>35.66904693847508 139.74958551782805 48.216 35.66907179429083 139.74951490741512 48.216 35.669063949457346 139.74951076229007 48.216 35.669039102657706 139.749581372688 48.216 35.66904693847508 139.74958551782805 48.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2306e608-d5e1-4cda-9877-2006883d4d70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2306e608-d5e1-4cda-9877-2006883d4d70_0">
											<gml:posList>35.66904693847508 139.74958551782805 45.638 35.66907179429083 139.74951490741512 45.638 35.66907179429083 139.74951490741512 48.216 35.66904693847508 139.74958551782805 48.216 35.66904693847508 139.74958551782805 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-085fb35e-7653-43bf-a62d-76844aefeaa9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-085fb35e-7653-43bf-a62d-76844aefeaa9_0">
											<gml:posList>35.66907381548007 139.74951794297434 45.638 35.66903769086215 139.74962509452897 45.638 35.66903769086215 139.74962509452897 48.216 35.66907381548007 139.74951794297434 48.216 35.66907381548007 139.74951794297434 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92af3dc1-62dd-49c5-ae19-a784c3b80459">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92af3dc1-62dd-49c5-ae19-a784c3b80459_0">
											<gml:posList>35.66903580241975 139.74957963085532 45.638 35.66903580241975 139.74957963085532 48.216 35.66902864288522 139.7495758495304 48.216 35.66902864288522 139.7495758495304 45.638 35.66903580241975 139.74957963085532 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c401ed18-713d-4d0c-88f5-0cc5686c6651">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c401ed18-713d-4d0c-88f5-0cc5686c6651_0">
											<gml:posList>35.6690762360179 139.7495249215671 48.216 35.66904020133909 139.74963179687603 48.216 35.66904020133909 139.74963179687603 45.638 35.6690762360179 139.7495249215671 45.638 35.6690762360179 139.7495249215671 48.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee5fd772-d678-48eb-98d9-93d2e06e58c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee5fd772-d678-48eb-98d9-93d2e06e58c5_0">
											<gml:posList>35.669039102657706 139.749581372688 45.638 35.66904693847508 139.74958551782805 45.638 35.66904693847508 139.74958551782805 48.216 35.669039102657706 139.749581372688 48.216 35.669039102657706 139.749581372688 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-639e121d-b754-4854-a6fd-0dc0f1b5590d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-639e121d-b754-4854-a6fd-0dc0f1b5590d_0">
											<gml:posList>35.66896495145825 139.74958825451722 48.216 35.66903769086215 139.74962509452897 48.216 35.66903769086215 139.74962509452897 45.638 35.66896495145825 139.74958825451722 45.638 35.66896495145825 139.74958825451722 48.216</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5fc409d-1308-4b7a-b922-702e9df64aba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5fc409d-1308-4b7a-b922-702e9df64aba_0">
											<gml:posList>35.66895909424878 139.74959072390715 45.638 35.66904020133909 139.74963179687603 45.638 35.66904020133909 139.74963179687603 48.216 35.66895909424878 139.74959072390715 48.216 35.66895909424878 139.74959072390715 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-585a24b8-07e4-4513-8a79-d0c12455213c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-585a24b8-07e4-4513-8a79-d0c12455213c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-585a24b8-07e4-4513-8a79-d0c12455213c">
											<gml:posList>35.668964374684045 139.7496013667991 6.154 35.66895258962563 139.74959545841585 6.154 35.668996664998176 139.74946337871444 6.154 35.66901773718656 139.749473563244 6.154 35.66903427005849 139.74942422522838 6.154 35.66910881261853 139.7494615824028 6.154 35.669095277611596 139.7495056152027 6.154 35.66909011996041 139.74950303581159 6.154 35.66904446141535 139.74963984501855 6.154 35.66903257717726 139.74963389254302 6.154 35.66902771986811 139.7496484342468 6.154 35.66895999412327 139.74961449409844 6.154 35.668964374684045 139.7496013667991 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21498f40-92a0-44db-b52b-acbb2aea2356">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21498f40-92a0-44db-b52b-acbb2aea2356">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21498f40-92a0-44db-b52b-acbb2aea2356">
											<gml:posList>35.668964374684045 139.7496013667991 46.163 35.668968564576986 139.74959921948692 46.163 35.66895677050476 139.74959331111307 46.163 35.66895258962563 139.74959545841585 46.163 35.668964374684045 139.7496013667991 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ab221f4-e048-4b49-8c3d-24726f90ace8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ab221f4-e048-4b49-8c3d-24726f90ace8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ab221f4-e048-4b49-8c3d-24726f90ace8">
											<gml:posList>35.668964374684045 139.7496013667991 46.163 35.66895999412327 139.74961449409844 46.163 35.668964175002735 139.74961234679645 46.163 35.668968564576986 139.74959921948692 46.163 35.668964374684045 139.7496013667991 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dea04f18-46c3-4cda-810d-b83209347e17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dea04f18-46c3-4cda-810d-b83209347e17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dea04f18-46c3-4cda-810d-b83209347e17">
											<gml:posList>35.66895258962563 139.74959545841585 46.163 35.66895677050476 139.74959331111307 46.163 35.66899843523532 139.74946846910103 46.163 35.668996664998176 139.74946337871444 46.163 35.66895258962563 139.74959545841585 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d06c8461-d1be-4263-92cf-0fb348ee332a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d06c8461-d1be-4263-92cf-0fb348ee332a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d06c8461-d1be-4263-92cf-0fb348ee332a">
											<gml:posList>35.66902771986811 139.7496484342468 46.163 35.66902595862925 139.74964331070677 46.163 35.668964175002735 139.74961234679645 46.163 35.66895999412327 139.74961449409844 46.163 35.66902771986811 139.7496484342468 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4379a6d2-5c73-4401-8c88-e22826615cab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4379a6d2-5c73-4401-8c88-e22826615cab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4379a6d2-5c73-4401-8c88-e22826615cab">
											<gml:posList>35.66901773718656 139.749473563244 46.163 35.668996664998176 139.74946337871444 46.163 35.66899843523532 139.74946846910103 46.163 35.66901950742327 139.74947865363217 46.163 35.66901773718656 139.749473563244 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b3a53519-2637-4cde-8cab-21f014d04257">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3a53519-2637-4cde-8cab-21f014d04257">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3a53519-2637-4cde-8cab-21f014d04257">
											<gml:posList>35.66901773718656 139.749473563244 46.163 35.66901950742327 139.74947865363217 46.163 35.6690360132869 139.74942935982904 46.163 35.66903427005849 139.74942422522838 46.163 35.66901773718656 139.749473563244 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-852ba381-a2b1-4058-8a2c-2ac221dd97c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-852ba381-a2b1-4058-8a2c-2ac221dd97c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-852ba381-a2b1-4058-8a2c-2ac221dd97c4">
											<gml:posList>35.66903257717726 139.74963389254302 46.163 35.669030815937795 139.74962876900298 46.163 35.66902595862925 139.74964331070677 46.163 35.66902771986811 139.7496484342468 46.163 35.66903257717726 139.74963389254302 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c307c311-4182-4b24-8014-439a15617cee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c307c311-4182-4b24-8014-439a15617cee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c307c311-4182-4b24-8014-439a15617cee">
											<gml:posList>35.668968564576986 139.74959921948692 45.638 35.668964175002735 139.74961234679645 45.638 35.66902595862925 139.74964331070677 45.638 35.669030815937795 139.74962876900298 45.638 35.66904270016846 139.7496347104316 45.638 35.66908835872309 139.74949792331682 45.638 35.669093426206345 139.74950045861752 45.638 35.66910470389017 139.7494637848715 45.638 35.6690360132869 139.74942935982904 45.638 35.66901950742327 139.74947865363217 45.638 35.66899843523532 139.74946846910103 45.638 35.66895677050476 139.74959331111307 45.638 35.668968564576986 139.74959921948692 45.638</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7530e35d-7cd8-43a2-80f6-93ca840238be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7530e35d-7cd8-43a2-80f6-93ca840238be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7530e35d-7cd8-43a2-80f6-93ca840238be">
											<gml:posList>35.66903257717726 139.74963389254302 46.163 35.66904446141535 139.74963984501855 46.163 35.66904270016846 139.7496347104316 46.163 35.669030815937795 139.74962876900298 46.163 35.66903257717726 139.74963389254302 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-872d5b9f-b5bc-43c8-b61a-7baac78965f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-872d5b9f-b5bc-43c8-b61a-7baac78965f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-872d5b9f-b5bc-43c8-b61a-7baac78965f1">
											<gml:posList>35.66909011996041 139.74950303581159 46.163 35.66908835872309 139.74949792331682 46.163 35.66904270016846 139.7496347104316 46.163 35.66904446141535 139.74963984501855 46.163 35.66909011996041 139.74950303581159 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37827ae1-788e-4cd7-8d77-4d602fce4793">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37827ae1-788e-4cd7-8d77-4d602fce4793">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37827ae1-788e-4cd7-8d77-4d602fce4793">
											<gml:posList>35.66903427005849 139.74942422522838 46.163 35.6690360132869 139.74942935982904 46.163 35.66910470389017 139.7494637848715 46.163 35.66910881261853 139.7494615824028 46.163 35.66903427005849 139.74942422522838 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35ac8806-4f46-4237-87a5-767dec1e2d6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35ac8806-4f46-4237-87a5-767dec1e2d6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35ac8806-4f46-4237-87a5-767dec1e2d6d">
											<gml:posList>35.66909011996041 139.74950303581159 46.163 35.669095277611596 139.7495056152027 46.163 35.669093426206345 139.74950045861752 46.163 35.66908835872309 139.74949792331682 46.163 35.66909011996041 139.74950303581159 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ad5d7c9-28a5-4ca9-bb2b-f048dc91da7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ad5d7c9-28a5-4ca9-bb2b-f048dc91da7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ad5d7c9-28a5-4ca9-bb2b-f048dc91da7c">
											<gml:posList>35.66910881261853 139.7494615824028 46.163 35.66910470389017 139.7494637848715 46.163 35.669093426206345 139.74950045861752 46.163 35.669095277611596 139.7495056152027 46.163 35.66910881261853 139.7494615824028 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bccc5fb-4800-4c22-9828-af2d6d713e98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bccc5fb-4800-4c22-9828-af2d6d713e98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bccc5fb-4800-4c22-9828-af2d6d713e98">
											<gml:posList>35.66895258962563 139.74959545841585 6.154 35.668964374684045 139.7496013667991 6.154 35.668964374684045 139.7496013667991 46.163 35.66895258962563 139.74959545841585 46.163 35.66895258962563 139.74959545841585 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67d8fff7-ea89-4a98-8fb3-b6191c3cd885">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67d8fff7-ea89-4a98-8fb3-b6191c3cd885">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67d8fff7-ea89-4a98-8fb3-b6191c3cd885">
											<gml:posList>35.668964374684045 139.7496013667991 6.154 35.66895999412327 139.74961449409844 6.154 35.66895999412327 139.74961449409844 46.163 35.668964374684045 139.7496013667991 46.163 35.668964374684045 139.7496013667991 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46553d03-b6ba-482a-81fd-e21b3de6c1b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46553d03-b6ba-482a-81fd-e21b3de6c1b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46553d03-b6ba-482a-81fd-e21b3de6c1b2">
											<gml:posList>35.668968564576986 139.74959921948692 46.163 35.668968564576986 139.74959921948692 45.638 35.66895677050476 139.74959331111307 45.638 35.66895677050476 139.74959331111307 46.163 35.668968564576986 139.74959921948692 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4026424e-7663-4e53-ac7f-95b387e0ef64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4026424e-7663-4e53-ac7f-95b387e0ef64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4026424e-7663-4e53-ac7f-95b387e0ef64">
											<gml:posList>35.668964175002735 139.74961234679645 46.163 35.668964175002735 139.74961234679645 45.638 35.668968564576986 139.74959921948692 45.638 35.668968564576986 139.74959921948692 46.163 35.668964175002735 139.74961234679645 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb860580-3fe7-4ca1-88c0-86f832326c5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb860580-3fe7-4ca1-88c0-86f832326c5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb860580-3fe7-4ca1-88c0-86f832326c5e">
											<gml:posList>35.668996664998176 139.74946337871444 6.154 35.66895258962563 139.74959545841585 6.154 35.66895258962563 139.74959545841585 46.163 35.668996664998176 139.74946337871444 46.163 35.668996664998176 139.74946337871444 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aab14de4-cabd-4c71-ad9c-ad65bfe27a4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aab14de4-cabd-4c71-ad9c-ad65bfe27a4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aab14de4-cabd-4c71-ad9c-ad65bfe27a4c">
											<gml:posList>35.66895677050476 139.74959331111307 46.163 35.66895677050476 139.74959331111307 45.638 35.66899843523532 139.74946846910103 45.638 35.66899843523532 139.74946846910103 46.163 35.66895677050476 139.74959331111307 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07d2b766-9ab5-4c68-8b2f-975975a11aa2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07d2b766-9ab5-4c68-8b2f-975975a11aa2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07d2b766-9ab5-4c68-8b2f-975975a11aa2">
											<gml:posList>35.66895999412327 139.74961449409844 6.154 35.66902771986811 139.7496484342468 6.154 35.66902771986811 139.7496484342468 46.163 35.66895999412327 139.74961449409844 46.163 35.66895999412327 139.74961449409844 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18c52315-d383-436d-b0b9-4dd96902b445">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18c52315-d383-436d-b0b9-4dd96902b445">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18c52315-d383-436d-b0b9-4dd96902b445">
											<gml:posList>35.66902595862925 139.74964331070677 46.163 35.66902595862925 139.74964331070677 45.638 35.668964175002735 139.74961234679645 45.638 35.668964175002735 139.74961234679645 46.163 35.66902595862925 139.74964331070677 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30d4819b-8c02-4ce6-9dd3-9101e6ccb766">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30d4819b-8c02-4ce6-9dd3-9101e6ccb766">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30d4819b-8c02-4ce6-9dd3-9101e6ccb766">
											<gml:posList>35.66901773718656 139.749473563244 6.154 35.668996664998176 139.74946337871444 6.154 35.668996664998176 139.74946337871444 46.163 35.66901773718656 139.749473563244 46.163 35.66901773718656 139.749473563244 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea9c2f5f-49e5-4156-96ea-681e416aab09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea9c2f5f-49e5-4156-96ea-681e416aab09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea9c2f5f-49e5-4156-96ea-681e416aab09">
											<gml:posList>35.66899843523532 139.74946846910103 46.163 35.66899843523532 139.74946846910103 45.638 35.66901950742327 139.74947865363217 45.638 35.66901950742327 139.74947865363217 46.163 35.66899843523532 139.74946846910103 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a94800ee-3a28-4c1d-b428-bd9bf59bfb73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a94800ee-3a28-4c1d-b428-bd9bf59bfb73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a94800ee-3a28-4c1d-b428-bd9bf59bfb73">
											<gml:posList>35.66903427005849 139.74942422522838 6.154 35.66901773718656 139.749473563244 6.154 35.66901773718656 139.749473563244 46.163 35.66903427005849 139.74942422522838 46.163 35.66903427005849 139.74942422522838 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4eeead0-5a25-47db-9f58-ebe582bcb857">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4eeead0-5a25-47db-9f58-ebe582bcb857">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4eeead0-5a25-47db-9f58-ebe582bcb857">
											<gml:posList>35.66901950742327 139.74947865363217 46.163 35.66901950742327 139.74947865363217 45.638 35.6690360132869 139.74942935982904 45.638 35.6690360132869 139.74942935982904 46.163 35.66901950742327 139.74947865363217 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6638a61d-ee17-4f95-9184-4179f0920432">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6638a61d-ee17-4f95-9184-4179f0920432">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6638a61d-ee17-4f95-9184-4179f0920432">
											<gml:posList>35.669030815937795 139.74962876900298 46.163 35.669030815937795 139.74962876900298 45.638 35.66902595862925 139.74964331070677 45.638 35.66902595862925 139.74964331070677 46.163 35.669030815937795 139.74962876900298 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4e1a063-dfd6-41f4-9e93-40dbdd22af11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4e1a063-dfd6-41f4-9e93-40dbdd22af11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4e1a063-dfd6-41f4-9e93-40dbdd22af11">
											<gml:posList>35.66902771986811 139.7496484342468 6.154 35.66903257717726 139.74963389254302 6.154 35.66903257717726 139.74963389254302 46.163 35.66902771986811 139.7496484342468 46.163 35.66902771986811 139.7496484342468 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6fcdec94-7727-4038-9428-8854c7d87750">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fcdec94-7727-4038-9428-8854c7d87750">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fcdec94-7727-4038-9428-8854c7d87750">
											<gml:posList>35.66904270016846 139.7496347104316 46.163 35.66904270016846 139.7496347104316 45.638 35.669030815937795 139.74962876900298 45.638 35.669030815937795 139.74962876900298 46.163 35.66904270016846 139.7496347104316 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f5df795-b5fe-4aa3-97dd-6750f9517e05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f5df795-b5fe-4aa3-97dd-6750f9517e05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f5df795-b5fe-4aa3-97dd-6750f9517e05">
											<gml:posList>35.66903257717726 139.74963389254302 6.154 35.66904446141535 139.74963984501855 6.154 35.66904446141535 139.74963984501855 46.163 35.66903257717726 139.74963389254302 46.163 35.66903257717726 139.74963389254302 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-667f3966-db7d-4414-b12f-aa2ca0314dea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-667f3966-db7d-4414-b12f-aa2ca0314dea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-667f3966-db7d-4414-b12f-aa2ca0314dea">
											<gml:posList>35.66908835872309 139.74949792331682 46.163 35.66908835872309 139.74949792331682 45.638 35.66904270016846 139.7496347104316 45.638 35.66904270016846 139.7496347104316 46.163 35.66908835872309 139.74949792331682 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-446391ec-1759-4eea-b764-a44b3fbff2fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-446391ec-1759-4eea-b764-a44b3fbff2fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-446391ec-1759-4eea-b764-a44b3fbff2fd">
											<gml:posList>35.66904446141535 139.74963984501855 6.154 35.66909011996041 139.74950303581159 6.154 35.66909011996041 139.74950303581159 46.163 35.66904446141535 139.74963984501855 46.163 35.66904446141535 139.74963984501855 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-011de64d-7dbd-49b8-9bc8-aafdd3904d36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-011de64d-7dbd-49b8-9bc8-aafdd3904d36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-011de64d-7dbd-49b8-9bc8-aafdd3904d36">
											<gml:posList>35.6690360132869 139.74942935982904 46.163 35.6690360132869 139.74942935982904 45.638 35.66910470389017 139.7494637848715 45.638 35.66910470389017 139.7494637848715 46.163 35.6690360132869 139.74942935982904 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61a78e37-818c-4888-aa24-ff6a2c05c1e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61a78e37-818c-4888-aa24-ff6a2c05c1e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61a78e37-818c-4888-aa24-ff6a2c05c1e2">
											<gml:posList>35.66910881261853 139.7494615824028 6.154 35.66903427005849 139.74942422522838 6.154 35.66903427005849 139.74942422522838 46.163 35.66910881261853 139.7494615824028 46.163 35.66910881261853 139.7494615824028 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e5b7d72-5272-4aad-846f-005a559ee00d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e5b7d72-5272-4aad-846f-005a559ee00d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e5b7d72-5272-4aad-846f-005a559ee00d">
											<gml:posList>35.669093426206345 139.74950045861752 46.163 35.669093426206345 139.74950045861752 45.638 35.66908835872309 139.74949792331682 45.638 35.66908835872309 139.74949792331682 46.163 35.669093426206345 139.74950045861752 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a88e934-fcbe-46b0-bba1-d497424c7779">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a88e934-fcbe-46b0-bba1-d497424c7779">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a88e934-fcbe-46b0-bba1-d497424c7779">
											<gml:posList>35.66909011996041 139.74950303581159 6.154 35.669095277611596 139.7495056152027 6.154 35.669095277611596 139.7495056152027 46.163 35.66909011996041 139.74950303581159 46.163 35.66909011996041 139.74950303581159 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-473fbb3c-e09c-4fa8-a8d9-c3b943215ed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-473fbb3c-e09c-4fa8-a8d9-c3b943215ed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-473fbb3c-e09c-4fa8-a8d9-c3b943215ed7">
											<gml:posList>35.66910470389017 139.7494637848715 46.163 35.66910470389017 139.7494637848715 45.638 35.669093426206345 139.74950045861752 45.638 35.669093426206345 139.74950045861752 46.163 35.66910470389017 139.7494637848715 46.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4acedbf2-903d-48de-ba73-b9958d282e22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4acedbf2-903d-48de-ba73-b9958d282e22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4acedbf2-903d-48de-ba73-b9958d282e22">
											<gml:posList>35.669095277611596 139.7495056152027 6.154 35.66910881261853 139.7494615824028 6.154 35.66910881261853 139.7494615824028 46.163 35.669095277611596 139.7495056152027 46.163 35.669095277611596 139.7495056152027 6.154</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8434</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">228.11125</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>