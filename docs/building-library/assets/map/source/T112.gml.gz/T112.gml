<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1db2cd67-01f3-4b80-90ff-8cb536d29863">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">21</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.673402108409974 139.73821048109315 0 35.67334033192876 139.73800986959253 0 35.673281881286336 139.73803690398694 0 35.673308178773524 139.7381222855226 0 35.67321256007087 139.73816650835343 0 35.67324804799208 139.73828173806476 0 35.673402108409974 139.73821048109315 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673402108409974 139.73821048109315 8.51 35.67324804799208 139.73828173806476 8.51 35.67321256007087 139.73816650835343 8.51 35.673308178773524 139.7381222855226 8.51 35.673281881286336 139.73803690398694 8.51 35.67334033192876 139.73800986959253 8.51 35.673402108409974 139.73821048109315 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673402108409974 139.73821048109315 8.51 35.67334033192876 139.73800986959253 8.51 35.67334033192876 139.73800986959253 29.119999999999997 35.673402108409974 139.73821048109315 29.119999999999997 35.673402108409974 139.73821048109315 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67334033192876 139.73800986959253 8.51 35.673281881286336 139.73803690398694 8.51 35.673281881286336 139.73803690398694 29.119999999999997 35.67334033192876 139.73800986959253 29.119999999999997 35.67334033192876 139.73800986959253 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673281881286336 139.73803690398694 8.51 35.673308178773524 139.7381222855226 8.51 35.673308178773524 139.7381222855226 29.119999999999997 35.673281881286336 139.73803690398694 29.119999999999997 35.673281881286336 139.73803690398694 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673308178773524 139.7381222855226 8.51 35.67321256007087 139.73816650835343 8.51 35.67321256007087 139.73816650835343 29.119999999999997 35.673308178773524 139.7381222855226 29.119999999999997 35.673308178773524 139.7381222855226 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67321256007087 139.73816650835343 8.51 35.67324804799208 139.73828173806476 8.51 35.67324804799208 139.73828173806476 29.119999999999997 35.67321256007087 139.73816650835343 29.119999999999997 35.67321256007087 139.73816650835343 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67324804799208 139.73828173806476 8.51 35.673402108409974 139.73821048109315 8.51 35.673402108409974 139.73821048109315 29.119999999999997 35.67324804799208 139.73828173806476 29.119999999999997 35.67324804799208 139.73828173806476 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673402108409974 139.73821048109315 29.119999999999997 35.67334033192876 139.73800986959253 29.119999999999997 35.673281881286336 139.73803690398694 29.119999999999997 35.673308178773524 139.7381222855226 29.119999999999997 35.67321256007087 139.73816650835343 29.119999999999997 35.67324804799208 139.73828173806476 29.119999999999997 35.673402108409974 139.73821048109315 29.119999999999997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a7ae3eb7-82ae-40d2-8330-dafd9afe15bc"/>
							<gml:surfaceMember xlink:href="#poly-b6bf5809-d12d-4f32-9f18-6fd9a8550d8b"/>
							<gml:surfaceMember xlink:href="#poly-f40d0b55-65ee-4905-9f5b-dffd405acf89"/>
							<gml:surfaceMember xlink:href="#poly-c68ac719-3cd9-4b66-ac05-d13c7024bf43"/>
							<gml:surfaceMember xlink:href="#poly-e9dcb622-a57c-474c-b4f3-19b4615acc57"/>
							<gml:surfaceMember xlink:href="#poly-5f8e170e-e9c8-47d0-9167-e9b09e1a6a36"/>
							<gml:surfaceMember xlink:href="#poly-4edc4f7d-584f-4e5a-b60d-dcea1f59e138"/>
							<gml:surfaceMember xlink:href="#poly-929e56a4-072b-4a26-af19-49299421c6e4"/>
							<gml:surfaceMember xlink:href="#poly-2f8300d1-0f2a-48dd-8a4e-104270fdc2c5"/>
							<gml:surfaceMember xlink:href="#poly-383d30b7-0211-4a03-b554-61b288e9aef1"/>
							<gml:surfaceMember xlink:href="#poly-09ed538b-7930-46c3-b648-a2f616d8d733"/>
							<gml:surfaceMember xlink:href="#poly-4330d7ec-0248-4970-a754-f4ffe0ccf255"/>
							<gml:surfaceMember xlink:href="#poly-93aff185-b88a-4ebe-ab5e-04d9706281ee"/>
							<gml:surfaceMember xlink:href="#poly-92a7b9fe-cbd6-4fe7-8b94-db56fc37ce83"/>
							<gml:surfaceMember xlink:href="#poly-aa66c423-12c8-40a9-a73c-61e1d1f2b449"/>
							<gml:surfaceMember xlink:href="#poly-032eb8e5-bf81-43fe-93d5-206ff66ad56a"/>
							<gml:surfaceMember xlink:href="#poly-157887fd-f320-4b5c-aa54-c8844b34ad35"/>
							<gml:surfaceMember xlink:href="#poly-36a4e897-3dc0-41bd-b873-b796edcdd619"/>
							<gml:surfaceMember xlink:href="#poly-45c003a9-e20c-4c33-af7e-5552b562548b"/>
							<gml:surfaceMember xlink:href="#poly-36b9cb8b-5880-4e39-80e3-c5c03f4b6ad1"/>
							<gml:surfaceMember xlink:href="#poly-79e995a8-3896-4eb7-a331-acf325f69c93"/>
							<gml:surfaceMember xlink:href="#poly-515cdc0b-87ae-4f81-9875-78881c3a90a8"/>
							<gml:surfaceMember xlink:href="#poly-f08ccb58-2af3-4192-958c-3c37f4aa5c35"/>
							<gml:surfaceMember xlink:href="#poly-294c0111-ded7-4a11-a0eb-3aff1be1e101"/>
							<gml:surfaceMember xlink:href="#poly-e7c2a3a3-7deb-4e6f-ac92-19f9a045bf28"/>
							<gml:surfaceMember xlink:href="#poly-dbad1b9a-2597-49f8-8003-8432f3154c47"/>
							<gml:surfaceMember xlink:href="#poly-7ac2f0d4-6536-4dc0-8e63-2b6cd2bd9a2f"/>
							<gml:surfaceMember xlink:href="#poly-6ef81a0a-02e3-4b87-a593-55b5d66c4004"/>
							<gml:surfaceMember xlink:href="#poly-c18d118d-21db-4bb6-bc33-1c341e331040"/>
							<gml:surfaceMember xlink:href="#poly-bc825971-0895-4e0c-b092-1a24094a0157"/>
							<gml:surfaceMember xlink:href="#poly-b2c185bd-8b45-4c5a-b2fb-d952daea221e"/>
							<gml:surfaceMember xlink:href="#poly-3440758e-978e-43f2-a062-89944e79c22f"/>
							<gml:surfaceMember xlink:href="#poly-40989d3e-4f8e-4cec-9d82-896c74e4e1cf"/>
							<gml:surfaceMember xlink:href="#poly-c854e58f-5e0e-4eec-92ca-ea6465d67305"/>
							<gml:surfaceMember xlink:href="#poly-47d8775e-8c3f-4914-9cfe-a78e8b6260d1"/>
							<gml:surfaceMember xlink:href="#poly-3c5338d8-c006-493e-b1bb-5b945bdd4703"/>
							<gml:surfaceMember xlink:href="#poly-4c8b8605-08ea-4b25-b2dc-135b195c1119"/>
							<gml:surfaceMember xlink:href="#poly-276ce998-1e4d-40ed-9b11-cd80fb645305"/>
							<gml:surfaceMember xlink:href="#poly-5b9fc11a-196c-4b18-a7bf-a82a77182e1c"/>
							<gml:surfaceMember xlink:href="#poly-cb6c97f0-f401-4979-b82f-18af5b582405"/>
							<gml:surfaceMember xlink:href="#poly-b37f1fb2-e010-443d-acde-86aef454a9ba"/>
							<gml:surfaceMember xlink:href="#poly-230ffb25-99e6-483a-892f-af39e7b914cc"/>
							<gml:surfaceMember xlink:href="#poly-697d2148-7c5c-4686-bee5-0577c4d5e178"/>
							<gml:surfaceMember xlink:href="#poly-b37d867d-4493-4478-aebf-f33cbe7d788a"/>
							<gml:surfaceMember xlink:href="#poly-3cbb3fd1-2d5d-49b7-a16f-a57c88d2b0ff"/>
							<gml:surfaceMember xlink:href="#poly-95e25ee7-f9d0-46be-9c31-ff6628e73370"/>
							<gml:surfaceMember xlink:href="#poly-ee574c08-1bba-4df6-9b5f-c1ba9b6af2f0"/>
							<gml:surfaceMember xlink:href="#poly-2256f9b1-b441-4ef1-889e-c9d2e7df277f"/>
							<gml:surfaceMember xlink:href="#poly-7ae50e6c-eb9d-42ae-bff3-9eaf7c77c833"/>
							<gml:surfaceMember xlink:href="#poly-501009dc-4b07-4adf-ae41-06fb8c30499f"/>
							<gml:surfaceMember xlink:href="#poly-0dfa46d5-9539-4e67-8fe5-18a2f936ae8d"/>
							<gml:surfaceMember xlink:href="#poly-b58a5167-3732-419b-be9d-081fd8f9f83d"/>
							<gml:surfaceMember xlink:href="#poly-93b4de45-d570-4a54-afb4-dd1736729067"/>
							<gml:surfaceMember xlink:href="#poly-bb6bdabf-7cfe-4d03-ac75-b12ea402c686"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1db2cd67-01f3-4b80-90ff-8cb536d29863_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7f903b0-43cf-4c53-8cbb-a23632d1a11b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67330600016897 139.73814852393303 29.26 35.673279257199596 139.7381608837561 29.26 35.673276437689736 139.73815174047022 29.26 35.67330318065818 139.73813938064455 29.26 35.67330600016897 139.73814852393303 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65c02bde-d43c-4ab6-96ef-735cc6e0e0cf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67328142033542 139.738183493699 35.219 35.67329969348551 139.73817503236182 35.219 35.67330329922093 139.73818674859027 35.219 35.67328501704757 139.7381951988892 35.219 35.67328142033542 139.738183493699 35.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c92ab33-4814-4637-9ec5-8b933e88d5de">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67331003071638 139.73811610823864 34.868 35.67330341568259 139.73809463033783 34.868 35.673321751913626 139.7380861578565 34.868 35.67332836694892 139.73810763576148 34.868 35.67331003071638 139.73811610823864 34.868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3650a4e7-c6eb-4d8a-986a-71d1b9e90efd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673350117536536 139.7380740391005 29.26 35.673355118323265 139.73807172440456 29.26 35.67336779716935 139.73811292446766 29.26 35.673362805386816 139.73811522810402 29.26 35.673350117536536 139.7380740391005 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9c204e3-622a-4dbf-b95e-8e5c10d66e3b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673355118323265 139.73807172440456 30.164 35.67335679426297 139.73807094914622 30.164 35.6733694821143 139.7381121381527 30.164 35.67336779716935 139.73811292446766 30.164 35.673355118323265 139.73807172440456 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db61d4cb-92fb-43ea-a50a-90b5521a461e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673366457864255 139.73811765403346 29.26 35.67336889063332 139.73811646915027 29.26 35.67338309668533 139.73816260527727 29.26 35.67338066391581 139.73816379015923 29.26 35.673366457864255 139.73811765403346 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-749ac332-62ee-4b93-af67-f1583b1bbb0c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67336889063332 139.73811646915027 30.164 35.6733722964995 139.7381147970577 30.164 35.67338650256088 139.73816094423302 30.164 35.67338309668533 139.73816260527727 30.164 35.67336889063332 139.73811646915027 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d4c9c46-d0c3-441d-9c28-7622a7da869a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d4c9c46-d0c3-441d-9c28-7622a7da869a_0">
											<gml:posList>35.673276437689736 139.73815174047022 31.903 35.673276437689736 139.73815174047022 29.26 35.673279257199596 139.7381608837561 29.26 35.673279257199596 139.7381608837561 31.903 35.673276437689736 139.73815174047022 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-083fdd4b-1a13-4cba-a81b-1408439084ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-083fdd4b-1a13-4cba-a81b-1408439084ad_0">
											<gml:posList>35.67328142033542 139.738183493699 37.975 35.67328142033542 139.738183493699 35.219 35.67328501704757 139.7381951988892 35.219 35.67328501704757 139.7381951988892 37.975 35.67328142033542 139.738183493699 37.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27818838-e40f-416b-b56a-e5329d4028d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27818838-e40f-416b-b56a-e5329d4028d7_0">
											<gml:posList>35.673276437689736 139.73815174047022 31.903 35.67330318065818 139.73813938064455 31.903 35.67330318065818 139.73813938064455 29.26 35.673276437689736 139.73815174047022 29.26 35.673276437689736 139.73815174047022 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-374eb3a8-cba6-4f1a-b5b9-e52c33a514ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-374eb3a8-cba6-4f1a-b5b9-e52c33a514ed_0">
											<gml:posList>35.67328142033542 139.738183493699 37.975 35.67329969348551 139.73817503236182 37.975 35.67329969348551 139.73817503236182 35.219 35.67328142033542 139.738183493699 35.219 35.67328142033542 139.738183493699 37.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6894612b-d9d9-4929-9e36-d63fcea4a857">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6894612b-d9d9-4929-9e36-d63fcea4a857_0">
											<gml:posList>35.673276437689736 139.73815174047022 31.903 35.673279257199596 139.7381608837561 31.903 35.67330600016897 139.73814852393303 31.903 35.67330318065818 139.73813938064455 31.903 35.673276437689736 139.73815174047022 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63ad771c-e180-4f2d-a17d-1b98eaadda1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63ad771c-e180-4f2d-a17d-1b98eaadda1f_0">
											<gml:posList>35.67328142033542 139.738183493699 37.975 35.67328501704757 139.7381951988892 37.975 35.67330329922093 139.73818674859027 37.975 35.67329969348551 139.73817503236182 37.975 35.67328142033542 139.738183493699 37.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-837905ff-7979-4cb3-81af-c9f8fdf8f0f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-837905ff-7979-4cb3-81af-c9f8fdf8f0f1_0">
											<gml:posList>35.67330600016897 139.73814852393303 31.903 35.673279257199596 139.7381608837561 31.903 35.673279257199596 139.7381608837561 29.26 35.67330600016897 139.73814852393303 29.26 35.67330600016897 139.73814852393303 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b4e3f4c-70fa-4b2a-a38c-69f6f55dd1bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b4e3f4c-70fa-4b2a-a38c-69f6f55dd1bc_0">
											<gml:posList>35.67328501704757 139.7381951988892 37.975 35.67328501704757 139.7381951988892 35.219 35.67330329922093 139.73818674859027 35.219 35.67330329922093 139.73818674859027 37.975 35.67328501704757 139.7381951988892 37.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90f1d688-d9b9-4f32-b917-41a35f350126">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90f1d688-d9b9-4f32-b917-41a35f350126_0">
											<gml:posList>35.67330329922093 139.73818674859027 37.975 35.67330329922093 139.73818674859027 35.219 35.67329969348551 139.73817503236182 35.219 35.67329969348551 139.73817503236182 37.975 35.67330329922093 139.73818674859027 37.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1f86fb5-fd52-45d8-a502-e50b4aa22f8f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1f86fb5-fd52-45d8-a502-e50b4aa22f8f_0">
											<gml:posList>35.67330600016897 139.73814852393303 31.903 35.67330600016897 139.73814852393303 29.26 35.67330318065818 139.73813938064455 29.26 35.67330318065818 139.73813938064455 31.903 35.67330600016897 139.73814852393303 31.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05237231-1833-4f2d-b5e2-0448e7d2d502">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05237231-1833-4f2d-b5e2-0448e7d2d502_0">
											<gml:posList>35.67331003071638 139.73811610823864 36.295 35.67330341568259 139.73809463033783 36.295 35.67330341568259 139.73809463033783 34.868 35.67331003071638 139.73811610823864 34.868 35.67331003071638 139.73811610823864 36.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f7a71fe-654e-48f1-b761-47dc0653bfb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f7a71fe-654e-48f1-b761-47dc0653bfb1_0">
											<gml:posList>35.67330341568259 139.73809463033783 36.295 35.673321751913626 139.7380861578565 36.295 35.673321751913626 139.7380861578565 34.868 35.67330341568259 139.73809463033783 34.868 35.67330341568259 139.73809463033783 36.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfdc70fa-3112-4323-8d0f-528b5de89d15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfdc70fa-3112-4323-8d0f-528b5de89d15_0">
											<gml:posList>35.673321751913626 139.7380861578565 36.295 35.67330341568259 139.73809463033783 36.295 35.67331003071638 139.73811610823864 36.295 35.67332836694892 139.73810763576148 36.295 35.673321751913626 139.7380861578565 36.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2af479d1-8769-426c-88ba-98eed8ee4cb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2af479d1-8769-426c-88ba-98eed8ee4cb8_0">
											<gml:posList>35.67332836694892 139.73810763576148 36.295 35.67331003071638 139.73811610823864 36.295 35.67331003071638 139.73811610823864 34.868 35.67332836694892 139.73810763576148 34.868 35.67332836694892 139.73810763576148 36.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79790618-7c19-484b-b484-5140d07b53f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79790618-7c19-484b-b484-5140d07b53f8_0">
											<gml:posList>35.67332836694892 139.73810763576148 36.295 35.67332836694892 139.73810763576148 34.868 35.673321751913626 139.7380861578565 34.868 35.673321751913626 139.7380861578565 36.295 35.67332836694892 139.73810763576148 36.295</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-557ba3c9-0cc0-4618-ac3a-96dd3b5f2e82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-557ba3c9-0cc0-4618-ac3a-96dd3b5f2e82_0">
											<gml:posList>35.673355118323265 139.73807172440456 30.164 35.673355118323265 139.73807172440456 29.26 35.673350117536536 139.7380740391005 29.26 35.673350117536536 139.7380740391005 30.384 35.67335679426297 139.73807094914622 30.384 35.67335679426297 139.73807094914622 30.164 35.673355118323265 139.73807172440456 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0c03e99-5acf-460c-82df-0b49a13e848c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0c03e99-5acf-460c-82df-0b49a13e848c_0">
											<gml:posList>35.673362805386816 139.73811522810402 30.384 35.673350117536536 139.7380740391005 30.384 35.673350117536536 139.7380740391005 29.26 35.673362805386816 139.73811522810402 29.26 35.673362805386816 139.73811522810402 30.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2cbc9e9f-d4be-4efd-8c72-6aa7da1d915f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2cbc9e9f-d4be-4efd-8c72-6aa7da1d915f_0">
											<gml:posList>35.6733694821143 139.7381121381527 30.384 35.67335679426297 139.73807094914622 30.384 35.673350117536536 139.7380740391005 30.384 35.673362805386816 139.73811522810402 30.384 35.6733694821143 139.7381121381527 30.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddefd320-5973-440d-9b6a-f08b82a2b02c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddefd320-5973-440d-9b6a-f08b82a2b02c_0">
											<gml:posList>35.67336779716935 139.73811292446766 29.26 35.673355118323265 139.73807172440456 29.26 35.673355118323265 139.73807172440456 30.164 35.67336779716935 139.73811292446766 30.164 35.67336779716935 139.73811292446766 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e116c80e-f3a9-4f8f-aed7-bb8e281bc556">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e116c80e-f3a9-4f8f-aed7-bb8e281bc556_0">
											<gml:posList>35.6733694821143 139.7381121381527 30.384 35.6733694821143 139.7381121381527 30.164 35.67335679426297 139.73807094914622 30.164 35.67335679426297 139.73807094914622 30.384 35.6733694821143 139.7381121381527 30.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ef60632-8f8e-4225-b889-0ca09abf22b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ef60632-8f8e-4225-b889-0ca09abf22b2_0">
											<gml:posList>35.67336779716935 139.73811292446766 30.164 35.6733694821143 139.7381121381527 30.164 35.6733694821143 139.7381121381527 30.384 35.673362805386816 139.73811522810402 30.384 35.673362805386816 139.73811522810402 29.26 35.67336779716935 139.73811292446766 29.26 35.67336779716935 139.73811292446766 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-118f6715-5ab2-4706-ab5c-6636501b9e1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-118f6715-5ab2-4706-ab5c-6636501b9e1f_0">
											<gml:posList>35.67336889063332 139.73811646915027 29.26 35.673366457864255 139.73811765403346 29.26 35.673366457864255 139.73811765403346 30.632 35.6733722964995 139.7381147970577 30.632 35.6733722964995 139.7381147970577 30.164 35.67336889063332 139.73811646915027 30.164 35.67336889063332 139.73811646915027 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-289a2b4e-ba8b-4942-92a0-bdef41d14cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-289a2b4e-ba8b-4942-92a0-bdef41d14cf0_0">
											<gml:posList>35.67338066391581 139.73816379015923 30.632 35.673366457864255 139.73811765403346 30.632 35.673366457864255 139.73811765403346 29.26 35.67338066391581 139.73816379015923 29.26 35.67338066391581 139.73816379015923 30.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08627936-536c-43d0-8804-35c81dc06d88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08627936-536c-43d0-8804-35c81dc06d88_0">
											<gml:posList>35.67338309668533 139.73816260527727 29.26 35.67336889063332 139.73811646915027 29.26 35.67336889063332 139.73811646915027 30.164 35.67338309668533 139.73816260527727 30.164 35.67338309668533 139.73816260527727 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5247f7c3-8322-4983-9c64-b37cc3b0b3d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5247f7c3-8322-4983-9c64-b37cc3b0b3d1_0">
											<gml:posList>35.67338650256088 139.73816094423302 30.632 35.6733722964995 139.7381147970577 30.632 35.673366457864255 139.73811765403346 30.632 35.67338066391581 139.73816379015923 30.632 35.67338650256088 139.73816094423302 30.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-000791cc-23c0-483e-af9e-2750dfe884e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-000791cc-23c0-483e-af9e-2750dfe884e0_0">
											<gml:posList>35.6733722964995 139.7381147970577 30.632 35.67338650256088 139.73816094423302 30.632 35.67338650256088 139.73816094423302 30.164 35.6733722964995 139.7381147970577 30.164 35.6733722964995 139.7381147970577 30.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2452c085-aeda-4c70-a790-bcf5697e30c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2452c085-aeda-4c70-a790-bcf5697e30c5_0">
											<gml:posList>35.67338309668533 139.73816260527727 30.164 35.67338650256088 139.73816094423302 30.164 35.67338650256088 139.73816094423302 30.632 35.67338066391581 139.73816379015923 30.632 35.67338066391581 139.73816379015923 29.26 35.67338309668533 139.73816260527727 29.26 35.67338309668533 139.73816260527727 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1db2cd67-01f3-4b80-90ff-8cb536d29863_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-401865c8-63ec-4b13-9f36-b8a04cee2ef7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67330016395082 139.73824570834392 29.26 35.67329291633946 139.7382221544133 29.26 35.673320794624644 139.73820926302156 29.26 35.67332804222977 139.73823280591256 29.26 35.67330016395082 139.73824570834392 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c561385-a43a-4383-a5af-9116c3cd47fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c561385-a43a-4383-a5af-9116c3cd47fd_0">
											<gml:posList>35.67329291633946 139.7382221544133 31.383 35.67329291633946 139.7382221544133 29.26 35.67330016395082 139.73824570834392 29.26 35.67330016395082 139.73824570834392 31.383 35.67329291633946 139.7382221544133 31.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91753002-f57c-4807-8220-39a167d0f454">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91753002-f57c-4807-8220-39a167d0f454_0">
											<gml:posList>35.673320794624644 139.73820926302156 31.383 35.673320794624644 139.73820926302156 29.26 35.67329291633946 139.7382221544133 29.26 35.67329291633946 139.7382221544133 31.383 35.673320794624644 139.73820926302156 31.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bac2240f-7682-4226-b082-1215e6b1acf2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bac2240f-7682-4226-b082-1215e6b1acf2_0">
											<gml:posList>35.673320794624644 139.73820926302156 31.383 35.67329291633946 139.7382221544133 31.383 35.67330016395082 139.73824570834392 31.383 35.67332804222977 139.73823280591256 31.383 35.673320794624644 139.73820926302156 31.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc17cdd0-7cc1-457c-b9b1-4712430809c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc17cdd0-7cc1-457c-b9b1-4712430809c2_0">
											<gml:posList>35.67330016395082 139.73824570834392 31.383 35.67330016395082 139.73824570834392 29.26 35.67332804222977 139.73823280591256 29.26 35.67332804222977 139.73823280591256 31.383 35.67330016395082 139.73824570834392 31.383</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b2c5b44-67a3-4d6e-9d24-3a775c9655e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b2c5b44-67a3-4d6e-9d24-3a775c9655e3_0">
											<gml:posList>35.67332804222977 139.73823280591256 29.26 35.673320794624644 139.73820926302156 29.26 35.673320794624644 139.73820926302156 31.383 35.67332804222977 139.73823280591256 31.383 35.67332804222977 139.73823280591256 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a7ae3eb7-82ae-40d2-8330-dafd9afe15bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7ae3eb7-82ae-40d2-8330-dafd9afe15bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7ae3eb7-82ae-40d2-8330-dafd9afe15bc">
											<gml:posList>35.67330817877352 139.7381222855226 8.51 35.673281881286336 139.7380369039869 8.51 35.673340331928756 139.73800986959253 8.51 35.67340210840998 139.73821048109315 8.51 35.67324804799207 139.73828173806476 8.51 35.67321256007087 139.7381665083534 8.51 35.67330817877352 139.7381222855226 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6bf5809-d12d-4f32-9f18-6fd9a8550d8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6bf5809-d12d-4f32-9f18-6fd9a8550d8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6bf5809-d12d-4f32-9f18-6fd9a8550d8b">
											<gml:posList>35.67321256007087 139.7381665083534 30.164 35.67324804799207 139.73828173806476 30.164 35.67325037757425 139.7382754387095 30.164 35.67321770915629 139.7381693522768 30.164 35.67321256007087 139.7381665083534 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f40d0b55-65ee-4905-9f5b-dffd405acf89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f40d0b55-65ee-4905-9f5b-dffd405acf89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f40d0b55-65ee-4905-9f5b-dffd405acf89">
											<gml:posList>35.67325037757425 139.7382754387095 29.26 35.67328392057881 139.7382106655134 29.26 35.67326993140688 139.73816520302356 29.26 35.67321770915629 139.7381693522768 29.26 35.67325037757425 139.7382754387095 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c68ac719-3cd9-4b66-ac05-d13c7024bf43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c68ac719-3cd9-4b66-ac05-d13c7024bf43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c68ac719-3cd9-4b66-ac05-d13c7024bf43">
											<gml:posList>35.67330817877352 139.7381222855226 30.164 35.67321256007087 139.7381665083534 30.164 35.67321770915629 139.7381693522768 30.164 35.67330585822182 139.73812859592275 30.164 35.67330958853838 139.73812686821339 30.164 35.673309091508656 139.7381252559909 30.164 35.67330817877352 139.7381222855226 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9dcb622-a57c-474c-b4f3-19b4615acc57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9dcb622-a57c-474c-b4f3-19b4615acc57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9dcb622-a57c-474c-b4f3-19b4615acc57">
											<gml:posList>35.67330585822182 139.73812859592275 29.26 35.67321770915629 139.7381693522768 29.26 35.67326993140688 139.73816520302356 29.26 35.67331497455704 139.73814437077885 29.26 35.67330958853838 139.73812686821339 29.26 35.67330585822182 139.73812859592275 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f8e170e-e9c8-47d0-9167-e9b09e1a6a36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f8e170e-e9c8-47d0-9167-e9b09e1a6a36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f8e170e-e9c8-47d0-9167-e9b09e1a6a36">
											<gml:posList>35.673274755867475 139.73816788163438 36.127 35.67326993140688 139.73816520302356 36.127 35.67328392057881 139.7382106655134 36.127 35.673286106251965 139.73820476400383 36.127 35.673274755867475 139.73816788163438 36.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4edc4f7d-584f-4e5a-b60d-dcea1f59e138">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4edc4f7d-584f-4e5a-b60d-dcea1f59e138">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4edc4f7d-584f-4e5a-b60d-dcea1f59e138">
											<gml:posList>35.673281881286336 139.7380369039869 30.164 35.67329750616649 139.73808764482166 30.164 35.67330123648246 139.7380859171106 30.164 35.67329983574724 139.73808135650359 30.164 35.673287030383484 139.73803975895106 30.164 35.673281881286336 139.7380369039869 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-929e56a4-072b-4a26-af19-49299421c6e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-929e56a4-072b-4a26-af19-49299421c6e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-929e56a4-072b-4a26-af19-49299421c6e4">
											<gml:posList>35.67326993140688 139.73816520302356 36.127 35.673274755867475 139.73816788163438 36.127 35.67331279790931 139.73815028332817 36.127 35.67331497455704 139.73814437077885 36.127 35.67326993140688 139.73816520302356 36.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f8300d1-0f2a-48dd-8a4e-104270fdc2c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f8300d1-0f2a-48dd-8a4e-104270fdc2c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f8300d1-0f2a-48dd-8a4e-104270fdc2c5">
											<gml:posList>35.673286106251965 139.73820476400383 35.219 35.67332415730413 139.73818715465526 35.219 35.67331279790931 139.73815028332817 35.219 35.673274755867475 139.73816788163438 35.219 35.673286106251965 139.73820476400383 35.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-383d30b7-0211-4a03-b554-61b288e9aef1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-383d30b7-0211-4a03-b554-61b288e9aef1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-383d30b7-0211-4a03-b554-61b288e9aef1">
											<gml:posList>35.67331048566507 139.7381214984698 35.23 35.67330058119861 139.73808935340088 35.23 35.67329750616649 139.73808764482166 35.23 35.673309091508656 139.7381252559909 35.23 35.67331048566507 139.7381214984698 35.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09ed538b-7930-46c3-b648-a2f616d8d733">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09ed538b-7930-46c3-b648-a2f616d8d733">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09ed538b-7930-46c3-b648-a2f616d8d733">
											<gml:posList>35.673325231256406 139.73807481984446 29.26 35.673287030383484 139.73803975895106 29.26 35.67329983574724 139.73808135650359 29.26 35.67330123648246 139.7380859171106 29.26 35.673325231256406 139.73807481984446 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4330d7ec-0248-4970-a754-f4ffe0ccf255">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4330d7ec-0248-4970-a754-f4ffe0ccf255">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4330d7ec-0248-4970-a754-f4ffe0ccf255">
											<gml:posList>35.673286106251965 139.73820476400383 36.127 35.67328392057881 139.7382106655134 36.127 35.67332897274176 139.73818982223324 36.127 35.67332415730413 139.73818715465526 36.127 35.673286106251965 139.73820476400383 36.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-93aff185-b88a-4ebe-ab5e-04d9706281ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93aff185-b88a-4ebe-ab5e-04d9706281ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93aff185-b88a-4ebe-ab5e-04d9706281ee">
											<gml:posList>35.673340331928756 139.73800986959253 30.164 35.673281881286336 139.7380369039869 30.164 35.673287030383484 139.73803975895106 30.164 35.673338011382974 139.73801617999843 30.164 35.673340331928756 139.73800986959253 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92a7b9fe-cbd6-4fe7-8b94-db56fc37ce83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92a7b9fe-cbd6-4fe7-8b94-db56fc37ce83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92a7b9fe-cbd6-4fe7-8b94-db56fc37ce83">
											<gml:posList>35.67330058119861 139.73808935340088 35.23 35.673323846115174 139.73807857735633 35.23 35.673325231256406 139.73807481984446 35.23 35.67329750616649 139.73808764482166 35.23 35.67330058119861 139.73808935340088 35.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa66c423-12c8-40a9-a73c-61e1d1f2b449">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa66c423-12c8-40a9-a73c-61e1d1f2b449">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa66c423-12c8-40a9-a73c-61e1d1f2b449">
											<gml:posList>35.673338011382974 139.73801617999843 29.26 35.673287030383484 139.73803975895106 29.26 35.673325231256406 139.73807481984446 29.26 35.673338011382974 139.73801617999843 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-032eb8e5-bf81-43fe-93d5-206ff66ad56a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-032eb8e5-bf81-43fe-93d5-206ff66ad56a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-032eb8e5-bf81-43fe-93d5-206ff66ad56a">
											<gml:posList>35.673333750584476 139.73811072243325 34.868 35.673323846115174 139.73807857735633 34.868 35.67330058119861 139.73808935340088 34.868 35.67331048566507 139.7381214984698 34.868 35.673333750584476 139.73811072243325 34.868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-157887fd-f320-4b5c-aa54-c8844b34ad35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-157887fd-f320-4b5c-aa54-c8844b34ad35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-157887fd-f320-4b5c-aa54-c8844b34ad35">
											<gml:posList>35.67331279790931 139.73815028332817 36.127 35.67332415730413 139.73818715465526 36.127 35.67331497455704 139.73814437077885 36.127 35.67331279790931 139.73815028332817 36.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36a4e897-3dc0-41bd-b873-b796edcdd619">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36a4e897-3dc0-41bd-b873-b796edcdd619">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36a4e897-3dc0-41bd-b873-b796edcdd619">
											<gml:posList>35.67332897274176 139.73818982223324 36.127 35.67331497455704 139.73814437077885 36.127 35.67332415730413 139.73818715465526 36.127 35.67332897274176 139.73818982223324 36.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45c003a9-e20c-4c33-af7e-5552b562548b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45c003a9-e20c-4c33-af7e-5552b562548b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45c003a9-e20c-4c33-af7e-5552b562548b">
											<gml:posList>35.67333681660254 139.73811243102483 29.26 35.673309091508656 139.7381252559909 29.26 35.67330958853838 139.73812686821339 29.26 35.67331497455704 139.73814437077885 29.26 35.67332897274176 139.73818982223324 29.26 35.67333681660254 139.73811243102483 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36b9cb8b-5880-4e39-80e3-c5c03f4b6ad1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36b9cb8b-5880-4e39-80e3-c5c03f4b6ad1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36b9cb8b-5880-4e39-80e3-c5c03f4b6ad1">
											<gml:posList>35.67333681660254 139.73811243102483 35.23 35.673333750584476 139.73811072243325 35.23 35.67331048566507 139.7381214984698 35.23 35.673309091508656 139.7381252559909 35.23 35.67333681660254 139.73811243102483 35.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79e995a8-3896-4eb7-a331-acf325f69c93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79e995a8-3896-4eb7-a331-acf325f69c93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79e995a8-3896-4eb7-a331-acf325f69c93">
											<gml:posList>35.6733969683394 139.7382076371499 29.26 35.673338011382974 139.73801617999843 29.26 35.673325231256406 139.73807481984446 29.26 35.67333681660254 139.73811243102483 29.26 35.67332897274176 139.73818982223324 29.26 35.67328392057881 139.7382106655134 29.26 35.67325037757425 139.7382754387095 29.26 35.6733969683394 139.7382076371499 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-515cdc0b-87ae-4f81-9875-78881c3a90a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-515cdc0b-87ae-4f81-9875-78881c3a90a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-515cdc0b-87ae-4f81-9875-78881c3a90a8">
											<gml:posList>35.67324804799207 139.73828173806476 30.164 35.67340210840998 139.73821048109315 30.164 35.6733969683394 139.7382076371499 30.164 35.67325037757425 139.7382754387095 30.164 35.67324804799207 139.73828173806476 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f08ccb58-2af3-4192-958c-3c37f4aa5c35">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f08ccb58-2af3-4192-958c-3c37f4aa5c35">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f08ccb58-2af3-4192-958c-3c37f4aa5c35">
											<gml:posList>35.673323846115174 139.73807857735633 35.23 35.673333750584476 139.73811072243325 35.23 35.67333681660254 139.73811243102483 35.23 35.673325231256406 139.73807481984446 35.23 35.673323846115174 139.73807857735633 35.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-294c0111-ded7-4a11-a0eb-3aff1be1e101">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-294c0111-ded7-4a11-a0eb-3aff1be1e101">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-294c0111-ded7-4a11-a0eb-3aff1be1e101">
											<gml:posList>35.67340210840998 139.73821048109315 30.164 35.673340331928756 139.73800986959253 30.164 35.673338011382974 139.73801617999843 30.164 35.6733969683394 139.7382076371499 30.164 35.67340210840998 139.73821048109315 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7c2a3a3-7deb-4e6f-ac92-19f9a045bf28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7c2a3a3-7deb-4e6f-ac92-19f9a045bf28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7c2a3a3-7deb-4e6f-ac92-19f9a045bf28">
											<gml:posList>35.673281881286336 139.7380369039869 8.51 35.673281881286336 139.7380369039869 30.164 35.673340331928756 139.73800986959253 30.164 35.673340331928756 139.73800986959253 8.51 35.673281881286336 139.7380369039869 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbad1b9a-2597-49f8-8003-8432f3154c47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbad1b9a-2597-49f8-8003-8432f3154c47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbad1b9a-2597-49f8-8003-8432f3154c47">
											<gml:posList>35.673338011382974 139.73801617999843 29.26 35.673338011382974 139.73801617999843 30.164 35.673287030383484 139.73803975895106 30.164 35.673287030383484 139.73803975895106 29.26 35.673338011382974 139.73801617999843 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ac2f0d4-6536-4dc0-8e63-2b6cd2bd9a2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ac2f0d4-6536-4dc0-8e63-2b6cd2bd9a2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ac2f0d4-6536-4dc0-8e63-2b6cd2bd9a2f">
											<gml:posList>35.67329983574724 139.73808135650359 30.164 35.67329983574724 139.73808135650359 29.26 35.673287030383484 139.73803975895106 29.26 35.673287030383484 139.73803975895106 30.164 35.67329983574724 139.73808135650359 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ef81a0a-02e3-4b87-a593-55b5d66c4004">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ef81a0a-02e3-4b87-a593-55b5d66c4004">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ef81a0a-02e3-4b87-a593-55b5d66c4004">
											<gml:posList>35.673281881286336 139.7380369039869 30.164 35.673281881286336 139.7380369039869 8.51 35.67330817877352 139.7381222855226 8.51 35.67330817877352 139.7381222855226 30.164 35.673309091508656 139.7381252559909 30.164 35.673309091508656 139.7381252559909 35.23 35.67329750616649 139.73808764482166 35.23 35.67329750616649 139.73808764482166 30.164 35.673281881286336 139.7380369039869 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c18d118d-21db-4bb6-bc33-1c341e331040">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c18d118d-21db-4bb6-bc33-1c341e331040">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c18d118d-21db-4bb6-bc33-1c341e331040">
											<gml:posList>35.67330123648246 139.7380859171106 30.164 35.67329750616649 139.73808764482166 30.164 35.67329750616649 139.73808764482166 35.23 35.673325231256406 139.73807481984446 35.23 35.673325231256406 139.73807481984446 29.26 35.67330123648246 139.7380859171106 29.26 35.67330123648246 139.7380859171106 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc825971-0895-4e0c-b092-1a24094a0157">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc825971-0895-4e0c-b092-1a24094a0157">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc825971-0895-4e0c-b092-1a24094a0157">
											<gml:posList>35.67330123648246 139.7380859171106 30.164 35.67330123648246 139.7380859171106 29.26 35.67329983574724 139.73808135650359 29.26 35.67329983574724 139.73808135650359 30.164 35.67330123648246 139.7380859171106 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2c185bd-8b45-4c5a-b2fb-d952daea221e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2c185bd-8b45-4c5a-b2fb-d952daea221e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2c185bd-8b45-4c5a-b2fb-d952daea221e">
											<gml:posList>35.673323846115174 139.73807857735633 34.868 35.673323846115174 139.73807857735633 35.23 35.67330058119861 139.73808935340088 35.23 35.67330058119861 139.73808935340088 34.868 35.673323846115174 139.73807857735633 34.868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3440758e-978e-43f2-a062-89944e79c22f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3440758e-978e-43f2-a062-89944e79c22f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3440758e-978e-43f2-a062-89944e79c22f">
											<gml:posList>35.673325231256406 139.73807481984446 35.23 35.67333681660254 139.73811243102483 35.23 35.67333681660254 139.73811243102483 29.26 35.673325231256406 139.73807481984446 29.26 35.673325231256406 139.73807481984446 35.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40989d3e-4f8e-4cec-9d82-896c74e4e1cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40989d3e-4f8e-4cec-9d82-896c74e4e1cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40989d3e-4f8e-4cec-9d82-896c74e4e1cf">
											<gml:posList>35.673333750584476 139.73811072243325 34.868 35.673333750584476 139.73811072243325 35.23 35.673323846115174 139.73807857735633 35.23 35.673323846115174 139.73807857735633 34.868 35.673333750584476 139.73811072243325 34.868</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c854e58f-5e0e-4eec-92ca-ea6465d67305">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c854e58f-5e0e-4eec-92ca-ea6465d67305">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c854e58f-5e0e-4eec-92ca-ea6465d67305">
											<gml:posList>35.67331048566507 139.7381214984698 35.23 35.67331048566507 139.7381214984698 34.868 35.67330058119861 139.73808935340088 34.868 35.67330058119861 139.73808935340088 35.23 35.67331048566507 139.7381214984698 35.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47d8775e-8c3f-4914-9cfe-a78e8b6260d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47d8775e-8c3f-4914-9cfe-a78e8b6260d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47d8775e-8c3f-4914-9cfe-a78e8b6260d1">
											<gml:posList>35.67340210840998 139.73821048109315 8.51 35.673340331928756 139.73800986959253 8.51 35.673340331928756 139.73800986959253 30.164 35.67340210840998 139.73821048109315 30.164 35.67340210840998 139.73821048109315 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c5338d8-c006-493e-b1bb-5b945bdd4703">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c5338d8-c006-493e-b1bb-5b945bdd4703">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c5338d8-c006-493e-b1bb-5b945bdd4703">
											<gml:posList>35.6733969683394 139.7382076371499 29.26 35.6733969683394 139.7382076371499 30.164 35.673338011382974 139.73801617999843 30.164 35.673338011382974 139.73801617999843 29.26 35.6733969683394 139.7382076371499 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c8b8605-08ea-4b25-b2dc-135b195c1119">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c8b8605-08ea-4b25-b2dc-135b195c1119">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c8b8605-08ea-4b25-b2dc-135b195c1119">
											<gml:posList>35.673333750584476 139.73811072243325 35.23 35.673333750584476 139.73811072243325 34.868 35.67331048566507 139.7381214984698 34.868 35.67331048566507 139.7381214984698 35.23 35.673333750584476 139.73811072243325 35.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-276ce998-1e4d-40ed-9b11-cd80fb645305">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-276ce998-1e4d-40ed-9b11-cd80fb645305">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-276ce998-1e4d-40ed-9b11-cd80fb645305">
											<gml:posList>35.673309091508656 139.7381252559909 30.164 35.673309091508656 139.7381252559909 29.26 35.67333681660254 139.73811243102483 29.26 35.67333681660254 139.73811243102483 35.23 35.673309091508656 139.7381252559909 35.23 35.673309091508656 139.7381252559909 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b9fc11a-196c-4b18-a7bf-a82a77182e1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b9fc11a-196c-4b18-a7bf-a82a77182e1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b9fc11a-196c-4b18-a7bf-a82a77182e1c">
											<gml:posList>35.67330958853838 139.73812686821339 30.164 35.67330958853838 139.73812686821339 29.26 35.673309091508656 139.7381252559909 29.26 35.673309091508656 139.7381252559909 30.164 35.67330958853838 139.73812686821339 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb6c97f0-f401-4979-b82f-18af5b582405">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb6c97f0-f401-4979-b82f-18af5b582405">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb6c97f0-f401-4979-b82f-18af5b582405">
											<gml:posList>35.67330958853838 139.73812686821339 29.26 35.67330958853838 139.73812686821339 30.164 35.67330585822182 139.73812859592275 30.164 35.67330585822182 139.73812859592275 29.26 35.67330958853838 139.73812686821339 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b37f1fb2-e010-443d-acde-86aef454a9ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b37f1fb2-e010-443d-acde-86aef454a9ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b37f1fb2-e010-443d-acde-86aef454a9ba">
											<gml:posList>35.67330817877352 139.7381222855226 8.51 35.67321256007087 139.7381665083534 8.51 35.67321256007087 139.7381665083534 30.164 35.67330817877352 139.7381222855226 30.164 35.67330817877352 139.7381222855226 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-230ffb25-99e6-483a-892f-af39e7b914cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-230ffb25-99e6-483a-892f-af39e7b914cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-230ffb25-99e6-483a-892f-af39e7b914cc">
											<gml:posList>35.67330585822182 139.73812859592275 30.164 35.67321770915629 139.7381693522768 30.164 35.67321770915629 139.7381693522768 29.26 35.67330585822182 139.73812859592275 29.26 35.67330585822182 139.73812859592275 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-697d2148-7c5c-4686-bee5-0577c4d5e178">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-697d2148-7c5c-4686-bee5-0577c4d5e178">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-697d2148-7c5c-4686-bee5-0577c4d5e178">
											<gml:posList>35.67331497455704 139.73814437077885 36.127 35.67331497455704 139.73814437077885 29.26 35.67326993140688 139.73816520302356 29.26 35.67326993140688 139.73816520302356 36.127 35.67331497455704 139.73814437077885 36.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b37d867d-4493-4478-aebf-f33cbe7d788a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b37d867d-4493-4478-aebf-f33cbe7d788a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b37d867d-4493-4478-aebf-f33cbe7d788a">
											<gml:posList>35.67331279790931 139.73815028332817 35.219 35.67331279790931 139.73815028332817 36.127 35.673274755867475 139.73816788163438 36.127 35.673274755867475 139.73816788163438 35.219 35.67331279790931 139.73815028332817 35.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cbb3fd1-2d5d-49b7-a16f-a57c88d2b0ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cbb3fd1-2d5d-49b7-a16f-a57c88d2b0ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cbb3fd1-2d5d-49b7-a16f-a57c88d2b0ff">
											<gml:posList>35.67332897274176 139.73818982223324 29.26 35.67331497455704 139.73814437077885 29.26 35.67331497455704 139.73814437077885 36.127 35.67332897274176 139.73818982223324 36.127 35.67332897274176 139.73818982223324 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95e25ee7-f9d0-46be-9c31-ff6628e73370">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95e25ee7-f9d0-46be-9c31-ff6628e73370">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95e25ee7-f9d0-46be-9c31-ff6628e73370">
											<gml:posList>35.67332415730413 139.73818715465526 35.219 35.67332415730413 139.73818715465526 36.127 35.67331279790931 139.73815028332817 36.127 35.67331279790931 139.73815028332817 35.219 35.67332415730413 139.73818715465526 35.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee574c08-1bba-4df6-9b5f-c1ba9b6af2f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee574c08-1bba-4df6-9b5f-c1ba9b6af2f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee574c08-1bba-4df6-9b5f-c1ba9b6af2f0">
											<gml:posList>35.673274755867475 139.73816788163438 35.219 35.673274755867475 139.73816788163438 36.127 35.673286106251965 139.73820476400383 36.127 35.673286106251965 139.73820476400383 35.219 35.673274755867475 139.73816788163438 35.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2256f9b1-b441-4ef1-889e-c9d2e7df277f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2256f9b1-b441-4ef1-889e-c9d2e7df277f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2256f9b1-b441-4ef1-889e-c9d2e7df277f">
											<gml:posList>35.67326993140688 139.73816520302356 29.26 35.67328392057881 139.7382106655134 29.26 35.67328392057881 139.7382106655134 36.127 35.67326993140688 139.73816520302356 36.127 35.67326993140688 139.73816520302356 29.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ae50e6c-eb9d-42ae-bff3-9eaf7c77c833">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ae50e6c-eb9d-42ae-bff3-9eaf7c77c833">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ae50e6c-eb9d-42ae-bff3-9eaf7c77c833">
											<gml:posList>35.673286106251965 139.73820476400383 35.219 35.673286106251965 139.73820476400383 36.127 35.67332415730413 139.73818715465526 36.127 35.67332415730413 139.73818715465526 35.219 35.673286106251965 139.73820476400383 35.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-501009dc-4b07-4adf-ae41-06fb8c30499f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-501009dc-4b07-4adf-ae41-06fb8c30499f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-501009dc-4b07-4adf-ae41-06fb8c30499f">
											<gml:posList>35.67328392057881 139.7382106655134 36.127 35.67328392057881 139.7382106655134 29.26 35.67332897274176 139.73818982223324 29.26 35.67332897274176 139.73818982223324 36.127 35.67328392057881 139.7382106655134 36.127</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0dfa46d5-9539-4e67-8fe5-18a2f936ae8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dfa46d5-9539-4e67-8fe5-18a2f936ae8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dfa46d5-9539-4e67-8fe5-18a2f936ae8d">
											<gml:posList>35.67325037757425 139.7382754387095 30.164 35.67325037757425 139.7382754387095 29.26 35.67321770915629 139.7381693522768 29.26 35.67321770915629 139.7381693522768 30.164 35.67325037757425 139.7382754387095 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b58a5167-3732-419b-be9d-081fd8f9f83d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b58a5167-3732-419b-be9d-081fd8f9f83d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b58a5167-3732-419b-be9d-081fd8f9f83d">
											<gml:posList>35.67321256007087 139.7381665083534 8.51 35.67324804799207 139.73828173806476 8.51 35.67324804799207 139.73828173806476 30.164 35.67321256007087 139.7381665083534 30.164 35.67321256007087 139.7381665083534 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93b4de45-d570-4a54-afb4-dd1736729067">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93b4de45-d570-4a54-afb4-dd1736729067">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93b4de45-d570-4a54-afb4-dd1736729067">
											<gml:posList>35.6733969683394 139.7382076371499 30.164 35.6733969683394 139.7382076371499 29.26 35.67325037757425 139.7382754387095 29.26 35.67325037757425 139.7382754387095 30.164 35.6733969683394 139.7382076371499 30.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb6bdabf-7cfe-4d03-ac75-b12ea402c686">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb6bdabf-7cfe-4d03-ac75-b12ea402c686">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb6bdabf-7cfe-4d03-ac75-b12ea402c686">
											<gml:posList>35.67324804799207 139.73828173806476 8.51 35.67340210840998 139.73821048109315 8.51 35.67340210840998 139.73821048109315 30.164 35.67324804799207 139.73828173806476 30.164 35.67324804799207 139.73828173806476 8.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10078</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">122.3684</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>