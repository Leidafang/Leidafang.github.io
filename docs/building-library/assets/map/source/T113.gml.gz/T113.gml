<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1e74c9d0-056a-4068-aa38-2136924367f8">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">41.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66813865846312 139.7491172676038 0 35.66816419134326 139.74903564431756 0 35.66810158839416 139.74900623954719 0 35.668076370310835 139.74908685726743 0 35.66811007553466 139.74910384365984 0 35.66813865846312 139.7491172676038 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66813865846312 139.7491172676038 5.35 35.66811007553466 139.74910384365984 5.35 35.668076370310835 139.74908685726743 5.35 35.66810158839416 139.74900623954719 5.35 35.66816419134326 139.74903564431756 5.35 35.66813865846312 139.7491172676038 5.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66813865846312 139.7491172676038 5.35 35.66816419134326 139.74903564431756 5.35 35.66816419134326 139.74903564431756 46.58 35.66813865846312 139.7491172676038 46.58 35.66813865846312 139.7491172676038 5.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66816419134326 139.74903564431756 5.35 35.66810158839416 139.74900623954719 5.35 35.66810158839416 139.74900623954719 46.58 35.66816419134326 139.74903564431756 46.58 35.66816419134326 139.74903564431756 5.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66810158839416 139.74900623954719 5.35 35.668076370310835 139.74908685726743 5.35 35.668076370310835 139.74908685726743 46.58 35.66810158839416 139.74900623954719 46.58 35.66810158839416 139.74900623954719 5.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668076370310835 139.74908685726743 5.35 35.66811007553466 139.74910384365984 5.35 35.66811007553466 139.74910384365984 46.58 35.668076370310835 139.74908685726743 46.58 35.668076370310835 139.74908685726743 5.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66811007553466 139.74910384365984 5.35 35.66813865846312 139.7491172676038 5.35 35.66813865846312 139.7491172676038 46.58 35.66811007553466 139.74910384365984 46.58 35.66811007553466 139.74910384365984 5.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66813865846312 139.7491172676038 46.58 35.66816419134326 139.74903564431756 46.58 35.66810158839416 139.74900623954719 46.58 35.668076370310835 139.74908685726743 46.58 35.66811007553466 139.74910384365984 46.58 35.66813865846312 139.7491172676038 46.58</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9e8aa638-cfa2-41c6-bd4b-b19ffe5aee24"/>
							<gml:surfaceMember xlink:href="#poly-ee30da39-c99a-4b67-be4a-4daf7fbd1c7c"/>
							<gml:surfaceMember xlink:href="#poly-79dc093c-b3e1-4199-90dc-feb39003bdf1"/>
							<gml:surfaceMember xlink:href="#poly-b975b153-97bb-439b-9f9d-6bed123c3a54"/>
							<gml:surfaceMember xlink:href="#poly-74c18c2b-e913-4dfd-8d58-d1bdeee8053f"/>
							<gml:surfaceMember xlink:href="#poly-f7734724-6b02-4988-8014-e918682e080c"/>
							<gml:surfaceMember xlink:href="#poly-5d64d59e-aa61-41d8-abe0-e013264f9cc8"/>
							<gml:surfaceMember xlink:href="#poly-69c73fe5-e0f3-4d77-9288-40a5843ad1c0"/>
							<gml:surfaceMember xlink:href="#poly-f4377ac6-6f39-40ac-bfd8-ab2a81d14932"/>
							<gml:surfaceMember xlink:href="#poly-990eb118-bb97-41e8-9dee-ecb1d943a878"/>
							<gml:surfaceMember xlink:href="#poly-828ef170-fd2e-4e83-a815-4133302f2482"/>
							<gml:surfaceMember xlink:href="#poly-b0f36524-7bfa-4c8c-9c2b-cf34f8f35b2b"/>
							<gml:surfaceMember xlink:href="#poly-a9aa7e73-4fa6-4cff-b25b-87d4ea866628"/>
							<gml:surfaceMember xlink:href="#poly-0af192d8-f108-474e-931a-6eb43e362f59"/>
							<gml:surfaceMember xlink:href="#poly-5435d04c-e40f-4581-af14-e19f86755e83"/>
							<gml:surfaceMember xlink:href="#poly-0f249bcf-e022-4b15-8e87-1e853cae851a"/>
							<gml:surfaceMember xlink:href="#poly-fac63a84-58cd-4a78-8d44-c79b5aca69ac"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9e8aa638-cfa2-41c6-bd4b-b19ffe5aee24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e8aa638-cfa2-41c6-bd4b-b19ffe5aee24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e8aa638-cfa2-41c6-bd4b-b19ffe5aee24">
											<gml:posList>35.66813865846312 139.74911726760382 5.35 35.66811007553466 139.74910384365984 5.35 35.668076370310835 139.74908685726743 5.35 35.66810158839413 139.74900623954716 5.35 35.668164191343244 139.74903564431756 5.35 35.66813865846312 139.74911726760382 5.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee30da39-c99a-4b67-be4a-4daf7fbd1c7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee30da39-c99a-4b67-be4a-4daf7fbd1c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee30da39-c99a-4b67-be4a-4daf7fbd1c7c">
											<gml:posList>35.66810158839413 139.74900623954716 47.6 35.66810355720032 139.74901168312832 47.6 35.66815974927646 139.74903807909746 47.6 35.668164191343244 139.74903564431756 47.6 35.66810158839413 139.74900623954716 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79dc093c-b3e1-4199-90dc-feb39003bdf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79dc093c-b3e1-4199-90dc-feb39003bdf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79dc093c-b3e1-4199-90dc-feb39003bdf1">
											<gml:posList>35.668076370310835 139.74908685726743 47.6 35.66808077639332 139.74908452194407 47.6 35.66810355720032 139.74901168312832 47.6 35.66810158839413 139.74900623954716 47.6 35.668076370310835 139.74908685726743 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b975b153-97bb-439b-9f9d-6bed123c3a54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b975b153-97bb-439b-9f9d-6bed123c3a54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b975b153-97bb-439b-9f9d-6bed123c3a54">
											<gml:posList>35.66808077639332 139.74908452194407 47.133 35.66811130766474 139.74909991000814 47.133 35.66813667163425 139.7491118240366 47.133 35.66815974927646 139.74903807909746 47.133 35.66810355720032 139.74901168312832 47.133 35.66808077639332 139.74908452194407 47.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74c18c2b-e913-4dfd-8d58-d1bdeee8053f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74c18c2b-e913-4dfd-8d58-d1bdeee8053f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74c18c2b-e913-4dfd-8d58-d1bdeee8053f">
											<gml:posList>35.668164191343244 139.74903564431756 47.6 35.66815974927646 139.74903807909746 47.6 35.66813667163425 139.7491118240366 47.6 35.66813865846312 139.74911726760382 47.6 35.668164191343244 139.74903564431756 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7734724-6b02-4988-8014-e918682e080c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7734724-6b02-4988-8014-e918682e080c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7734724-6b02-4988-8014-e918682e080c">
											<gml:posList>35.66811007553466 139.74910384365984 47.6 35.66811130766474 139.74909991000814 47.6 35.66808077639332 139.74908452194407 47.6 35.668076370310835 139.74908685726743 47.6 35.66811007553466 139.74910384365984 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d64d59e-aa61-41d8-abe0-e013264f9cc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d64d59e-aa61-41d8-abe0-e013264f9cc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d64d59e-aa61-41d8-abe0-e013264f9cc8">
											<gml:posList>35.66811007553466 139.74910384365984 47.6 35.66813865846312 139.74911726760382 47.6 35.66813667163425 139.7491118240366 47.6 35.66811130766474 139.74909991000814 47.6 35.66811007553466 139.74910384365984 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69c73fe5-e0f3-4d77-9288-40a5843ad1c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69c73fe5-e0f3-4d77-9288-40a5843ad1c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69c73fe5-e0f3-4d77-9288-40a5843ad1c0">
											<gml:posList>35.66810158839413 139.74900623954716 5.35 35.668076370310835 139.74908685726743 5.35 35.668076370310835 139.74908685726743 47.6 35.66810158839413 139.74900623954716 47.6 35.66810158839413 139.74900623954716 5.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4377ac6-6f39-40ac-bfd8-ab2a81d14932">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4377ac6-6f39-40ac-bfd8-ab2a81d14932">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4377ac6-6f39-40ac-bfd8-ab2a81d14932">
											<gml:posList>35.66815974927646 139.74903807909746 47.6 35.66815974927646 139.74903807909746 47.133 35.66813667163425 139.7491118240366 47.133 35.66813667163425 139.7491118240366 47.6 35.66815974927646 139.74903807909746 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-990eb118-bb97-41e8-9dee-ecb1d943a878">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-990eb118-bb97-41e8-9dee-ecb1d943a878">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-990eb118-bb97-41e8-9dee-ecb1d943a878">
											<gml:posList>35.66808077639332 139.74908452194407 47.6 35.66808077639332 139.74908452194407 47.133 35.66810355720032 139.74901168312832 47.133 35.66810355720032 139.74901168312832 47.6 35.66808077639332 139.74908452194407 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-828ef170-fd2e-4e83-a815-4133302f2482">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-828ef170-fd2e-4e83-a815-4133302f2482">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-828ef170-fd2e-4e83-a815-4133302f2482">
											<gml:posList>35.668076370310835 139.74908685726743 5.35 35.66811007553466 139.74910384365984 5.35 35.66811007553466 139.74910384365984 47.6 35.668076370310835 139.74908685726743 47.6 35.668076370310835 139.74908685726743 5.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0f36524-7bfa-4c8c-9c2b-cf34f8f35b2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0f36524-7bfa-4c8c-9c2b-cf34f8f35b2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0f36524-7bfa-4c8c-9c2b-cf34f8f35b2b">
											<gml:posList>35.66811130766474 139.74909991000814 47.6 35.66811130766474 139.74909991000814 47.133 35.66808077639332 139.74908452194407 47.133 35.66808077639332 139.74908452194407 47.6 35.66811130766474 139.74909991000814 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9aa7e73-4fa6-4cff-b25b-87d4ea866628">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9aa7e73-4fa6-4cff-b25b-87d4ea866628">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9aa7e73-4fa6-4cff-b25b-87d4ea866628">
											<gml:posList>35.66813667163425 139.7491118240366 47.6 35.66813667163425 139.7491118240366 47.133 35.66811130766474 139.74909991000814 47.133 35.66811130766474 139.74909991000814 47.6 35.66813667163425 139.7491118240366 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0af192d8-f108-474e-931a-6eb43e362f59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0af192d8-f108-474e-931a-6eb43e362f59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0af192d8-f108-474e-931a-6eb43e362f59">
											<gml:posList>35.66811007553466 139.74910384365984 5.35 35.66813865846312 139.74911726760382 5.35 35.66813865846312 139.74911726760382 47.6 35.66811007553466 139.74910384365984 47.6 35.66811007553466 139.74910384365984 5.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5435d04c-e40f-4581-af14-e19f86755e83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5435d04c-e40f-4581-af14-e19f86755e83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5435d04c-e40f-4581-af14-e19f86755e83">
											<gml:posList>35.66810355720032 139.74901168312832 47.6 35.66810355720032 139.74901168312832 47.133 35.66815974927646 139.74903807909746 47.133 35.66815974927646 139.74903807909746 47.6 35.66810355720032 139.74901168312832 47.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f249bcf-e022-4b15-8e87-1e853cae851a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f249bcf-e022-4b15-8e87-1e853cae851a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f249bcf-e022-4b15-8e87-1e853cae851a">
											<gml:posList>35.668164191343244 139.74903564431756 5.35 35.66810158839413 139.74900623954716 5.35 35.66810158839413 139.74900623954716 47.6 35.668164191343244 139.74903564431756 47.6 35.668164191343244 139.74903564431756 5.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fac63a84-58cd-4a78-8d44-c79b5aca69ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fac63a84-58cd-4a78-8d44-c79b5aca69ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fac63a84-58cd-4a78-8d44-c79b5aca69ac">
											<gml:posList>35.66813865846312 139.74911726760382 5.35 35.668164191343244 139.74903564431756 5.35 35.668164191343244 139.74903564431756 47.6 35.66813865846312 139.74911726760382 47.6 35.66813865846312 139.74911726760382 5.35</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6552</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1233.94658</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>