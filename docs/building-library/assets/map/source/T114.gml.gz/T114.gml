<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1e9386f5-0f53-4594-97f1-a77bc8b583e9">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:measuredHeight uom="m">8.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67002547161603 139.74648402306497 0 35.67005460864914 139.74651547321704 0 35.67010062241274 139.74645113438373 0 35.670071395305534 139.7464197947969 0 35.67002547161603 139.74648402306497 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002547161603 139.74648402306497 6.117 35.670071395305534 139.7464197947969 6.117 35.67010062241274 139.74645113438373 6.117 35.67005460864914 139.74651547321704 6.117 35.67002547161603 139.74648402306497 6.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002547161603 139.74648402306497 6.117 35.67005460864914 139.74651547321704 6.117 35.67005460864914 139.74651547321704 14.32 35.67002547161603 139.74648402306497 14.32 35.67002547161603 139.74648402306497 6.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67005460864914 139.74651547321704 6.117 35.67010062241274 139.74645113438373 6.117 35.67010062241274 139.74645113438373 14.32 35.67005460864914 139.74651547321704 14.32 35.67005460864914 139.74651547321704 6.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67010062241274 139.74645113438373 6.117 35.670071395305534 139.7464197947969 6.117 35.670071395305534 139.7464197947969 14.32 35.67010062241274 139.74645113438373 14.32 35.67010062241274 139.74645113438373 6.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670071395305534 139.7464197947969 6.117 35.67002547161603 139.74648402306497 6.117 35.67002547161603 139.74648402306497 14.32 35.670071395305534 139.7464197947969 14.32 35.670071395305534 139.7464197947969 6.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002547161603 139.74648402306497 14.32 35.67005460864914 139.74651547321704 14.32 35.67010062241274 139.74645113438373 14.32 35.670071395305534 139.7464197947969 14.32 35.67002547161603 139.74648402306497 14.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0d186ae6-59a1-4527-8c90-e51ddf4e8aa2"/>
							<gml:surfaceMember xlink:href="#poly-b32b8ac9-0c7c-45e4-bdfa-13f80437f943"/>
							<gml:surfaceMember xlink:href="#poly-e27d89cb-3c18-48b1-b16b-57823547f440"/>
							<gml:surfaceMember xlink:href="#poly-11c93537-6c22-42d8-9200-03e2e9cbdd5a"/>
							<gml:surfaceMember xlink:href="#poly-ffe6b953-d591-4686-906c-f4f915ef2172"/>
							<gml:surfaceMember xlink:href="#poly-5fc0ecdf-d4c2-4264-9db2-cd900b01c625"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0d186ae6-59a1-4527-8c90-e51ddf4e8aa2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d186ae6-59a1-4527-8c90-e51ddf4e8aa2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d186ae6-59a1-4527-8c90-e51ddf4e8aa2">
											<gml:posList>35.67002547161603 139.74648402306497 6.117 35.67007139530554 139.74641979479688 6.117 35.67010062241271 139.74645113438373 6.117 35.67005460864912 139.74651547321704 6.117 35.67002547161603 139.74648402306497 6.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b32b8ac9-0c7c-45e4-bdfa-13f80437f943">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b32b8ac9-0c7c-45e4-bdfa-13f80437f943">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b32b8ac9-0c7c-45e4-bdfa-13f80437f943">
											<gml:posList>35.67007139530554 139.74641979479688 14.2 35.67002547161603 139.74648402306497 14.2 35.67005460864912 139.74651547321704 14.2 35.67010062241271 139.74645113438373 14.2 35.67007139530554 139.74641979479688 14.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e27d89cb-3c18-48b1-b16b-57823547f440">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e27d89cb-3c18-48b1-b16b-57823547f440">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e27d89cb-3c18-48b1-b16b-57823547f440">
											<gml:posList>35.67002547161603 139.74648402306497 6.117 35.67005460864912 139.74651547321704 6.117 35.67005460864912 139.74651547321704 14.2 35.67002547161603 139.74648402306497 14.2 35.67002547161603 139.74648402306497 6.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11c93537-6c22-42d8-9200-03e2e9cbdd5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11c93537-6c22-42d8-9200-03e2e9cbdd5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11c93537-6c22-42d8-9200-03e2e9cbdd5a">
											<gml:posList>35.67010062241271 139.74645113438373 6.117 35.67007139530554 139.74641979479688 6.117 35.67007139530554 139.74641979479688 14.2 35.67010062241271 139.74645113438373 14.2 35.67010062241271 139.74645113438373 6.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffe6b953-d591-4686-906c-f4f915ef2172">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffe6b953-d591-4686-906c-f4f915ef2172">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffe6b953-d591-4686-906c-f4f915ef2172">
											<gml:posList>35.67007139530554 139.74641979479688 6.117 35.67002547161603 139.74648402306497 6.117 35.67002547161603 139.74648402306497 14.2 35.67007139530554 139.74641979479688 14.2 35.67007139530554 139.74641979479688 6.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fc0ecdf-d4c2-4264-9db2-cd900b01c625">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fc0ecdf-d4c2-4264-9db2-cd900b01c625">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fc0ecdf-d4c2-4264-9db2-cd900b01c625">
											<gml:posList>35.67005460864912 139.74651547321704 6.117 35.67010062241271 139.74645113438373 6.117 35.67010062241271 139.74645113438373 14.2 35.67005460864912 139.74651547321704 14.2 35.67005460864912 139.74651547321704 6.117</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7488</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>