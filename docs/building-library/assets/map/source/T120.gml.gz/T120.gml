<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1f77c0e5-97bb-4874-b560-82a27b5c9a11">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">31</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67036602300477 139.74890985432685 0 35.67037709989479 139.7488955929882 0 35.67037975837067 139.7488305277159 0 35.67035371731429 139.74871445900493 0 35.67025303473076 139.74858742301066 0 35.670168286593125 139.74868847513864 0 35.67036602300477 139.74890985432685 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036602300477 139.74890985432685 6.63 35.670168286593125 139.74868847513864 6.63 35.67025303473076 139.74858742301066 6.63 35.67035371731429 139.74871445900493 6.63 35.67037975837067 139.7488305277159 6.63 35.67037709989479 139.7488955929882 6.63 35.67036602300477 139.74890985432685 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036602300477 139.74890985432685 6.63 35.67037709989479 139.7488955929882 6.63 35.67037709989479 139.7488955929882 36.74 35.67036602300477 139.74890985432685 36.74 35.67036602300477 139.74890985432685 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67037709989479 139.7488955929882 6.63 35.67037975837067 139.7488305277159 6.63 35.67037975837067 139.7488305277159 36.74 35.67037709989479 139.7488955929882 36.74 35.67037709989479 139.7488955929882 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67037975837067 139.7488305277159 6.63 35.67035371731429 139.74871445900493 6.63 35.67035371731429 139.74871445900493 36.74 35.67037975837067 139.7488305277159 36.74 35.67037975837067 139.7488305277159 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67035371731429 139.74871445900493 6.63 35.67025303473076 139.74858742301066 6.63 35.67025303473076 139.74858742301066 36.74 35.67035371731429 139.74871445900493 36.74 35.67035371731429 139.74871445900493 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025303473076 139.74858742301066 6.63 35.670168286593125 139.74868847513864 6.63 35.670168286593125 139.74868847513864 36.74 35.67025303473076 139.74858742301066 36.74 35.67025303473076 139.74858742301066 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670168286593125 139.74868847513864 6.63 35.67036602300477 139.74890985432685 6.63 35.67036602300477 139.74890985432685 36.74 35.670168286593125 139.74868847513864 36.74 35.670168286593125 139.74868847513864 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036602300477 139.74890985432685 36.74 35.67037709989479 139.7488955929882 36.74 35.67037975837067 139.7488305277159 36.74 35.67035371731429 139.74871445900493 36.74 35.67025303473076 139.74858742301066 36.74 35.670168286593125 139.74868847513864 36.74 35.67036602300477 139.74890985432685 36.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6d241145-7f00-47bd-a6f4-c87044ce99da"/>
							<gml:surfaceMember xlink:href="#poly-c3a95e08-bb18-457b-84a5-e8887d90d8b7"/>
							<gml:surfaceMember xlink:href="#poly-2225c001-70d7-4d77-a55b-d410bab28c07"/>
							<gml:surfaceMember xlink:href="#poly-5e283111-3e89-45c4-a874-319399ff19a5"/>
							<gml:surfaceMember xlink:href="#poly-9e7db2be-c4e2-4cd2-8be7-8e13cfea4414"/>
							<gml:surfaceMember xlink:href="#poly-94685794-6900-41d3-b429-8728c0523036"/>
							<gml:surfaceMember xlink:href="#poly-357b7830-2bd4-4e85-9d45-a908e7a914af"/>
							<gml:surfaceMember xlink:href="#poly-e788bec1-1399-40fa-9b5e-75fd46e760e3"/>
							<gml:surfaceMember xlink:href="#poly-129f14b5-59cb-47f3-825c-094e0631c6b9"/>
							<gml:surfaceMember xlink:href="#poly-cc7f6e55-a3f2-41c7-a90c-cb4ef7d272c4"/>
							<gml:surfaceMember xlink:href="#poly-d4ba2322-3c3a-4e0f-9067-6f99ed5a3ed7"/>
							<gml:surfaceMember xlink:href="#poly-58f27a00-a388-410b-bd42-7c5535b011d4"/>
							<gml:surfaceMember xlink:href="#poly-17c7a564-5908-404f-bf0a-e355c4d3a0bc"/>
							<gml:surfaceMember xlink:href="#poly-b9f03d41-c141-409e-ae9e-6116bb029fd6"/>
							<gml:surfaceMember xlink:href="#poly-730e064d-7921-4306-8f02-d6f1222abad1"/>
							<gml:surfaceMember xlink:href="#poly-ea4a9833-5010-438a-88ae-2808502ce863"/>
							<gml:surfaceMember xlink:href="#poly-9e6dfd48-c7c2-456d-8002-7637f9c4bdc3"/>
							<gml:surfaceMember xlink:href="#poly-2b6043a1-b07e-40a6-8545-aa106be740d2"/>
							<gml:surfaceMember xlink:href="#poly-583188bd-7a92-4d46-9956-cbdbb23f8a6f"/>
							<gml:surfaceMember xlink:href="#poly-49de3134-0f63-49ff-97d5-32d0f4b2b393"/>
							<gml:surfaceMember xlink:href="#poly-8d9e942f-5405-47e1-8bc3-c2d3542bc738"/>
							<gml:surfaceMember xlink:href="#poly-cf1edb1a-f52e-4e6d-a356-00ea3d627807"/>
							<gml:surfaceMember xlink:href="#poly-789d6a31-19bc-46ed-a5cf-3476efb966f7"/>
							<gml:surfaceMember xlink:href="#poly-e31a2b72-76c3-46bf-8f28-75d7b4c2fd42"/>
							<gml:surfaceMember xlink:href="#poly-c2c662b3-f9a7-4acc-9cee-af8e366d2f59"/>
							<gml:surfaceMember xlink:href="#poly-2eb6023a-d602-4418-a27d-1a5d5848b9b0"/>
							<gml:surfaceMember xlink:href="#poly-4fb378f8-0669-46e0-9be4-50796888fff4"/>
							<gml:surfaceMember xlink:href="#poly-1c59d84c-c623-4136-843e-6865f7d7456c"/>
							<gml:surfaceMember xlink:href="#poly-b5ac8673-5e67-42f8-9322-521e28dbc260"/>
							<gml:surfaceMember xlink:href="#poly-227de11c-8673-4108-bcaf-f938b865f30f"/>
							<gml:surfaceMember xlink:href="#poly-0788bf53-05cd-48b8-9040-4dec355f74de"/>
							<gml:surfaceMember xlink:href="#poly-3d6fb2e0-d0de-4286-a2a1-49cc8e67644b"/>
							<gml:surfaceMember xlink:href="#poly-8492afeb-4fc7-42d7-a7b0-28fb79991b6a"/>
							<gml:surfaceMember xlink:href="#poly-207bd88f-89f2-4d6c-85f9-0b3e4eff07db"/>
							<gml:surfaceMember xlink:href="#poly-8b4c4086-ce02-4825-b52e-e31088520929"/>
							<gml:surfaceMember xlink:href="#poly-a21f49f3-ad3b-418a-ac85-dc762fb4e168"/>
							<gml:surfaceMember xlink:href="#poly-54530591-2f0b-4a30-a341-ebc680a6db71"/>
							<gml:surfaceMember xlink:href="#poly-015760db-239d-4fd6-81f7-d60fc2a235ad"/>
							<gml:surfaceMember xlink:href="#poly-c103ef51-88d6-47ba-9263-e11ebd73cf69"/>
							<gml:surfaceMember xlink:href="#poly-d88e2ec2-14fc-4999-981c-724698dfcba7"/>
							<gml:surfaceMember xlink:href="#poly-45934bef-e691-469a-98f2-e16578348d43"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1f77c0e5-97bb-4874-b560-82a27b5c9a11_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f6f3d0c-613b-4d66-b945-a76488e6154d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67019921452989 139.7486526085004 37.3 35.67020213748588 139.74865617334743 37.3 35.67019330243181 139.74866672078596 37.3 35.670190370462414 139.74866315594844 37.3 35.67019921452989 139.7486526085004 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15dbf1e9-d009-4ddb-8d5c-1f80fe122ee5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670199337794166 139.74867408225168 36.795 35.67019330243181 139.74866672078596 36.795 35.67020213748588 139.74865617334743 36.795 35.67020818187035 139.74866354584987 36.795 35.670199337794166 139.74867408225168 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39cde632-a54c-4b6b-a63a-f6018d1067dc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67022628730168 139.74863342572877 36.795 35.67024761423164 139.74860842764593 36.795 35.670253334093815 139.7486157563069 36.795 35.67023199814862 139.74864075439908 36.795 35.67022628730168 139.74863342572877 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03eb4814-4d85-4530-b5c4-9357f7e4a9ac">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67033792042422 139.74874606796445 36.795 35.670332184051006 139.74875371802383 36.795 35.67028838773967 139.74870440959035 36.795 35.670294124109795 139.74869675953164 36.795 35.67033792042422 139.74874606796445 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-059faf88-ea29-4941-bbe4-a6a54e09ea7c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67034154306085 139.74873198016758 36.795 35.67030102141737 139.7486865013314 36.795 35.67030641556768 139.74867928243526 36.795 35.67034693721384 139.74872476127086 36.795 35.67034154306085 139.74873198016758 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6788f4d9-7ad3-4f8c-870a-3b54610eff22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6788f4d9-7ad3-4f8c-870a-3b54610eff22_0">
											<gml:posList>35.67019921452989 139.7486526085004 37.3 35.670190370462414 139.74866315594844 37.3 35.670190370462414 139.74866315594844 38.879 35.67019921452989 139.7486526085004 38.879 35.67019921452989 139.7486526085004 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fad7fa3d-7832-4995-83fa-f45f69797b63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fad7fa3d-7832-4995-83fa-f45f69797b63_0">
											<gml:posList>35.670199337794166 139.74867408225168 36.795 35.670199337794166 139.74867408225168 38.879 35.670190370462414 139.74866315594844 38.879 35.670190370462414 139.74866315594844 37.3 35.67019330243181 139.74866672078596 37.3 35.67019330243181 139.74866672078596 36.795 35.670199337794166 139.74867408225168 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f81769f-cab9-47dc-a23a-09e2860d05ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f81769f-cab9-47dc-a23a-09e2860d05ba_0">
											<gml:posList>35.67019330243181 139.74866672078596 37.3 35.67020213748588 139.74865617334743 37.3 35.67020213748588 139.74865617334743 36.795 35.67019330243181 139.74866672078596 36.795 35.67019330243181 139.74866672078596 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fec83fd-d1fd-48f1-97eb-840ed3ef32ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fec83fd-d1fd-48f1-97eb-840ed3ef32ea_0">
											<gml:posList>35.670199337794166 139.74867408225168 38.879 35.67020818187035 139.74866354584987 38.879 35.67019921452989 139.7486526085004 38.879 35.670190370462414 139.74866315594844 38.879 35.670199337794166 139.74867408225168 38.879</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42100cbd-7b86-45f8-aedc-4083df818d9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42100cbd-7b86-45f8-aedc-4083df818d9f_0">
											<gml:posList>35.67020213748588 139.74865617334743 37.3 35.67019921452989 139.7486526085004 37.3 35.67019921452989 139.7486526085004 38.879 35.67020818187035 139.74866354584987 38.879 35.67020818187035 139.74866354584987 36.795 35.67020213748588 139.74865617334743 36.795 35.67020213748588 139.74865617334743 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef6ac231-d1ea-445e-8989-75d7f1d7713f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef6ac231-d1ea-445e-8989-75d7f1d7713f_0">
											<gml:posList>35.670199337794166 139.74867408225168 36.795 35.67020818187035 139.74866354584987 36.795 35.67020818187035 139.74866354584987 38.879 35.670199337794166 139.74867408225168 38.879 35.670199337794166 139.74867408225168 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcaeadc7-45db-4cdd-8e70-c8297d26cedb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcaeadc7-45db-4cdd-8e70-c8297d26cedb_0">
											<gml:posList>35.67022628730168 139.74863342572877 36.795 35.67023199814862 139.74864075439908 36.795 35.67023199814862 139.74864075439908 38.438 35.67022628730168 139.74863342572877 38.438 35.67022628730168 139.74863342572877 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d973424-5810-4e63-9636-b5670dceaa6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d973424-5810-4e63-9636-b5670dceaa6e_0">
											<gml:posList>35.67022628730168 139.74863342572877 36.795 35.67022628730168 139.74863342572877 38.438 35.67024761423164 139.74860842764593 38.438 35.67024761423164 139.74860842764593 36.795 35.67022628730168 139.74863342572877 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74aa6ab4-80eb-4d41-beca-d2a7202b9c7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74aa6ab4-80eb-4d41-beca-d2a7202b9c7b_0">
											<gml:posList>35.670253334093815 139.7486157563069 38.438 35.67024761423164 139.74860842764593 38.438 35.67022628730168 139.74863342572877 38.438 35.67023199814862 139.74864075439908 38.438 35.670253334093815 139.7486157563069 38.438</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5c2453b-ba3e-4592-b454-827f75730633">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5c2453b-ba3e-4592-b454-827f75730633_0">
											<gml:posList>35.67023199814862 139.74864075439908 36.795 35.670253334093815 139.7486157563069 36.795 35.670253334093815 139.7486157563069 38.438 35.67023199814862 139.74864075439908 38.438 35.67023199814862 139.74864075439908 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8408fa7-64ef-4e5a-adb2-60f207a00273">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8408fa7-64ef-4e5a-adb2-60f207a00273_0">
											<gml:posList>35.670253334093815 139.7486157563069 36.795 35.67024761423164 139.74860842764593 36.795 35.67024761423164 139.74860842764593 38.438 35.670253334093815 139.7486157563069 38.438 35.670253334093815 139.7486157563069 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa857553-2eec-461b-a371-c8149580259f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa857553-2eec-461b-a371-c8149580259f_0">
											<gml:posList>35.670294124109795 139.74869675953164 36.795 35.67028838773967 139.74870440959035 36.795 35.67028838773967 139.74870440959035 38.459 35.670294124109795 139.74869675953164 38.459 35.670294124109795 139.74869675953164 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1aa73f0f-1e17-40d5-ae83-7d33a92661a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1aa73f0f-1e17-40d5-ae83-7d33a92661a9_0">
											<gml:posList>35.67030102141737 139.7486865013314 36.795 35.67030102141737 139.7486865013314 38.459 35.67030641556768 139.74867928243526 38.459 35.67030641556768 139.74867928243526 36.795 35.67030102141737 139.7486865013314 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cecff0cf-baee-4303-9d9e-dbc3b30cd423">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cecff0cf-baee-4303-9d9e-dbc3b30cd423_0">
											<gml:posList>35.67028838773967 139.74870440959035 36.795 35.670332184051006 139.74875371802383 36.795 35.670332184051006 139.74875371802383 38.459 35.67028838773967 139.74870440959035 38.459 35.67028838773967 139.74870440959035 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c368a6a-b126-4087-aaa5-10d8e8715f97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c368a6a-b126-4087-aaa5-10d8e8715f97_0">
											<gml:posList>35.67033792042422 139.74874606796445 38.459 35.670294124109795 139.74869675953164 38.459 35.67028838773967 139.74870440959035 38.459 35.670332184051006 139.74875371802383 38.459 35.67033792042422 139.74874606796445 38.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b54685ce-c95b-45a8-8c1c-6559376c99f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b54685ce-c95b-45a8-8c1c-6559376c99f8_0">
											<gml:posList>35.670294124109795 139.74869675953164 38.459 35.67033792042422 139.74874606796445 38.459 35.67033792042422 139.74874606796445 36.795 35.670294124109795 139.74869675953164 36.795 35.670294124109795 139.74869675953164 38.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c6e275e-c640-49b3-942a-276c7af34eea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c6e275e-c640-49b3-942a-276c7af34eea_0">
											<gml:posList>35.67030102141737 139.7486865013314 36.795 35.67034154306085 139.74873198016758 36.795 35.67034154306085 139.74873198016758 38.459 35.67030102141737 139.7486865013314 38.459 35.67030102141737 139.7486865013314 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3d22416-fcef-42a5-81a0-b8b85fb17e1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3d22416-fcef-42a5-81a0-b8b85fb17e1d_0">
											<gml:posList>35.67034154306085 139.74873198016758 38.459 35.67034693721384 139.74872476127086 38.459 35.67030641556768 139.74867928243526 38.459 35.67030102141737 139.7486865013314 38.459 35.67034154306085 139.74873198016758 38.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ab48fb1-6797-40ae-bc19-5af302e86de1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ab48fb1-6797-40ae-bc19-5af302e86de1_0">
											<gml:posList>35.67030641556768 139.74867928243526 36.795 35.67030641556768 139.74867928243526 38.459 35.67034693721384 139.74872476127086 38.459 35.67034693721384 139.74872476127086 36.795 35.67030641556768 139.74867928243526 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7c585ee-87c2-423a-95f4-6ff97911c7c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7c585ee-87c2-423a-95f4-6ff97911c7c8_0">
											<gml:posList>35.670332184051006 139.74875371802383 36.795 35.67033792042422 139.74874606796445 36.795 35.67033792042422 139.74874606796445 38.459 35.670332184051006 139.74875371802383 38.459 35.670332184051006 139.74875371802383 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5119405-fdbc-428c-9c83-75c45f521d03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5119405-fdbc-428c-9c83-75c45f521d03_0">
											<gml:posList>35.67034154306085 139.74873198016758 36.795 35.67034693721384 139.74872476127086 36.795 35.67034693721384 139.74872476127086 38.459 35.67034154306085 139.74873198016758 38.459 35.67034154306085 139.74873198016758 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6d241145-7f00-47bd-a6f4-c87044ce99da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d241145-7f00-47bd-a6f4-c87044ce99da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d241145-7f00-47bd-a6f4-c87044ce99da">
											<gml:posList>35.67036602300478 139.74890985432683 6.63 35.670168286593125 139.74868847513866 6.63 35.670253034730734 139.74858742301063 6.63 35.67035371731427 139.74871445900493 6.63 35.67037975837067 139.74883052771588 6.63 35.67037709989476 139.7488955929882 6.63 35.67036602300478 139.74890985432683 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3a95e08-bb18-457b-84a5-e8887d90d8b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3a95e08-bb18-457b-84a5-e8887d90d8b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3a95e08-bb18-457b-84a5-e8887d90d8b7">
											<gml:posList>35.670168286593125 139.74868847513866 37.3 35.670175154973954 139.74868835742532 37.3 35.67025295033837 139.7485955862732 37.3 35.670253034730734 139.74858742301063 37.3 35.670168286593125 139.74868847513866 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2225c001-70d7-4d77-a55b-d410bab28c07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2225c001-70d7-4d77-a55b-d410bab28c07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2225c001-70d7-4d77-a55b-d410bab28c07">
											<gml:posList>35.67028515139024 139.74881931606922 37.3 35.67028485723682 139.74881117529517 37.3 35.670175154973954 139.74868835742532 37.3 35.670168286593125 139.74868847513866 37.3 35.67028515139024 139.74881931606922 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e283111-3e89-45c4-a874-319399ff19a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e283111-3e89-45c4-a874-319399ff19a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e283111-3e89-45c4-a874-319399ff19a5">
											<gml:posList>35.67028485723682 139.74881117529517 36.795 35.67028832123642 139.74881505992263 36.795 35.670312932590356 139.74878204987348 36.795 35.670347164115206 139.74880398477725 36.795 35.670363100086085 139.74884207756608 36.795 35.67034005563192 139.74887298717852 36.795 35.67034352864323 139.74887687180183 36.795 35.670365792007765 139.74890179080154 36.795 35.67037249217725 139.74889316766368 36.795 35.670375026607026 139.74883116233974 36.795 35.67034950999291 139.74871743488816 36.795 35.67025295033837 139.7485955862732 36.795 35.670175154973954 139.74868835742532 36.795 35.67028485723682 139.74881117529517 36.795</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e7db2be-c4e2-4cd2-8be7-8e13cfea4414">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e7db2be-c4e2-4cd2-8be7-8e13cfea4414">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e7db2be-c4e2-4cd2-8be7-8e13cfea4414">
											<gml:posList>35.67028485723682 139.74881117529517 37.3 35.67028515139024 139.74881931606922 37.3 35.67028832123642 139.74881505992263 37.3 35.67028485723682 139.74881117529517 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94685794-6900-41d3-b429-8728c0523036">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94685794-6900-41d3-b429-8728c0523036">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94685794-6900-41d3-b429-8728c0523036">
											<gml:posList>35.670312932590356 139.74878204987348 44.306 35.67028515139024 139.74881931606922 44.306 35.67028884688564 139.74881912438767 44.306 35.67031350326277 139.74878604801455 44.306 35.670312932590356 139.74878204987348 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-357b7830-2bd4-4e85-9d45-a908e7a914af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-357b7830-2bd4-4e85-9d45-a908e7a914af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-357b7830-2bd4-4e85-9d45-a908e7a914af">
											<gml:posList>35.67035371731427 139.74871445900493 37.3 35.670253034730734 139.74858742301063 37.3 35.67025295033837 139.7485955862732 37.3 35.67034950999291 139.74871743488816 37.3 35.67035371731427 139.74871445900493 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e788bec1-1399-40fa-9b5e-75fd46e760e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e788bec1-1399-40fa-9b5e-75fd46e760e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e788bec1-1399-40fa-9b5e-75fd46e760e3">
											<gml:posList>35.67033688578372 139.7488772433256 44.306 35.670336711346316 139.7488727145451 44.306 35.67028884688564 139.74881912438767 44.306 35.67028515139024 139.74881931606922 44.306 35.67033688578372 139.7488772433256 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-129f14b5-59cb-47f3-825c-094e0631c6b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-129f14b5-59cb-47f3-825c-094e0631c6b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-129f14b5-59cb-47f3-825c-094e0631c6b9">
											<gml:posList>35.67028884688564 139.74881912438767 44.038 35.670336711346316 139.7488727145451 44.038 35.67035992689068 139.74884156173587 44.038 35.67034520079038 139.74880636179205 44.038 35.67031350326277 139.74878604801455 44.038 35.67028884688564 139.74881912438767 44.038</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc7f6e55-a3f2-41c7-a90c-cb4ef7d272c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc7f6e55-a3f2-41c7-a90c-cb4ef7d272c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc7f6e55-a3f2-41c7-a90c-cb4ef7d272c4">
											<gml:posList>35.670347164115206 139.74880398477725 44.306 35.670312932590356 139.74878204987348 44.306 35.67031350326277 139.74878604801455 44.306 35.67034520079038 139.74880636179205 44.306 35.670347164115206 139.74880398477725 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4ba2322-3c3a-4e0f-9067-6f99ed5a3ed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4ba2322-3c3a-4e0f-9067-6f99ed5a3ed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4ba2322-3c3a-4e0f-9067-6f99ed5a3ed7">
											<gml:posList>35.67034005563192 139.74887298717852 37.3 35.67033688578372 139.7488772433256 37.3 35.67034352864323 139.74887687180183 37.3 35.67034005563192 139.74887298717852 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-58f27a00-a388-410b-bd42-7c5535b011d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58f27a00-a388-410b-bd42-7c5535b011d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58f27a00-a388-410b-bd42-7c5535b011d4">
											<gml:posList>35.670363100086085 139.74884207756608 44.306 35.67035992689068 139.74884156173587 44.306 35.670336711346316 139.7488727145451 44.306 35.67033688578372 139.7488772433256 44.306 35.670363100086085 139.74884207756608 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17c7a564-5908-404f-bf0a-e355c4d3a0bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17c7a564-5908-404f-bf0a-e355c4d3a0bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17c7a564-5908-404f-bf0a-e355c4d3a0bc">
											<gml:posList>35.67036602300478 139.74890985432683 37.3 35.670365792007765 139.74890179080154 37.3 35.67034352864323 139.74887687180183 37.3 35.67033688578372 139.7488772433256 37.3 35.67036602300478 139.74890985432683 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9f03d41-c141-409e-ae9e-6116bb029fd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9f03d41-c141-409e-ae9e-6116bb029fd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9f03d41-c141-409e-ae9e-6116bb029fd6">
											<gml:posList>35.670347164115206 139.74880398477725 44.306 35.67034520079038 139.74880636179205 44.306 35.67035992689068 139.74884156173587 44.306 35.670363100086085 139.74884207756608 44.306 35.670347164115206 139.74880398477725 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-730e064d-7921-4306-8f02-d6f1222abad1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-730e064d-7921-4306-8f02-d6f1222abad1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-730e064d-7921-4306-8f02-d6f1222abad1">
											<gml:posList>35.67035371731427 139.74871445900493 37.3 35.67034950999291 139.74871743488816 37.3 35.670375026607026 139.74883116233974 37.3 35.67037975837067 139.74883052771588 37.3 35.67035371731427 139.74871445900493 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea4a9833-5010-438a-88ae-2808502ce863">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea4a9833-5010-438a-88ae-2808502ce863">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea4a9833-5010-438a-88ae-2808502ce863">
											<gml:posList>35.67037709989476 139.7488955929882 37.3 35.67037249217725 139.74889316766368 37.3 35.670365792007765 139.74890179080154 37.3 35.67036602300478 139.74890985432683 37.3 35.67037709989476 139.7488955929882 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e6dfd48-c7c2-456d-8002-7637f9c4bdc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e6dfd48-c7c2-456d-8002-7637f9c4bdc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e6dfd48-c7c2-456d-8002-7637f9c4bdc3">
											<gml:posList>35.67037975837067 139.74883052771588 37.3 35.670375026607026 139.74883116233974 37.3 35.67037249217725 139.74889316766368 37.3 35.67037709989476 139.7488955929882 37.3 35.67037975837067 139.74883052771588 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b6043a1-b07e-40a6-8545-aa106be740d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b6043a1-b07e-40a6-8545-aa106be740d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b6043a1-b07e-40a6-8545-aa106be740d2">
											<gml:posList>35.67025295033837 139.7485955862732 37.3 35.67025295033837 139.7485955862732 36.795 35.67034950999291 139.74871743488816 36.795 35.67034950999291 139.74871743488816 37.3 35.67025295033837 139.7485955862732 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-583188bd-7a92-4d46-9956-cbdbb23f8a6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-583188bd-7a92-4d46-9956-cbdbb23f8a6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-583188bd-7a92-4d46-9956-cbdbb23f8a6f">
											<gml:posList>35.67034950999291 139.74871743488816 37.3 35.67034950999291 139.74871743488816 36.795 35.670375026607026 139.74883116233974 36.795 35.670375026607026 139.74883116233974 37.3 35.67034950999291 139.74871743488816 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49de3134-0f63-49ff-97d5-32d0f4b2b393">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49de3134-0f63-49ff-97d5-32d0f4b2b393">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49de3134-0f63-49ff-97d5-32d0f4b2b393">
											<gml:posList>35.67031350326277 139.74878604801455 44.306 35.67031350326277 139.74878604801455 44.038 35.67034520079038 139.74880636179205 44.038 35.67034520079038 139.74880636179205 44.306 35.67031350326277 139.74878604801455 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d9e942f-5405-47e1-8bc3-c2d3542bc738">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d9e942f-5405-47e1-8bc3-c2d3542bc738">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d9e942f-5405-47e1-8bc3-c2d3542bc738">
											<gml:posList>35.67034520079038 139.74880636179205 44.306 35.67034520079038 139.74880636179205 44.038 35.67035992689068 139.74884156173587 44.038 35.67035992689068 139.74884156173587 44.306 35.67034520079038 139.74880636179205 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf1edb1a-f52e-4e6d-a356-00ea3d627807">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf1edb1a-f52e-4e6d-a356-00ea3d627807">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf1edb1a-f52e-4e6d-a356-00ea3d627807">
											<gml:posList>35.670253034730734 139.74858742301063 6.63 35.670168286593125 139.74868847513866 6.63 35.670168286593125 139.74868847513866 37.3 35.670253034730734 139.74858742301063 37.3 35.670253034730734 139.74858742301063 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-789d6a31-19bc-46ed-a5cf-3476efb966f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-789d6a31-19bc-46ed-a5cf-3476efb966f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-789d6a31-19bc-46ed-a5cf-3476efb966f7">
											<gml:posList>35.670175154973954 139.74868835742532 37.3 35.670175154973954 139.74868835742532 36.795 35.67025295033837 139.7485955862732 36.795 35.67025295033837 139.7485955862732 37.3 35.670175154973954 139.74868835742532 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e31a2b72-76c3-46bf-8f28-75d7b4c2fd42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e31a2b72-76c3-46bf-8f28-75d7b4c2fd42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e31a2b72-76c3-46bf-8f28-75d7b4c2fd42">
											<gml:posList>35.67035371731427 139.74871445900493 6.63 35.670253034730734 139.74858742301063 6.63 35.670253034730734 139.74858742301063 37.3 35.67035371731427 139.74871445900493 37.3 35.67035371731427 139.74871445900493 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2c662b3-f9a7-4acc-9cee-af8e366d2f59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2c662b3-f9a7-4acc-9cee-af8e366d2f59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2c662b3-f9a7-4acc-9cee-af8e366d2f59">
											<gml:posList>35.67028485723682 139.74881117529517 37.3 35.67028485723682 139.74881117529517 36.795 35.670175154973954 139.74868835742532 36.795 35.670175154973954 139.74868835742532 37.3 35.67028485723682 139.74881117529517 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2eb6023a-d602-4418-a27d-1a5d5848b9b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2eb6023a-d602-4418-a27d-1a5d5848b9b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2eb6023a-d602-4418-a27d-1a5d5848b9b0">
											<gml:posList>35.67037975837067 139.74883052771588 6.63 35.67035371731427 139.74871445900493 6.63 35.67035371731427 139.74871445900493 37.3 35.67037975837067 139.74883052771588 37.3 35.67037975837067 139.74883052771588 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fb378f8-0669-46e0-9be4-50796888fff4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fb378f8-0669-46e0-9be4-50796888fff4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fb378f8-0669-46e0-9be4-50796888fff4">
											<gml:posList>35.670312932590356 139.74878204987348 44.306 35.670347164115206 139.74880398477725 44.306 35.670347164115206 139.74880398477725 36.795 35.670312932590356 139.74878204987348 36.795 35.670312932590356 139.74878204987348 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c59d84c-c623-4136-843e-6865f7d7456c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c59d84c-c623-4136-843e-6865f7d7456c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c59d84c-c623-4136-843e-6865f7d7456c">
											<gml:posList>35.67033688578372 139.7488772433256 37.3 35.67033688578372 139.7488772433256 44.306 35.67028515139024 139.74881931606922 44.306 35.67028515139024 139.74881931606922 37.3 35.670168286593125 139.74868847513866 37.3 35.670168286593125 139.74868847513866 6.63 35.67036602300478 139.74890985432683 6.63 35.67036602300478 139.74890985432683 37.3 35.67033688578372 139.7488772433256 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5ac8673-5e67-42f8-9322-521e28dbc260">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5ac8673-5e67-42f8-9322-521e28dbc260">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5ac8673-5e67-42f8-9322-521e28dbc260">
											<gml:posList>35.67028832123642 139.74881505992263 37.3 35.67028515139024 139.74881931606922 37.3 35.67028515139024 139.74881931606922 44.306 35.670312932590356 139.74878204987348 44.306 35.670312932590356 139.74878204987348 36.795 35.67028832123642 139.74881505992263 36.795 35.67028832123642 139.74881505992263 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-227de11c-8673-4108-bcaf-f938b865f30f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-227de11c-8673-4108-bcaf-f938b865f30f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-227de11c-8673-4108-bcaf-f938b865f30f">
											<gml:posList>35.67028884688564 139.74881912438767 44.306 35.67028884688564 139.74881912438767 44.038 35.67031350326277 139.74878604801455 44.038 35.67031350326277 139.74878604801455 44.306 35.67028884688564 139.74881912438767 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0788bf53-05cd-48b8-9040-4dec355f74de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0788bf53-05cd-48b8-9040-4dec355f74de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0788bf53-05cd-48b8-9040-4dec355f74de">
											<gml:posList>35.67028832123642 139.74881505992263 37.3 35.67028832123642 139.74881505992263 36.795 35.67028485723682 139.74881117529517 36.795 35.67028485723682 139.74881117529517 37.3 35.67028832123642 139.74881505992263 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d6fb2e0-d0de-4286-a2a1-49cc8e67644b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d6fb2e0-d0de-4286-a2a1-49cc8e67644b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d6fb2e0-d0de-4286-a2a1-49cc8e67644b">
											<gml:posList>35.670347164115206 139.74880398477725 44.306 35.670363100086085 139.74884207756608 44.306 35.670363100086085 139.74884207756608 36.795 35.670347164115206 139.74880398477725 36.795 35.670347164115206 139.74880398477725 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8492afeb-4fc7-42d7-a7b0-28fb79991b6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8492afeb-4fc7-42d7-a7b0-28fb79991b6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8492afeb-4fc7-42d7-a7b0-28fb79991b6a">
											<gml:posList>35.670336711346316 139.7488727145451 44.306 35.670336711346316 139.7488727145451 44.038 35.67028884688564 139.74881912438767 44.038 35.67028884688564 139.74881912438767 44.306 35.670336711346316 139.7488727145451 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-207bd88f-89f2-4d6c-85f9-0b3e4eff07db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-207bd88f-89f2-4d6c-85f9-0b3e4eff07db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-207bd88f-89f2-4d6c-85f9-0b3e4eff07db">
											<gml:posList>35.67035992689068 139.74884156173587 44.306 35.67035992689068 139.74884156173587 44.038 35.670336711346316 139.7488727145451 44.038 35.670336711346316 139.7488727145451 44.306 35.67035992689068 139.74884156173587 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b4c4086-ce02-4825-b52e-e31088520929">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b4c4086-ce02-4825-b52e-e31088520929">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b4c4086-ce02-4825-b52e-e31088520929">
											<gml:posList>35.67033688578372 139.7488772433256 44.306 35.67033688578372 139.7488772433256 37.3 35.67034005563192 139.74887298717852 37.3 35.67034005563192 139.74887298717852 36.795 35.670363100086085 139.74884207756608 36.795 35.670363100086085 139.74884207756608 44.306 35.67033688578372 139.7488772433256 44.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a21f49f3-ad3b-418a-ac85-dc762fb4e168">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a21f49f3-ad3b-418a-ac85-dc762fb4e168">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a21f49f3-ad3b-418a-ac85-dc762fb4e168">
											<gml:posList>35.670375026607026 139.74883116233974 37.3 35.670375026607026 139.74883116233974 36.795 35.67037249217725 139.74889316766368 36.795 35.67037249217725 139.74889316766368 37.3 35.670375026607026 139.74883116233974 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54530591-2f0b-4a30-a341-ebc680a6db71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54530591-2f0b-4a30-a341-ebc680a6db71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54530591-2f0b-4a30-a341-ebc680a6db71">
											<gml:posList>35.67037709989476 139.7488955929882 6.63 35.67037975837067 139.74883052771588 6.63 35.67037975837067 139.74883052771588 37.3 35.67037709989476 139.7488955929882 37.3 35.67037709989476 139.7488955929882 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-015760db-239d-4fd6-81f7-d60fc2a235ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-015760db-239d-4fd6-81f7-d60fc2a235ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-015760db-239d-4fd6-81f7-d60fc2a235ad">
											<gml:posList>35.67034352864323 139.74887687180183 37.3 35.67034352864323 139.74887687180183 36.795 35.67034005563192 139.74887298717852 36.795 35.67034005563192 139.74887298717852 37.3 35.67034352864323 139.74887687180183 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c103ef51-88d6-47ba-9263-e11ebd73cf69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c103ef51-88d6-47ba-9263-e11ebd73cf69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c103ef51-88d6-47ba-9263-e11ebd73cf69">
											<gml:posList>35.670365792007765 139.74890179080154 37.3 35.670365792007765 139.74890179080154 36.795 35.67034352864323 139.74887687180183 36.795 35.67034352864323 139.74887687180183 37.3 35.670365792007765 139.74890179080154 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d88e2ec2-14fc-4999-981c-724698dfcba7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d88e2ec2-14fc-4999-981c-724698dfcba7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d88e2ec2-14fc-4999-981c-724698dfcba7">
											<gml:posList>35.67037249217725 139.74889316766368 37.3 35.67037249217725 139.74889316766368 36.795 35.670365792007765 139.74890179080154 36.795 35.670365792007765 139.74890179080154 37.3 35.67037249217725 139.74889316766368 37.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45934bef-e691-469a-98f2-e16578348d43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45934bef-e691-469a-98f2-e16578348d43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45934bef-e691-469a-98f2-e16578348d43">
											<gml:posList>35.67036602300478 139.74890985432683 6.63 35.67037709989476 139.7488955929882 6.63 35.67037709989476 139.7488955929882 37.3 35.67036602300478 139.74890985432683 37.3 35.67036602300478 139.74890985432683 6.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9364</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">307.30585</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>8</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>