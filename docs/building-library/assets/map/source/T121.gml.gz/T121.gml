<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1ff97ae6-d2c2-4ffb-9599-69639b775f4f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">9.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67138985561953 139.7409996650348 0 35.67130929673233 139.74091326459677 0 35.671274811389836 139.74096179796936 0 35.67127652535276 139.74096356341596 0 35.67124321007963 139.74100988612406 0 35.67132232534908 139.7410945208267 0 35.67138985561953 139.7409996650348 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138985561953 139.7409996650348 8.16 35.67132232534908 139.7410945208267 8.16 35.67124321007963 139.74100988612406 8.16 35.67127652535276 139.74096356341596 8.16 35.671274811389836 139.74096179796936 8.16 35.67130929673233 139.74091326459677 8.16 35.67138985561953 139.7409996650348 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138985561953 139.7409996650348 8.16 35.67130929673233 139.74091326459677 8.16 35.67130929673233 139.74091326459677 17.77 35.67138985561953 139.7409996650348 17.77 35.67138985561953 139.7409996650348 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130929673233 139.74091326459677 8.16 35.671274811389836 139.74096179796936 8.16 35.671274811389836 139.74096179796936 17.77 35.67130929673233 139.74091326459677 17.77 35.67130929673233 139.74091326459677 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671274811389836 139.74096179796936 8.16 35.67127652535276 139.74096356341596 8.16 35.67127652535276 139.74096356341596 17.77 35.671274811389836 139.74096179796936 17.77 35.671274811389836 139.74096179796936 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67127652535276 139.74096356341596 8.16 35.67124321007963 139.74100988612406 8.16 35.67124321007963 139.74100988612406 17.77 35.67127652535276 139.74096356341596 17.77 35.67127652535276 139.74096356341596 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67124321007963 139.74100988612406 8.16 35.67132232534908 139.7410945208267 8.16 35.67132232534908 139.7410945208267 17.77 35.67124321007963 139.74100988612406 17.77 35.67124321007963 139.74100988612406 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67132232534908 139.7410945208267 8.16 35.67138985561953 139.7409996650348 8.16 35.67138985561953 139.7409996650348 17.77 35.67132232534908 139.7410945208267 17.77 35.67132232534908 139.7410945208267 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138985561953 139.7409996650348 17.77 35.67130929673233 139.74091326459677 17.77 35.671274811389836 139.74096179796936 17.77 35.67127652535276 139.74096356341596 17.77 35.67124321007963 139.74100988612406 17.77 35.67132232534908 139.7410945208267 17.77 35.67138985561953 139.7409996650348 17.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ae307124-3450-4a65-9550-b83c1266b681"/>
							<gml:surfaceMember xlink:href="#poly-8d277a13-b74c-4a2c-a6ba-6aa7f42d460a"/>
							<gml:surfaceMember xlink:href="#poly-15812cd2-6093-4394-bd90-9daabd903e43"/>
							<gml:surfaceMember xlink:href="#poly-36322d4e-c7be-4cc4-8dc3-fd94f139484b"/>
							<gml:surfaceMember xlink:href="#poly-f54c26da-39ba-491c-95f7-b5df16f1e1df"/>
							<gml:surfaceMember xlink:href="#poly-672a91ca-ab44-4325-8b18-a37bd000137f"/>
							<gml:surfaceMember xlink:href="#poly-666f2f81-5420-4c0c-bb5b-6fa584653569"/>
							<gml:surfaceMember xlink:href="#poly-bcc784a2-b855-42ee-9a21-afebce5096f4"/>
							<gml:surfaceMember xlink:href="#poly-817985d2-8bde-47cf-ac26-839526cc4591"/>
							<gml:surfaceMember xlink:href="#poly-31f11c87-0700-4642-821e-605a11a77782"/>
							<gml:surfaceMember xlink:href="#poly-46d3df16-671c-44d0-99c8-f7d458067e7f"/>
							<gml:surfaceMember xlink:href="#poly-79c29a6e-06d2-44a1-a9c4-4ce179fc23bb"/>
							<gml:surfaceMember xlink:href="#poly-29815171-75fc-4673-9d24-9a1fc09a3e8f"/>
							<gml:surfaceMember xlink:href="#poly-b6c55ee0-860d-4b70-9e9d-42a98cc1dbfe"/>
							<gml:surfaceMember xlink:href="#poly-34b974f5-abf1-4947-a8ac-31b71fa3bfdc"/>
							<gml:surfaceMember xlink:href="#poly-1bf10d21-14ce-4d79-ae94-fa5f5c646a4a"/>
							<gml:surfaceMember xlink:href="#poly-b88b070e-eb5a-418e-9423-2e4be10565d8"/>
							<gml:surfaceMember xlink:href="#poly-4abd73e2-961e-443c-bc1b-67cdfdc19dea"/>
							<gml:surfaceMember xlink:href="#poly-c5237696-fbaf-4401-86bb-45c4a644c4e7"/>
							<gml:surfaceMember xlink:href="#poly-c4242491-e02f-443a-a663-c977264d647f"/>
							<gml:surfaceMember xlink:href="#poly-422aac30-c2c6-4cb4-b1c0-43c5ec768a18"/>
							<gml:surfaceMember xlink:href="#poly-777c7de7-ab61-4c7b-a920-9e5f19c7ed92"/>
							<gml:surfaceMember xlink:href="#poly-3bcbb7f8-b732-4056-9ba2-a4ddc66247bb"/>
							<gml:surfaceMember xlink:href="#poly-ec13d1f3-2d79-4aad-89ef-843545e21e2c"/>
							<gml:surfaceMember xlink:href="#poly-f96e2180-4359-4d6b-bfc4-820a49626d5b"/>
							<gml:surfaceMember xlink:href="#poly-016e0bad-02cb-48ee-963b-699d7edbd175"/>
							<gml:surfaceMember xlink:href="#poly-4d809388-9cc2-4f0a-aa16-e39587b991a2"/>
							<gml:surfaceMember xlink:href="#poly-2105b418-1764-4991-a33a-342ea585be81"/>
							<gml:surfaceMember xlink:href="#poly-0c7094b0-cf87-4426-9946-8744084ab99b"/>
							<gml:surfaceMember xlink:href="#poly-88c630e8-db09-4cba-82cc-ef7121c4cbab"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1ff97ae6-d2c2-4ffb-9599-69639b775f4f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e03d098-f0ce-4a01-8262-15c9e31f6b51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67132715584173 139.7410110597931 18.014 35.67132723687206 139.7410109381895 18.014 35.67133541905031 139.74101971064852 18.014 35.67132715584173 139.7410110597931 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a751825-3a98-4bba-b98f-198f758b845d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67135771721858 139.7410173652315 17.789 35.67134737182555 139.74103221244903 17.789 35.67133541905031 139.74101971064852 17.789 35.67132723687206 139.7410109381895 17.789 35.67133750122371 139.74099620153024 17.789 35.67135771721858 139.7410173652315 17.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d44335fb-bb86-4338-bfeb-ed609e5db0c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d44335fb-bb86-4338-bfeb-ed609e5db0c3_0">
											<gml:posList>35.67132723687206 139.7410109381895 18.014 35.67132715584173 139.7410110597931 18.014 35.67132715584173 139.7410110597931 20.048 35.67133750122371 139.74099620153024 20.048 35.67133750122371 139.74099620153024 17.789 35.67132723687206 139.7410109381895 17.789 35.67132723687206 139.7410109381895 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79703581-6278-4622-bd19-c30f65a3e592">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79703581-6278-4622-bd19-c30f65a3e592_0">
											<gml:posList>35.67133750122371 139.74099620153024 17.789 35.67133750122371 139.74099620153024 20.048 35.67135771721858 139.7410173652315 20.048 35.67135771721858 139.7410173652315 17.789 35.67133750122371 139.74099620153024 17.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a203cf6f-7a1a-4fba-b749-5943a149281a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a203cf6f-7a1a-4fba-b749-5943a149281a_0">
											<gml:posList>35.67132715584173 139.7410110597931 20.048 35.67134737182555 139.74103221244903 20.048 35.67135771721858 139.7410173652315 20.048 35.67133750122371 139.74099620153024 20.048 35.67132715584173 139.7410110597931 20.048</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38177ef3-8675-4645-a642-4bd3826a58f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38177ef3-8675-4645-a642-4bd3826a58f9_0">
											<gml:posList>35.67133541905031 139.74101971064852 17.789 35.67133541905031 139.74101971064852 18.014 35.67132723687206 139.7410109381895 18.014 35.67132723687206 139.7410109381895 17.789 35.67133541905031 139.74101971064852 17.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0cdba19-d837-4681-8e1c-f6616942eeef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0cdba19-d837-4681-8e1c-f6616942eeef_0">
											<gml:posList>35.67134737182555 139.74103221244903 17.789 35.67134737182555 139.74103221244903 20.048 35.67132715584173 139.7410110597931 20.048 35.67132715584173 139.7410110597931 18.014 35.67133541905031 139.74101971064852 18.014 35.67133541905031 139.74101971064852 17.789 35.67134737182555 139.74103221244903 17.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e290b1a-4d19-4fef-a355-e0f9fd9e2cbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e290b1a-4d19-4fef-a355-e0f9fd9e2cbe_0">
											<gml:posList>35.67135771721858 139.7410173652315 17.789 35.67135771721858 139.7410173652315 20.048 35.67134737182555 139.74103221244903 20.048 35.67134737182555 139.74103221244903 17.789 35.67135771721858 139.7410173652315 17.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_1ff97ae6-d2c2-4ffb-9599-69639b775f4f_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d3fbb91-d83f-4bcb-9dd6-b35a600def2d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67135830500197 139.74097281444665 17.789 35.67138379876301 139.7410001470053 17.789 35.67137113007635 139.74101792420004 17.789 35.671345537591904 139.74099114407335 17.789 35.67135830500197 139.74097281444665 17.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd0cdc5e-f854-473a-a326-b3aac4e55685">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138379876301 139.7410001470053 18.014 35.67135830500197 139.74097281444665 18.014 35.67135854810978 139.74097247172838 18.014 35.671385069757015 139.74100022286635 18.014 35.6713720592349 139.74101889521305 18.014 35.67137113007635 139.74101792420004 18.014 35.67138379876301 139.7410001470053 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e82254a-514b-4e14-88a7-3c5921b8ac36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e82254a-514b-4e14-88a7-3c5921b8ac36_0">
											<gml:posList>35.671345537591904 139.74099114407335 17.789 35.671345537591904 139.74099114407335 21.192 35.67135854810978 139.74097247172838 21.192 35.67135854810978 139.74097247172838 18.014 35.67135830500197 139.74097281444665 18.014 35.67135830500197 139.74097281444665 17.789 35.671345537591904 139.74099114407335 17.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-171d1b13-d0d2-4342-b54d-ac426d8061cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-171d1b13-d0d2-4342-b54d-ac426d8061cf_0">
											<gml:posList>35.67135854810978 139.74097247172838 18.014 35.67135854810978 139.74097247172838 21.192 35.671385069757015 139.74100022286635 21.192 35.671385069757015 139.74100022286635 18.014 35.67135854810978 139.74097247172838 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bad52de-d48e-4ef2-bbc9-a3ebe7efec35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bad52de-d48e-4ef2-bbc9-a3ebe7efec35_0">
											<gml:posList>35.67138379876301 139.7410001470053 17.789 35.67135830500197 139.74097281444665 17.789 35.67135830500197 139.74097281444665 18.014 35.67138379876301 139.7410001470053 18.014 35.67138379876301 139.7410001470053 17.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b0e2027-36c3-464b-8e0b-bc5e7704973f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b0e2027-36c3-464b-8e0b-bc5e7704973f_0">
											<gml:posList>35.6713720592349 139.74101889521305 21.192 35.671385069757015 139.74100022286635 21.192 35.67135854810978 139.74097247172838 21.192 35.671345537591904 139.74099114407335 21.192 35.6713720592349 139.74101889521305 21.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04a0ade7-2592-4d7e-b042-53a71f45db98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04a0ade7-2592-4d7e-b042-53a71f45db98_0">
											<gml:posList>35.6713720592349 139.74101889521305 21.192 35.671345537591904 139.74099114407335 21.192 35.671345537591904 139.74099114407335 17.789 35.67137113007635 139.74101792420004 17.789 35.67137113007635 139.74101792420004 18.014 35.6713720592349 139.74101889521305 18.014 35.6713720592349 139.74101889521305 21.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ace6475-96a9-4ce8-b8f5-003f3a39d072">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ace6475-96a9-4ce8-b8f5-003f3a39d072_0">
											<gml:posList>35.67137113007635 139.74101792420004 18.014 35.67137113007635 139.74101792420004 17.789 35.67138379876301 139.7410001470053 17.789 35.67138379876301 139.7410001470053 18.014 35.67137113007635 139.74101792420004 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33cb9280-06ea-40f5-95a9-676bdc6b0ff9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33cb9280-06ea-40f5-95a9-676bdc6b0ff9_0">
											<gml:posList>35.671385069757015 139.74100022286635 21.192 35.6713720592349 139.74101889521305 21.192 35.6713720592349 139.74101889521305 18.014 35.671385069757015 139.74100022286635 18.014 35.671385069757015 139.74100022286635 21.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ae307124-3450-4a65-9550-b83c1266b681">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae307124-3450-4a65-9550-b83c1266b681">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae307124-3450-4a65-9550-b83c1266b681">
											<gml:posList>35.671276525352724 139.74096356341596 8.16 35.671274811389814 139.74096179796936 8.16 35.67130929673233 139.74091326459677 8.16 35.67138985561951 139.7409996650348 8.16 35.671322325349074 139.7410945208267 8.16 35.6712432100796 139.74100988612406 8.16 35.671276525352724 139.74096356341596 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d277a13-b74c-4a2c-a6ba-6aa7f42d460a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d277a13-b74c-4a2c-a6ba-6aa7f42d460a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d277a13-b74c-4a2c-a6ba-6aa7f42d460a">
											<gml:posList>35.67127844686 139.74096562687583 17.97 35.671355370158004 139.7410480879553 18.014 35.671276525352724 139.74096356341596 17.97 35.67127844686 139.74096562687583 17.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15812cd2-6093-4394-bd90-9daabd903e43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15812cd2-6093-4394-bd90-9daabd903e43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15812cd2-6093-4394-bd90-9daabd903e43">
											<gml:posList>35.671274811389814 139.74096179796936 18.014 35.67128088623981 139.74096127179035 18.014 35.671309708064044 139.7409207093878 18.014 35.67130929673233 139.74091326459677 18.014 35.671274811389814 139.74096179796936 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36322d4e-c7be-4cc4-8dc3-fd94f139484b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36322d4e-c7be-4cc4-8dc3-fd94f139484b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36322d4e-c7be-4cc4-8dc3-fd94f139484b">
											<gml:posList>35.67130929673233 139.74091326459677 18.014 35.671309708064044 139.7409207093878 18.014 35.67138379876301 139.7410001470053 18.014 35.67138985561951 139.7409996650348 18.014 35.67130929673233 139.74091326459677 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f54c26da-39ba-491c-95f7-b5df16f1e1df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f54c26da-39ba-491c-95f7-b5df16f1e1df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f54c26da-39ba-491c-95f7-b5df16f1e1df">
											<gml:posList>35.671274811389814 139.74096179796936 18.014 35.671276525352724 139.74096356341596 18.014 35.67128088623981 139.74096127179035 18.014 35.671274811389814 139.74096179796936 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-672a91ca-ab44-4325-8b18-a37bd000137f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-672a91ca-ab44-4325-8b18-a37bd000137f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-672a91ca-ab44-4325-8b18-a37bd000137f">
											<gml:posList>35.67138379876301 139.7410001470053 17.789 35.671309708064044 139.7409207093878 17.789 35.67128088623981 139.74096127179035 17.789 35.67135494982043 139.7410406431697 17.789 35.67138379876301 139.7410001470053 17.789</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-666f2f81-5420-4c0c-bb5b-6fa584653569">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-666f2f81-5420-4c0c-bb5b-6fa584653569">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-666f2f81-5420-4c0c-bb5b-6fa584653569">
											<gml:posList>35.671246842389166 139.74100959473552 17.97 35.67127844686 139.74096562687583 17.97 35.671276525352724 139.74096356341596 17.97 35.6712432100796 139.74100988612406 17.97 35.671246842389166 139.74100959473552 17.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bcc784a2-b855-42ee-9a21-afebce5096f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcc784a2-b855-42ee-9a21-afebce5096f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcc784a2-b855-42ee-9a21-afebce5096f4">
											<gml:posList>35.671276525352724 139.74096356341596 18.014 35.671355370158004 139.7410480879553 18.014 35.67135494982043 139.7410406431697 18.014 35.67128088623981 139.74096127179035 18.014 35.671276525352724 139.74096356341596 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-817985d2-8bde-47cf-ac26-839526cc4591">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-817985d2-8bde-47cf-ac26-839526cc4591">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-817985d2-8bde-47cf-ac26-839526cc4591">
											<gml:posList>35.67138985561951 139.7409996650348 18.014 35.67138379876301 139.7410001470053 18.014 35.67135494982043 139.7410406431697 18.014 35.671355370158004 139.7410480879553 18.014 35.67138985561951 139.7409996650348 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-31f11c87-0700-4642-821e-605a11a77782">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31f11c87-0700-4642-821e-605a11a77782">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31f11c87-0700-4642-821e-605a11a77782">
											<gml:posList>35.67132207857684 139.7410900804621 17.721 35.67135343963844 139.74104602450186 17.721 35.67127844686 139.74096562687583 17.721 35.671246842389166 139.74100959473552 17.721 35.67132207857684 139.7410900804621 17.721</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46d3df16-671c-44d0-99c8-f7d458067e7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46d3df16-671c-44d0-99c8-f7d458067e7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46d3df16-671c-44d0-99c8-f7d458067e7f">
											<gml:posList>35.671322325349074 139.7410945208267 17.97 35.67132207857684 139.7410900804621 17.97 35.671246842389166 139.74100959473552 17.97 35.6712432100796 139.74100988612406 17.97 35.671322325349074 139.7410945208267 17.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79c29a6e-06d2-44a1-a9c4-4ce179fc23bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79c29a6e-06d2-44a1-a9c4-4ce179fc23bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79c29a6e-06d2-44a1-a9c4-4ce179fc23bb">
											<gml:posList>35.67132207857684 139.7410900804621 17.97 35.671322325349074 139.7410945208267 17.97 35.671355370158004 139.7410480879553 17.97 35.67135343963844 139.74104602450186 17.97 35.67132207857684 139.7410900804621 17.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29815171-75fc-4673-9d24-9a1fc09a3e8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29815171-75fc-4673-9d24-9a1fc09a3e8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29815171-75fc-4673-9d24-9a1fc09a3e8f">
											<gml:posList>35.671309708064044 139.7409207093878 18.014 35.671309708064044 139.7409207093878 17.789 35.67138379876301 139.7410001470053 17.789 35.67138379876301 139.7410001470053 18.014 35.671309708064044 139.7409207093878 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6c55ee0-860d-4b70-9e9d-42a98cc1dbfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6c55ee0-860d-4b70-9e9d-42a98cc1dbfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6c55ee0-860d-4b70-9e9d-42a98cc1dbfe">
											<gml:posList>35.67135494982043 139.7410406431697 18.014 35.67135494982043 139.7410406431697 17.789 35.67128088623981 139.74096127179035 17.789 35.67128088623981 139.74096127179035 18.014 35.67135494982043 139.7410406431697 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34b974f5-abf1-4947-a8ac-31b71fa3bfdc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34b974f5-abf1-4947-a8ac-31b71fa3bfdc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34b974f5-abf1-4947-a8ac-31b71fa3bfdc">
											<gml:posList>35.67127844686 139.74096562687583 17.97 35.67127844686 139.74096562687583 17.721 35.67135343963844 139.74104602450186 17.721 35.67127844686 139.74096562687583 17.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bf10d21-14ce-4d79-ae94-fa5f5c646a4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bf10d21-14ce-4d79-ae94-fa5f5c646a4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bf10d21-14ce-4d79-ae94-fa5f5c646a4a">
											<gml:posList>35.67127844686 139.74096562687583 17.97 35.67135343963844 139.74104602450186 17.721 35.67135343963844 139.74104602450186 17.97 35.67127844686 139.74096562687583 17.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b88b070e-eb5a-418e-9423-2e4be10565d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b88b070e-eb5a-418e-9423-2e4be10565d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b88b070e-eb5a-418e-9423-2e4be10565d8">
											<gml:posList>35.671276525352724 139.74096356341596 8.16 35.6712432100796 139.74100988612406 8.16 35.6712432100796 139.74100988612406 17.97 35.671276525352724 139.74096356341596 17.97 35.671276525352724 139.74096356341596 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4abd73e2-961e-443c-bc1b-67cdfdc19dea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4abd73e2-961e-443c-bc1b-67cdfdc19dea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4abd73e2-961e-443c-bc1b-67cdfdc19dea">
											<gml:posList>35.671246842389166 139.74100959473552 17.97 35.671246842389166 139.74100959473552 17.721 35.67127844686 139.74096562687583 17.721 35.67127844686 139.74096562687583 17.97 35.671246842389166 139.74100959473552 17.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5237696-fbaf-4401-86bb-45c4a644c4e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5237696-fbaf-4401-86bb-45c4a644c4e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5237696-fbaf-4401-86bb-45c4a644c4e7">
											<gml:posList>35.671274811389814 139.74096179796936 18.014 35.671274811389814 139.74096179796936 8.16 35.671276525352724 139.74096356341596 8.16 35.671276525352724 139.74096356341596 17.97 35.671276525352724 139.74096356341596 18.014 35.671274811389814 139.74096179796936 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4242491-e02f-443a-a663-c977264d647f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4242491-e02f-443a-a663-c977264d647f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4242491-e02f-443a-a663-c977264d647f">
											<gml:posList>35.6712432100796 139.74100988612406 8.16 35.671322325349074 139.7410945208267 8.16 35.671322325349074 139.7410945208267 17.97 35.6712432100796 139.74100988612406 17.97 35.6712432100796 139.74100988612406 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-422aac30-c2c6-4cb4-b1c0-43c5ec768a18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-422aac30-c2c6-4cb4-b1c0-43c5ec768a18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-422aac30-c2c6-4cb4-b1c0-43c5ec768a18">
											<gml:posList>35.67132207857684 139.7410900804621 17.97 35.67132207857684 139.7410900804621 17.721 35.671246842389166 139.74100959473552 17.721 35.671246842389166 139.74100959473552 17.97 35.67132207857684 139.7410900804621 17.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-777c7de7-ab61-4c7b-a920-9e5f19c7ed92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-777c7de7-ab61-4c7b-a920-9e5f19c7ed92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-777c7de7-ab61-4c7b-a920-9e5f19c7ed92">
											<gml:posList>35.67130929673233 139.74091326459677 8.16 35.671274811389814 139.74096179796936 8.16 35.671274811389814 139.74096179796936 18.014 35.67130929673233 139.74091326459677 18.014 35.67130929673233 139.74091326459677 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bcbb7f8-b732-4056-9ba2-a4ddc66247bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bcbb7f8-b732-4056-9ba2-a4ddc66247bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bcbb7f8-b732-4056-9ba2-a4ddc66247bb">
											<gml:posList>35.67128088623981 139.74096127179035 18.014 35.67128088623981 139.74096127179035 17.789 35.671309708064044 139.7409207093878 17.789 35.671309708064044 139.7409207093878 18.014 35.67128088623981 139.74096127179035 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec13d1f3-2d79-4aad-89ef-843545e21e2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec13d1f3-2d79-4aad-89ef-843545e21e2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec13d1f3-2d79-4aad-89ef-843545e21e2c">
											<gml:posList>35.671355370158004 139.7410480879553 18.014 35.671276525352724 139.74096356341596 18.014 35.671276525352724 139.74096356341596 17.97 35.671355370158004 139.7410480879553 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f96e2180-4359-4d6b-bfc4-820a49626d5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f96e2180-4359-4d6b-bfc4-820a49626d5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f96e2180-4359-4d6b-bfc4-820a49626d5b">
											<gml:posList>35.67127844686 139.74096562687583 17.97 35.67135343963844 139.74104602450186 17.97 35.671355370158004 139.7410480879553 18.014 35.67127844686 139.74096562687583 17.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-016e0bad-02cb-48ee-963b-699d7edbd175">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-016e0bad-02cb-48ee-963b-699d7edbd175">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-016e0bad-02cb-48ee-963b-699d7edbd175">
											<gml:posList>35.67135343963844 139.74104602450186 17.97 35.67135343963844 139.74104602450186 17.721 35.67132207857684 139.7410900804621 17.721 35.67132207857684 139.7410900804621 17.97 35.67135343963844 139.74104602450186 17.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d809388-9cc2-4f0a-aa16-e39587b991a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d809388-9cc2-4f0a-aa16-e39587b991a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d809388-9cc2-4f0a-aa16-e39587b991a2">
											<gml:posList>35.67138985561951 139.7409996650348 8.16 35.67130929673233 139.74091326459677 8.16 35.67130929673233 139.74091326459677 18.014 35.67138985561951 139.7409996650348 18.014 35.67138985561951 139.7409996650348 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2105b418-1764-4991-a33a-342ea585be81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2105b418-1764-4991-a33a-342ea585be81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2105b418-1764-4991-a33a-342ea585be81">
											<gml:posList>35.671322325349074 139.7410945208267 8.16 35.67138985561951 139.7409996650348 8.16 35.67138985561951 139.7409996650348 18.014 35.671355370158004 139.7410480879553 18.014 35.671355370158004 139.7410480879553 17.97 35.671322325349074 139.7410945208267 17.97 35.671322325349074 139.7410945208267 8.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c7094b0-cf87-4426-9946-8744084ab99b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c7094b0-cf87-4426-9946-8744084ab99b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c7094b0-cf87-4426-9946-8744084ab99b">
											<gml:posList>35.67138379876301 139.7410001470053 18.014 35.67138379876301 139.7410001470053 17.789 35.67135494982043 139.7410406431697 17.789 35.67135494982043 139.7410406431697 18.014 35.67138379876301 139.7410001470053 18.014</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88c630e8-db09-4cba-82cc-ef7121c4cbab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88c630e8-db09-4cba-82cc-ef7121c4cbab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88c630e8-db09-4cba-82cc-ef7121c4cbab">
											<gml:posList>35.67135343963844 139.74104602450186 17.97 35.671355370158004 139.7410480879553 17.97 35.671355370158004 139.7410480879553 18.014 35.67135343963844 139.74104602450186 17.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2524</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">107.30354</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>