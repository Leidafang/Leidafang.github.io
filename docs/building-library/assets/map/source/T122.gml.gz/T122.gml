<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_1ffbe548-5c4f-46f0-9eda-a38ce669d5f9">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66849959526659 139.73763077102055 0 35.668490984853534 139.7376505646815 0 35.66851731863862 139.73766778711322 0 35.66852593806818 139.73764799343687 0 35.66849959526659 139.73763077102055 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66849959526659 139.73763077102055 24.406 35.66852593806818 139.73764799343687 24.406 35.66851731863862 139.73766778711322 24.406 35.668490984853534 139.7376505646815 24.406 35.66849959526659 139.73763077102055 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66849959526659 139.73763077102055 24.406 35.668490984853534 139.7376505646815 24.406 35.668490984853534 139.7376505646815 27.66 35.66849959526659 139.73763077102055 27.66 35.66849959526659 139.73763077102055 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668490984853534 139.7376505646815 24.406 35.66851731863862 139.73766778711322 24.406 35.66851731863862 139.73766778711322 27.66 35.668490984853534 139.7376505646815 27.66 35.668490984853534 139.7376505646815 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851731863862 139.73766778711322 24.406 35.66852593806818 139.73764799343687 24.406 35.66852593806818 139.73764799343687 27.66 35.66851731863862 139.73766778711322 27.66 35.66851731863862 139.73766778711322 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852593806818 139.73764799343687 24.406 35.66849959526659 139.73763077102055 24.406 35.66849959526659 139.73763077102055 27.66 35.66852593806818 139.73764799343687 27.66 35.66852593806818 139.73764799343687 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66849959526659 139.73763077102055 27.66 35.668490984853534 139.7376505646815 27.66 35.66851731863862 139.73766778711322 27.66 35.66852593806818 139.73764799343687 27.66 35.66849959526659 139.73763077102055 27.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3dc0794e-23f5-4326-a854-ad299d7cf73b"/>
							<gml:surfaceMember xlink:href="#poly-4e35a3bb-0b68-41a4-8b40-d87fa1b2adad"/>
							<gml:surfaceMember xlink:href="#poly-ea2286f4-f950-40b6-8648-8ca0d7a7f560"/>
							<gml:surfaceMember xlink:href="#poly-bd2c3cc6-9a5b-4c00-acb3-5832ba8a08ad"/>
							<gml:surfaceMember xlink:href="#poly-4cd51535-dc6c-4948-9a10-3afe5dbcb355"/>
							<gml:surfaceMember xlink:href="#poly-4aa5d878-1ee7-4f88-abe2-d185d9167a2e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3dc0794e-23f5-4326-a854-ad299d7cf73b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dc0794e-23f5-4326-a854-ad299d7cf73b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dc0794e-23f5-4326-a854-ad299d7cf73b">
											<gml:posList>35.66849959526659 139.73763077102055 24.406 35.668525938068186 139.73764799343687 24.406 35.6685173186386 139.73766778711322 24.406 35.66849098485351 139.7376505646815 24.406 35.66849959526659 139.73763077102055 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e35a3bb-0b68-41a4-8b40-d87fa1b2adad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e35a3bb-0b68-41a4-8b40-d87fa1b2adad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e35a3bb-0b68-41a4-8b40-d87fa1b2adad">
											<gml:posList>35.668525938068186 139.73764799343687 27.631 35.66849959526659 139.73763077102055 27.631 35.66849098485351 139.7376505646815 27.631 35.6685173186386 139.73766778711322 27.631 35.668525938068186 139.73764799343687 27.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea2286f4-f950-40b6-8648-8ca0d7a7f560">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea2286f4-f950-40b6-8648-8ca0d7a7f560">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea2286f4-f950-40b6-8648-8ca0d7a7f560">
											<gml:posList>35.668525938068186 139.73764799343687 24.406 35.66849959526659 139.73763077102055 24.406 35.66849959526659 139.73763077102055 27.631 35.668525938068186 139.73764799343687 27.631 35.668525938068186 139.73764799343687 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd2c3cc6-9a5b-4c00-acb3-5832ba8a08ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd2c3cc6-9a5b-4c00-acb3-5832ba8a08ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd2c3cc6-9a5b-4c00-acb3-5832ba8a08ad">
											<gml:posList>35.66849959526659 139.73763077102055 24.406 35.66849098485351 139.7376505646815 24.406 35.66849098485351 139.7376505646815 27.631 35.66849959526659 139.73763077102055 27.631 35.66849959526659 139.73763077102055 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cd51535-dc6c-4948-9a10-3afe5dbcb355">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cd51535-dc6c-4948-9a10-3afe5dbcb355">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cd51535-dc6c-4948-9a10-3afe5dbcb355">
											<gml:posList>35.6685173186386 139.73766778711322 24.406 35.668525938068186 139.73764799343687 24.406 35.668525938068186 139.73764799343687 27.631 35.6685173186386 139.73766778711322 27.631 35.6685173186386 139.73766778711322 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4aa5d878-1ee7-4f88-abe2-d185d9167a2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4aa5d878-1ee7-4f88-abe2-d185d9167a2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4aa5d878-1ee7-4f88-abe2-d185d9167a2e">
											<gml:posList>35.66849098485351 139.7376505646815 24.406 35.6685173186386 139.73766778711322 24.406 35.6685173186386 139.73766778711322 27.631 35.66849098485351 139.7376505646815 27.631 35.66849098485351 139.7376505646815 24.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2741</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">3</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>