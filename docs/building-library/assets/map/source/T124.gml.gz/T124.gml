<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_21602244-dd7f-4a15-b834-8bd098d36709">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">29.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>3</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672125204560494 139.7388614861318 0 35.6721498226667 139.7388520565487 0 35.67208343535408 139.73864397465272 0 35.672086589287275 139.7386428662783 0 35.672062351425716 139.738539831144 0 35.67192754356256 139.7385874903676 0 35.67194961053674 139.73868091747218 0 35.67198511643016 139.73867049186214 0 35.671986925166095 139.73867811179818 0 35.67197133577244 139.73868365344288 0 35.672035276936334 139.73895642619226 0 35.672051958378425 139.7389641390981 0 35.67213577197857 139.7389002027127 0 35.67212740172354 139.73887018818476 0 35.672125204560494 139.7388614861318 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672125204560494 139.7388614861318 9.9 35.67212740172354 139.73887018818476 9.9 35.67213577197857 139.7389002027127 9.9 35.672051958378425 139.7389641390981 9.9 35.672035276936334 139.73895642619226 9.9 35.67197133577244 139.73868365344288 9.9 35.671986925166095 139.73867811179818 9.9 35.67198511643016 139.73867049186214 9.9 35.67194961053674 139.73868091747218 9.9 35.67192754356256 139.7385874903676 9.9 35.672062351425716 139.738539831144 9.9 35.672086589287275 139.7386428662783 9.9 35.67208343535408 139.73864397465272 9.9 35.6721498226667 139.7388520565487 9.9 35.672125204560494 139.7388614861318 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672125204560494 139.7388614861318 9.9 35.6721498226667 139.7388520565487 9.9 35.6721498226667 139.7388520565487 38.2 35.672125204560494 139.7388614861318 38.2 35.672125204560494 139.7388614861318 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6721498226667 139.7388520565487 9.9 35.67208343535408 139.73864397465272 9.9 35.67208343535408 139.73864397465272 38.2 35.6721498226667 139.7388520565487 38.2 35.6721498226667 139.7388520565487 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67208343535408 139.73864397465272 9.9 35.672086589287275 139.7386428662783 9.9 35.672086589287275 139.7386428662783 38.2 35.67208343535408 139.73864397465272 38.2 35.67208343535408 139.73864397465272 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672086589287275 139.7386428662783 9.9 35.672062351425716 139.738539831144 9.9 35.672062351425716 139.738539831144 38.2 35.672086589287275 139.7386428662783 38.2 35.672086589287275 139.7386428662783 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672062351425716 139.738539831144 9.9 35.67192754356256 139.7385874903676 9.9 35.67192754356256 139.7385874903676 38.2 35.672062351425716 139.738539831144 38.2 35.672062351425716 139.738539831144 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67192754356256 139.7385874903676 9.9 35.67194961053674 139.73868091747218 9.9 35.67194961053674 139.73868091747218 38.2 35.67192754356256 139.7385874903676 38.2 35.67192754356256 139.7385874903676 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67194961053674 139.73868091747218 9.9 35.67198511643016 139.73867049186214 9.9 35.67198511643016 139.73867049186214 38.2 35.67194961053674 139.73868091747218 38.2 35.67194961053674 139.73868091747218 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67198511643016 139.73867049186214 9.9 35.671986925166095 139.73867811179818 9.9 35.671986925166095 139.73867811179818 38.2 35.67198511643016 139.73867049186214 38.2 35.67198511643016 139.73867049186214 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671986925166095 139.73867811179818 9.9 35.67197133577244 139.73868365344288 9.9 35.67197133577244 139.73868365344288 38.2 35.671986925166095 139.73867811179818 38.2 35.671986925166095 139.73867811179818 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67197133577244 139.73868365344288 9.9 35.672035276936334 139.73895642619226 9.9 35.672035276936334 139.73895642619226 38.2 35.67197133577244 139.73868365344288 38.2 35.67197133577244 139.73868365344288 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672035276936334 139.73895642619226 9.9 35.672051958378425 139.7389641390981 9.9 35.672051958378425 139.7389641390981 38.2 35.672035276936334 139.73895642619226 38.2 35.672035276936334 139.73895642619226 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672051958378425 139.7389641390981 9.9 35.67213577197857 139.7389002027127 9.9 35.67213577197857 139.7389002027127 38.2 35.672051958378425 139.7389641390981 38.2 35.672051958378425 139.7389641390981 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67213577197857 139.7389002027127 9.9 35.67212740172354 139.73887018818476 9.9 35.67212740172354 139.73887018818476 38.2 35.67213577197857 139.7389002027127 38.2 35.67213577197857 139.7389002027127 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212740172354 139.73887018818476 9.9 35.672125204560494 139.7388614861318 9.9 35.672125204560494 139.7388614861318 38.2 35.67212740172354 139.73887018818476 38.2 35.67212740172354 139.73887018818476 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672125204560494 139.7388614861318 38.2 35.6721498226667 139.7388520565487 38.2 35.67208343535408 139.73864397465272 38.2 35.672086589287275 139.7386428662783 38.2 35.672062351425716 139.738539831144 38.2 35.67192754356256 139.7385874903676 38.2 35.67194961053674 139.73868091747218 38.2 35.67198511643016 139.73867049186214 38.2 35.671986925166095 139.73867811179818 38.2 35.67197133577244 139.73868365344288 38.2 35.672035276936334 139.73895642619226 38.2 35.672051958378425 139.7389641390981 38.2 35.67213577197857 139.7389002027127 38.2 35.67212740172354 139.73887018818476 38.2 35.672125204560494 139.7388614861318 38.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-92ee53eb-a658-4aaa-ad36-2e766893113d"/>
							<gml:surfaceMember xlink:href="#poly-dc3f1302-1669-4e93-87d8-ebe74cc7b4c1"/>
							<gml:surfaceMember xlink:href="#poly-b0c45997-7d3e-41a9-acec-0aa8108bbfa4"/>
							<gml:surfaceMember xlink:href="#poly-126ef808-a7c1-45ef-ba50-4f0aa8a5d12e"/>
							<gml:surfaceMember xlink:href="#poly-0c903f2e-c4e0-414d-9bf2-a067df559c83"/>
							<gml:surfaceMember xlink:href="#poly-531d3982-4f5a-4563-a1c5-a752196c8a77"/>
							<gml:surfaceMember xlink:href="#poly-77423173-1915-4a40-938c-8c163cbe215f"/>
							<gml:surfaceMember xlink:href="#poly-6e8148d5-41f9-4aa1-bf49-7f86dde5b38b"/>
							<gml:surfaceMember xlink:href="#poly-6aec18af-4534-4ec9-a871-a908b971f096"/>
							<gml:surfaceMember xlink:href="#poly-b2e4a39d-9f1b-4ee0-ba19-864ee56c2e6f"/>
							<gml:surfaceMember xlink:href="#poly-f69bf4eb-2cd8-4d92-9986-91ff10f6ffc5"/>
							<gml:surfaceMember xlink:href="#poly-2b82b4f0-06cc-411a-b99d-a7394c9a3bd4"/>
							<gml:surfaceMember xlink:href="#poly-cb548a6d-e537-4f88-8a61-e3483aa84bb5"/>
							<gml:surfaceMember xlink:href="#poly-1069acaf-15f2-4afc-ac17-4302b683098a"/>
							<gml:surfaceMember xlink:href="#poly-33d8b5cd-e1d8-4b1c-b72c-57d1e34965f2"/>
							<gml:surfaceMember xlink:href="#poly-0c389d86-5b2c-4cd6-8819-05488a7315ef"/>
							<gml:surfaceMember xlink:href="#poly-a41395bb-a707-4066-9a90-0250a2cee7b1"/>
							<gml:surfaceMember xlink:href="#poly-3fc2a988-cee3-44cb-9cef-2721644364ac"/>
							<gml:surfaceMember xlink:href="#poly-febbfab0-b95b-4adb-999a-9e596227c93e"/>
							<gml:surfaceMember xlink:href="#poly-95cfa199-3583-431c-a9b8-2ab53f8699b6"/>
							<gml:surfaceMember xlink:href="#poly-e38df353-c353-49a9-81f3-c77f6ab6d5e3"/>
							<gml:surfaceMember xlink:href="#poly-26157708-9d4a-4d79-aa74-f69a5fca5d13"/>
							<gml:surfaceMember xlink:href="#poly-1b489a6e-f926-4abe-ad1e-949803f7b3c5"/>
							<gml:surfaceMember xlink:href="#poly-3416c946-0f8d-4427-a8d6-f252dd8a8770"/>
							<gml:surfaceMember xlink:href="#poly-b6c4fdf6-9d54-4c15-ab79-ed75eb237484"/>
							<gml:surfaceMember xlink:href="#poly-c7625ee5-cf5f-40c1-89b4-11f1913826fc"/>
							<gml:surfaceMember xlink:href="#poly-e71b7443-cb4b-4c20-b0c4-a9649bd79e23"/>
							<gml:surfaceMember xlink:href="#poly-22bf33bd-ad57-42d4-8f30-bdeb56e577c1"/>
							<gml:surfaceMember xlink:href="#poly-c99968ee-2ba9-4f54-ba53-5f5f4f773685"/>
							<gml:surfaceMember xlink:href="#poly-dacc6f55-625a-4798-8714-32d19c0e317d"/>
							<gml:surfaceMember xlink:href="#poly-4527fde1-0b5a-4d54-ae39-4cd1d715ac06"/>
							<gml:surfaceMember xlink:href="#poly-3e54be50-f70a-481d-beab-6be377582838"/>
							<gml:surfaceMember xlink:href="#poly-7a13d165-3beb-4c71-83fb-e058c88cf090"/>
							<gml:surfaceMember xlink:href="#poly-5f52b854-543e-4723-8908-491c4c22b6ed"/>
							<gml:surfaceMember xlink:href="#poly-12f1b44f-b9c0-4c28-b83b-5f53105f9f29"/>
							<gml:surfaceMember xlink:href="#poly-349f25b7-54ed-4d90-bf1e-eb891156b94d"/>
							<gml:surfaceMember xlink:href="#poly-ea6df4dc-77f4-4fbd-9276-825376adb758"/>
							<gml:surfaceMember xlink:href="#poly-c562838c-e8bc-448f-b37b-d9ce15e865fc"/>
							<gml:surfaceMember xlink:href="#poly-a9dc654a-0072-4e41-b7c8-1770135f5591"/>
							<gml:surfaceMember xlink:href="#poly-b57a3206-2f4e-4339-8664-662d0aa066bc"/>
							<gml:surfaceMember xlink:href="#poly-8b52f5fc-a437-45e9-aa24-4722fa1db9a9"/>
							<gml:surfaceMember xlink:href="#poly-095f55fc-475d-4b4e-a8f5-ee49b1216346"/>
							<gml:surfaceMember xlink:href="#poly-d135d9c7-3527-4a77-94ec-04bba492899a"/>
							<gml:surfaceMember xlink:href="#poly-c03e66ab-5c4e-4fa2-9910-2ee5bed7f973"/>
							<gml:surfaceMember xlink:href="#poly-eb4970b7-8239-4abb-a217-8300ab1010f1"/>
							<gml:surfaceMember xlink:href="#poly-04f468c4-f1fb-45dc-b281-7ddafe4070d1"/>
							<gml:surfaceMember xlink:href="#poly-124d6063-8276-4ddd-a90e-e95747610826"/>
							<gml:surfaceMember xlink:href="#poly-742414f6-5f38-4298-9725-2ca86e4cfadc"/>
							<gml:surfaceMember xlink:href="#poly-77f290df-15d1-42e8-bd90-fe757424cc8e"/>
							<gml:surfaceMember xlink:href="#poly-2e2ffd37-f7f5-403b-a02d-fd374f9c6113"/>
							<gml:surfaceMember xlink:href="#poly-7069d7c5-4f42-4653-9f3d-b3674cedcbb3"/>
							<gml:surfaceMember xlink:href="#poly-205f95f7-787f-4d69-93c8-83edf741946d"/>
							<gml:surfaceMember xlink:href="#poly-a78f7619-ce64-4eda-9a3f-184efc384016"/>
							<gml:surfaceMember xlink:href="#poly-5720e9e7-1e5d-4283-9ac4-e81972e1dfe4"/>
							<gml:surfaceMember xlink:href="#poly-977a3096-bdb7-447c-9ef8-c4a3c75bbd40"/>
							<gml:surfaceMember xlink:href="#poly-dbfb7849-99e9-4550-bfdb-4133e928701e"/>
							<gml:surfaceMember xlink:href="#poly-4cd4ce1a-08a2-4392-8f8e-9d71be987304"/>
							<gml:surfaceMember xlink:href="#poly-73d4038b-8782-42fe-95ec-54a64c94a57d"/>
							<gml:surfaceMember xlink:href="#poly-7117f697-153b-45b2-b80c-cb33414e7331"/>
							<gml:surfaceMember xlink:href="#poly-b5c28b50-e1c4-487e-b228-51819d60cbe2"/>
							<gml:surfaceMember xlink:href="#poly-a90ddd03-d4eb-47ed-b96a-b04755894a04"/>
							<gml:surfaceMember xlink:href="#poly-2f208401-b013-493b-a7ac-7071939e5748"/>
							<gml:surfaceMember xlink:href="#poly-252ab348-ee47-437e-ad49-c453ded83767"/>
							<gml:surfaceMember xlink:href="#poly-1a142302-8943-42dd-805b-0aad4b247df7"/>
							<gml:surfaceMember xlink:href="#poly-22bd4a0e-3cee-4b2f-bdf4-e882ff7f9389"/>
							<gml:surfaceMember xlink:href="#poly-8043fe9a-9e8d-4d23-baae-81afc33cb304"/>
							<gml:surfaceMember xlink:href="#poly-21cbe09a-1f07-4fbc-a914-8cfa2f38d466"/>
							<gml:surfaceMember xlink:href="#poly-b880f365-2de1-4309-b8c6-fea23a78675e"/>
							<gml:surfaceMember xlink:href="#poly-179e5a79-f48c-46eb-ae20-2eef1fcbc53c"/>
							<gml:surfaceMember xlink:href="#poly-e4a2f136-ba7c-4a93-91e8-6b54ff734064"/>
							<gml:surfaceMember xlink:href="#poly-36ed6a5e-374c-4c59-94a8-bac5b9ac0d04"/>
							<gml:surfaceMember xlink:href="#poly-14d81a7f-4194-4bee-8280-3f22a71359db"/>
							<gml:surfaceMember xlink:href="#poly-3fe6b0ba-9c09-4baf-8fcb-b1686759e575"/>
							<gml:surfaceMember xlink:href="#poly-36f8b94a-f703-4afc-b567-afed5231d824"/>
							<gml:surfaceMember xlink:href="#poly-a9ccd57f-64f8-4294-b256-6b9f5d68d390"/>
							<gml:surfaceMember xlink:href="#poly-e646603c-54e3-4f24-acca-f9d516dd6796"/>
							<gml:surfaceMember xlink:href="#poly-6b53efee-053b-44ce-8d30-a83bfd5b606d"/>
							<gml:surfaceMember xlink:href="#poly-03c53061-cd35-445c-94b9-7debb192e382"/>
							<gml:surfaceMember xlink:href="#poly-8f1cedad-0407-4988-9926-da76115cd3d7"/>
							<gml:surfaceMember xlink:href="#poly-93a8a979-beb4-4184-88f9-0064171fbfcb"/>
							<gml:surfaceMember xlink:href="#poly-2dcbd12d-bdc3-4aa2-862f-f04018509ff0"/>
							<gml:surfaceMember xlink:href="#poly-55be6de4-4184-4c15-b5da-a3a32800f287"/>
							<gml:surfaceMember xlink:href="#poly-d076dad6-7f93-43f5-ac3a-b9eee7d367d9"/>
							<gml:surfaceMember xlink:href="#poly-cb46242c-540c-47d1-ad43-95cb525f67ea"/>
							<gml:surfaceMember xlink:href="#poly-d31e5a41-139d-419f-bc6c-df55c7f37c8a"/>
							<gml:surfaceMember xlink:href="#poly-a7554232-fe59-472d-b21c-8856115c2c57"/>
							<gml:surfaceMember xlink:href="#poly-5969e060-5812-4331-b1b4-2c3720ee0ac2"/>
							<gml:surfaceMember xlink:href="#poly-c7fdeae7-0970-490a-ac65-1070cfd8a5db"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_21602244-dd7f-4a15-b834-8bd098d36709_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afc18581-2291-436a-8663-aba43709f656">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67204656511334 139.73861584965246 30.662 35.67207110275489 139.7386072817247 30.662 35.67205787088913 139.73855037479348 30.662 35.67198422193689 139.7385761007445 30.662 35.67199428828452 139.73861940210148 30.662 35.67199289154027 139.73861988979672 30.662 35.6719824543698 139.73857498713915 30.662 35.67205909505938 139.73854821928057 30.662 35.67207307761114 139.73860836194763 30.662 35.672047864123 139.73861716265 30.662 35.67204772917789 139.73861749420408 30.662 35.67204565660453 139.73861823676737 30.662 35.67204656511334 139.73861584965246 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa61301c-be4e-407d-8528-3e72a6ae6efa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67204485053093 139.73862479933388 30.662 35.67204471560317 139.73862515298094 30.662 35.67204795349632 139.73863911191813 30.662 35.672046016076486 139.7386397880423 30.662 35.67204276012123 139.73862578494075 30.662 35.672044172373226 139.73862209374533 30.662 35.67204485053093 139.73862479933388 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60ae1bc0-28f8-47b1-8d72-daa37b05fb3a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672044172373226 139.73862209374533 30.857 35.67204565660453 139.73861823676737 30.857 35.67204772917789 139.73861749420408 30.857 35.67204485053093 139.73862479933388 30.857 35.672044172373226 139.73862209374533 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b415bdb-8810-43d7-875f-55a0d6621419">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b415bdb-8810-43d7-875f-55a0d6621419_0">
											<gml:posList>35.67204485053093 139.73862479933388 30.857 35.67204485053093 139.73862479933388 30.662 35.672044172373226 139.73862209374533 30.662 35.672044172373226 139.73862209374533 30.857 35.67204485053093 139.73862479933388 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2301b2df-867c-44f7-bfbb-8d8f4e5edfcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2301b2df-867c-44f7-bfbb-8d8f4e5edfcb_0">
											<gml:posList>35.67204772917789 139.73861749420408 30.662 35.67204772917789 139.73861749420408 30.857 35.67204565660453 139.73861823676737 30.857 35.67204565660453 139.73861823676737 30.662 35.67204772917789 139.73861749420408 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9474be6-2445-420e-8ff9-91d5f9e10afe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9474be6-2445-420e-8ff9-91d5f9e10afe_0">
											<gml:posList>35.6719824543698 139.73857498713915 30.662 35.6719824543698 139.73857498713915 31.91 35.67205909505938 139.73854821928057 31.91 35.67205909505938 139.73854821928057 30.662 35.6719824543698 139.73857498713915 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4551adc8-7960-46d1-b283-5b4aea77a357">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4551adc8-7960-46d1-b283-5b4aea77a357_0">
											<gml:posList>35.67205787088913 139.73855037479348 31.91 35.67198422193689 139.7385761007445 31.91 35.67198422193689 139.7385761007445 30.662 35.67205787088913 139.73855037479348 30.662 35.67205787088913 139.73855037479348 31.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed2a4aae-c9c3-408f-b19c-061e181a63c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed2a4aae-c9c3-408f-b19c-061e181a63c4_0">
											<gml:posList>35.67207307761114 139.73860836194763 31.91 35.67207307761114 139.73860836194763 30.662 35.67205909505938 139.73854821928057 30.662 35.67205909505938 139.73854821928057 31.91 35.67207307761114 139.73860836194763 31.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09c0dd64-a86c-475d-9893-ede3dc57f877">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09c0dd64-a86c-475d-9893-ede3dc57f877_0">
											<gml:posList>35.67207110275489 139.7386072817247 30.662 35.67207110275489 139.7386072817247 31.91 35.67205787088913 139.73855037479348 31.91 35.67205787088913 139.73855037479348 30.662 35.67207110275489 139.7386072817247 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3dc4cc5-2c56-4b1a-87ce-dbc67499e65f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3dc4cc5-2c56-4b1a-87ce-dbc67499e65f_0">
											<gml:posList>35.67204471560317 139.73862515298094 31.91 35.672047864123 139.73861716265 31.91 35.67207307761114 139.73860836194763 31.91 35.67205909505938 139.73854821928057 31.91 35.6719824543698 139.73857498713915 31.91 35.67199289154027 139.73861988979672 31.91 35.67199428828452 139.73861940210148 31.91 35.67198422193689 139.7385761007445 31.91 35.67205787088913 139.73855037479348 31.91 35.67207110275489 139.7386072817247 31.91 35.67204656511334 139.73861584965246 31.91 35.67204276012123 139.73862578494075 31.91 35.672046016076486 139.7386397880423 31.91 35.67204795349632 139.73863911191813 31.91 35.67204471560317 139.73862515298094 31.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0afd8067-292f-4b8a-af4c-09e87eebbaed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0afd8067-292f-4b8a-af4c-09e87eebbaed_0">
											<gml:posList>35.67199289154027 139.73861988979672 30.662 35.67199289154027 139.73861988979672 31.91 35.6719824543698 139.73857498713915 31.91 35.6719824543698 139.73857498713915 30.662 35.67199289154027 139.73861988979672 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0ca8f55-49b5-4026-84e9-523371213b4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0ca8f55-49b5-4026-84e9-523371213b4a_0">
											<gml:posList>35.67198422193689 139.7385761007445 30.662 35.67198422193689 139.7385761007445 31.91 35.67199428828452 139.73861940210148 31.91 35.67199428828452 139.73861940210148 30.662 35.67198422193689 139.7385761007445 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9318d1d-42e7-4b06-b0ce-98921ad85ded">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9318d1d-42e7-4b06-b0ce-98921ad85ded_0">
											<gml:posList>35.67204656511334 139.73861584965246 31.91 35.67207110275489 139.7386072817247 31.91 35.67207110275489 139.7386072817247 30.662 35.67204656511334 139.73861584965246 30.662 35.67204656511334 139.73861584965246 31.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36ac1393-aeee-4107-b873-8e3be5d52329">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36ac1393-aeee-4107-b873-8e3be5d52329_0">
											<gml:posList>35.67207307761114 139.73860836194763 31.91 35.672047864123 139.73861716265 31.91 35.672047864123 139.73861716265 30.662 35.67207307761114 139.73860836194763 30.662 35.67207307761114 139.73860836194763 31.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27a614c4-7808-455a-820d-e4eb061f019a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27a614c4-7808-455a-820d-e4eb061f019a_0">
											<gml:posList>35.67199428828452 139.73861940210148 30.662 35.67199428828452 139.73861940210148 31.91 35.67199289154027 139.73861988979672 31.91 35.67199289154027 139.73861988979672 30.662 35.67199428828452 139.73861940210148 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-097c8680-af25-47d3-aaa1-8b536121347d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-097c8680-af25-47d3-aaa1-8b536121347d_0">
											<gml:posList>35.67204276012123 139.73862578494075 31.91 35.67204656511334 139.73861584965246 31.91 35.67204656511334 139.73861584965246 30.662 35.67204565660453 139.73861823676737 30.662 35.67204565660453 139.73861823676737 30.857 35.672044172373226 139.73862209374533 30.857 35.672044172373226 139.73862209374533 30.662 35.67204276012123 139.73862578494075 30.662 35.67204276012123 139.73862578494075 31.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e56cdd1-fd4c-49eb-b49f-f3bdb2341b1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e56cdd1-fd4c-49eb-b49f-f3bdb2341b1c_0">
											<gml:posList>35.672047864123 139.73861716265 30.662 35.672047864123 139.73861716265 31.91 35.67204471560317 139.73862515298094 31.91 35.67204471560317 139.73862515298094 30.662 35.67204485053093 139.73862479933388 30.662 35.67204485053093 139.73862479933388 30.857 35.67204772917789 139.73861749420408 30.857 35.67204772917789 139.73861749420408 30.662 35.672047864123 139.73861716265 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ea859a6-ae62-4573-b7c2-111be3e22cea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ea859a6-ae62-4573-b7c2-111be3e22cea_0">
											<gml:posList>35.67204471560317 139.73862515298094 30.662 35.67204471560317 139.73862515298094 31.91 35.67204795349632 139.73863911191813 31.91 35.67204795349632 139.73863911191813 30.662 35.67204471560317 139.73862515298094 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26f65fd0-aa32-4ae1-a2d2-ebfe4d300af1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26f65fd0-aa32-4ae1-a2d2-ebfe4d300af1_0">
											<gml:posList>35.672046016076486 139.7386397880423 30.662 35.672046016076486 139.7386397880423 31.91 35.67204276012123 139.73862578494075 31.91 35.67204276012123 139.73862578494075 30.662 35.672046016076486 139.7386397880423 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d62b5800-fe1a-4d66-8cd4-51947a58bd5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d62b5800-fe1a-4d66-8cd4-51947a58bd5f_0">
											<gml:posList>35.67204795349632 139.73863911191813 30.662 35.67204795349632 139.73863911191813 31.91 35.672046016076486 139.7386397880423 31.91 35.672046016076486 139.7386397880423 30.662 35.67204795349632 139.73863911191813 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_21602244-dd7f-4a15-b834-8bd098d36709_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da297acc-2c40-4533-9e22-f3a46c19d4f5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67201872467869 139.7386196273021 30.662 35.672012520862324 139.73859369748632 30.662 35.672031507424435 139.73858688146063 30.662 35.672037702219846 139.7386128002462 30.662 35.67201872467869 139.7386196273021 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cf3aa81-790f-48f6-88cd-1a2926190e89">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672023449867574 139.73870241512998 40.919 35.67204510374154 139.73869463493602 40.919 35.67206254855643 139.73876760955642 40.919 35.67204088565539 139.73877537869657 40.919 35.672023449867574 139.73870241512998 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65a30c3e-753e-4a50-81bc-8403a6b645ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65a30c3e-753e-4a50-81bc-8403a6b645ac_0">
											<gml:posList>35.672012520862324 139.73859369748632 33.056 35.672031507424435 139.73858688146063 33.056 35.672031507424435 139.73858688146063 30.662 35.672012520862324 139.73859369748632 30.662 35.672012520862324 139.73859369748632 33.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81c2502b-8627-4d4e-a3f8-1d01d495dfe9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81c2502b-8627-4d4e-a3f8-1d01d495dfe9_0">
											<gml:posList>35.672031507424435 139.73858688146063 33.056 35.672012520862324 139.73859369748632 33.056 35.67201872467869 139.7386196273021 33.056 35.672037702219846 139.7386128002462 33.056 35.672031507424435 139.73858688146063 33.056</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1106cd6e-f6c0-4c9f-bffe-2d0b9537dac3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1106cd6e-f6c0-4c9f-bffe-2d0b9537dac3_0">
											<gml:posList>35.672012520862324 139.73859369748632 30.662 35.67201872467869 139.7386196273021 30.662 35.67201872467869 139.7386196273021 33.056 35.672012520862324 139.73859369748632 33.056 35.672012520862324 139.73859369748632 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ea8803e-71a8-4dd2-9243-cdb5c12e10fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ea8803e-71a8-4dd2-9243-cdb5c12e10fd_0">
											<gml:posList>35.67201872467869 139.7386196273021 30.662 35.672037702219846 139.7386128002462 30.662 35.672037702219846 139.7386128002462 33.056 35.67201872467869 139.7386196273021 33.056 35.67201872467869 139.7386196273021 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff223897-7680-4dc0-bc6c-68ada3d15af4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff223897-7680-4dc0-bc6c-68ada3d15af4_0">
											<gml:posList>35.67204510374154 139.73869463493602 40.919 35.672023449867574 139.73870241512998 40.919 35.672023449867574 139.73870241512998 43.147 35.67204510374154 139.73869463493602 43.147 35.67204510374154 139.73869463493602 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de469f29-8616-44fc-971a-9769daeee7e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de469f29-8616-44fc-971a-9769daeee7e8_0">
											<gml:posList>35.672023449867574 139.73870241512998 40.919 35.67204088565539 139.73877537869657 40.919 35.67204088565539 139.73877537869657 43.147 35.672023449867574 139.73870241512998 43.147 35.672023449867574 139.73870241512998 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca42a893-536c-4c99-bee4-e50a613c6b3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca42a893-536c-4c99-bee4-e50a613c6b3a_0">
											<gml:posList>35.672031507424435 139.73858688146063 30.662 35.672031507424435 139.73858688146063 33.056 35.672037702219846 139.7386128002462 33.056 35.672037702219846 139.7386128002462 30.662 35.672031507424435 139.73858688146063 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-653ba268-59b8-43ed-81bb-b675f1e4c14e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-653ba268-59b8-43ed-81bb-b675f1e4c14e_0">
											<gml:posList>35.67204510374154 139.73869463493602 40.919 35.67204510374154 139.73869463493602 43.147 35.67206254855643 139.73876760955642 43.147 35.67206254855643 139.73876760955642 40.919 35.67204510374154 139.73869463493602 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38871e59-d168-476e-8fa6-a389a68eb455">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38871e59-d168-476e-8fa6-a389a68eb455_0">
											<gml:posList>35.672023449867574 139.73870241512998 43.147 35.67204088565539 139.73877537869657 43.147 35.67206254855643 139.73876760955642 43.147 35.67204510374154 139.73869463493602 43.147 35.672023449867574 139.73870241512998 43.147</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c025868-485c-4a80-a1b5-48b228b47bb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c025868-485c-4a80-a1b5-48b228b47bb2_0">
											<gml:posList>35.67206254855643 139.73876760955642 40.919 35.67206254855643 139.73876760955642 43.147 35.67204088565539 139.73877537869657 43.147 35.67204088565539 139.73877537869657 40.919 35.67206254855643 139.73876760955642 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_21602244-dd7f-4a15-b834-8bd098d36709_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25587a7a-c03f-49d9-a8ab-68dbb94b0bf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25587a7a-c03f-49d9-a8ab-68dbb94b0bf3_0">
											<gml:posList>35.671974065307445 139.73863573059515 27.03 35.67196459435511 139.73863887898153 27.409 35.67196459435511 139.73863887898153 27.03 35.671974065307445 139.73863573059515 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fa3b2d2-c4dc-4c58-b680-14d0af6fcd85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fa3b2d2-c4dc-4c58-b680-14d0af6fcd85_0">
											<gml:posList>35.671974065307445 139.73863573059515 27.03 35.671974065307445 139.73863573059515 27.409 35.67196459435511 139.73863887898153 27.409 35.671974065307445 139.73863573059515 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d35dbfe-5382-4bbd-b279-37954c64dcff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d35dbfe-5382-4bbd-b279-37954c64dcff_0">
											<gml:posList>35.67198816927212 139.73862106630244 27.03 35.67196259532078 139.73862997788197 27.409 35.67198816927212 139.73862106630244 27.409 35.67198816927212 139.73862106630244 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9559884e-9802-43d6-85a5-8bf60b82136a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9559884e-9802-43d6-85a5-8bf60b82136a_0">
											<gml:posList>35.67198816927212 139.73862106630244 27.03 35.67196259532078 139.73862997788197 27.03 35.67196259532078 139.73862997788197 27.409 35.67198816927212 139.73862106630244 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-830521c3-2a1f-4c96-a0a5-8e94c9e45f8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-830521c3-2a1f-4c96-a0a5-8e94c9e45f8a_0">
											<gml:posList>35.671990276497816 139.73863000041626 27.409 35.67198216640015 139.73863287103455 27.03 35.671990276497816 139.73863000041626 27.03 35.671990276497816 139.73863000041626 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36907151-8952-443e-bd43-9aa59d5f43a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36907151-8952-443e-bd43-9aa59d5f43a9_0">
											<gml:posList>35.671990276497816 139.73863000041626 27.409 35.67198216640015 139.73863287103455 27.409 35.67198216640015 139.73863287103455 27.03 35.671990276497816 139.73863000041626 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-141a2442-f602-4a77-9668-da6adf451cca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-141a2442-f602-4a77-9668-da6adf451cca_0">
											<gml:posList>35.67198816927212 139.73862106630244 27.409 35.671990276497816 139.73863000041626 27.03 35.67198816927212 139.73862106630244 27.03 35.67198816927212 139.73862106630244 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f6249de-2e1c-4356-a971-92932c579de1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f6249de-2e1c-4356-a971-92932c579de1_0">
											<gml:posList>35.67198816927212 139.73862106630244 27.409 35.671990276497816 139.73863000041626 27.409 35.671990276497816 139.73863000041626 27.03 35.67198816927212 139.73862106630244 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-033c7a80-235d-4e99-88a8-56a680d2b4e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-033c7a80-235d-4e99-88a8-56a680d2b4e2_0">
											<gml:posList>35.67200158120334 139.73860897665267 30.662 35.672005280179576 139.73862469142787 31.032 35.67200158120334 139.73860897665267 31.032 35.67200158120334 139.73860897665267 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c26b322e-fb04-485e-aa9c-caa3655487c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c26b322e-fb04-485e-aa9c-caa3655487c6_0">
											<gml:posList>35.67200158120334 139.73860897665267 30.662 35.672005280179576 139.73862469142787 30.662 35.672005280179576 139.73862469142787 31.032 35.67200158120334 139.73860897665267 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15f074f7-6ed8-4352-bcce-151b08ddb351">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15f074f7-6ed8-4352-bcce-151b08ddb351_0">
											<gml:posList>35.67200998866625 139.7386059952151 30.662 35.67200158120334 139.73860897665267 31.032 35.67200998866625 139.7386059952151 31.032 35.67200998866625 139.7386059952151 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e2661d1-135d-482b-ae73-1478fa7d52aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e2661d1-135d-482b-ae73-1478fa7d52aa_0">
											<gml:posList>35.67200998866625 139.7386059952151 30.662 35.67200158120334 139.73860897665267 30.662 35.67200158120334 139.73860897665267 31.032 35.67200998866625 139.7386059952151 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-007954a9-3ec3-478a-b17e-129f848bee5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-007954a9-3ec3-478a-b17e-129f848bee5a_0">
											<gml:posList>35.67200158120334 139.73860897665267 31.032 35.67201242607834 139.73862216438798 31.032 35.67200998866625 139.7386059952151 31.032 35.67200158120334 139.73860897665267 31.032</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75adddcc-1a81-44bc-9840-d24f8ffa2e1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75adddcc-1a81-44bc-9840-d24f8ffa2e1a_0">
											<gml:posList>35.67200998866625 139.7386059952151 31.032 35.67201242607834 139.73862216438798 31.032 35.67201368765156 139.73862172103824 31.032 35.67200998866625 139.7386059952151 31.032</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c148fd3f-cb9f-4c44-8024-221db1354605">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c148fd3f-cb9f-4c44-8024-221db1354605_0">
											<gml:posList>35.672005280179576 139.73862469142787 31.032 35.67201242607834 139.73862216438798 31.032 35.67200158120334 139.73860897665267 31.032 35.672005280179576 139.73862469142787 31.032</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd1af4c0-1f23-465f-a44b-69d266d4013e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd1af4c0-1f23-465f-a44b-69d266d4013e_0">
											<gml:posList>35.67201242607834 139.73862216438798 30.662 35.672005280179576 139.73862469142787 31.032 35.672005280179576 139.73862469142787 30.662 35.67201242607834 139.73862216438798 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-940c9cf1-6920-4df5-9805-06a4961153bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-940c9cf1-6920-4df5-9805-06a4961153bd_0">
											<gml:posList>35.67201242607834 139.73862216438798 30.662 35.67201242607834 139.73862216438798 31.032 35.672005280179576 139.73862469142787 31.032 35.67201242607834 139.73862216438798 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fb7ce7a-9fe3-417f-aa58-c8d6707cee71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fb7ce7a-9fe3-417f-aa58-c8d6707cee71_0">
											<gml:posList>35.67200998866625 139.7386059952151 30.662 35.67201368765156 139.73862172103824 31.032 35.67201368765156 139.73862172103824 30.662 35.67200998866625 139.7386059952151 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a838866-748d-4d24-92e0-07de57f9542d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a838866-748d-4d24-92e0-07de57f9542d_0">
											<gml:posList>35.67200998866625 139.7386059952151 30.662 35.67200998866625 139.7386059952151 31.032 35.67201368765156 139.73862172103824 31.032 35.67200998866625 139.7386059952151 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d5b483a-f3b5-4dea-aab1-ed0f9f6b1ddc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d5b483a-f3b5-4dea-aab1-ed0f9f6b1ddc_0">
											<gml:posList>35.67201368765156 139.73862172103824 30.662 35.67201242607834 139.73862216438798 31.032 35.67201242607834 139.73862216438798 30.662 35.67201368765156 139.73862172103824 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f9827ae-67ed-4c77-b8c9-c190361669e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f9827ae-67ed-4c77-b8c9-c190361669e9_0">
											<gml:posList>35.67201368765156 139.73862172103824 30.662 35.67201368765156 139.73862172103824 31.032 35.67201242607834 139.73862216438798 31.032 35.67201368765156 139.73862172103824 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ccbe6d4-a641-47e8-b235-36a8263dcd4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ccbe6d4-a641-47e8-b235-36a8263dcd4e_0">
											<gml:posList>35.67212520456049 139.7388614861318 38.7 35.67212740172353 139.73887018818476 9.97 35.67212740172353 139.73887018818476 38.7 35.67212520456049 139.7388614861318 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ed19c65-a61c-4779-bfd8-5ce988c92c9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ed19c65-a61c-4779-bfd8-5ce988c92c9d_0">
											<gml:posList>35.67212520456049 139.7388614861318 38.7 35.67212520456049 139.7388614861318 9.97 35.67212740172353 139.73887018818476 9.97 35.67212520456049 139.7388614861318 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cfa0259-b8db-4157-b212-cc08310852c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cfa0259-b8db-4157-b212-cc08310852c7_0">
											<gml:posList>35.67212740172353 139.73887018818476 38.7 35.672135771978546 139.73890020271267 9.97 35.672135771978546 139.73890020271267 38.7 35.67212740172353 139.73887018818476 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1918879b-a751-4b46-a050-dcbbf3d4e6ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1918879b-a751-4b46-a050-dcbbf3d4e6ec_0">
											<gml:posList>35.67212740172353 139.73887018818476 38.7 35.67212740172353 139.73887018818476 9.97 35.672135771978546 139.73890020271267 9.97 35.67212740172353 139.73887018818476 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8d4e1cb-5e68-4b61-9e4d-d1b9d9eef5cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8d4e1cb-5e68-4b61-9e4d-d1b9d9eef5cf_0">
											<gml:posList>35.6721498226667 139.7388520565487 38.7 35.67212520456049 139.7388614861318 9.97 35.67212520456049 139.7388614861318 38.7 35.6721498226667 139.7388520565487 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14bf3577-b148-45bd-99f6-473f086c7e5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14bf3577-b148-45bd-99f6-473f086c7e5b_0">
											<gml:posList>35.6721498226667 139.7388520565487 38.7 35.6721498226667 139.7388520565487 9.97 35.67212520456049 139.7388614861318 9.97 35.6721498226667 139.7388520565487 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19160da0-f4e6-4db6-809b-920b32048762">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19160da0-f4e6-4db6-809b-920b32048762_0">
											<gml:posList>35.672135771978546 139.73890020271267 38.7 35.672159427875116 139.7388821580002 38.7 35.67212740172353 139.73887018818476 38.7 35.672135771978546 139.73890020271267 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-030af005-822b-4d43-b0c9-895deec8c99b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-030af005-822b-4d43-b0c9-895deec8c99b_0">
											<gml:posList>35.672159427875116 139.7388821580002 38.7 35.6721498226667 139.7388520565487 38.7 35.67212740172353 139.73887018818476 38.7 35.672159427875116 139.7388821580002 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a9ba4f3-448a-44f5-9a3d-f711c228d21d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a9ba4f3-448a-44f5-9a3d-f711c228d21d_0">
											<gml:posList>35.6721498226667 139.7388520565487 38.7 35.67212520456049 139.7388614861318 38.7 35.67212740172353 139.73887018818476 38.7 35.6721498226667 139.7388520565487 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f0f3820-5c16-4383-b38d-4124f47a2e19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f0f3820-5c16-4383-b38d-4124f47a2e19_0">
											<gml:posList>35.672135771978546 139.73890020271267 38.7 35.672159427875116 139.7388821580002 9.97 35.672159427875116 139.7388821580002 38.7 35.672135771978546 139.73890020271267 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f053b74-df47-4da5-a227-9a67b36e2dd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f053b74-df47-4da5-a227-9a67b36e2dd0_0">
											<gml:posList>35.672135771978546 139.73890020271267 38.7 35.672135771978546 139.73890020271267 9.97 35.672159427875116 139.7388821580002 9.97 35.672135771978546 139.73890020271267 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a3a8819-a2cb-41f9-9975-1c63032b8d2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a3a8819-a2cb-41f9-9975-1c63032b8d2a_0">
											<gml:posList>35.672159427875116 139.7388821580002 38.7 35.6721498226667 139.7388520565487 9.97 35.6721498226667 139.7388520565487 38.7 35.672159427875116 139.7388821580002 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cee33896-1572-492b-90e0-01629db3487c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cee33896-1572-492b-90e0-01629db3487c_0">
											<gml:posList>35.672159427875116 139.7388821580002 38.7 35.672159427875116 139.7388821580002 9.97 35.6721498226667 139.7388520565487 9.97 35.672159427875116 139.7388821580002 38.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-545c5c29-4cde-4823-8987-fe152c95eb37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-545c5c29-4cde-4823-8987-fe152c95eb37_0">
											<gml:posList>35.67196459435511 139.73863887898153 27.409 35.67196259532078 139.73862997788197 27.03 35.67196459435511 139.73863887898153 27.03 35.67196459435511 139.73863887898153 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea344d64-6d05-4e5b-9f7b-f4491fceb0c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea344d64-6d05-4e5b-9f7b-f4491fceb0c3_0">
											<gml:posList>35.67196459435511 139.73863887898153 27.409 35.67196259532078 139.73862997788197 27.409 35.67196259532078 139.73862997788197 27.03 35.67196459435511 139.73863887898153 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e56646d-02e0-4115-8506-d471da1bc2a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e56646d-02e0-4115-8506-d471da1bc2a3_0">
											<gml:posList>35.67196459435511 139.73863887898153 27.409 35.671974065307445 139.73863573059515 27.409 35.67196259532078 139.73862997788197 27.409 35.67196459435511 139.73863887898153 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07023413-0538-4f1d-a45e-1a691ca14b6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07023413-0538-4f1d-a45e-1a691ca14b6d_0">
											<gml:posList>35.67196259532078 139.73862997788197 27.409 35.671974065307445 139.73863573059515 27.409 35.67198816927212 139.73862106630244 27.409 35.67196259532078 139.73862997788197 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cb42c99-1f33-4efd-95d9-0213b60b17f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cb42c99-1f33-4efd-95d9-0213b60b17f7_0">
											<gml:posList>35.67198816927212 139.73862106630244 27.409 35.67198216640015 139.73863287103455 27.409 35.671990276497816 139.73863000041626 27.409 35.67198816927212 139.73862106630244 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d37068c-dbf3-45ad-98ad-8d3c210a6b11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d37068c-dbf3-45ad-98ad-8d3c210a6b11_0">
											<gml:posList>35.67198816927212 139.73862106630244 27.409 35.671974065307445 139.73863573059515 27.409 35.67198216640015 139.73863287103455 27.409 35.67198816927212 139.73862106630244 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c3558ef-5c30-4f35-962e-4cda477d80c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c3558ef-5c30-4f35-962e-4cda477d80c1_0">
											<gml:posList>35.671974065307445 139.73863573059515 27.409 35.67198216640015 139.73863287103455 27.03 35.67198216640015 139.73863287103455 27.409 35.671974065307445 139.73863573059515 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5986f06f-783d-43f2-b613-bba3b7bfa31b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5986f06f-783d-43f2-b613-bba3b7bfa31b_0">
											<gml:posList>35.671974065307445 139.73863573059515 27.409 35.671974065307445 139.73863573059515 27.03 35.67198216640015 139.73863287103455 27.03 35.671974065307445 139.73863573059515 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6c12288-3216-4f75-a318-339e8312fc97">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67201242607834 139.73862216438798 30.662 35.67200158120334 139.73860897665267 30.662 35.67200998866625 139.7386059952151 30.662 35.67201242607834 139.73862216438798 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38588687-5624-4f0b-b597-3015dd691f1f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67200998866625 139.7386059952151 30.662 35.67201368765156 139.73862172103824 30.662 35.67201242607834 139.73862216438798 30.662 35.67200998866625 139.7386059952151 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa36319b-80d9-425e-9d24-7d799c810c05">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672005280179576 139.73862469142787 30.662 35.67200158120334 139.73860897665267 30.662 35.67201242607834 139.73862216438798 30.662 35.672005280179576 139.73862469142787 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15d4bc35-ad8f-430a-b404-4d3fe249b9ba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671990276497816 139.73863000041626 27.03 35.67198216640015 139.73863287103455 27.03 35.67198816927212 139.73862106630244 27.03 35.671990276497816 139.73863000041626 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-269b5093-2769-400c-b25e-65cc526d3379">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67196259532078 139.73862997788197 27.03 35.67198816927212 139.73862106630244 27.03 35.671974065307445 139.73863573059515 27.03 35.67196259532078 139.73862997788197 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48407c9c-b2e2-413e-aa72-58b827fa29aa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67196259532078 139.73862997788197 27.03 35.671974065307445 139.73863573059515 27.03 35.67196459435511 139.73863887898153 27.03 35.67196259532078 139.73862997788197 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d47a19e7-3e21-42d5-a2d5-0239f9732e49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67198816927212 139.73862106630244 27.03 35.67198216640015 139.73863287103455 27.03 35.671974065307445 139.73863573059515 27.03 35.67198816927212 139.73862106630244 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da7bb554-245b-4b01-8497-c0b79d06fe0e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212520456049 139.7388614861318 9.97 35.6721498226667 139.7388520565487 9.97 35.67212740172353 139.73887018818476 9.97 35.67212520456049 139.7388614861318 9.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4602a32f-e832-4823-8fb4-dda57c39cf7e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212740172353 139.73887018818476 9.97 35.672159427875116 139.7388821580002 9.97 35.672135771978546 139.73890020271267 9.97 35.67212740172353 139.73887018818476 9.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdb9093c-970b-4f95-bdac-520f0d6f1767">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67212740172353 139.73887018818476 9.97 35.6721498226667 139.7388520565487 9.97 35.672159427875116 139.7388821580002 9.97 35.67212740172353 139.73887018818476 9.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_21602244-dd7f-4a15-b834-8bd098d36709_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da610dd8-28a5-43ef-b13a-c22edc98005d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67203683169549 139.73864056109778 30.662 35.6720246124794 139.7386448836595 30.662 35.67202150137847 139.73863168678386 30.662 35.67203372960781 139.73862736420963 30.662 35.67203683169549 139.73864056109778 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2e2ae8a-3bf4-4073-8add-863085668cd3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671980030881905 139.73864526770723 36.37 35.67199852157953 139.73863830867793 36.37 35.672003992061526 139.7386601521599 36.37 35.67198550135395 139.73866710013817 36.37 35.671980030881905 139.73864526770723 36.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c3d409d-f9a5-40e5-a869-81bc300cd50b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67207018921986 139.7386835146461 40.919 35.67206771959097 139.73867221700058 40.919 35.67207746092087 139.73866902410882 40.919 35.672079930550055 139.73868032175557 40.919 35.67207018921986 139.7386835146461 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a42e667-91be-41be-acce-415e1b016614">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67208765197405 139.7387678450621 45.297 35.67210178128749 139.7387624818919 45.297 35.672107459565545 139.7387849658623 45.297 35.67209333024244 139.7387903179824 45.297 35.67208765197405 139.7387678450621 45.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef32042d-9ee5-4084-bb55-4c1878689f0d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672044894146666 139.73879500357913 40.919 35.67205442796483 139.7387915568786 40.919 35.67206257584441 139.73882532744008 40.919 35.67205305104767 139.7388287851728 40.919 35.672044894146666 139.73879500357913 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fb98655-69c8-4005-9490-2d6d6fa5a849">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6721292535196 139.7388293139519 40.919 35.67213193101276 139.7388413293885 40.919 35.67212200950798 139.73884465503184 40.919 35.672119323001425 139.73883263960727 40.919 35.6721292535196 139.7388293139519 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c43536a9-7362-4772-a430-c0ba6a01833c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67210323084511 139.7388522329675 40.919 35.67207706256956 139.73886190739458 40.919 35.672074168965864 139.73885016838256 40.919 35.672100337231804 139.73884048290552 40.919 35.67210323084511 139.7388522329675 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64a29cfe-522b-4f52-95d2-1f8277f19412">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67207194464774 139.7388757878197 40.919 35.67206700653312 139.73887758316934 40.919 35.67206943007775 139.7388876105288 40.919 35.672065203838876 139.73888913992326 40.919 35.67205211839774 139.73883487288796 40.919 35.67206127374486 139.7388315591959 40.919 35.67207194464774 139.7388757878197 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-328ab729-7954-4189-a4f5-a9e7ec8ff6df">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672124919865446 139.73886625855513 41.181 35.6721224603246 139.73886779691662 41.181 35.67212052536528 139.7388601218797 41.181 35.6721230844903 139.73885913572565 41.181 35.672124919865446 139.73886625855513 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01a3070e-b75f-4ae6-b9b0-c204652d01d8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672103954152796 139.73886653732842 40.919 35.67212052536528 139.7388601218797 40.919 35.6721224603246 139.73886779691662 40.919 35.67210680217504 139.7388776246558 40.919 35.672103954152796 139.73886653732842 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f6fddd2-fa1c-4d7d-98d3-29b1004ad5fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f6fddd2-fa1c-4d7d-98d3-29b1004ad5fb_0">
											<gml:posList>35.6721224603246 139.73886779691662 40.919 35.67212052536528 139.7388601218797 40.919 35.67212052536528 139.7388601218797 41.181 35.6721224603246 139.73886779691662 41.181 35.6721224603246 139.73886779691662 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aeef446b-32c5-45af-86d3-70ea2f2a483d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aeef446b-32c5-45af-86d3-70ea2f2a483d_0">
											<gml:posList>35.671980030881905 139.73864526770723 36.37 35.67198550135395 139.73866710013817 36.37 35.67198550135395 139.73866710013817 36.903 35.671980030881905 139.73864526770723 36.903 35.671980030881905 139.73864526770723 36.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-126cfc6d-db9d-49ef-956f-b30fece15733">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-126cfc6d-db9d-49ef-956f-b30fece15733_0">
											<gml:posList>35.671980030881905 139.73864526770723 36.37 35.671980030881905 139.73864526770723 36.903 35.67199852157953 139.73863830867793 36.903 35.67199852157953 139.73863830867793 36.37 35.671980030881905 139.73864526770723 36.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c62e4464-53af-4089-af8e-b484ba6c2e04">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c62e4464-53af-4089-af8e-b484ba6c2e04_0">
											<gml:posList>35.671980030881905 139.73864526770723 36.903 35.67198550135395 139.73866710013817 36.903 35.672003992061526 139.7386601521599 36.903 35.67199852157953 139.73863830867793 36.903 35.671980030881905 139.73864526770723 36.903</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63d4114d-3e53-4723-b6d5-54407875518f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63d4114d-3e53-4723-b6d5-54407875518f_0">
											<gml:posList>35.672003992061526 139.7386601521599 36.37 35.672003992061526 139.7386601521599 36.903 35.67198550135395 139.73866710013817 36.903 35.67198550135395 139.73866710013817 36.37 35.672003992061526 139.7386601521599 36.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7183efe9-9344-4e0c-88e2-78ec2a572131">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7183efe9-9344-4e0c-88e2-78ec2a572131_0">
											<gml:posList>35.672003992061526 139.7386601521599 36.37 35.67199852157953 139.73863830867793 36.37 35.67199852157953 139.73863830867793 36.903 35.672003992061526 139.7386601521599 36.903 35.672003992061526 139.7386601521599 36.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a51c6281-bd48-49e4-a715-9453cdeb643a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a51c6281-bd48-49e4-a715-9453cdeb643a_0">
											<gml:posList>35.6720246124794 139.7386448836595 30.662 35.6720246124794 139.7386448836595 32.73 35.67202150137847 139.73863168678386 32.73 35.67202150137847 139.73863168678386 30.662 35.6720246124794 139.7386448836595 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-207cd55b-a56d-480a-b06c-2d9382d981ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-207cd55b-a56d-480a-b06c-2d9382d981ca_0">
											<gml:posList>35.67203372960781 139.73862736420963 30.662 35.67202150137847 139.73863168678386 30.662 35.67202150137847 139.73863168678386 32.73 35.67203372960781 139.73862736420963 32.73 35.67203372960781 139.73862736420963 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0328b96d-a60b-4147-87f5-d793580e0585">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0328b96d-a60b-4147-87f5-d793580e0585_0">
											<gml:posList>35.67203683169549 139.73864056109778 32.73 35.67203372960781 139.73862736420963 32.73 35.67202150137847 139.73863168678386 32.73 35.6720246124794 139.7386448836595 32.73 35.67203683169549 139.73864056109778 32.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-405c96ad-9c23-4377-a235-79e5db5e6ff1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-405c96ad-9c23-4377-a235-79e5db5e6ff1_0">
											<gml:posList>35.6720246124794 139.7386448836595 30.662 35.67203683169549 139.73864056109778 30.662 35.67203683169549 139.73864056109778 32.73 35.6720246124794 139.7386448836595 32.73 35.6720246124794 139.7386448836595 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d65d281d-a9f5-4893-8c1c-80ea99c620c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d65d281d-a9f5-4893-8c1c-80ea99c620c2_0">
											<gml:posList>35.67203372960781 139.73862736420963 30.662 35.67203372960781 139.73862736420963 32.73 35.67203683169549 139.73864056109778 32.73 35.67203683169549 139.73864056109778 30.662 35.67203372960781 139.73862736420963 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e481027d-2c70-4c55-835b-ea8c8f8bb6c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e481027d-2c70-4c55-835b-ea8c8f8bb6c8_0">
											<gml:posList>35.67205305104767 139.7388287851728 40.919 35.67205305104767 139.7388287851728 42.593 35.672044894146666 139.73879500357913 42.593 35.672044894146666 139.73879500357913 40.919 35.67205305104767 139.7388287851728 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf47e71c-e075-413a-8396-6ddd61c6cbc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf47e71c-e075-413a-8396-6ddd61c6cbc2_0">
											<gml:posList>35.67205442796483 139.7387915568786 40.919 35.672044894146666 139.73879500357913 40.919 35.672044894146666 139.73879500357913 42.593 35.67205442796483 139.7387915568786 42.593 35.67205442796483 139.7387915568786 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fa44ebe-ce88-4815-9d2f-01231dd49a4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fa44ebe-ce88-4815-9d2f-01231dd49a4f_0">
											<gml:posList>35.672044894146666 139.73879500357913 42.593 35.67205305104767 139.7388287851728 42.593 35.67206257584441 139.73882532744008 42.593 35.67205442796483 139.7387915568786 42.593 35.672044894146666 139.73879500357913 42.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e921c193-1670-4d13-989e-8035998ed8ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e921c193-1670-4d13-989e-8035998ed8ed_0">
											<gml:posList>35.67205211839774 139.73883487288796 40.919 35.67205211839774 139.73883487288796 42.593 35.67206127374486 139.7388315591959 42.593 35.67206127374486 139.7388315591959 40.919 35.67205211839774 139.73883487288796 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89b538ef-8328-43ce-8fb6-45d59be31d94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89b538ef-8328-43ce-8fb6-45d59be31d94_0">
											<gml:posList>35.67205305104767 139.7388287851728 40.919 35.67206257584441 139.73882532744008 40.919 35.67206257584441 139.73882532744008 42.593 35.67205305104767 139.7388287851728 42.593 35.67205305104767 139.7388287851728 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19f982a1-d499-4f78-9d28-45204bc199ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19f982a1-d499-4f78-9d28-45204bc199ef_0">
											<gml:posList>35.67206257584441 139.73882532744008 40.919 35.67205442796483 139.7387915568786 40.919 35.67205442796483 139.7387915568786 42.593 35.67206257584441 139.73882532744008 42.593 35.67206257584441 139.73882532744008 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fec03e85-bcf1-4652-9dca-1512b91a56a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fec03e85-bcf1-4652-9dca-1512b91a56a4_0">
											<gml:posList>35.67205211839774 139.73883487288796 40.919 35.672065203838876 139.73888913992326 40.919 35.672065203838876 139.73888913992326 42.593 35.67205211839774 139.73883487288796 42.593 35.67205211839774 139.73883487288796 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a4b148c-aafa-4f8d-9502-9fa20b030f6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a4b148c-aafa-4f8d-9502-9fa20b030f6a_0">
											<gml:posList>35.67205211839774 139.73883487288796 42.593 35.672065203838876 139.73888913992326 42.593 35.67206943007775 139.7388876105288 42.593 35.67206700653312 139.73887758316934 42.593 35.67207194464774 139.7388757878197 42.593 35.67206127374486 139.7388315591959 42.593 35.67205211839774 139.73883487288796 42.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba685499-cbb6-47c9-b994-978f68d327a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba685499-cbb6-47c9-b994-978f68d327a2_0">
											<gml:posList>35.67207194464774 139.7388757878197 40.919 35.67206127374486 139.7388315591959 40.919 35.67206127374486 139.7388315591959 42.593 35.67207194464774 139.7388757878197 42.593 35.67207194464774 139.7388757878197 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1618f983-2f0c-4001-8ba9-3a3533e07949">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1618f983-2f0c-4001-8ba9-3a3533e07949_0">
											<gml:posList>35.67206943007775 139.7388876105288 40.919 35.67206943007775 139.7388876105288 42.593 35.672065203838876 139.73888913992326 42.593 35.672065203838876 139.73888913992326 40.919 35.67206943007775 139.7388876105288 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-278d9a5f-f2af-4d41-821b-ba2f93daee0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-278d9a5f-f2af-4d41-821b-ba2f93daee0f_0">
											<gml:posList>35.67206943007775 139.7388876105288 40.919 35.67206700653312 139.73887758316934 40.919 35.67206700653312 139.73887758316934 42.593 35.67206943007775 139.7388876105288 42.593 35.67206943007775 139.7388876105288 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29442950-d477-4e45-9414-b54f4f02b3ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29442950-d477-4e45-9414-b54f4f02b3ca_0">
											<gml:posList>35.67206771959097 139.73867221700058 40.919 35.67207018921986 139.7386835146461 40.919 35.67207018921986 139.7386835146461 42.152 35.67206771959097 139.73867221700058 42.152 35.67206771959097 139.73867221700058 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b020c4e4-ea19-4c7e-a96b-fdc62cfcd990">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b020c4e4-ea19-4c7e-a96b-fdc62cfcd990_0">
											<gml:posList>35.67206700653312 139.73887758316934 40.919 35.67207194464774 139.7388757878197 40.919 35.67207194464774 139.7388757878197 42.593 35.67206700653312 139.73887758316934 42.593 35.67206700653312 139.73887758316934 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2730f23-c456-4fe8-8c25-6a9c358c97b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2730f23-c456-4fe8-8c25-6a9c358c97b8_0">
											<gml:posList>35.67207746092087 139.73866902410882 40.919 35.67206771959097 139.73867221700058 40.919 35.67206771959097 139.73867221700058 42.152 35.67207746092087 139.73866902410882 42.152 35.67207746092087 139.73866902410882 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed2856e4-7cf7-4bde-a596-0bc82ffcf19e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed2856e4-7cf7-4bde-a596-0bc82ffcf19e_0">
											<gml:posList>35.67207746092087 139.73866902410882 42.152 35.67206771959097 139.73867221700058 42.152 35.67207018921986 139.7386835146461 42.152 35.672079930550055 139.73868032175557 42.152 35.67207746092087 139.73866902410882 42.152</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46914e11-5eba-4880-a789-d8aaf3331024">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46914e11-5eba-4880-a789-d8aaf3331024_0">
											<gml:posList>35.67207018921986 139.7386835146461 40.919 35.672079930550055 139.73868032175557 40.919 35.672079930550055 139.73868032175557 42.152 35.67207018921986 139.7386835146461 42.152 35.67207018921986 139.7386835146461 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c84195a-092c-470a-93f2-bcaa872ddd90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c84195a-092c-470a-93f2-bcaa872ddd90_0">
											<gml:posList>35.67207706256956 139.73886190739458 40.919 35.67207706256956 139.73886190739458 42.593 35.672074168965864 139.73885016838256 42.593 35.672074168965864 139.73885016838256 40.919 35.67207706256956 139.73886190739458 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7506c0a-d2bc-48fa-809e-f74a462bf226">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7506c0a-d2bc-48fa-809e-f74a462bf226_0">
											<gml:posList>35.672079930550055 139.73868032175557 40.919 35.67207746092087 139.73866902410882 40.919 35.67207746092087 139.73866902410882 42.152 35.672079930550055 139.73868032175557 42.152 35.672079930550055 139.73868032175557 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fff8726-d5bb-45f2-9bb1-6208ecf21b6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fff8726-d5bb-45f2-9bb1-6208ecf21b6b_0">
											<gml:posList>35.672100337231804 139.73884048290552 40.919 35.672074168965864 139.73885016838256 40.919 35.672074168965864 139.73885016838256 42.593 35.672100337231804 139.73884048290552 42.593 35.672100337231804 139.73884048290552 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d415917-2530-4acd-83c8-3f22d263aef4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d415917-2530-4acd-83c8-3f22d263aef4_0">
											<gml:posList>35.67210323084511 139.7388522329675 42.593 35.672100337231804 139.73884048290552 42.593 35.672074168965864 139.73885016838256 42.593 35.67207706256956 139.73886190739458 42.593 35.67210323084511 139.7388522329675 42.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02ee049a-c361-4464-a915-15fe006782d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02ee049a-c361-4464-a915-15fe006782d7_0">
											<gml:posList>35.67207706256956 139.73886190739458 40.919 35.67210323084511 139.7388522329675 40.919 35.67210323084511 139.7388522329675 42.593 35.67207706256956 139.73886190739458 42.593 35.67207706256956 139.73886190739458 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01957e05-b9ab-468f-bb09-ff841496abcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01957e05-b9ab-468f-bb09-ff841496abcc_0">
											<gml:posList>35.67208765197405 139.7387678450621 45.297 35.67209333024244 139.7387903179824 45.297 35.67209333024244 139.7387903179824 49.164 35.67208765197405 139.7387678450621 49.164 35.67208765197405 139.7387678450621 45.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f35dbf1d-52fc-4ffe-8706-72e0790ca716">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f35dbf1d-52fc-4ffe-8706-72e0790ca716_0">
											<gml:posList>35.67208765197405 139.7387678450621 49.164 35.67210178128749 139.7387624818919 49.164 35.67210178128749 139.7387624818919 45.297 35.67208765197405 139.7387678450621 45.297 35.67208765197405 139.7387678450621 49.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47a31af0-cb62-4033-a3ed-9d656111d8d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47a31af0-cb62-4033-a3ed-9d656111d8d8_0">
											<gml:posList>35.672107459565545 139.7387849658623 49.164 35.67210178128749 139.7387624818919 49.164 35.67208765197405 139.7387678450621 49.164 35.67209333024244 139.7387903179824 49.164 35.672107459565545 139.7387849658623 49.164</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7f12a52-fcab-47d8-85d8-f63f4e509517">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7f12a52-fcab-47d8-85d8-f63f4e509517_0">
											<gml:posList>35.67209333024244 139.7387903179824 45.297 35.672107459565545 139.7387849658623 45.297 35.672107459565545 139.7387849658623 49.164 35.67209333024244 139.7387903179824 49.164 35.67209333024244 139.7387903179824 45.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08acb433-94cf-462e-8968-9d212f718a31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08acb433-94cf-462e-8968-9d212f718a31_0">
											<gml:posList>35.67210323084511 139.7388522329675 40.919 35.672100337231804 139.73884048290552 40.919 35.672100337231804 139.73884048290552 42.593 35.67210323084511 139.7388522329675 42.593 35.67210323084511 139.7388522329675 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-698fb328-4a45-4744-8911-6974489ad3ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-698fb328-4a45-4744-8911-6974489ad3ec_0">
											<gml:posList>35.67210178128749 139.7387624818919 45.297 35.67210178128749 139.7387624818919 49.164 35.672107459565545 139.7387849658623 49.164 35.672107459565545 139.7387849658623 45.297 35.67210178128749 139.7387624818919 45.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f93e8b8a-94b7-402c-ae34-ea780a1734ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f93e8b8a-94b7-402c-ae34-ea780a1734ca_0">
											<gml:posList>35.672103954152796 139.73886653732842 40.919 35.67210680217504 139.7388776246558 40.919 35.67210680217504 139.7388776246558 42.15 35.672103954152796 139.73886653732842 42.15 35.672103954152796 139.73886653732842 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d17ba755-7a1c-4e9d-a52c-38dc100eeae7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d17ba755-7a1c-4e9d-a52c-38dc100eeae7_0">
											<gml:posList>35.67212052536528 139.7388601218797 41.181 35.67212052536528 139.7388601218797 40.919 35.672103954152796 139.73886653732842 40.919 35.672103954152796 139.73886653732842 42.15 35.6721230844903 139.73885913572565 42.15 35.6721230844903 139.73885913572565 41.181 35.67212052536528 139.7388601218797 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c4ab09e-0584-4524-9c5f-09588ee10a26">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c4ab09e-0584-4524-9c5f-09588ee10a26_0">
											<gml:posList>35.672124919865446 139.73886625855513 42.15 35.6721230844903 139.73885913572565 42.15 35.672103954152796 139.73886653732842 42.15 35.67210680217504 139.7388776246558 42.15 35.672124919865446 139.73886625855513 42.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0753aec-e63c-4fe0-b941-26b90a7ae139">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0753aec-e63c-4fe0-b941-26b90a7ae139_0">
											<gml:posList>35.672124919865446 139.73886625855513 42.15 35.67210680217504 139.7388776246558 42.15 35.67210680217504 139.7388776246558 40.919 35.6721224603246 139.73886779691662 40.919 35.6721224603246 139.73886779691662 41.181 35.672124919865446 139.73886625855513 41.181 35.672124919865446 139.73886625855513 42.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45bcea50-d8ea-43c4-aca8-494da151256b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45bcea50-d8ea-43c4-aca8-494da151256b_0">
											<gml:posList>35.67212200950798 139.73884465503184 42.74 35.672119323001425 139.73883263960727 42.74 35.672119323001425 139.73883263960727 40.919 35.67212200950798 139.73884465503184 40.919 35.67212200950798 139.73884465503184 42.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e9b789c-370c-4cb6-8fb5-60849edc1f33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e9b789c-370c-4cb6-8fb5-60849edc1f33_0">
											<gml:posList>35.672124919865446 139.73886625855513 41.181 35.6721230844903 139.73885913572565 41.181 35.6721230844903 139.73885913572565 42.15 35.672124919865446 139.73886625855513 42.15 35.672124919865446 139.73886625855513 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63b708ea-ad20-4b75-8d48-f1912ef82908">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63b708ea-ad20-4b75-8d48-f1912ef82908_0">
											<gml:posList>35.6721292535196 139.7388293139519 40.919 35.672119323001425 139.73883263960727 40.919 35.672119323001425 139.73883263960727 42.74 35.6721292535196 139.7388293139519 42.74 35.6721292535196 139.7388293139519 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e37b5367-f218-4a68-8190-ad58e308e844">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e37b5367-f218-4a68-8190-ad58e308e844_0">
											<gml:posList>35.6721292535196 139.7388293139519 42.74 35.672119323001425 139.73883263960727 42.74 35.67212200950798 139.73884465503184 42.74 35.67213193101276 139.7388413293885 42.74 35.6721292535196 139.7388293139519 42.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b44a88c8-0ce7-4cb4-b2ac-7c5005293417">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b44a88c8-0ce7-4cb4-b2ac-7c5005293417_0">
											<gml:posList>35.67212200950798 139.73884465503184 40.919 35.67213193101276 139.7388413293885 40.919 35.67213193101276 139.7388413293885 42.74 35.67212200950798 139.73884465503184 42.74 35.67212200950798 139.73884465503184 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdd73cac-be47-4a34-8a6e-8677f9c3e9fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdd73cac-be47-4a34-8a6e-8677f9c3e9fd_0">
											<gml:posList>35.67213193101276 139.7388413293885 40.919 35.6721292535196 139.7388293139519 40.919 35.6721292535196 139.7388293139519 42.74 35.67213193101276 139.7388413293885 42.74 35.67213193101276 139.7388413293885 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-92ee53eb-a658-4aaa-ad36-2e766893113d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92ee53eb-a658-4aaa-ad36-2e766893113d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92ee53eb-a658-4aaa-ad36-2e766893113d">
											<gml:posList>35.67208343535408 139.73864397465272 9.9 35.6721498226667 139.7388520565487 9.9 35.67212520456049 139.7388614861318 9.9 35.67212740172353 139.73887018818476 9.9 35.672135771978546 139.73890020271267 9.9 35.67205195837841 139.7389641390981 9.9 35.67203527693632 139.7389564261923 9.9 35.67197133577245 139.73868365344288 9.9 35.67198692516607 139.73867811179815 9.9 35.671985116430136 139.73867049186214 9.9 35.67194961053675 139.73868091747215 9.9 35.67192754356256 139.73858749036756 9.9 35.672062351425666 139.738539831144 9.9 35.672086589287275 139.73864286627827 9.9 35.67208343535408 139.73864397465272 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dc3f1302-1669-4e93-87d8-ebe74cc7b4c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc3f1302-1669-4e93-87d8-ebe74cc7b4c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc3f1302-1669-4e93-87d8-ebe74cc7b4c1">
											<gml:posList>35.67193150270639 139.7385901810282 27.409 35.67197709947263 139.738574043471 27.409 35.671976213163646 139.7385702776692 27.409 35.67192754356256 139.73858749036756 27.409 35.67194961053675 139.73868091747215 27.409 35.671982430958224 139.73867127933306 27.409 35.671981499444726 139.7386673368396 27.409 35.67195184225743 139.73867623113165 27.409 35.67193150270639 139.7385901810282 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0c45997-7d3e-41a9-acec-0aa8108bbfa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0c45997-7d3e-41a9-acec-0aa8108bbfa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0c45997-7d3e-41a9-acec-0aa8108bbfa4">
											<gml:posList>35.67193150270639 139.7385901810282 27.03 35.671981499444726 139.7386673368396 27.03 35.671974065307445 139.73863573059515 27.03 35.67193150270639 139.7385901810282 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-126ef808-a7c1-45ef-ba50-4f0aa8a5d12e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-126ef808-a7c1-45ef-ba50-4f0aa8a5d12e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-126ef808-a7c1-45ef-ba50-4f0aa8a5d12e">
											<gml:posList>35.67193150270639 139.7385901810282 27.03 35.67195184225743 139.73867623113165 27.03 35.671981499444726 139.7386673368396 27.03 35.67193150270639 139.7385901810282 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c903f2e-c4e0-414d-9bf2-a067df559c83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c903f2e-c4e0-414d-9bf2-a067df559c83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c903f2e-c4e0-414d-9bf2-a067df559c83">
											<gml:posList>35.67193150270639 139.7385901810282 27.03 35.671990276497816 139.73863000041626 27.081 35.67197709947263 139.738574043471 27.03 35.67193150270639 139.7385901810282 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-531d3982-4f5a-4563-a1c5-a752196c8a77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-531d3982-4f5a-4563-a1c5-a752196c8a77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-531d3982-4f5a-4563-a1c5-a752196c8a77">
											<gml:posList>35.67193150270639 139.7385901810282 27.03 35.671974065307445 139.73863573059515 27.03 35.671990276497816 139.73863000041626 27.081 35.67193150270639 139.7385901810282 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-77423173-1915-4a40-938c-8c163cbe215f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77423173-1915-4a40-938c-8c163cbe215f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77423173-1915-4a40-938c-8c163cbe215f">
											<gml:posList>35.671982430958224 139.73867127933306 36.765 35.67198385277248 139.73866828405815 36.765 35.67197659951796 139.73863745085256 36.765 35.671974065307445 139.73863573059515 36.765 35.671982430958224 139.73867127933306 36.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e8148d5-41f9-4aa1-bf49-7f86dde5b38b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e8148d5-41f9-4aa1-bf49-7f86dde5b38b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e8148d5-41f9-4aa1-bf49-7f86dde5b38b">
											<gml:posList>35.671974065307445 139.73863573059515 36.765 35.67197659951796 139.73863745085256 36.765 35.67201280660951 139.73862464939737 36.765 35.672014210299594 139.73862153263056 36.765 35.671974065307445 139.73863573059515 36.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6aec18af-4534-4ec9-a871-a908b971f096">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6aec18af-4534-4ec9-a871-a908b971f096">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6aec18af-4534-4ec9-a871-a908b971f096">
											<gml:posList>35.67201280660951 139.73862464939737 36.37 35.67197659951796 139.73863745085256 36.37 35.67198385277248 139.73866828405815 36.37 35.671986538244376 139.73866749658714 36.37 35.67198831985249 139.73867500609043 36.37 35.67199795285296 139.7386716034469 36.37 35.6720218686389 139.73866314674058 36.37 35.67201280660951 139.73862464939737 36.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b2e4a39d-9f1b-4ee0-ba19-864ee56c2e6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2e4a39d-9f1b-4ee0-ba19-864ee56c2e6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2e4a39d-9f1b-4ee0-ba19-864ee56c2e6f">
											<gml:posList>35.67201280660951 139.73862464939737 36.765 35.6720218686389 139.73866314674058 36.765 35.67202441185403 139.73866485594277 36.765 35.672014210299594 139.73862153263056 36.765 35.67201280660951 139.73862464939737 36.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f69bf4eb-2cd8-4d92-9986-91ff10f6ffc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f69bf4eb-2cd8-4d92-9986-91ff10f6ffc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f69bf4eb-2cd8-4d92-9986-91ff10f6ffc5">
											<gml:posList>35.671976213163646 139.7385702776692 30.857 35.671990276497816 139.73863000041626 30.857 35.67199365570442 139.7386288034046 30.857 35.67198056010643 139.73857323298773 30.857 35.67205994896274 139.73854516943962 30.857 35.67207471779527 139.738607962336 30.857 35.672043412805245 139.73861902371885 30.857 35.672051324847736 139.73865085035447 30.857 35.672023435115406 139.738660714664 30.857 35.67202441185403 139.73866485594277 30.857 35.67205573485847 139.7386537724662 30.857 35.67204781380304 139.73862194583918 30.857 35.67207906471968 139.73861089556723 30.857 35.672062351425666 139.738539831144 30.857 35.671976213163646 139.7385702776692 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b82b4f0-06cc-411a-b99d-a7394c9a3bd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b82b4f0-06cc-411a-b99d-a7394c9a3bd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b82b4f0-06cc-411a-b99d-a7394c9a3bd4">
											<gml:posList>35.67205994896274 139.73854516943962 30.662 35.67198056010643 139.73857323298773 30.662 35.67199365570442 139.7386288034046 30.662 35.672014210299594 139.73862153263056 30.662 35.672023435115406 139.738660714664 30.662 35.672051324847736 139.73865085035447 30.662 35.672043412805245 139.73861902371885 30.662 35.67207471779527 139.738607962336 30.662 35.67205994896274 139.73854516943962 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb548a6d-e537-4f88-8a61-e3483aa84bb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb548a6d-e537-4f88-8a61-e3483aa84bb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb548a6d-e537-4f88-8a61-e3483aa84bb5">
											<gml:posList>35.67207906471968 139.73861089556723 27.409 35.67204781380304 139.73862194583918 27.409 35.67205573485847 139.7386537724662 27.409 35.67208343535408 139.73864397465272 27.409 35.672086589287275 139.73864286627827 27.409 35.67207906471968 139.73861089556723 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1069acaf-15f2-4afc-ac17-4302b683098a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1069acaf-15f2-4afc-ac17-4302b683098a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1069acaf-15f2-4afc-ac17-4302b683098a">
											<gml:posList>35.671985116430136 139.73867049186214 36.765 35.671986538244376 139.73866749658714 36.765 35.67198385277248 139.73866828405815 36.765 35.671982430958224 139.73867127933306 36.765 35.671985116430136 139.73867049186214 36.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33d8b5cd-e1d8-4b1c-b72c-57d1e34965f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33d8b5cd-e1d8-4b1c-b72c-57d1e34965f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33d8b5cd-e1d8-4b1c-b72c-57d1e34965f2">
											<gml:posList>35.671985116430136 139.73867049186214 36.765 35.67198692516607 139.73867811179815 36.765 35.67198831985249 139.73867500609043 36.765 35.671986538244376 139.73866749658714 36.765 35.671985116430136 139.73867049186214 36.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c389d86-5b2c-4cd6-8819-05488a7315ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c389d86-5b2c-4cd6-8819-05488a7315ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c389d86-5b2c-4cd6-8819-05488a7315ef">
											<gml:posList>35.67198692516607 139.73867811179815 36.765 35.67202441185403 139.73866485594277 36.765 35.6720218686389 139.73866314674058 36.765 35.67199795285296 139.7386716034469 36.765 35.67198831985249 139.73867500609043 36.765 35.67198692516607 139.73867811179815 36.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a41395bb-a707-4066-9a90-0250a2cee7b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a41395bb-a707-4066-9a90-0250a2cee7b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a41395bb-a707-4066-9a90-0250a2cee7b1">
											<gml:posList>35.67197133577245 139.73868365344288 35.722 35.67203527693632 139.7389564261923 35.722 35.672058566280434 139.7389192162896 40.96 35.67197133577245 139.73868365344288 35.722</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3fc2a988-cee3-44cb-9cef-2721644364ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fc2a988-cee3-44cb-9cef-2721644364ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fc2a988-cee3-44cb-9cef-2721644364ac">
											<gml:posList>35.672058566280434 139.7389192162896 40.96 35.67199853162416 139.73867401089666 40.96 35.67197133577245 139.73868365344288 35.722 35.672058566280434 139.7389192162896 40.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-febbfab0-b95b-4adb-999a-9e596227c93e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-febbfab0-b95b-4adb-999a-9e596227c93e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-febbfab0-b95b-4adb-999a-9e596227c93e">
											<gml:posList>35.67199853162416 139.73867401089666 41.181 35.672058566280434 139.7389192162896 41.181 35.67206102104923 139.73891159132006 41.181 35.672003699212354 139.738677473391 41.181 35.67199853162416 139.73867401089666 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95cfa199-3583-431c-a9b8-2ab53f8699b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95cfa199-3583-431c-a9b8-2ab53f8699b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95cfa199-3583-431c-a9b8-2ab53f8699b6">
											<gml:posList>35.67199853162416 139.73867401089666 41.181 35.672003699212354 139.738677473391 41.181 35.672080952405835 139.7386501304822 41.181 35.67208343535408 139.73864397465272 41.181 35.67199853162416 139.73867401089666 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e38df353-c353-49a9-81f3-c77f6ab6d5e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e38df353-c353-49a9-81f3-c77f6ab6d5e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e38df353-c353-49a9-81f3-c77f6ab6d5e3">
											<gml:posList>35.672080952405835 139.7386501304822 40.919 35.672003699212354 139.738677473391 40.919 35.6720625716771 139.7387052520871 40.919 35.67208846039319 139.73869542328976 40.919 35.672080952405835 139.7386501304822 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26157708-9d4a-4d79-aa74-f69a5fca5d13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26157708-9d4a-4d79-aa74-f69a5fca5d13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26157708-9d4a-4d79-aa74-f69a5fca5d13">
											<gml:posList>35.672058566280434 139.7389192162896 40.96 35.67203527693632 139.7389564261923 35.722 35.67205195837841 139.7389641390981 35.722 35.672058566280434 139.7389192162896 40.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b489a6e-f926-4abe-ad1e-949803f7b3c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b489a6e-f926-4abe-ad1e-949803f7b3c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b489a6e-f926-4abe-ad1e-949803f7b3c5">
											<gml:posList>35.672003699212354 139.738677473391 40.919 35.67206102104923 139.73891159132006 40.919 35.672090239692174 139.73881475647357 40.919 35.6720625716771 139.7387052520871 40.919 35.672003699212354 139.738677473391 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3416c946-0f8d-4427-a8d6-f252dd8a8770">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3416c946-0f8d-4427-a8d6-f252dd8a8770">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3416c946-0f8d-4427-a8d6-f252dd8a8770">
											<gml:posList>35.67208622953998 139.73870121428615 45.55 35.67208846039319 139.73869542328976 45.55 35.6720625716771 139.7387052520871 45.55 35.67206737843776 139.73870836152432 45.55 35.67208622953998 139.73870121428615 45.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6c4fdf6-9d54-4c15-ab79-ed75eb237484">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6c4fdf6-9d54-4c15-ab79-ed75eb237484">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6c4fdf6-9d54-4c15-ab79-ed75eb237484">
											<gml:posList>35.672092767925555 139.738808865711 45.55 35.67206737843776 139.73870836152432 45.55 35.6720625716771 139.7387052520871 45.55 35.672090239692174 139.73881475647357 45.55 35.672092767925555 139.738808865711 45.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c7625ee5-cf5f-40c1-89b4-11f1913826fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7625ee5-cf5f-40c1-89b4-11f1913826fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7625ee5-cf5f-40c1-89b4-11f1913826fc">
											<gml:posList>35.67206102104923 139.73891159132006 41.181 35.672058566280434 139.7389192162896 41.181 35.67212740172353 139.73887018818476 41.181 35.67212246936432 139.73886783004548 41.181 35.67206102104923 139.73891159132006 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e71b7443-cb4b-4c20-b0c4-a9649bd79e23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e71b7443-cb4b-4c20-b0c4-a9649bd79e23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e71b7443-cb4b-4c20-b0c4-a9649bd79e23">
											<gml:posList>35.672092767925555 139.738808865711 45.297 35.67211866566374 139.73879903693276 45.297 35.67208622953998 139.73870121428615 45.297 35.67206737843776 139.73870836152432 45.297 35.672092767925555 139.738808865711 45.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22bf33bd-ad57-42d4-8f30-bdeb56e577c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22bf33bd-ad57-42d4-8f30-bdeb56e577c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22bf33bd-ad57-42d4-8f30-bdeb56e577c1">
											<gml:posList>35.672058566280434 139.7389192162896 40.96 35.67205195837841 139.7389641390981 35.722 35.672135771978546 139.73890020271267 35.722 35.672058566280434 139.7389192162896 40.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c99968ee-2ba9-4f54-ba53-5f5f4f773685">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c99968ee-2ba9-4f54-ba53-5f5f4f773685">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c99968ee-2ba9-4f54-ba53-5f5f4f773685">
											<gml:posList>35.672135771978546 139.73890020271267 35.722 35.67212740172353 139.73887018818476 40.96 35.672058566280434 139.7389192162896 40.96 35.672135771978546 139.73890020271267 35.722</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dacc6f55-625a-4798-8714-32d19c0e317d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dacc6f55-625a-4798-8714-32d19c0e317d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dacc6f55-625a-4798-8714-32d19c0e317d">
											<gml:posList>35.6721238058255 139.73880201342666 40.919 35.672090239692174 139.73881475647357 40.919 35.67206102104923 139.73891159132006 40.919 35.67212246936432 139.73886783004548 40.919 35.67212002805929 139.7388581451424 40.919 35.67214433978547 139.73884882638492 40.919 35.6721238058255 139.73880201342666 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4527fde1-0b5a-4d54-ae39-4cd1d715ac06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4527fde1-0b5a-4d54-ae39-4cd1d715ac06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4527fde1-0b5a-4d54-ae39-4cd1d715ac06">
											<gml:posList>35.67211866566374 139.73879903693276 45.55 35.6721238058255 139.73880201342666 45.55 35.67208846039319 139.73869542328976 45.55 35.67208622953998 139.73870121428615 45.55 35.67211866566374 139.73879903693276 45.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e54be50-f70a-481d-beab-6be377582838">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e54be50-f70a-481d-beab-6be377582838">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e54be50-f70a-481d-beab-6be377582838">
											<gml:posList>35.672090239692174 139.73881475647357 45.55 35.6721238058255 139.73880201342666 45.55 35.67211866566374 139.73879903693276 45.55 35.672092767925555 139.738808865711 45.55 35.672090239692174 139.73881475647357 45.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a13d165-3beb-4c71-83fb-e058c88cf090">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a13d165-3beb-4c71-83fb-e058c88cf090">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a13d165-3beb-4c71-83fb-e058c88cf090">
											<gml:posList>35.67214433978547 139.73884882638492 40.919 35.672080952405835 139.7386501304822 40.919 35.67208846039319 139.73869542328976 40.919 35.6721238058255 139.73880201342666 40.919 35.67214433978547 139.73884882638492 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f52b854-543e-4723-8908-491c4c22b6ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f52b854-543e-4723-8908-491c4c22b6ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f52b854-543e-4723-8908-491c4c22b6ed">
											<gml:posList>35.67208343535408 139.73864397465272 41.181 35.672080952405835 139.7386501304822 41.181 35.67214433978547 139.73884882638492 41.181 35.6721498226667 139.7388520565487 41.181 35.67208343535408 139.73864397465272 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-12f1b44f-b9c0-4c28-b83b-5f53105f9f29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12f1b44f-b9c0-4c28-b83b-5f53105f9f29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12f1b44f-b9c0-4c28-b83b-5f53105f9f29">
											<gml:posList>35.67212520456049 139.7388614861318 41.181 35.67212002805929 139.7388581451424 41.181 35.67212246936432 139.73886783004548 41.181 35.67212740172353 139.73887018818476 41.181 35.67212520456049 139.7388614861318 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-349f25b7-54ed-4d90-bf1e-eb891156b94d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-349f25b7-54ed-4d90-bf1e-eb891156b94d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-349f25b7-54ed-4d90-bf1e-eb891156b94d">
											<gml:posList>35.67212520456049 139.7388614861318 41.181 35.6721498226667 139.7388520565487 41.181 35.67214433978547 139.73884882638492 41.181 35.67212002805929 139.7388581451424 41.181 35.67212520456049 139.7388614861318 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea6df4dc-77f4-4fbd-9276-825376adb758">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea6df4dc-77f4-4fbd-9276-825376adb758">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea6df4dc-77f4-4fbd-9276-825376adb758">
											<gml:posList>35.67208622953998 139.73870121428615 45.297 35.67211866566374 139.73879903693276 45.297 35.67211866566374 139.73879903693276 45.55 35.67208622953998 139.73870121428615 45.55 35.67208622953998 139.73870121428615 45.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c562838c-e8bc-448f-b37b-d9ce15e865fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c562838c-e8bc-448f-b37b-d9ce15e865fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c562838c-e8bc-448f-b37b-d9ce15e865fc">
											<gml:posList>35.672092767925555 139.738808865711 45.297 35.67206737843776 139.73870836152432 45.297 35.67206737843776 139.73870836152432 45.55 35.672092767925555 139.738808865711 45.55 35.672092767925555 139.738808865711 45.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9dc654a-0072-4e41-b7c8-1770135f5591">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9dc654a-0072-4e41-b7c8-1770135f5591">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9dc654a-0072-4e41-b7c8-1770135f5591">
											<gml:posList>35.67192754356256 139.73858749036756 27.409 35.67192754356256 139.73858749036756 9.9 35.67194961053675 139.73868091747215 9.9 35.67194961053675 139.73868091747215 27.409 35.67192754356256 139.73858749036756 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b57a3206-2f4e-4339-8664-662d0aa066bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b57a3206-2f4e-4339-8664-662d0aa066bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b57a3206-2f4e-4339-8664-662d0aa066bc">
											<gml:posList>35.67195184225743 139.73867623113165 27.03 35.67193150270639 139.7385901810282 27.03 35.67193150270639 139.7385901810282 27.409 35.67195184225743 139.73867623113165 27.409 35.67195184225743 139.73867623113165 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b52f5fc-a437-45e9-aa24-4722fa1db9a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b52f5fc-a437-45e9-aa24-4722fa1db9a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b52f5fc-a437-45e9-aa24-4722fa1db9a9">
											<gml:posList>35.67193150270639 139.7385901810282 27.03 35.67197709947263 139.738574043471 27.03 35.67197709947263 139.738574043471 27.409 35.67193150270639 139.7385901810282 27.409 35.67193150270639 139.7385901810282 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-095f55fc-475d-4b4e-a8f5-ee49b1216346">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-095f55fc-475d-4b4e-a8f5-ee49b1216346">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-095f55fc-475d-4b4e-a8f5-ee49b1216346">
											<gml:posList>35.671981499444726 139.7386673368396 27.03 35.67195184225743 139.73867623113165 27.03 35.67195184225743 139.73867623113165 27.409 35.671981499444726 139.7386673368396 27.409 35.671981499444726 139.7386673368396 27.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d135d9c7-3527-4a77-94ec-04bba492899a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d135d9c7-3527-4a77-94ec-04bba492899a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d135d9c7-3527-4a77-94ec-04bba492899a">
											<gml:posList>35.671985116430136 139.73867049186214 9.9 35.671985116430136 139.73867049186214 36.765 35.671982430958224 139.73867127933306 36.765 35.671982430958224 139.73867127933306 27.409 35.67194961053675 139.73868091747215 27.409 35.67194961053675 139.73868091747215 9.9 35.671985116430136 139.73867049186214 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c03e66ab-5c4e-4fa2-9910-2ee5bed7f973">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c03e66ab-5c4e-4fa2-9910-2ee5bed7f973">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c03e66ab-5c4e-4fa2-9910-2ee5bed7f973">
											<gml:posList>35.671982430958224 139.73867127933306 36.765 35.671974065307445 139.73863573059515 36.765 35.671974065307445 139.73863573059515 27.03 35.671981499444726 139.7386673368396 27.03 35.671981499444726 139.7386673368396 27.409 35.671982430958224 139.73867127933306 27.409 35.671982430958224 139.73867127933306 36.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb4970b7-8239-4abb-a217-8300ab1010f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb4970b7-8239-4abb-a217-8300ab1010f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb4970b7-8239-4abb-a217-8300ab1010f1">
											<gml:posList>35.67198385277248 139.73866828405815 36.37 35.67197659951796 139.73863745085256 36.37 35.67197659951796 139.73863745085256 36.765 35.67198385277248 139.73866828405815 36.765 35.67198385277248 139.73866828405815 36.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04f468c4-f1fb-45dc-b281-7ddafe4070d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04f468c4-f1fb-45dc-b281-7ddafe4070d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04f468c4-f1fb-45dc-b281-7ddafe4070d1">
											<gml:posList>35.67197709947263 139.738574043471 27.409 35.67197709947263 139.738574043471 27.03 35.671990276497816 139.73863000041626 27.081 35.671990276497816 139.73863000041626 30.857 35.671976213163646 139.7385702776692 30.857 35.671976213163646 139.7385702776692 27.409 35.67197709947263 139.738574043471 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-124d6063-8276-4ddd-a90e-e95747610826">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-124d6063-8276-4ddd-a90e-e95747610826">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-124d6063-8276-4ddd-a90e-e95747610826">
											<gml:posList>35.67198385277248 139.73866828405815 36.765 35.671986538244376 139.73866749658714 36.765 35.671986538244376 139.73866749658714 36.37 35.67198385277248 139.73866828405815 36.37 35.67198385277248 139.73866828405815 36.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-742414f6-5f38-4298-9725-2ca86e4cfadc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-742414f6-5f38-4298-9725-2ca86e4cfadc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-742414f6-5f38-4298-9725-2ca86e4cfadc">
											<gml:posList>35.67198692516607 139.73867811179815 9.9 35.67198692516607 139.73867811179815 36.765 35.671985116430136 139.73867049186214 36.765 35.671985116430136 139.73867049186214 9.9 35.67198692516607 139.73867811179815 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77f290df-15d1-42e8-bd90-fe757424cc8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77f290df-15d1-42e8-bd90-fe757424cc8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77f290df-15d1-42e8-bd90-fe757424cc8e">
											<gml:posList>35.67199365570442 139.7386288034046 30.662 35.67198056010643 139.73857323298773 30.662 35.67198056010643 139.73857323298773 30.857 35.67199365570442 139.7386288034046 30.857 35.67199365570442 139.7386288034046 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e2ffd37-f7f5-403b-a02d-fd374f9c6113">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e2ffd37-f7f5-403b-a02d-fd374f9c6113">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e2ffd37-f7f5-403b-a02d-fd374f9c6113">
											<gml:posList>35.671986538244376 139.73866749658714 36.765 35.67198831985249 139.73867500609043 36.765 35.67198831985249 139.73867500609043 36.37 35.671986538244376 139.73866749658714 36.37 35.671986538244376 139.73866749658714 36.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7069d7c5-4f42-4653-9f3d-b3674cedcbb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7069d7c5-4f42-4653-9f3d-b3674cedcbb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7069d7c5-4f42-4653-9f3d-b3674cedcbb3">
											<gml:posList>35.67198831985249 139.73867500609043 36.765 35.67199795285296 139.7386716034469 36.765 35.67199795285296 139.7386716034469 36.37 35.67198831985249 139.73867500609043 36.37 35.67198831985249 139.73867500609043 36.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-205f95f7-787f-4d69-93c8-83edf741946d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-205f95f7-787f-4d69-93c8-83edf741946d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-205f95f7-787f-4d69-93c8-83edf741946d">
											<gml:posList>35.671990276497816 139.73863000041626 30.857 35.671990276497816 139.73863000041626 27.081 35.671974065307445 139.73863573059515 27.03 35.671974065307445 139.73863573059515 36.765 35.672014210299594 139.73862153263056 36.765 35.672014210299594 139.73862153263056 30.662 35.67199365570442 139.7386288034046 30.662 35.67199365570442 139.7386288034046 30.857 35.671990276497816 139.73863000041626 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a78f7619-ce64-4eda-9a3f-184efc384016">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a78f7619-ce64-4eda-9a3f-184efc384016">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a78f7619-ce64-4eda-9a3f-184efc384016">
											<gml:posList>35.67201280660951 139.73862464939737 36.765 35.67197659951796 139.73863745085256 36.765 35.67197659951796 139.73863745085256 36.37 35.67201280660951 139.73862464939737 36.37 35.67201280660951 139.73862464939737 36.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5720e9e7-1e5d-4283-9ac4-e81972e1dfe4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5720e9e7-1e5d-4283-9ac4-e81972e1dfe4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5720e9e7-1e5d-4283-9ac4-e81972e1dfe4">
											<gml:posList>35.672062351425666 139.738539831144 30.857 35.672062351425666 139.738539831144 9.9 35.67192754356256 139.73858749036756 9.9 35.67192754356256 139.73858749036756 27.409 35.671976213163646 139.7385702776692 27.409 35.671976213163646 139.7385702776692 30.857 35.672062351425666 139.738539831144 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-977a3096-bdb7-447c-9ef8-c4a3c75bbd40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-977a3096-bdb7-447c-9ef8-c4a3c75bbd40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-977a3096-bdb7-447c-9ef8-c4a3c75bbd40">
											<gml:posList>35.6720218686389 139.73866314674058 36.37 35.67199795285296 139.7386716034469 36.37 35.67199795285296 139.7386716034469 36.765 35.6720218686389 139.73866314674058 36.765 35.6720218686389 139.73866314674058 36.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbfb7849-99e9-4550-bfdb-4133e928701e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbfb7849-99e9-4550-bfdb-4133e928701e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbfb7849-99e9-4550-bfdb-4133e928701e">
											<gml:posList>35.6720218686389 139.73866314674058 36.765 35.67201280660951 139.73862464939737 36.765 35.67201280660951 139.73862464939737 36.37 35.6720218686389 139.73866314674058 36.37 35.6720218686389 139.73866314674058 36.765</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cd4ce1a-08a2-4392-8f8e-9d71be987304">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cd4ce1a-08a2-4392-8f8e-9d71be987304">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cd4ce1a-08a2-4392-8f8e-9d71be987304">
											<gml:posList>35.672014210299594 139.73862153263056 30.662 35.672014210299594 139.73862153263056 36.765 35.67202441185403 139.73866485594277 36.765 35.67202441185403 139.73866485594277 30.857 35.672023435115406 139.738660714664 30.857 35.672023435115406 139.738660714664 30.662 35.672014210299594 139.73862153263056 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73d4038b-8782-42fe-95ec-54a64c94a57d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73d4038b-8782-42fe-95ec-54a64c94a57d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73d4038b-8782-42fe-95ec-54a64c94a57d">
											<gml:posList>35.67198056010643 139.73857323298773 30.662 35.67205994896274 139.73854516943962 30.662 35.67205994896274 139.73854516943962 30.857 35.67198056010643 139.73857323298773 30.857 35.67198056010643 139.73857323298773 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7117f697-153b-45b2-b80c-cb33414e7331">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7117f697-153b-45b2-b80c-cb33414e7331">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7117f697-153b-45b2-b80c-cb33414e7331">
											<gml:posList>35.67208343535408 139.73864397465272 41.181 35.67208343535408 139.73864397465272 27.409 35.67205573485847 139.7386537724662 27.409 35.67205573485847 139.7386537724662 30.857 35.67202441185403 139.73866485594277 30.857 35.67202441185403 139.73866485594277 36.765 35.67198692516607 139.73867811179815 36.765 35.67198692516607 139.73867811179815 9.9 35.67197133577245 139.73868365344288 9.9 35.67197133577245 139.73868365344288 35.722 35.67199853162416 139.73867401089666 40.96 35.67199853162416 139.73867401089666 41.181 35.67208343535408 139.73864397465272 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5c28b50-e1c4-487e-b228-51819d60cbe2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5c28b50-e1c4-487e-b228-51819d60cbe2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5c28b50-e1c4-487e-b228-51819d60cbe2">
											<gml:posList>35.672051324847736 139.73865085035447 30.662 35.672023435115406 139.738660714664 30.662 35.672023435115406 139.738660714664 30.857 35.672051324847736 139.73865085035447 30.857 35.672051324847736 139.73865085035447 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a90ddd03-d4eb-47ed-b96a-b04755894a04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a90ddd03-d4eb-47ed-b96a-b04755894a04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a90ddd03-d4eb-47ed-b96a-b04755894a04">
											<gml:posList>35.672080952405835 139.7386501304822 41.181 35.672003699212354 139.738677473391 41.181 35.672003699212354 139.738677473391 40.919 35.672080952405835 139.7386501304822 40.919 35.672080952405835 139.7386501304822 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f208401-b013-493b-a7ac-7071939e5748">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f208401-b013-493b-a7ac-7071939e5748">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f208401-b013-493b-a7ac-7071939e5748">
											<gml:posList>35.672051324847736 139.73865085035447 30.857 35.672043412805245 139.73861902371885 30.857 35.672043412805245 139.73861902371885 30.662 35.672051324847736 139.73865085035447 30.662 35.672051324847736 139.73865085035447 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-252ab348-ee47-437e-ad49-c453ded83767">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-252ab348-ee47-437e-ad49-c453ded83767">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-252ab348-ee47-437e-ad49-c453ded83767">
											<gml:posList>35.67205573485847 139.7386537724662 27.409 35.67204781380304 139.73862194583918 27.409 35.67204781380304 139.73862194583918 30.857 35.67205573485847 139.7386537724662 30.857 35.67205573485847 139.7386537724662 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a142302-8943-42dd-805b-0aad4b247df7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a142302-8943-42dd-805b-0aad4b247df7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a142302-8943-42dd-805b-0aad4b247df7">
											<gml:posList>35.672043412805245 139.73861902371885 30.857 35.67207471779527 139.738607962336 30.857 35.67207471779527 139.738607962336 30.662 35.672043412805245 139.73861902371885 30.662 35.672043412805245 139.73861902371885 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22bd4a0e-3cee-4b2f-bdf4-e882ff7f9389">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22bd4a0e-3cee-4b2f-bdf4-e882ff7f9389">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22bd4a0e-3cee-4b2f-bdf4-e882ff7f9389">
											<gml:posList>35.67204781380304 139.73862194583918 27.409 35.67207906471968 139.73861089556723 27.409 35.67207906471968 139.73861089556723 30.857 35.67204781380304 139.73862194583918 30.857 35.67204781380304 139.73862194583918 27.409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8043fe9a-9e8d-4d23-baae-81afc33cb304">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8043fe9a-9e8d-4d23-baae-81afc33cb304">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8043fe9a-9e8d-4d23-baae-81afc33cb304">
											<gml:posList>35.67205994896274 139.73854516943962 30.662 35.67207471779527 139.738607962336 30.662 35.67207471779527 139.738607962336 30.857 35.67205994896274 139.73854516943962 30.857 35.67205994896274 139.73854516943962 30.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21cbe09a-1f07-4fbc-a914-8cfa2f38d466">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21cbe09a-1f07-4fbc-a914-8cfa2f38d466">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21cbe09a-1f07-4fbc-a914-8cfa2f38d466">
											<gml:posList>35.672062351425666 139.738539831144 30.857 35.67207906471968 139.73861089556723 30.857 35.67207906471968 139.73861089556723 27.409 35.672086589287275 139.73864286627827 27.409 35.672086589287275 139.73864286627827 9.9 35.672062351425666 139.738539831144 9.9 35.672062351425666 139.738539831144 30.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b880f365-2de1-4309-b8c6-fea23a78675e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b880f365-2de1-4309-b8c6-fea23a78675e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b880f365-2de1-4309-b8c6-fea23a78675e">
											<gml:posList>35.6720625716771 139.7387052520871 45.55 35.67208846039319 139.73869542328976 45.55 35.67208846039319 139.73869542328976 40.919 35.6720625716771 139.7387052520871 40.919 35.6720625716771 139.7387052520871 45.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-179e5a79-f48c-46eb-ae20-2eef1fcbc53c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-179e5a79-f48c-46eb-ae20-2eef1fcbc53c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-179e5a79-f48c-46eb-ae20-2eef1fcbc53c">
											<gml:posList>35.67206737843776 139.73870836152432 45.297 35.67208622953998 139.73870121428615 45.297 35.67208622953998 139.73870121428615 45.55 35.67206737843776 139.73870836152432 45.55 35.67206737843776 139.73870836152432 45.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4a2f136-ba7c-4a93-91e8-6b54ff734064">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4a2f136-ba7c-4a93-91e8-6b54ff734064">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4a2f136-ba7c-4a93-91e8-6b54ff734064">
											<gml:posList>35.672086589287275 139.73864286627827 9.9 35.672086589287275 139.73864286627827 27.409 35.67208343535408 139.73864397465272 27.409 35.67208343535408 139.73864397465272 9.9 35.672086589287275 139.73864286627827 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36ed6a5e-374c-4c59-94a8-bac5b9ac0d04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36ed6a5e-374c-4c59-94a8-bac5b9ac0d04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36ed6a5e-374c-4c59-94a8-bac5b9ac0d04">
											<gml:posList>35.6721498226667 139.7388520565487 41.181 35.6721498226667 139.7388520565487 9.9 35.67208343535408 139.73864397465272 9.9 35.67208343535408 139.73864397465272 27.409 35.67208343535408 139.73864397465272 41.181 35.6721498226667 139.7388520565487 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14d81a7f-4194-4bee-8280-3f22a71359db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14d81a7f-4194-4bee-8280-3f22a71359db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14d81a7f-4194-4bee-8280-3f22a71359db">
											<gml:posList>35.6721238058255 139.73880201342666 45.55 35.6721238058255 139.73880201342666 40.919 35.67208846039319 139.73869542328976 40.919 35.67208846039319 139.73869542328976 45.55 35.6721238058255 139.73880201342666 45.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fe6b0ba-9c09-4baf-8fcb-b1686759e575">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fe6b0ba-9c09-4baf-8fcb-b1686759e575">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fe6b0ba-9c09-4baf-8fcb-b1686759e575">
											<gml:posList>35.672080952405835 139.7386501304822 40.919 35.67214433978547 139.73884882638492 40.919 35.67214433978547 139.73884882638492 41.181 35.672080952405835 139.7386501304822 41.181 35.672080952405835 139.7386501304822 40.919</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36f8b94a-f703-4afc-b567-afed5231d824">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36f8b94a-f703-4afc-b567-afed5231d824">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36f8b94a-f703-4afc-b567-afed5231d824">
											<gml:posList>35.672090239692174 139.73881475647357 45.55 35.6720625716771 139.7387052520871 45.55 35.6720625716771 139.7387052520871 40.919 35.672090239692174 139.73881475647357 40.919 35.672090239692174 139.73881475647357 45.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9ccd57f-64f8-4294-b256-6b9f5d68d390">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9ccd57f-64f8-4294-b256-6b9f5d68d390">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9ccd57f-64f8-4294-b256-6b9f5d68d390">
											<gml:posList>35.672003699212354 139.738677473391 41.181 35.67206102104923 139.73891159132006 41.181 35.67206102104923 139.73891159132006 40.919 35.672003699212354 139.738677473391 40.919 35.672003699212354 139.738677473391 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e646603c-54e3-4f24-acca-f9d516dd6796">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e646603c-54e3-4f24-acca-f9d516dd6796">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e646603c-54e3-4f24-acca-f9d516dd6796">
											<gml:posList>35.672058566280434 139.7389192162896 40.96 35.672058566280434 139.7389192162896 41.181 35.67199853162416 139.73867401089666 41.181 35.67199853162416 139.73867401089666 40.96 35.672058566280434 139.7389192162896 40.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b53efee-053b-44ce-8d30-a83bfd5b606d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b53efee-053b-44ce-8d30-a83bfd5b606d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b53efee-053b-44ce-8d30-a83bfd5b606d">
											<gml:posList>35.67211866566374 139.73879903693276 45.297 35.672092767925555 139.738808865711 45.297 35.672092767925555 139.738808865711 45.55 35.67211866566374 139.73879903693276 45.55 35.67211866566374 139.73879903693276 45.297</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03c53061-cd35-445c-94b9-7debb192e382">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03c53061-cd35-445c-94b9-7debb192e382">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03c53061-cd35-445c-94b9-7debb192e382">
											<gml:posList>35.672090239692174 139.73881475647357 45.55 35.672090239692174 139.73881475647357 40.919 35.6721238058255 139.73880201342666 40.919 35.6721238058255 139.73880201342666 45.55 35.672090239692174 139.73881475647357 45.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f1cedad-0407-4988-9926-da76115cd3d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f1cedad-0407-4988-9926-da76115cd3d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f1cedad-0407-4988-9926-da76115cd3d7">
											<gml:posList>35.67203527693632 139.7389564261923 35.722 35.67197133577245 139.73868365344288 35.722 35.67197133577245 139.73868365344288 9.9 35.67203527693632 139.7389564261923 9.9 35.67203527693632 139.7389564261923 35.722</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-93a8a979-beb4-4184-88f9-0064171fbfcb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-93a8a979-beb4-4184-88f9-0064171fbfcb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-93a8a979-beb4-4184-88f9-0064171fbfcb">
											<gml:posList>35.67212002805929 139.7388581451424 41.181 35.67214433978547 139.73884882638492 41.181 35.67214433978547 139.73884882638492 40.919 35.67212002805929 139.7388581451424 40.919 35.67212002805929 139.7388581451424 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2dcbd12d-bdc3-4aa2-862f-f04018509ff0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dcbd12d-bdc3-4aa2-862f-f04018509ff0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dcbd12d-bdc3-4aa2-862f-f04018509ff0">
											<gml:posList>35.6721498226667 139.7388520565487 9.9 35.6721498226667 139.7388520565487 41.181 35.67212520456049 139.7388614861318 41.181 35.67212520456049 139.7388614861318 9.9 35.6721498226667 139.7388520565487 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55be6de4-4184-4c15-b5da-a3a32800f287">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55be6de4-4184-4c15-b5da-a3a32800f287">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55be6de4-4184-4c15-b5da-a3a32800f287">
											<gml:posList>35.67212246936432 139.73886783004548 41.181 35.67212002805929 139.7388581451424 41.181 35.67212002805929 139.7388581451424 40.919 35.67212246936432 139.73886783004548 40.919 35.67212246936432 139.73886783004548 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d076dad6-7f93-43f5-ac3a-b9eee7d367d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d076dad6-7f93-43f5-ac3a-b9eee7d367d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d076dad6-7f93-43f5-ac3a-b9eee7d367d9">
											<gml:posList>35.67212740172353 139.73887018818476 40.96 35.67212740172353 139.73887018818476 9.9 35.67212520456049 139.7388614861318 9.9 35.67212520456049 139.7388614861318 41.181 35.67212740172353 139.73887018818476 41.181 35.67212740172353 139.73887018818476 40.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb46242c-540c-47d1-ad43-95cb525f67ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb46242c-540c-47d1-ad43-95cb525f67ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb46242c-540c-47d1-ad43-95cb525f67ea">
											<gml:posList>35.67212740172353 139.73887018818476 9.9 35.67212740172353 139.73887018818476 40.96 35.672135771978546 139.73890020271267 35.722 35.672135771978546 139.73890020271267 9.9 35.67212740172353 139.73887018818476 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d31e5a41-139d-419f-bc6c-df55c7f37c8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d31e5a41-139d-419f-bc6c-df55c7f37c8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d31e5a41-139d-419f-bc6c-df55c7f37c8a">
											<gml:posList>35.67206102104923 139.73891159132006 41.181 35.67212246936432 139.73886783004548 41.181 35.67212246936432 139.73886783004548 40.919 35.67206102104923 139.73891159132006 40.919 35.67206102104923 139.73891159132006 41.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a7554232-fe59-472d-b21c-8856115c2c57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7554232-fe59-472d-b21c-8856115c2c57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7554232-fe59-472d-b21c-8856115c2c57">
											<gml:posList>35.672058566280434 139.7389192162896 40.96 35.67212740172353 139.73887018818476 40.96 35.67212740172353 139.73887018818476 41.181 35.672058566280434 139.7389192162896 41.181 35.672058566280434 139.7389192162896 40.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5969e060-5812-4331-b1b4-2c3720ee0ac2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5969e060-5812-4331-b1b4-2c3720ee0ac2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5969e060-5812-4331-b1b4-2c3720ee0ac2">
											<gml:posList>35.672135771978546 139.73890020271267 9.9 35.672135771978546 139.73890020271267 35.722 35.67205195837841 139.7389641390981 35.722 35.67205195837841 139.7389641390981 9.9 35.672135771978546 139.73890020271267 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7fdeae7-0970-490a-ac65-1070cfd8a5db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7fdeae7-0970-490a-ac65-1070cfd8a5db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7fdeae7-0970-490a-ac65-1070cfd8a5db">
											<gml:posList>35.67205195837841 139.7389641390981 9.9 35.67205195837841 139.7389641390981 35.722 35.67203527693632 139.7389564261923 35.722 35.67203527693632 139.7389564261923 9.9 35.67205195837841 139.7389641390981 9.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-275</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">354.1652</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>