<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_219075d8-1abe-450a-8c61-fb34040ca696">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">8.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67015278178034 139.7443119756954 0 35.67016931752523 139.7442450171774 0 35.67007446690928 139.7442096642097 0 35.67005784104644 139.7442766227558 0 35.67015278178034 139.7443119756954 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67015278178034 139.7443119756954 8.792 35.67005784104644 139.7442766227558 8.792 35.67007446690928 139.7442096642097 8.792 35.67016931752523 139.7442450171774 8.792 35.67015278178034 139.7443119756954 8.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67015278178034 139.7443119756954 8.792 35.67016931752523 139.7442450171774 8.792 35.67016931752523 139.7442450171774 17.51 35.67015278178034 139.7443119756954 17.51 35.67015278178034 139.7443119756954 8.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67016931752523 139.7442450171774 8.792 35.67007446690928 139.7442096642097 8.792 35.67007446690928 139.7442096642097 17.51 35.67016931752523 139.7442450171774 17.51 35.67016931752523 139.7442450171774 8.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67007446690928 139.7442096642097 8.792 35.67005784104644 139.7442766227558 8.792 35.67005784104644 139.7442766227558 17.51 35.67007446690928 139.7442096642097 17.51 35.67007446690928 139.7442096642097 8.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67005784104644 139.7442766227558 8.792 35.67015278178034 139.7443119756954 8.792 35.67015278178034 139.7443119756954 17.51 35.67005784104644 139.7442766227558 17.51 35.67005784104644 139.7442766227558 8.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67015278178034 139.7443119756954 17.51 35.67016931752523 139.7442450171774 17.51 35.67007446690928 139.7442096642097 17.51 35.67005784104644 139.7442766227558 17.51 35.67015278178034 139.7443119756954 17.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4a8bf195-f360-42bb-8abf-d07c81d69c59"/>
							<gml:surfaceMember xlink:href="#poly-df62952b-ee3e-449c-8d5f-fcd6d8a461b3"/>
							<gml:surfaceMember xlink:href="#poly-efba8207-44f3-484f-a6c8-7621fa1e3043"/>
							<gml:surfaceMember xlink:href="#poly-cbd18432-293c-4651-8e4a-e1220df41807"/>
							<gml:surfaceMember xlink:href="#poly-43abb8f5-2a89-454a-81ee-785f32ca18cd"/>
							<gml:surfaceMember xlink:href="#poly-b8f1886b-6111-4d0f-b95e-dc63cb32904d"/>
							<gml:surfaceMember xlink:href="#poly-f5efe55a-4b2b-4332-b0bc-c327f1a7109b"/>
							<gml:surfaceMember xlink:href="#poly-ebf06f3c-4c45-442a-87de-97f0488f4ece"/>
							<gml:surfaceMember xlink:href="#poly-a25de395-1002-4b9f-ab35-b5d4435dc843"/>
							<gml:surfaceMember xlink:href="#poly-4ace7559-6fce-4ca1-9ece-0ce2fb14badd"/>
							<gml:surfaceMember xlink:href="#poly-f4dbd879-6c56-48c0-9bcd-120fc7ec7ae1"/>
							<gml:surfaceMember xlink:href="#poly-dae19005-9b5b-476f-b32f-3cf8abedc9f2"/>
							<gml:surfaceMember xlink:href="#poly-a949ffef-7a69-4f83-890a-f9671e01ff64"/>
							<gml:surfaceMember xlink:href="#poly-3da2177e-e56c-42f8-bef3-315162333c17"/>
							<gml:surfaceMember xlink:href="#poly-908b7537-65b7-4d9b-9a7d-2f1fdae8bf36"/>
							<gml:surfaceMember xlink:href="#poly-0fde42a7-960d-44a5-a0d9-ca4782faddaf"/>
							<gml:surfaceMember xlink:href="#poly-d4cffbe8-af6c-4b5e-947b-2fece40bc0fa"/>
							<gml:surfaceMember xlink:href="#poly-5ba36951-8f3c-48d5-ad30-05c2e5f787b2"/>
							<gml:surfaceMember xlink:href="#poly-a9dbe23d-433c-4096-b957-698dc8ad56d6"/>
							<gml:surfaceMember xlink:href="#poly-68861e9e-f865-492e-93fc-c0a33b71c03c"/>
							<gml:surfaceMember xlink:href="#poly-a36e19aa-45e8-4445-9e84-480dd8409a8d"/>
							<gml:surfaceMember xlink:href="#poly-d74fec7f-7277-483c-8fc8-bdc0cc929be5"/>
							<gml:surfaceMember xlink:href="#poly-04643a38-8bbd-4f34-818c-45a0a6c32006"/>
							<gml:surfaceMember xlink:href="#poly-0f735cf1-67cc-4f9e-957b-77944c2d3fde"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_219075d8-1abe-450a-8c61-fb34040ca696_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b086d23-b45f-4f95-947f-7aa81b6dfb2a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013039289602 139.74430144036216 19.824 35.67011772511801 139.74429672664505 19.824 35.670121607480134 139.74428108088028 19.824 35.670134275266925 139.74428580564137 19.824 35.67013039289602 139.74430144036216 19.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b8ff562-b474-4388-9974-8e3e01491924">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011765322058 139.74429701392668 20.4 35.67011772511801 139.74429672664505 20.4 35.67013039289602 139.74430144036216 20.4 35.67013032100676 139.74430173869007 20.4 35.67011765322058 139.74429701392668 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6fb713c-898a-4976-b47a-1905d38b2948">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6fb713c-898a-4976-b47a-1905d38b2948_0">
											<gml:posList>35.67011772511801 139.74429672664505 20.4 35.67011765322058 139.74429701392668 20.4 35.67011765322058 139.74429701392668 22.075 35.670121607480134 139.74428108088028 22.075 35.670121607480134 139.74428108088028 19.824 35.67011772511801 139.74429672664505 19.824 35.67011772511801 139.74429672664505 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74dde307-72c5-456f-a422-d404616f1b28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74dde307-72c5-456f-a422-d404616f1b28_0">
											<gml:posList>35.67013032100676 139.74430173869007 20.4 35.67013032100676 139.74430173869007 22.075 35.67011765322058 139.74429701392668 22.075 35.67011765322058 139.74429701392668 20.4 35.67013032100676 139.74430173869007 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7799534-6300-4730-9c0b-9eaf792cca9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7799534-6300-4730-9c0b-9eaf792cca9f_0">
											<gml:posList>35.67011772511801 139.74429672664505 20.4 35.67011772511801 139.74429672664505 19.824 35.67013039289602 139.74430144036216 19.824 35.67013039289602 139.74430144036216 20.4 35.67011772511801 139.74429672664505 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c0d12be-faa6-444a-bbd9-611c07653450">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c0d12be-faa6-444a-bbd9-611c07653450_0">
											<gml:posList>35.670134275266925 139.74428580564137 22.075 35.670121607480134 139.74428108088028 22.075 35.67011765322058 139.74429701392668 22.075 35.67013032100676 139.74430173869007 22.075 35.670134275266925 139.74428580564137 22.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-117eed42-8750-4d24-ad11-b58a66bd1575">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-117eed42-8750-4d24-ad11-b58a66bd1575_0">
											<gml:posList>35.670121607480134 139.74428108088028 19.824 35.670121607480134 139.74428108088028 22.075 35.670134275266925 139.74428580564137 22.075 35.670134275266925 139.74428580564137 19.824 35.670121607480134 139.74428108088028 19.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c182e519-0370-4f7f-808b-b362526e98c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c182e519-0370-4f7f-808b-b362526e98c7_0">
											<gml:posList>35.670134275266925 139.74428580564137 19.824 35.670134275266925 139.74428580564137 22.075 35.67013032100676 139.74430173869007 22.075 35.67013032100676 139.74430173869007 20.4 35.67013039289602 139.74430144036216 20.4 35.67013039289602 139.74430144036216 19.824 35.670134275266925 139.74428580564137 19.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4a8bf195-f360-42bb-8abf-d07c81d69c59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a8bf195-f360-42bb-8abf-d07c81d69c59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a8bf195-f360-42bb-8abf-d07c81d69c59">
											<gml:posList>35.67015278178034 139.74431197569544 8.792 35.67005784104645 139.74427662275582 8.792 35.670074466909284 139.7442096642097 8.792 35.67016931752523 139.7442450171774 8.792 35.67015278178034 139.74431197569544 8.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-df62952b-ee3e-449c-8d5f-fcd6d8a461b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df62952b-ee3e-449c-8d5f-fcd6d8a461b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df62952b-ee3e-449c-8d5f-fcd6d8a461b3">
											<gml:posList>35.67005784104645 139.74427662275582 15.4 35.67007007605225 139.74428118229986 15.4 35.670086692903844 139.74421422375448 15.4 35.670074466909284 139.7442096642097 15.4 35.67005784104645 139.74427662275582 15.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-efba8207-44f3-484f-a6c8-7621fa1e3043">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efba8207-44f3-484f-a6c8-7621fa1e3043">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efba8207-44f3-484f-a6c8-7621fa1e3043">
											<gml:posList>35.67008730786455 139.7442169625334 18.04 35.670086692903844 139.74421422375448 18.04 35.67007007605225 139.74428118229986 18.04 35.67007172449358 139.74427973341452 18.04 35.67008730786455 139.7442169625334 18.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbd18432-293c-4651-8e4a-e1220df41807">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbd18432-293c-4651-8e4a-e1220df41807">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbd18432-293c-4651-8e4a-e1220df41807">
											<gml:posList>35.67010243524458 139.7442932309257 18.04 35.67010290256963 139.74429135254906 18.04 35.67007172449358 139.74427973341452 18.04 35.67007007605225 139.74428118229986 18.04 35.67010243524458 139.7442932309257 18.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43abb8f5-2a89-454a-81ee-785f32ca18cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43abb8f5-2a89-454a-81ee-785f32ca18cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43abb8f5-2a89-454a-81ee-785f32ca18cd">
											<gml:posList>35.67008730786455 139.7442169625334 17.447 35.67007172449358 139.74427973341452 17.447 35.67010290256963 139.74429135254906 17.447 35.670118476932814 139.74422858165576 17.447 35.67008730786455 139.7442169625334 17.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8f1886b-6111-4d0f-b95e-dc63cb32904d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8f1886b-6111-4d0f-b95e-dc63cb32904d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8f1886b-6111-4d0f-b95e-dc63cb32904d">
											<gml:posList>35.67008730786455 139.7442169625334 18.04 35.670118476932814 139.74422858165576 18.04 35.67011905211092 139.74422628340199 18.04 35.670086692903844 139.74421422375448 18.04 35.67008730786455 139.7442169625334 18.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5efe55a-4b2b-4332-b0bc-c327f1a7109b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5efe55a-4b2b-4332-b0bc-c327f1a7109b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5efe55a-4b2b-4332-b0bc-c327f1a7109b">
											<gml:posList>35.67010243524458 139.7442932309257 20.4 35.67010457045982 139.74429182568431 20.4 35.670120189777435 139.7442289000927 20.4 35.67011905211092 139.74422628340199 20.4 35.67010243524458 139.7442932309257 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ebf06f3c-4c45-442a-87de-97f0488f4ece">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebf06f3c-4c45-442a-87de-97f0488f4ece">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebf06f3c-4c45-442a-87de-97f0488f4ece">
											<gml:posList>35.67015278178034 139.74431197569544 20.4 35.67015162608002 139.74430934797624 20.4 35.67010457045982 139.74429182568431 20.4 35.67010243524458 139.7442932309257 20.4 35.67015278178034 139.74431197569544 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a25de395-1002-4b9f-ab35-b5d4435dc843">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a25de395-1002-4b9f-ab35-b5d4435dc843">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a25de395-1002-4b9f-ab35-b5d4435dc843">
											<gml:posList>35.670167173288654 139.74424641138498 19.824 35.670120189777435 139.7442289000927 19.824 35.67010457045982 139.74429182568431 19.824 35.67015162608002 139.74430934797624 19.824 35.670167173288654 139.74424641138498 19.824</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ace7559-6fce-4ca1-9ece-0ce2fb14badd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ace7559-6fce-4ca1-9ece-0ce2fb14badd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ace7559-6fce-4ca1-9ece-0ce2fb14badd">
											<gml:posList>35.67011905211092 139.74422628340199 20.4 35.670120189777435 139.7442289000927 20.4 35.670167173288654 139.74424641138498 20.4 35.67016931752523 139.7442450171774 20.4 35.67011905211092 139.74422628340199 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4dbd879-6c56-48c0-9bcd-120fc7ec7ae1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4dbd879-6c56-48c0-9bcd-120fc7ec7ae1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4dbd879-6c56-48c0-9bcd-120fc7ec7ae1">
											<gml:posList>35.67016931752523 139.7442450171774 20.4 35.670167173288654 139.74424641138498 20.4 35.67015162608002 139.74430934797624 20.4 35.67015278178034 139.74431197569544 20.4 35.67016931752523 139.7442450171774 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dae19005-9b5b-476f-b32f-3cf8abedc9f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dae19005-9b5b-476f-b32f-3cf8abedc9f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dae19005-9b5b-476f-b32f-3cf8abedc9f2">
											<gml:posList>35.67008730786455 139.7442169625334 18.04 35.67008730786455 139.7442169625334 17.447 35.670118476932814 139.74422858165576 17.447 35.670118476932814 139.74422858165576 18.04 35.67008730786455 139.7442169625334 18.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a949ffef-7a69-4f83-890a-f9671e01ff64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a949ffef-7a69-4f83-890a-f9671e01ff64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a949ffef-7a69-4f83-890a-f9671e01ff64">
											<gml:posList>35.670074466909284 139.7442096642097 8.792 35.670074466909284 139.7442096642097 15.4 35.670086692903844 139.74421422375448 15.4 35.670086692903844 139.74421422375448 18.04 35.67011905211092 139.74422628340199 18.04 35.67011905211092 139.74422628340199 20.4 35.67016931752523 139.7442450171774 20.4 35.67016931752523 139.7442450171774 8.792 35.670074466909284 139.7442096642097 8.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3da2177e-e56c-42f8-bef3-315162333c17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3da2177e-e56c-42f8-bef3-315162333c17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3da2177e-e56c-42f8-bef3-315162333c17">
											<gml:posList>35.670120189777435 139.7442289000927 20.4 35.670120189777435 139.7442289000927 19.824 35.670167173288654 139.74424641138498 19.824 35.670167173288654 139.74424641138498 20.4 35.670120189777435 139.7442289000927 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-908b7537-65b7-4d9b-9a7d-2f1fdae8bf36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-908b7537-65b7-4d9b-9a7d-2f1fdae8bf36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-908b7537-65b7-4d9b-9a7d-2f1fdae8bf36">
											<gml:posList>35.670074466909284 139.7442096642097 8.792 35.67005784104645 139.74427662275582 8.792 35.67005784104645 139.74427662275582 15.4 35.670074466909284 139.7442096642097 15.4 35.670074466909284 139.7442096642097 8.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fde42a7-960d-44a5-a0d9-ca4782faddaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fde42a7-960d-44a5-a0d9-ca4782faddaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fde42a7-960d-44a5-a0d9-ca4782faddaf">
											<gml:posList>35.67007007605225 139.74428118229986 15.4 35.67007007605225 139.74428118229986 18.04 35.670086692903844 139.74421422375448 18.04 35.670086692903844 139.74421422375448 15.4 35.67007007605225 139.74428118229986 15.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4cffbe8-af6c-4b5e-947b-2fece40bc0fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4cffbe8-af6c-4b5e-947b-2fece40bc0fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4cffbe8-af6c-4b5e-947b-2fece40bc0fa">
											<gml:posList>35.67007172449358 139.74427973341452 18.04 35.67007172449358 139.74427973341452 17.447 35.67008730786455 139.7442169625334 17.447 35.67008730786455 139.7442169625334 18.04 35.67007172449358 139.74427973341452 18.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ba36951-8f3c-48d5-ad30-05c2e5f787b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ba36951-8f3c-48d5-ad30-05c2e5f787b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ba36951-8f3c-48d5-ad30-05c2e5f787b2">
											<gml:posList>35.67010243524458 139.7442932309257 20.4 35.67011905211092 139.74422628340199 20.4 35.67011905211092 139.74422628340199 18.04 35.670118476932814 139.74422858165576 18.04 35.670118476932814 139.74422858165576 17.447 35.67010290256963 139.74429135254906 17.447 35.67010290256963 139.74429135254906 18.04 35.67010243524458 139.7442932309257 18.04 35.67010243524458 139.7442932309257 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9dbe23d-433c-4096-b957-698dc8ad56d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9dbe23d-433c-4096-b957-698dc8ad56d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9dbe23d-433c-4096-b957-698dc8ad56d6">
											<gml:posList>35.67010457045982 139.74429182568431 20.4 35.67010457045982 139.74429182568431 19.824 35.670120189777435 139.7442289000927 19.824 35.670120189777435 139.7442289000927 20.4 35.67010457045982 139.74429182568431 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68861e9e-f865-492e-93fc-c0a33b71c03c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68861e9e-f865-492e-93fc-c0a33b71c03c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68861e9e-f865-492e-93fc-c0a33b71c03c">
											<gml:posList>35.670167173288654 139.74424641138498 20.4 35.670167173288654 139.74424641138498 19.824 35.67015162608002 139.74430934797624 19.824 35.67015162608002 139.74430934797624 20.4 35.670167173288654 139.74424641138498 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a36e19aa-45e8-4445-9e84-480dd8409a8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a36e19aa-45e8-4445-9e84-480dd8409a8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a36e19aa-45e8-4445-9e84-480dd8409a8d">
											<gml:posList>35.67015278178034 139.74431197569544 8.792 35.67016931752523 139.7442450171774 8.792 35.67016931752523 139.7442450171774 20.4 35.67015278178034 139.74431197569544 20.4 35.67015278178034 139.74431197569544 8.792</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d74fec7f-7277-483c-8fc8-bdc0cc929be5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d74fec7f-7277-483c-8fc8-bdc0cc929be5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d74fec7f-7277-483c-8fc8-bdc0cc929be5">
											<gml:posList>35.67010290256963 139.74429135254906 18.04 35.67010290256963 139.74429135254906 17.447 35.67007172449358 139.74427973341452 17.447 35.67007172449358 139.74427973341452 18.04 35.67010290256963 139.74429135254906 18.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04643a38-8bbd-4f34-818c-45a0a6c32006">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04643a38-8bbd-4f34-818c-45a0a6c32006">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04643a38-8bbd-4f34-818c-45a0a6c32006">
											<gml:posList>35.67010243524458 139.7442932309257 18.04 35.67007007605225 139.74428118229986 18.04 35.67007007605225 139.74428118229986 15.4 35.67005784104645 139.74427662275582 15.4 35.67005784104645 139.74427662275582 8.792 35.67015278178034 139.74431197569544 8.792 35.67015278178034 139.74431197569544 20.4 35.67010243524458 139.7442932309257 20.4 35.67010243524458 139.7442932309257 18.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f735cf1-67cc-4f9e-957b-77944c2d3fde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f735cf1-67cc-4f9e-957b-77944c2d3fde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f735cf1-67cc-4f9e-957b-77944c2d3fde">
											<gml:posList>35.67015162608002 139.74430934797624 20.4 35.67015162608002 139.74430934797624 19.824 35.67010457045982 139.74429182568431 19.824 35.67010457045982 139.74429182568431 20.4 35.67015162608002 139.74430934797624 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8601</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">69.70395</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>