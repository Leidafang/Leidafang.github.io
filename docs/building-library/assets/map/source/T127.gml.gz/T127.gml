<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_220c39e2-9df1-415d-9972-d33905168880">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671247395616696 139.7374839876551 0 35.67123241648364 139.7374634593023 0 35.67120305734319 139.7374956393527 0 35.67122272879155 139.7375226794576 0 35.671212101741645 139.73753418038584 0 35.67123727752513 139.73756872546463 0 35.67130905456522 139.7374903208461 0 35.67128676763574 139.73746140596228 0 35.671279650314446 139.73746583302628 0 35.67127279232301 139.73745634133797 0 35.671247395616696 139.7374839876551 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671247395616696 139.7374839876551 10.9 35.67127279232301 139.73745634133797 10.9 35.671279650314446 139.73746583302628 10.9 35.67128676763574 139.73746140596228 10.9 35.67130905456522 139.7374903208461 10.9 35.67123727752513 139.73756872546463 10.9 35.671212101741645 139.73753418038584 10.9 35.67122272879155 139.7375226794576 10.9 35.67120305734319 139.7374956393527 10.9 35.67123241648364 139.7374634593023 10.9 35.671247395616696 139.7374839876551 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671247395616696 139.7374839876551 10.9 35.67123241648364 139.7374634593023 10.9 35.67123241648364 139.7374634593023 24.97 35.671247395616696 139.7374839876551 24.97 35.671247395616696 139.7374839876551 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67123241648364 139.7374634593023 10.9 35.67120305734319 139.7374956393527 10.9 35.67120305734319 139.7374956393527 24.97 35.67123241648364 139.7374634593023 24.97 35.67123241648364 139.7374634593023 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67120305734319 139.7374956393527 10.9 35.67122272879155 139.7375226794576 10.9 35.67122272879155 139.7375226794576 24.97 35.67120305734319 139.7374956393527 24.97 35.67120305734319 139.7374956393527 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67122272879155 139.7375226794576 10.9 35.671212101741645 139.73753418038584 10.9 35.671212101741645 139.73753418038584 24.97 35.67122272879155 139.7375226794576 24.97 35.67122272879155 139.7375226794576 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671212101741645 139.73753418038584 10.9 35.67123727752513 139.73756872546463 10.9 35.67123727752513 139.73756872546463 24.97 35.671212101741645 139.73753418038584 24.97 35.671212101741645 139.73753418038584 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67123727752513 139.73756872546463 10.9 35.67130905456522 139.7374903208461 10.9 35.67130905456522 139.7374903208461 24.97 35.67123727752513 139.73756872546463 24.97 35.67123727752513 139.73756872546463 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67130905456522 139.7374903208461 10.9 35.67128676763574 139.73746140596228 10.9 35.67128676763574 139.73746140596228 24.97 35.67130905456522 139.7374903208461 24.97 35.67130905456522 139.7374903208461 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128676763574 139.73746140596228 10.9 35.671279650314446 139.73746583302628 10.9 35.671279650314446 139.73746583302628 24.97 35.67128676763574 139.73746140596228 24.97 35.67128676763574 139.73746140596228 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671279650314446 139.73746583302628 10.9 35.67127279232301 139.73745634133797 10.9 35.67127279232301 139.73745634133797 24.97 35.671279650314446 139.73746583302628 24.97 35.671279650314446 139.73746583302628 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67127279232301 139.73745634133797 10.9 35.671247395616696 139.7374839876551 10.9 35.671247395616696 139.7374839876551 24.97 35.67127279232301 139.73745634133797 24.97 35.67127279232301 139.73745634133797 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671247395616696 139.7374839876551 24.97 35.67123241648364 139.7374634593023 24.97 35.67120305734319 139.7374956393527 24.97 35.67122272879155 139.7375226794576 24.97 35.671212101741645 139.73753418038584 24.97 35.67123727752513 139.73756872546463 24.97 35.67130905456522 139.7374903208461 24.97 35.67128676763574 139.73746140596228 24.97 35.671279650314446 139.73746583302628 24.97 35.67127279232301 139.73745634133797 24.97 35.671247395616696 139.7374839876551 24.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d54313aa-479f-4175-9f19-69d586db7798"/>
							<gml:surfaceMember xlink:href="#poly-26dcbe95-bd31-4c87-ba46-9b7be9accac0"/>
							<gml:surfaceMember xlink:href="#poly-3516b450-a602-404a-8089-317a586f6d3b"/>
							<gml:surfaceMember xlink:href="#poly-6c51bb14-d179-4aa5-8f86-c6b0a496bc8d"/>
							<gml:surfaceMember xlink:href="#poly-395fcd08-be60-4d89-a3a1-ff9e278be49c"/>
							<gml:surfaceMember xlink:href="#poly-b316b14a-7533-4a20-8ed5-c455db88cafd"/>
							<gml:surfaceMember xlink:href="#poly-3fe73cbc-ddd5-41a8-a3a1-bf3be123f12e"/>
							<gml:surfaceMember xlink:href="#poly-5427d3ec-68b3-466c-82b7-6bc88b5a2ad6"/>
							<gml:surfaceMember xlink:href="#poly-0bb99727-8b09-4a65-af91-8f1cf987ff12"/>
							<gml:surfaceMember xlink:href="#poly-cb783b65-ecf4-4c16-842b-664949c17038"/>
							<gml:surfaceMember xlink:href="#poly-b57ed846-4b52-4091-81e2-72faa6dd8cf3"/>
							<gml:surfaceMember xlink:href="#poly-c5f4e6a7-ab6d-4e65-ba64-58c84f6f40fd"/>
							<gml:surfaceMember xlink:href="#poly-c15361de-af00-4d73-86ad-5501b2328f3c"/>
							<gml:surfaceMember xlink:href="#poly-24621fd6-f971-4eaf-8746-6a904353f0c4"/>
							<gml:surfaceMember xlink:href="#poly-d7bfd036-4862-4466-88ea-792224907985"/>
							<gml:surfaceMember xlink:href="#poly-7cb5671b-88cd-4091-9a87-a2c6cac997d8"/>
							<gml:surfaceMember xlink:href="#poly-31e842c7-c4cd-4899-a28e-12d702218e0f"/>
							<gml:surfaceMember xlink:href="#poly-0c0634cc-1237-4daf-8392-a056743fb28d"/>
							<gml:surfaceMember xlink:href="#poly-6f811ae0-ea81-42e9-8bc1-3f533243d620"/>
							<gml:surfaceMember xlink:href="#poly-87d85c9c-99f0-4df3-8696-89983521b932"/>
							<gml:surfaceMember xlink:href="#poly-d1785ed4-4dd2-446f-a181-125f2ad60f77"/>
							<gml:surfaceMember xlink:href="#poly-150dd9fa-f71f-444b-9227-e37c007b9001"/>
							<gml:surfaceMember xlink:href="#poly-c4b7578e-cb38-4f1d-97a8-4c122db617e3"/>
							<gml:surfaceMember xlink:href="#poly-a3958b9e-bbe6-4fad-ba6b-943f37aeb67f"/>
							<gml:surfaceMember xlink:href="#poly-91d5b8c0-a85c-48e7-8d10-b74c8fa07a3f"/>
							<gml:surfaceMember xlink:href="#poly-ea140be6-60fb-4078-898e-52dc8d3a49d5"/>
							<gml:surfaceMember xlink:href="#poly-0260bccf-cae2-4964-b228-96bbf08f6e39"/>
							<gml:surfaceMember xlink:href="#poly-745bc50a-decb-495f-9143-d63fcdcbd47b"/>
							<gml:surfaceMember xlink:href="#poly-a9f4114e-9d97-4891-bbc4-d9515bb7093c"/>
							<gml:surfaceMember xlink:href="#poly-44a1b5d7-b89c-404c-9c6c-fb16f477496f"/>
							<gml:surfaceMember xlink:href="#poly-6c916d86-5ccf-4a87-a872-5675d8fd8b41"/>
							<gml:surfaceMember xlink:href="#poly-e8e0790e-bc04-487f-a84c-4fb188eb586f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_220c39e2-9df1-415d-9972-d33905168880_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60f40c6d-ee5e-46dc-9e78-62474fe4e381">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60f40c6d-ee5e-46dc-9e78-62474fe4e381_0">
											<gml:posList>35.6712472451532 139.73748746744423 25.642 35.67124874012948 139.737485830793 25.642 35.67124874012948 139.737485830793 25.32 35.6712472451532 139.73748746744423 25.32 35.6712472451532 139.73748746744423 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-137f82ad-7550-4cc1-ba7e-bf32a5c7600d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-137f82ad-7550-4cc1-ba7e-bf32a5c7600d_0">
											<gml:posList>35.67124874012948 139.737485830793 25.642 35.671232416483626 139.7374634593023 25.642 35.671232416483626 139.7374634593023 27.125 35.671250283155125 139.73748793880674 27.125 35.671250283155125 139.73748793880674 25.32 35.67124874012948 139.737485830793 25.32 35.67124874012948 139.737485830793 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bb55e6a-1416-4ed1-ae77-05d831e5a59c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bb55e6a-1416-4ed1-ae77-05d831e5a59c_0">
											<gml:posList>35.6712472451532 139.73748746744423 25.32 35.67123225700701 139.73746693910158 25.32 35.67123225700701 139.73746693910158 25.642 35.6712472451532 139.73748746744423 25.642 35.6712472451532 139.73748746744423 25.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f5aa334-8e07-4bbc-b28d-98d112e00188">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f5aa334-8e07-4bbc-b28d-98d112e00188_0">
											<gml:posList>35.67120305734318 139.7374956393527 25.642 35.67120305734318 139.7374956393527 27.125 35.671232416483626 139.7374634593023 27.125 35.671232416483626 139.7374634593023 25.642 35.67120305734318 139.7374956393527 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-066048d2-1b27-49ec-8372-51b23d6b3306">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-066048d2-1b27-49ec-8372-51b23d6b3306_0">
											<gml:posList>35.67123225700701 139.73746693910158 25.32 35.67120588780093 139.7374958237576 25.32 35.67120588780093 139.7374958237576 25.642 35.67123225700701 139.73746693910158 25.642 35.67123225700701 139.73746693910158 25.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be345a8b-430c-4d62-b83d-594ae3b611da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be345a8b-430c-4d62-b83d-594ae3b611da_0">
											<gml:posList>35.671250283155125 139.73748793880674 27.125 35.671232416483626 139.7374634593023 27.125 35.67120305734318 139.7374956393527 27.125 35.671221032348654 139.7375203396534 27.125 35.671250283155125 139.73748793880674 27.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-449b7f06-e159-4a44-953d-fc0afda02320">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-449b7f06-e159-4a44-953d-fc0afda02320_0">
											<gml:posList>35.671250283155125 139.73748793880674 25.32 35.671250283155125 139.73748793880674 27.125 35.671221032348654 139.7375203396534 27.125 35.671221032348654 139.7375203396534 25.642 35.67122251830288 139.7375186919677 25.642 35.67122251830288 139.7375186919677 25.32 35.671250283155125 139.73748793880674 25.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92ab2076-bc5a-49be-bbd3-a0bb6b5a1566">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92ab2076-bc5a-49be-bbd3-a0bb6b5a1566_0">
											<gml:posList>35.67122251830288 139.7375186919677 25.32 35.67122251830288 139.7375186919677 25.642 35.67120588780093 139.7374958237576 25.642 35.67120588780093 139.7374958237576 25.32 35.67122251830288 139.7375186919677 25.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-315edcd9-2dcc-475b-8f27-f1ba71251181">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-315edcd9-2dcc-475b-8f27-f1ba71251181_0">
											<gml:posList>35.671221032348654 139.7375203396534 25.642 35.671221032348654 139.7375203396534 27.125 35.67120305734318 139.7374956393527 27.125 35.67120305734318 139.7374956393527 25.642 35.671221032348654 139.7375203396534 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32938d02-f783-4c06-a264-f87d3c4a1a72">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6712472451532 139.73748746744423 25.642 35.67123225700701 139.73746693910158 25.642 35.67120588780093 139.7374958237576 25.642 35.67122251830288 139.7375186919677 25.642 35.671221032348654 139.7375203396534 25.642 35.67120305734318 139.7374956393527 25.642 35.671232416483626 139.7374634593023 25.642 35.67124874012948 139.737485830793 25.642 35.6712472451532 139.73748746744423 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a8bddbe-1975-4e6c-8d6a-c624bdf98737">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671250283155125 139.73748793880674 25.32 35.67122251830288 139.7375186919677 25.32 35.67120588780093 139.7374958237576 25.32 35.67123225700701 139.73746693910158 25.32 35.6712472451532 139.73748746744423 25.32 35.67124874012948 139.737485830793 25.32 35.671250283155125 139.73748793880674 25.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d54313aa-479f-4175-9f19-69d586db7798">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d54313aa-479f-4175-9f19-69d586db7798">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d54313aa-479f-4175-9f19-69d586db7798">
											<gml:posList>35.671279650314446 139.73746583302628 10.9 35.67128676763573 139.73746140596225 10.9 35.67130905456522 139.7374903208461 10.9 35.67123727752516 139.73756872546463 10.9 35.67121210174164 139.73753418038584 10.9 35.671222728791534 139.7375226794576 10.9 35.67120305734318 139.7374956393527 10.9 35.671232416483626 139.7374634593023 10.9 35.67124739561669 139.7374839876551 10.9 35.67127279232299 139.73745634133797 10.9 35.671279650314446 139.73746583302628 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26dcbe95-bd31-4c87-ba46-9b7be9accac0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26dcbe95-bd31-4c87-ba46-9b7be9accac0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26dcbe95-bd31-4c87-ba46-9b7be9accac0">
											<gml:posList>35.671279650314446 139.73746583302628 25.642 35.67127279232299 139.73745634133797 25.642 35.67127261481914 139.73745982116057 25.642 35.67127916600084 139.7374688824071 25.642 35.671279650314446 139.73746583302628 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3516b450-a602-404a-8089-317a586f6d3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3516b450-a602-404a-8089-317a586f6d3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3516b450-a602-404a-8089-317a586f6d3b">
											<gml:posList>35.671279650314446 139.73746583302628 25.642 35.67127916600084 139.7374688824071 25.642 35.67128632837325 139.73746443319675 25.642 35.67128676763573 139.73746140596225 25.642 35.671279650314446 139.73746583302628 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c51bb14-d179-4aa5-8f86-c6b0a496bc8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c51bb14-d179-4aa5-8f86-c6b0a496bc8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c51bb14-d179-4aa5-8f86-c6b0a496bc8d">
											<gml:posList>35.67124739561669 139.7374839876551 25.642 35.6712472451532 139.73748746744423 25.642 35.67127261481914 139.73745982116057 25.642 35.67127279232299 139.73745634133797 25.642 35.67124739561669 139.7374839876551 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-395fcd08-be60-4d89-a3a1-ff9e278be49c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-395fcd08-be60-4d89-a3a1-ff9e278be49c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-395fcd08-be60-4d89-a3a1-ff9e278be49c">
											<gml:posList>35.67124739561669 139.7374839876551 25.642 35.671232416483626 139.7374634593023 25.642 35.67123225700701 139.73746693910158 25.642 35.6712472451532 139.73748746744423 25.642 35.67124739561669 139.7374839876551 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b316b14a-7533-4a20-8ed5-c455db88cafd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b316b14a-7533-4a20-8ed5-c455db88cafd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b316b14a-7533-4a20-8ed5-c455db88cafd">
											<gml:posList>35.67128676763573 139.73746140596225 25.642 35.67128632837325 139.73746443319675 25.642 35.67130617006035 139.73749018069128 25.642 35.67130905456522 139.7374903208461 25.642 35.67128676763573 139.73746140596225 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3fe73cbc-ddd5-41a8-a3a1-bf3be123f12e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fe73cbc-ddd5-41a8-a3a1-bf3be123f12e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fe73cbc-ddd5-41a8-a3a1-bf3be123f12e">
											<gml:posList>35.67120305734318 139.7374956393527 25.642 35.67120588780093 139.7374958237576 25.642 35.67123225700701 139.73746693910158 25.642 35.671232416483626 139.7374634593023 25.642 35.67120305734318 139.7374956393527 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5427d3ec-68b3-466c-82b7-6bc88b5a2ad6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5427d3ec-68b3-466c-82b7-6bc88b5a2ad6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5427d3ec-68b3-466c-82b7-6bc88b5a2ad6">
											<gml:posList>35.671222728791534 139.7375226794576 25.642 35.67122557729426 139.73752288593474 25.642 35.67120588780093 139.7374958237576 25.642 35.67120305734318 139.7374956393527 25.642 35.671222728791534 139.7375226794576 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0bb99727-8b09-4a65-af91-8f1cf987ff12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bb99727-8b09-4a65-af91-8f1cf987ff12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bb99727-8b09-4a65-af91-8f1cf987ff12">
											<gml:posList>35.67123225700701 139.73746693910158 25.32 35.67120588780093 139.7374958237576 25.32 35.67122557729426 139.73752288593474 25.32 35.67121494122185 139.73753437582775 25.32 35.67123743700472 139.73756524566534 25.32 35.67130617006035 139.73749018069128 25.32 35.67128632837325 139.73746443319675 25.32 35.67127916600084 139.7374688824071 25.32 35.67127261481914 139.73745982116057 25.32 35.6712472451532 139.73748746744423 25.32 35.67123225700701 139.73746693910158 25.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb783b65-ecf4-4c16-842b-664949c17038">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb783b65-ecf4-4c16-842b-664949c17038">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb783b65-ecf4-4c16-842b-664949c17038">
											<gml:posList>35.671222728791534 139.7375226794576 25.642 35.67121210174164 139.73753418038584 25.642 35.67121494122185 139.73753437582775 25.642 35.67122557729426 139.73752288593474 25.642 35.671222728791534 139.7375226794576 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b57ed846-4b52-4091-81e2-72faa6dd8cf3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b57ed846-4b52-4091-81e2-72faa6dd8cf3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b57ed846-4b52-4091-81e2-72faa6dd8cf3">
											<gml:posList>35.67130905456522 139.7374903208461 25.642 35.67130617006035 139.73749018069128 25.642 35.67123743700472 139.73756524566534 25.642 35.67123727752516 139.73756872546463 25.642 35.67130905456522 139.7374903208461 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5f4e6a7-ab6d-4e65-ba64-58c84f6f40fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5f4e6a7-ab6d-4e65-ba64-58c84f6f40fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5f4e6a7-ab6d-4e65-ba64-58c84f6f40fd">
											<gml:posList>35.67123727752516 139.73756872546463 25.642 35.67123743700472 139.73756524566534 25.642 35.67121494122185 139.73753437582775 25.642 35.67121210174164 139.73753418038584 25.642 35.67123727752516 139.73756872546463 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c15361de-af00-4d73-86ad-5501b2328f3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c15361de-af00-4d73-86ad-5501b2328f3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c15361de-af00-4d73-86ad-5501b2328f3c">
											<gml:posList>35.6712472451532 139.73748746744423 25.642 35.6712472451532 139.73748746744423 25.32 35.67127261481914 139.73745982116057 25.32 35.67127261481914 139.73745982116057 25.642 35.6712472451532 139.73748746744423 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24621fd6-f971-4eaf-8746-6a904353f0c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24621fd6-f971-4eaf-8746-6a904353f0c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24621fd6-f971-4eaf-8746-6a904353f0c4">
											<gml:posList>35.671222728791534 139.7375226794576 25.642 35.67120305734318 139.7374956393527 25.642 35.67120305734318 139.7374956393527 10.9 35.671222728791534 139.7375226794576 10.9 35.671222728791534 139.7375226794576 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7bfd036-4862-4466-88ea-792224907985">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7bfd036-4862-4466-88ea-792224907985">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7bfd036-4862-4466-88ea-792224907985">
											<gml:posList>35.67122557729426 139.73752288593474 25.642 35.67122557729426 139.73752288593474 25.32 35.67120588780093 139.7374958237576 25.32 35.67120588780093 139.7374958237576 25.642 35.67122557729426 139.73752288593474 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cb5671b-88cd-4091-9a87-a2c6cac997d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cb5671b-88cd-4091-9a87-a2c6cac997d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cb5671b-88cd-4091-9a87-a2c6cac997d8">
											<gml:posList>35.671222728791534 139.7375226794576 10.9 35.67121210174164 139.73753418038584 10.9 35.67121210174164 139.73753418038584 25.642 35.671222728791534 139.7375226794576 25.642 35.671222728791534 139.7375226794576 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31e842c7-c4cd-4899-a28e-12d702218e0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31e842c7-c4cd-4899-a28e-12d702218e0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31e842c7-c4cd-4899-a28e-12d702218e0f">
											<gml:posList>35.671232416483626 139.7374634593023 10.9 35.67120305734318 139.7374956393527 10.9 35.67120305734318 139.7374956393527 25.642 35.671232416483626 139.7374634593023 25.642 35.671232416483626 139.7374634593023 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c0634cc-1237-4daf-8392-a056743fb28d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c0634cc-1237-4daf-8392-a056743fb28d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c0634cc-1237-4daf-8392-a056743fb28d">
											<gml:posList>35.67120588780093 139.7374958237576 25.642 35.67120588780093 139.7374958237576 25.32 35.67123225700701 139.73746693910158 25.32 35.67123225700701 139.73746693910158 25.642 35.67120588780093 139.7374958237576 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f811ae0-ea81-42e9-8bc1-3f533243d620">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f811ae0-ea81-42e9-8bc1-3f533243d620">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f811ae0-ea81-42e9-8bc1-3f533243d620">
											<gml:posList>35.67121494122185 139.73753437582775 25.642 35.67121494122185 139.73753437582775 25.32 35.67122557729426 139.73752288593474 25.32 35.67122557729426 139.73752288593474 25.642 35.67121494122185 139.73753437582775 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87d85c9c-99f0-4df3-8696-89983521b932">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87d85c9c-99f0-4df3-8696-89983521b932">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87d85c9c-99f0-4df3-8696-89983521b932">
											<gml:posList>35.67121210174164 139.73753418038584 10.9 35.67123727752516 139.73756872546463 10.9 35.67123727752516 139.73756872546463 25.642 35.67121210174164 139.73753418038584 25.642 35.67121210174164 139.73753418038584 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1785ed4-4dd2-446f-a181-125f2ad60f77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1785ed4-4dd2-446f-a181-125f2ad60f77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1785ed4-4dd2-446f-a181-125f2ad60f77">
											<gml:posList>35.67123743700472 139.73756524566534 25.642 35.67123743700472 139.73756524566534 25.32 35.67121494122185 139.73753437582775 25.32 35.67121494122185 139.73753437582775 25.642 35.67123743700472 139.73756524566534 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-150dd9fa-f71f-444b-9227-e37c007b9001">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-150dd9fa-f71f-444b-9227-e37c007b9001">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-150dd9fa-f71f-444b-9227-e37c007b9001">
											<gml:posList>35.67123225700701 139.73746693910158 25.642 35.67123225700701 139.73746693910158 25.32 35.6712472451532 139.73748746744423 25.32 35.6712472451532 139.73748746744423 25.642 35.67123225700701 139.73746693910158 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4b7578e-cb38-4f1d-97a8-4c122db617e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4b7578e-cb38-4f1d-97a8-4c122db617e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4b7578e-cb38-4f1d-97a8-4c122db617e3">
											<gml:posList>35.67124739561669 139.7374839876551 10.9 35.671232416483626 139.7374634593023 10.9 35.671232416483626 139.7374634593023 25.642 35.67124739561669 139.7374839876551 25.642 35.67124739561669 139.7374839876551 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3958b9e-bbe6-4fad-ba6b-943f37aeb67f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3958b9e-bbe6-4fad-ba6b-943f37aeb67f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3958b9e-bbe6-4fad-ba6b-943f37aeb67f">
											<gml:posList>35.67127279232299 139.73745634133797 10.9 35.67124739561669 139.7374839876551 10.9 35.67124739561669 139.7374839876551 25.642 35.67127279232299 139.73745634133797 25.642 35.67127279232299 139.73745634133797 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91d5b8c0-a85c-48e7-8d10-b74c8fa07a3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91d5b8c0-a85c-48e7-8d10-b74c8fa07a3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91d5b8c0-a85c-48e7-8d10-b74c8fa07a3f">
											<gml:posList>35.67130617006035 139.73749018069128 25.642 35.67130617006035 139.73749018069128 25.32 35.67123743700472 139.73756524566534 25.32 35.67123743700472 139.73756524566534 25.642 35.67130617006035 139.73749018069128 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea140be6-60fb-4078-898e-52dc8d3a49d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea140be6-60fb-4078-898e-52dc8d3a49d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea140be6-60fb-4078-898e-52dc8d3a49d5">
											<gml:posList>35.67123727752516 139.73756872546463 10.9 35.67130905456522 139.7374903208461 10.9 35.67130905456522 139.7374903208461 25.642 35.67123727752516 139.73756872546463 25.642 35.67123727752516 139.73756872546463 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0260bccf-cae2-4964-b228-96bbf08f6e39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0260bccf-cae2-4964-b228-96bbf08f6e39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0260bccf-cae2-4964-b228-96bbf08f6e39">
											<gml:posList>35.67127261481914 139.73745982116057 25.642 35.67127261481914 139.73745982116057 25.32 35.67127916600084 139.7374688824071 25.32 35.67127916600084 139.7374688824071 25.642 35.67127261481914 139.73745982116057 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-745bc50a-decb-495f-9143-d63fcdcbd47b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-745bc50a-decb-495f-9143-d63fcdcbd47b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-745bc50a-decb-495f-9143-d63fcdcbd47b">
											<gml:posList>35.671279650314446 139.73746583302628 10.9 35.67127279232299 139.73745634133797 10.9 35.67127279232299 139.73745634133797 25.642 35.671279650314446 139.73746583302628 25.642 35.671279650314446 139.73746583302628 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9f4114e-9d97-4891-bbc4-d9515bb7093c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9f4114e-9d97-4891-bbc4-d9515bb7093c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9f4114e-9d97-4891-bbc4-d9515bb7093c">
											<gml:posList>35.67127916600084 139.7374688824071 25.642 35.67127916600084 139.7374688824071 25.32 35.67128632837325 139.73746443319675 25.32 35.67128632837325 139.73746443319675 25.642 35.67127916600084 139.7374688824071 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44a1b5d7-b89c-404c-9c6c-fb16f477496f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44a1b5d7-b89c-404c-9c6c-fb16f477496f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44a1b5d7-b89c-404c-9c6c-fb16f477496f">
											<gml:posList>35.67128676763573 139.73746140596225 10.9 35.671279650314446 139.73746583302628 10.9 35.671279650314446 139.73746583302628 25.642 35.67128676763573 139.73746140596225 25.642 35.67128676763573 139.73746140596225 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c916d86-5ccf-4a87-a872-5675d8fd8b41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c916d86-5ccf-4a87-a872-5675d8fd8b41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c916d86-5ccf-4a87-a872-5675d8fd8b41">
											<gml:posList>35.67128632837325 139.73746443319675 25.642 35.67128632837325 139.73746443319675 25.32 35.67130617006035 139.73749018069128 25.32 35.67130617006035 139.73749018069128 25.642 35.67128632837325 139.73746443319675 25.642</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8e0790e-bc04-487f-a84c-4fb188eb586f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8e0790e-bc04-487f-a84c-4fb188eb586f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8e0790e-bc04-487f-a84c-4fb188eb586f">
											<gml:posList>35.67130905456522 139.7374903208461 10.9 35.67128676763573 139.73746140596225 10.9 35.67128676763573 139.73746140596225 25.642 35.67130905456522 139.7374903208461 25.642 35.67130905456522 139.7374903208461 10.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1044</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">61.3441</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>