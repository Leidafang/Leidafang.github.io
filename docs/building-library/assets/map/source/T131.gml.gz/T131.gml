<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_22cf6d96-a6ea-49fc-bfea-45d8f0563a73">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>下水工事仮設建物</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">15</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67459155592416 139.74736315516503 0 35.67459848078916 139.7473411645244 0 35.67458319243395 139.74726396351787 0 35.67453988337822 139.74720358383874 0 35.67446131554862 139.7471221427026 0 35.6744147662314 139.74706839476852 0 35.67439103046623 139.74702699476248 0 35.67434939563857 139.74703897013802 0 35.67424160124561 139.74730454058812 0 35.67419248736398 139.74744610261465 0 35.67420117440725 139.74749359449007 0 35.67452686486987 139.74740166751405 0 35.67452306475799 139.7473815663552 0 35.67459155592416 139.74736315516503 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67459155592416 139.74736315516503 18.766 35.67452306475799 139.7473815663552 18.766 35.67452686486987 139.74740166751405 18.766 35.67420117440725 139.74749359449007 18.766 35.67419248736398 139.74744610261465 18.766 35.67424160124561 139.74730454058812 18.766 35.67434939563857 139.74703897013802 18.766 35.67439103046623 139.74702699476248 18.766 35.6744147662314 139.74706839476852 18.766 35.67446131554862 139.7471221427026 18.766 35.67453988337822 139.74720358383874 18.766 35.67458319243395 139.74726396351787 18.766 35.67459848078916 139.7473411645244 18.766 35.67459155592416 139.74736315516503 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67459155592416 139.74736315516503 18.766 35.67459848078916 139.7473411645244 18.766 35.67459848078916 139.7473411645244 33.8 35.67459155592416 139.74736315516503 33.8 35.67459155592416 139.74736315516503 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67459848078916 139.7473411645244 18.766 35.67458319243395 139.74726396351787 18.766 35.67458319243395 139.74726396351787 33.8 35.67459848078916 139.7473411645244 33.8 35.67459848078916 139.7473411645244 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67458319243395 139.74726396351787 18.766 35.67453988337822 139.74720358383874 18.766 35.67453988337822 139.74720358383874 33.8 35.67458319243395 139.74726396351787 33.8 35.67458319243395 139.74726396351787 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67453988337822 139.74720358383874 18.766 35.67446131554862 139.7471221427026 18.766 35.67446131554862 139.7471221427026 33.8 35.67453988337822 139.74720358383874 33.8 35.67453988337822 139.74720358383874 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67446131554862 139.7471221427026 18.766 35.6744147662314 139.74706839476852 18.766 35.6744147662314 139.74706839476852 33.8 35.67446131554862 139.7471221427026 33.8 35.67446131554862 139.7471221427026 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6744147662314 139.74706839476852 18.766 35.67439103046623 139.74702699476248 18.766 35.67439103046623 139.74702699476248 33.8 35.6744147662314 139.74706839476852 33.8 35.6744147662314 139.74706839476852 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67439103046623 139.74702699476248 18.766 35.67434939563857 139.74703897013802 18.766 35.67434939563857 139.74703897013802 33.8 35.67439103046623 139.74702699476248 33.8 35.67439103046623 139.74702699476248 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67434939563857 139.74703897013802 18.766 35.67424160124561 139.74730454058812 18.766 35.67424160124561 139.74730454058812 33.8 35.67434939563857 139.74703897013802 33.8 35.67434939563857 139.74703897013802 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67424160124561 139.74730454058812 18.766 35.67419248736398 139.74744610261465 18.766 35.67419248736398 139.74744610261465 33.8 35.67424160124561 139.74730454058812 33.8 35.67424160124561 139.74730454058812 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67419248736398 139.74744610261465 18.766 35.67420117440725 139.74749359449007 18.766 35.67420117440725 139.74749359449007 33.8 35.67419248736398 139.74744610261465 33.8 35.67419248736398 139.74744610261465 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67420117440725 139.74749359449007 18.766 35.67452686486987 139.74740166751405 18.766 35.67452686486987 139.74740166751405 33.8 35.67420117440725 139.74749359449007 33.8 35.67420117440725 139.74749359449007 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67452686486987 139.74740166751405 18.766 35.67452306475799 139.7473815663552 18.766 35.67452306475799 139.7473815663552 33.8 35.67452686486987 139.74740166751405 33.8 35.67452686486987 139.74740166751405 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67452306475799 139.7473815663552 18.766 35.67459155592416 139.74736315516503 18.766 35.67459155592416 139.74736315516503 33.8 35.67452306475799 139.7473815663552 33.8 35.67452306475799 139.7473815663552 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67459155592416 139.74736315516503 33.8 35.67459848078916 139.7473411645244 33.8 35.67458319243395 139.74726396351787 33.8 35.67453988337822 139.74720358383874 33.8 35.67446131554862 139.7471221427026 33.8 35.6744147662314 139.74706839476852 33.8 35.67439103046623 139.74702699476248 33.8 35.67434939563857 139.74703897013802 33.8 35.67424160124561 139.74730454058812 33.8 35.67419248736398 139.74744610261465 33.8 35.67420117440725 139.74749359449007 33.8 35.67452686486987 139.74740166751405 33.8 35.67452306475799 139.7473815663552 33.8 35.67459155592416 139.74736315516503 33.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-28b89d62-6931-4535-96dc-3520b2213e03"/>
							<gml:surfaceMember xlink:href="#poly-951e7a27-07fa-49ad-8ce2-9eaa3aee7a1f"/>
							<gml:surfaceMember xlink:href="#poly-062e1f16-25e3-493e-8551-9dbce6925606"/>
							<gml:surfaceMember xlink:href="#poly-03417115-4bc0-435f-ac0e-9699c5d4cb94"/>
							<gml:surfaceMember xlink:href="#poly-9271c65b-c559-4695-b789-3ce821d3622b"/>
							<gml:surfaceMember xlink:href="#poly-0fee7751-aa57-431a-bb48-254efe4ebe73"/>
							<gml:surfaceMember xlink:href="#poly-927a7782-e7dc-4549-ae08-b7133752f375"/>
							<gml:surfaceMember xlink:href="#poly-98ed5d92-9ced-4f34-b3fa-e5c62ebe38c8"/>
							<gml:surfaceMember xlink:href="#poly-a30ef4bf-2ee0-410f-bef4-3328137ab7cc"/>
							<gml:surfaceMember xlink:href="#poly-66b1d30a-aaca-4ff4-a87c-60df4c1815cb"/>
							<gml:surfaceMember xlink:href="#poly-e96ca0b8-c00c-43b4-a95b-b1d1aa1f9248"/>
							<gml:surfaceMember xlink:href="#poly-ee6a20f2-7244-47b3-ac60-80acb9208910"/>
							<gml:surfaceMember xlink:href="#poly-c2dd01c6-b999-4c82-9c87-7fdecf91d1f8"/>
							<gml:surfaceMember xlink:href="#poly-c61b3418-24b1-440b-a1e3-f262aa409b2c"/>
							<gml:surfaceMember xlink:href="#poly-6a2c826a-e739-4bd5-ab63-4f3fcec43493"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-28b89d62-6931-4535-96dc-3520b2213e03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28b89d62-6931-4535-96dc-3520b2213e03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28b89d62-6931-4535-96dc-3520b2213e03">
											<gml:posList>35.67452686486986 139.74740166751405 18.766 35.67420117440726 139.74749359449004 18.766 35.67419248736397 139.74744610261462 18.766 35.67424160124561 139.7473045405881 18.766 35.67434939563857 139.74703897013802 18.766 35.67439103046622 139.74702699476248 18.766 35.674414766231386 139.74706839476852 18.766 35.67446131554863 139.74712214270264 18.766 35.67453988337823 139.74720358383874 18.766 35.67458319243395 139.74726396351784 18.766 35.67459848078914 139.7473411645244 18.766 35.674591555924124 139.747363155165 18.766 35.67452306475797 139.7473815663552 18.766 35.67452686486986 139.74740166751405 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-951e7a27-07fa-49ad-8ce2-9eaa3aee7a1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-951e7a27-07fa-49ad-8ce2-9eaa3aee7a1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-951e7a27-07fa-49ad-8ce2-9eaa3aee7a1f">
											<gml:posList>35.67419248736397 139.74744610261462 33.1 35.67420117440726 139.74749359449004 33.1 35.67452686486986 139.74740166751405 33.1 35.67452306475797 139.7473815663552 33.1 35.674591555924124 139.747363155165 33.1 35.67459848078914 139.7473411645244 33.1 35.67458319243395 139.74726396351784 33.1 35.67453988337823 139.74720358383874 33.1 35.67446131554863 139.74712214270264 33.1 35.674414766231386 139.74706839476852 33.1 35.67439103046622 139.74702699476248 33.1 35.67434939563857 139.74703897013802 33.1 35.67424160124561 139.7473045405881 33.1 35.67419248736397 139.74744610261462 33.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-062e1f16-25e3-493e-8551-9dbce6925606">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-062e1f16-25e3-493e-8551-9dbce6925606">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-062e1f16-25e3-493e-8551-9dbce6925606">
											<gml:posList>35.67439103046622 139.74702699476248 18.766 35.67434939563857 139.74703897013802 18.766 35.67434939563857 139.74703897013802 33.1 35.67439103046622 139.74702699476248 33.1 35.67439103046622 139.74702699476248 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03417115-4bc0-435f-ac0e-9699c5d4cb94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03417115-4bc0-435f-ac0e-9699c5d4cb94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03417115-4bc0-435f-ac0e-9699c5d4cb94">
											<gml:posList>35.674414766231386 139.74706839476852 18.766 35.67439103046622 139.74702699476248 18.766 35.67439103046622 139.74702699476248 33.1 35.674414766231386 139.74706839476852 33.1 35.674414766231386 139.74706839476852 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9271c65b-c559-4695-b789-3ce821d3622b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9271c65b-c559-4695-b789-3ce821d3622b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9271c65b-c559-4695-b789-3ce821d3622b">
											<gml:posList>35.67446131554863 139.74712214270264 18.766 35.674414766231386 139.74706839476852 18.766 35.674414766231386 139.74706839476852 33.1 35.67446131554863 139.74712214270264 33.1 35.67446131554863 139.74712214270264 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fee7751-aa57-431a-bb48-254efe4ebe73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fee7751-aa57-431a-bb48-254efe4ebe73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fee7751-aa57-431a-bb48-254efe4ebe73">
											<gml:posList>35.67453988337823 139.74720358383874 18.766 35.67446131554863 139.74712214270264 18.766 35.67446131554863 139.74712214270264 33.1 35.67453988337823 139.74720358383874 33.1 35.67453988337823 139.74720358383874 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-927a7782-e7dc-4549-ae08-b7133752f375">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-927a7782-e7dc-4549-ae08-b7133752f375">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-927a7782-e7dc-4549-ae08-b7133752f375">
											<gml:posList>35.67434939563857 139.74703897013802 18.766 35.67424160124561 139.7473045405881 18.766 35.67424160124561 139.7473045405881 33.1 35.67434939563857 139.74703897013802 33.1 35.67434939563857 139.74703897013802 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98ed5d92-9ced-4f34-b3fa-e5c62ebe38c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98ed5d92-9ced-4f34-b3fa-e5c62ebe38c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98ed5d92-9ced-4f34-b3fa-e5c62ebe38c8">
											<gml:posList>35.67458319243395 139.74726396351784 18.766 35.67453988337823 139.74720358383874 18.766 35.67453988337823 139.74720358383874 33.1 35.67458319243395 139.74726396351784 33.1 35.67458319243395 139.74726396351784 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a30ef4bf-2ee0-410f-bef4-3328137ab7cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a30ef4bf-2ee0-410f-bef4-3328137ab7cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a30ef4bf-2ee0-410f-bef4-3328137ab7cc">
											<gml:posList>35.67459848078914 139.7473411645244 18.766 35.67458319243395 139.74726396351784 18.766 35.67458319243395 139.74726396351784 33.1 35.67459848078914 139.7473411645244 33.1 35.67459848078914 139.7473411645244 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66b1d30a-aaca-4ff4-a87c-60df4c1815cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66b1d30a-aaca-4ff4-a87c-60df4c1815cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66b1d30a-aaca-4ff4-a87c-60df4c1815cb">
											<gml:posList>35.674591555924124 139.747363155165 18.766 35.67459848078914 139.7473411645244 18.766 35.67459848078914 139.7473411645244 33.1 35.674591555924124 139.747363155165 33.1 35.674591555924124 139.747363155165 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e96ca0b8-c00c-43b4-a95b-b1d1aa1f9248">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e96ca0b8-c00c-43b4-a95b-b1d1aa1f9248">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e96ca0b8-c00c-43b4-a95b-b1d1aa1f9248">
											<gml:posList>35.67452306475797 139.7473815663552 18.766 35.674591555924124 139.747363155165 18.766 35.674591555924124 139.747363155165 33.1 35.67452306475797 139.7473815663552 33.1 35.67452306475797 139.7473815663552 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee6a20f2-7244-47b3-ac60-80acb9208910">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee6a20f2-7244-47b3-ac60-80acb9208910">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee6a20f2-7244-47b3-ac60-80acb9208910">
											<gml:posList>35.67424160124561 139.7473045405881 18.766 35.67419248736397 139.74744610261462 18.766 35.67419248736397 139.74744610261462 33.1 35.67424160124561 139.7473045405881 33.1 35.67424160124561 139.7473045405881 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2dd01c6-b999-4c82-9c87-7fdecf91d1f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2dd01c6-b999-4c82-9c87-7fdecf91d1f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2dd01c6-b999-4c82-9c87-7fdecf91d1f8">
											<gml:posList>35.67452686486986 139.74740166751405 18.766 35.67452306475797 139.7473815663552 18.766 35.67452306475797 139.7473815663552 33.1 35.67452686486986 139.74740166751405 33.1 35.67452686486986 139.74740166751405 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c61b3418-24b1-440b-a1e3-f262aa409b2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c61b3418-24b1-440b-a1e3-f262aa409b2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c61b3418-24b1-440b-a1e3-f262aa409b2c">
											<gml:posList>35.67420117440726 139.74749359449004 18.766 35.67452686486986 139.74740166751405 18.766 35.67452686486986 139.74740166751405 33.1 35.67420117440726 139.74749359449004 33.1 35.67420117440726 139.74749359449004 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a2c826a-e739-4bd5-ab63-4f3fcec43493">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a2c826a-e739-4bd5-ab63-4f3fcec43493">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a2c826a-e739-4bd5-ab63-4f3fcec43493">
											<gml:posList>35.67419248736397 139.74744610261462 18.766 35.67420117440726 139.74749359449004 18.766 35.67420117440726 139.74749359449004 33.1 35.67419248736397 139.74744610261462 33.1 35.67419248736397 139.74744610261462 18.766</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4571</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1203.53495</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>