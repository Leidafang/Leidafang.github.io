<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_237eaa0a-c02b-4416-9c64-202b80688344">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667638108843896 139.73852105895736 0 35.667646533438955 139.73852838346215 0 35.66767370040898 139.73848205803225 0 35.6675870226198 139.73841124604905 0 35.667563891380404 139.73845446278787 0 35.66748705212136 139.73840087082385 0 35.66740379618242 139.73855461715297 0 35.667580939229765 139.7386986668819 0 35.667663205144244 139.73854657841514 0 35.66765562883185 139.7385405121349 0 35.667649406560756 139.73853696271635 0 35.66764583290261 139.7385430532224 0 35.667632492801395 139.73853189056095 0 35.667638108843896 139.73852105895736 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667638108843896 139.73852105895736 13.635 35.667632492801395 139.73853189056095 13.635 35.66764583290261 139.7385430532224 13.635 35.667649406560756 139.73853696271635 13.635 35.66765562883185 139.7385405121349 13.635 35.667663205144244 139.73854657841514 13.635 35.667580939229765 139.7386986668819 13.635 35.66740379618242 139.73855461715297 13.635 35.66748705212136 139.73840087082385 13.635 35.667563891380404 139.73845446278787 13.635 35.6675870226198 139.73841124604905 13.635 35.66767370040898 139.73848205803225 13.635 35.667646533438955 139.73852838346215 13.635 35.667638108843896 139.73852105895736 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667638108843896 139.73852105895736 13.635 35.667646533438955 139.73852838346215 13.635 35.667646533438955 139.73852838346215 27.95 35.667638108843896 139.73852105895736 27.95 35.667638108843896 139.73852105895736 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667646533438955 139.73852838346215 13.635 35.66767370040898 139.73848205803225 13.635 35.66767370040898 139.73848205803225 27.95 35.667646533438955 139.73852838346215 27.95 35.667646533438955 139.73852838346215 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66767370040898 139.73848205803225 13.635 35.6675870226198 139.73841124604905 13.635 35.6675870226198 139.73841124604905 27.95 35.66767370040898 139.73848205803225 27.95 35.66767370040898 139.73848205803225 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6675870226198 139.73841124604905 13.635 35.667563891380404 139.73845446278787 13.635 35.667563891380404 139.73845446278787 27.95 35.6675870226198 139.73841124604905 27.95 35.6675870226198 139.73841124604905 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667563891380404 139.73845446278787 13.635 35.66748705212136 139.73840087082385 13.635 35.66748705212136 139.73840087082385 27.95 35.667563891380404 139.73845446278787 27.95 35.667563891380404 139.73845446278787 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66748705212136 139.73840087082385 13.635 35.66740379618242 139.73855461715297 13.635 35.66740379618242 139.73855461715297 27.95 35.66748705212136 139.73840087082385 27.95 35.66748705212136 139.73840087082385 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66740379618242 139.73855461715297 13.635 35.667580939229765 139.7386986668819 13.635 35.667580939229765 139.7386986668819 27.95 35.66740379618242 139.73855461715297 27.95 35.66740379618242 139.73855461715297 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667580939229765 139.7386986668819 13.635 35.667663205144244 139.73854657841514 13.635 35.667663205144244 139.73854657841514 27.95 35.667580939229765 139.7386986668819 27.95 35.667580939229765 139.7386986668819 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667663205144244 139.73854657841514 13.635 35.66765562883185 139.7385405121349 13.635 35.66765562883185 139.7385405121349 27.95 35.667663205144244 139.73854657841514 27.95 35.667663205144244 139.73854657841514 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66765562883185 139.7385405121349 13.635 35.667649406560756 139.73853696271635 13.635 35.667649406560756 139.73853696271635 27.95 35.66765562883185 139.7385405121349 27.95 35.66765562883185 139.7385405121349 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667649406560756 139.73853696271635 13.635 35.66764583290261 139.7385430532224 13.635 35.66764583290261 139.7385430532224 27.95 35.667649406560756 139.73853696271635 27.95 35.667649406560756 139.73853696271635 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66764583290261 139.7385430532224 13.635 35.667632492801395 139.73853189056095 13.635 35.667632492801395 139.73853189056095 27.95 35.66764583290261 139.7385430532224 27.95 35.66764583290261 139.7385430532224 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667632492801395 139.73853189056095 13.635 35.667638108843896 139.73852105895736 13.635 35.667638108843896 139.73852105895736 27.95 35.667632492801395 139.73853189056095 27.95 35.667632492801395 139.73853189056095 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667638108843896 139.73852105895736 27.95 35.667646533438955 139.73852838346215 27.95 35.66767370040898 139.73848205803225 27.95 35.6675870226198 139.73841124604905 27.95 35.667563891380404 139.73845446278787 27.95 35.66748705212136 139.73840087082385 27.95 35.66740379618242 139.73855461715297 27.95 35.667580939229765 139.7386986668819 27.95 35.667663205144244 139.73854657841514 27.95 35.66765562883185 139.7385405121349 27.95 35.667649406560756 139.73853696271635 27.95 35.66764583290261 139.7385430532224 27.95 35.667632492801395 139.73853189056095 27.95 35.667638108843896 139.73852105895736 27.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5e547d0b-a70e-4e08-9cae-1c03dc3bd84d"/>
							<gml:surfaceMember xlink:href="#poly-1ce3bf8f-5111-4370-a76f-0ee5afe0399e"/>
							<gml:surfaceMember xlink:href="#poly-c1e91055-c9aa-4ee3-a0de-85e6f67b0e26"/>
							<gml:surfaceMember xlink:href="#poly-8d3225a7-9dd3-4818-9319-86d735056e45"/>
							<gml:surfaceMember xlink:href="#poly-3f24edf9-c992-4ba5-ae12-5fe25578754a"/>
							<gml:surfaceMember xlink:href="#poly-81bda7fe-3f90-4fe6-a6cc-108ae9160dd9"/>
							<gml:surfaceMember xlink:href="#poly-b03cf646-4006-44bf-9cde-d40edbc6e6cc"/>
							<gml:surfaceMember xlink:href="#poly-bbd69245-403d-4f4c-ad73-ef4e1bc78076"/>
							<gml:surfaceMember xlink:href="#poly-7116e855-07fd-4c8b-b9ba-d091792a4f61"/>
							<gml:surfaceMember xlink:href="#poly-6e9e3345-4c65-4328-ad12-70715b146cd2"/>
							<gml:surfaceMember xlink:href="#poly-3db36f61-cd84-4948-8960-1c24f288e1d7"/>
							<gml:surfaceMember xlink:href="#poly-32ab6468-af2d-474e-9208-96eeab00c953"/>
							<gml:surfaceMember xlink:href="#poly-28e06fc8-b57f-4d6e-8efd-a980df7dd71c"/>
							<gml:surfaceMember xlink:href="#poly-299ce0ce-3441-476b-8983-cccd0ce5ffba"/>
							<gml:surfaceMember xlink:href="#poly-2fa2fbb6-e2eb-4cbb-9092-ea3789c2c942"/>
							<gml:surfaceMember xlink:href="#poly-873c3004-2034-4f53-8ca4-43c4037d4671"/>
							<gml:surfaceMember xlink:href="#poly-f8d01963-e8b1-4d0c-aa56-2cd243b63604"/>
							<gml:surfaceMember xlink:href="#poly-1da6c73a-da2a-4010-8bd8-178ba307a3f0"/>
							<gml:surfaceMember xlink:href="#poly-650153ee-e842-47f6-8779-92dbf34266af"/>
							<gml:surfaceMember xlink:href="#poly-b0e4fceb-4c85-4fa6-ab94-660fc617f0d7"/>
							<gml:surfaceMember xlink:href="#poly-18a23459-b5e3-4d88-9a2f-383e4d31af96"/>
							<gml:surfaceMember xlink:href="#poly-5611437b-2ada-4c0b-91e1-7dcf0034ddf8"/>
							<gml:surfaceMember xlink:href="#poly-d040a225-7268-4204-a27c-9ed125b23cf0"/>
							<gml:surfaceMember xlink:href="#poly-2ab3f8f6-d8d9-4b85-b318-dcca5498fb83"/>
							<gml:surfaceMember xlink:href="#poly-9055d095-34c8-448f-b2bc-33119340045e"/>
							<gml:surfaceMember xlink:href="#poly-1bb9740b-b3c8-4435-923c-c8331c1c8fd3"/>
							<gml:surfaceMember xlink:href="#poly-3e96654d-cfbd-44c9-b945-e9dd2bdebf64"/>
							<gml:surfaceMember xlink:href="#poly-77a7243e-4986-4a71-96e7-5d60b57664aa"/>
							<gml:surfaceMember xlink:href="#poly-222085b0-cddd-4425-b07c-11cfb2b80a29"/>
							<gml:surfaceMember xlink:href="#poly-ebc56175-0247-4a0c-993e-7e843d665bef"/>
							<gml:surfaceMember xlink:href="#poly-cad2b20d-dd64-46b5-b389-ce52ccb84a25"/>
							<gml:surfaceMember xlink:href="#poly-ac29c216-8c24-43ee-84c4-90247f52466b"/>
							<gml:surfaceMember xlink:href="#poly-79756abc-c12a-4ac3-8820-a7e56c4ee883"/>
							<gml:surfaceMember xlink:href="#poly-ceaa1789-8f6c-4492-b65d-fe94a41c36b7"/>
							<gml:surfaceMember xlink:href="#poly-0c6e8668-14f4-4867-992a-3bcd95ab49ac"/>
							<gml:surfaceMember xlink:href="#poly-ef2657cb-36ec-4175-9220-44e404011c6d"/>
							<gml:surfaceMember xlink:href="#poly-ea16fbdc-f179-4917-9c30-174a88cdf0d1"/>
							<gml:surfaceMember xlink:href="#poly-217f21ee-7090-4766-b54f-78b8e8f5fe5e"/>
							<gml:surfaceMember xlink:href="#poly-40b3c206-14dc-4ee5-bd90-a8e3f1b94732"/>
							<gml:surfaceMember xlink:href="#poly-0489d9e5-715d-43a8-b32c-804268822610"/>
							<gml:surfaceMember xlink:href="#poly-78eb7fa4-ef33-4716-935b-4bce3296b2b1"/>
							<gml:surfaceMember xlink:href="#poly-fb44fe28-2090-4074-987b-8563a5c9bf78"/>
							<gml:surfaceMember xlink:href="#poly-94d4bb41-a357-4a50-bc9a-478f6ead0804"/>
							<gml:surfaceMember xlink:href="#poly-02c28af7-dd56-4650-a48f-54c48e5399df"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_237eaa0a-c02b-4416-9c64-202b80688344_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccc020b6-fe36-4311-8bb4-7593f058aa90">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66764940656075 139.73853696271632 13.635 35.66764583290258 139.7385430532224 13.635 35.66763249280138 139.73853189056095 13.635 35.66763810884389 139.73852105895736 13.635 35.667646533438926 139.73852838346215 13.635 35.6676712699743 139.73848621416036 13.635 35.66768119151115 139.7384943763814 13.635 35.66765562883185 139.73854051213488 13.635 35.66764940656075 139.73853696271632 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2358153a-f1d8-4bbf-9730-b0b0e6320cbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2358153a-f1d8-4bbf-9730-b0b0e6320cbb_0">
											<gml:posList>35.66768119151115 139.7384943763814 13.635 35.6676712699743 139.73848621416036 13.635 35.6676712699743 139.73848621416036 28.233 35.66768119151115 139.7384943763814 28.233 35.66768119151115 139.7384943763814 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-436d4080-3051-4aa2-b72b-5d96f34f184c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-436d4080-3051-4aa2-b72b-5d96f34f184c_0">
											<gml:posList>35.6676712699743 139.73848621416036 13.635 35.667646533438926 139.73852838346215 13.635 35.667646533438926 139.73852838346215 28.233 35.6676712699743 139.73848621416036 28.233 35.6676712699743 139.73848621416036 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d228dc92-f349-4af3-bca7-5e9919da6e70">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d228dc92-f349-4af3-bca7-5e9919da6e70_0">
											<gml:posList>35.66763249280138 139.73853189056095 28.233 35.66764583290258 139.7385430532224 28.233 35.66764940656075 139.73853696271632 28.233 35.66765562883185 139.73854051213488 28.233 35.66768119151115 139.7384943763814 28.233 35.6676712699743 139.73848621416036 28.233 35.667646533438926 139.73852838346215 28.233 35.66763810884389 139.73852105895736 28.233 35.66763249280138 139.73853189056095 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9eebe70d-bd21-45b8-b008-3e0e24db3715">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9eebe70d-bd21-45b8-b008-3e0e24db3715_0">
											<gml:posList>35.66765562883185 139.73854051213488 13.635 35.66768119151115 139.7384943763814 13.635 35.66768119151115 139.7384943763814 28.233 35.66765562883185 139.73854051213488 28.233 35.66765562883185 139.73854051213488 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6f28d8b-1ee4-45b9-ba46-bbdde87df3e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6f28d8b-1ee4-45b9-ba46-bbdde87df3e2_0">
											<gml:posList>35.667646533438926 139.73852838346215 13.635 35.66763810884389 139.73852105895736 13.635 35.66763810884389 139.73852105895736 28.233 35.667646533438926 139.73852838346215 28.233 35.667646533438926 139.73852838346215 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4372c6e-dd09-4bb1-aeee-5d75cc8e188f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4372c6e-dd09-4bb1-aeee-5d75cc8e188f_0">
											<gml:posList>35.66763249280138 139.73853189056095 28.233 35.66763810884389 139.73852105895736 28.233 35.66763810884389 139.73852105895736 13.635 35.66763249280138 139.73853189056095 13.635 35.66763249280138 139.73853189056095 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5e268c1-c627-445b-aaeb-6367c5490bbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5e268c1-c627-445b-aaeb-6367c5490bbf_0">
											<gml:posList>35.66764583290258 139.7385430532224 28.233 35.66763249280138 139.73853189056095 28.233 35.66763249280138 139.73853189056095 13.635 35.66764583290258 139.7385430532224 13.635 35.66764583290258 139.7385430532224 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8cfcc9a-8310-4d87-aac4-b984867a5870">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8cfcc9a-8310-4d87-aac4-b984867a5870_0">
											<gml:posList>35.66765562883185 139.73854051213488 28.233 35.66764940656075 139.73853696271632 28.233 35.66764940656075 139.73853696271632 13.635 35.66765562883185 139.73854051213488 13.635 35.66765562883185 139.73854051213488 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9bf44ea-409c-4e3b-a37f-4fd2d2f9f813">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9bf44ea-409c-4e3b-a37f-4fd2d2f9f813_0">
											<gml:posList>35.66764940656075 139.73853696271632 28.233 35.66764583290258 139.7385430532224 28.233 35.66764583290258 139.7385430532224 13.635 35.66764940656075 139.73853696271632 13.635 35.66764940656075 139.73853696271632 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_237eaa0a-c02b-4416-9c64-202b80688344_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e168627-3198-47e5-8b2e-5de0e474e198">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e168627-3198-47e5-8b2e-5de0e474e198_0">
											<gml:posList>35.667635125196114 139.7385209299347 27.923 35.66763510715996 139.73852091891015 28.233 35.6676355311008 139.73852129396883 27.922 35.667635125196114 139.7385209299347 27.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e18f831-0a41-4cc1-8d89-4fd1fb2a97f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e18f831-0a41-4cc1-8d89-4fd1fb2a97f7_0">
											<gml:posList>35.66763510715996 139.73852091891015 28.233 35.66763583778493 139.73852156975323 28.233 35.6676355311008 139.73852129396883 27.922 35.66763510715996 139.73852091891015 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-beb4e178-0c63-4925-89fd-265b534c5877">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-beb4e178-0c63-4925-89fd-265b534c5877_0">
											<gml:posList>35.66763583778493 139.73852156975323 28.233 35.66763583778493 139.73852156975323 27.922 35.6676355311008 139.73852129396883 27.922 35.66763583778493 139.73852156975323 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-304c6566-9781-48b9-9caa-1b99116a016f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-304c6566-9781-48b9-9caa-1b99116a016f_0">
											<gml:posList>35.66758683269758 139.73851340956634 27.922 35.66749879308694 139.73844162720138 29.532 35.66758683269758 139.73851340956634 29.532 35.66758683269758 139.73851340956634 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab2ea45c-bcce-417e-bcac-0b13fe62075a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab2ea45c-bcce-417e-bcac-0b13fe62075a_0">
											<gml:posList>35.66758683269758 139.73851340956634 27.922 35.66749879308694 139.73844162720138 27.922 35.66749879308694 139.73844162720138 29.532 35.66758683269758 139.73851340956634 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14ec0551-a608-4cce-b7b0-71b23c44234e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14ec0551-a608-4cce-b7b0-71b23c44234e_0">
											<gml:posList>35.66758765539943 139.73851652353014 27.922 35.66749929109629 139.73844448749043 29.532 35.66749929109629 139.73844448749043 27.922 35.66758765539943 139.73851652353014 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c735e31e-d8b3-4319-b023-ddd4fedecec0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c735e31e-d8b3-4319-b023-ddd4fedecec0_0">
											<gml:posList>35.66758765539943 139.73851652353014 27.922 35.66758765539943 139.73851652353014 29.532 35.66749929109629 139.73844448749043 29.532 35.66758765539943 139.73851652353014 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c1d0a46-0582-458d-9a2a-68fc20db55bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c1d0a46-0582-458d-9a2a-68fc20db55bd_0">
											<gml:posList>35.667452979647344 139.73852601652712 27.922 35.66749879308694 139.73844162720138 29.532 35.66749879308694 139.73844162720138 27.922 35.667452979647344 139.73852601652712 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0eb5ffb-0600-4256-a2df-308bb440aebe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0eb5ffb-0600-4256-a2df-308bb440aebe_0">
											<gml:posList>35.667452979647344 139.73852601652712 27.922 35.667452979647344 139.73852601652712 29.532 35.66749879308694 139.73844162720138 29.532 35.667452979647344 139.73852601652712 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-666a94e7-9c9a-4d7e-a2e5-3c3ef92a0cb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-666a94e7-9c9a-4d7e-a2e5-3c3ef92a0cb3_0">
											<gml:posList>35.66749929109629 139.73844448749043 29.532 35.667455358784146 139.7385253951462 27.922 35.66749929109629 139.73844448749043 27.922 35.66749929109629 139.73844448749043 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ef3577b-f968-4ffe-aac5-c5fc8862dda9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ef3577b-f968-4ffe-aac5-c5fc8862dda9_0">
											<gml:posList>35.66749929109629 139.73844448749043 29.532 35.667455358784146 139.7385253951462 29.532 35.667455358784146 139.7385253951462 27.922 35.66749929109629 139.73844448749043 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2656ce07-f3b8-48a0-82e7-f8a0f8adc037">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2656ce07-f3b8-48a0-82e7-f8a0f8adc037_0">
											<gml:posList>35.667601072544194 139.73848816394602 28.233 35.66760001946073 139.73849009821998 29.532 35.66760109955057 139.7384881197306 29.532 35.667601072544194 139.73848816394602 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cdceb26-b875-4b18-9dc3-0a8f3981bdd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cdceb26-b875-4b18-9dc3-0a8f3981bdd1_0">
											<gml:posList>35.667601072544194 139.73848816394602 28.233 35.66760001946073 139.73849009821998 28.233 35.66760001946073 139.73849009821998 29.532 35.667601072544194 139.73848816394602 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc5cfa7c-6d88-471b-afc4-05052208ebfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc5cfa7c-6d88-471b-afc4-05052208ebfa_0">
											<gml:posList>35.66759585138611 139.73849680799648 29.532 35.66759759215753 139.73849823085564 27.922 35.66759585138611 139.73849680799648 27.922 35.66759585138611 139.73849680799648 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bd4420a-befc-448b-8bad-a57f34adeac6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bd4420a-befc-448b-8bad-a57f34adeac6_0">
											<gml:posList>35.66759585138611 139.73849680799648 29.532 35.66759759215753 139.73849823085564 29.532 35.66759759215753 139.73849823085564 27.922 35.66759585138611 139.73849680799648 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-249f5874-7d37-45c6-afe4-dd1fe159427e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-249f5874-7d37-45c6-afe4-dd1fe159427e_0">
											<gml:posList>35.667601072544194 139.73848816394602 28.233 35.66763834115691 139.73851846290052 29.532 35.66763834115691 139.73851846290052 28.181 35.667601072544194 139.73848816394602 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bae34e5-366c-400e-8f1d-d95fa59a5cad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bae34e5-366c-400e-8f1d-d95fa59a5cad_0">
											<gml:posList>35.667601072544194 139.73848816394602 28.233 35.66760109955057 139.7384881197306 29.532 35.66763834115691 139.73851846290052 29.532 35.667601072544194 139.73848816394602 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29644f8a-369e-4495-83bb-dd3cb9d5f560">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29644f8a-369e-4495-83bb-dd3cb9d5f560_0">
											<gml:posList>35.6676359442276 139.7385193825429 28.233 35.66760001946073 139.73849009821998 29.532 35.66760001946073 139.73849009821998 28.233 35.6676359442276 139.7385193825429 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb8737da-6024-4fff-bd90-074904665317">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb8737da-6024-4fff-bd90-074904665317_0">
											<gml:posList>35.6676359442276 139.7385193825429 28.233 35.6676359442276 139.7385193825429 29.532 35.66760001946073 139.73849009821998 29.532 35.6676359442276 139.7385193825429 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c97259a-df18-494d-8df4-69e51683a3ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c97259a-df18-494d-8df4-69e51683a3ea_0">
											<gml:posList>35.66758683269758 139.73851340956634 29.532 35.66759585138611 139.73849680799648 27.922 35.66758683269758 139.73851340956634 27.922 35.66758683269758 139.73851340956634 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dce2cedd-ee00-4f07-aef7-46e368e7e4a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dce2cedd-ee00-4f07-aef7-46e368e7e4a2_0">
											<gml:posList>35.66758683269758 139.73851340956634 29.532 35.66759585138611 139.73849680799648 29.532 35.66759585138611 139.73849680799648 27.922 35.66758683269758 139.73851340956634 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-661cd41f-3d4c-420e-b032-b28bace3abaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-661cd41f-3d4c-420e-b032-b28bace3abaf_0">
											<gml:posList>35.66759759215753 139.73849823085564 27.922 35.66758765539943 139.73851652353014 29.532 35.66758765539943 139.73851652353014 27.922 35.66759759215753 139.73849823085564 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7cb2e50-4236-432e-9248-1edf0c2da616">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7cb2e50-4236-432e-9248-1edf0c2da616_0">
											<gml:posList>35.66759759215753 139.73849823085564 27.922 35.66759759215753 139.73849823085564 29.532 35.66758765539943 139.73851652353014 29.532 35.66759759215753 139.73849823085564 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1ac3979-d0af-4c1e-b215-971e803ebd44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1ac3979-d0af-4c1e-b215-971e803ebd44_0">
											<gml:posList>35.66760483479894 139.73850408765045 27.922 35.66760483479894 139.73850408765045 29.532 35.66760599835251 139.73850508040334 27.922 35.66760483479894 139.73850408765045 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83b0c846-10d0-498c-a41e-082084a3e74a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83b0c846-10d0-498c-a41e-082084a3e74a_0">
											<gml:posList>35.66760599835251 139.73850508040334 27.922 35.667632154936605 139.73852635697418 29.532 35.667631912070405 139.7385269979224 27.923 35.66760599835251 139.73850508040334 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f0489c9-b640-4bae-b467-98801ef55baf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f0489c9-b640-4bae-b467-98801ef55baf_0">
											<gml:posList>35.66760599835251 139.73850508040334 27.922 35.66760483479894 139.73850408765045 29.532 35.667632154936605 139.73852635697418 29.532 35.66760599835251 139.73850508040334 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-824eaf31-3e11-425d-b03a-05aa90bfeaa5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-824eaf31-3e11-425d-b03a-05aa90bfeaa5_0">
											<gml:posList>35.6676057028306 139.73850753293755 27.922 35.66760768715514 139.73850918747252 27.922 35.6676057028306 139.73850753293755 29.532 35.6676057028306 139.73850753293755 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edf36333-77a7-47cc-a936-eb570250e6c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edf36333-77a7-47cc-a936-eb570250e6c8_0">
											<gml:posList>35.66760768715514 139.73850918747252 27.922 35.667615128332834 139.73851534227302 27.922 35.667615119327806 139.73851535332955 28.233 35.66760768715514 139.73850918747252 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1857aedd-40c9-4921-a15f-e853fc140b3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1857aedd-40c9-4921-a15f-e853fc140b3f_0">
											<gml:posList>35.6676057028306 139.73850753293755 29.532 35.667615119327806 139.73851535332955 28.233 35.66763265350052 139.7385299242042 29.532 35.6676057028306 139.73850753293755 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79a99a4f-45c0-459d-b9a1-3b84b59671ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79a99a4f-45c0-459d-b9a1-3b84b59671ce_0">
											<gml:posList>35.667615119327806 139.73851535332955 28.233 35.66763251817289 139.73852976972182 28.233 35.66763265350052 139.7385299242042 29.532 35.667615119327806 139.73851535332955 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85e7339d-308f-4bd4-bd00-84622e215f47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85e7339d-308f-4bd4-bd00-84622e215f47_0">
											<gml:posList>35.66760768715514 139.73850918747252 27.922 35.667615119327806 139.73851535332955 28.233 35.6676057028306 139.73850753293755 29.532 35.66760768715514 139.73850918747252 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f6e83d0-795e-448f-821c-0c3f391f0948">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f6e83d0-795e-448f-821c-0c3f391f0948_0">
											<gml:posList>35.66763191376622 139.73852915186714 27.923 35.667615218339634 139.73851517647842 28.233 35.667615218339634 139.73851517647842 27.922 35.66763191376622 139.73852915186714 27.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-114df3e4-f18d-4309-8cf9-c3865165549a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-114df3e4-f18d-4309-8cf9-c3865165549a_0">
											<gml:posList>35.66763191376622 139.73852915186714 27.923 35.66763191376622 139.73852915186714 28.233 35.667615218339634 139.73851517647842 28.233 35.66763191376622 139.73852915186714 27.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08172057-0248-47c6-aad3-0906f5197d7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08172057-0248-47c6-aad3-0906f5197d7d_0">
											<gml:posList>35.6676359442276 139.7385193825429 28.233 35.66763510715996 139.73852091891015 28.233 35.6676359442276 139.7385193825429 29.532 35.6676359442276 139.7385193825429 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0110870c-59d9-471c-be72-60663ee0bc20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0110870c-59d9-471c-be72-60663ee0bc20_0">
											<gml:posList>35.6676359442276 139.7385193825429 29.532 35.66763510715996 139.73852091891015 28.233 35.667632154936605 139.73852635697418 29.532 35.6676359442276 139.7385193825429 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc8383f1-c616-40b1-8bf3-fc508803686a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc8383f1-c616-40b1-8bf3-fc508803686a_0">
											<gml:posList>35.667632154936605 139.73852635697418 29.532 35.66763510715996 139.73852091891015 28.233 35.667631912070405 139.7385269979224 27.923 35.667632154936605 139.73852635697418 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25ace304-f2bf-4eb3-857e-f2e946bfe992">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25ace304-f2bf-4eb3-857e-f2e946bfe992_0">
											<gml:posList>35.66763510715996 139.73852091891015 28.233 35.667635125196114 139.7385209299347 27.923 35.667631912070405 139.7385269979224 27.923 35.66763510715996 139.73852091891015 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bffa02c8-c3c7-46dd-975e-678a5ee336c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bffa02c8-c3c7-46dd-975e-678a5ee336c3_0">
											<gml:posList>35.66763834115691 139.73851846290052 29.532 35.66760109955057 139.7384881197306 29.532 35.6676359442276 139.7385193825429 29.532 35.66763834115691 139.73851846290052 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b2c8016-7151-42bd-b852-c67fe699a4d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b2c8016-7151-42bd-b852-c67fe699a4d7_0">
											<gml:posList>35.66763265350052 139.7385299242042 29.532 35.66763834115691 139.73851846290052 29.532 35.6676359442276 139.7385193825429 29.532 35.66763265350052 139.7385299242042 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95b44a2d-a804-4f07-90c9-44a52dbc7a21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95b44a2d-a804-4f07-90c9-44a52dbc7a21_0">
											<gml:posList>35.667455358784146 139.7385253951462 29.532 35.66749879308694 139.73844162720138 29.532 35.667452979647344 139.73852601652712 29.532 35.667455358784146 139.7385253951462 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cab13ec-4816-45fd-b1d6-7f622a62ec6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cab13ec-4816-45fd-b1d6-7f622a62ec6e_0">
											<gml:posList>35.66760109955057 139.7384881197306 29.532 35.66760001946073 139.73849009821998 29.532 35.6676359442276 139.7385193825429 29.532 35.66760109955057 139.7384881197306 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3997f79-1503-4480-99e8-8ae81a55ff55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3997f79-1503-4480-99e8-8ae81a55ff55_0">
											<gml:posList>35.667452979647344 139.73852601652712 29.532 35.66755187871292 139.73860665594728 29.532 35.6675509566973 139.7386033322298 29.532 35.667452979647344 139.73852601652712 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbcdf37a-2e7f-4134-bba0-af12106af0ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbcdf37a-2e7f-4134-bba0-af12106af0ca_0">
											<gml:posList>35.6676057028306 139.73850753293755 29.532 35.66763265350052 139.7385299242042 29.532 35.667632154936605 139.73852635697418 29.532 35.6676057028306 139.73850753293755 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-715d7efe-ad11-4d5f-bdd0-70d164fe54cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-715d7efe-ad11-4d5f-bdd0-70d164fe54cf_0">
											<gml:posList>35.66755187871292 139.73860665594728 29.532 35.6676057028306 139.73850753293755 29.532 35.6675509566973 139.7386033322298 29.532 35.66755187871292 139.73860665594728 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8151ad40-cfbd-44f6-a54e-52382214f1d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8151ad40-cfbd-44f6-a54e-52382214f1d2_0">
											<gml:posList>35.66759759215753 139.73849823085564 29.532 35.66759585138611 139.73849680799648 29.532 35.66758683269758 139.73851340956634 29.532 35.66759759215753 139.73849823085564 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98e9a82a-f067-43a9-b811-e90634efed9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98e9a82a-f067-43a9-b811-e90634efed9e_0">
											<gml:posList>35.66758683269758 139.73851340956634 29.532 35.66749879308694 139.73844162720138 29.532 35.66749929109629 139.73844448749043 29.532 35.66758683269758 139.73851340956634 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bc1d9d3-d466-4ff2-a237-c1c312dc80b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bc1d9d3-d466-4ff2-a237-c1c312dc80b2_0">
											<gml:posList>35.66759759215753 139.73849823085564 29.532 35.66758683269758 139.73851340956634 29.532 35.66758765539943 139.73851652353014 29.532 35.66759759215753 139.73849823085564 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50529468-dcce-4f28-a6a8-3fc392760bbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50529468-dcce-4f28-a6a8-3fc392760bbd_0">
											<gml:posList>35.66760483479894 139.73850408765045 29.532 35.6675509566973 139.7386033322298 29.532 35.6676057028306 139.73850753293755 29.532 35.66760483479894 139.73850408765045 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e21e13c-5c12-4f28-b324-3b4e8f65ea5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e21e13c-5c12-4f28-b324-3b4e8f65ea5f_0">
											<gml:posList>35.66760483479894 139.73850408765045 29.532 35.6676057028306 139.73850753293755 29.532 35.667632154936605 139.73852635697418 29.532 35.66760483479894 139.73850408765045 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92968ffc-db24-4811-8b53-f4b1454d5676">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92968ffc-db24-4811-8b53-f4b1454d5676_0">
											<gml:posList>35.667632154936605 139.73852635697418 29.532 35.66763265350052 139.7385299242042 29.532 35.6676359442276 139.7385193825429 29.532 35.667632154936605 139.73852635697418 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13264d61-8bac-45f1-bf97-20782728f7cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13264d61-8bac-45f1-bf97-20782728f7cf_0">
											<gml:posList>35.667455358784146 139.7385253951462 29.532 35.667452979647344 139.73852601652712 29.532 35.6675509566973 139.7386033322298 29.532 35.667455358784146 139.7385253951462 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f14153f-5108-4d32-946e-a753acba5a3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f14153f-5108-4d32-946e-a753acba5a3c_0">
											<gml:posList>35.667455358784146 139.7385253951462 29.532 35.66749929109629 139.73844448749043 29.532 35.66749879308694 139.73844162720138 29.532 35.667455358784146 139.7385253951462 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7563d22b-f67a-4ba6-93bc-f61198e03be8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7563d22b-f67a-4ba6-93bc-f61198e03be8_0">
											<gml:posList>35.66758683269758 139.73851340956634 29.532 35.66749929109629 139.73844448749043 29.532 35.66758765539943 139.73851652353014 29.532 35.66758683269758 139.73851340956634 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7df69c42-e0d3-474e-ad39-40855faaf3f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7df69c42-e0d3-474e-ad39-40855faaf3f4_0">
											<gml:posList>35.66763834115691 139.73851846290052 29.532 35.66763265350052 139.7385299242042 29.532 35.66763251817289 139.73852976972182 28.233 35.66763834115691 139.73851846290052 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-258e4ad8-1c18-48b9-8f35-8d65d4171983">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-258e4ad8-1c18-48b9-8f35-8d65d4171983_0">
											<gml:posList>35.66763834115691 139.73851846290052 28.181 35.66763834115691 139.73851846290052 29.532 35.66763251817289 139.73852976972182 28.233 35.66763834115691 139.73851846290052 28.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3420ba1d-5778-4808-89e9-ca83229bf341">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3420ba1d-5778-4808-89e9-ca83229bf341_0">
											<gml:posList>35.66763191376622 139.73852915186714 27.923 35.66763223777337 139.73852853291473 27.923 35.66763191376622 139.73852915186714 28.233 35.66763191376622 139.73852915186714 27.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-944c91c7-9f35-4fd0-97f4-8256c471424f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-944c91c7-9f35-4fd0-97f4-8256c471424f_0">
											<gml:posList>35.66763583778493 139.73852156975323 28.233 35.66763191376622 139.73852915186714 28.233 35.66763472177878 139.7385237250196 27.922 35.66763583778493 139.73852156975323 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b286b16-946b-42d1-9650-93551eb68032">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b286b16-946b-42d1-9650-93551eb68032_0">
											<gml:posList>35.66763583778493 139.73852156975323 28.233 35.66763472177878 139.7385237250196 27.922 35.66763583778493 139.73852156975323 27.922 35.66763583778493 139.73852156975323 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5567984-a935-4492-be5a-6556cb208560">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5567984-a935-4492-be5a-6556cb208560_0">
											<gml:posList>35.66763191376622 139.73852915186714 28.233 35.66763223777337 139.73852853291473 27.923 35.66763472177878 139.7385237250196 27.922 35.66763191376622 139.73852915186714 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3767c292-0d6b-47c1-8645-056120ff2c09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3767c292-0d6b-47c1-8645-056120ff2c09_0">
											<gml:posList>35.6675509566973 139.7386033322298 27.922 35.66760483479894 139.73850408765045 29.532 35.66760483479894 139.73850408765045 27.922 35.6675509566973 139.7386033322298 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0137e03-2c37-4c3c-8894-3634c4b1a437">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0137e03-2c37-4c3c-8894-3634c4b1a437_0">
											<gml:posList>35.6675509566973 139.7386033322298 27.922 35.6675509566973 139.7386033322298 29.532 35.66760483479894 139.73850408765045 29.532 35.6675509566973 139.7386033322298 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3db957a-bc79-45ce-ade7-12dd45ac6c64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3db957a-bc79-45ce-ade7-12dd45ac6c64_0">
											<gml:posList>35.6676057028306 139.73850753293755 29.532 35.66755187871292 139.73860665594728 27.922 35.6676057028306 139.73850753293755 27.922 35.6676057028306 139.73850753293755 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f1cd345-3268-4e0c-ba8c-d24c967151d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f1cd345-3268-4e0c-ba8c-d24c967151d5_0">
											<gml:posList>35.6676057028306 139.73850753293755 29.532 35.66755187871292 139.73860665594728 29.532 35.66755187871292 139.73860665594728 27.922 35.6676057028306 139.73850753293755 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e56bf061-0bdd-4837-a029-1c61f118bc78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e56bf061-0bdd-4837-a029-1c61f118bc78_0">
											<gml:posList>35.667455358784146 139.7385253951462 29.532 35.6675509566973 139.7386033322298 27.922 35.667455358784146 139.7385253951462 27.922 35.667455358784146 139.7385253951462 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f165835-ba05-43e0-8876-0eb0a4d5b4c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f165835-ba05-43e0-8876-0eb0a4d5b4c3_0">
											<gml:posList>35.667455358784146 139.7385253951462 29.532 35.6675509566973 139.7386033322298 29.532 35.6675509566973 139.7386033322298 27.922 35.667455358784146 139.7385253951462 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d62c674a-71e5-4c71-a197-13f5b6943eff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d62c674a-71e5-4c71-a197-13f5b6943eff_0">
											<gml:posList>35.66755187871292 139.73860665594728 29.532 35.667452979647344 139.73852601652712 27.922 35.66755187871292 139.73860665594728 27.922 35.66755187871292 139.73860665594728 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c2bfded-3a94-4d9d-adc8-4fa4b79dede7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c2bfded-3a94-4d9d-adc8-4fa4b79dede7_0">
											<gml:posList>35.66755187871292 139.73860665594728 29.532 35.667452979647344 139.73852601652712 29.532 35.667452979647344 139.73852601652712 27.922 35.66755187871292 139.73860665594728 29.532</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2138cdc-899f-451d-9040-9ee8c982433d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676355311008 139.73852129396883 27.922 35.66763583778493 139.73852156975323 27.922 35.66763472177878 139.7385237250196 27.922 35.6676355311008 139.73852129396883 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-763f8dce-257d-4808-9a21-430f47d15864">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66760483479894 139.73850408765045 27.922 35.66760599835251 139.73850508040334 27.922 35.6676057028306 139.73850753293755 27.922 35.66760483479894 139.73850408765045 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17fcf82f-4f02-41c9-b89a-359c8ac5b2c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66758683269758 139.73851340956634 27.922 35.66759585138611 139.73849680799648 27.922 35.66759759215753 139.73849823085564 27.922 35.66758683269758 139.73851340956634 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1333d2d9-91cf-431a-84f2-b62a1ae25487">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676057028306 139.73850753293755 27.922 35.66760599835251 139.73850508040334 27.922 35.66760764192125 139.73850897765433 27.922 35.6676057028306 139.73850753293755 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ca07e80-0bc5-4396-9166-954980aa24c3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66759759215753 139.73849823085564 27.922 35.66758765539943 139.73851652353014 27.922 35.66758683269758 139.73851340956634 27.922 35.66759759215753 139.73849823085564 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b164c50d-fafb-48d5-8917-59b1829ba956">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66749879308694 139.73844162720138 27.922 35.66758683269758 139.73851340956634 27.922 35.66749929109629 139.73844448749043 27.922 35.66749879308694 139.73844162720138 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69b8eb18-79ab-4456-98d4-841de769674f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667452979647344 139.73852601652712 27.922 35.66749879308694 139.73844162720138 27.922 35.667455358784146 139.7385253951462 27.922 35.667452979647344 139.73852601652712 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8643c8e3-3e4b-4beb-a162-6d2a00c62008">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676057028306 139.73850753293755 27.922 35.66760764192125 139.73850897765433 27.922 35.66760768715514 139.73850918747252 27.922 35.6676057028306 139.73850753293755 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ceae53f0-cd0d-46ea-8ba8-536e8c8d6c5f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66760483479894 139.73850408765045 27.922 35.6676057028306 139.73850753293755 27.922 35.6675509566973 139.7386033322298 27.922 35.66760483479894 139.73850408765045 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2984bf5-5eb6-4f28-bcf8-1173e5067a43">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6675509566973 139.7386033322298 27.922 35.66755187871292 139.73860665594728 27.922 35.667452979647344 139.73852601652712 27.922 35.6675509566973 139.7386033322298 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7e509ff-c328-4563-beb9-2fd128277876">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6675509566973 139.7386033322298 27.922 35.667452979647344 139.73852601652712 27.922 35.667455358784146 139.7385253951462 27.922 35.6675509566973 139.7386033322298 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22fb6bec-2889-42a2-9cdb-d56fc2d07bcc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676057028306 139.73850753293755 27.922 35.66755187871292 139.73860665594728 27.922 35.6675509566973 139.7386033322298 27.922 35.6676057028306 139.73850753293755 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34194073-f5e6-42ed-9406-c8dca32f53af">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667455358784146 139.7385253951462 27.922 35.66749879308694 139.73844162720138 27.922 35.66749929109629 139.73844448749043 27.922 35.667455358784146 139.7385253951462 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e9a51c7-4d46-42f0-9250-b658754afa9b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66758765539943 139.73851652353014 27.922 35.66749929109629 139.73844448749043 27.922 35.66758683269758 139.73851340956634 27.922 35.66758765539943 139.73851652353014 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95ae3dcc-b43f-460c-b108-ec3b8948e64b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667615218339634 139.73851517647842 28.233 35.667615128332834 139.73851534227302 27.922 35.667615218339634 139.73851517647842 27.922 35.667615218339634 139.73851517647842 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc05d3b0-1f95-4000-aa2c-8ac6754da4bd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667615218339634 139.73851517647842 28.233 35.667615119327806 139.73851535332955 28.233 35.667615128332834 139.73851534227302 27.922 35.667615218339634 139.73851517647842 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d3d217b-2311-4dbe-b08e-6ccb9a188a3a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66763223777337 139.73852853291473 27.923 35.66763191376622 139.73852915186714 27.923 35.667631912070405 139.7385269979224 27.923 35.66763223777337 139.73852853291473 27.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5954d992-a15d-4d0c-87e4-22c115bf810d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667631912070405 139.7385269979224 27.923 35.667615218339634 139.73851517647842 27.922 35.66760599835251 139.73850508040334 27.922 35.667631912070405 139.7385269979224 27.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-404e5037-7f1b-48db-8ce9-f540c83ffa6f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667615218339634 139.73851517647842 27.922 35.667615128332834 139.73851534227302 27.922 35.66760768715514 139.73850918747252 27.922 35.667615218339634 139.73851517647842 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb35a245-d3a4-42a4-b445-2c9e91e1a117">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66763191376622 139.73852915186714 27.923 35.667615218339634 139.73851517647842 27.922 35.667631912070405 139.7385269979224 27.923 35.66763191376622 139.73852915186714 27.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f5ed26d-d27c-4d63-870f-4c05c11c0bac">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66760599835251 139.73850508040334 27.922 35.667615218339634 139.73851517647842 27.922 35.66760764192125 139.73850897765433 27.922 35.66760599835251 139.73850508040334 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c79bd0a8-ae51-4a2d-8d1f-82df3fcc45ea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66760764192125 139.73850897765433 27.922 35.667615218339634 139.73851517647842 27.922 35.66760768715514 139.73850918747252 27.922 35.66760764192125 139.73850897765433 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6105ed09-4cea-423a-befc-863470b6dc7d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667615119327806 139.73851535332955 28.233 35.667615218339634 139.73851517647842 28.233 35.66763191376622 139.73852915186714 28.233 35.667615119327806 139.73851535332955 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d94ad79c-bcac-4ab3-bef6-448988031913">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66763251817289 139.73852976972182 28.233 35.667615119327806 139.73851535332955 28.233 35.66763191376622 139.73852915186714 28.233 35.66763251817289 139.73852976972182 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea36e17e-51f0-4740-9484-72e2796e7dea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676359442276 139.7385193825429 28.233 35.66760001946073 139.73849009821998 28.233 35.667601072544194 139.73848816394602 28.233 35.6676359442276 139.7385193825429 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0134fc77-5aef-4da5-b09a-ace35b894b41">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66763251817289 139.73852976972182 28.233 35.66763583778493 139.73852156975323 28.233 35.66763834115691 139.73851846290052 28.181 35.66763251817289 139.73852976972182 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84eb9c9b-a34a-4416-ab93-ae5c1e7d4842">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6676359442276 139.7385193825429 28.233 35.667601072544194 139.73848816394602 28.233 35.66763834115691 139.73851846290052 28.181 35.6676359442276 139.7385193825429 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-154891c1-ed9e-4d52-9d98-7e00f749a0e9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66763583778493 139.73852156975323 28.233 35.66763510715996 139.73852091891015 28.233 35.6676359442276 139.7385193825429 28.233 35.66763583778493 139.73852156975323 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95f9f013-da58-4aea-81e6-255b6e180c38">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66763251817289 139.73852976972182 28.233 35.66763191376622 139.73852915186714 28.233 35.66763583778493 139.73852156975323 28.233 35.66763251817289 139.73852976972182 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a744fa4-b17f-4002-8981-503019e597ad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66763583778493 139.73852156975323 28.233 35.6676359442276 139.7385193825429 28.233 35.66763834115691 139.73851846290052 28.181 35.66763583778493 139.73852156975323 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d2f52b8-f3dc-41e7-b337-e87709ebf574">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66763223777337 139.73852853291473 27.923 35.667631912070405 139.7385269979224 27.923 35.66763472177878 139.7385237250196 27.922 35.66763223777337 139.73852853291473 27.923</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80075ef1-cbcc-42ef-b574-077db693a067">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66763472177878 139.7385237250196 27.922 35.667635125196114 139.7385209299347 27.923 35.6676355311008 139.73852129396883 27.922 35.66763472177878 139.7385237250196 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-527484a1-d1e6-4786-a19d-824837e14ed6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66763472177878 139.7385237250196 27.922 35.667631912070405 139.7385269979224 27.923 35.667635125196114 139.7385209299347 27.923 35.66763472177878 139.7385237250196 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_237eaa0a-c02b-4416-9c64-202b80688344_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4229cc45-eeac-45c3-810c-22dcc7a19bac">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66750178478938 139.7385320892766 27.922 35.667483791420985 139.73851815962806 27.922 35.66750001837825 139.73848665973264 27.922 35.667518020772675 139.73850060041212 27.922 35.66750178478938 139.7385320892766 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3952e658-f7c5-421f-92de-a576080d779e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66752029655255 139.73854042911077 27.922 35.66751585957615 139.7385490611763 27.922 35.66750766110792 139.73854273054164 27.922 35.66751209808388 139.7385340984767 27.922 35.66752029655255 139.73854042911077 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb5ef1c6-aa2f-486b-a79e-542cc40188b8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66751448535613 139.73853236145362 27.922 35.667519021334485 139.73852354149054 27.922 35.66752614652673 139.73852905599895 27.922 35.66752161955301 139.73853786490596 27.922 35.66751448535613 139.73853236145362 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20aa8ec8-5070-4144-abe4-1c7cd3aa45d1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66752621368256 139.73851131625864 27.922 35.66753083061763 139.73850228632588 27.922 35.667538352623545 139.7385080654648 27.922 35.66753372667434 139.7385170954087 27.922 35.66752621368256 139.73851131625864 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c7df3b4-2425-41bf-af40-caff8e5470ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667531555788095 139.73856470566164 27.922 35.667538302341086 139.73857014330093 27.922 35.667533766081185 139.7385786097961 27.922 35.66752701952858 139.73857317215635 27.922 35.667531555788095 139.73856470566164 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-788ff077-e9c1-44bb-841a-81694aaa3c19">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667538352623545 139.7385080654648 27.922 35.66753083061763 139.73850228632588 27.922 35.66753083061763 139.73850228632588 30.092 35.667538352623545 139.7385080654648 30.092 35.667538352623545 139.7385080654648 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bfaef8e-3182-4adc-b1da-4cd5c356583a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66753218960257 139.73849963371063 27.922 35.66753971160861 139.73850541284938 27.922 35.66753971160861 139.73850541284938 30.092 35.66753218960257 139.73849963371063 30.092 35.66753218960257 139.73849963371063 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79a0f7e1-6dfd-416c-aaf9-3d49be6d7f2d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66753218960257 139.73849963371063 27.922 35.667536905548545 139.73849042692558 27.922 35.66754442756372 139.73849621710963 27.922 35.66753971160861 139.73850541284938 27.922 35.66753218960257 139.73849963371063 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6d010d9-fb03-4dc8-a8c0-d607b23c0ea5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667539409403894 139.7385680764153 27.922 35.66753266285082 139.7385626387761 27.922 35.66753744214114 139.73855374120407 27.922 35.667544188694606 139.73855917884288 27.922 35.667539409403894 139.7385680764153 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97de7bf8-8bd7-4a58-8eae-149c23172067">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66754325569187 139.73858771142378 27.922 35.66753587777902 139.7385817664188 27.922 35.66754058506523 139.73857300148305 27.922 35.66754795396479 139.73857894649822 27.922 35.66754325569187 139.73858771142378 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5baa3f6-bf63-429d-822b-845c3088c80d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66753864820686 139.7385514864215 27.922 35.667543337480815 139.73854274359672 27.922 35.667550093048504 139.73854818122433 27.922 35.66754539476044 139.73855692406016 27.922 35.66753864820686 139.7385514864215 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9183861-748a-443e-9369-3925c798530a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667553939322325 139.7385677941427 27.922 35.66754884501993 139.73857728856493 27.922 35.66754253139561 139.73857219283457 27.922 35.667547625697615 139.7385626984128 27.922 35.667553939322325 139.7385677941427 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-660af554-69ac-43ce-be7b-f2d3cbc319dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66755116409951 139.73854616961 27.922 35.66754441754545 139.73854073197185 27.922 35.66754919682545 139.73853182335137 27.922 35.6675559433799 139.73853726098912 27.922 35.66755116409951 139.73854616961 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee01ba59-366a-4033-b92b-72fbe26b5b89">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66754919682545 139.73853182335137 27.922 35.66754919682545 139.73853182335137 30.092 35.6675559433799 139.73853726098912 30.092 35.6675559433799 139.73853726098912 27.922 35.66754919682545 139.73853182335137 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57e10ba4-7a79-4e74-9349-bd8f502cb36c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667550168890415 139.73853002172544 27.922 35.66755691544495 139.73853545936308 27.922 35.66755691544495 139.73853545936308 30.092 35.667550168890415 139.73853002172544 30.092 35.667550168890415 139.73853002172544 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cee8e45b-3ea0-4793-9cc9-74725dad5acc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6675490842087 139.73856052065278 27.922 35.667553755490616 139.73855182203212 27.922 35.667560709490274 139.73855742511472 27.922 35.66755604722168 139.73856612372515 27.922 35.6675490842087 139.73856052065278 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2afecc89-9e48-40f8-9cd1-b4c955b038c4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66755525418405 139.7385205383566 27.922 35.667562000739004 139.73852597599378 27.922 35.66755691544495 139.73853545936308 27.922 35.667550168890415 139.73853002172544 27.922 35.66755525418405 139.7385205383566 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dace4bf9-ab56-4424-8b6a-0581039f7395">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667561735559744 139.73855552401216 27.922 35.66755477253758 139.73854990989446 27.922 35.667559560823264 139.73854099021685 27.922 35.66756652383714 139.73854659328825 27.922 35.667561735559744 139.73855552401216 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c3142b2-3d35-40b1-9b93-ec488bfc032e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66755620823879 139.7385187588434 27.922 35.6675608525113 139.738510104435 27.922 35.66756890688332 139.73851658988303 27.922 35.667564262610355 139.73852524429196 27.922 35.66755620823879 139.7385187588434 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1b447b9-6829-46b3-ab50-ddb2178b690d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66756070389701 139.73853886805833 27.922 35.66756765789725 139.7385444711403 27.922 35.66756765789725 139.7385444711403 30.092 35.66756070389701 139.73853886805833 30.092 35.66756070389701 139.73853886805833 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3223101e-d2c6-4437-8fb1-ee15f5710839">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757239218713 139.7385356619835 27.922 35.66756765789725 139.7385444711403 27.922 35.66756070389701 139.73853886805833 27.922 35.66756542916406 139.73853004786676 27.922 35.66757239218713 139.7385356619835 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69e72f39-8bef-491a-a3b9-079ec0972c83">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757239218713 139.7385356619835 27.922 35.66756542916406 139.73853004786676 27.922 35.66756542916406 139.73853004786676 30.092 35.66757239218713 139.7385356619835 30.092 35.66757239218713 139.7385356619835 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88c156d4-4606-4ab8-92e2-c464ce87834c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6675665452312 139.73852796992338 27.922 35.667573508254385 139.73853358404 27.922 35.667573508254385 139.73853358404 30.092 35.6675665452312 139.73852796992338 30.092 35.6675665452312 139.73852796992338 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe9f5784-b91d-4df2-a4ad-4701854c9dc1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757847652637 139.73852429963273 27.922 35.667573508254385 139.73853358404 27.922 35.6675665452312 139.73852796992338 27.922 35.66757152252519 139.73851869655175 27.922 35.66757847652637 139.73852429963273 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad6f69f7-31f0-4988-bc81-fc272889cb18">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667564913882636 139.7384594764036 27.922 35.6675852170426 139.7384762862937 27.922 35.66758096863697 139.73848400133917 27.922 35.667560665478064 139.73846719144802 27.922 35.667564913882636 139.7384594764036 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd7767a4-20df-4ab5-9419-252467588770">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd7767a4-20df-4ab5-9419-252467588770_0">
											<gml:posList>35.66751448535613 139.73853236145362 27.922 35.66752161955301 139.73853786490596 27.922 35.66752161955301 139.73853786490596 30.092 35.66751448535613 139.73853236145362 30.092 35.66751448535613 139.73853236145362 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa736679-5e27-466c-9993-558fed051696">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa736679-5e27-466c-9993-558fed051696_0">
											<gml:posList>35.66754253139561 139.73857219283457 27.922 35.66754884501993 139.73857728856493 27.922 35.66754884501993 139.73857728856493 30.092 35.66754253139561 139.73857219283457 30.092 35.66754253139561 139.73857219283457 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0570103-e6c1-47a5-a3d2-faf4ab7beff0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0570103-e6c1-47a5-a3d2-faf4ab7beff0_0">
											<gml:posList>35.66754441754545 139.73854073197185 27.922 35.66755116409951 139.73854616961 27.922 35.66755116409951 139.73854616961 30.092 35.66754441754545 139.73854073197185 30.092 35.66754441754545 139.73854073197185 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5fdca67-0d92-45d7-b30e-a446acd191f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5fdca67-0d92-45d7-b30e-a446acd191f7_0">
											<gml:posList>35.667547625697615 139.7385626984128 30.092 35.667553939322325 139.7385677941427 30.092 35.667553939322325 139.7385677941427 27.922 35.667547625697615 139.7385626984128 27.922 35.667547625697615 139.7385626984128 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29755872-a539-4b06-801a-d3e21442e0e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29755872-a539-4b06-801a-d3e21442e0e5_0">
											<gml:posList>35.667553755490616 139.73855182203212 27.922 35.667553755490616 139.73855182203212 30.092 35.667560709490274 139.73855742511472 30.092 35.667560709490274 139.73855742511472 27.922 35.667553755490616 139.73855182203212 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8aaa4cab-566b-4a0d-9d74-09f934b0acac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8aaa4cab-566b-4a0d-9d74-09f934b0acac_0">
											<gml:posList>35.667562000739004 139.73852597599378 27.922 35.66755525418405 139.7385205383566 27.922 35.66755525418405 139.7385205383566 30.092 35.667562000739004 139.73852597599378 30.092 35.667562000739004 139.73852597599378 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-451fbbf4-fb8d-466e-bed0-7e5e5e104798">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-451fbbf4-fb8d-466e-bed0-7e5e5e104798_0">
											<gml:posList>35.66756652383714 139.73854659328825 27.922 35.667559560823264 139.73854099021685 27.922 35.667559560823264 139.73854099021685 30.092 35.66756652383714 139.73854659328825 30.092 35.66756652383714 139.73854659328825 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2612a462-d973-4582-8026-51336b631cc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2612a462-d973-4582-8026-51336b631cc2_0">
											<gml:posList>35.667564262610355 139.73852524429196 27.922 35.66756890688332 139.73851658988303 27.922 35.66756890688332 139.73851658988303 30.092 35.667564262610355 139.73852524429196 30.092 35.667564262610355 139.73852524429196 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c76103ce-2906-42c7-bb59-fc2ae22e0c96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c76103ce-2906-42c7-bb59-fc2ae22e0c96_0">
											<gml:posList>35.667564913882636 139.7384594764036 27.922 35.667560665478064 139.73846719144802 27.922 35.667560665478064 139.73846719144802 29.349 35.667564913882636 139.7384594764036 29.349 35.667564913882636 139.7384594764036 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef5e4a83-76bd-43c1-aaea-4e13855c346a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef5e4a83-76bd-43c1-aaea-4e13855c346a_0">
											<gml:posList>35.6675852170426 139.7384762862937 27.922 35.667564913882636 139.7384594764036 27.922 35.667564913882636 139.7384594764036 29.349 35.6675852170426 139.7384762862937 29.349 35.6675852170426 139.7384762862937 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3cdfe7f-e7ed-41f1-b4fa-186a08d8c1f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3cdfe7f-e7ed-41f1-b4fa-186a08d8c1f0_0">
											<gml:posList>35.66758096863697 139.73848400133917 29.349 35.6675852170426 139.7384762862937 29.349 35.667564913882636 139.7384594764036 29.349 35.667560665478064 139.73846719144802 29.349 35.66758096863697 139.73848400133917 29.349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-733ffd28-bca7-40d4-97ed-120b29ab5a72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-733ffd28-bca7-40d4-97ed-120b29ab5a72_0">
											<gml:posList>35.667560665478064 139.73846719144802 27.922 35.66758096863697 139.73848400133917 27.922 35.66758096863697 139.73848400133917 29.349 35.667560665478064 139.73846719144802 29.349 35.667560665478064 139.73846719144802 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cdd2c47-7413-4479-888b-358f5fe5134e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cdd2c47-7413-4479-888b-358f5fe5134e_0">
											<gml:posList>35.66758096863697 139.73848400133917 27.922 35.6675852170426 139.7384762862937 27.922 35.6675852170426 139.7384762862937 29.349 35.66758096863697 139.73848400133917 29.349 35.66758096863697 139.73848400133917 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c544349-4529-490c-8736-e0487ef33406">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c544349-4529-490c-8736-e0487ef33406_0">
											<gml:posList>35.66754442756372 139.73849621710963 27.922 35.667536905548545 139.73849042692558 27.922 35.667536905548545 139.73849042692558 30.092 35.66754442756372 139.73849621710963 30.092 35.66754442756372 139.73849621710963 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8cb1a836-f0c0-4838-add0-1d68b8d395f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8cb1a836-f0c0-4838-add0-1d68b8d395f3_0">
											<gml:posList>35.66750001837825 139.73848665973264 27.922 35.66750001837825 139.73848665973264 30.898 35.667518020772675 139.73850060041212 30.898 35.667518020772675 139.73850060041212 27.922 35.66750001837825 139.73848665973264 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4faed2c-8df6-4a1a-9485-4ecca4d61eb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4faed2c-8df6-4a1a-9485-4ecca4d61eb0_0">
											<gml:posList>35.667536905548545 139.73849042692558 27.922 35.66753218960257 139.73849963371063 27.922 35.66753218960257 139.73849963371063 30.092 35.667536905548545 139.73849042692558 30.092 35.667536905548545 139.73849042692558 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3eb185e0-02bf-44ec-a38d-1a29e63be293">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3eb185e0-02bf-44ec-a38d-1a29e63be293_0">
											<gml:posList>35.66753218960257 139.73849963371063 30.092 35.66753971160861 139.73850541284938 30.092 35.66754442756372 139.73849621710963 30.092 35.667536905548545 139.73849042692558 30.092 35.66753218960257 139.73849963371063 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d6f3204-e36e-489e-bf59-35307b4e437b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d6f3204-e36e-489e-bf59-35307b4e437b_0">
											<gml:posList>35.66753971160861 139.73850541284938 27.922 35.66754442756372 139.73849621710963 27.922 35.66754442756372 139.73849621710963 30.092 35.66753971160861 139.73850541284938 30.092 35.66753971160861 139.73850541284938 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9df1bfe-e636-465d-9bfe-e1ce170eba53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9df1bfe-e636-465d-9bfe-e1ce170eba53_0">
											<gml:posList>35.66750001837825 139.73848665973264 27.922 35.667483791420985 139.73851815962806 27.922 35.667483791420985 139.73851815962806 30.898 35.66750001837825 139.73848665973264 30.898 35.66750001837825 139.73848665973264 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce357ed3-9242-4afc-823b-efe0408331cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce357ed3-9242-4afc-823b-efe0408331cb_0">
											<gml:posList>35.66753083061763 139.73850228632588 27.922 35.66752621368256 139.73851131625864 27.922 35.66752621368256 139.73851131625864 30.092 35.66753083061763 139.73850228632588 30.092 35.66753083061763 139.73850228632588 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc4396e8-5a7a-44bf-bcda-a252ad1f527c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc4396e8-5a7a-44bf-bcda-a252ad1f527c_0">
											<gml:posList>35.66750178478938 139.7385320892766 30.898 35.667518020772675 139.73850060041212 30.898 35.66750001837825 139.73848665973264 30.898 35.667483791420985 139.73851815962806 30.898 35.66750178478938 139.7385320892766 30.898</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e6093a0-c6ba-4960-924f-c068d0f8b58b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e6093a0-c6ba-4960-924f-c068d0f8b58b_0">
											<gml:posList>35.667538352623545 139.7385080654648 30.092 35.66753083061763 139.73850228632588 30.092 35.66752621368256 139.73851131625864 30.092 35.66753372667434 139.7385170954087 30.092 35.667538352623545 139.7385080654648 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39e97006-2db0-4983-8e96-3edd5b19b50b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39e97006-2db0-4983-8e96-3edd5b19b50b_0">
											<gml:posList>35.667538352623545 139.7385080654648 27.922 35.667538352623545 139.7385080654648 30.092 35.66753372667434 139.7385170954087 30.092 35.66753372667434 139.7385170954087 27.922 35.667538352623545 139.7385080654648 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29186844-6952-42d3-90a5-49c2060289c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29186844-6952-42d3-90a5-49c2060289c9_0">
											<gml:posList>35.6675608525113 139.738510104435 27.922 35.6675608525113 139.738510104435 30.092 35.66756890688332 139.73851658988303 30.092 35.66756890688332 139.73851658988303 27.922 35.6675608525113 139.738510104435 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-020b540a-9b55-46ae-9c02-9202647e8746">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-020b540a-9b55-46ae-9c02-9202647e8746_0">
											<gml:posList>35.66752621368256 139.73851131625864 27.922 35.66753372667434 139.7385170954087 27.922 35.66753372667434 139.7385170954087 30.092 35.66752621368256 139.73851131625864 30.092 35.66752621368256 139.73851131625864 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d4103c3-c689-4a9e-8fae-8f62e751aa4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d4103c3-c689-4a9e-8fae-8f62e751aa4c_0">
											<gml:posList>35.66755620823879 139.7385187588434 27.922 35.66755620823879 139.7385187588434 30.092 35.6675608525113 139.738510104435 30.092 35.6675608525113 139.738510104435 27.922 35.66755620823879 139.7385187588434 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b92234b7-4964-41e9-8727-a6c8d69f343c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b92234b7-4964-41e9-8727-a6c8d69f343c_0">
											<gml:posList>35.66750178478938 139.7385320892766 27.922 35.667518020772675 139.73850060041212 27.922 35.667518020772675 139.73850060041212 30.898 35.66750178478938 139.7385320892766 30.898 35.66750178478938 139.7385320892766 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f58fc90f-d1a8-4a24-bf4a-dc53d61ce94b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f58fc90f-d1a8-4a24-bf4a-dc53d61ce94b_0">
											<gml:posList>35.66756890688332 139.73851658988303 30.092 35.6675608525113 139.738510104435 30.092 35.66755620823879 139.7385187588434 30.092 35.667564262610355 139.73852524429196 30.092 35.66756890688332 139.73851658988303 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90f1ae64-6ec6-46c8-a869-fc23833f8128">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90f1ae64-6ec6-46c8-a869-fc23833f8128_0">
											<gml:posList>35.66757847652637 139.73852429963273 27.922 35.66757152252519 139.73851869655175 27.922 35.66757152252519 139.73851869655175 30.092 35.66757847652637 139.73852429963273 30.092 35.66757847652637 139.73852429963273 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-553aeda8-2158-4951-a626-2dd9af5b6b87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-553aeda8-2158-4951-a626-2dd9af5b6b87_0">
											<gml:posList>35.66755620823879 139.7385187588434 27.922 35.667564262610355 139.73852524429196 27.922 35.667564262610355 139.73852524429196 30.092 35.66755620823879 139.7385187588434 30.092 35.66755620823879 139.7385187588434 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74bf675f-0647-46de-935c-05414db9dd38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74bf675f-0647-46de-935c-05414db9dd38_0">
											<gml:posList>35.66757152252519 139.73851869655175 27.922 35.6675665452312 139.73852796992338 27.922 35.6675665452312 139.73852796992338 30.092 35.66757152252519 139.73851869655175 30.092 35.66757152252519 139.73851869655175 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b09008aa-731a-4ecc-8147-521177373cd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b09008aa-731a-4ecc-8147-521177373cd3_0">
											<gml:posList>35.667483791420985 139.73851815962806 27.922 35.66750178478938 139.7385320892766 27.922 35.66750178478938 139.7385320892766 30.898 35.667483791420985 139.73851815962806 30.898 35.667483791420985 139.73851815962806 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-041b534d-9257-48a4-9116-0431cd672f1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-041b534d-9257-48a4-9116-0431cd672f1f_0">
											<gml:posList>35.667550168890415 139.73853002172544 27.922 35.667550168890415 139.73853002172544 30.092 35.66755525418405 139.7385205383566 30.092 35.66755525418405 139.7385205383566 27.922 35.667550168890415 139.73853002172544 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70a9144e-0e17-4f2e-bef6-3daf80b94641">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70a9144e-0e17-4f2e-bef6-3daf80b94641_0">
											<gml:posList>35.6675665452312 139.73852796992338 30.092 35.667573508254385 139.73853358404 30.092 35.66757847652637 139.73852429963273 30.092 35.66757152252519 139.73851869655175 30.092 35.6675665452312 139.73852796992338 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56dc7a88-a6ed-48b4-813a-7e6b74cb4b96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56dc7a88-a6ed-48b4-813a-7e6b74cb4b96_0">
											<gml:posList>35.66752614652673 139.73852905599895 27.922 35.667519021334485 139.73852354149054 27.922 35.667519021334485 139.73852354149054 30.092 35.66752614652673 139.73852905599895 30.092 35.66752614652673 139.73852905599895 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3f6ebb0-7e40-4294-8292-44b1a56ef939">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3f6ebb0-7e40-4294-8292-44b1a56ef939_0">
											<gml:posList>35.66751448535613 139.73853236145362 27.922 35.66751448535613 139.73853236145362 30.092 35.667519021334485 139.73852354149054 30.092 35.667519021334485 139.73852354149054 27.922 35.66751448535613 139.73853236145362 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-247deea0-14d8-4191-aa84-adec09c257ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-247deea0-14d8-4191-aa84-adec09c257ba_0">
											<gml:posList>35.66755525418405 139.7385205383566 30.092 35.667550168890415 139.73853002172544 30.092 35.66755691544495 139.73853545936308 30.092 35.667562000739004 139.73852597599378 30.092 35.66755525418405 139.7385205383566 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26dcec02-5da9-4f1a-ba05-da796d38da9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26dcec02-5da9-4f1a-ba05-da796d38da9e_0">
											<gml:posList>35.66757847652637 139.73852429963273 27.922 35.66757847652637 139.73852429963273 30.092 35.667573508254385 139.73853358404 30.092 35.667573508254385 139.73853358404 27.922 35.66757847652637 139.73852429963273 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c72f9f14-bb7d-4fe4-af2a-06315085e859">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c72f9f14-bb7d-4fe4-af2a-06315085e859_0">
											<gml:posList>35.66751448535613 139.73853236145362 30.092 35.66752161955301 139.73853786490596 30.092 35.66752614652673 139.73852905599895 30.092 35.667519021334485 139.73852354149054 30.092 35.66751448535613 139.73853236145362 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f725f7ab-1d19-491a-b0fb-ce9d7455c5e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f725f7ab-1d19-491a-b0fb-ce9d7455c5e4_0">
											<gml:posList>35.66755691544495 139.73853545936308 27.922 35.667562000739004 139.73852597599378 27.922 35.667562000739004 139.73852597599378 30.092 35.66755691544495 139.73853545936308 30.092 35.66755691544495 139.73853545936308 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edba667b-568e-4806-9758-fbb8b488898d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edba667b-568e-4806-9758-fbb8b488898d_0">
											<gml:posList>35.66752614652673 139.73852905599895 27.922 35.66752614652673 139.73852905599895 30.092 35.66752161955301 139.73853786490596 30.092 35.66752161955301 139.73853786490596 27.922 35.66752614652673 139.73852905599895 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2aea52d-d43a-42db-9543-a91aee97a19f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2aea52d-d43a-42db-9543-a91aee97a19f_0">
											<gml:posList>35.66756542916406 139.73853004786676 27.922 35.66756070389701 139.73853886805833 27.922 35.66756070389701 139.73853886805833 30.092 35.66756542916406 139.73853004786676 30.092 35.66756542916406 139.73853004786676 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb410d98-6293-4529-89a2-0aadec780cb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb410d98-6293-4529-89a2-0aadec780cb1_0">
											<gml:posList>35.66754919682545 139.73853182335137 27.922 35.66754441754545 139.73854073197185 27.922 35.66754441754545 139.73854073197185 30.092 35.66754919682545 139.73853182335137 30.092 35.66754919682545 139.73853182335137 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0569d885-304b-4097-a13a-f426de11f34b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0569d885-304b-4097-a13a-f426de11f34b_0">
											<gml:posList>35.66752029655255 139.73854042911077 27.922 35.66751209808388 139.7385340984767 27.922 35.66751209808388 139.7385340984767 30.092 35.66752029655255 139.73854042911077 30.092 35.66752029655255 139.73854042911077 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99c4a474-feaa-4b53-b61a-39c8c111fa98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99c4a474-feaa-4b53-b61a-39c8c111fa98_0">
											<gml:posList>35.66756070389701 139.73853886805833 30.092 35.66756765789725 139.7385444711403 30.092 35.66757239218713 139.7385356619835 30.092 35.66756542916406 139.73853004786676 30.092 35.66756070389701 139.73853886805833 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3a68e75-ca82-4f3d-b649-b1bc6e8ccdd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3a68e75-ca82-4f3d-b649-b1bc6e8ccdd5_0">
											<gml:posList>35.66751209808388 139.7385340984767 27.922 35.66750766110792 139.73854273054164 27.922 35.66750766110792 139.73854273054164 30.092 35.66751209808388 139.7385340984767 30.092 35.66751209808388 139.7385340984767 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34b5c027-424c-4cf6-a166-3940c8776330">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34b5c027-424c-4cf6-a166-3940c8776330_0">
											<gml:posList>35.66754919682545 139.73853182335137 30.092 35.66754441754545 139.73854073197185 30.092 35.66755116409951 139.73854616961 30.092 35.6675559433799 139.73853726098912 30.092 35.66754919682545 139.73853182335137 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afcad469-58d4-4a6b-b671-a4921578f2d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afcad469-58d4-4a6b-b671-a4921578f2d4_0">
											<gml:posList>35.66756765789725 139.7385444711403 27.922 35.66757239218713 139.7385356619835 27.922 35.66757239218713 139.7385356619835 30.092 35.66756765789725 139.7385444711403 30.092 35.66756765789725 139.7385444711403 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eee82180-1f79-45e1-8330-5538ccdace8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eee82180-1f79-45e1-8330-5538ccdace8a_0">
											<gml:posList>35.66750766110792 139.73854273054164 30.092 35.66751585957615 139.7385490611763 30.092 35.66752029655255 139.73854042911077 30.092 35.66751209808388 139.7385340984767 30.092 35.66750766110792 139.73854273054164 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fde676b-b1c0-42df-a4b3-08d6c94a61e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fde676b-b1c0-42df-a4b3-08d6c94a61e7_0">
											<gml:posList>35.6675559433799 139.73853726098912 27.922 35.6675559433799 139.73853726098912 30.092 35.66755116409951 139.73854616961 30.092 35.66755116409951 139.73854616961 27.922 35.6675559433799 139.73853726098912 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c039a664-6771-4fac-b765-ef7b14be9a29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c039a664-6771-4fac-b765-ef7b14be9a29_0">
											<gml:posList>35.66751585957615 139.7385490611763 27.922 35.66752029655255 139.73854042911077 27.922 35.66752029655255 139.73854042911077 30.092 35.66751585957615 139.7385490611763 30.092 35.66751585957615 139.7385490611763 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5d70668-9d14-483a-b5e2-38690c1bde18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5d70668-9d14-483a-b5e2-38690c1bde18_0">
											<gml:posList>35.667550093048504 139.73854818122433 27.922 35.667543337480815 139.73854274359672 27.922 35.667543337480815 139.73854274359672 30.092 35.667550093048504 139.73854818122433 30.092 35.667550093048504 139.73854818122433 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad562a70-0e28-4b41-b4e3-499bd16a9a82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad562a70-0e28-4b41-b4e3-499bd16a9a82_0">
											<gml:posList>35.667559560823264 139.73854099021685 27.922 35.66755477253758 139.73854990989446 27.922 35.66755477253758 139.73854990989446 30.092 35.667559560823264 139.73854099021685 30.092 35.667559560823264 139.73854099021685 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe42f0dc-a5a2-491e-a7e9-a46536a6dc16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe42f0dc-a5a2-491e-a7e9-a46536a6dc16_0">
											<gml:posList>35.66750766110792 139.73854273054164 27.922 35.66751585957615 139.7385490611763 27.922 35.66751585957615 139.7385490611763 30.092 35.66750766110792 139.73854273054164 30.092 35.66750766110792 139.73854273054164 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c411fe3a-db11-43cf-88c7-666a9a7f2a71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c411fe3a-db11-43cf-88c7-666a9a7f2a71_0">
											<gml:posList>35.667543337480815 139.73854274359672 27.922 35.66753864820686 139.7385514864215 27.922 35.66753864820686 139.7385514864215 30.092 35.667543337480815 139.73854274359672 30.092 35.667543337480815 139.73854274359672 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b0024e3-9ece-46ae-847a-9f5a24d11dfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b0024e3-9ece-46ae-847a-9f5a24d11dfb_0">
											<gml:posList>35.667559560823264 139.73854099021685 30.092 35.66755477253758 139.73854990989446 30.092 35.667561735559744 139.73855552401216 30.092 35.66756652383714 139.73854659328825 30.092 35.667559560823264 139.73854099021685 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-633abfcf-bbcc-47d0-a17f-c7aa70d75ab9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-633abfcf-bbcc-47d0-a17f-c7aa70d75ab9_0">
											<gml:posList>35.667550093048504 139.73854818122433 30.092 35.667543337480815 139.73854274359672 30.092 35.66753864820686 139.7385514864215 30.092 35.66754539476044 139.73855692406016 30.092 35.667550093048504 139.73854818122433 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07831e75-5f41-423a-aaca-fad3b0f550f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07831e75-5f41-423a-aaca-fad3b0f550f1_0">
											<gml:posList>35.667561735559744 139.73855552401216 27.922 35.66756652383714 139.73854659328825 27.922 35.66756652383714 139.73854659328825 30.092 35.667561735559744 139.73855552401216 30.092 35.667561735559744 139.73855552401216 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97017bcb-fc19-4431-af72-2fd9b8733ab3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97017bcb-fc19-4431-af72-2fd9b8733ab3_0">
											<gml:posList>35.667550093048504 139.73854818122433 27.922 35.667550093048504 139.73854818122433 30.092 35.66754539476044 139.73855692406016 30.092 35.66754539476044 139.73855692406016 27.922 35.667550093048504 139.73854818122433 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c2def25-6937-45f7-a85d-ae047cf1ce4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c2def25-6937-45f7-a85d-ae047cf1ce4f_0">
											<gml:posList>35.66755477253758 139.73854990989446 27.922 35.667561735559744 139.73855552401216 27.922 35.667561735559744 139.73855552401216 30.092 35.66755477253758 139.73854990989446 30.092 35.66755477253758 139.73854990989446 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c844acbe-ba89-4875-8550-60453bf53098">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c844acbe-ba89-4875-8550-60453bf53098_0">
											<gml:posList>35.66754539476044 139.73855692406016 27.922 35.66754539476044 139.73855692406016 30.092 35.66753864820686 139.7385514864215 30.092 35.66753864820686 139.7385514864215 27.922 35.66754539476044 139.73855692406016 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d8727ec-f87c-4ba6-8196-1d3c3300aee7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d8727ec-f87c-4ba6-8196-1d3c3300aee7_0">
											<gml:posList>35.6675490842087 139.73856052065278 27.922 35.6675490842087 139.73856052065278 30.092 35.667553755490616 139.73855182203212 30.092 35.667553755490616 139.73855182203212 27.922 35.6675490842087 139.73856052065278 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c68cd32e-60a0-4329-9a2e-baeca1052d2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c68cd32e-60a0-4329-9a2e-baeca1052d2e_0">
											<gml:posList>35.667544188694606 139.73855917884288 27.922 35.66753744214114 139.73855374120407 27.922 35.66753744214114 139.73855374120407 30.092 35.667544188694606 139.73855917884288 30.092 35.667544188694606 139.73855917884288 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77d8fd65-039d-42f7-9a3f-a49aa92fff1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77d8fd65-039d-42f7-9a3f-a49aa92fff1b_0">
											<gml:posList>35.66753744214114 139.73855374120407 27.922 35.66753266285082 139.7385626387761 27.922 35.66753266285082 139.7385626387761 30.092 35.66753744214114 139.73855374120407 30.092 35.66753744214114 139.73855374120407 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ddb58d6-b140-4153-896f-56e6a63b6705">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ddb58d6-b140-4153-896f-56e6a63b6705_0">
											<gml:posList>35.6675490842087 139.73856052065278 30.092 35.66755604722168 139.73856612372515 30.092 35.667560709490274 139.73855742511472 30.092 35.667553755490616 139.73855182203212 30.092 35.6675490842087 139.73856052065278 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87c91b37-7f1f-4531-94a7-4dbf4b1b1d44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87c91b37-7f1f-4531-94a7-4dbf4b1b1d44_0">
											<gml:posList>35.66753744214114 139.73855374120407 30.092 35.66753266285082 139.7385626387761 30.092 35.667539409403894 139.7385680764153 30.092 35.667544188694606 139.73855917884288 30.092 35.66753744214114 139.73855374120407 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9de60963-0e66-4ff2-8fe9-55e5f3c969ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9de60963-0e66-4ff2-8fe9-55e5f3c969ae_0">
											<gml:posList>35.66755604722168 139.73856612372515 27.922 35.667560709490274 139.73855742511472 27.922 35.667560709490274 139.73855742511472 30.092 35.66755604722168 139.73856612372515 30.092 35.66755604722168 139.73856612372515 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee32cecd-9e7f-48ea-9aff-1badbf45ec46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee32cecd-9e7f-48ea-9aff-1badbf45ec46_0">
											<gml:posList>35.6675490842087 139.73856052065278 27.922 35.66755604722168 139.73856612372515 27.922 35.66755604722168 139.73856612372515 30.092 35.6675490842087 139.73856052065278 30.092 35.6675490842087 139.73856052065278 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba399660-bd30-44e4-92c8-6a3cd931f7ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba399660-bd30-44e4-92c8-6a3cd931f7ff_0">
											<gml:posList>35.667539409403894 139.7385680764153 27.922 35.667544188694606 139.73855917884288 27.922 35.667544188694606 139.73855917884288 30.092 35.667539409403894 139.7385680764153 30.092 35.667539409403894 139.7385680764153 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-573cda13-b924-4cc2-8729-4b1cf93348ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-573cda13-b924-4cc2-8729-4b1cf93348ff_0">
											<gml:posList>35.66753266285082 139.7385626387761 27.922 35.667539409403894 139.7385680764153 27.922 35.667539409403894 139.7385680764153 30.092 35.66753266285082 139.7385626387761 30.092 35.66753266285082 139.7385626387761 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fea302a-a030-493f-b8b7-2d5307e2b29e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fea302a-a030-493f-b8b7-2d5307e2b29e_0">
											<gml:posList>35.667538302341086 139.73857014330093 27.922 35.667531555788095 139.73856470566164 27.922 35.667531555788095 139.73856470566164 30.092 35.667538302341086 139.73857014330093 30.092 35.667538302341086 139.73857014330093 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef2c2898-8bda-4057-bce3-3ff05352afce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef2c2898-8bda-4057-bce3-3ff05352afce_0">
											<gml:posList>35.667547625697615 139.7385626984128 27.922 35.66754253139561 139.73857219283457 27.922 35.66754253139561 139.73857219283457 30.092 35.667547625697615 139.7385626984128 30.092 35.667547625697615 139.7385626984128 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87a09a61-9146-41d5-a4a7-6eaa71997f46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87a09a61-9146-41d5-a4a7-6eaa71997f46_0">
											<gml:posList>35.66752701952858 139.73857317215635 27.922 35.66752701952858 139.73857317215635 30.092 35.667531555788095 139.73856470566164 30.092 35.667531555788095 139.73856470566164 27.922 35.66752701952858 139.73857317215635 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bf0eed0-a225-4ae4-9a04-5dff010d970a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bf0eed0-a225-4ae4-9a04-5dff010d970a_0">
											<gml:posList>35.66754253139561 139.73857219283457 30.092 35.66754884501993 139.73857728856493 30.092 35.667553939322325 139.7385677941427 30.092 35.667547625697615 139.7385626984128 30.092 35.66754253139561 139.73857219283457 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c9325a3-fc8a-4685-83e6-547a2c01e4ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c9325a3-fc8a-4685-83e6-547a2c01e4ae_0">
											<gml:posList>35.667533766081185 139.7385786097961 30.092 35.667538302341086 139.73857014330093 30.092 35.667531555788095 139.73856470566164 30.092 35.66752701952858 139.73857317215635 30.092 35.667533766081185 139.7385786097961 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f07adda-ac87-4b4f-833f-76601c670e33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f07adda-ac87-4b4f-833f-76601c670e33_0">
											<gml:posList>35.66754884501993 139.73857728856493 27.922 35.667553939322325 139.7385677941427 27.922 35.667553939322325 139.7385677941427 30.092 35.66754884501993 139.73857728856493 30.092 35.66754884501993 139.73857728856493 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-998a28d9-746b-4e6e-a693-fb9d2e6ab243">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-998a28d9-746b-4e6e-a693-fb9d2e6ab243_0">
											<gml:posList>35.667533766081185 139.7385786097961 27.922 35.667538302341086 139.73857014330093 27.922 35.667538302341086 139.73857014330093 30.092 35.667533766081185 139.7385786097961 30.092 35.667533766081185 139.7385786097961 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f29cd009-b1c1-40e2-a7cb-598cef392a7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f29cd009-b1c1-40e2-a7cb-598cef392a7f_0">
											<gml:posList>35.66752701952858 139.73857317215635 27.922 35.667533766081185 139.7385786097961 27.922 35.667533766081185 139.7385786097961 30.092 35.66752701952858 139.73857317215635 30.092 35.66752701952858 139.73857317215635 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a403d35-b277-4aae-8330-8b352bed5db3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a403d35-b277-4aae-8330-8b352bed5db3_0">
											<gml:posList>35.66754795396479 139.73857894649822 27.922 35.66754058506523 139.73857300148305 27.922 35.66754058506523 139.73857300148305 30.092 35.66754795396479 139.73857894649822 30.092 35.66754795396479 139.73857894649822 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-129d2c5d-d061-476e-a76c-dd02546004be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-129d2c5d-d061-476e-a76c-dd02546004be_0">
											<gml:posList>35.66754058506523 139.73857300148305 27.922 35.66753587777902 139.7385817664188 27.922 35.66753587777902 139.7385817664188 30.092 35.66754058506523 139.73857300148305 30.092 35.66754058506523 139.73857300148305 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d1a5308-3a1d-40db-b943-04346554b424">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d1a5308-3a1d-40db-b943-04346554b424_0">
											<gml:posList>35.66754058506523 139.73857300148305 30.092 35.66753587777902 139.7385817664188 30.092 35.66754325569187 139.73858771142378 30.092 35.66754795396479 139.73857894649822 30.092 35.66754058506523 139.73857300148305 30.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd6175d9-5382-4a35-aacb-13d10e1ef827">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd6175d9-5382-4a35-aacb-13d10e1ef827_0">
											<gml:posList>35.66754325569187 139.73858771142378 27.922 35.66754795396479 139.73857894649822 27.922 35.66754795396479 139.73857894649822 30.092 35.66754325569187 139.73858771142378 30.092 35.66754325569187 139.73858771142378 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b141074-24b7-4942-9a71-3289d5c64501">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b141074-24b7-4942-9a71-3289d5c64501_0">
											<gml:posList>35.66753587777902 139.7385817664188 27.922 35.66754325569187 139.73858771142378 27.922 35.66754325569187 139.73858771142378 30.092 35.66753587777902 139.7385817664188 30.092 35.66753587777902 139.7385817664188 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5e547d0b-a70e-4e08-9cae-1c03dc3bd84d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e547d0b-a70e-4e08-9cae-1c03dc3bd84d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e547d0b-a70e-4e08-9cae-1c03dc3bd84d">
											<gml:posList>35.66767370040898 139.73848205803225 13.635 35.667646533438926 139.73852838346215 13.635 35.66763810884389 139.73852105895736 13.635 35.66763249280138 139.73853189056095 13.635 35.66764583290258 139.7385430532224 13.635 35.66764940656075 139.73853696271632 13.635 35.66765562883185 139.73854051213488 13.635 35.66766320514423 139.73854657841514 13.635 35.667580939229765 139.7386986668819 13.635 35.667403796182434 139.73855461715297 13.635 35.66748705212137 139.73840087082385 13.635 35.66756389138039 139.73845446278787 13.635 35.667587022619756 139.73841124604905 13.635 35.66767370040898 139.73848205803225 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ce3bf8f-5111-4370-a76f-0ee5afe0399e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ce3bf8f-5111-4370-a76f-0ee5afe0399e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ce3bf8f-5111-4370-a76f-0ee5afe0399e">
											<gml:posList>35.66756389138039 139.73845446278787 28.233 35.66763810884389 139.73852105895736 28.233 35.667646533438926 139.73852838346215 28.233 35.66756389138039 139.73845446278787 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1e91055-c9aa-4ee3-a0de-85e6f67b0e26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1e91055-c9aa-4ee3-a0de-85e6f67b0e26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1e91055-c9aa-4ee3-a0de-85e6f67b0e26">
											<gml:posList>35.66755405592043 139.7384754726242 25.628 35.66756389138039 139.73845446278787 25.628 35.66748705212137 139.73840087082385 25.628 35.66747824050039 139.73841714076104 25.628 35.66755405592043 139.7384754726242 25.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d3225a7-9dd3-4818-9319-86d735056e45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d3225a7-9dd3-4818-9319-86d735056e45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d3225a7-9dd3-4818-9319-86d735056e45">
											<gml:posList>35.66755405592043 139.7384754726242 28.233 35.66747824050039 139.73841714076104 28.233 35.66747872945308 139.73841994583063 28.233 35.667554644083665 139.73847835490048 28.233 35.66755405592043 139.7384754726242 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f24edf9-c992-4ba5-ae12-5fe25578754a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f24edf9-c992-4ba5-ae12-5fe25578754a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f24edf9-c992-4ba5-ae12-5fe25578754a">
											<gml:posList>35.66755405592043 139.7384754726242 28.233 35.667554644083665 139.73847835490048 28.233 35.667564407538734 139.7384574777 28.233 35.66756389138039 139.73845446278787 28.233 35.66755405592043 139.7384754726242 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81bda7fe-3f90-4fe6-a6cc-108ae9160dd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81bda7fe-3f90-4fe6-a6cc-108ae9160dd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81bda7fe-3f90-4fe6-a6cc-108ae9160dd9">
											<gml:posList>35.66741726116209 139.73852975911856 28.233 35.66741960424403 139.7385291377807 28.233 35.66747872945308 139.73841994583063 28.233 35.66747824050039 139.73841714076104 28.233 35.66741726116209 139.73852975911856 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b03cf646-4006-44bf-9cde-d40edbc6e6cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b03cf646-4006-44bf-9cde-d40edbc6e6cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b03cf646-4006-44bf-9cde-d40edbc6e6cc">
											<gml:posList>35.66763583778493 139.73852156975323 27.922 35.667564407538734 139.7384574777 27.922 35.667554644083665 139.73847835490048 27.922 35.66747872945308 139.73841994583063 27.922 35.66741960424403 139.7385291377807 27.922 35.667550672767966 139.73863198555057 27.922 35.667615218339634 139.73851517647842 27.922 35.66763191376622 139.73852915186714 27.922 35.66763583778493 139.73852156975323 27.922</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbd69245-403d-4f4c-ad73-ef4e1bc78076">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbd69245-403d-4f4c-ad73-ef4e1bc78076">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbd69245-403d-4f4c-ad73-ef4e1bc78076">
											<gml:posList>35.66755114370558 139.738634812737 28.233 35.667550672767966 139.73863198555057 28.233 35.66741960424403 139.7385291377807 28.233 35.66741726116209 139.73852975911856 28.233 35.66755114370558 139.738634812737 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7116e855-07fd-4c8b-b9ba-d091792a4f61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7116e855-07fd-4c8b-b9ba-d091792a4f61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7116e855-07fd-4c8b-b9ba-d091792a4f61">
											<gml:posList>35.66755114370558 139.738634812737 28.233 35.66741726116209 139.73852975911856 28.233 35.667403796182434 139.73855461715297 24.988 35.66755114370558 139.738634812737 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e9e3345-4c65-4328-ad12-70715b146cd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e9e3345-4c65-4328-ad12-70715b146cd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e9e3345-4c65-4328-ad12-70715b146cd2">
											<gml:posList>35.667403796182434 139.73855461715297 24.988 35.66756749115174 139.73868772524838 24.988 35.66755114370558 139.738634812737 28.233 35.667403796182434 139.73855461715297 24.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3db36f61-cd84-4948-8960-1c24f288e1d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3db36f61-cd84-4948-8960-1c24f288e1d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3db36f61-cd84-4948-8960-1c24f288e1d7">
											<gml:posList>35.66767370040898 139.73848205803225 26.821 35.667587022619756 139.73841124604905 26.821 35.66756389138039 139.73845446278787 28.233 35.66767370040898 139.73848205803225 26.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-32ab6468-af2d-474e-9208-96eeab00c953">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32ab6468-af2d-474e-9208-96eeab00c953">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32ab6468-af2d-474e-9208-96eeab00c953">
											<gml:posList>35.66756389138039 139.73845446278787 28.233 35.667564407538734 139.7384574777 28.233 35.66763583778493 139.73852156975323 28.233 35.66763810884389 139.73852105895736 28.233 35.66756389138039 139.73845446278787 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28e06fc8-b57f-4d6e-8efd-a980df7dd71c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28e06fc8-b57f-4d6e-8efd-a980df7dd71c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28e06fc8-b57f-4d6e-8efd-a980df7dd71c">
											<gml:posList>35.66767370040898 139.73848205803225 26.821 35.66756389138039 139.73845446278787 28.233 35.667646533438926 139.73852838346215 28.233 35.66767370040898 139.73848205803225 26.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-299ce0ce-3441-476b-8983-cccd0ce5ffba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-299ce0ce-3441-476b-8983-cccd0ce5ffba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-299ce0ce-3441-476b-8983-cccd0ce5ffba">
											<gml:posList>35.66761576130281 139.73851789312246 28.233 35.66763249280138 139.73853189056095 28.233 35.66763191376622 139.73852915186714 28.233 35.667615218339634 139.73851517647842 28.233 35.66761576130281 139.73851789312246 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2fa2fbb6-e2eb-4cbb-9092-ea3789c2c942">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fa2fbb6-e2eb-4cbb-9092-ea3789c2c942">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fa2fbb6-e2eb-4cbb-9092-ea3789c2c942">
											<gml:posList>35.66763810884389 139.73852105895736 28.233 35.66763583778493 139.73852156975323 28.233 35.66763191376622 139.73852915186714 28.233 35.66763249280138 139.73853189056095 28.233 35.66763810884389 139.73852105895736 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-873c3004-2034-4f53-8ca4-43c4037d4671">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-873c3004-2034-4f53-8ca4-43c4037d4671">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-873c3004-2034-4f53-8ca4-43c4037d4671">
											<gml:posList>35.66761576130281 139.73851789312246 28.233 35.667615218339634 139.73851517647842 28.233 35.667550672767966 139.73863198555057 28.233 35.66755114370558 139.738634812737 28.233 35.66761576130281 139.73851789312246 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8d01963-e8b1-4d0c-aa56-2cd243b63604">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8d01963-e8b1-4d0c-aa56-2cd243b63604">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8d01963-e8b1-4d0c-aa56-2cd243b63604">
											<gml:posList>35.66756749115174 139.73868772524838 24.988 35.66761576130281 139.73851789312246 28.233 35.66755114370558 139.738634812737 28.233 35.66756749115174 139.73868772524838 24.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1da6c73a-da2a-4010-8bd8-178ba307a3f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1da6c73a-da2a-4010-8bd8-178ba307a3f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1da6c73a-da2a-4010-8bd8-178ba307a3f0">
											<gml:posList>35.66756749115174 139.73868772524838 24.988 35.66763243868424 139.7385318464414 26.453 35.66761576130281 139.73851789312246 28.233 35.66756749115174 139.73868772524838 24.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-650153ee-e842-47f6-8779-92dbf34266af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-650153ee-e842-47f6-8779-92dbf34266af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-650153ee-e842-47f6-8779-92dbf34266af">
											<gml:posList>35.66756749115174 139.73868772524838 24.988 35.66764583290258 139.7385430532224 24.988 35.66763243868424 139.7385318464414 26.453 35.66756749115174 139.73868772524838 24.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0e4fceb-4c85-4fa6-ab94-660fc617f0d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0e4fceb-4c85-4fa6-ab94-660fc617f0d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0e4fceb-4c85-4fa6-ab94-660fc617f0d7">
											<gml:posList>35.667580939229765 139.7386986668819 24.988 35.66766320514423 139.73854657841514 24.988 35.66765562883185 139.73854051213488 24.988 35.66764940656075 139.73853696271632 24.988 35.66764583290258 139.7385430532224 24.988 35.66756749115174 139.73868772524838 24.988 35.667580939229765 139.7386986668819 24.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18a23459-b5e3-4d88-9a2f-383e4d31af96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18a23459-b5e3-4d88-9a2f-383e4d31af96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18a23459-b5e3-4d88-9a2f-383e4d31af96">
											<gml:posList>35.66756389138039 139.73845446278787 13.635 35.66748705212137 139.73840087082385 13.635 35.66748705212137 139.73840087082385 25.628 35.66756389138039 139.73845446278787 25.628 35.66756389138039 139.73845446278787 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5611437b-2ada-4c0b-91e1-7dcf0034ddf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5611437b-2ada-4c0b-91e1-7dcf0034ddf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5611437b-2ada-4c0b-91e1-7dcf0034ddf8">
											<gml:posList>35.667587022619756 139.73841124604905 26.821 35.667587022619756 139.73841124604905 13.635 35.66756389138039 139.73845446278787 13.635 35.66756389138039 139.73845446278787 25.628 35.66756389138039 139.73845446278787 28.233 35.667587022619756 139.73841124604905 26.821</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d040a225-7268-4204-a27c-9ed125b23cf0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d040a225-7268-4204-a27c-9ed125b23cf0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d040a225-7268-4204-a27c-9ed125b23cf0">
											<gml:posList>35.66747824050039 139.73841714076104 28.233 35.66755405592043 139.7384754726242 28.233 35.66755405592043 139.7384754726242 25.628 35.66747824050039 139.73841714076104 25.628 35.66747824050039 139.73841714076104 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ab3f8f6-d8d9-4b85-b318-dcca5498fb83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ab3f8f6-d8d9-4b85-b318-dcca5498fb83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ab3f8f6-d8d9-4b85-b318-dcca5498fb83">
											<gml:posList>35.66767370040898 139.73848205803225 13.635 35.667587022619756 139.73841124604905 13.635 35.667587022619756 139.73841124604905 26.821 35.66767370040898 139.73848205803225 26.821 35.66767370040898 139.73848205803225 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9055d095-34c8-448f-b2bc-33119340045e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9055d095-34c8-448f-b2bc-33119340045e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9055d095-34c8-448f-b2bc-33119340045e">
											<gml:posList>35.66747872945308 139.73841994583063 28.233 35.66747872945308 139.73841994583063 27.922 35.667554644083665 139.73847835490048 27.922 35.667554644083665 139.73847835490048 28.233 35.66747872945308 139.73841994583063 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bb9740b-b3c8-4435-923c-c8331c1c8fd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bb9740b-b3c8-4435-923c-c8331c1c8fd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bb9740b-b3c8-4435-923c-c8331c1c8fd3">
											<gml:posList>35.66755405592043 139.7384754726242 28.233 35.66756389138039 139.73845446278787 28.233 35.66756389138039 139.73845446278787 25.628 35.66755405592043 139.7384754726242 25.628 35.66755405592043 139.7384754726242 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e96654d-cfbd-44c9-b945-e9dd2bdebf64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e96654d-cfbd-44c9-b945-e9dd2bdebf64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e96654d-cfbd-44c9-b945-e9dd2bdebf64">
											<gml:posList>35.667554644083665 139.73847835490048 28.233 35.667554644083665 139.73847835490048 27.922 35.667564407538734 139.7384574777 27.922 35.667564407538734 139.7384574777 28.233 35.667554644083665 139.73847835490048 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77a7243e-4986-4a71-96e7-5d60b57664aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77a7243e-4986-4a71-96e7-5d60b57664aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77a7243e-4986-4a71-96e7-5d60b57664aa">
											<gml:posList>35.66741960424403 139.7385291377807 28.233 35.66741960424403 139.7385291377807 27.922 35.66747872945308 139.73841994583063 27.922 35.66747872945308 139.73841994583063 28.233 35.66741960424403 139.7385291377807 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-222085b0-cddd-4425-b07c-11cfb2b80a29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-222085b0-cddd-4425-b07c-11cfb2b80a29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-222085b0-cddd-4425-b07c-11cfb2b80a29">
											<gml:posList>35.66741726116209 139.73852975911856 28.233 35.66747824050039 139.73841714076104 28.233 35.66747824050039 139.73841714076104 25.628 35.66748705212137 139.73840087082385 25.628 35.66748705212137 139.73840087082385 13.635 35.667403796182434 139.73855461715297 13.635 35.667403796182434 139.73855461715297 24.988 35.66741726116209 139.73852975911856 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebc56175-0247-4a0c-993e-7e843d665bef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebc56175-0247-4a0c-993e-7e843d665bef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebc56175-0247-4a0c-993e-7e843d665bef">
											<gml:posList>35.667564407538734 139.7384574777 28.233 35.667564407538734 139.7384574777 27.922 35.66763583778493 139.73852156975323 27.922 35.66763583778493 139.73852156975323 28.233 35.667564407538734 139.7384574777 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cad2b20d-dd64-46b5-b389-ce52ccb84a25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cad2b20d-dd64-46b5-b389-ce52ccb84a25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cad2b20d-dd64-46b5-b389-ce52ccb84a25">
											<gml:posList>35.667646533438926 139.73852838346215 13.635 35.66767370040898 139.73848205803225 13.635 35.66767370040898 139.73848205803225 26.821 35.667646533438926 139.73852838346215 28.233 35.667646533438926 139.73852838346215 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac29c216-8c24-43ee-84c4-90247f52466b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac29c216-8c24-43ee-84c4-90247f52466b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac29c216-8c24-43ee-84c4-90247f52466b">
											<gml:posList>35.66763191376622 139.73852915186714 28.233 35.66763191376622 139.73852915186714 27.922 35.667615218339634 139.73851517647842 27.922 35.667615218339634 139.73851517647842 28.233 35.66763191376622 139.73852915186714 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79756abc-c12a-4ac3-8820-a7e56c4ee883">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79756abc-c12a-4ac3-8820-a7e56c4ee883">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79756abc-c12a-4ac3-8820-a7e56c4ee883">
											<gml:posList>35.66763810884389 139.73852105895736 13.635 35.667646533438926 139.73852838346215 13.635 35.667646533438926 139.73852838346215 28.233 35.66763810884389 139.73852105895736 28.233 35.66763810884389 139.73852105895736 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ceaa1789-8f6c-4492-b65d-fe94a41c36b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceaa1789-8f6c-4492-b65d-fe94a41c36b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceaa1789-8f6c-4492-b65d-fe94a41c36b7">
											<gml:posList>35.66761576130281 139.73851789312246 28.233 35.66763243868424 139.7385318464414 26.453 35.66763249280138 139.73853189056095 28.233 35.66761576130281 139.73851789312246 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c6e8668-14f4-4867-992a-3bcd95ab49ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c6e8668-14f4-4867-992a-3bcd95ab49ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c6e8668-14f4-4867-992a-3bcd95ab49ac">
											<gml:posList>35.66763583778493 139.73852156975323 28.233 35.66763583778493 139.73852156975323 27.922 35.66763191376622 139.73852915186714 27.922 35.66763191376622 139.73852915186714 28.233 35.66763583778493 139.73852156975323 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef2657cb-36ec-4175-9220-44e404011c6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef2657cb-36ec-4175-9220-44e404011c6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef2657cb-36ec-4175-9220-44e404011c6d">
											<gml:posList>35.66763810884389 139.73852105895736 28.233 35.66763249280138 139.73853189056095 28.233 35.66763243868424 139.7385318464414 26.453 35.66763249280138 139.73853189056095 13.635 35.66763810884389 139.73852105895736 13.635 35.66763810884389 139.73852105895736 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea16fbdc-f179-4917-9c30-174a88cdf0d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea16fbdc-f179-4917-9c30-174a88cdf0d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea16fbdc-f179-4917-9c30-174a88cdf0d1">
											<gml:posList>35.66763249280138 139.73853189056095 13.635 35.66763243868424 139.7385318464414 26.453 35.66764583290258 139.7385430532224 24.988 35.66764583290258 139.7385430532224 13.635 35.66763249280138 139.73853189056095 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-217f21ee-7090-4766-b54f-78b8e8f5fe5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-217f21ee-7090-4766-b54f-78b8e8f5fe5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-217f21ee-7090-4766-b54f-78b8e8f5fe5e">
											<gml:posList>35.66765562883185 139.73854051213488 13.635 35.66764940656075 139.73853696271632 13.635 35.66764940656075 139.73853696271632 24.988 35.66765562883185 139.73854051213488 24.988 35.66765562883185 139.73854051213488 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40b3c206-14dc-4ee5-bd90-a8e3f1b94732">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40b3c206-14dc-4ee5-bd90-a8e3f1b94732">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40b3c206-14dc-4ee5-bd90-a8e3f1b94732">
											<gml:posList>35.66764940656075 139.73853696271632 13.635 35.66764583290258 139.7385430532224 13.635 35.66764583290258 139.7385430532224 24.988 35.66764940656075 139.73853696271632 24.988 35.66764940656075 139.73853696271632 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0489d9e5-715d-43a8-b32c-804268822610">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0489d9e5-715d-43a8-b32c-804268822610">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0489d9e5-715d-43a8-b32c-804268822610">
											<gml:posList>35.66766320514423 139.73854657841514 13.635 35.66765562883185 139.73854051213488 13.635 35.66765562883185 139.73854051213488 24.988 35.66766320514423 139.73854657841514 24.988 35.66766320514423 139.73854657841514 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78eb7fa4-ef33-4716-935b-4bce3296b2b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78eb7fa4-ef33-4716-935b-4bce3296b2b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78eb7fa4-ef33-4716-935b-4bce3296b2b1">
											<gml:posList>35.667615218339634 139.73851517647842 28.233 35.667615218339634 139.73851517647842 27.922 35.667550672767966 139.73863198555057 27.922 35.667550672767966 139.73863198555057 28.233 35.667615218339634 139.73851517647842 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb44fe28-2090-4074-987b-8563a5c9bf78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb44fe28-2090-4074-987b-8563a5c9bf78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb44fe28-2090-4074-987b-8563a5c9bf78">
											<gml:posList>35.667550672767966 139.73863198555057 28.233 35.667550672767966 139.73863198555057 27.922 35.66741960424403 139.7385291377807 27.922 35.66741960424403 139.7385291377807 28.233 35.667550672767966 139.73863198555057 28.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94d4bb41-a357-4a50-bc9a-478f6ead0804">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94d4bb41-a357-4a50-bc9a-478f6ead0804">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94d4bb41-a357-4a50-bc9a-478f6ead0804">
											<gml:posList>35.667580939229765 139.7386986668819 13.635 35.66766320514423 139.73854657841514 13.635 35.66766320514423 139.73854657841514 24.988 35.667580939229765 139.7386986668819 24.988 35.667580939229765 139.7386986668819 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02c28af7-dd56-4650-a48f-54c48e5399df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02c28af7-dd56-4650-a48f-54c48e5399df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02c28af7-dd56-4650-a48f-54c48e5399df">
											<gml:posList>35.667403796182434 139.73855461715297 13.635 35.667580939229765 139.7386986668819 13.635 35.667580939229765 139.7386986668819 24.988 35.66756749115174 139.73868772524838 24.988 35.667403796182434 139.73855461715297 24.988 35.667403796182434 139.73855461715297 13.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9999</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">464.6958</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">2</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>