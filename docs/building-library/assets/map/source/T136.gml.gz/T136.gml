<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2389849d-90eb-4633-9585-d497e2e9bf90">
			<gml:name>愛宕警察署虎の門交番</gml:name>
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>環状第二号線新橋・虎ノ門地区</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">421</bldg:usage>
			<bldg:measuredHeight uom="m">6.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66913415507225 139.74742654825562 0 35.66912420956314 139.7474218367091 0 35.669109423459325 139.74742313389777 0 35.66909864206913 139.7474255711694 0 35.6690437125546 139.74747004960724 0 35.66903777833438 139.74747443352155 0 35.66902593788283 139.74748453126554 0 35.669019945696505 139.74749358331022 0 35.669020393330484 139.74750194581273 0 35.66902394337176 139.74750634718654 0 35.669035127090616 139.74751193888915 0 35.66904169601508 139.7475153340495 0 35.669090205059746 139.74754040313098 0 35.6691231046718 139.74744485020585 0 35.669127680686856 139.74744701696494 0 35.66913415507225 139.74742654825562 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913415507225 139.74742654825562 5.84 35.669127680686856 139.74744701696494 5.84 35.6691231046718 139.74744485020585 5.84 35.669090205059746 139.74754040313098 5.84 35.66904169601508 139.7475153340495 5.84 35.669035127090616 139.74751193888915 5.84 35.66902394337176 139.74750634718654 5.84 35.669020393330484 139.74750194581273 5.84 35.669019945696505 139.74749358331022 5.84 35.66902593788283 139.74748453126554 5.84 35.66903777833438 139.74747443352155 5.84 35.6690437125546 139.74747004960724 5.84 35.66909864206913 139.7474255711694 5.84 35.669109423459325 139.74742313389777 5.84 35.66912420956314 139.7474218367091 5.84 35.66913415507225 139.74742654825562 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913415507225 139.74742654825562 5.84 35.66912420956314 139.7474218367091 5.84 35.66912420956314 139.7474218367091 12.485 35.66913415507225 139.74742654825562 12.485 35.66913415507225 139.74742654825562 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66912420956314 139.7474218367091 5.84 35.669109423459325 139.74742313389777 5.84 35.669109423459325 139.74742313389777 12.485 35.66912420956314 139.7474218367091 12.485 35.66912420956314 139.7474218367091 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669109423459325 139.74742313389777 5.84 35.66909864206913 139.7474255711694 5.84 35.66909864206913 139.7474255711694 12.485 35.669109423459325 139.74742313389777 12.485 35.669109423459325 139.74742313389777 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909864206913 139.7474255711694 5.84 35.6690437125546 139.74747004960724 5.84 35.6690437125546 139.74747004960724 12.485 35.66909864206913 139.7474255711694 12.485 35.66909864206913 139.7474255711694 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690437125546 139.74747004960724 5.84 35.66903777833438 139.74747443352155 5.84 35.66903777833438 139.74747443352155 12.485 35.6690437125546 139.74747004960724 12.485 35.6690437125546 139.74747004960724 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903777833438 139.74747443352155 5.84 35.66902593788283 139.74748453126554 5.84 35.66902593788283 139.74748453126554 12.485 35.66903777833438 139.74747443352155 12.485 35.66903777833438 139.74747443352155 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902593788283 139.74748453126554 5.84 35.669019945696505 139.74749358331022 5.84 35.669019945696505 139.74749358331022 12.485 35.66902593788283 139.74748453126554 12.485 35.66902593788283 139.74748453126554 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669019945696505 139.74749358331022 5.84 35.669020393330484 139.74750194581273 5.84 35.669020393330484 139.74750194581273 12.485 35.669019945696505 139.74749358331022 12.485 35.669019945696505 139.74749358331022 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669020393330484 139.74750194581273 5.84 35.66902394337176 139.74750634718654 5.84 35.66902394337176 139.74750634718654 12.485 35.669020393330484 139.74750194581273 12.485 35.669020393330484 139.74750194581273 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902394337176 139.74750634718654 5.84 35.669035127090616 139.74751193888915 5.84 35.669035127090616 139.74751193888915 12.485 35.66902394337176 139.74750634718654 12.485 35.66902394337176 139.74750634718654 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669035127090616 139.74751193888915 5.84 35.66904169601508 139.7475153340495 5.84 35.66904169601508 139.7475153340495 12.485 35.669035127090616 139.74751193888915 12.485 35.669035127090616 139.74751193888915 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904169601508 139.7475153340495 5.84 35.669090205059746 139.74754040313098 5.84 35.669090205059746 139.74754040313098 12.485 35.66904169601508 139.7475153340495 12.485 35.66904169601508 139.7475153340495 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669090205059746 139.74754040313098 5.84 35.6691231046718 139.74744485020585 5.84 35.6691231046718 139.74744485020585 12.485 35.669090205059746 139.74754040313098 12.485 35.669090205059746 139.74754040313098 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691231046718 139.74744485020585 5.84 35.669127680686856 139.74744701696494 5.84 35.669127680686856 139.74744701696494 12.485 35.6691231046718 139.74744485020585 12.485 35.6691231046718 139.74744485020585 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669127680686856 139.74744701696494 5.84 35.66913415507225 139.74742654825562 5.84 35.66913415507225 139.74742654825562 12.485 35.669127680686856 139.74744701696494 12.485 35.669127680686856 139.74744701696494 5.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913415507225 139.74742654825562 12.485 35.66912420956314 139.7474218367091 12.485 35.669109423459325 139.74742313389777 12.485 35.66909864206913 139.7474255711694 12.485 35.6690437125546 139.74747004960724 12.485 35.66903777833438 139.74747443352155 12.485 35.66902593788283 139.74748453126554 12.485 35.669019945696505 139.74749358331022 12.485 35.669020393330484 139.74750194581273 12.485 35.66902394337176 139.74750634718654 12.485 35.669035127090616 139.74751193888915 12.485 35.66904169601508 139.7475153340495 12.485 35.669090205059746 139.74754040313098 12.485 35.6691231046718 139.74744485020585 12.485 35.669127680686856 139.74744701696494 12.485 35.66913415507225 139.74742654825562 12.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_5"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_6"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_7"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_8"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_9"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_10"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_11"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1033_12"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1032_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1032_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1032_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1032_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1032_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1032_5"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1032_6"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_p1032_7"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0157_b_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_5c5224d1-7b5c-43e8-8b7b-4554fbb240a8">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_df5bf383-ad3a-4a3f-b61d-c0a957042fa7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_28d338b7-5c8e-450a-9993-9b7072639024">
											<gml:posList>35.66902178626362 139.7475117953996 7.4212544185398315 35.669023031834264 139.747512403205 7.4212544185398315 35.669023031834264 139.747512403205 9.472493432211706 35.66902178626362 139.7475117953996 9.472493432211706 35.66902178626362 139.7475117953996 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_32f5cde3-4df6-453f-b04d-51c73a5bb081">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ffb286ba-ddc2-4762-9483-ddb421587ec9">
											<gml:posList>35.669023031834264 139.747512403205 7.4212544185398315 35.66902320655805 139.7475118939979 7.4212544185398315 35.66902320655805 139.7475118939979 9.472493432211706 35.669023031834264 139.747512403205 9.472493432211706 35.669023031834264 139.747512403205 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1277defe-914f-44bd-a159-38720b3490c4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_507bd9e7-9278-45f9-8e67-8eb2a7629fa6">
											<gml:posList>35.66902320655805 139.7475118939979 7.4212544185398315 35.669021988917464 139.74751129981513 7.4212544185398315 35.669021988917464 139.74751129981513 9.472493432211706 35.66902320655805 139.7475118939979 9.472493432211706 35.66902320655805 139.7475118939979 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b649a22a-20c8-4b08-9259-be2fc9accf8c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e7b6ffc1-9abe-4e6f-959d-998e7641a016">
											<gml:posList>35.669021988917464 139.74751129981513 7.4212544185398315 35.66902069990251 139.74751033119134 7.4212544185398315 35.66902069990251 139.74751033119134 9.472493432211706 35.669021988917464 139.74751129981513 9.472493432211706 35.669021988917464 139.74751129981513 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_605ebf13-0af5-4857-92c6-e8172607dafe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_09992240-dab9-4a84-8929-b73efb3df92e">
											<gml:posList>35.66902069990251 139.74751033119134 7.4212544185398315 35.66901952925392 139.74750890027758 7.4212544185398315 35.66901952925392 139.74750890027758 9.472493432211706 35.66902069990251 139.74751033119134 9.472493432211706 35.66902069990251 139.74751033119134 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_67e5b3f1-9e2d-4c34-9960-e9be0519668c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_42f2d921-b50d-4fa4-8ec8-556313c90398">
											<gml:posList>35.66901952925392 139.74750890027758 7.4212544185398315 35.66901862951852 139.7475070301705 7.4212544185398315 35.66901862951852 139.7475070301705 9.472493432211706 35.66901952925392 139.74750890027758 9.472493432211706 35.66901952925392 139.74750890027758 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d0c0f8e3-98bf-4055-b5d7-e157301961e2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e61b0f7e-baba-42de-be09-c3e47aa5171e">
											<gml:posList>35.66901862951852 139.7475070301705 7.4212544185398315 35.66901814851022 139.74750485757426 7.4212544185398315 35.66901814851022 139.74750485757426 9.472493432211706 35.66901862951852 139.7475070301705 9.472493432211706 35.66901862951852 139.7475070301705 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a3003317-f933-4b60-bc94-7b6088cf8d21">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3b67fe25-3c88-4a56-99cb-4890bafcd3b8">
											<gml:posList>35.66901814851022 139.74750485757426 7.4212544185398315 35.6690181624475 139.74750260640965 7.4212544185398315 35.6690181624475 139.74750260640965 9.472493432211706 35.66901814851022 139.74750485757426 9.472493432211706 35.66901814851022 139.74750485757426 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_38a8aeeb-1108-4cab-9fa8-67c9ea95dd2a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_31d326f3-b9d0-4efa-b8ac-479c1e85f321">
											<gml:posList>35.6690181624475 139.74750260640965 7.4212544185398315 35.669018643994086 139.7475005172264 7.4212544185398315 35.669018643994086 139.7475005172264 9.472493432211706 35.6690181624475 139.74750260640965 9.472493432211706 35.6690181624475 139.74750260640965 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ce80d0a8-5348-4169-b65a-c285992c4e5a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a2f71ab5-a90c-4f8e-90e3-ecfce583436e">
											<gml:posList>35.669018643994086 139.7475005172264 7.4212544185398315 35.66901947898246 139.7474987683037 7.4212544185398315 35.66901947898246 139.7474987683037 9.472493432211706 35.669018643994086 139.7475005172264 9.472493432211706 35.669018643994086 139.7475005172264 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fd92f3aa-d3f3-47ed-9394-f6c87632624e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b77869a0-aeb2-407d-afa4-6eda0b95e062">
											<gml:posList>35.66901947898246 139.7474987683037 7.4212544185398315 35.66902089433843 139.74749695555354 7.4212544185398315 35.66902089433843 139.74749695555354 9.472493432211706 35.66901947898246 139.7474987683037 9.472493432211706 35.66901947898246 139.7474987683037 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2d968f3e-eda6-44ef-95a2-29b23c4c309e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d2e3fbd9-f522-414e-aab2-ba6c91660659">
											<gml:posList>35.66902089433843 139.74749695555354 7.4212544185398315 35.66902328436605 139.7474950519229 7.4212544185398315 35.66902328436605 139.7474950519229 9.472493432211706 35.66902089433843 139.74749695555354 9.472493432211706 35.66902089433843 139.74749695555354 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b9b5aa8f-6a9e-4f41-8420-0f6338166886">
									<gml:exterior>
										<gml:LinearRing gml:id="line_32a38170-e8b4-4a85-acf3-ad81a35c551f">
											<gml:posList>35.66902328436605 139.7474950519229 7.4212544185398315 35.66902303880452 139.74749458884264 7.4212544185398315 35.66902303880452 139.74749458884264 9.472493432211706 35.66902328436605 139.7474950519229 9.472493432211706 35.66902328436605 139.7474950519229 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ec3657fc-d13b-4dcd-896e-b45b930d85e8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ba896867-90ef-438f-8a0b-e7d12daf0155">
											<gml:posList>35.66902303880452 139.74749458884264 7.4212544185398315 35.66902060492698 139.74749652741005 7.4212544185398315 35.66902060492698 139.74749652741005 9.472493432211706 35.66902303880452 139.74749458884264 9.472493432211706 35.66902303880452 139.74749458884264 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_598f606e-dcca-4885-96fd-42ef6450118b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_85f032cb-e66d-4ffe-9604-73b87805cbf7">
											<gml:posList>35.66902060492698 139.74749652741005 7.4212544185398315 35.66901911674191 139.74749843327763 7.4212544185398315 35.66901911674191 139.74749843327763 9.472493432211706 35.66902060492698 139.74749652741005 9.472493432211706 35.66902060492698 139.74749652741005 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ceb7b6d2-0da4-4d5f-94dd-1d4892a84603">
									<gml:exterior>
										<gml:LinearRing gml:id="line_988cbe4d-d7fb-4805-a598-d939c9109d23">
											<gml:posList>35.66901911674191 139.74749843327763 7.4212544185398315 35.66901822599627 139.74750029923348 7.4212544185398315 35.66901822599627 139.74750029923348 9.472493432211706 35.66901911674191 139.74749843327763 9.472493432211706 35.66901911674191 139.74749843327763 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_642132da-808d-4a3d-a78c-8144f6a048ba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_23a8efe3-f585-4edd-b31d-ccce03bc8a95">
											<gml:posList>35.66901822599627 139.74750029923348 7.4212544185398315 35.66901771222747 139.74750252784182 7.4212544185398315 35.66901771222747 139.74750252784182 9.472493432211706 35.66901822599627 139.74750029923348 9.472493432211706 35.66901822599627 139.74750029923348 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3b0c5e38-3f5e-4785-9659-ca9fa451c7d8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9f77ff8a-8ec1-4722-922f-63e26dcfc20f">
											<gml:posList>35.66901771222747 139.74750252784182 7.4212544185398315 35.66901769729681 139.74750492901666 7.4212544185398315 35.66901769729681 139.74750492901666 9.472493432211706 35.66901771222747 139.74750252784182 9.472493432211706 35.66901771222747 139.74750252784182 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6f524a63-edae-4fa2-bdcf-56e47ca6d880">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b427b4cf-8d58-4b34-93df-d3e57b648ed1">
											<gml:posList>35.66901769729681 139.74750492901666 7.4212544185398315 35.66901821045491 139.74750724653123 7.4212544185398315 35.66901821045491 139.74750724653123 9.472493432211706 35.66901769729681 139.74750492901666 9.472493432211706 35.66901769729681 139.74750492901666 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e5340b36-af0e-4102-a5b0-e108c0f9ea34">
									<gml:exterior>
										<gml:LinearRing gml:id="line_440f57e3-1d2e-49f7-8f7a-765e0afede62">
											<gml:posList>35.66901821045491 139.74750724653123 7.4212544185398315 35.669019170246266 139.74750924163789 7.4212544185398315 35.669019170246266 139.74750924163789 9.472493432211706 35.66901821045491 139.74750724653123 9.472493432211706 35.66901821045491 139.74750724653123 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_829c3465-c364-4617-a67d-8aaf462963b1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c9ea51a5-e8c8-4294-bf0d-56b3a2dbdb80">
											<gml:posList>35.669019170246266 139.74750924163789 7.4212544185398315 35.66902041908485 139.7475107680356 7.4212544185398315 35.66902041908485 139.7475107680356 9.472493432211706 35.669019170246266 139.74750924163789 9.472493432211706 35.669019170246266 139.74750924163789 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2e6fc822-8e3d-43a7-9706-55da076aa968">
									<gml:exterior>
										<gml:LinearRing gml:id="line_49bbaceb-29a4-4ab1-b1e0-eedc46fda4a4">
											<gml:posList>35.66902041908485 139.7475107680356 7.4212544185398315 35.66902178626362 139.7475117953996 7.4212544185398315 35.66902178626362 139.7475117953996 9.472493432211706 35.66902041908485 139.7475107680356 9.472493432211706 35.66902041908485 139.7475107680356 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c248622d-bfec-4c38-ac6b-5c1c76f9a314">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ae5fd3af-498b-410a-8aa7-933168e1bb3d">
											<gml:posList>35.66902178626362 139.7475117953996 9.472493432211706 35.669023031834264 139.747512403205 9.472493432211706 35.66902320655805 139.7475118939979 9.472493432211706 35.669021988917464 139.74751129981513 9.472493432211706 35.66902069990251 139.74751033119134 9.472493432211706 35.66901952925392 139.74750890027758 9.472493432211706 35.66901862951852 139.7475070301705 9.472493432211706 35.66901814851022 139.74750485757426 9.472493432211706 35.6690181624475 139.74750260640965 9.472493432211706 35.669018643994086 139.7475005172264 9.472493432211706 35.66901947898246 139.7474987683037 9.472493432211706 35.66902089433843 139.74749695555354 9.472493432211706 35.66902328436605 139.7474950519229 9.472493432211706 35.66902303880452 139.74749458884264 9.472493432211706 35.66902060492698 139.74749652741005 9.472493432211706 35.66901911674191 139.74749843327763 9.472493432211706 35.66901822599627 139.74750029923348 9.472493432211706 35.66901771222747 139.74750252784182 9.472493432211706 35.66901769729681 139.74750492901666 9.472493432211706 35.66901821045491 139.74750724653123 9.472493432211706 35.669019170246266 139.74750924163789 9.472493432211706 35.66902041908485 139.7475107680356 9.472493432211706 35.66902178626362 139.7475117953996 9.472493432211706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_320f3934-1630-4f93-a4d5-b2731e9835cd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8bd37c51-375a-4fe2-8f4b-90a963ed0a17">
											<gml:posList>35.669023031834264 139.747512403205 7.4212544185398315 35.66902178626362 139.7475117953996 7.4212544185398315 35.66902041908485 139.7475107680356 7.4212544185398315 35.669019170246266 139.74750924163789 7.4212544185398315 35.66901821045491 139.74750724653123 7.4212544185398315 35.66901769729681 139.74750492901666 7.4212544185398315 35.66901771222747 139.74750252784182 7.4212544185398315 35.66901822599627 139.74750029923348 7.4212544185398315 35.66901911674191 139.74749843327763 7.4212544185398315 35.66902060492698 139.74749652741005 7.4212544185398315 35.66902303880452 139.74749458884264 7.4212544185398315 35.66902328436605 139.7474950519229 7.4212544185398315 35.66902089433843 139.74749695555354 7.4212544185398315 35.66901947898246 139.7474987683037 7.4212544185398315 35.669018643994086 139.7475005172264 7.4212544185398315 35.6690181624475 139.74750260640965 7.4212544185398315 35.66901814851022 139.74750485757426 7.4212544185398315 35.66901862951852 139.7475070301705 7.4212544185398315 35.66901952925392 139.74750890027758 7.4212544185398315 35.66902069990251 139.74751033119134 7.4212544185398315 35.669021988917464 139.74751129981513 7.4212544185398315 35.66902320655805 139.7475118939979 7.4212544185398315 35.669023031834264 139.747512403205 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_be11d0f6-7c00-4d8a-b011-e944b44951b2">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f63acaa2-2b42-411b-8fbd-03ce2e06278d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_befd36f0-f5dc-4887-9dec-e4c2aab5bbf3">
											<gml:posList>35.66909615277147 139.74743296627636 9.615498803305456 35.669120772027895 139.74744565699146 9.615498803305456 35.669120772027895 139.74744565699146 13.561253808188269 35.66909615277147 139.74743296627636 13.561253808188269 35.66909615277147 139.74743296627636 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0dc06667-6489-41ae-8e1f-8e103dc5e608">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1aeadaed-faf9-4909-8442-17c7fda56766">
											<gml:posList>35.669120772027895 139.74744565699146 9.615498803305456 35.669120018643824 139.74744785198112 9.615498803305456 35.669120018643824 139.74744785198112 13.561253808188269 35.669120772027895 139.74744565699146 13.561253808188269 35.669120772027895 139.74744565699146 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eef5ca63-88d1-442e-ab83-dbc8bc382ed2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_44df9e53-8e32-43c3-9be0-950999c6f22e">
											<gml:posList>35.669120018643824 139.74744785198112 9.615498803305456 35.66912379987138 139.7474498012558 9.615498803305456 35.66912379987138 139.7474498012558 13.561253808188269 35.669120018643824 139.74744785198112 13.561253808188269 35.669120018643824 139.74744785198112 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6af77a0c-ab1b-44de-bdea-f5bddedeacac">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d99688ec-828e-455c-b188-6ae8b309ce7a">
											<gml:posList>35.66912379987138 139.7474498012558 9.615498803305456 35.6691295951225 139.74743291713324 9.615498803305456 35.6691295951225 139.74743291713324 13.561253808188269 35.66912379987138 139.7474498012558 13.561253808188269 35.66912379987138 139.7474498012558 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2ec6aea6-68b4-462c-8c03-ccf423e84ba4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0b6e61c8-8eac-42e5-8936-855307ee8358">
											<gml:posList>35.6691295951225 139.74743291713324 9.615498803305456 35.66912764072369 139.74743179601035 9.615498803305456 35.66912764072369 139.74743179601035 13.561253808188269 35.6691295951225 139.74743291713324 13.561253808188269 35.6691295951225 139.74743291713324 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_13cfa5f1-e829-4e4b-8402-2a4d0078b4c7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e8357ab4-f3be-4d42-a1ec-97ac4d013a42">
											<gml:posList>35.66912764072369 139.74743179601035 9.615498803305456 35.66912528801407 139.74743067649413 9.615498803305456 35.66912528801407 139.74743067649413 13.561253808188269 35.66912764072369 139.74743179601035 13.561253808188269 35.66912764072369 139.74743179601035 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6aaedb4e-9889-46ce-b584-aceaf6a4fd2f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_36bbdbde-e224-4ca3-b02f-3db8f67b9df2">
											<gml:posList>35.66912528801407 139.74743067649413 9.615498803305456 35.669122879053965 139.74742975373596 9.615498803305456 35.669122879053965 139.74742975373596 13.561253808188269 35.66912528801407 139.74743067649413 13.561253808188269 35.66912528801407 139.74743067649413 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5c5921fd-ebde-49f0-94e4-ec3b51bfb319">
									<gml:exterior>
										<gml:LinearRing gml:id="line_344f73f2-460a-46d9-a800-8fd33786a442">
											<gml:posList>35.669122879053965 139.74742975373596 9.615498803305456 35.66912042498687 139.74742903176914 9.615498803305456 35.66912042498687 139.74742903176914 13.561253808188269 35.669122879053965 139.74742975373596 13.561253808188269 35.669122879053965 139.74742975373596 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6423b19c-5320-4505-8ce9-452b2718d193">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5f77f09b-8c42-4aa0-b044-d2eacf2cfa89">
											<gml:posList>35.66912042498687 139.74742903176914 9.615498803305456 35.669117936680884 139.7474285141215 9.615498803305456 35.669117936680884 139.7474285141215 13.561253808188269 35.66912042498687 139.74742903176914 13.561253808188269 35.66912042498687 139.74742903176914 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e946ceca-db10-4381-b047-555a94d00d28">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1e973299-07eb-44af-b8d6-fc85b02dd75d">
											<gml:posList>35.669117936680884 139.7474285141215 9.615498803305456 35.669115425690784 139.74742820297186 9.615498803305456 35.669115425690784 139.74742820297186 13.561253808188269 35.669117936680884 139.7474285141215 13.561253808188269 35.669117936680884 139.7474285141215 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7d5fbf27-0d36-4b64-bd26-3cd11e3a5807">
									<gml:exterior>
										<gml:LinearRing gml:id="line_079cf45a-6348-4af0-986d-581c71fc2b99">
											<gml:posList>35.669115425690784 139.74742820297186 9.615498803305456 35.66911290329583 139.74742809982496 9.615498803305456 35.66911290329583 139.74742809982496 13.561253808188269 35.669115425690784 139.74742820297186 13.561253808188269 35.669115425690784 139.74742820297186 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_601a92a2-2186-40e3-a320-3a130ab7a521">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7caa3cf7-006d-42d9-92ca-77f65908358d">
											<gml:posList>35.66911290329583 139.74742809982496 9.615498803305456 35.66911038091208 139.7474282051743 9.615498803305456 35.66911038091208 139.7474282051743 13.561253808188269 35.66911290329583 139.74742809982496 13.561253808188269 35.66911290329583 139.74742809982496 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e5bdcb17-7129-4c5f-baec-eec169db4b01">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2767ce08-d3b6-4871-904c-0b3adef6ddbc">
											<gml:posList>35.66911038091208 139.7474282051743 9.615498803305456 35.66910786995476 139.74742851833338 9.615498803305456 35.66910786995476 139.74742851833338 13.561253808188269 35.66911038091208 139.7474282051743 13.561253808188269 35.66911038091208 139.7474282051743 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_58af559d-d4b0-44d3-a3a2-84907148a31d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d44ff7b8-4b4d-4765-8ade-3e192e515154">
											<gml:posList>35.66910786995476 139.74742851833338 9.615498803305456 35.66910538197624 139.74742903810997 9.615498803305456 35.66910538197624 139.74742903810997 13.561253808188269 35.66910786995476 139.74742851833338 13.561253808188269 35.66910786995476 139.74742851833338 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d2dfec72-8a1c-4345-ab55-8f953f66c220">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b47ea929-9a84-4f59-a64d-f13ae1dabac7">
											<gml:posList>35.66910538197624 139.74742903810997 9.615498803305456 35.66910292825302 139.74742976213224 9.615498803305456 35.66910292825302 139.74742976213224 13.561253808188269 35.66910538197624 139.74742903810997 13.561253808188269 35.66910538197624 139.74742903810997 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6cae76d8-47e9-423d-a823-cf2ed9a99731">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9dbe2a59-46b8-49d6-93c9-389cb447cfb1">
											<gml:posList>35.66910292825302 139.74742976213224 9.615498803305456 35.669100519923184 139.74743068684876 9.615498803305456 35.669100519923184 139.74743068684876 13.561253808188269 35.66910292825302 139.74742976213224 13.561253808188269 35.66910292825302 139.74742976213224 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c5d28b61-5ac6-4566-ba98-d114c8f73bfe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cacff580-3034-4e56-a4ba-ae3f0c98de75">
											<gml:posList>35.669100519923184 139.74743068684876 9.615498803305456 35.669098167849505 139.74743180837118 9.615498803305456 35.669098167849505 139.74743180837118 13.561253808188269 35.669100519923184 139.74743068684876 13.561253808188269 35.669100519923184 139.74743068684876 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_68cf1e3f-e59f-4788-8920-815ffe733ee7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_26b31f28-0a9b-48a8-a970-c4e016f5f43e">
											<gml:posList>35.669098167849505 139.74743180837118 9.615498803305456 35.66909615277147 139.74743296627636 9.615498803305456 35.66909615277147 139.74743296627636 13.561253808188269 35.669098167849505 139.74743180837118 13.561253808188269 35.669098167849505 139.74743180837118 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a1a845c3-a6c4-4a65-88d4-2e44131e81ce">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e6802bc0-17bb-4954-8ee2-b4dfa805aabf">
											<gml:posList>35.66909615277147 139.74743296627636 13.561253808188269 35.669120772027895 139.74744565699146 13.561253808188269 35.669120018643824 139.74744785198112 13.561253808188269 35.66912379987138 139.7474498012558 13.561253808188269 35.6691295951225 139.74743291713324 13.561253808188269 35.66912764072369 139.74743179601035 13.561253808188269 35.66912528801407 139.74743067649413 13.561253808188269 35.669122879053965 139.74742975373596 13.561253808188269 35.66912042498687 139.74742903176914 13.561253808188269 35.669117936680884 139.7474285141215 13.561253808188269 35.669115425690784 139.74742820297186 13.561253808188269 35.66911290329583 139.74742809982496 13.561253808188269 35.66911038091208 139.7474282051743 13.561253808188269 35.66910786995476 139.74742851833338 13.561253808188269 35.66910538197624 139.74742903810997 13.561253808188269 35.66910292825302 139.74742976213224 13.561253808188269 35.669100519923184 139.74743068684876 13.561253808188269 35.669098167849505 139.74743180837118 13.561253808188269 35.66909615277147 139.74743296627636 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_46a3a05d-6646-478d-9004-5695619f360f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1d1a548d-bd49-42d4-92bb-411b708724e8">
											<gml:posList>35.669120772027895 139.74744565699146 9.615498803305456 35.66909615277147 139.74743296627636 9.615498803305456 35.669098167849505 139.74743180837118 9.615498803305456 35.669100519923184 139.74743068684876 9.615498803305456 35.66910292825302 139.74742976213224 9.615498803305456 35.66910538197624 139.74742903810997 9.615498803305456 35.66910786995476 139.74742851833338 9.615498803305456 35.66911038091208 139.7474282051743 9.615498803305456 35.66911290329583 139.74742809982496 9.615498803305456 35.669115425690784 139.74742820297186 9.615498803305456 35.669117936680884 139.7474285141215 9.615498803305456 35.66912042498687 139.74742903176914 9.615498803305456 35.669122879053965 139.74742975373596 9.615498803305456 35.66912528801407 139.74743067649413 9.615498803305456 35.66912764072369 139.74743179601035 9.615498803305456 35.6691295951225 139.74743291713324 9.615498803305456 35.66912379987138 139.7474498012558 9.615498803305456 35.669120018643824 139.74744785198112 9.615498803305456 35.669120772027895 139.74744565699146 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="gml_b37dc940-7782-4fe1-969f-982a8d4aaabf">
					<bldg:lod3Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9187c9fd-1ac5-4540-9474-7e7204ed09bc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9db161a7-8e38-42c7-965f-bd6d4551cff9">
											<gml:posList>35.66907108264796 139.74745650498915 9.615498803305456 35.669091670952035 139.74743973582585 9.615498803305456 35.669091670952035 139.74743973582585 13.561253808188269 35.66907108264796 139.74745650498915 13.561253808188269 35.66907108264796 139.74745650498915 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6dc00900-2bb1-4362-a404-d3fce509af2d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e6b522b6-dffd-4a12-87c3-d92b6cf7f80b">
											<gml:posList>35.669091670952035 139.74743973582585 9.615498803305456 35.669093248680014 139.74743513929832 9.615498803305456 35.669093248680014 139.74743513929832 13.561253808188269 35.669091670952035 139.74743973582585 13.561253808188269 35.669091670952035 139.74743973582585 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_98731777-dfdc-494f-b13d-c34156b9f5c7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e31a47d8-37df-4b96-945e-9ca0c595edce">
											<gml:posList>35.6690648510531 139.74745786410688 12.175687096762488 35.669093248680014 139.74743513929832 13.561253808188269 35.669066269779876 139.74745672875295 12.067151330160925 35.6690648510531 139.74745786410688 12.175687096762488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f7129166-87b1-4b6a-8ba3-3d7af5b12823">
									<gml:exterior>
										<gml:LinearRing gml:id="line_23938294-f753-4282-b005-20fd61edbc45">
											<gml:posList>35.669093248680014 139.74743513929832 13.561253808188269 35.6690648510531 139.74745786410688 12.175687096762488 35.669063237820126 139.74745915507197 12.213376305746863 35.669093248680014 139.74743513929832 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ecfcacfb-f3f8-4698-8449-79e75ad40108">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6d26e841-8379-47f3-b4fd-47b1cf55f447">
											<gml:posList>35.669066269779876 139.74745672875295 12.067151330160925 35.669093248680014 139.74743513929832 13.561253808188269 35.66906732286263 139.7474558862245 11.900876305746863 35.669066269779876 139.74745672875295 12.067151330160925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_79877f61-f92d-4f06-a2e4-9f3ce559178b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8aa5fc5a-87b8-4a1b-bcb6-7a9d85d1cccf">
											<gml:posList>35.66906732286263 139.7474558862245 11.900876305746863 35.669093248680014 139.74743513929832 13.561253808188269 35.66906788315037 139.7474554377876 11.696904442953894 35.66906732286263 139.7474558862245 11.900876305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_531c078e-6692-4bd1-9d92-9a2927171dcb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_51947e92-fab9-42ac-a86a-577ab7c51a84">
											<gml:posList>35.66906788315037 139.7474554377876 11.696904442953894 35.669093248680014 139.74743513929832 13.561253808188269 35.66906788315037 139.7474554377876 11.479848168539831 35.66906788315037 139.7474554377876 11.696904442953894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_00fae71d-a232-49f5-9563-26e68c12bfb1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6082a629-e1c7-42c5-b1b3-c54690ebc356">
											<gml:posList>35.66906788315037 139.7474554377876 11.479848168539831 35.669093248680014 139.74743513929832 13.561253808188269 35.669093248680014 139.74743513929832 9.615498803305456 35.66906788315037 139.7474554377876 11.479848168539831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2ef9b7c9-3b4e-476e-9f9d-9a2d5d9a44e2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8abd0210-06b4-4015-b7b3-5580872be0c7">
											<gml:posList>35.66906788315037 139.7474554377876 11.479848168539831 35.669093248680014 139.74743513929832 9.615498803305456 35.66906732286263 139.7474558862245 11.275876305746863 35.66906788315037 139.7474554377876 11.479848168539831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bfbace52-3fa9-45b4-bbcb-d097deab5aff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7f5e8a34-34ac-46f1-8f33-dc696c3952ec">
											<gml:posList>35.66906732286263 139.7474558862245 11.275876305746863 35.669093248680014 139.74743513929832 9.615498803305456 35.669066269779876 139.74745672875295 11.1096012813328 35.66906732286263 139.7474558862245 11.275876305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e6dc1fab-43ba-46fb-863f-8bc0389e18b0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_db6a057f-f29d-4908-9f94-c208a05c5000">
											<gml:posList>35.669066269779876 139.74745672875295 11.1096012813328 35.669093248680014 139.74743513929832 9.615498803305456 35.6690648510531 139.74745786410688 11.001065514731238 35.669066269779876 139.74745672875295 11.1096012813328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a5df28bd-fbe7-4af0-8f81-cc989a3f407a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0e124b93-bb83-40f3-b69c-9a108f0093e0">
											<gml:posList>35.6690648510531 139.74745786410688 11.001065514731238 35.669093248680014 139.74743513929832 9.615498803305456 35.669063237820126 139.74745915507197 10.963376305746863 35.6690648510531 139.74745786410688 11.001065514731238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6c101233-c7cf-4860-82be-33d782bc0f7a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cdd1635a-c69f-408a-a0e5-150c4e7f9603">
											<gml:posList>35.669063237820126 139.74745915507197 10.963376305746863 35.669093248680014 139.74743513929832 9.615498803305456 35.66901951914571 139.7474941403918 9.615498803305456 35.669063237820126 139.74745915507197 10.963376305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d10ef6ae-3fd2-4077-ab39-4a13d0b14348">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9c40652a-3509-45b9-9668-cdf1fbdc18f1">
											<gml:posList>35.66901951914571 139.7474941403918 13.561253808188269 35.66906162458723 139.74746044620557 12.175687096762488 35.66906020586031 139.74746158139078 12.067151330160925 35.66901951914571 139.7474941403918 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1e13f22b-21e6-48d2-b628-e0c8d78596b8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7169782d-e45a-4a94-a702-c4d160dfc99d">
											<gml:posList>35.66906162458723 139.74746044620557 12.175687096762488 35.66901951914571 139.7474941403918 13.561253808188269 35.669063237820126 139.74745915507197 12.213376305746863 35.66906162458723 139.74746044620557 12.175687096762488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3c0de459-8c79-400e-ab55-93a19f468f5e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e4ab3ad9-7c9d-4cf8-9d61-1a7631315369">
											<gml:posList>35.669063237820126 139.74745915507197 12.213376305746863 35.66901951914571 139.7474941403918 13.561253808188269 35.669093248680014 139.74743513929832 13.561253808188269 35.669063237820126 139.74745915507197 12.213376305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_60f7ce9d-a3ba-44e0-85f4-9727f99dea90">
									<gml:exterior>
										<gml:LinearRing gml:id="line_332c2179-8eba-4c22-9b18-f018ef0452ac">
											<gml:posList>35.66901951914571 139.7474941403918 13.561253808188269 35.66906020586031 139.74746158139078 12.067151330160925 35.669059152777635 139.74746242408764 11.900876305746863 35.66901951914571 139.7474941403918 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_53d052ed-62e3-48be-bb2e-474c2e15895d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f65d0f64-db38-489d-a13c-bb523128de6b">
											<gml:posList>35.66901951914571 139.7474941403918 13.561253808188269 35.669059152777635 139.74746242408764 11.900876305746863 35.66905859248987 139.74746287252444 11.696904442953894 35.66901951914571 139.7474941403918 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_11df42a9-b8a8-4ac1-92be-66094f889e19">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d658830d-e3b7-421f-b469-21564b0ce132">
											<gml:posList>35.66901951914571 139.7474941403918 13.561253808188269 35.66905859248987 139.74746287252444 11.696904442953894 35.66905859248987 139.74746287252444 11.479848168539831 35.66901951914571 139.7474941403918 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a36ba7f8-abb4-4e41-8205-2fa379428867">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f8052fc8-6fb0-458d-8a45-62c53cbef6fc">
											<gml:posList>35.66901951914571 139.7474941403918 13.561253808188269 35.66905859248987 139.74746287252444 11.479848168539831 35.66901951914571 139.7474941403918 9.615498803305456 35.66901951914571 139.7474941403918 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2ef60c03-dc9b-49c5-b6b3-56847c6349de">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4a1d2c66-f525-460a-ac33-dc96f1ecdc8f">
											<gml:posList>35.66901951914571 139.7474941403918 9.615498803305456 35.66905859248987 139.74746287252444 11.479848168539831 35.669059152777635 139.74746242408764 11.275876305746863 35.66901951914571 139.7474941403918 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c6153389-9493-41ee-be00-843a77e3a351">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3ffe2f02-94c7-4121-a31e-d6008e2d6b2b">
											<gml:posList>35.66901951914571 139.7474941403918 9.615498803305456 35.669059152777635 139.74746242408764 11.275876305746863 35.66906020586031 139.74746158139078 11.1096012813328 35.66901951914571 139.7474941403918 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5b35a264-fce4-4958-b0e4-9e2dbe2d42b4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_52618612-b2c9-46f1-8289-e579ba61dce9">
											<gml:posList>35.66901951914571 139.7474941403918 9.615498803305456 35.66906020586031 139.74746158139078 11.1096012813328 35.66906162458723 139.74746044620557 11.001065514731238 35.66901951914571 139.7474941403918 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_461a9acc-0582-48b8-acf5-44ab54a3f559">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b3687fd8-3cec-4300-92de-0d6d78462091">
											<gml:posList>35.66901951914571 139.7474941403918 9.615498803305456 35.66906162458723 139.74746044620557 11.001065514731238 35.669063237820126 139.74745915507197 10.963376305746863 35.66901951914571 139.7474941403918 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_df018098-6b18-4cf8-a7c3-e50e0df062e1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_15dfb76b-ece9-4714-b71f-f0039d2cf13f">
											<gml:posList>35.66901951914571 139.7474941403918 9.615498803305456 35.66901795563865 139.74749592228744 9.615498803305456 35.66901795563865 139.74749592228744 13.561253808188269 35.66901951914571 139.7474941403918 13.561253808188269 35.66901951914571 139.7474941403918 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_beaff6df-0f19-437c-8c83-387b435025d7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9868a11b-0e96-4094-be5e-b1fce1f78137">
											<gml:posList>35.66901795563865 139.74749592228744 9.615498803305456 35.669016656241475 139.74749833309627 9.615498803305456 35.669016656241475 139.74749833309627 13.561253808188269 35.66901795563865 139.74749592228744 13.561253808188269 35.66901795563865 139.74749592228744 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a07c3665-8226-48c7-b980-92a77e7b2613">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ad3f5a02-e681-49da-943b-542f25f1fe18">
											<gml:posList>35.669016656241475 139.74749833309627 9.615498803305456 35.66901584809851 139.74750127532198 9.615498803305456 35.66901584809851 139.74750127532198 13.561253808188269 35.669016656241475 139.74749833309627 13.561253808188269 35.669016656241475 139.74749833309627 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b1ddca80-6cb3-4528-9bb2-773346e5f548">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3919b8cd-73da-4133-96c8-0fd83e47347f">
											<gml:posList>35.66901584809851 139.74750127532198 9.615498803305456 35.669015714093206 139.7475044957757 9.615498803305456 35.669015714093206 139.7475044957757 13.561253808188269 35.66901584809851 139.74750127532198 13.561253808188269 35.66901584809851 139.74750127532198 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e1aed410-5c59-466f-94d8-44de976ea8ff">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d8380686-2b3a-4fe6-bb17-69c4e696fb99">
											<gml:posList>35.669015714093206 139.7475044957757 9.615498803305456 35.66901630884849 139.74750763673663 9.615498803305456 35.66901630884849 139.74750763673663 13.561253808188269 35.669015714093206 139.7475044957757 13.561253808188269 35.669015714093206 139.7475044957757 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f7e99050-d45e-4a08-88bb-d4ce8d11f3bd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_162208d9-f2d8-4b0c-a743-e8efad7ae7c5">
											<gml:posList>35.66901630884849 139.74750763673663 9.615498803305456 35.66901752704286 139.74751035869002 9.615498803305456 35.66901752704286 139.74751035869002 13.561253808188269 35.66901630884849 139.74750763673663 13.561253808188269 35.66901630884849 139.74750763673663 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e6f5d8cb-46a2-49cb-9adc-5f6cd65305d7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1f2722ad-1551-43f0-9716-8d9bb7226edd">
											<gml:posList>35.66901752704286 139.74751035869002 9.615498803305456 35.66901915259079 139.74751245134857 9.615498803305456 35.66901915259079 139.74751245134857 13.561253808188269 35.66901752704286 139.74751035869002 13.561253808188269 35.66901752704286 139.74751035869002 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3d08e9d0-e7c6-437d-80ca-b07db1068668">
									<gml:exterior>
										<gml:LinearRing gml:id="line_08c70127-4fe6-4074-ab1a-2cdeb548f228">
											<gml:posList>35.66901915259079 139.74751245134857 9.615498803305456 35.66902094779228 139.7475138681099 9.615498803305456 35.66902094779228 139.7475138681099 13.561253808188269 35.66901915259079 139.74751245134857 13.561253808188269 35.66901915259079 139.74751245134857 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d5728a4f-1cf0-48cc-9593-e562c7382be7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b8387f6b-25b8-4d2f-80e7-b34e59e769f6">
											<gml:posList>35.66902094779228 139.7475138681099 9.615498803305456 35.66904296534702 139.74752461150172 9.615498803305456 35.66904296534702 139.74752461150172 13.561253808188269 35.66902094779228 139.7475138681099 13.561253808188269 35.66902094779228 139.7475138681099 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_97762fe4-0b45-4fe3-ab0f-03a98982d437">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1ef9b06a-7cb4-4a37-bd37-8885cf66e18c">
											<gml:posList>35.66904296534702 139.74752461150172 9.615498803305456 35.66904369498759 139.7475224856457 9.615498803305456 35.66904369498759 139.7475224856457 13.561253808188269 35.66904296534702 139.74752461150172 13.561253808188269 35.66904296534702 139.74752461150172 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_877ea63f-f82c-468d-b40a-295fb2d6fb70">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cef5cae8-37b0-4b9d-9ac6-e85b8e81db35">
											<gml:posList>35.66904369498759 139.7475224856457 9.615498803305456 35.66902178626362 139.7475117953996 9.615498803305456 35.66902178626362 139.7475117953996 13.561253808188269 35.66904369498759 139.7475224856457 13.561253808188269 35.66904369498759 139.7475224856457 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1491d889-4f01-407e-8b59-f9147fce8512">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4806cc3f-b9f2-4da2-b237-22e919d8f352">
											<gml:posList>35.66902178626362 139.7475117953996 9.615498803305456 35.66902041908485 139.7475107680356 9.615498803305456 35.66902041908485 139.7475107680356 13.561253808188269 35.66902178626362 139.7475117953996 13.561253808188269 35.66902178626362 139.7475117953996 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8001914f-3b89-405b-af2d-50f95443dced">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d1774e26-a84d-41ec-9c5a-c330212054bd">
											<gml:posList>35.66902041908485 139.7475107680356 9.615498803305456 35.669019170246266 139.74750924163789 9.615498803305456 35.669019170246266 139.74750924163789 13.561253808188269 35.66902041908485 139.7475107680356 13.561253808188269 35.66902041908485 139.7475107680356 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_901267a1-03a7-415b-aad6-5120d5ea2a93">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b639d553-5d3c-46c2-b8d9-6951ea3bcda4">
											<gml:posList>35.669019170246266 139.74750924163789 9.615498803305456 35.66901821045491 139.74750724653123 9.615498803305456 35.66901821045491 139.74750724653123 13.561253808188269 35.669019170246266 139.74750924163789 13.561253808188269 35.669019170246266 139.74750924163789 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b9d8b2a-e976-42ff-8b53-526cd3685c08">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c475dbbc-448e-457f-a524-d725349c7ea9">
											<gml:posList>35.66901821045491 139.74750724653123 9.615498803305456 35.66901769729681 139.74750492901666 9.615498803305456 35.66901769729681 139.74750492901666 13.561253808188269 35.66901821045491 139.74750724653123 13.561253808188269 35.66901821045491 139.74750724653123 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c6882537-3d78-4194-a21b-8ec8f5424069">
									<gml:exterior>
										<gml:LinearRing gml:id="line_731a000a-7478-4a6d-ba0e-808013492039">
											<gml:posList>35.66901769729681 139.74750492901666 9.615498803305456 35.66901771222747 139.74750252784182 9.615498803305456 35.66901771222747 139.74750252784182 13.561253808188269 35.66901769729681 139.74750492901666 13.561253808188269 35.66901769729681 139.74750492901666 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3c80a3fa-fd5f-4bc5-aee4-e63df14b5b48">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1315a67b-968b-41c9-8f56-b2ff495b1687">
											<gml:posList>35.66901771222747 139.74750252784182 9.615498803305456 35.66901822599627 139.74750029923348 9.615498803305456 35.66901822599627 139.74750029923348 13.561253808188269 35.66901771222747 139.74750252784182 13.561253808188269 35.66901771222747 139.74750252784182 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_26d39b6c-7d8c-4ffb-9916-828ddbd95be5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d9605535-9712-4874-84c0-f17f1ab07ac5">
											<gml:posList>35.66901822599627 139.74750029923348 9.615498803305456 35.66901911674191 139.74749843327763 9.615498803305456 35.66901911674191 139.74749843327763 13.561253808188269 35.66901822599627 139.74750029923348 13.561253808188269 35.66901822599627 139.74750029923348 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_878bb3fc-fc26-49a1-a70c-b1afd70eaff6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cf3cc618-9a25-46af-9be2-7cf12e44a958">
											<gml:posList>35.66901911674191 139.74749843327763 9.615498803305456 35.66902022539165 139.747497013408 9.615498803305456 35.66902022539165 139.747497013408 13.561253808188269 35.66901911674191 139.74749843327763 13.561253808188269 35.66901911674191 139.74749843327763 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bc8bed3b-596b-45ba-ad3d-aac2873b54a1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2ad31475-5973-43bd-adac-ef0c23143f56">
											<gml:posList>35.669061547695215 139.74746409960443 12.067151330160925 35.66907108264796 139.74745650498915 13.561253808188269 35.66902022539165 139.747497013408 13.561253808188269 35.669061547695215 139.74746409960443 12.067151330160925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5ae59ff9-4e78-49ad-ae58-0d5ffe335fdd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d09482a7-25b8-4d2f-ab93-ce686fb3038f">
											<gml:posList>35.66907108264796 139.74745650498915 13.561253808188269 35.669061547695215 139.74746409960443 12.067151330160925 35.669062968350346 139.74746296812523 12.175687096762488 35.66907108264796 139.74745650498915 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ec036042-dce6-4c07-94e0-e06d0b0490ca">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a48743f2-5f7b-4785-9268-0c195213dc72">
											<gml:posList>35.669061547695215 139.74746409960443 12.067151330160925 35.66902022539165 139.747497013408 13.561253808188269 35.66906049323521 139.74746493960595 11.900876305746863 35.669061547695215 139.74746409960443 12.067151330160925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3c08d256-6b7f-485e-9beb-740136dbf19b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_027b342b-a5d3-4f4c-ad50-d33319625925">
											<gml:posList>35.66906049323521 139.74746493960595 11.900876305746863 35.66902022539165 139.747497013408 13.561253808188269 35.669059932121115 139.74746538652664 11.696904442953894 35.66906049323521 139.74746493960595 11.900876305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aa5a024b-3299-45d9-ae73-d910e8afb71d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_707ef4c5-352b-4561-a5ef-77463f0b59c3">
											<gml:posList>35.669059932121115 139.74746538652664 11.696904442953894 35.66902022539165 139.747497013408 13.561253808188269 35.66902022539165 139.747497013408 9.615498803305456 35.669059932121115 139.74746538652664 11.696904442953894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f954046e-fc64-4c6e-929b-d19139f98cc5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0bebf8ab-dbdb-4d2f-b645-a16b2270a431">
											<gml:posList>35.669059932121115 139.74746538652664 11.696904442953894 35.66902022539165 139.747497013408 9.615498803305456 35.669059932121115 139.74746538652664 11.479848168539831 35.669059932121115 139.74746538652664 11.696904442953894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_09363c60-986a-4ed9-b660-3609cb24dd89">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8e5b390c-ce95-483e-a7d0-3f9a7a519cbf">
											<gml:posList>35.669059932121115 139.74746538652664 11.479848168539831 35.66902022539165 139.747497013408 9.615498803305456 35.66906049323521 139.74746493960595 11.275876305746863 35.669059932121115 139.74746538652664 11.479848168539831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9ae3824e-19e1-4a44-a5db-22ab82bb44db">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cd3ecf4a-d99b-4fbd-b3ce-8a5129933abb">
											<gml:posList>35.66906049323521 139.74746493960595 11.275876305746863 35.66902022539165 139.747497013408 9.615498803305456 35.669061547695215 139.74746409960443 11.1096012813328 35.66906049323521 139.74746493960595 11.275876305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c4eee3b7-576f-4fde-97de-4ce2b6066d14">
									<gml:exterior>
										<gml:LinearRing gml:id="line_da74c51a-f289-4cdc-a8ea-2daf398075b2">
											<gml:posList>35.669061547695215 139.74746409960443 11.1096012813328 35.66902022539165 139.747497013408 9.615498803305456 35.66907108264796 139.74745650498915 9.615498803305456 35.669061547695215 139.74746409960443 11.1096012813328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8e087e62-167a-41cc-b10c-9091c69d5c4f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7c2c0878-c0dc-4e43-a261-dbafea2324df">
											<gml:posList>35.669061547695215 139.74746409960443 11.1096012813328 35.66907108264796 139.74745650498915 9.615498803305456 35.669062968350346 139.74746296812523 11.001065514731238 35.669061547695215 139.74746409960443 11.1096012813328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_46452a01-1322-40d7-8231-debf95a28c5c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e63f1a9c-0614-4a2e-8a99-ce3f2e7a1372">
											<gml:posList>35.669062968350346 139.74746296812523 11.001065514731238 35.66907108264796 139.74745650498915 9.615498803305456 35.66906458392442 139.7474616812029 10.963376305746863 35.669062968350346 139.74746296812523 11.001065514731238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aa4b1a0c-aa4a-4b87-abd0-7f5afbeafc06">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8c211fcf-732c-4ee6-9737-693b6d05c624">
											<gml:posList>35.66907108264796 139.74745650498915 13.561253808188269 35.669066199498594 139.74746039444906 12.175687096762488 35.66906762015369 139.74745926296976 12.067151330160925 35.66907108264796 139.74745650498915 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3097e78f-011e-4722-8625-3748f0e5945a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6b3e7a2e-bd48-412d-9194-dc269733b607">
											<gml:posList>35.669066199498594 139.74746039444906 12.175687096762488 35.66907108264796 139.74745650498915 13.561253808188269 35.66906458392442 139.7474616812029 12.213376305746863 35.669066199498594 139.74746039444906 12.175687096762488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e029cb34-7254-49c2-bc45-bbf751e9162f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_46e02029-ca20-4d98-92f3-f7a6323a2560">
											<gml:posList>35.66907108264796 139.74745650498915 13.561253808188269 35.66906762015369 139.74745926296976 12.067151330160925 35.669068674613655 139.7474584229681 11.900876305746863 35.66907108264796 139.74745650498915 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2eaadf02-ad57-4aff-8d02-b8f572a4da31">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a27b1da7-d66f-4486-8473-8f2424060ebf">
											<gml:posList>35.66907108264796 139.74745650498915 13.561253808188269 35.669068674613655 139.7474584229681 11.900876305746863 35.66906923572772 139.7474579760473 11.696904442953894 35.66907108264796 139.74745650498915 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5526063e-f69d-47bc-9129-87780bb53d41">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f37a9987-22f5-486a-9620-cd3740097e03">
											<gml:posList>35.66907108264796 139.74745650498915 13.561253808188269 35.66906923572772 139.7474579760473 11.696904442953894 35.66906923572772 139.7474579760473 11.479848168539831 35.66907108264796 139.74745650498915 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cb0c9c94-143d-49d6-9bed-f7162d84d233">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e6775de5-b8d1-4995-9bfd-652f443ea850">
											<gml:posList>35.66906458392442 139.7474616812029 12.213376305746863 35.66907108264796 139.74745650498915 13.561253808188269 35.669062968350346 139.74746296812523 12.175687096762488 35.66906458392442 139.7474616812029 12.213376305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_92b50fd7-deea-47eb-b4aa-1dc7f4aead49">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9af24050-cb3f-4f2d-8d5f-602e96f42e47">
											<gml:posList>35.66907108264796 139.74745650498915 13.561253808188269 35.66906923572772 139.7474579760473 11.479848168539831 35.66907108264796 139.74745650498915 9.615498803305456 35.66907108264796 139.74745650498915 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d70779fd-1143-461f-b9e5-8fc84ad2f761">
									<gml:exterior>
										<gml:LinearRing gml:id="line_20e3587c-b95a-40f1-8b08-bbec4fb1ebf6">
											<gml:posList>35.66907108264796 139.74745650498915 9.615498803305456 35.66906923572772 139.7474579760473 11.479848168539831 35.669068674613655 139.7474584229681 11.275876305746863 35.66907108264796 139.74745650498915 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a02c0f39-fae2-4a14-ac3d-c0edaaef80b4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f76dc6a3-b12e-4caa-8c77-4102fbcc9114">
											<gml:posList>35.66907108264796 139.74745650498915 9.615498803305456 35.669068674613655 139.7474584229681 11.275876305746863 35.66906762015369 139.74745926296976 11.1096012813328 35.66907108264796 139.74745650498915 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b8898e76-61c5-40a6-8ba4-6fb25010f260">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7ce0dc3b-5bb4-4947-a71a-d010ffca05d1">
											<gml:posList>35.66907108264796 139.74745650498915 9.615498803305456 35.66906762015369 139.74745926296976 11.1096012813328 35.669066199498594 139.74746039444906 11.001065514731238 35.66907108264796 139.74745650498915 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c94e9a97-9763-4c03-93b8-b5bbda0db9b5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5a1e55ad-093c-491f-a788-6c946905c3bc">
											<gml:posList>35.66907108264796 139.74745650498915 9.615498803305456 35.669066199498594 139.74746039444906 11.001065514731238 35.66906458392442 139.7474616812029 10.963376305746863 35.66907108264796 139.74745650498915 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4ed160c3-5beb-4492-a399-44aa78dd5418">
									<gml:exterior>
										<gml:LinearRing gml:id="line_71280fbf-969d-47b9-9c71-c16d5428cf22">
											<gml:posList>35.66907108264796 139.74745650498915 13.561253808188269 35.669091670952035 139.74743973582585 13.561253808188269 35.669093248680014 139.74743513929832 13.561253808188269 35.66901951914571 139.7474941403918 13.561253808188269 35.66901795563865 139.74749592228744 13.561253808188269 35.669016656241475 139.74749833309627 13.561253808188269 35.66901584809851 139.74750127532198 13.561253808188269 35.669015714093206 139.7475044957757 13.561253808188269 35.66901630884849 139.74750763673663 13.561253808188269 35.66901752704286 139.74751035869002 13.561253808188269 35.66901915259079 139.74751245134857 13.561253808188269 35.66902094779228 139.7475138681099 13.561253808188269 35.66904296534702 139.74752461150172 13.561253808188269 35.66904369498759 139.7475224856457 13.561253808188269 35.66902178626362 139.7475117953996 13.561253808188269 35.66902041908485 139.7475107680356 13.561253808188269 35.669019170246266 139.74750924163789 13.561253808188269 35.66901821045491 139.74750724653123 13.561253808188269 35.66901769729681 139.74750492901666 13.561253808188269 35.66901771222747 139.74750252784182 13.561253808188269 35.66901822599627 139.74750029923348 13.561253808188269 35.66901911674191 139.74749843327763 13.561253808188269 35.66902022539165 139.747497013408 13.561253808188269 35.66907108264796 139.74745650498915 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_35014703-9d9b-4b19-a1f6-f5f441f7f0a2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_04c50f5b-8128-48cb-81f7-f8fcdebe123e">
											<gml:posList>35.669091670952035 139.74743973582585 9.615498803305456 35.66907108264796 139.74745650498915 9.615498803305456 35.66902022539165 139.747497013408 9.615498803305456 35.66901911674191 139.74749843327763 9.615498803305456 35.66901822599627 139.74750029923348 9.615498803305456 35.66901771222747 139.74750252784182 9.615498803305456 35.66901769729681 139.74750492901666 9.615498803305456 35.66901821045491 139.74750724653123 9.615498803305456 35.669019170246266 139.74750924163789 9.615498803305456 35.66902041908485 139.7475107680356 9.615498803305456 35.66902178626362 139.7475117953996 9.615498803305456 35.66904369498759 139.7475224856457 9.615498803305456 35.66904296534702 139.74752461150172 9.615498803305456 35.66902094779228 139.7475138681099 9.615498803305456 35.66901915259079 139.74751245134857 9.615498803305456 35.66901752704286 139.74751035869002 9.615498803305456 35.66901630884849 139.74750763673663 9.615498803305456 35.669015714093206 139.7475044957757 9.615498803305456 35.66901584809851 139.74750127532198 9.615498803305456 35.669016656241475 139.74749833309627 9.615498803305456 35.66901795563865 139.74749592228744 9.615498803305456 35.66901951914571 139.7474941403918 9.615498803305456 35.669093248680014 139.74743513929832 9.615498803305456 35.669091670952035 139.74743973582585 9.615498803305456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d6efa342-a52c-4b69-b762-23575364c8e4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c658cd88-4125-4ce6-8845-0b8d02bcf200">
											<gml:posList>35.66906458392442 139.7474616812029 12.213376305746863 35.669063237820126 139.74745915507197 12.213376305746863 35.6690648510531 139.74745786410688 12.175687096762488 35.669066199498594 139.74746039444906 12.175687096762488 35.66906458392442 139.7474616812029 12.213376305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_55bebd37-300e-44a2-b43c-18654a198efb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8ed54d10-c214-426e-b061-d29db8598b7d">
											<gml:posList>35.669066199498594 139.74746039444906 12.175687096762488 35.6690648510531 139.74745786410688 12.175687096762488 35.669066269779876 139.74745672875295 12.067151330160925 35.66906762015369 139.74745926296976 12.067151330160925 35.669066199498594 139.74746039444906 12.175687096762488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fecab88a-2621-4c43-a4e1-85fd8bf65a67">
									<gml:exterior>
										<gml:LinearRing gml:id="line_64fe5bcf-8813-4c84-aa62-5c311d72d8af">
											<gml:posList>35.66906762015369 139.74745926296976 12.067151330160925 35.669066269779876 139.74745672875295 12.067151330160925 35.66906732286263 139.7474558862245 11.900876305746863 35.669068674613655 139.7474584229681 11.900876305746863 35.66906762015369 139.74745926296976 12.067151330160925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5b93a68a-06b3-4a3d-88c1-3bdc1af55331">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b432ba26-9f42-4b68-9d98-35566f4edb87">
											<gml:posList>35.669068674613655 139.7474584229681 11.900876305746863 35.66906732286263 139.7474558862245 11.900876305746863 35.66906788315037 139.7474554377876 11.696904442953894 35.66906923572772 139.7474579760473 11.696904442953894 35.669068674613655 139.7474584229681 11.900876305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c278c12e-8d11-476b-8d5b-8806a1ae5dad">
									<gml:exterior>
										<gml:LinearRing gml:id="line_91e4330f-1ccf-43fb-bb84-fc3f65fe42a5">
											<gml:posList>35.66906923572772 139.7474579760473 11.696904442953894 35.66906788315037 139.7474554377876 11.696904442953894 35.66906788315037 139.7474554377876 11.479848168539831 35.66906923572772 139.7474579760473 11.479848168539831 35.66906923572772 139.7474579760473 11.696904442953894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_52f53493-1d55-4db5-bf74-b9f9eadf785f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_32ba1270-9326-4633-b396-4d931c98ef26">
											<gml:posList>35.66906923572772 139.7474579760473 11.479848168539831 35.66906788315037 139.7474554377876 11.479848168539831 35.66906732286263 139.7474558862245 11.275876305746863 35.669068674613655 139.7474584229681 11.275876305746863 35.66906923572772 139.7474579760473 11.479848168539831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_877b0f55-65e9-4f9d-9648-055cde818462">
									<gml:exterior>
										<gml:LinearRing gml:id="line_09298162-c0f4-4b85-b135-e5e9ace9e0c0">
											<gml:posList>35.669068674613655 139.7474584229681 11.275876305746863 35.66906732286263 139.7474558862245 11.275876305746863 35.669066269779876 139.74745672875295 11.1096012813328 35.66906762015369 139.74745926296976 11.1096012813328 35.669068674613655 139.7474584229681 11.275876305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1303fe44-8653-42c0-b2f6-055553bea296">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0cc06d36-f4b0-42dc-b7fa-084381dc063c">
											<gml:posList>35.66906762015369 139.74745926296976 11.1096012813328 35.669066269779876 139.74745672875295 11.1096012813328 35.6690648510531 139.74745786410688 11.001065514731238 35.669066199498594 139.74746039444906 11.001065514731238 35.66906762015369 139.74745926296976 11.1096012813328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_042b1fef-6caf-4139-becc-ff22a36c4d20">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0440ad35-8ec3-49cc-90ee-8290c3bf216f">
											<gml:posList>35.669066199498594 139.74746039444906 11.001065514731238 35.6690648510531 139.74745786410688 11.001065514731238 35.669063237820126 139.74745915507197 10.963376305746863 35.66906458392442 139.7474616812029 10.963376305746863 35.669066199498594 139.74746039444906 11.001065514731238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_99bfa70d-f57b-4bf3-a203-e19b5942e878">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6d14f895-91a4-4ee6-ac46-1bf3fc5aa311">
											<gml:posList>35.66906458392442 139.7474616812029 10.963376305746863 35.669063237820126 139.74745915507197 10.963376305746863 35.66906162458723 139.74746044620557 11.001065514731238 35.669062968350346 139.74746296812523 11.001065514731238 35.66906458392442 139.7474616812029 10.963376305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f7d8d39c-1323-42a1-a0ef-46a5251da14f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d27445eb-d633-4067-a3cc-9ff33aa7a7db">
											<gml:posList>35.669062968350346 139.74746296812523 11.001065514731238 35.66906162458723 139.74746044620557 11.001065514731238 35.66906020586031 139.74746158139078 11.1096012813328 35.669061547695215 139.74746409960443 11.1096012813328 35.669062968350346 139.74746296812523 11.001065514731238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8684e193-0fae-486c-bf4f-4613059be0bc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5c0cf4ae-a82c-445d-9bdd-d42d3e9df895">
											<gml:posList>35.669061547695215 139.74746409960443 11.1096012813328 35.66906020586031 139.74746158139078 11.1096012813328 35.669059152777635 139.74746242408764 11.275876305746863 35.66906049323521 139.74746493960595 11.275876305746863 35.669061547695215 139.74746409960443 11.1096012813328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f709dfa8-0acc-4a2b-b4f1-1e146812f931">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e6fa4f14-59a5-4de6-be5d-1313ab157d5e">
											<gml:posList>35.66906049323521 139.74746493960595 11.275876305746863 35.669059152777635 139.74746242408764 11.275876305746863 35.66905859248987 139.74746287252444 11.479848168539831 35.669059932121115 139.74746538652664 11.479848168539831 35.66906049323521 139.74746493960595 11.275876305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_35ab1555-9120-48e8-b7a6-e2a2a622977d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_33b02be4-a2f1-422d-b946-4ba4317dff56">
											<gml:posList>35.669059932121115 139.74746538652664 11.479848168539831 35.66905859248987 139.74746287252444 11.479848168539831 35.66905859248987 139.74746287252444 11.696904442953894 35.669059932121115 139.74746538652664 11.696904442953894 35.669059932121115 139.74746538652664 11.479848168539831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_53c67464-9af8-4f4e-8865-d37107f588d6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_71589da0-dbcf-4af6-84ee-38a4614de367">
											<gml:posList>35.669059932121115 139.74746538652664 11.696904442953894 35.66905859248987 139.74746287252444 11.696904442953894 35.669059152777635 139.74746242408764 11.900876305746863 35.66906049323521 139.74746493960595 11.900876305746863 35.669059932121115 139.74746538652664 11.696904442953894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3e564912-ef8f-4e3c-8c3a-3d651d09a233">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dd7c7b1e-1f01-4b28-9d09-52273657535e">
											<gml:posList>35.66906049323521 139.74746493960595 11.900876305746863 35.669059152777635 139.74746242408764 11.900876305746863 35.66906020586031 139.74746158139078 12.067151330160925 35.669061547695215 139.74746409960443 12.067151330160925 35.66906049323521 139.74746493960595 11.900876305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7153c0f3-7d1e-43b9-8351-6c0e60f5930e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c787e2c6-bebe-41b5-a8da-b0cb0abd9aa5">
											<gml:posList>35.669061547695215 139.74746409960443 12.067151330160925 35.66906020586031 139.74746158139078 12.067151330160925 35.66906162458723 139.74746044620557 12.175687096762488 35.669062968350346 139.74746296812523 12.175687096762488 35.669061547695215 139.74746409960443 12.067151330160925</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b7a8ce5b-3051-4201-be7c-2a6591017c32">
									<gml:exterior>
										<gml:LinearRing gml:id="line_98041862-017c-42d3-856a-a7fac55b34c7">
											<gml:posList>35.669062968350346 139.74746296812523 12.175687096762488 35.66906162458723 139.74746044620557 12.175687096762488 35.669063237820126 139.74745915507197 12.213376305746863 35.66906458392442 139.7474616812029 12.213376305746863 35.669062968350346 139.74746296812523 12.175687096762488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0157_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_b_0">
											<gml:posList>35.669124221496546 139.74742183839342 5.86301299 35.66913415515379 139.74742654820218 5.86350838 35.669127692287574 139.74744701917763 5.86333795 35.6691231066465 139.74744484500303 5.86310924 35.66909021725711 139.74754040588465 5.86219471 35.66903515042667 139.7475119433627 5.85943676 35.66902396664871 139.7475063518299 5.85887871 35.669020416760084 139.74750195064945 5.85868446 35.66901996873696 139.74749358824414 5.85860894 35.66902596134673 139.74748453657492 5.85882921 35.66903780122015 139.74747443804816 5.85931553 35.66904373599243 139.74747005410273 5.85956386 35.669098665442746 139.74742557599316 5.8618415 35.66910944706077 139.74742313866437 5.86233003 35.669124221496546 139.74742183839342 5.86301299</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gml_21453508-ff7c-45e3-9dec-8451c8867473">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ce216f63-9d19-49b4-b87b-70e2191cd1aa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_79bc55f2-8eb3-4b00-aaf9-3045db737489">
											<gml:posList>35.669087126915194 139.74754367812918 6.9097492915867065 35.66902178626362 139.7475117953996 6.9097492915867065 35.66902041908485 139.7475107680356 6.9097492915867065 35.669019170246266 139.74750924163789 6.9097492915867065 35.66901821045491 139.74750724653123 6.9097492915867065 35.66901769729681 139.74750492901666 6.9097492915867065 35.66901771222747 139.74750252784182 6.9097492915867065 35.66901822599627 139.74750029923348 6.9097492915867065 35.66901911674191 139.74749843327763 6.9097492915867065 35.66902060492698 139.74749652741005 6.9097492915867065 35.6690709244374 139.747456447346 6.9097492915867065 35.6690842670889 139.74746130616822 6.9097492915867065 35.66909268662737 139.74743677685657 6.9097492915867065 35.66909431898195 139.74743202099077 6.9097492915867065 35.669120772027895 139.74744565699146 6.9097492915867065 35.669087126915194 139.74754367812918 6.9097492915867065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_c09c7ebf-fb40-4b4e-a883-702550795e32">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1824ee5a-1d7d-4103-a1d8-9a83a8aac40d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c2eb2c63-f9b9-4b17-b325-1d34be662712">
											<gml:posList>35.66902041908485 139.7475107680356 9.472493432211706 35.669019170246266 139.74750924163789 9.472493432211706 35.66901821045491 139.74750724653123 9.472493432211706 35.66901769729681 139.74750492901666 9.472493432211706 35.66901771222747 139.74750252784182 9.472493432211706 35.66901822599627 139.74750029923348 9.472493432211706 35.66901911674191 139.74749843327763 9.472493432211706 35.66902060492698 139.74749652741005 9.472493432211706 35.66902303880452 139.74749458884264 9.472493432211706 35.66903792607768 139.747501852905 9.472493432211706 35.66903268751735 139.7475171146221 9.472493432211706 35.66902178626362 139.7475117953996 9.472493432211706 35.66902041908485 139.7475107680356 9.472493432211706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_3700b617-9563-4311-a596-a49fb150a457">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a90828bf-8f79-4f45-bec1-be2b0ea70c22">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c22ce719-bee2-4790-8ade-23626a73878a">
											<gml:posList>35.66902178626362 139.7475117953996 11.996846459555456 35.669039391144324 139.74752038557116 11.996846459555456 35.669057730284074 139.7474669565661 11.996846459555456 35.66902060492698 139.74749652741005 11.996846459555456 35.66901911674191 139.74749843327763 11.996846459555456 35.66901822599627 139.74750029923348 11.996846459555456 35.66901771222747 139.74750252784182 11.996846459555456 35.66901769729681 139.74750492901666 11.996846459555456 35.66901821045491 139.74750724653123 11.996846459555456 35.669019170246266 139.74750924163789 11.996846459555456 35.66902041908485 139.7475107680356 11.996846459555456 35.66902178626362 139.7475117953996 11.996846459555456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_0194c17e-ea68-4d48-bef4-87183601ad1a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6661be3e-39a0-449f-8efd-39cb58ff48c5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_19de36af-878a-4e28-b9a1-528b4a62866e">
											<gml:posList>35.6690709244374 139.747456447346 13.561253808188269 35.669057730284074 139.7474669565661 13.561253808188269 35.669039391144324 139.74752038557116 13.561253808188269 35.669087126915194 139.74754367812918 13.561253808188269 35.669120772027895 139.74744565699146 13.561253808188269 35.66909431898195 139.74743202099077 13.561253808188269 35.6690842670889 139.74746130616822 13.561253808188269 35.6690709244374 139.747456447346 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0157_p1033_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_0">
											<gml:posList>35.669134131809834 139.7474265433785 12.00065325 35.66912419816223 139.74742183357426 12.00015786 35.6691094237407 139.747423133844 11.99947491 35.66909864213313 139.74742557117045 11.99898637 35.669043712735785 139.74747004923734 11.99670873 35.66903777796917 139.74747443317855 11.99646041 35.669025938107296 139.74748453169545 11.99597409 35.669019945503194 139.74749358335603 11.99575382 35.669020393525955 139.74750194575327 11.99582934 35.66902394341115 139.74750634692944 11.99602359 35.66903512717828 139.74751193845705 11.99658163 35.6690416987038 139.74751533509456 11.9969104 35.66906021511586 139.74746153529108 11.99742356 35.66907445224489 139.74745161206198 11.99802407 35.66908597095267 139.74745756575268 11.99860081 35.66909618834804 139.74742787884276 11.99888651 35.66912397744709 139.74744224223105 12.00027917 35.66912308331326 139.74744484016176 12.00025411 35.669127668949905 139.74744701433428 12.00048282 35.669134131809834 139.7474265433785 12.00065325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0157_p1032_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1032_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1032_1">
											<gml:posList>35.66912397457652 139.74744224163584 12.7552791 35.66909618548071 139.74742787824914 12.75388645 35.669085968086605 139.74745756515563 12.75360074 35.669074449380176 139.74745161146555 12.753024 35.66906021225285 139.74746153469349 12.75242349 35.66904169584296 139.74751533449066 12.75191033 35.669090191089 139.74754040034455 12.75433952 35.66912397457652 139.74744224163584 12.7552791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_9fe39874-55d0-4ccf-889b-9e067be8df8e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_24d0c05e-36b3-4ad0-9303-3b2d00caf408">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c8f6aa7d-058c-4cda-ba84-c400e5d17e07">
											<gml:posList>35.669039391144324 139.74752038557116 13.561253808188269 35.669039391144324 139.74752038557116 11.996846459555456 35.66902178626362 139.7475117953996 11.996846459555456 35.66902178626362 139.7475117953996 9.472493432211706 35.66903268751735 139.7475171146221 9.472493432211706 35.66903268751735 139.7475171146221 7.4212544185398315 35.66902178626362 139.7475117953996 7.4212544185398315 35.66902178626362 139.7475117953996 6.9097492915867065 35.669087126915194 139.74754367812918 6.9097492915867065 35.669087126915194 139.74754367812918 13.561253808188269 35.669039391144324 139.74752038557116 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_bfbadb81-09d9-4948-a373-3c2a8653c003">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_df287819-236d-4a9d-8c79-db05979de257">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d54f90e7-5f3d-4b54-8504-97c658263e6d">
											<gml:posList>35.66901821045491 139.74750724653123 7.4212544185398315 35.66901769729681 139.74750492901666 7.4212544185398315 35.66901769729681 139.74750492901666 6.9097492915867065 35.66901821045491 139.74750724653123 6.9097492915867065 35.66901821045491 139.74750724653123 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1033_7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_7">
											<gml:posList>35.669020393525955 139.74750194575327 11.99582934 35.669019945503194 139.74749358335603 11.99575382 35.66901996873696 139.74749358824414 5.85860894 35.669020416760084 139.74750195064945 5.85868446 35.669020393525955 139.74750194575327 11.99582934</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1033_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_4">
											<gml:posList>35.669127668949905 139.74744701433428 12.00048282 35.66912308331326 139.74744484016176 12.00025411 35.6691231066465 139.74744484500303 5.86310924 35.669127692287574 139.74744701917763 5.86333795 35.669127668949905 139.74744701433428 12.00048282</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1033_10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_10">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_10">
											<gml:posList>35.66903777796917 139.74747443317855 11.99646041 35.669043712735785 139.74747004923734 11.99670873 35.66904373599243 139.74747005410273 5.85956386 35.66903780122015 139.74747443804816 5.85931553 35.66903777796917 139.74747443317855 11.99646041</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_ebd9cd1c-622b-488f-af0f-5c87a4efe476">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d20a170a-32fb-4d61-a859-5d1d427a9ae7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b86a1ba2-3288-4cb7-bb40-92b1cc4f4474">
											<gml:posList>35.669019170246266 139.74750924163789 7.4212544185398315 35.66901821045491 139.74750724653123 7.4212544185398315 35.66901821045491 139.74750724653123 6.9097492915867065 35.669019170246266 139.74750924163789 6.9097492915867065 35.669019170246266 139.74750924163789 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1033_5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_5">
											<gml:posList>35.66903512717828 139.74751193845705 11.99658163 35.66902394341115 139.74750634692944 11.99602359 35.66902396664871 139.7475063518299 5.85887871 35.66903515042667 139.7475119433627 5.85943676 35.66903512717828 139.74751193845705 11.99658163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1033_12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_12">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_12">
											<gml:posList>35.66909864213313 139.74742557117045 11.99898637 35.6691094237407 139.747423133844 11.99947491 35.66910944706077 139.74742313866437 5.86233003 35.669098665442746 139.74742557599316 5.8618415 35.66909864213313 139.74742557117045 11.99898637</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a6219512-980c-4a72-a5fa-2e8efdda93f5">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0a40b385-6ef7-4f7c-8f84-2fe6e639f569">
									<gml:exterior>
										<gml:LinearRing gml:id="line_de93c533-587d-451f-b1e3-5f02e23a14eb">
											<gml:posList>35.669039391144324 139.74752038557116 13.561253808188269 35.669057730284074 139.7474669565661 13.561253808188269 35.669057730284074 139.7474669565661 11.996846459555456 35.669039391144324 139.74752038557116 11.996846459555456 35.669039391144324 139.74752038557116 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1032_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1032_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1032_3">
											<gml:posList>35.66906021225285 139.74746153469349 12.75242349 35.66906021511586 139.74746153529108 11.99742356 35.6690416987038 139.74751533509456 11.9969104 35.66904169584296 139.74751533449066 12.75191033 35.66906021225285 139.74746153469349 12.75242349</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_5806177b-31b2-4ec1-ab60-2acabe67880e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59db29de-a73c-43f6-9709-4d083c91227c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6012e225-3887-44ba-b33b-6f5a77d1181c">
											<gml:posList>35.66901822599627 139.74750029923348 7.4212544185398315 35.66901911674191 139.74749843327763 7.4212544185398315 35.66901911674191 139.74749843327763 6.9097492915867065 35.66901822599627 139.74750029923348 6.9097492915867065 35.66901822599627 139.74750029923348 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1da53c46-76d1-4bea-a765-4276da73af29">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a75f606f-9897-4b12-8379-27f74fe78478">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b06d2054-0d74-4ef0-ae0e-0e4cb96c7237">
											<gml:posList>35.66906451533815 139.7474615521672 12.213376305746863 35.66906613091233 139.7474602654134 12.175687096762488 35.66906755156729 139.74745913376552 12.067151330160925 35.66906860602726 139.74745829376386 11.900876305746863 35.66906916714144 139.7474578470116 11.696904442953894 35.66906916714144 139.7474578470116 11.479848168539831 35.66906860602726 139.74745829376386 11.275876305746863 35.66906755156729 139.74745913376552 11.1096012813328 35.66906613091233 139.7474602654134 11.001065514731238 35.66906451533815 139.7474615521672 10.963376305746863 35.6690628999015 139.74746283892085 11.001065514731238 35.66906147910896 139.74746397056873 11.1096012813328 35.669060424648826 139.7474648104017 11.275876305746863 35.66905986367228 139.7474652573223 11.479848168539831 35.66905986367228 139.7474652573223 11.696904442953894 35.669060424648826 139.7474648104017 11.900876305746863 35.66906147910896 139.74746397056873 12.067151330160925 35.6690628999015 139.74746283892085 12.175687096762488 35.66906451533815 139.7474615521672 12.213376305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_05771913-8a90-489e-ac14-2f52e5958179">
									<gml:exterior>
										<gml:LinearRing gml:id="line_103fd5d2-efd8-4712-a399-681a0a0147af">
											<gml:posList>35.6690709244374 139.747456447346 13.561253808188269 35.66906916714144 139.7474578470116 11.696904442953894 35.66906860602726 139.74745829376386 11.900876305746863 35.6690709244374 139.747456447346 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1cf45e12-5ffc-48e3-9f7f-4cdfcd08c811">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e4d27c9c-83d4-4046-b2ed-342b23b1bac9">
											<gml:posList>35.66906916714144 139.7474578470116 11.696904442953894 35.6690709244374 139.747456447346 13.561253808188269 35.66906916714144 139.7474578470116 11.479848168539831 35.66906916714144 139.7474578470116 11.696904442953894</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d1f8676c-fab5-4351-a90d-d8c49c00a70f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2787d5b6-d7b8-4d8e-ad2f-c9fbc4e01b5f">
											<gml:posList>35.6690709244374 139.747456447346 13.561253808188269 35.66906860602726 139.74745829376386 11.900876305746863 35.66906755156729 139.74745913376552 12.067151330160925 35.6690709244374 139.747456447346 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_94ba32e8-fd3f-4451-acda-5673fd48f408">
									<gml:exterior>
										<gml:LinearRing gml:id="line_92fd3b6b-b717-46b7-98e7-424667b82711">
											<gml:posList>35.6690709244374 139.747456447346 13.561253808188269 35.66906755156729 139.74745913376552 12.067151330160925 35.66906613091233 139.7474602654134 12.175687096762488 35.6690709244374 139.747456447346 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b89d35f3-bb7b-4173-aa56-2b302de69b60">
									<gml:exterior>
										<gml:LinearRing gml:id="line_17a20508-5d21-49f2-ab7e-f6355ff6dc81">
											<gml:posList>35.66906916714144 139.7474578470116 11.479848168539831 35.6690709244374 139.747456447346 13.561253808188269 35.6690709244374 139.747456447346 6.9097492915867065 35.66906916714144 139.7474578470116 11.479848168539831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0712ce06-ff13-42e1-9dfa-426684c6bd11">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6c767480-9484-4874-8c0e-f22bb5821c8b">
											<gml:posList>35.6690709244374 139.747456447346 13.561253808188269 35.66906613091233 139.7474602654134 12.175687096762488 35.66906451533815 139.7474615521672 12.213376305746863 35.6690709244374 139.747456447346 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a024198d-9dd7-4730-98ac-8ce99ddf118c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e24d07ec-c273-425c-91bc-87a3f87f8f0d">
											<gml:posList>35.6690709244374 139.747456447346 13.561253808188269 35.66906451533815 139.7474615521672 12.213376305746863 35.669057730284074 139.7474669565661 13.561253808188269 35.6690709244374 139.747456447346 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7db03b8f-ff1b-49e3-a73e-f739763a9056">
									<gml:exterior>
										<gml:LinearRing gml:id="line_76f9f19d-0543-4b46-8a06-830734d7a567">
											<gml:posList>35.669057730284074 139.7474669565661 13.561253808188269 35.66906451533815 139.7474615521672 12.213376305746863 35.6690628999015 139.74746283892085 12.175687096762488 35.669057730284074 139.7474669565661 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_aecf6f6b-3c50-4fa4-a93c-90eb452de90d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_98b03013-9a68-489a-a850-db518151931a">
											<gml:posList>35.669057730284074 139.7474669565661 13.561253808188269 35.6690628999015 139.74746283892085 12.175687096762488 35.66906147910896 139.74746397056873 12.067151330160925 35.669057730284074 139.7474669565661 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_38a902af-1e3b-4591-9b29-0b21c78fa844">
									<gml:exterior>
										<gml:LinearRing gml:id="line_10c042ef-d4cb-4e1a-ae8e-fc9a002f2b79">
											<gml:posList>35.669057730284074 139.7474669565661 13.561253808188269 35.66906147910896 139.74746397056873 12.067151330160925 35.669057730284074 139.7474669565661 11.996846459555456 35.669057730284074 139.7474669565661 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f71dbfc3-69bf-47a9-b2ec-6bff9c8e5129">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4bb1cf0f-2261-4380-9b79-5b434c1dcbdb">
											<gml:posList>35.669057730284074 139.7474669565661 11.996846459555456 35.66906147910896 139.74746397056873 12.067151330160925 35.669060424648826 139.7474648104017 11.900876305746863 35.669057730284074 139.7474669565661 11.996846459555456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2a76cfeb-92e7-4ec6-a989-b657fb6f2ed6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6158337a-4b4e-42e6-9c3e-d49b23b64eb9">
											<gml:posList>35.669057730284074 139.7474669565661 11.996846459555456 35.669060424648826 139.7474648104017 11.900876305746863 35.66905986367228 139.7474652573223 11.696904442953894 35.669057730284074 139.7474669565661 11.996846459555456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b5b9604-492d-4d5e-8af3-0e82840322cd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f7e79b17-bea9-406a-ad9d-027cae637f30">
											<gml:posList>35.66906860602726 139.74745829376386 11.275876305746863 35.6690709244374 139.747456447346 6.9097492915867065 35.66906755156729 139.74745913376552 11.1096012813328 35.66906860602726 139.74745829376386 11.275876305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dbb5353e-a843-4379-93c7-932bcdb139f3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a99cf46a-a321-4bd1-abf4-5cd3e402535f">
											<gml:posList>35.6690709244374 139.747456447346 6.9097492915867065 35.66906860602726 139.74745829376386 11.275876305746863 35.66906916714144 139.7474578470116 11.479848168539831 35.6690709244374 139.747456447346 6.9097492915867065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0357158c-a0b9-4c0f-b4b1-38305d0f8f08">
									<gml:exterior>
										<gml:LinearRing gml:id="line_27548a8d-e6b1-4114-ac3d-243dab6acca8">
											<gml:posList>35.66906755156729 139.74745913376552 11.1096012813328 35.6690709244374 139.747456447346 6.9097492915867065 35.66906613091233 139.7474602654134 11.001065514731238 35.66906755156729 139.74745913376552 11.1096012813328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_54d438d6-7f2b-47bb-b1e8-501dccbc8be7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e30b067b-aba9-4a11-b822-4dbd2e5b95e0">
											<gml:posList>35.66906613091233 139.7474602654134 11.001065514731238 35.6690709244374 139.747456447346 6.9097492915867065 35.66906451533815 139.7474615521672 10.963376305746863 35.66906613091233 139.7474602654134 11.001065514731238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e71bff87-cac5-4c1e-90f9-a8090ec59758">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5f282f4f-c3e0-4d9e-973e-bd2aa807f17c">
											<gml:posList>35.66906451533815 139.7474615521672 10.963376305746863 35.6690709244374 139.747456447346 6.9097492915867065 35.6690628999015 139.74746283892085 11.001065514731238 35.66906451533815 139.7474615521672 10.963376305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bbf5f22a-774f-4d8f-88f9-bb66ec8b9079">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0f3acf0a-d485-46df-a561-d4bbc15e3914">
											<gml:posList>35.66902303880452 139.74749458884264 7.4212544185398315 35.6690709244374 139.747456447346 6.9097492915867065 35.66902060492698 139.74749652741005 6.9097492915867065 35.66902303880452 139.74749458884264 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8662ac39-0fd6-4adc-a367-b0ce2c7973db">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cfc6e4af-5666-4d05-ac27-0c9fb38b4de4">
											<gml:posList>35.6690709244374 139.747456447346 6.9097492915867065 35.66902303880452 139.74749458884264 7.4212544185398315 35.66906147910896 139.74746397056873 11.1096012813328 35.6690709244374 139.747456447346 6.9097492915867065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a8b67d97-23ca-4b68-ada5-ae0650b14a69">
									<gml:exterior>
										<gml:LinearRing gml:id="line_87be74d3-3cce-4492-a3b9-93d84213af3a">
											<gml:posList>35.6690628999015 139.74746283892085 11.001065514731238 35.6690709244374 139.747456447346 6.9097492915867065 35.66906147910896 139.74746397056873 11.1096012813328 35.6690628999015 139.74746283892085 11.001065514731238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2f38c2d2-45c9-422a-9298-69b387340b7d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f9fa6cf5-cc1e-4c8f-850c-a0d0fd582926">
											<gml:posList>35.66906147910896 139.74746397056873 11.1096012813328 35.66902303880452 139.74749458884264 7.4212544185398315 35.66902303880452 139.74749458884264 9.472493432211706 35.66906147910896 139.74746397056873 11.1096012813328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a3f74002-def6-4b79-85b3-db5cca7f53a0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_dab49e39-a77f-475c-a7b8-8eb9ac2620bd">
											<gml:posList>35.66906147910896 139.74746397056873 11.1096012813328 35.66902303880452 139.74749458884264 9.472493432211706 35.669060424648826 139.7474648104017 11.275876305746863 35.66906147910896 139.74746397056873 11.1096012813328</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ebabcb63-ee7e-46d3-986b-4dc6e5457986">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fb78de3e-ba86-4e8e-ad9b-33e33089e114">
											<gml:posList>35.66905986367228 139.7474652573223 11.479848168539831 35.669057730284074 139.7474669565661 11.996846459555456 35.66905986367228 139.7474652573223 11.696904442953894 35.66905986367228 139.7474652573223 11.479848168539831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_26e7fa69-233b-437e-b8e2-6c9a44e52333">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2599b20c-ad89-4bb7-947f-94d19bdb07e8">
											<gml:posList>35.669057730284074 139.7474669565661 11.996846459555456 35.66905986367228 139.7474652573223 11.479848168539831 35.66902303880452 139.74749458884264 9.472493432211706 35.669057730284074 139.7474669565661 11.996846459555456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6ddca088-cf1b-4d25-b14e-37a06794d728">
									<gml:exterior>
										<gml:LinearRing gml:id="line_025b7878-6b6f-4ce1-9da8-aa37cba4200d">
											<gml:posList>35.669060424648826 139.7474648104017 11.275876305746863 35.66902303880452 139.74749458884264 9.472493432211706 35.66905986367228 139.7474652573223 11.479848168539831 35.669060424648826 139.7474648104017 11.275876305746863</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7d31a3ae-133b-4a9c-8578-67369043e967">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b3d0de88-60b8-4583-a07b-fe4b15805e63">
											<gml:posList>35.66902303880452 139.74749458884264 7.4212544185398315 35.66902060492698 139.74749652741005 6.9097492915867065 35.66902060492698 139.74749652741005 7.4212544185398315 35.66902303880452 139.74749458884264 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_08c5f7e7-d769-46fa-aea3-df648977baad">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2e6865a6-6747-4372-8ec8-888b8310ad89">
											<gml:posList>35.669057730284074 139.7474669565661 11.996846459555456 35.66902303880452 139.74749458884264 9.472493432211706 35.66902060492698 139.74749652741005 11.996846459555456 35.669057730284074 139.7474669565661 11.996846459555456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_efe261d3-dfd2-4363-85ae-49b788dfcb20">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9dec4ea6-c6af-46ed-bc47-b6e8d5160027">
											<gml:posList>35.66902060492698 139.74749652741005 11.996846459555456 35.66902303880452 139.74749458884264 9.472493432211706 35.66902060492698 139.74749652741005 9.472493432211706 35.66902060492698 139.74749652741005 11.996846459555456</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1033_9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_9">
											<gml:posList>35.669025938107296 139.74748453169545 11.99597409 35.66903777796917 139.74747443317855 11.99646041 35.66903780122015 139.74747443804816 5.85931553 35.66902596134673 139.74748453657492 5.85882921 35.669025938107296 139.74748453169545 11.99597409</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_3f4f34ca-fa24-49f6-a734-3aad930500ba">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8479262b-94fa-40a9-8e73-2c4d32c14b5f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c297c2ae-7629-40de-8000-3610d1a8a709">
											<gml:posList>35.669019170246266 139.74750924163789 9.472493432211706 35.669019170246266 139.74750924163789 11.996846459555456 35.66901821045491 139.74750724653123 11.996846459555456 35.66901821045491 139.74750724653123 9.472493432211706 35.669019170246266 139.74750924163789 9.472493432211706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f69129c6-4c5b-4e4c-bfe9-b2ca0a080d16">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1b633b33-a6a5-4d15-895c-4d1b0379e8cf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_545e9cec-08bc-4fdc-b7d4-d1e7858d5d9b">
											<gml:posList>35.66902178626362 139.7475117953996 9.472493432211706 35.66902178626362 139.7475117953996 11.996846459555456 35.66902041908485 139.7475107680356 11.996846459555456 35.66902041908485 139.7475107680356 9.472493432211706 35.66902178626362 139.7475117953996 9.472493432211706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_ad6287d7-fa86-4182-887a-46cc856baa85">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_43a7460b-def0-4261-8583-24af0b4ff54f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_212f6e01-353f-42ed-9ec9-c6f620690340">
											<gml:posList>35.66902303880452 139.74749458884264 9.472493432211706 35.66902303880452 139.74749458884264 7.4212544185398315 35.66903792607768 139.747501852905 7.4212544185398315 35.66903792607768 139.747501852905 9.472493432211706 35.66902303880452 139.74749458884264 9.472493432211706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_8997cd80-fee4-48e4-9942-fdfa4ad8d890">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2d679781-04c9-4b3f-aa3d-22498ae0c04f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_668c3ea8-5af6-42ae-b2f7-6d2a9437c85f">
											<gml:posList>35.66901911674191 139.74749843327763 9.472493432211706 35.66901911674191 139.74749843327763 11.996846459555456 35.66902060492698 139.74749652741005 11.996846459555456 35.66902060492698 139.74749652741005 9.472493432211706 35.66901911674191 139.74749843327763 9.472493432211706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1033_11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_11">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_11">
											<gml:posList>35.669043712735785 139.74747004923734 11.99670873 35.66909864213313 139.74742557117045 11.99898637 35.669098665442746 139.74742557599316 5.8618415 35.66904373599243 139.74747005410273 5.85956386 35.669043712735785 139.74747004923734 11.99670873</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_475c38a9-c218-416c-8e96-b2d873fc660f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0ef6cf62-bb61-48b2-b0a0-6755bfd94c33">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f193697d-9e0a-48bd-ab52-79ec7eef56f7">
											<gml:posList>35.66901911674191 139.74749843327763 7.4212544185398315 35.66902060492698 139.74749652741005 7.4212544185398315 35.66902060492698 139.74749652741005 6.9097492915867065 35.66901911674191 139.74749843327763 6.9097492915867065 35.66901911674191 139.74749843327763 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e3dc8e5a-ddb6-4647-a6ff-ed83d8d0ce66">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e54473a7-8b5a-4be2-aa3e-f219f980caba">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a2a195a5-7c1f-47da-8250-453ce5258e07">
											<gml:posList>35.66903792607768 139.747501852905 7.4212544185398315 35.66903268751735 139.7475171146221 7.4212544185398315 35.66903268751735 139.7475171146221 9.472493432211706 35.66903792607768 139.747501852905 9.472493432211706 35.66903792607768 139.747501852905 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1032_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1032_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1032_2">
											<gml:posList>35.6691231066465 139.74744484500303 5.86310924 35.66912308331326 139.74744484016176 12.00025411 35.66912397744709 139.74744224223105 12.00027917 35.66912397457652 139.74744224163584 12.7552791 35.669090191089 139.74754040034455 12.75433952 35.66909021725711 139.74754040588465 5.86219471 35.6691231066465 139.74744484500303 5.86310924</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c578634e-d404-457c-bdda-15f40df6725a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b5d5c196-e047-45fa-813e-ea9f257f025f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1c3966f7-84ca-456c-962d-6015c61673c5">
											<gml:posList>35.66901822599627 139.74750029923348 9.472493432211706 35.66901822599627 139.74750029923348 11.996846459555456 35.66901911674191 139.74749843327763 11.996846459555456 35.66901911674191 139.74749843327763 9.472493432211706 35.66901822599627 139.74750029923348 9.472493432211706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e9641775-3c8e-448c-956e-fd37ea99a9cf">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1fc96e79-9977-4591-99a0-b24eb6e68978">
									<gml:exterior>
										<gml:LinearRing gml:id="line_78ebdfd0-6871-41d3-9b92-0225041053f8">
											<gml:posList>35.66909268662737 139.74743677685657 9.370930932211706 35.6690842670889 139.74746130616822 9.370930932211706 35.6690842670889 139.74746130616822 13.561253808188269 35.66909431898195 139.74743202099077 13.561253808188269 35.66909431898195 139.74743202099077 6.9097492915867065 35.66909268662737 139.74743677685657 6.9097492915867065 35.66909268662737 139.74743677685657 9.370930932211706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1032_5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1032_5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1032_5">
											<gml:posList>35.669085968086605 139.74745756515563 12.75360074 35.66908597095267 139.74745756575268 11.99860081 35.66907445224489 139.74745161206198 11.99802407 35.669074449380176 139.74745161146555 12.753024 35.669085968086605 139.74745756515563 12.75360074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1033_8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_8">
											<gml:posList>35.669019945503194 139.74749358335603 11.99575382 35.669025938107296 139.74748453169545 11.99597409 35.66902596134673 139.74748453657492 5.85882921 35.66901996873696 139.74749358824414 5.85860894 35.669019945503194 139.74749358335603 11.99575382</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1032_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1032_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1032_4">
											<gml:posList>35.669074449380176 139.74745161146555 12.753024 35.66907445224489 139.74745161206198 11.99802407 35.66906021511586 139.74746153529108 11.99742356 35.66906021225285 139.74746153469349 12.75242349 35.669074449380176 139.74745161146555 12.753024</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1033_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_3">
											<gml:posList>35.669134131809834 139.7474265433785 12.00065325 35.669127668949905 139.74744701433428 12.00048282 35.669127692287574 139.74744701917763 5.86333795 35.66913415515379 139.74742654820218 5.86350838 35.669134131809834 139.7474265433785 12.00065325</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_611198c1-ff05-4118-a82c-408c2352d5e8">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a4e9989e-d3b8-4780-a2cb-630bcfaa71df">
									<gml:exterior>
										<gml:LinearRing gml:id="line_81d8f004-e3a1-4d6e-a70b-286aabdd7805">
											<gml:posList>35.669087126915194 139.74754367812918 6.9097492915867065 35.669120772027895 139.74744565699146 6.9097492915867065 35.669120772027895 139.74744565699146 13.561253808188269 35.669087126915194 139.74754367812918 13.561253808188269 35.669087126915194 139.74754367812918 6.9097492915867065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_1913cc50-bf71-4019-8511-52bbbfbe94ea">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0811377d-5aa0-4479-abc6-f7c9cd18aedd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_47ad835e-6317-4d13-9888-8dc3b211f6b2">
											<gml:posList>35.66902041908485 139.7475107680356 9.472493432211706 35.66902041908485 139.7475107680356 11.996846459555456 35.669019170246266 139.74750924163789 11.996846459555456 35.669019170246266 139.74750924163789 9.472493432211706 35.66902041908485 139.7475107680356 9.472493432211706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1033_6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_6">
											<gml:posList>35.66902394341115 139.74750634692944 11.99602359 35.669020393525955 139.74750194575327 11.99582934 35.669020416760084 139.74750195064945 5.85868446 35.66902396664871 139.7475063518299 5.85887871 35.66902394341115 139.74750634692944 11.99602359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_270380eb-4fde-4697-821d-46f9d04408ff">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_deef78cf-4c9f-40cf-8428-472af47a24c9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_139b1446-4be9-49ac-8858-894ed170b5b8">
											<gml:posList>35.66901821045491 139.74750724653123 9.472493432211706 35.66901821045491 139.74750724653123 11.996846459555456 35.66901769729681 139.74750492901666 11.996846459555456 35.66901769729681 139.74750492901666 9.472493432211706 35.66901821045491 139.74750724653123 9.472493432211706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_57d03566-34c3-4343-85d4-7a63780e2a2d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0c65e4e8-e923-48ef-bdf6-8caa97be7fa6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_385de13c-9c10-4b7f-b563-34479863b937">
											<gml:posList>35.66901769729681 139.74750492901666 9.472493432211706 35.66901769729681 139.74750492901666 11.996846459555456 35.66901771222747 139.74750252784182 11.996846459555456 35.66901771222747 139.74750252784182 9.472493432211706 35.66901769729681 139.74750492901666 9.472493432211706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_4c907b05-d6f5-4964-b2cc-10d52baede9a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_296412d9-8979-4435-879d-042a65015b78">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f55bde41-505c-4b9b-83b2-6c2cbe696a62">
											<gml:posList>35.66902041908485 139.7475107680356 7.4212544185398315 35.669019170246266 139.74750924163789 7.4212544185398315 35.669019170246266 139.74750924163789 6.9097492915867065 35.66902041908485 139.7475107680356 6.9097492915867065 35.66902041908485 139.7475107680356 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1033_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_2">
											<gml:posList>35.66912419816223 139.74742183357426 12.00015786 35.669134131809834 139.7474265433785 12.00065325 35.66913415515379 139.74742654820218 5.86350838 35.669124221496546 139.74742183839342 5.86301299 35.66912419816223 139.74742183357426 12.00015786</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2b2e3995-b2ca-4839-baf9-1f386ceb3f79">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ee955808-8000-4c1a-b587-8fc1640f83ca">
									<gml:exterior>
										<gml:LinearRing gml:id="line_13de19a5-577a-48ee-b5e3-335ec805ac4b">
											<gml:posList>35.66902178626362 139.7475117953996 7.4212544185398315 35.66902041908485 139.7475107680356 7.4212544185398315 35.66902041908485 139.7475107680356 6.9097492915867065 35.66902178626362 139.7475117953996 6.9097492915867065 35.66902178626362 139.7475117953996 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1032_6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1032_6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1032_6">
											<gml:posList>35.66909618548071 139.74742787824914 12.75388645 35.66909618834804 139.74742787884276 11.99888651 35.66908597095267 139.74745756575268 11.99860081 35.669085968086605 139.74745756515563 12.75360074 35.66909618548071 139.74742787824914 12.75388645</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_09053c6e-97d6-4652-b1af-da295a62328c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_563526a5-804f-4c51-a4ac-2ce58ef07157">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ed8a6534-d390-42ac-adbb-88f21f638499">
											<gml:posList>35.66901771222747 139.74750252784182 7.4212544185398315 35.66901822599627 139.74750029923348 7.4212544185398315 35.66901822599627 139.74750029923348 6.9097492915867065 35.66901771222747 139.74750252784182 6.9097492915867065 35.66901771222747 139.74750252784182 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_26c1efe5-b369-473a-b6ae-473d93e68f38">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_acd776e3-1a66-4826-b5ed-1f7096d09f92">
									<gml:exterior>
										<gml:LinearRing gml:id="line_64b2dd48-6add-4257-a4c7-ac190887a544">
											<gml:posList>35.6690842670889 139.74746130616822 6.9097492915867065 35.6690709244374 139.747456447346 6.9097492915867065 35.6690709244374 139.747456447346 13.561253808188269 35.6690842670889 139.74746130616822 13.561253808188269 35.6690842670889 139.74746130616822 9.370930932211706 35.6690842670889 139.74746130616822 6.9097492915867065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_79e3f950-7c48-474f-b1c1-f0eb0c6bd389">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e3e3da64-c479-448e-af3a-4e743fee7489">
											<gml:exterior>
												<gml:LinearRing gml:id="line_aa2c2880-a11c-48e1-b36f-2385a3f47353">
													<gml:posList>35.6690842670889 139.74746130616822 6.9097492915867065 35.6690842670889 139.74746130616822 9.370930932211706 35.66909268662737 139.74743677685657 9.370930932211706 35.66909268662737 139.74743677685657 6.9097492915867065 35.6690842670889 139.74746130616822 6.9097492915867065</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1032_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1032_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1032_0">
											<gml:posList>35.66904169584296 139.74751533449066 12.75191033 35.6690416987038 139.74751533509456 11.9969104 35.66903512717828 139.74751193845705 11.99658163 35.66903515042667 139.7475119433627 5.85943676 35.66909021725711 139.74754040588465 5.86219471 35.669090191089 139.74754040034455 12.75433952 35.66904169584296 139.74751533449066 12.75191033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_10c09d96-f623-4bf0-b15b-fcbd1ffccb37">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_927d53a5-cd80-4d20-b238-f0f9df183913">
									<gml:exterior>
										<gml:LinearRing gml:id="line_e9185236-f607-4247-9dd5-cc618c6ae512">
											<gml:posList>35.66911191623389 139.7474410920336 9.619527123617956 35.669120772027895 139.74744565699146 13.561253808188269 35.669120772027895 139.74744565699146 6.9097492915867065 35.66911191623389 139.7474410920336 9.619527123617956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_670e7bd6-1627-4976-8451-9f1977c97d07">
									<gml:exterior>
										<gml:LinearRing gml:id="line_405a79b9-5ab5-46f9-9efd-8598d94d0461">
											<gml:posList>35.669120772027895 139.74744565699146 13.561253808188269 35.66911191623389 139.7474410920336 9.619527123617956 35.66909431898195 139.74743202099077 13.561253808188269 35.669120772027895 139.74744565699146 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e8898089-a630-4576-97dd-2125fd4187c5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ac201c2c-c3fd-4cb5-92dd-c1f7e590ef59">
											<gml:posList>35.66911191623389 139.7474410920336 9.619527123617956 35.669120772027895 139.74744565699146 6.9097492915867065 35.66911191623389 139.7474410920336 7.943181298422644 35.66911191623389 139.7474410920336 9.619527123617956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_16234b8b-1abc-49a6-9415-52b4fb23cfb4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_3c63b8ee-b179-4261-b728-28e4b5bfcbea">
											<gml:posList>35.66911191623389 139.7474410920336 7.943181298422644 35.669120772027895 139.74744565699146 6.9097492915867065 35.66909431898195 139.74743202099077 6.9097492915867065 35.66911191623389 139.7474410920336 7.943181298422644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fdc19bd3-b42f-4bdd-be00-75645ed409aa">
									<gml:exterior>
										<gml:LinearRing gml:id="line_510ddb6a-faf7-4f61-8dc8-d58432ea7b3e">
											<gml:posList>35.66911191623389 139.7474410920336 7.943181298422644 35.66909431898195 139.74743202099077 6.9097492915867065 35.66910030205041 139.74743510511118 7.943181298422644 35.66911191623389 139.7474410920336 7.943181298422644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_53c36d23-8844-4812-b8c4-9c0d76ddf277">
									<gml:exterior>
										<gml:LinearRing gml:id="line_47dd45a5-0f1c-4952-802b-7a9b210312ba">
											<gml:posList>35.66909431898195 139.74743202099077 13.561253808188269 35.66910030205041 139.74743510511118 9.619527123617956 35.66909431898195 139.74743202099077 6.9097492915867065 35.66909431898195 139.74743202099077 13.561253808188269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_1eebee81-d89b-48d0-a365-62792793c2cc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8fbda7d8-9ab6-4a07-841e-6c46c69f0b97">
											<gml:posList>35.66910030205041 139.74743510511118 9.619527123617956 35.66909431898195 139.74743202099077 13.561253808188269 35.66911191623389 139.7474410920336 9.619527123617956 35.66910030205041 139.74743510511118 9.619527123617956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_700e907a-17a5-40a4-b53c-5569c2a7f213">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6e3e600d-177a-414e-a136-0ce0b4095603">
											<gml:posList>35.66909431898195 139.74743202099077 6.9097492915867065 35.66910030205041 139.74743510511118 9.619527123617956 35.66910030205041 139.74743510511118 7.943181298422644 35.66909431898195 139.74743202099077 6.9097492915867065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Window gml:id="wnd_3a696f7b-e938-4785-aff6-60ab1ddeb8b6">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_00e2a13d-3a51-45c2-9ea1-993d494a3e1c">
											<gml:exterior>
												<gml:LinearRing gml:id="line_3c7cdda9-5467-4ac1-a443-ea9f987e9a85">
													<gml:posList>35.66911191623389 139.7474410920336 7.943181298422644 35.66910030205041 139.74743510511118 7.943181298422644 35.66910030205041 139.74743510511118 9.619527123617956 35.66911191623389 139.7474410920336 9.619527123617956 35.66911191623389 139.7474410920336 7.943181298422644</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Window>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e92ac9d4-d67d-4ef5-8afa-add322e4fd6c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d13c2b88-5ad9-473c-a28e-d0e535d1d6f6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b27cc26e-2221-4fe7-b741-fc300313f1d2">
											<gml:posList>35.66901769729681 139.74750492901666 7.4212544185398315 35.66901771222747 139.74750252784182 7.4212544185398315 35.66901771222747 139.74750252784182 6.9097492915867065 35.66901769729681 139.74750492901666 6.9097492915867065 35.66901769729681 139.74750492901666 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1032_7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1032_7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1032_7">
											<gml:posList>35.66912397457652 139.74744224163584 12.7552791 35.66912397744709 139.74744224223105 12.00027917 35.66909618834804 139.74742787884276 11.99888651 35.66909618548071 139.74742787824914 12.75388645 35.66912397457652 139.74744224163584 12.7552791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0785c63c-3b97-457d-889f-c4a1439d6ac3">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7a06c5f9-e656-4a2f-b1b2-dbaa07ad8d71">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b69b6b2a-eb80-49ae-960f-38d7b10acf23">
											<gml:posList>35.66901771222747 139.74750252784182 9.472493432211706 35.66901771222747 139.74750252784182 11.996846459555456 35.66901822599627 139.74750029923348 11.996846459555456 35.66901822599627 139.74750029923348 9.472493432211706 35.66901771222747 139.74750252784182 9.472493432211706</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0157_p1033_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0157_p1033_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0157_p1033_1">
											<gml:posList>35.6691094237407 139.747423133844 11.99947491 35.66912419816223 139.74742183357426 12.00015786 35.669124221496546 139.74742183839342 5.86301299 35.66910944706077 139.74742313866437 5.86233003 35.6691094237407 139.747423133844 11.99947491</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_37d96e9e-b990-404b-8674-17835bb57bb7">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_68022819-5cce-4ecb-99d5-222d90f59203">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9c4b0c78-0a55-4df8-8d6b-1323f7c9d581">
											<gml:posList>35.66902041908485 139.7475107680356 7.4212544185398315 35.66902178626362 139.7475117953996 7.4212544185398315 35.66903268751735 139.7475171146221 7.4212544185398315 35.66903792607768 139.747501852905 7.4212544185398315 35.66902303880452 139.74749458884264 7.4212544185398315 35.66902060492698 139.74749652741005 7.4212544185398315 35.66901911674191 139.74749843327763 7.4212544185398315 35.66901822599627 139.74750029923348 7.4212544185398315 35.66901771222747 139.74750252784182 7.4212544185398315 35.66901769729681 139.74750492901666 7.4212544185398315 35.66901821045491 139.74750724653123 7.4212544185398315 35.669019170246266 139.74750924163789 7.4212544185398315 35.66902041908485 139.7475107680356 7.4212544185398315</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:lod3Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#Poly_1b633b33-a6a5-4d15-895c-4d1b0379e8cf"/>
							<gml:surfaceMember xlink:href="#Poly_0811377d-5aa0-4479-abc6-f7c9cd18aedd"/>
							<gml:surfaceMember xlink:href="#Poly_8479262b-94fa-40a9-8e73-2c4d32c14b5f"/>
							<gml:surfaceMember xlink:href="#Poly_deef78cf-4c9f-40cf-8428-472af47a24c9"/>
							<gml:surfaceMember xlink:href="#Poly_0c65e4e8-e923-48ef-bdf6-8caa97be7fa6"/>
							<gml:surfaceMember xlink:href="#Poly_7a06c5f9-e656-4a2f-b1b2-dbaa07ad8d71"/>
							<gml:surfaceMember xlink:href="#Poly_b5d5c196-e047-45fa-813e-ea9f257f025f"/>
							<gml:surfaceMember xlink:href="#Poly_2d679781-04c9-4b3f-aa3d-22498ae0c04f"/>
							<gml:surfaceMember xlink:href="#Poly_e3e3da64-c479-448e-af3a-4e743fee7489"/>
							<gml:surfaceMember xlink:href="#Poly_927d53a5-cd80-4d20-b238-f0f9df183913"/>
							<gml:surfaceMember xlink:href="#Poly_670e7bd6-1627-4976-8451-9f1977c97d07"/>
							<gml:surfaceMember xlink:href="#Poly_e8898089-a630-4576-97dd-2125fd4187c5"/>
							<gml:surfaceMember xlink:href="#Poly_16234b8b-1abc-49a6-9415-52b4fb23cfb4"/>
							<gml:surfaceMember xlink:href="#Poly_fdc19bd3-b42f-4bdd-be00-75645ed409aa"/>
							<gml:surfaceMember xlink:href="#Poly_53c36d23-8844-4812-b8c4-9c0d76ddf277"/>
							<gml:surfaceMember xlink:href="#Poly_1eebee81-d89b-48d0-a365-62792793c2cc"/>
							<gml:surfaceMember xlink:href="#Poly_700e907a-17a5-40a4-b53c-5569c2a7f213"/>
							<gml:surfaceMember xlink:href="#Poly_24d0c05e-36b3-4ad0-9303-3b2d00caf408"/>
							<gml:surfaceMember xlink:href="#Poly_ee955808-8000-4c1a-b587-8fc1640f83ca"/>
							<gml:surfaceMember xlink:href="#Poly_296412d9-8979-4435-879d-042a65015b78"/>
							<gml:surfaceMember xlink:href="#Poly_d20a170a-32fb-4d61-a859-5d1d427a9ae7"/>
							<gml:surfaceMember xlink:href="#Poly_df287819-236d-4a9d-8c79-db05979de257"/>
							<gml:surfaceMember xlink:href="#Poly_d13c2b88-5ad9-473c-a28e-d0e535d1d6f6"/>
							<gml:surfaceMember xlink:href="#Poly_563526a5-804f-4c51-a4ac-2ce58ef07157"/>
							<gml:surfaceMember xlink:href="#Poly_59db29de-a73c-43f6-9709-4d083c91227c"/>
							<gml:surfaceMember xlink:href="#Poly_0ef6cf62-bb61-48b2-b0a0-6755bfd94c33"/>
							<gml:surfaceMember xlink:href="#Poly_acd776e3-1a66-4826-b5ed-1f7096d09f92"/>
							<gml:surfaceMember xlink:href="#Poly_1fc96e79-9977-4591-99a0-b24eb6e68978"/>
							<gml:surfaceMember xlink:href="#Poly_00e2a13d-3a51-45c2-9ea1-993d494a3e1c"/>
							<gml:surfaceMember xlink:href="#Poly_a4e9989e-d3b8-4780-a2cb-630bcfaa71df"/>
							<gml:surfaceMember xlink:href="#Poly_6661be3e-39a0-449f-8efd-39cb58ff48c5"/>
							<gml:surfaceMember xlink:href="#Poly_ce216f63-9d19-49b4-b87b-70e2191cd1aa"/>
							<gml:surfaceMember xlink:href="#Poly_43a7460b-def0-4261-8583-24af0b4ff54f"/>
							<gml:surfaceMember xlink:href="#Poly_e54473a7-8b5a-4be2-aa3e-f219f980caba"/>
							<gml:surfaceMember xlink:href="#Poly_1824ee5a-1d7d-4103-a1d8-9a83a8aac40d"/>
							<gml:surfaceMember xlink:href="#Poly_68022819-5cce-4ecb-99d5-222d90f59203"/>
							<gml:surfaceMember xlink:href="#Poly_0a40b385-6ef7-4f7c-8f84-2fe6e639f569"/>
							<gml:surfaceMember xlink:href="#Poly_a90828bf-8f79-4f45-bec1-be2b0ea70c22"/>
							<gml:surfaceMember xlink:href="#Poly_a75f606f-9897-4b12-8379-27f74fe78478"/>
							<gml:surfaceMember xlink:href="#Poly_05771913-8a90-489e-ac14-2f52e5958179"/>
							<gml:surfaceMember xlink:href="#Poly_1cf45e12-5ffc-48e3-9f7f-4cdfcd08c811"/>
							<gml:surfaceMember xlink:href="#Poly_d1f8676c-fab5-4351-a90d-d8c49c00a70f"/>
							<gml:surfaceMember xlink:href="#Poly_94ba32e8-fd3f-4451-acda-5673fd48f408"/>
							<gml:surfaceMember xlink:href="#Poly_b89d35f3-bb7b-4173-aa56-2b302de69b60"/>
							<gml:surfaceMember xlink:href="#Poly_0712ce06-ff13-42e1-9dfa-426684c6bd11"/>
							<gml:surfaceMember xlink:href="#Poly_a024198d-9dd7-4730-98ac-8ce99ddf118c"/>
							<gml:surfaceMember xlink:href="#Poly_7db03b8f-ff1b-49e3-a73e-f739763a9056"/>
							<gml:surfaceMember xlink:href="#Poly_aecf6f6b-3c50-4fa4-a93c-90eb452de90d"/>
							<gml:surfaceMember xlink:href="#Poly_38a902af-1e3b-4591-9b29-0b21c78fa844"/>
							<gml:surfaceMember xlink:href="#Poly_f71dbfc3-69bf-47a9-b2ec-6bff9c8e5129"/>
							<gml:surfaceMember xlink:href="#Poly_2a76cfeb-92e7-4ec6-a989-b657fb6f2ed6"/>
							<gml:surfaceMember xlink:href="#Poly_1b5b9604-492d-4d5e-8af3-0e82840322cd"/>
							<gml:surfaceMember xlink:href="#Poly_dbb5353e-a843-4379-93c7-932bcdb139f3"/>
							<gml:surfaceMember xlink:href="#Poly_0357158c-a0b9-4c0f-b4b1-38305d0f8f08"/>
							<gml:surfaceMember xlink:href="#Poly_54d438d6-7f2b-47bb-b1e8-501dccbc8be7"/>
							<gml:surfaceMember xlink:href="#Poly_e71bff87-cac5-4c1e-90f9-a8090ec59758"/>
							<gml:surfaceMember xlink:href="#Poly_bbf5f22a-774f-4d8f-88f9-bb66ec8b9079"/>
							<gml:surfaceMember xlink:href="#Poly_8662ac39-0fd6-4adc-a367-b0ce2c7973db"/>
							<gml:surfaceMember xlink:href="#Poly_a8b67d97-23ca-4b68-ada5-ae0650b14a69"/>
							<gml:surfaceMember xlink:href="#Poly_2f38c2d2-45c9-422a-9298-69b387340b7d"/>
							<gml:surfaceMember xlink:href="#Poly_a3f74002-def6-4b79-85b3-db5cca7f53a0"/>
							<gml:surfaceMember xlink:href="#Poly_ebabcb63-ee7e-46d3-986b-4dc6e5457986"/>
							<gml:surfaceMember xlink:href="#Poly_26e7fa69-233b-437e-b8e2-6c9a44e52333"/>
							<gml:surfaceMember xlink:href="#Poly_6ddca088-cf1b-4d25-b14e-37a06794d728"/>
							<gml:surfaceMember xlink:href="#Poly_7d31a3ae-133b-4a9c-8578-67369043e967"/>
							<gml:surfaceMember xlink:href="#Poly_08c5f7e7-d769-46fa-aea3-df648977baad"/>
							<gml:surfaceMember xlink:href="#Poly_efe261d3-dfd2-4363-85ae-49b788dfcb20"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod3Solid>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">3</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">2</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">2</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
					<uro:lodType>3.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">53.16955</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1110</uro:detailedUsage>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2440500000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>