<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2413bbe6-0b22-4876-8a75-f9fdcdd5c833">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">37.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.671402648090435 139.73809742957198 0 35.6715426167058 139.73805619272144 0 35.67153318636046 139.7380081299169 0 35.67153534886632 139.73800713316808 0 35.67152557389765 139.7379564417364 0 35.67138319026886 139.73799847696455 0 35.671402648090435 139.73809742957198 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671402648090435 139.73809742957198 10.69 35.67138319026886 139.73799847696455 10.69 35.67152557389765 139.7379564417364 10.69 35.67153534886632 139.73800713316808 10.69 35.67153318636046 139.7380081299169 10.69 35.6715426167058 139.73805619272144 10.69 35.671402648090435 139.73809742957198 10.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671402648090435 139.73809742957198 10.69 35.6715426167058 139.73805619272144 10.69 35.6715426167058 139.73805619272144 48.52 35.671402648090435 139.73809742957198 48.52 35.671402648090435 139.73809742957198 10.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715426167058 139.73805619272144 10.69 35.67153318636046 139.7380081299169 10.69 35.67153318636046 139.7380081299169 48.52 35.6715426167058 139.73805619272144 48.52 35.6715426167058 139.73805619272144 10.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67153318636046 139.7380081299169 10.69 35.67153534886632 139.73800713316808 10.69 35.67153534886632 139.73800713316808 48.52 35.67153318636046 139.7380081299169 48.52 35.67153318636046 139.7380081299169 10.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67153534886632 139.73800713316808 10.69 35.67152557389765 139.7379564417364 10.69 35.67152557389765 139.7379564417364 48.52 35.67153534886632 139.73800713316808 48.52 35.67153534886632 139.73800713316808 10.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67152557389765 139.7379564417364 10.69 35.67138319026886 139.73799847696455 10.69 35.67138319026886 139.73799847696455 48.52 35.67152557389765 139.7379564417364 48.52 35.67152557389765 139.7379564417364 10.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67138319026886 139.73799847696455 10.69 35.671402648090435 139.73809742957198 10.69 35.671402648090435 139.73809742957198 48.52 35.67138319026886 139.73799847696455 48.52 35.67138319026886 139.73799847696455 10.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671402648090435 139.73809742957198 48.52 35.6715426167058 139.73805619272144 48.52 35.67153318636046 139.7380081299169 48.52 35.67153534886632 139.73800713316808 48.52 35.67152557389765 139.7379564417364 48.52 35.67138319026886 139.73799847696455 48.52 35.671402648090435 139.73809742957198 48.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f60f9868-e603-4cd2-a5ab-3e7340de3395"/>
							<gml:surfaceMember xlink:href="#poly-6deb8ffe-2dfb-4833-a5bc-a37e329f9272"/>
							<gml:surfaceMember xlink:href="#poly-f9653ab7-15fa-43f6-803e-958a13e3ff8e"/>
							<gml:surfaceMember xlink:href="#poly-ce00ea78-5917-452f-938d-eef57068d624"/>
							<gml:surfaceMember xlink:href="#poly-84049044-7cbf-4ff8-b27c-0f1593f0a565"/>
							<gml:surfaceMember xlink:href="#poly-d19557d2-8bc6-4a83-b341-85c64fac2caf"/>
							<gml:surfaceMember xlink:href="#poly-5400c69b-97ae-4c87-a642-b0782a1541f8"/>
							<gml:surfaceMember xlink:href="#poly-564fb246-c146-41c8-b6ef-9fcbf73a9c85"/>
							<gml:surfaceMember xlink:href="#poly-c607328f-a5f6-488a-80ac-9507b42bce2d"/>
							<gml:surfaceMember xlink:href="#poly-e1891a81-1d66-49f1-be80-147a6483b835"/>
							<gml:surfaceMember xlink:href="#poly-37d4d471-59d4-44d5-b86c-2416e1f635cc"/>
							<gml:surfaceMember xlink:href="#poly-755d6fef-0f1e-4387-b4ef-29387cb9996a"/>
							<gml:surfaceMember xlink:href="#poly-35cdd212-dde8-4948-b42e-27c34587c0c0"/>
							<gml:surfaceMember xlink:href="#poly-272eb3d2-3e5a-416c-9988-003e96fde6b7"/>
							<gml:surfaceMember xlink:href="#poly-f95a9b7a-d7e9-4cbf-b332-5fa9bf49427a"/>
							<gml:surfaceMember xlink:href="#poly-e7c76a5c-858c-441f-bcfb-f1de562047dd"/>
							<gml:surfaceMember xlink:href="#poly-69e4f791-1f6f-45ef-86e0-96784e2803cd"/>
							<gml:surfaceMember xlink:href="#poly-51a86f2b-4ec4-4db2-9e7f-bcd6f2fbdd65"/>
							<gml:surfaceMember xlink:href="#poly-85dd7d4f-4870-4ad6-b615-b9e65ac76954"/>
							<gml:surfaceMember xlink:href="#poly-73442c6d-c6d6-439a-803e-d1da8198fc85"/>
							<gml:surfaceMember xlink:href="#poly-f88ca91a-84b7-413e-b68d-975f5130db51"/>
							<gml:surfaceMember xlink:href="#poly-416b07ef-6a3e-450c-8ff0-470bc415da3e"/>
							<gml:surfaceMember xlink:href="#poly-1a7f997d-d643-46c1-b456-18a35cfa3dd2"/>
							<gml:surfaceMember xlink:href="#poly-750c1a1f-b1a4-41d5-91f1-ac902bb8271f"/>
							<gml:surfaceMember xlink:href="#poly-807b5fd2-657e-4014-911c-33d0e4e85770"/>
							<gml:surfaceMember xlink:href="#poly-fdcc5590-8263-4a64-84cd-091ecc154eec"/>
							<gml:surfaceMember xlink:href="#poly-79a69660-3f54-4e94-9c7f-1eb0f37dc1f8"/>
							<gml:surfaceMember xlink:href="#poly-03c0a7b2-946c-4339-9d0a-6be9e97545a5"/>
							<gml:surfaceMember xlink:href="#poly-e395a700-8b52-4568-86c0-341fe4098b99"/>
							<gml:surfaceMember xlink:href="#poly-eca4127f-6e49-4038-8754-9f80e72105ec"/>
							<gml:surfaceMember xlink:href="#poly-17c62f56-b572-4c7b-9e20-bd48f3e046eb"/>
							<gml:surfaceMember xlink:href="#poly-7cd90fee-87c1-4962-bf0a-1a340ba73055"/>
							<gml:surfaceMember xlink:href="#poly-5895c188-40f5-4d06-809f-bc284fbd90cb"/>
							<gml:surfaceMember xlink:href="#poly-6f133925-d349-489c-ab13-1f66e4dd7ce6"/>
							<gml:surfaceMember xlink:href="#poly-482a863f-50cf-481d-b282-27ca4dcb99dc"/>
							<gml:surfaceMember xlink:href="#poly-762139c7-63de-4652-96d3-81a8fbee305c"/>
							<gml:surfaceMember xlink:href="#poly-23a672db-986c-456b-a984-7b90725b60e8"/>
							<gml:surfaceMember xlink:href="#poly-4c7d23e9-c373-4c81-bcd4-64763c5a12b2"/>
							<gml:surfaceMember xlink:href="#poly-04762b08-22f7-47c1-b2a2-9e29985ddbc1"/>
							<gml:surfaceMember xlink:href="#poly-25b50b3c-1344-4911-8196-9647f10f0901"/>
							<gml:surfaceMember xlink:href="#poly-1531c92a-6e31-47fc-a7bc-397ffdbcf384"/>
							<gml:surfaceMember xlink:href="#poly-b59c63aa-828a-453f-9d47-1b372bac20a4"/>
							<gml:surfaceMember xlink:href="#poly-90e71622-f9e6-4a56-9f36-e26c4750d0a9"/>
							<gml:surfaceMember xlink:href="#poly-bcd8cab4-f163-4ede-8155-6a68ff77dd39"/>
							<gml:surfaceMember xlink:href="#poly-17dd839a-fbed-4c77-9c75-6341199ae73e"/>
							<gml:surfaceMember xlink:href="#poly-9558306c-f5cb-40b0-82b2-be89ddcc4786"/>
							<gml:surfaceMember xlink:href="#poly-5e5daabb-3fe1-40eb-90a2-cfe6c2c39ac1"/>
							<gml:surfaceMember xlink:href="#poly-f9955047-a0ed-4644-a0fe-4ced11e0dd9d"/>
							<gml:surfaceMember xlink:href="#poly-0c9fef3f-9d33-4c45-952b-aad8b931ddae"/>
							<gml:surfaceMember xlink:href="#poly-407555de-7164-490b-b90f-58727e18a27c"/>
							<gml:surfaceMember xlink:href="#poly-d9ea8a7a-88fe-4056-aa67-5fb8b8e4f6e5"/>
							<gml:surfaceMember xlink:href="#poly-ed1f608e-cb16-48ba-b3f2-6ad8d7a16cd7"/>
							<gml:surfaceMember xlink:href="#poly-c3196116-4d0b-4786-8755-6be47e945117"/>
							<gml:surfaceMember xlink:href="#poly-6742bddb-69ca-4f40-a64c-247582b6375d"/>
							<gml:surfaceMember xlink:href="#poly-c5cc6a6e-a22b-42f6-b0e5-4c83923c3254"/>
							<gml:surfaceMember xlink:href="#poly-6c18d3ba-c4c8-47c3-b7f9-75994567a2fe"/>
							<gml:surfaceMember xlink:href="#poly-4dd4b14b-fa27-4aa8-882b-b6649d4f55ab"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2413bbe6-0b22-4876-8a75-f9fdcdd5c833_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55e56582-99b1-4622-b700-da994b06f2be">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6715509794978 139.7380537304779 10.72 35.671542616705786 139.73805619272142 10.72 35.67153318636047 139.73800812991686 10.72 35.67153534886629 139.73800713316805 10.72 35.67154147670943 139.73800524799086 10.72 35.6715509794978 139.7380537304779 10.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf9ea118-66c6-4ec5-ae6f-c4153a58cc0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf9ea118-66c6-4ec5-ae6f-c4153a58cc0c_0">
											<gml:posList>35.67153534886629 139.73800713316805 46.244 35.67153534886629 139.73800713316805 10.72 35.67153318636047 139.73800812991686 10.72 35.67153318636047 139.73800812991686 46.244 35.67153534886629 139.73800713316805 46.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04e09b2b-496d-4673-afda-3c538db52d9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04e09b2b-496d-4673-afda-3c538db52d9f_0">
											<gml:posList>35.67153318636047 139.73800812991686 46.244 35.67153318636047 139.73800812991686 10.72 35.671542616705786 139.73805619272142 10.72 35.671542616705786 139.73805619272142 44.042 35.67153318636047 139.73800812991686 46.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20edbafa-7b0e-4a9a-9883-b42f181c441c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20edbafa-7b0e-4a9a-9883-b42f181c441c_0">
											<gml:posList>35.67154147670943 139.73800524799086 46.244 35.67154147670943 139.73800524799086 10.72 35.67153534886629 139.73800713316805 10.72 35.67153534886629 139.73800713316805 46.244 35.67154147670943 139.73800524799086 46.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e017ff86-505b-46a1-b0aa-720ff529fe23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e017ff86-505b-46a1-b0aa-720ff529fe23_0">
											<gml:posList>35.6715509794978 139.7380537304779 44.042 35.67154147670943 139.73800524799086 46.244 35.67153534886629 139.73800713316805 46.244 35.67153318636047 139.73800812991686 46.244 35.671542616705786 139.73805619272142 44.042 35.6715509794978 139.7380537304779 44.042</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59c8556b-d18e-4b6d-911b-7f37f520c5fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59c8556b-d18e-4b6d-911b-7f37f520c5fe_0">
											<gml:posList>35.6715509794978 139.7380537304779 44.042 35.6715509794978 139.7380537304779 10.72 35.67154147670943 139.73800524799086 10.72 35.67154147670943 139.73800524799086 46.244 35.6715509794978 139.7380537304779 44.042</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41f3202e-2ab6-440f-85fa-ecf5348268d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41f3202e-2ab6-440f-85fa-ecf5348268d8_0">
											<gml:posList>35.671542616705786 139.73805619272142 44.042 35.671542616705786 139.73805619272142 10.72 35.6715509794978 139.7380537304779 10.72 35.6715509794978 139.7380537304779 44.042 35.671542616705786 139.73805619272142 44.042</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f60f9868-e603-4cd2-a5ab-3e7340de3395">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f60f9868-e603-4cd2-a5ab-3e7340de3395">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f60f9868-e603-4cd2-a5ab-3e7340de3395">
											<gml:posList>35.67138319026887 139.73799847696452 10.69 35.671525573897625 139.73795644173637 10.69 35.67153534886629 139.73800713316805 10.69 35.67153318636047 139.73800812991686 10.69 35.671542616705786 139.73805619272142 10.69 35.671402648090414 139.73809742957198 10.69 35.67138319026887 139.73799847696452 10.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6deb8ffe-2dfb-4833-a5bc-a37e329f9272">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6deb8ffe-2dfb-4833-a5bc-a37e329f9272">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6deb8ffe-2dfb-4833-a5bc-a37e329f9272">
											<gml:posList>35.671402648090414 139.73809742957198 48.746 35.67140577991997 139.7380911735891 48.746 35.67140474818799 139.7380859056818 48.746 35.67138968873563 139.73800931680034 48.746 35.67138830408318 139.73800230398385 48.746 35.67138319026887 139.73799847696452 48.746 35.671402648090414 139.73809742957198 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9653ab7-15fa-43f6-803e-958a13e3ff8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9653ab7-15fa-43f6-803e-958a13e3ff8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9653ab7-15fa-43f6-803e-958a13e3ff8e">
											<gml:posList>35.67146545520476 139.73802838118988 50.125 35.671397218472265 139.73804761676064 50.125 35.67140098332728 139.7380667556971 49.77 35.671469337721945 139.73804812755438 49.77 35.67146545520476 139.73802838118988 50.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce00ea78-5917-452f-938d-eef57068d624">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce00ea78-5917-452f-938d-eef57068d624">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce00ea78-5917-452f-938d-eef57068d624">
											<gml:posList>35.671469337721945 139.73804812755438 49.77 35.67140098332728 139.7380667556971 49.77 35.67140474818799 139.7380859056818 49.246 35.671469337721945 139.73804812755438 49.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84049044-7cbf-4ff8-b27c-0f1593f0a565">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84049044-7cbf-4ff8-b27c-0f1593f0a565">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84049044-7cbf-4ff8-b27c-0f1593f0a565">
											<gml:posList>35.67140474818799 139.7380859056818 49.246 35.671472812984184 139.7380658087261 49.246 35.671469337721945 139.73804812755438 49.77 35.67140474818799 139.7380859056818 49.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d19557d2-8bc6-4a83-b341-85c64fac2caf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d19557d2-8bc6-4a83-b341-85c64fac2caf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d19557d2-8bc6-4a83-b341-85c64fac2caf">
											<gml:posList>35.671542616705786 139.73805619272142 48.746 35.67153750288457 139.73805235464488 48.746 35.67140577991997 139.7380911735891 48.746 35.671402648090414 139.73809742957198 48.746 35.671542616705786 139.73805619272142 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5400c69b-97ae-4c87-a642-b0782a1541f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5400c69b-97ae-4c87-a642-b0782a1541f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5400c69b-97ae-4c87-a642-b0782a1541f8">
											<gml:posList>35.67150818146838 139.73796157691672 49.084 35.67151113972725 139.73796379372715 49.084 35.671523755995985 139.73796006712368 49.084 35.671525573897625 139.73795644173637 49.084 35.67150818146838 139.73796157691672 49.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-564fb246-c146-41c8-b6ef-9fcbf73a9c85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-564fb246-c146-41c8-b6ef-9fcbf73a9c85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-564fb246-c146-41c8-b6ef-9fcbf73a9c85">
											<gml:posList>35.67150818146838 139.73796157691672 48.746 35.67149780909101 139.7379646380653 48.746 35.671503590332804 139.73796898347553 48.746 35.67150930369296 139.73796728657823 48.746 35.67150818146838 139.73796157691672 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c607328f-a5f6-488a-80ac-9507b42bce2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c607328f-a5f6-488a-80ac-9507b42bce2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c607328f-a5f6-488a-80ac-9507b42bce2d">
											<gml:posList>35.67149780909101 139.7379646380653 48.746 35.67149880460719 139.7379696961384 48.746 35.671503590332804 139.73796898347553 48.746 35.67149780909101 139.7379646380653 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1891a81-1d66-49f1-be80-147a6483b835">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1891a81-1d66-49f1-be80-147a6483b835">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1891a81-1d66-49f1-be80-147a6483b835">
											<gml:posList>35.671525573897625 139.73795644173637 49.084 35.671523755995985 139.73796006712368 49.084 35.67152799180895 139.73798202236253 49.084 35.671530941071204 139.73798426127775 49.084 35.671525573897625 139.73795644173637 49.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-37d4d471-59d4-44d5-b86c-2416e1f635cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37d4d471-59d4-44d5-b86c-2416e1f635cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37d4d471-59d4-44d5-b86c-2416e1f635cc">
											<gml:posList>35.67152799180895 139.73798202236253 48.616 35.671523755995985 139.73796006712368 48.616 35.67151113972725 139.73796379372715 48.616 35.671515447579324 139.73798566050573 48.616 35.67152799180895 139.73798202236253 48.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-755d6fef-0f1e-4387-b4ef-29387cb9996a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-755d6fef-0f1e-4387-b4ef-29387cb9996a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-755d6fef-0f1e-4387-b4ef-29387cb9996a">
											<gml:posList>35.67151362966806 139.7379892748455 49.084 35.671515447579324 139.73798566050573 49.084 35.67151113972725 139.73796379372715 49.084 35.67150818146838 139.73796157691672 49.084 35.67151362966806 139.7379892748455 49.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35cdd212-dde8-4948-b42e-27c34587c0c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35cdd212-dde8-4948-b42e-27c34587c0c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35cdd212-dde8-4948-b42e-27c34587c0c0">
											<gml:posList>35.67149780909101 139.7379646380653 48.746 35.67138319026887 139.73799847696452 48.746 35.67138830408318 139.73800230398385 48.746 35.67149880460719 139.7379696961384 48.746 35.67149780909101 139.7379646380653 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-272eb3d2-3e5a-416c-9988-003e96fde6b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-272eb3d2-3e5a-416c-9988-003e96fde6b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-272eb3d2-3e5a-416c-9988-003e96fde6b7">
											<gml:posList>35.67151362966806 139.7379892748455 48.466 35.67150930369296 139.73796728657823 48.466 35.671503590332804 139.73796898347553 48.466 35.67151048655067 139.73800403659365 48.466 35.671523301078786 139.73800025452874 48.466 35.6715207398665 139.73798721175655 48.466 35.67151362966806 139.7379892748455 48.466</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f95a9b7a-d7e9-4cbf-b332-5fa9bf49427a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f95a9b7a-d7e9-4cbf-b332-5fa9bf49427a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f95a9b7a-d7e9-4cbf-b332-5fa9bf49427a">
											<gml:posList>35.671530941071204 139.73798426127775 49.084 35.67152799180895 139.73798202236253 49.084 35.671515447579324 139.73798566050573 49.084 35.67151362966806 139.7379892748455 49.084 35.671530941071204 139.73798426127775 49.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7c76a5c-858c-441f-bcfb-f1de562047dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7c76a5c-858c-441f-bcfb-f1de562047dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7c76a5c-858c-441f-bcfb-f1de562047dd">
											<gml:posList>35.67149880460719 139.7379696961384 48.746 35.6715069497729 139.73801113259705 48.746 35.67151048655067 139.73800403659365 48.746 35.671503590332804 139.73796898347553 48.746 35.67149880460719 139.7379696961384 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69e4f791-1f6f-45ef-86e0-96784e2803cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69e4f791-1f6f-45ef-86e0-96784e2803cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69e4f791-1f6f-45ef-86e0-96784e2803cd">
											<gml:posList>35.67152688770863 139.73799920085432 48.746 35.67153343009533 139.73799720471962 48.746 35.671530941071204 139.73798426127775 48.746 35.6715207398665 139.73798721175655 48.746 35.671523301078786 139.73800025452874 48.746 35.67152688770863 139.73799920085432 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51a86f2b-4ec4-4db2-9e7f-bcd6f2fbdd65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51a86f2b-4ec4-4db2-9e7f-bcd6f2fbdd65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51a86f2b-4ec4-4db2-9e7f-bcd6f2fbdd65">
											<gml:posList>35.67153448903851 139.73800268248385 48.746 35.67153343009533 139.73799720471962 48.746 35.67152688770863 139.73799920085432 48.746 35.671528181157115 139.73800486612842 48.746 35.67153448903851 139.73800268248385 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-85dd7d4f-4870-4ad6-b615-b9e65ac76954">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85dd7d4f-4870-4ad6-b615-b9e65ac76954">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85dd7d4f-4870-4ad6-b615-b9e65ac76954">
											<gml:posList>35.671528181157115 139.73800486612842 48.746 35.67152688770863 139.73799920085432 48.746 35.671523301078786 139.73800025452874 48.746 35.67151048655067 139.73800403659365 48.746 35.6715069497729 139.73801113259705 48.746 35.671528181157115 139.73800486612842 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73442c6d-c6d6-439a-803e-d1da8198fc85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73442c6d-c6d6-439a-803e-d1da8198fc85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73442c6d-c6d6-439a-803e-d1da8198fc85">
											<gml:posList>35.67153318636047 139.73800812991686 48.746 35.67153534886629 139.73800713316805 48.746 35.67153448903851 139.73800268248385 48.746 35.671528181157115 139.73800486612842 48.746 35.67153318636047 139.73800812991686 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f88ca91a-84b7-413e-b68d-975f5130db51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f88ca91a-84b7-413e-b68d-975f5130db51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f88ca91a-84b7-413e-b68d-975f5130db51">
											<gml:posList>35.67145775351911 139.73798921978351 49.246 35.67138968873563 139.73800931680034 49.246 35.67139345360547 139.7380284667796 49.77 35.67146157269307 139.7380086458737 49.77 35.67145775351911 139.73798921978351 49.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-416b07ef-6a3e-450c-8ff0-470bc415da3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-416b07ef-6a3e-450c-8ff0-470bc415da3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-416b07ef-6a3e-450c-8ff0-470bc415da3e">
											<gml:posList>35.67149109177289 139.73804169478112 49.659 35.671483326750675 139.73800222413672 49.659 35.67146157269307 139.7380086458737 49.659 35.671469337721945 139.73804812755438 49.659 35.67149109177289 139.73804169478112 49.659</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a7f997d-d643-46c1-b456-18a35cfa3dd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a7f997d-d643-46c1-b456-18a35cfa3dd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a7f997d-d643-46c1-b456-18a35cfa3dd2">
											<gml:posList>35.671397218472265 139.73804761676064 50.125 35.67146545520476 139.73802838118988 50.125 35.67146157269307 139.7380086458737 49.77 35.67139345360547 139.7380284667796 49.77 35.671397218472265 139.73804761676064 50.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-750c1a1f-b1a4-41d5-91f1-ac902bb8271f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-750c1a1f-b1a4-41d5-91f1-ac902bb8271f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-750c1a1f-b1a4-41d5-91f1-ac902bb8271f">
											<gml:posList>35.67145775351911 139.73798921978351 48.292 35.67146157269307 139.7380086458737 48.292 35.671483326750675 139.73800222413672 48.292 35.67149109177289 139.73804169478112 48.292 35.671469337721945 139.73804812755438 48.292 35.671472812984184 139.7380658087261 48.292 35.67140474818799 139.7380859056818 48.292 35.67140577991997 139.7380911735891 48.292 35.67153750288457 139.73805235464488 48.292 35.671528181157115 139.73800486612842 48.292 35.6715069497729 139.73801113259705 48.292 35.67149880460719 139.7379696961384 48.292 35.67138830408318 139.73800230398385 48.292 35.67138968873563 139.73800931680034 48.292 35.67145775351911 139.73798921978351 48.292</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-807b5fd2-657e-4014-911c-33d0e4e85770">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-807b5fd2-657e-4014-911c-33d0e4e85770">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-807b5fd2-657e-4014-911c-33d0e4e85770">
											<gml:posList>35.67153318636047 139.73800812991686 48.746 35.671528181157115 139.73800486612842 48.746 35.67153750288457 139.73805235464488 48.746 35.671542616705786 139.73805619272142 48.746 35.67153318636047 139.73800812991686 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fdcc5590-8263-4a64-84cd-091ecc154eec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdcc5590-8263-4a64-84cd-091ecc154eec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdcc5590-8263-4a64-84cd-091ecc154eec">
											<gml:posList>35.671515447579324 139.73798566050573 49.084 35.67152799180895 139.73798202236253 49.084 35.67152799180895 139.73798202236253 48.616 35.671515447579324 139.73798566050573 48.616 35.671515447579324 139.73798566050573 49.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79a69660-3f54-4e94-9c7f-1eb0f37dc1f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79a69660-3f54-4e94-9c7f-1eb0f37dc1f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79a69660-3f54-4e94-9c7f-1eb0f37dc1f8">
											<gml:posList>35.671523301078786 139.73800025452874 48.746 35.671523301078786 139.73800025452874 48.466 35.67151048655067 139.73800403659365 48.466 35.67151048655067 139.73800403659365 48.746 35.671523301078786 139.73800025452874 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03c0a7b2-946c-4339-9d0a-6be9e97545a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03c0a7b2-946c-4339-9d0a-6be9e97545a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03c0a7b2-946c-4339-9d0a-6be9e97545a5">
											<gml:posList>35.67138968873563 139.73800931680034 48.746 35.67138968873563 139.73800931680034 48.292 35.67138830408318 139.73800230398385 48.292 35.67138830408318 139.73800230398385 48.746 35.67138968873563 139.73800931680034 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e395a700-8b52-4568-86c0-341fe4098b99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e395a700-8b52-4568-86c0-341fe4098b99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e395a700-8b52-4568-86c0-341fe4098b99">
											<gml:posList>35.67138319026887 139.73799847696452 10.69 35.671402648090414 139.73809742957198 10.69 35.671402648090414 139.73809742957198 48.746 35.67138319026887 139.73799847696452 48.746 35.67138319026887 139.73799847696452 10.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eca4127f-6e49-4038-8754-9f80e72105ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eca4127f-6e49-4038-8754-9f80e72105ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eca4127f-6e49-4038-8754-9f80e72105ec">
											<gml:posList>35.67140098332728 139.7380667556971 49.77 35.671397218472265 139.73804761676064 50.125 35.67139345360547 139.7380284667796 49.77 35.67138968873563 139.73800931680034 49.246 35.67138968873563 139.73800931680034 48.746 35.67140474818799 139.7380859056818 48.746 35.67140474818799 139.7380859056818 49.246 35.67140098332728 139.7380667556971 49.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17c62f56-b572-4c7b-9e20-bd48f3e046eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17c62f56-b572-4c7b-9e20-bd48f3e046eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17c62f56-b572-4c7b-9e20-bd48f3e046eb">
											<gml:posList>35.67140577991997 139.7380911735891 48.746 35.67140577991997 139.7380911735891 48.292 35.67140474818799 139.7380859056818 48.292 35.67140474818799 139.7380859056818 48.746 35.67140577991997 139.7380911735891 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cd90fee-87c1-4962-bf0a-1a340ba73055">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cd90fee-87c1-4962-bf0a-1a340ba73055">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cd90fee-87c1-4962-bf0a-1a340ba73055">
											<gml:posList>35.67145775351911 139.73798921978351 49.246 35.67145775351911 139.73798921978351 48.292 35.67138968873563 139.73800931680034 48.292 35.67138968873563 139.73800931680034 48.746 35.67138968873563 139.73800931680034 49.246 35.67145775351911 139.73798921978351 49.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5895c188-40f5-4d06-809f-bc284fbd90cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5895c188-40f5-4d06-809f-bc284fbd90cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5895c188-40f5-4d06-809f-bc284fbd90cb">
											<gml:posList>35.671472812984184 139.7380658087261 48.292 35.671472812984184 139.7380658087261 49.246 35.67140474818799 139.7380859056818 49.246 35.67140474818799 139.7380859056818 48.746 35.67140474818799 139.7380859056818 48.292 35.671472812984184 139.7380658087261 48.292</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f133925-d349-489c-ab13-1f66e4dd7ce6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f133925-d349-489c-ab13-1f66e4dd7ce6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f133925-d349-489c-ab13-1f66e4dd7ce6">
											<gml:posList>35.67138830408318 139.73800230398385 48.746 35.67138830408318 139.73800230398385 48.292 35.67149880460719 139.7379696961384 48.292 35.67149880460719 139.7379696961384 48.746 35.67138830408318 139.73800230398385 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-482a863f-50cf-481d-b282-27ca4dcb99dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-482a863f-50cf-481d-b282-27ca4dcb99dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-482a863f-50cf-481d-b282-27ca4dcb99dc">
											<gml:posList>35.67150818146838 139.73796157691672 48.746 35.67150818146838 139.73796157691672 49.084 35.671525573897625 139.73795644173637 49.084 35.671525573897625 139.73795644173637 10.69 35.67138319026887 139.73799847696452 10.69 35.67138319026887 139.73799847696452 48.746 35.67149780909101 139.7379646380653 48.746 35.67150818146838 139.73796157691672 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-762139c7-63de-4652-96d3-81a8fbee305c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-762139c7-63de-4652-96d3-81a8fbee305c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-762139c7-63de-4652-96d3-81a8fbee305c">
											<gml:posList>35.67145775351911 139.73798921978351 48.292 35.67145775351911 139.73798921978351 49.246 35.67146157269307 139.7380086458737 49.77 35.67146157269307 139.7380086458737 49.659 35.67146157269307 139.7380086458737 48.292 35.67145775351911 139.73798921978351 48.292</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23a672db-986c-456b-a984-7b90725b60e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23a672db-986c-456b-a984-7b90725b60e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23a672db-986c-456b-a984-7b90725b60e8">
											<gml:posList>35.67146157269307 139.7380086458737 49.77 35.67146545520476 139.73802838118988 50.125 35.671469337721945 139.73804812755438 49.77 35.671469337721945 139.73804812755438 49.659 35.67146157269307 139.7380086458737 49.659 35.67146157269307 139.7380086458737 49.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c7d23e9-c373-4c81-bcd4-64763c5a12b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c7d23e9-c373-4c81-bcd4-64763c5a12b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c7d23e9-c373-4c81-bcd4-64763c5a12b2">
											<gml:posList>35.671472812984184 139.7380658087261 49.246 35.671472812984184 139.7380658087261 48.292 35.671469337721945 139.73804812755438 48.292 35.671469337721945 139.73804812755438 49.659 35.671469337721945 139.73804812755438 49.77 35.671472812984184 139.7380658087261 49.246</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04762b08-22f7-47c1-b2a2-9e29985ddbc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04762b08-22f7-47c1-b2a2-9e29985ddbc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04762b08-22f7-47c1-b2a2-9e29985ddbc1">
											<gml:posList>35.67153750288457 139.73805235464488 48.746 35.67153750288457 139.73805235464488 48.292 35.67140577991997 139.7380911735891 48.292 35.67140577991997 139.7380911735891 48.746 35.67153750288457 139.73805235464488 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25b50b3c-1344-4911-8196-9647f10f0901">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25b50b3c-1344-4911-8196-9647f10f0901">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25b50b3c-1344-4911-8196-9647f10f0901">
											<gml:posList>35.67146157269307 139.7380086458737 49.659 35.671483326750675 139.73800222413672 49.659 35.671483326750675 139.73800222413672 48.292 35.67146157269307 139.7380086458737 48.292 35.67146157269307 139.7380086458737 49.659</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1531c92a-6e31-47fc-a7bc-397ffdbcf384">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1531c92a-6e31-47fc-a7bc-397ffdbcf384">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1531c92a-6e31-47fc-a7bc-397ffdbcf384">
											<gml:posList>35.671402648090414 139.73809742957198 10.69 35.671542616705786 139.73805619272142 10.69 35.671542616705786 139.73805619272142 48.746 35.671402648090414 139.73809742957198 48.746 35.671402648090414 139.73809742957198 10.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b59c63aa-828a-453f-9d47-1b372bac20a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b59c63aa-828a-453f-9d47-1b372bac20a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b59c63aa-828a-453f-9d47-1b372bac20a4">
											<gml:posList>35.671469337721945 139.73804812755438 48.292 35.67149109177289 139.73804169478112 48.292 35.67149109177289 139.73804169478112 49.659 35.671469337721945 139.73804812755438 49.659 35.671469337721945 139.73804812755438 48.292</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90e71622-f9e6-4a56-9f36-e26c4750d0a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90e71622-f9e6-4a56-9f36-e26c4750d0a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90e71622-f9e6-4a56-9f36-e26c4750d0a9">
											<gml:posList>35.671483326750675 139.73800222413672 49.659 35.67149109177289 139.73804169478112 49.659 35.67149109177289 139.73804169478112 48.292 35.671483326750675 139.73800222413672 48.292 35.671483326750675 139.73800222413672 49.659</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bcd8cab4-f163-4ede-8155-6a68ff77dd39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcd8cab4-f163-4ede-8155-6a68ff77dd39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcd8cab4-f163-4ede-8155-6a68ff77dd39">
											<gml:posList>35.67149880460719 139.7379696961384 48.746 35.67149880460719 139.7379696961384 48.292 35.6715069497729 139.73801113259705 48.292 35.6715069497729 139.73801113259705 48.746 35.67149880460719 139.7379696961384 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17dd839a-fbed-4c77-9c75-6341199ae73e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17dd839a-fbed-4c77-9c75-6341199ae73e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17dd839a-fbed-4c77-9c75-6341199ae73e">
											<gml:posList>35.671503590332804 139.73796898347553 48.746 35.671503590332804 139.73796898347553 48.466 35.67150930369296 139.73796728657823 48.466 35.67150930369296 139.73796728657823 48.746 35.671503590332804 139.73796898347553 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9558306c-f5cb-40b0-82b2-be89ddcc4786">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9558306c-f5cb-40b0-82b2-be89ddcc4786">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9558306c-f5cb-40b0-82b2-be89ddcc4786">
											<gml:posList>35.67151048655067 139.73800403659365 48.746 35.67151048655067 139.73800403659365 48.466 35.671503590332804 139.73796898347553 48.466 35.671503590332804 139.73796898347553 48.746 35.67151048655067 139.73800403659365 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e5daabb-3fe1-40eb-90a2-cfe6c2c39ac1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e5daabb-3fe1-40eb-90a2-cfe6c2c39ac1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e5daabb-3fe1-40eb-90a2-cfe6c2c39ac1">
											<gml:posList>35.67150818146838 139.73796157691672 49.084 35.67150818146838 139.73796157691672 48.746 35.67150930369296 139.73796728657823 48.746 35.67150930369296 139.73796728657823 48.466 35.67151362966806 139.7379892748455 48.466 35.67151362966806 139.7379892748455 49.084 35.67150818146838 139.73796157691672 49.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9955047-a0ed-4644-a0fe-4ced11e0dd9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9955047-a0ed-4644-a0fe-4ced11e0dd9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9955047-a0ed-4644-a0fe-4ced11e0dd9d">
											<gml:posList>35.67151113972725 139.73796379372715 49.084 35.671515447579324 139.73798566050573 49.084 35.671515447579324 139.73798566050573 48.616 35.67151113972725 139.73796379372715 48.616 35.67151113972725 139.73796379372715 49.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c9fef3f-9d33-4c45-952b-aad8b931ddae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c9fef3f-9d33-4c45-952b-aad8b931ddae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c9fef3f-9d33-4c45-952b-aad8b931ddae">
											<gml:posList>35.67151113972725 139.73796379372715 48.616 35.671523755995985 139.73796006712368 48.616 35.671523755995985 139.73796006712368 49.084 35.67151113972725 139.73796379372715 49.084 35.67151113972725 139.73796379372715 48.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-407555de-7164-490b-b90f-58727e18a27c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-407555de-7164-490b-b90f-58727e18a27c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-407555de-7164-490b-b90f-58727e18a27c">
											<gml:posList>35.6715069497729 139.73801113259705 48.746 35.6715069497729 139.73801113259705 48.292 35.671528181157115 139.73800486612842 48.292 35.671528181157115 139.73800486612842 48.746 35.6715069497729 139.73801113259705 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9ea8a7a-88fe-4056-aa67-5fb8b8e4f6e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9ea8a7a-88fe-4056-aa67-5fb8b8e4f6e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9ea8a7a-88fe-4056-aa67-5fb8b8e4f6e5">
											<gml:posList>35.6715207398665 139.73798721175655 48.746 35.6715207398665 139.73798721175655 48.466 35.671523301078786 139.73800025452874 48.466 35.671523301078786 139.73800025452874 48.746 35.6715207398665 139.73798721175655 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed1f608e-cb16-48ba-b3f2-6ad8d7a16cd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed1f608e-cb16-48ba-b3f2-6ad8d7a16cd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed1f608e-cb16-48ba-b3f2-6ad8d7a16cd7">
											<gml:posList>35.67151362966806 139.7379892748455 49.084 35.67151362966806 139.7379892748455 48.466 35.6715207398665 139.73798721175655 48.466 35.6715207398665 139.73798721175655 48.746 35.671530941071204 139.73798426127775 48.746 35.671530941071204 139.73798426127775 49.084 35.67151362966806 139.7379892748455 49.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c3196116-4d0b-4786-8755-6be47e945117">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3196116-4d0b-4786-8755-6be47e945117">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3196116-4d0b-4786-8755-6be47e945117">
											<gml:posList>35.671523755995985 139.73796006712368 48.616 35.67152799180895 139.73798202236253 48.616 35.67152799180895 139.73798202236253 49.084 35.671523755995985 139.73796006712368 49.084 35.671523755995985 139.73796006712368 48.616</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6742bddb-69ca-4f40-a64c-247582b6375d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6742bddb-69ca-4f40-a64c-247582b6375d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6742bddb-69ca-4f40-a64c-247582b6375d">
											<gml:posList>35.671525573897625 139.73795644173637 49.084 35.671530941071204 139.73798426127775 49.084 35.671530941071204 139.73798426127775 48.746 35.67153343009533 139.73799720471962 48.746 35.67153448903851 139.73800268248385 48.746 35.67153534886629 139.73800713316805 48.746 35.67153534886629 139.73800713316805 10.69 35.671525573897625 139.73795644173637 10.69 35.671525573897625 139.73795644173637 49.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5cc6a6e-a22b-42f6-b0e5-4c83923c3254">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5cc6a6e-a22b-42f6-b0e5-4c83923c3254">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5cc6a6e-a22b-42f6-b0e5-4c83923c3254">
											<gml:posList>35.671528181157115 139.73800486612842 48.746 35.671528181157115 139.73800486612842 48.292 35.67153750288457 139.73805235464488 48.292 35.67153750288457 139.73805235464488 48.746 35.671528181157115 139.73800486612842 48.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c18d3ba-c4c8-47c3-b7f9-75994567a2fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c18d3ba-c4c8-47c3-b7f9-75994567a2fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c18d3ba-c4c8-47c3-b7f9-75994567a2fe">
											<gml:posList>35.67153318636047 139.73800812991686 10.69 35.67153534886629 139.73800713316805 10.69 35.67153534886629 139.73800713316805 48.746 35.67153318636047 139.73800812991686 48.746 35.67153318636047 139.73800812991686 10.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4dd4b14b-fa27-4aa8-882b-b6649d4f55ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4dd4b14b-fa27-4aa8-882b-b6649d4f55ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4dd4b14b-fa27-4aa8-882b-b6649d4f55ab">
											<gml:posList>35.671542616705786 139.73805619272142 10.69 35.67153318636047 139.73800812991686 10.69 35.67153318636047 139.73800812991686 48.746 35.671542616705786 139.73805619272142 48.746 35.671542616705786 139.73805619272142 10.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9922</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">152.79055</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>