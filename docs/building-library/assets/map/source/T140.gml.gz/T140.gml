<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_24e08a9d-fa5c-407d-8f7a-b05585a3668b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">6.8</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667592831763656 139.73834811199535 0 35.66757009413029 139.73833035507545 0 35.66757874320468 139.73831372078882 0 35.66750731054947 139.7382581342841 0 35.667483820559134 139.7383035606212 0 35.667439896770475 139.73826948098653 0 35.667432427410304 139.7382847331191 0 35.667410377339976 139.73832728577892 0 35.66756117942916 139.73844452471295 0 35.6675880896374 139.73839268771664 0 35.667575092601204 139.7383822316178 0 35.667592831763656 139.73834811199535 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667592831763656 139.73834811199535 14.614 35.667575092601204 139.7383822316178 14.614 35.6675880896374 139.73839268771664 14.614 35.66756117942916 139.73844452471295 14.614 35.667410377339976 139.73832728577892 14.614 35.667432427410304 139.7382847331191 14.614 35.667439896770475 139.73826948098653 14.614 35.667483820559134 139.7383035606212 14.614 35.66750731054947 139.7382581342841 14.614 35.66757874320468 139.73831372078882 14.614 35.66757009413029 139.73833035507545 14.614 35.667592831763656 139.73834811199535 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667592831763656 139.73834811199535 14.614 35.66757009413029 139.73833035507545 14.614 35.66757009413029 139.73833035507545 21.4 35.667592831763656 139.73834811199535 21.4 35.667592831763656 139.73834811199535 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757009413029 139.73833035507545 14.614 35.66757874320468 139.73831372078882 14.614 35.66757874320468 139.73831372078882 21.4 35.66757009413029 139.73833035507545 21.4 35.66757009413029 139.73833035507545 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757874320468 139.73831372078882 14.614 35.66750731054947 139.7382581342841 14.614 35.66750731054947 139.7382581342841 21.4 35.66757874320468 139.73831372078882 21.4 35.66757874320468 139.73831372078882 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66750731054947 139.7382581342841 14.614 35.667483820559134 139.7383035606212 14.614 35.667483820559134 139.7383035606212 21.4 35.66750731054947 139.7382581342841 21.4 35.66750731054947 139.7382581342841 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667483820559134 139.7383035606212 14.614 35.667439896770475 139.73826948098653 14.614 35.667439896770475 139.73826948098653 21.4 35.667483820559134 139.7383035606212 21.4 35.667483820559134 139.7383035606212 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667439896770475 139.73826948098653 14.614 35.667432427410304 139.7382847331191 14.614 35.667432427410304 139.7382847331191 21.4 35.667439896770475 139.73826948098653 21.4 35.667439896770475 139.73826948098653 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667432427410304 139.7382847331191 14.614 35.667410377339976 139.73832728577892 14.614 35.667410377339976 139.73832728577892 21.4 35.667432427410304 139.7382847331191 21.4 35.667432427410304 139.7382847331191 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667410377339976 139.73832728577892 14.614 35.66756117942916 139.73844452471295 14.614 35.66756117942916 139.73844452471295 21.4 35.667410377339976 139.73832728577892 21.4 35.667410377339976 139.73832728577892 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66756117942916 139.73844452471295 14.614 35.6675880896374 139.73839268771664 14.614 35.6675880896374 139.73839268771664 21.4 35.66756117942916 139.73844452471295 21.4 35.66756117942916 139.73844452471295 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6675880896374 139.73839268771664 14.614 35.667575092601204 139.7383822316178 14.614 35.667575092601204 139.7383822316178 21.4 35.6675880896374 139.73839268771664 21.4 35.6675880896374 139.73839268771664 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667575092601204 139.7383822316178 14.614 35.667592831763656 139.73834811199535 14.614 35.667592831763656 139.73834811199535 21.4 35.667575092601204 139.7383822316178 21.4 35.667575092601204 139.7383822316178 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667592831763656 139.73834811199535 21.4 35.66757009413029 139.73833035507545 21.4 35.66757874320468 139.73831372078882 21.4 35.66750731054947 139.7382581342841 21.4 35.667483820559134 139.7383035606212 21.4 35.667439896770475 139.73826948098653 21.4 35.667432427410304 139.7382847331191 21.4 35.667410377339976 139.73832728577892 21.4 35.66756117942916 139.73844452471295 21.4 35.6675880896374 139.73839268771664 21.4 35.667575092601204 139.7383822316178 21.4 35.667592831763656 139.73834811199535 21.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-49543065-2e45-49ba-a93d-7e3ae3b430fc"/>
							<gml:surfaceMember xlink:href="#poly-a6f8e2d1-276b-48cd-a468-cfc400335e85"/>
							<gml:surfaceMember xlink:href="#poly-8e8d6adc-d5d3-4c46-a1ea-db993aa5855d"/>
							<gml:surfaceMember xlink:href="#poly-b160fc18-225e-4420-b221-fbb99d47a6ba"/>
							<gml:surfaceMember xlink:href="#poly-5eda9977-6f7a-44be-a466-28e76fd3696f"/>
							<gml:surfaceMember xlink:href="#poly-911aa2cb-975b-4ba1-a968-b174d1b070eb"/>
							<gml:surfaceMember xlink:href="#poly-cad6a2f2-7bd1-4e3f-a361-35a49b39d090"/>
							<gml:surfaceMember xlink:href="#poly-c86e0ca4-c058-4eac-82ea-3f55a506919f"/>
							<gml:surfaceMember xlink:href="#poly-762ebf65-c085-45cb-b617-de0000975b37"/>
							<gml:surfaceMember xlink:href="#poly-03349be1-96e0-4eb6-8fff-24b9874d989d"/>
							<gml:surfaceMember xlink:href="#poly-1d57a948-d67a-4f48-9630-c0a0880dda48"/>
							<gml:surfaceMember xlink:href="#poly-c272222c-3cdb-4711-89ad-74e5eef7af60"/>
							<gml:surfaceMember xlink:href="#poly-d25a3cb5-708b-48aa-a904-67e49d41952c"/>
							<gml:surfaceMember xlink:href="#poly-dd8fc71d-3dbf-4c31-8d4b-99cd69789548"/>
							<gml:surfaceMember xlink:href="#poly-8dc1b3c4-1810-4b36-8ffe-a796a03489c5"/>
							<gml:surfaceMember xlink:href="#poly-d0862d07-a89c-4b4a-bd60-0678822250c2"/>
							<gml:surfaceMember xlink:href="#poly-b24be99f-90db-4504-8da6-9f7502599449"/>
							<gml:surfaceMember xlink:href="#poly-211ace8c-8ede-48d5-8f21-a64482954e77"/>
							<gml:surfaceMember xlink:href="#poly-e3f09ec7-8598-41e6-b767-4bc4ad4878a2"/>
							<gml:surfaceMember xlink:href="#poly-45f9f7d0-9e5f-4e48-9322-778bf76cf359"/>
							<gml:surfaceMember xlink:href="#poly-309ba1a5-bd34-4fe3-bae0-ab846be75b9e"/>
							<gml:surfaceMember xlink:href="#poly-64cb67f9-cf98-4398-9552-e5193d6fac78"/>
							<gml:surfaceMember xlink:href="#poly-77bd38f9-7952-4534-95e4-a0d5735e044d"/>
							<gml:surfaceMember xlink:href="#poly-efaf84ee-9840-4b6d-91ac-b7f6a0a0aae9"/>
							<gml:surfaceMember xlink:href="#poly-f8dd3ee3-0386-4737-8cfc-2e138b6e6523"/>
							<gml:surfaceMember xlink:href="#poly-30e075b0-53a0-4f33-9830-cf834b876d7b"/>
							<gml:surfaceMember xlink:href="#poly-7a17728e-a8ca-48ba-b9af-0ee3f07847a5"/>
							<gml:surfaceMember xlink:href="#poly-f976e1b0-2e79-400d-881e-ed6f1eab309a"/>
							<gml:surfaceMember xlink:href="#poly-be386503-988c-492e-82fe-e36ed1e9ccd8"/>
							<gml:surfaceMember xlink:href="#poly-521c4956-ec56-4ee8-adfb-cb81a53a47dd"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-49543065-2e45-49ba-a93d-7e3ae3b430fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49543065-2e45-49ba-a93d-7e3ae3b430fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49543065-2e45-49ba-a93d-7e3ae3b430fc">
											<gml:posList>35.66756117942914 139.73844452471295 14.614 35.667410377339955 139.73832728577892 14.614 35.66743242741028 139.73828473311906 14.614 35.66743989677044 139.73826948098653 14.614 35.66748382055909 139.7383035606212 14.614 35.66750731054945 139.73825813428408 14.614 35.667578743204665 139.73831372078882 14.614 35.667570094130305 139.73833035507545 14.614 35.667592831763656 139.73834811199535 14.614 35.667575092601204 139.7383822316178 14.614 35.66758808963739 139.7383926877166 14.614 35.66756117942914 139.73844452471295 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6f8e2d1-276b-48cd-a468-cfc400335e85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6f8e2d1-276b-48cd-a468-cfc400335e85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6f8e2d1-276b-48cd-a468-cfc400335e85">
											<gml:posList>35.66748382055909 139.7383035606212 19.631 35.66743989677044 139.73826948098653 19.631 35.66743242741028 139.73828473311906 19.631 35.667476080582425 139.73831855902483 19.631 35.66748382055909 139.7383035606212 19.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e8d6adc-d5d3-4c46-a1ea-db993aa5855d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e8d6adc-d5d3-4c46-a1ea-db993aa5855d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e8d6adc-d5d3-4c46-a1ea-db993aa5855d">
											<gml:posList>35.667578743204665 139.73831372078882 19.631 35.66750731054945 139.73825813428408 19.631 35.667490453563026 139.73829073956142 20.77 35.6675618680627 139.73834618250876 20.77 35.667578743204665 139.73831372078882 19.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b160fc18-225e-4420-b221-fbb99d47a6ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b160fc18-225e-4420-b221-fbb99d47a6ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b160fc18-225e-4420-b221-fbb99d47a6ba">
											<gml:posList>35.66754742283772 139.73837384743044 22.136 35.66743242741028 139.73828473311906 22.136 35.667421402377016 139.73830600945192 22.907 35.66754742283772 139.73837384743044 22.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5eda9977-6f7a-44be-a466-28e76fd3696f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5eda9977-6f7a-44be-a466-28e76fd3696f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5eda9977-6f7a-44be-a466-28e76fd3696f">
											<gml:posList>35.667476080582425 139.73831855902483 19.631 35.66754742283772 139.73837384743044 19.625 35.667552534933726 139.73836407682768 20.034 35.667554217939326 139.73836082734866 20.165 35.6675618680627 139.73834618250876 20.77 35.667490453563026 139.73829073956142 20.77 35.667476080582425 139.73831855902483 19.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-911aa2cb-975b-4ba1-a968-b174d1b070eb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-911aa2cb-975b-4ba1-a968-b174d1b070eb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-911aa2cb-975b-4ba1-a968-b174d1b070eb">
											<gml:posList>35.66756380927838 139.73837317631853 21.439 35.66758146745418 139.73833923352876 21.439 35.667570094130305 139.73833035507545 20.165 35.667554217939326 139.73836082734866 20.165 35.667552525937424 139.73836409893008 20.165 35.66756380927838 139.73837317631853 21.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cad6a2f2-7bd1-4e3f-a361-35a49b39d090">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cad6a2f2-7bd1-4e3f-a361-35a49b39d090">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cad6a2f2-7bd1-4e3f-a361-35a49b39d090">
											<gml:posList>35.66754742283772 139.73837384743044 22.136 35.667421402377016 139.73830600945192 22.907 35.6675820955959 139.7384042377517 22.136 35.66754742283772 139.73837384743044 22.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c86e0ca4-c058-4eac-82ea-3f55a506919f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c86e0ca4-c058-4eac-82ea-3f55a506919f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c86e0ca4-c058-4eac-82ea-3f55a506919f">
											<gml:posList>35.667421402377016 139.73830600945192 22.907 35.66757163750985 139.73842437571201 22.907 35.6675820955959 139.7384042377517 22.136 35.667421402377016 139.73830600945192 22.907</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-762ebf65-c085-45cb-b617-de0000975b37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-762ebf65-c085-45cb-b617-de0000975b37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-762ebf65-c085-45cb-b617-de0000975b37">
											<gml:posList>35.667410377339955 139.73832728577892 22.136 35.66756117942914 139.73844452471295 22.136 35.66757163750985 139.73842437571201 22.907 35.667421402377016 139.73830600945192 22.907 35.667410377339955 139.73832728577892 22.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03349be1-96e0-4eb6-8fff-24b9874d989d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03349be1-96e0-4eb6-8fff-24b9874d989d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03349be1-96e0-4eb6-8fff-24b9874d989d">
											<gml:posList>35.66754742283772 139.73837384743044 19.625 35.6675820955959 139.7384042377517 19.625 35.66758808963739 139.7383926877166 19.625 35.667575092609916 139.73838224266368 19.625 35.667552525937424 139.73836409893008 19.625 35.66754742283772 139.73837384743044 19.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d57a948-d67a-4f48-9630-c0a0880dda48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d57a948-d67a-4f48-9630-c0a0880dda48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d57a948-d67a-4f48-9630-c0a0880dda48">
											<gml:posList>35.667575092601204 139.7383822316178 20.165 35.667592831763656 139.73834811199535 20.165 35.66758146745418 139.73833923352876 21.439 35.66756380927838 139.73837317631853 21.439 35.667575092601204 139.7383822316178 20.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c272222c-3cdb-4711-89ad-74e5eef7af60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c272222c-3cdb-4711-89ad-74e5eef7af60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c272222c-3cdb-4711-89ad-74e5eef7af60">
											<gml:posList>35.66756380927838 139.73837317631853 21.439 35.667552525937424 139.73836409893008 20.165 35.667552534933726 139.73836407682768 20.034 35.66756380927838 139.73837317631853 21.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d25a3cb5-708b-48aa-a904-67e49d41952c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d25a3cb5-708b-48aa-a904-67e49d41952c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d25a3cb5-708b-48aa-a904-67e49d41952c">
											<gml:posList>35.66756380927838 139.73837317631853 21.439 35.667552534933726 139.73836407682768 20.034 35.667552525937424 139.73836409893008 19.625 35.66756380927838 139.73837317631853 21.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd8fc71d-3dbf-4c31-8d4b-99cd69789548">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd8fc71d-3dbf-4c31-8d4b-99cd69789548">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd8fc71d-3dbf-4c31-8d4b-99cd69789548">
											<gml:posList>35.66756380927838 139.73837317631853 21.439 35.667552525937424 139.73836409893008 19.625 35.667575092609916 139.73838224266368 19.625 35.66756380927838 139.73837317631853 21.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8dc1b3c4-1810-4b36-8ffe-a796a03489c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dc1b3c4-1810-4b36-8ffe-a796a03489c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dc1b3c4-1810-4b36-8ffe-a796a03489c5">
											<gml:posList>35.66743989677044 139.73826948098653 14.614 35.66743242741028 139.73828473311906 14.614 35.66743242741028 139.73828473311906 19.631 35.66743989677044 139.73826948098653 19.631 35.66743989677044 139.73826948098653 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0862d07-a89c-4b4a-bd60-0678822250c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0862d07-a89c-4b4a-bd60-0678822250c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0862d07-a89c-4b4a-bd60-0678822250c2">
											<gml:posList>35.667578743204665 139.73831372078882 14.614 35.66750731054945 139.73825813428408 14.614 35.66750731054945 139.73825813428408 19.631 35.667578743204665 139.73831372078882 19.631 35.667578743204665 139.73831372078882 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b24be99f-90db-4504-8da6-9f7502599449">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b24be99f-90db-4504-8da6-9f7502599449">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b24be99f-90db-4504-8da6-9f7502599449">
											<gml:posList>35.66748382055909 139.7383035606212 14.614 35.66743989677044 139.73826948098653 14.614 35.66743989677044 139.73826948098653 19.631 35.66748382055909 139.7383035606212 19.631 35.66748382055909 139.7383035606212 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-211ace8c-8ede-48d5-8f21-a64482954e77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-211ace8c-8ede-48d5-8f21-a64482954e77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-211ace8c-8ede-48d5-8f21-a64482954e77">
											<gml:posList>35.66748382055909 139.7383035606212 19.631 35.667476080582425 139.73831855902483 19.631 35.667490453563026 139.73829073956142 20.77 35.66750731054945 139.73825813428408 19.631 35.66750731054945 139.73825813428408 14.614 35.66748382055909 139.7383035606212 14.614 35.66748382055909 139.7383035606212 19.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3f09ec7-8598-41e6-b767-4bc4ad4878a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3f09ec7-8598-41e6-b767-4bc4ad4878a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3f09ec7-8598-41e6-b767-4bc4ad4878a2">
											<gml:posList>35.667410377339955 139.73832728577892 22.136 35.667421402377016 139.73830600945192 22.907 35.66743242741028 139.73828473311906 22.136 35.66743242741028 139.73828473311906 19.631 35.66743242741028 139.73828473311906 14.614 35.667410377339955 139.73832728577892 14.614 35.667410377339955 139.73832728577892 22.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45f9f7d0-9e5f-4e48-9322-778bf76cf359">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45f9f7d0-9e5f-4e48-9322-778bf76cf359">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45f9f7d0-9e5f-4e48-9322-778bf76cf359">
											<gml:posList>35.66743242741028 139.73828473311906 22.136 35.66754742283772 139.73837384743044 22.136 35.66754742283772 139.73837384743044 19.625 35.667476080582425 139.73831855902483 19.631 35.66743242741028 139.73828473311906 19.631 35.66743242741028 139.73828473311906 22.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-309ba1a5-bd34-4fe3-bae0-ab846be75b9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-309ba1a5-bd34-4fe3-bae0-ab846be75b9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-309ba1a5-bd34-4fe3-bae0-ab846be75b9e">
											<gml:posList>35.667570094130305 139.73833035507545 20.165 35.667570094130305 139.73833035507545 14.614 35.667578743204665 139.73831372078882 14.614 35.667578743204665 139.73831372078882 19.631 35.6675618680627 139.73834618250876 20.77 35.667554217939326 139.73836082734866 20.165 35.667570094130305 139.73833035507545 20.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-64cb67f9-cf98-4398-9552-e5193d6fac78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64cb67f9-cf98-4398-9552-e5193d6fac78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64cb67f9-cf98-4398-9552-e5193d6fac78">
											<gml:posList>35.667592831763656 139.73834811199535 14.614 35.667570094130305 139.73833035507545 14.614 35.667570094130305 139.73833035507545 20.165 35.66758146745418 139.73833923352876 21.439 35.667592831763656 139.73834811199535 20.165 35.667592831763656 139.73834811199535 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77bd38f9-7952-4534-95e4-a0d5735e044d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77bd38f9-7952-4534-95e4-a0d5735e044d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77bd38f9-7952-4534-95e4-a0d5735e044d">
											<gml:posList>35.667552525937424 139.73836409893008 20.165 35.667554217939326 139.73836082734866 20.165 35.667552534933726 139.73836407682768 20.034 35.667552525937424 139.73836409893008 20.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efaf84ee-9840-4b6d-91ac-b7f6a0a0aae9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efaf84ee-9840-4b6d-91ac-b7f6a0a0aae9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efaf84ee-9840-4b6d-91ac-b7f6a0a0aae9">
											<gml:posList>35.667592831763656 139.73834811199535 20.165 35.667575092601204 139.7383822316178 20.165 35.667575092609916 139.73838224266368 19.625 35.667575092601204 139.7383822316178 14.614 35.667592831763656 139.73834811199535 14.614 35.667592831763656 139.73834811199535 20.165</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8dd3ee3-0386-4737-8cfc-2e138b6e6523">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8dd3ee3-0386-4737-8cfc-2e138b6e6523">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8dd3ee3-0386-4737-8cfc-2e138b6e6523">
											<gml:posList>35.66754742283772 139.73837384743044 19.625 35.667552525937424 139.73836409893008 19.625 35.667552534933726 139.73836407682768 20.034 35.66754742283772 139.73837384743044 19.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30e075b0-53a0-4f33-9830-cf834b876d7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30e075b0-53a0-4f33-9830-cf834b876d7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30e075b0-53a0-4f33-9830-cf834b876d7b">
											<gml:posList>35.66756380927838 139.73837317631853 21.439 35.667575092609916 139.73838224266368 19.625 35.667575092601204 139.7383822316178 20.165 35.66756380927838 139.73837317631853 21.439</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a17728e-a8ca-48ba-b9af-0ee3f07847a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a17728e-a8ca-48ba-b9af-0ee3f07847a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a17728e-a8ca-48ba-b9af-0ee3f07847a5">
											<gml:posList>35.667410377339955 139.73832728577892 14.614 35.66756117942914 139.73844452471295 14.614 35.66756117942914 139.73844452471295 22.136 35.667410377339955 139.73832728577892 22.136 35.667410377339955 139.73832728577892 14.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f976e1b0-2e79-400d-881e-ed6f1eab309a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f976e1b0-2e79-400d-881e-ed6f1eab309a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f976e1b0-2e79-400d-881e-ed6f1eab309a">
											<gml:posList>35.667575092609916 139.73838224266368 19.625 35.66758808963739 139.7383926877166 19.625 35.66758808963739 139.7383926877166 14.614 35.667575092601204 139.7383822316178 14.614 35.667575092609916 139.73838224266368 19.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be386503-988c-492e-82fe-e36ed1e9ccd8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be386503-988c-492e-82fe-e36ed1e9ccd8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be386503-988c-492e-82fe-e36ed1e9ccd8">
											<gml:posList>35.6675820955959 139.7384042377517 19.625 35.66754742283772 139.73837384743044 19.625 35.66754742283772 139.73837384743044 22.136 35.6675820955959 139.7384042377517 22.136 35.6675820955959 139.7384042377517 19.625</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-521c4956-ec56-4ee8-adfb-cb81a53a47dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-521c4956-ec56-4ee8-adfb-cb81a53a47dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-521c4956-ec56-4ee8-adfb-cb81a53a47dd">
											<gml:posList>35.66757163750985 139.73842437571201 22.907 35.66756117942914 139.73844452471295 22.136 35.66756117942914 139.73844452471295 14.614 35.66758808963739 139.7383926877166 14.614 35.66758808963739 139.7383926877166 19.625 35.6675820955959 139.7384042377517 19.625 35.6675820955959 139.7384042377517 22.136 35.66757163750985 139.73842437571201 22.907</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1613</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">95.32415</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">2</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">22</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>