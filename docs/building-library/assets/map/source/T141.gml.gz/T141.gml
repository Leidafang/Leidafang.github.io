<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_25350710-9a23-4137-99c3-9fdd8a45341b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66806767154703 139.73892791427943 0 35.66804841390771 139.73895692149395 0 35.668078543382364 139.738987041454 0 35.6680829549151 139.7389804086976 0 35.66808931455964 139.73898674158588 0 35.668103368375604 139.73896552788023 0 35.66813768432698 139.7390008897651 0 35.66814652478694 139.73900982658552 0 35.66826158449161 139.73883660092685 0 35.66818138959995 139.73875661225287 0 35.668096328411394 139.73888474612627 0 35.66809226905512 139.73888069704628 0 35.66808877079376 139.73887950820512 0 35.66808325425501 139.73887933796829 0 35.66807663917671 139.73888061604393 0 35.66807135137737 139.73888477554652 0 35.66806661413423 139.73888985121323 0 35.66806358008659 139.7388944167601 0 35.66806072009744 139.73890254994015 0 35.66805969833617 139.73890995192298 0 35.66806000073471 139.7389162587984 0 35.66806205160518 139.73892232060453 0 35.66806767154703 139.73892791427943 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66806767154703 139.73892791427943 12.92 35.66806205160518 139.73892232060453 12.92 35.66806000073471 139.7389162587984 12.92 35.66805969833617 139.73890995192298 12.92 35.66806072009744 139.73890254994015 12.92 35.66806358008659 139.7388944167601 12.92 35.66806661413423 139.73888985121323 12.92 35.66807135137737 139.73888477554652 12.92 35.66807663917671 139.73888061604393 12.92 35.66808325425501 139.73887933796829 12.92 35.66808877079376 139.73887950820512 12.92 35.66809226905512 139.73888069704628 12.92 35.668096328411394 139.73888474612627 12.92 35.66818138959995 139.73875661225287 12.92 35.66826158449161 139.73883660092685 12.92 35.66814652478694 139.73900982658552 12.92 35.66813768432698 139.7390008897651 12.92 35.668103368375604 139.73896552788023 12.92 35.66808931455964 139.73898674158588 12.92 35.6680829549151 139.7389804086976 12.92 35.668078543382364 139.738987041454 12.92 35.66804841390771 139.73895692149395 12.92 35.66806767154703 139.73892791427943 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66806767154703 139.73892791427943 12.92 35.66804841390771 139.73895692149395 12.92 35.66804841390771 139.73895692149395 29.61 35.66806767154703 139.73892791427943 29.61 35.66806767154703 139.73892791427943 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66804841390771 139.73895692149395 12.92 35.668078543382364 139.738987041454 12.92 35.668078543382364 139.738987041454 29.61 35.66804841390771 139.73895692149395 29.61 35.66804841390771 139.73895692149395 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668078543382364 139.738987041454 12.92 35.6680829549151 139.7389804086976 12.92 35.6680829549151 139.7389804086976 29.61 35.668078543382364 139.738987041454 29.61 35.668078543382364 139.738987041454 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6680829549151 139.7389804086976 12.92 35.66808931455964 139.73898674158588 12.92 35.66808931455964 139.73898674158588 29.61 35.6680829549151 139.7389804086976 29.61 35.6680829549151 139.7389804086976 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66808931455964 139.73898674158588 12.92 35.668103368375604 139.73896552788023 12.92 35.668103368375604 139.73896552788023 29.61 35.66808931455964 139.73898674158588 29.61 35.66808931455964 139.73898674158588 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668103368375604 139.73896552788023 12.92 35.66813768432698 139.7390008897651 12.92 35.66813768432698 139.7390008897651 29.61 35.668103368375604 139.73896552788023 29.61 35.668103368375604 139.73896552788023 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66813768432698 139.7390008897651 12.92 35.66814652478694 139.73900982658552 12.92 35.66814652478694 139.73900982658552 29.61 35.66813768432698 139.7390008897651 29.61 35.66813768432698 139.7390008897651 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66814652478694 139.73900982658552 12.92 35.66826158449161 139.73883660092685 12.92 35.66826158449161 139.73883660092685 29.61 35.66814652478694 139.73900982658552 29.61 35.66814652478694 139.73900982658552 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66826158449161 139.73883660092685 12.92 35.66818138959995 139.73875661225287 12.92 35.66818138959995 139.73875661225287 29.61 35.66826158449161 139.73883660092685 29.61 35.66826158449161 139.73883660092685 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66818138959995 139.73875661225287 12.92 35.668096328411394 139.73888474612627 12.92 35.668096328411394 139.73888474612627 29.61 35.66818138959995 139.73875661225287 29.61 35.66818138959995 139.73875661225287 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668096328411394 139.73888474612627 12.92 35.66809226905512 139.73888069704628 12.92 35.66809226905512 139.73888069704628 29.61 35.668096328411394 139.73888474612627 29.61 35.668096328411394 139.73888474612627 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66809226905512 139.73888069704628 12.92 35.66808877079376 139.73887950820512 12.92 35.66808877079376 139.73887950820512 29.61 35.66809226905512 139.73888069704628 29.61 35.66809226905512 139.73888069704628 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66808877079376 139.73887950820512 12.92 35.66808325425501 139.73887933796829 12.92 35.66808325425501 139.73887933796829 29.61 35.66808877079376 139.73887950820512 29.61 35.66808877079376 139.73887950820512 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66808325425501 139.73887933796829 12.92 35.66807663917671 139.73888061604393 12.92 35.66807663917671 139.73888061604393 29.61 35.66808325425501 139.73887933796829 29.61 35.66808325425501 139.73887933796829 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66807663917671 139.73888061604393 12.92 35.66807135137737 139.73888477554652 12.92 35.66807135137737 139.73888477554652 29.61 35.66807663917671 139.73888061604393 29.61 35.66807663917671 139.73888061604393 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66807135137737 139.73888477554652 12.92 35.66806661413423 139.73888985121323 12.92 35.66806661413423 139.73888985121323 29.61 35.66807135137737 139.73888477554652 29.61 35.66807135137737 139.73888477554652 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66806661413423 139.73888985121323 12.92 35.66806358008659 139.7388944167601 12.92 35.66806358008659 139.7388944167601 29.61 35.66806661413423 139.73888985121323 29.61 35.66806661413423 139.73888985121323 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66806358008659 139.7388944167601 12.92 35.66806072009744 139.73890254994015 12.92 35.66806072009744 139.73890254994015 29.61 35.66806358008659 139.7388944167601 29.61 35.66806358008659 139.7388944167601 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66806072009744 139.73890254994015 12.92 35.66805969833617 139.73890995192298 12.92 35.66805969833617 139.73890995192298 29.61 35.66806072009744 139.73890254994015 29.61 35.66806072009744 139.73890254994015 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66805969833617 139.73890995192298 12.92 35.66806000073471 139.7389162587984 12.92 35.66806000073471 139.7389162587984 29.61 35.66805969833617 139.73890995192298 29.61 35.66805969833617 139.73890995192298 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66806000073471 139.7389162587984 12.92 35.66806205160518 139.73892232060453 12.92 35.66806205160518 139.73892232060453 29.61 35.66806000073471 139.7389162587984 29.61 35.66806000073471 139.7389162587984 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66806205160518 139.73892232060453 12.92 35.66806767154703 139.73892791427943 12.92 35.66806767154703 139.73892791427943 29.61 35.66806205160518 139.73892232060453 29.61 35.66806205160518 139.73892232060453 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66806767154703 139.73892791427943 29.61 35.66804841390771 139.73895692149395 29.61 35.668078543382364 139.738987041454 29.61 35.6680829549151 139.7389804086976 29.61 35.66808931455964 139.73898674158588 29.61 35.668103368375604 139.73896552788023 29.61 35.66813768432698 139.7390008897651 29.61 35.66814652478694 139.73900982658552 29.61 35.66826158449161 139.73883660092685 29.61 35.66818138959995 139.73875661225287 29.61 35.668096328411394 139.73888474612627 29.61 35.66809226905512 139.73888069704628 29.61 35.66808877079376 139.73887950820512 29.61 35.66808325425501 139.73887933796829 29.61 35.66807663917671 139.73888061604393 29.61 35.66807135137737 139.73888477554652 29.61 35.66806661413423 139.73888985121323 29.61 35.66806358008659 139.7388944167601 29.61 35.66806072009744 139.73890254994015 29.61 35.66805969833617 139.73890995192298 29.61 35.66806000073471 139.7389162587984 29.61 35.66806205160518 139.73892232060453 29.61 35.66806767154703 139.73892791427943 29.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-34df0efe-f438-4129-aaeb-5c5d65fbf610"/>
							<gml:surfaceMember xlink:href="#poly-12613074-809b-474e-bc10-b528f9e9528d"/>
							<gml:surfaceMember xlink:href="#poly-7f406986-53fb-4cbe-9edd-445974d949fe"/>
							<gml:surfaceMember xlink:href="#poly-fc4e617f-d41f-4e2f-9b9c-a54f4fda9b46"/>
							<gml:surfaceMember xlink:href="#poly-45a5894c-319e-4159-8f1c-fc1a104f3ded"/>
							<gml:surfaceMember xlink:href="#poly-8b4af985-4bc1-43b6-8c0b-ecf42334893c"/>
							<gml:surfaceMember xlink:href="#poly-f90521d9-d44d-4e5c-a97d-43aaf2bd30b1"/>
							<gml:surfaceMember xlink:href="#poly-8e15d9e1-d07b-4b58-8600-62e21a364d1b"/>
							<gml:surfaceMember xlink:href="#poly-140dd5b3-8926-44a0-942e-003b3493e2d7"/>
							<gml:surfaceMember xlink:href="#poly-2bf229e8-5b49-4154-81d0-32ec79570243"/>
							<gml:surfaceMember xlink:href="#poly-1992c709-2bec-4ca1-a1f0-a8c647694a2c"/>
							<gml:surfaceMember xlink:href="#poly-e5c431f6-bb46-428d-a4a4-ab447b6448b2"/>
							<gml:surfaceMember xlink:href="#poly-c29b2fff-091a-48a6-9a73-72b0dd9308fd"/>
							<gml:surfaceMember xlink:href="#poly-cd5a026e-7801-4c46-b551-931de28c6963"/>
							<gml:surfaceMember xlink:href="#poly-b15e660c-aeb6-4b02-83b8-09c4a11a3956"/>
							<gml:surfaceMember xlink:href="#poly-b6c8a8fd-088f-4058-bbf1-ba2c8527c1fe"/>
							<gml:surfaceMember xlink:href="#poly-5ff24cca-f762-433b-9d50-88b7a36648ab"/>
							<gml:surfaceMember xlink:href="#poly-ea47ef1c-0bff-4540-98a1-d42a8066e9a0"/>
							<gml:surfaceMember xlink:href="#poly-be1e392a-81ec-472f-8ce0-00aca1cda479"/>
							<gml:surfaceMember xlink:href="#poly-450e5e23-75cb-4145-bd5f-a745daee1493"/>
							<gml:surfaceMember xlink:href="#poly-16b37a85-49e9-4e90-bf86-1d152e309d64"/>
							<gml:surfaceMember xlink:href="#poly-ea69489d-3432-443b-8a1f-f3cce14586e4"/>
							<gml:surfaceMember xlink:href="#poly-65f8d002-d684-4d66-8ec3-9e8d3685b059"/>
							<gml:surfaceMember xlink:href="#poly-3127002d-f534-4c7b-9078-426612ed43f5"/>
							<gml:surfaceMember xlink:href="#poly-3955ecf9-d242-47eb-9f1f-3d9b7b75afbb"/>
							<gml:surfaceMember xlink:href="#poly-26051d79-118d-441d-aa78-d379f94552a5"/>
							<gml:surfaceMember xlink:href="#poly-fc3787ac-fda6-49f8-a969-c7f849993a4c"/>
							<gml:surfaceMember xlink:href="#poly-50cf3e44-8067-4f78-b75b-af2b24fd6ad1"/>
							<gml:surfaceMember xlink:href="#poly-410e88ea-b3ad-4527-af4a-e949a3be54a7"/>
							<gml:surfaceMember xlink:href="#poly-84373f32-c52f-491b-98b1-c06ef0617a3f"/>
							<gml:surfaceMember xlink:href="#poly-fcbf37bb-c198-456f-a177-5df68e3f34c9"/>
							<gml:surfaceMember xlink:href="#poly-86f51662-0b11-4bd5-9c22-8595876b69f2"/>
							<gml:surfaceMember xlink:href="#poly-abc5d61b-2931-438f-9b96-511d3dd2d849"/>
							<gml:surfaceMember xlink:href="#poly-f17ca0e3-c3f6-41b4-997b-9d560eed6c8b"/>
							<gml:surfaceMember xlink:href="#poly-0634a60f-8db7-46e4-af4b-aa73a19c5ba2"/>
							<gml:surfaceMember xlink:href="#poly-25c467bc-6ffb-4d05-a576-1f77657c43d1"/>
							<gml:surfaceMember xlink:href="#poly-528ae093-8318-4036-a347-c22dc94c3a56"/>
							<gml:surfaceMember xlink:href="#poly-b8a03de4-541b-4ab9-a16b-4b253dc9f032"/>
							<gml:surfaceMember xlink:href="#poly-feb1080e-dbc4-475a-9da3-3d5104e210c0"/>
							<gml:surfaceMember xlink:href="#poly-c6b383c9-37e7-4b74-bb95-1bdd1228f61a"/>
							<gml:surfaceMember xlink:href="#poly-4e341c7c-eff0-4b81-a48f-9635cfb64313"/>
							<gml:surfaceMember xlink:href="#poly-4b40ff9c-0587-483a-9124-c74431502496"/>
							<gml:surfaceMember xlink:href="#poly-47529900-d1bd-404b-9827-c6a4f410adae"/>
							<gml:surfaceMember xlink:href="#poly-c8ad8ba0-3fcc-4b7a-8661-23352533f920"/>
							<gml:surfaceMember xlink:href="#poly-ba470aa3-9e43-4765-ba40-4d38d887d1da"/>
							<gml:surfaceMember xlink:href="#poly-ba634bab-9772-46d1-9fe7-2d01985941be"/>
							<gml:surfaceMember xlink:href="#poly-d142d4c9-772d-4966-b15d-bdb7a7abeb9f"/>
							<gml:surfaceMember xlink:href="#poly-303ac92e-4f24-45e7-9d9e-eea6d9459176"/>
							<gml:surfaceMember xlink:href="#poly-8a36d13f-0843-453a-bac1-4a79a009a7cb"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_25350710-9a23-4137-99c3-9fdd8a45341b_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-232cf22b-de42-48b5-84ee-e24681354d0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-232cf22b-de42-48b5-84ee-e24681354d0d_0">
											<gml:posList>35.66807676282084 139.73893484042733 31.238 35.66807676282084 139.73893484042733 29.635 35.6681840535844 139.7387743710091 29.635 35.6681840535844 139.7387743710091 31.238 35.66807676282084 139.73893484042733 31.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72cba38f-21d7-4b88-9dea-a39e4a1f304e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72cba38f-21d7-4b88-9dea-a39e4a1f304e_0">
											<gml:posList>35.668246983053834 139.73883763436345 31.238 35.668246983053834 139.73883763436345 29.635 35.66814055636526 139.7389966226493 29.635 35.66814055636526 139.7389966226493 31.238 35.668246983053834 139.73883763436345 31.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae379048-1504-4c30-98e3-b729d911d06c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae379048-1504-4c30-98e3-b729d911d06c_0">
											<gml:posList>35.66824972256759 139.73883679164157 31.238 35.66824972256759 139.73883679164157 29.635 35.66818369894373 139.73877041697483 29.635 35.66818369894373 139.73877041697483 31.238 35.66824972256759 139.73883679164157 31.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8406283f-cfc0-4ffd-a80d-01211c75e151">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8406283f-cfc0-4ffd-a80d-01211c75e151_0">
											<gml:posList>35.668246983053834 139.73883763436345 31.238 35.6681840535844 139.7387743710091 31.238 35.6681840535844 139.7387743710091 29.635 35.668246983053834 139.73883763436345 29.635 35.668246983053834 139.73883763436345 31.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-437a0cb0-9c84-4347-b0c0-4361d084d794">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-437a0cb0-9c84-4347-b0c0-4361d084d794_0">
											<gml:posList>35.66807495866422 139.7389330420628 31.238 35.66818369894373 139.73877041697483 31.238 35.66818369894373 139.73877041697483 29.635 35.66807495866422 139.7389330420628 29.635 35.66807495866422 139.7389330420628 31.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aece41a2-26af-4fd8-bb13-b66f930f50a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aece41a2-26af-4fd8-bb13-b66f930f50a9_0">
											<gml:posList>35.668116175370905 139.7389750896442 31.238 35.66814066694429 139.73899970433945 31.238 35.66824972256759 139.73883679164157 31.238 35.66818369894373 139.73877041697483 31.238 35.66807495866422 139.7389330420628 31.238 35.66807676282084 139.73893484042733 31.238 35.6681840535844 139.7387743710091 31.238 35.668246983053834 139.73883763436345 31.238 35.66814055636526 139.7389966226493 31.238 35.66811737280286 139.73897330983755 31.238 35.668116175370905 139.7389750896442 31.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02a5a2fc-c54b-4dd9-a449-fbf06944a1d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02a5a2fc-c54b-4dd9-a449-fbf06944a1d0_0">
											<gml:posList>35.66824972256759 139.73883679164157 31.238 35.66814066694429 139.73899970433945 31.238 35.66814066694429 139.73899970433945 29.635 35.66824972256759 139.73883679164157 29.635 35.66824972256759 139.73883679164157 31.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2422054-492f-40e9-8d34-0fc0f2cb875e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2422054-492f-40e9-8d34-0fc0f2cb875e_0">
											<gml:posList>35.66807676282084 139.73893484042733 31.238 35.66807495866422 139.7389330420628 31.238 35.66807495866422 139.7389330420628 29.635 35.66807676282084 139.73893484042733 29.635 35.66807676282084 139.73893484042733 31.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25811e87-a2fb-4608-8cfd-cc7fd8942bfe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25811e87-a2fb-4608-8cfd-cc7fd8942bfe_0">
											<gml:posList>35.668116175370905 139.7389750896442 29.635 35.668116175370905 139.7389750896442 31.238 35.66811737280286 139.73897330983755 31.238 35.66811737280286 139.73897330983755 29.635 35.668116175370905 139.7389750896442 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d12a9307-56ba-438f-a9e0-7e2f21ef914c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d12a9307-56ba-438f-a9e0-7e2f21ef914c_0">
											<gml:posList>35.66811737280286 139.73897330983755 31.238 35.66814055636526 139.7389966226493 31.238 35.66814055636526 139.7389966226493 29.635 35.66811737280286 139.73897330983755 29.635 35.66811737280286 139.73897330983755 31.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcf94f28-1c4b-4787-9485-8ae428570737">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcf94f28-1c4b-4787-9485-8ae428570737_0">
											<gml:posList>35.66814066694429 139.73899970433945 31.238 35.668116175370905 139.7389750896442 31.238 35.668116175370905 139.7389750896442 29.635 35.66814066694429 139.73899970433945 29.635 35.66814066694429 139.73899970433945 31.238</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5860f6a3-40ba-4d8a-ad05-cbd7adce617f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66814066694429 139.73899970433945 29.635 35.668116175370905 139.7389750896442 29.635 35.66811737280286 139.73897330983755 29.635 35.66814055636526 139.7389966226493 29.635 35.668246983053834 139.73883763436345 29.635 35.6681840535844 139.7387743710091 29.635 35.66807676282084 139.73893484042733 29.635 35.66807495866422 139.7389330420628 29.635 35.66818369894373 139.73877041697483 29.635 35.66824972256759 139.73883679164157 29.635 35.66814066694429 139.73899970433945 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_25350710-9a23-4137-99c3-9fdd8a45341b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ff3c597-dd1f-4b9a-9779-5ee13587cec3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66818896405265 139.73880624385137 29.635 35.668182081143065 139.73879932615077 29.635 35.66818661874479 139.7387925496294 29.635 35.66819350165476 139.7387994673298 29.635 35.66818896405265 139.73880624385137 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6346e7a-0ef1-4f73-8231-0c6dfb1d4506">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66818896405265 139.73880624385137 29.635 35.66819350165476 139.7387994673298 29.635 35.66819350165476 139.7387994673298 31.733 35.66818896405265 139.73880624385137 31.733 35.66818896405265 139.73880624385137 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55d8484a-98c6-4ba7-b93d-b56d491317d0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66819685741416 139.7388028434368 29.635 35.66819231981187 139.73880961995843 29.635 35.66819231981187 139.73880961995843 31.733 35.66819685741416 139.7388028434368 31.733 35.66819685741416 139.7388028434368 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33f46e01-8453-47e0-ad03-9e1a094a1003">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66819942823739 139.73881675831413 29.635 35.66819231981187 139.73880961995843 29.635 35.66819685741416 139.7388028434368 29.635 35.66820396584008 139.73880998179231 29.635 35.66819942823739 139.73881675831413 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-098ea7b9-8310-44e8-b05b-bd5d8f53a633">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668169071396896 139.73881856144988 29.635 35.66817411317007 139.7388110221655 29.635 35.668181672637274 139.73881861287225 29.635 35.6681766308723 139.73882616320284 29.635 35.668169071396896 139.73881856144988 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dea0bbf1-2aa3-4dfc-bc98-8df2d5c769a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66820255847977 139.73881991376876 29.635 35.66820710509636 139.7388131372362 29.635 35.66821411430132 139.73882018734278 29.635 35.66820957669807 139.7388269638649 29.635 35.66820255847977 139.73881991376876 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b8fe2ff-10b6-4403-b886-97eee08bf452">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6681766308723 139.73882616320284 29.635 35.668181672637274 139.73881861287225 29.635 35.668181672637274 139.73881861287225 31.733 35.6681766308723 139.73882616320284 31.733 35.6681766308723 139.73882616320284 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1a806b8-66db-4bef-893e-bc06b89ced0a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668184396941186 139.73882136010428 29.635 35.668179355167375 139.738828899389 29.635 35.668179355167375 139.738828899389 31.733 35.668184396941186 139.73882136010428 31.733 35.668184396941186 139.73882136010428 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-160d1d15-9573-4c20-96ce-062154ead33d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668184396941186 139.73882136010428 29.635 35.668191424181806 139.73882842123433 29.635 35.66818637339383 139.73883596052988 29.635 35.668179355167375 139.738828899389 29.635 35.668184396941186 139.73882136010428 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3de4f30d-b633-4616-ba4f-06d42b533383">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66821600856435 139.7388334292174 29.635 35.668220510147734 139.73882669692142 29.635 35.66822776290452 139.73883397870856 29.635 35.668223252307 139.73884071101537 29.635 35.66821600856435 139.7388334292174 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-205b175f-797b-4943-a618-8e774218ccb2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66819423868343 139.73883124568243 29.635 35.668201491448634 139.73883853851356 29.635 35.66819644066003 139.73884607780943 29.635 35.66818918789527 139.73883878497807 29.635 35.66819423868343 139.73883124568243 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffc72c38-4886-463f-a6cb-d43e20e2851a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66823315720435 139.738850673848 29.635 35.66822594052082 139.73884341410826 29.635 35.668230550139434 139.73883651599525 29.635 35.668237775837106 139.73884377572412 29.635 35.66823315720435 139.738850673848 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3390f79-454a-4b41-9f8b-82e42376356c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668203016857575 139.7388526865898 29.635 35.66820793259672 139.73884534628013 29.635 35.66821514928015 139.73885260601844 29.635 35.66821023354057 139.7388599463283 29.635 35.668203016857575 139.7388526865898 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9612a34f-ee3a-4b10-80bf-33ea9b5b7136">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66821789167139 139.73885543055317 29.635 35.66821300293817 139.73886272664748 29.635 35.66821300293817 139.73886272664748 31.733 35.66821789167139 139.73885543055317 31.733 35.66821789167139 139.73885543055317 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2077ebd1-b8b1-449a-ac58-d4a18c331397">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66822025569278 139.7388700084372 29.635 35.66821300293817 139.73886272664748 29.635 35.66821789167139 139.73885543055317 29.635 35.66822513541272 139.73886271235332 29.635 35.66822025569278 139.7388700084372 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bf99e63-de2e-4c54-a0aa-75000f09388f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66812876421681 139.73893632564054 29.635 35.66810338821998 139.73891035335845 29.635 35.66811654215731 139.73889106269044 29.635 35.668141909144516 139.73891703498126 29.635 35.66812876421681 139.73893632564054 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17ceb541-29b9-483c-a539-587e159b3a0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17ceb541-29b9-483c-a539-587e159b3a0c_0">
											<gml:posList>35.66819942823739 139.73881675831413 29.635 35.66820396584008 139.73880998179231 29.635 35.66820396584008 139.73880998179231 31.733 35.66819942823739 139.73881675831413 31.733 35.66819942823739 139.73881675831413 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faef6858-1109-47f9-841f-df126a643971">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faef6858-1109-47f9-841f-df126a643971_0">
											<gml:posList>35.66821514928015 139.73885260601844 29.635 35.66821514928015 139.73885260601844 31.733 35.66821023354057 139.7388599463283 31.733 35.66821023354057 139.7388599463283 29.635 35.66821514928015 139.73885260601844 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da932cca-244b-40ff-b7b0-962dce9f9d15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da932cca-244b-40ff-b7b0-962dce9f9d15_0">
											<gml:posList>35.66818661874479 139.7387925496294 29.635 35.668182081143065 139.73879932615077 29.635 35.668182081143065 139.73879932615077 31.733 35.66818661874479 139.7387925496294 31.733 35.66818661874479 139.7387925496294 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82c94cc1-cff9-4576-b362-78140e7830df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82c94cc1-cff9-4576-b362-78140e7830df_0">
											<gml:posList>35.66819350165476 139.7387994673298 29.635 35.66818661874479 139.7387925496294 29.635 35.66818661874479 139.7387925496294 31.733 35.66819350165476 139.7387994673298 31.733 35.66819350165476 139.7387994673298 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb22b12b-138e-446a-93ad-b419d24b3774">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb22b12b-138e-446a-93ad-b419d24b3774_0">
											<gml:posList>35.66818661874479 139.7387925496294 31.733 35.668182081143065 139.73879932615077 31.733 35.66818896405265 139.73880624385137 31.733 35.66819350165476 139.7387994673298 31.733 35.66818661874479 139.7387925496294 31.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5a8b2da-43a1-4ecc-b4ad-46e03273d5dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5a8b2da-43a1-4ecc-b4ad-46e03273d5dc_0">
											<gml:posList>35.668182081143065 139.73879932615077 29.635 35.66818896405265 139.73880624385137 29.635 35.66818896405265 139.73880624385137 31.733 35.668182081143065 139.73879932615077 31.733 35.668182081143065 139.73879932615077 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5135dc0-b980-4275-9c36-126ccf578762">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5135dc0-b980-4275-9c36-126ccf578762_0">
											<gml:posList>35.66820396584008 139.73880998179231 29.635 35.66819685741416 139.7388028434368 29.635 35.66819685741416 139.7388028434368 31.733 35.66820396584008 139.73880998179231 31.733 35.66820396584008 139.73880998179231 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02248bf3-0b71-489d-8cb0-0951e5268b90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02248bf3-0b71-489d-8cb0-0951e5268b90_0">
											<gml:posList>35.66819685741416 139.7388028434368 31.733 35.66819231981187 139.73880961995843 31.733 35.66819942823739 139.73881675831413 31.733 35.66820396584008 139.73880998179231 31.733 35.66819685741416 139.7388028434368 31.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-547ea557-9023-4c96-8a87-14e38b36c52b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-547ea557-9023-4c96-8a87-14e38b36c52b_0">
											<gml:posList>35.66819231981187 139.73880961995843 29.635 35.66819942823739 139.73881675831413 29.635 35.66819942823739 139.73881675831413 31.733 35.66819231981187 139.73880961995843 31.733 35.66819231981187 139.73880961995843 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b28f8fb6-cc21-413d-b74a-ffd9e76088bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b28f8fb6-cc21-413d-b74a-ffd9e76088bb_0">
											<gml:posList>35.668169071396896 139.73881856144988 31.733 35.66817411317007 139.7388110221655 31.733 35.66817411317007 139.7388110221655 29.635 35.668169071396896 139.73881856144988 29.635 35.668169071396896 139.73881856144988 31.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-048c9a46-a69b-4880-827c-34f750e9e655">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-048c9a46-a69b-4880-827c-34f750e9e655_0">
											<gml:posList>35.668181672637274 139.73881861287225 29.635 35.66817411317007 139.7388110221655 29.635 35.66817411317007 139.7388110221655 31.733 35.668181672637274 139.73881861287225 31.733 35.668181672637274 139.73881861287225 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ebf59e9-ed9f-4343-8bad-29fcf486ac6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ebf59e9-ed9f-4343-8bad-29fcf486ac6e_0">
											<gml:posList>35.66820710509636 139.7388131372362 29.635 35.66820255847977 139.73881991376876 29.635 35.66820255847977 139.73881991376876 31.733 35.66820710509636 139.7388131372362 31.733 35.66820710509636 139.7388131372362 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1086c246-d1ca-46c6-bfac-cc248678c42a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1086c246-d1ca-46c6-bfac-cc248678c42a_0">
											<gml:posList>35.66821411430132 139.73882018734278 29.635 35.66820710509636 139.7388131372362 29.635 35.66820710509636 139.7388131372362 31.733 35.66821411430132 139.73882018734278 31.733 35.66821411430132 139.73882018734278 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d362fbba-8a89-43f9-914b-08547abd0bf1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d362fbba-8a89-43f9-914b-08547abd0bf1_0">
											<gml:posList>35.668181672637274 139.73881861287225 31.733 35.66817411317007 139.7388110221655 31.733 35.668169071396896 139.73881856144988 31.733 35.6681766308723 139.73882616320284 31.733 35.668181672637274 139.73881861287225 31.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02942a80-3c11-4c6e-b903-b37d4e568c47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02942a80-3c11-4c6e-b903-b37d4e568c47_0">
											<gml:posList>35.66821411430132 139.73882018734278 31.733 35.66820710509636 139.7388131372362 31.733 35.66820255847977 139.73881991376876 31.733 35.66820957669807 139.7388269638649 31.733 35.66821411430132 139.73882018734278 31.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6c64f03-f3c2-415e-9cb7-73e8b6b3a57b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6c64f03-f3c2-415e-9cb7-73e8b6b3a57b_0">
											<gml:posList>35.668169071396896 139.73881856144988 29.635 35.6681766308723 139.73882616320284 29.635 35.6681766308723 139.73882616320284 31.733 35.668169071396896 139.73881856144988 31.733 35.668169071396896 139.73881856144988 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb6839d9-4e02-4a47-b833-636bc514ac2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb6839d9-4e02-4a47-b833-636bc514ac2f_0">
											<gml:posList>35.66820255847977 139.73881991376876 29.635 35.66820957669807 139.7388269638649 29.635 35.66820957669807 139.7388269638649 31.733 35.66820255847977 139.73881991376876 31.733 35.66820255847977 139.73881991376876 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67c4f3ee-883a-4379-bb08-67f8d2d61c1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67c4f3ee-883a-4379-bb08-67f8d2d61c1a_0">
											<gml:posList>35.66820957669807 139.7388269638649 29.635 35.66821411430132 139.73882018734278 29.635 35.66821411430132 139.73882018734278 31.733 35.66820957669807 139.7388269638649 31.733 35.66820957669807 139.7388269638649 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f37fbf73-4e5c-453f-be45-f2939c595eb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f37fbf73-4e5c-453f-be45-f2939c595eb4_0">
											<gml:posList>35.668184396941186 139.73882136010428 29.635 35.668184396941186 139.73882136010428 31.733 35.668191424181806 139.73882842123433 31.733 35.668191424181806 139.73882842123433 29.635 35.668184396941186 139.73882136010428 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-610c48f0-1a58-4bb5-92da-d8dfc312b227">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-610c48f0-1a58-4bb5-92da-d8dfc312b227_0">
											<gml:posList>35.66818637339383 139.73883596052988 31.733 35.668191424181806 139.73882842123433 31.733 35.668184396941186 139.73882136010428 31.733 35.668179355167375 139.738828899389 31.733 35.66818637339383 139.73883596052988 31.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fc3198a-75bf-45fe-9571-dc217b38b064">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fc3198a-75bf-45fe-9571-dc217b38b064_0">
											<gml:posList>35.668220510147734 139.73882669692142 29.635 35.66821600856435 139.7388334292174 29.635 35.66821600856435 139.7388334292174 31.733 35.668220510147734 139.73882669692142 31.733 35.668220510147734 139.73882669692142 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e6f0c1c-cc83-4762-8319-b2f67a78bf5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e6f0c1c-cc83-4762-8319-b2f67a78bf5f_0">
											<gml:posList>35.668220510147734 139.73882669692142 29.635 35.668220510147734 139.73882669692142 31.733 35.66822776290452 139.73883397870856 31.733 35.66822776290452 139.73883397870856 29.635 35.668220510147734 139.73882669692142 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ea0511c-86ec-4d9d-bfd7-fab7bbfd41e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ea0511c-86ec-4d9d-bfd7-fab7bbfd41e3_0">
											<gml:posList>35.66818637339383 139.73883596052988 29.635 35.668191424181806 139.73882842123433 29.635 35.668191424181806 139.73882842123433 31.733 35.66818637339383 139.73883596052988 31.733 35.66818637339383 139.73883596052988 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14cbdec3-ef6c-4774-87db-49a4e7d7f029">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14cbdec3-ef6c-4774-87db-49a4e7d7f029_0">
											<gml:posList>35.66818637339383 139.73883596052988 29.635 35.66818637339383 139.73883596052988 31.733 35.668179355167375 139.738828899389 31.733 35.668179355167375 139.738828899389 29.635 35.66818637339383 139.73883596052988 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3884b7a-3f50-486d-b3b6-8274dbe1f8e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3884b7a-3f50-486d-b3b6-8274dbe1f8e1_0">
											<gml:posList>35.66822776290452 139.73883397870856 31.733 35.668220510147734 139.73882669692142 31.733 35.66821600856435 139.7388334292174 31.733 35.668223252307 139.73884071101537 31.733 35.66822776290452 139.73883397870856 31.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b0e9fdb-ce00-4c64-a063-1b5ba4d262ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b0e9fdb-ce00-4c64-a063-1b5ba4d262ac_0">
											<gml:posList>35.66819423868343 139.73883124568243 29.635 35.66819423868343 139.73883124568243 31.733 35.668201491448634 139.73883853851356 31.733 35.668201491448634 139.73883853851356 29.635 35.66819423868343 139.73883124568243 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e90e1bf-14a5-463a-b05c-bfafaca8d429">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e90e1bf-14a5-463a-b05c-bfafaca8d429_0">
											<gml:posList>35.66819423868343 139.73883124568243 29.635 35.66818918789527 139.73883878497807 29.635 35.66818918789527 139.73883878497807 31.733 35.66819423868343 139.73883124568243 31.733 35.66819423868343 139.73883124568243 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8044077-32e0-4d42-968a-4aa3a02338cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8044077-32e0-4d42-968a-4aa3a02338cd_0">
											<gml:posList>35.66821600856435 139.7388334292174 29.635 35.668223252307 139.73884071101537 29.635 35.668223252307 139.73884071101537 31.733 35.66821600856435 139.7388334292174 31.733 35.66821600856435 139.7388334292174 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf694e08-d03e-474f-a6a7-41283bb3074c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf694e08-d03e-474f-a6a7-41283bb3074c_0">
											<gml:posList>35.668223252307 139.73884071101537 29.635 35.66822776290452 139.73883397870856 29.635 35.66822776290452 139.73883397870856 31.733 35.668223252307 139.73884071101537 31.733 35.668223252307 139.73884071101537 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3b48501-e54b-4221-90fa-f0efe288d7fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3b48501-e54b-4221-90fa-f0efe288d7fc_0">
											<gml:posList>35.66819644066003 139.73884607780943 31.733 35.668201491448634 139.73883853851356 31.733 35.66819423868343 139.73883124568243 31.733 35.66818918789527 139.73883878497807 31.733 35.66819644066003 139.73884607780943 31.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b8fc2d6-28f1-4f35-afc2-bfaaa1c25dd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b8fc2d6-28f1-4f35-afc2-bfaaa1c25dd1_0">
											<gml:posList>35.668230550139434 139.73883651599525 29.635 35.66822594052082 139.73884341410826 29.635 35.66822594052082 139.73884341410826 31.733 35.668230550139434 139.73883651599525 31.733 35.668230550139434 139.73883651599525 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5473fed-766e-4580-a572-e7fe4d3d91fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5473fed-766e-4580-a572-e7fe4d3d91fb_0">
											<gml:posList>35.668237775837106 139.73884377572412 29.635 35.668230550139434 139.73883651599525 29.635 35.668230550139434 139.73883651599525 31.733 35.668237775837106 139.73884377572412 31.733 35.668237775837106 139.73884377572412 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6714340f-88f9-4c7d-b656-b71c58b4396a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6714340f-88f9-4c7d-b656-b71c58b4396a_0">
											<gml:posList>35.66819644066003 139.73884607780943 29.635 35.668201491448634 139.73883853851356 29.635 35.668201491448634 139.73883853851356 31.733 35.66819644066003 139.73884607780943 31.733 35.66819644066003 139.73884607780943 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aed842aa-055d-418d-b1b0-217804c9026f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aed842aa-055d-418d-b1b0-217804c9026f_0">
											<gml:posList>35.66818918789527 139.73883878497807 29.635 35.66819644066003 139.73884607780943 29.635 35.66819644066003 139.73884607780943 31.733 35.66818918789527 139.73883878497807 31.733 35.66818918789527 139.73883878497807 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dcd3ca6-7c51-4ca5-92b2-bb0ef0d5bf0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dcd3ca6-7c51-4ca5-92b2-bb0ef0d5bf0c_0">
											<gml:posList>35.66823315720435 139.738850673848 31.733 35.668237775837106 139.73884377572412 31.733 35.668230550139434 139.73883651599525 31.733 35.66822594052082 139.73884341410826 31.733 35.66823315720435 139.738850673848 31.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a0dad6f-7bf7-4963-80ea-651bec7d7f23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a0dad6f-7bf7-4963-80ea-651bec7d7f23_0">
											<gml:posList>35.66822594052082 139.73884341410826 29.635 35.66823315720435 139.738850673848 29.635 35.66823315720435 139.738850673848 31.733 35.66822594052082 139.73884341410826 31.733 35.66822594052082 139.73884341410826 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6649c498-3588-47ff-ae1e-719ba6e47412">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6649c498-3588-47ff-ae1e-719ba6e47412_0">
											<gml:posList>35.668237775837106 139.73884377572412 29.635 35.668237775837106 139.73884377572412 31.733 35.66823315720435 139.738850673848 31.733 35.66823315720435 139.738850673848 29.635 35.668237775837106 139.73884377572412 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d30c51a2-7893-4447-b856-da8f0c65ae86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d30c51a2-7893-4447-b856-da8f0c65ae86_0">
											<gml:posList>35.66821514928015 139.73885260601844 29.635 35.66820793259672 139.73884534628013 29.635 35.66820793259672 139.73884534628013 31.733 35.66821514928015 139.73885260601844 31.733 35.66821514928015 139.73885260601844 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0eab596-caf0-40ca-9a29-bc881ccc2e03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0eab596-caf0-40ca-9a29-bc881ccc2e03_0">
											<gml:posList>35.66820793259672 139.73884534628013 29.635 35.668203016857575 139.7388526865898 29.635 35.668203016857575 139.7388526865898 31.733 35.66820793259672 139.73884534628013 31.733 35.66820793259672 139.73884534628013 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d061fc8d-fdf9-4aaa-b25b-36b21605f3de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d061fc8d-fdf9-4aaa-b25b-36b21605f3de_0">
											<gml:posList>35.66821514928015 139.73885260601844 31.733 35.66820793259672 139.73884534628013 31.733 35.668203016857575 139.7388526865898 31.733 35.66821023354057 139.7388599463283 31.733 35.66821514928015 139.73885260601844 31.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42d02f54-30ce-4c16-992d-a0e5ab18c172">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42d02f54-30ce-4c16-992d-a0e5ab18c172_0">
											<gml:posList>35.668203016857575 139.7388526865898 29.635 35.66821023354057 139.7388599463283 29.635 35.66821023354057 139.7388599463283 31.733 35.668203016857575 139.7388526865898 31.733 35.668203016857575 139.7388526865898 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad4b38c6-2b04-46fc-97da-083557de0f4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad4b38c6-2b04-46fc-97da-083557de0f4e_0">
											<gml:posList>35.66822513541272 139.73886271235332 29.635 35.66821789167139 139.73885543055317 29.635 35.66821789167139 139.73885543055317 31.733 35.66822513541272 139.73886271235332 31.733 35.66822513541272 139.73886271235332 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2452c1d1-8966-4d95-80eb-6d3a491b50e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2452c1d1-8966-4d95-80eb-6d3a491b50e7_0">
											<gml:posList>35.66822025569278 139.7388700084372 31.733 35.66822513541272 139.73886271235332 31.733 35.66821789167139 139.73885543055317 31.733 35.66821300293817 139.73886272664748 31.733 35.66822025569278 139.7388700084372 31.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d429688d-742e-4885-80d8-49428033fd9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d429688d-742e-4885-80d8-49428033fd9f_0">
											<gml:posList>35.66821300293817 139.73886272664748 29.635 35.66822025569278 139.7388700084372 29.635 35.66822025569278 139.7388700084372 31.733 35.66821300293817 139.73886272664748 31.733 35.66821300293817 139.73886272664748 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b999eaa3-82b2-4e81-9763-8f7138ade6b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b999eaa3-82b2-4e81-9763-8f7138ade6b0_0">
											<gml:posList>35.66822025569278 139.7388700084372 29.635 35.66822513541272 139.73886271235332 29.635 35.66822513541272 139.73886271235332 31.733 35.66822025569278 139.7388700084372 31.733 35.66822025569278 139.7388700084372 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ba432f4-4d15-472b-b1e0-4cc6a95a22af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ba432f4-4d15-472b-b1e0-4cc6a95a22af_0">
											<gml:posList>35.66811654215731 139.73889106269044 29.635 35.66810338821998 139.73891035335845 29.635 35.66810338821998 139.73891035335845 32.745 35.66811654215731 139.73889106269044 32.745 35.66811654215731 139.73889106269044 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe36ed88-818a-4dee-b627-018ec6be23e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe36ed88-818a-4dee-b627-018ec6be23e0_0">
											<gml:posList>35.66810338821998 139.73891035335845 29.635 35.66812876421681 139.73893632564054 29.635 35.66812876421681 139.73893632564054 32.745 35.66810338821998 139.73891035335845 32.745 35.66810338821998 139.73891035335845 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84d888ed-aef8-4775-b74b-e4e156837928">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84d888ed-aef8-4775-b74b-e4e156837928_0">
											<gml:posList>35.66812876421681 139.73893632564054 32.745 35.668141909144516 139.73891703498126 32.745 35.66811654215731 139.73889106269044 32.745 35.66810338821998 139.73891035335845 32.745 35.66812876421681 139.73893632564054 32.745</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-093d5355-e120-4b23-80d2-92afd6a6233a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-093d5355-e120-4b23-80d2-92afd6a6233a_0">
											<gml:posList>35.66811654215731 139.73889106269044 29.635 35.66811654215731 139.73889106269044 32.745 35.668141909144516 139.73891703498126 32.745 35.668141909144516 139.73891703498126 29.635 35.66811654215731 139.73889106269044 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b42ce3f-6b8d-4469-b592-687988a42072">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b42ce3f-6b8d-4469-b592-687988a42072_0">
											<gml:posList>35.66812876421681 139.73893632564054 29.635 35.668141909144516 139.73891703498126 29.635 35.668141909144516 139.73891703498126 32.745 35.66812876421681 139.73893632564054 32.745 35.66812876421681 139.73893632564054 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_25350710-9a23-4137-99c3-9fdd8a45341b_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b530023-6812-4342-b9c4-2a916c49ebe4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66808931455963 139.73898674158588 12.93 35.668103368375604 139.73896552788023 12.93 35.668137684326986 139.7390008897651 12.93 35.66812408960793 139.73902134076323 12.93 35.66808931455963 139.73898674158588 12.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d45d9fd-3204-485a-8272-b164fe462874">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d45d9fd-3204-485a-8272-b164fe462874_0">
											<gml:posList>35.66808931455963 139.73898674158588 12.93 35.66808931455963 139.73898674158588 30.115 35.668103368375604 139.73896552788023 30.115 35.668103368375604 139.73896552788023 12.93 35.66808931455963 139.73898674158588 12.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2c631ed-0cf9-43eb-8c9c-e043fe4770c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2c631ed-0cf9-43eb-8c9c-e043fe4770c1_0">
											<gml:posList>35.66808931455963 139.73898674158588 12.93 35.66812408960793 139.73902134076323 12.93 35.66812408960793 139.73902134076323 30.115 35.66808931455963 139.73898674158588 30.115 35.66808931455963 139.73898674158588 12.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b263e737-12cd-428f-b504-aa7f99b4f402">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b263e737-12cd-428f-b504-aa7f99b4f402_0">
											<gml:posList>35.66808931455963 139.73898674158588 30.115 35.66812408960793 139.73902134076323 30.115 35.668137684326986 139.7390008897651 30.115 35.668103368375604 139.73896552788023 30.115 35.66808931455963 139.73898674158588 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ba4283f-c04c-4e97-83dd-13f70b8a9c01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ba4283f-c04c-4e97-83dd-13f70b8a9c01_0">
											<gml:posList>35.668137684326986 139.7390008897651 12.93 35.668103368375604 139.73896552788023 12.93 35.668103368375604 139.73896552788023 30.115 35.668137684326986 139.7390008897651 30.115 35.668137684326986 139.7390008897651 12.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64460116-7ac0-4e7f-b416-ad084c075a50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64460116-7ac0-4e7f-b416-ad084c075a50_0">
											<gml:posList>35.66812408960793 139.73902134076323 12.93 35.668137684326986 139.7390008897651 12.93 35.668137684326986 139.7390008897651 30.115 35.66812408960793 139.73902134076323 30.115 35.66812408960793 139.73902134076323 12.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-34df0efe-f438-4129-aaeb-5c5d65fbf610">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34df0efe-f438-4129-aaeb-5c5d65fbf610">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34df0efe-f438-4129-aaeb-5c5d65fbf610">
											<gml:posList>35.66808877079377 139.73887950820512 12.92 35.66809226905511 139.73888069704628 12.92 35.66809632841139 139.73888474612627 12.92 35.66818138959995 139.73875661225287 12.92 35.66826158449162 139.73883660092682 12.92 35.66814652478694 139.73900982658552 12.92 35.668137684326986 139.7390008897651 12.92 35.668103368375604 139.73896552788023 12.92 35.66808931455963 139.73898674158588 12.92 35.66808295491511 139.7389804086976 12.92 35.66807854338236 139.73898704145398 12.92 35.668048413907705 139.73895692149392 12.92 35.66806767154704 139.73892791427943 12.92 35.66806205160518 139.73892232060453 12.92 35.66806000073471 139.7389162587984 12.92 35.66805969833617 139.73890995192298 12.92 35.66806072009744 139.73890254994015 12.92 35.66806358008655 139.73889441676008 12.92 35.66806661413424 139.73888985121323 12.92 35.66807135137737 139.73888477554652 12.92 35.6680766391767 139.7388806160439 12.92 35.668083254255 139.73887933796829 12.92 35.66808877079377 139.73887950820512 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-12613074-809b-474e-bc10-b528f9e9528d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12613074-809b-474e-bc10-b528f9e9528d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12613074-809b-474e-bc10-b528f9e9528d">
											<gml:posList>35.66807467345622 139.7389831688819 33.95 35.668093597940235 139.73895460389406 33.95 35.66806737444916 139.73892836751278 33.95 35.668048413907705 139.73895692149392 33.95 35.66807467345622 139.7389831688819 33.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f406986-53fb-4cbe-9edd-445974d949fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f406986-53fb-4cbe-9edd-445974d949fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f406986-53fb-4cbe-9edd-445974d949fe">
											<gml:posList>35.66807854338236 139.73898704145398 30.115 35.66807829759711 139.7389839599253 30.115 35.6680771880347 139.73898284559075 30.115 35.66807467345622 139.7389831688819 30.115 35.66807854338236 139.73898704145398 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fc4e617f-d41f-4e2f-9b9c-a54f4fda9b46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc4e617f-d41f-4e2f-9b9c-a54f4fda9b46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc4e617f-d41f-4e2f-9b9c-a54f4fda9b46">
											<gml:posList>35.66809632841139 139.73888474612627 20.276 35.66809226905511 139.73888069704628 20.276 35.66808877079377 139.73887950820512 20.276 35.668083254255 139.73887933796829 20.276 35.6680766391767 139.7388806160439 20.276 35.66807135137737 139.73888477554652 20.276 35.66806661413424 139.73888985121323 20.276 35.66806358008655 139.73889441676008 20.276 35.66806072009744 139.73890254994015 20.276 35.66805969833617 139.73890995192298 20.276 35.66806000073471 139.7389162587984 20.276 35.66806205160518 139.73892232060453 20.276 35.66806767154704 139.73892791427943 20.276 35.66809632841139 139.73888474612627 20.276</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45a5894c-319e-4159-8f1c-fc1a104f3ded">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45a5894c-319e-4159-8f1c-fc1a104f3ded">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45a5894c-319e-4159-8f1c-fc1a104f3ded">
											<gml:posList>35.66808295491511 139.7389804086976 30.115 35.6680827091297 139.73897732716878 30.115 35.66807829759711 139.7389839599253 30.115 35.66807854338236 139.73898704145398 30.115 35.66808295491511 139.7389804086976 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b4af985-4bc1-43b6-8c0b-ecf42334893c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b4af985-4bc1-43b6-8c0b-ecf42334893c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b4af985-4bc1-43b6-8c0b-ecf42334893c">
											<gml:posList>35.668093597940235 139.73895460389406 30.115 35.668096112518654 139.73895428060197 30.115 35.66806988903617 139.7389280552659 30.115 35.66806737444916 139.73892836751278 30.115 35.668093597940235 139.73895460389406 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f90521d9-d44d-4e5c-a97d-43aaf2bd30b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f90521d9-d44d-4e5c-a97d-43aaf2bd30b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f90521d9-d44d-4e5c-a97d-43aaf2bd30b1">
											<gml:posList>35.668093597940235 139.73895460389406 30.115 35.66807467345622 139.7389831688819 30.115 35.6680771880347 139.73898284559075 30.115 35.668096112518654 139.73895428060197 30.115 35.668093597940235 139.73895460389406 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e15d9e1-d07b-4b58-8600-62e21a364d1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e15d9e1-d07b-4b58-8600-62e21a364d1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e15d9e1-d07b-4b58-8600-62e21a364d1b">
											<gml:posList>35.66808295491511 139.7389804086976 30.115 35.66808931455963 139.73898674158588 30.115 35.668089059752 139.7389836490215 30.115 35.6680827091297 139.73897732716878 30.115 35.66808295491511 139.7389804086976 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-140dd5b3-8926-44a0-942e-003b3493e2d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-140dd5b3-8926-44a0-942e-003b3493e2d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-140dd5b3-8926-44a0-942e-003b3493e2d7">
											<gml:posList>35.668103368375604 139.73896552788023 30.115 35.6681031405913 139.73896241319164 30.115 35.668089059752 139.7389836490215 30.115 35.66808931455963 139.73898674158588 30.115 35.668103368375604 139.73896552788023 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2bf229e8-5b49-4154-81d0-32ec79570243">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bf229e8-5b49-4154-81d0-32ec79570243">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bf229e8-5b49-4154-81d0-32ec79570243">
											<gml:posList>35.668103368375604 139.73896552788023 30.115 35.668137684326986 139.7390008897651 30.115 35.66813881872381 139.73899918735412 30.115 35.6681031405913 139.73896241319164 30.115 35.668103368375604 139.73896552788023 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1992c709-2bec-4ca1-a1f0-a8c647694a2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1992c709-2bec-4ca1-a1f0-a8c647694a2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1992c709-2bec-4ca1-a1f0-a8c647694a2c">
											<gml:posList>35.66806737444916 139.73892836751278 30.115 35.66806988903617 139.7389280552659 30.115 35.66818164439606 139.7387596827282 30.115 35.66818138959995 139.73875661225287 30.115 35.66806737444916 139.73892836751278 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5c431f6-bb46-428d-a4a4-ab447b6448b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5c431f6-bb46-428d-a4a4-ab447b6448b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5c431f6-bb46-428d-a4a4-ab447b6448b2">
											<gml:posList>35.668137684326986 139.7390008897651 30.115 35.66814652478694 139.73900982658552 30.115 35.66814627899363 139.7390067340082 30.115 35.66813881872381 139.73899918735412 30.115 35.668137684326986 139.7390008897651 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c29b2fff-091a-48a6-9a73-72b0dd9308fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c29b2fff-091a-48a6-9a73-72b0dd9308fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c29b2fff-091a-48a6-9a73-72b0dd9308fd">
											<gml:posList>35.668096112518654 139.73895428060197 29.635 35.6680771880347 139.73898284559075 29.635 35.66807829759711 139.7389839599253 29.635 35.6680827091297 139.73897732716878 29.635 35.668089059752 139.7389836490215 29.635 35.6681031405913 139.73896241319164 29.635 35.66813881872381 139.73899918735412 29.635 35.66814627899363 139.7390067340082 29.635 35.66825907891865 139.73883691316672 29.635 35.66818164439606 139.7387596827282 29.635 35.66806988903617 139.7389280552659 29.635 35.668096112518654 139.73895428060197 29.635</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd5a026e-7801-4c46-b551-931de28c6963">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd5a026e-7801-4c46-b551-931de28c6963">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd5a026e-7801-4c46-b551-931de28c6963">
											<gml:posList>35.66826158449162 139.73883660092682 30.115 35.66825907891865 139.73883691316672 30.115 35.66814627899363 139.7390067340082 30.115 35.66814652478694 139.73900982658552 30.115 35.66826158449162 139.73883660092682 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b15e660c-aeb6-4b02-83b8-09c4a11a3956">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b15e660c-aeb6-4b02-83b8-09c4a11a3956">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b15e660c-aeb6-4b02-83b8-09c4a11a3956">
											<gml:posList>35.66818138959995 139.73875661225287 30.115 35.66818164439606 139.7387596827282 30.115 35.66825907891865 139.73883691316672 30.115 35.66826158449162 139.73883660092682 30.115 35.66818138959995 139.73875661225287 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6c8a8fd-088f-4058-bbf1-ba2c8527c1fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6c8a8fd-088f-4058-bbf1-ba2c8527c1fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6c8a8fd-088f-4058-bbf1-ba2c8527c1fe">
											<gml:posList>35.66806988903617 139.7389280552659 30.115 35.66806988903617 139.7389280552659 29.635 35.66818164439606 139.7387596827282 29.635 35.66818164439606 139.7387596827282 30.115 35.66806988903617 139.7389280552659 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ff24cca-f762-433b-9d50-88b7a36648ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ff24cca-f762-433b-9d50-88b7a36648ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ff24cca-f762-433b-9d50-88b7a36648ab">
											<gml:posList>35.66825907891865 139.73883691316672 30.115 35.66825907891865 139.73883691316672 29.635 35.66814627899363 139.7390067340082 29.635 35.66814627899363 139.7390067340082 30.115 35.66825907891865 139.73883691316672 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea47ef1c-0bff-4540-98a1-d42a8066e9a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea47ef1c-0bff-4540-98a1-d42a8066e9a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea47ef1c-0bff-4540-98a1-d42a8066e9a0">
											<gml:posList>35.6680827091297 139.73897732716878 30.115 35.6680827091297 139.73897732716878 29.635 35.66807829759711 139.7389839599253 29.635 35.66807829759711 139.7389839599253 30.115 35.6680827091297 139.73897732716878 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be1e392a-81ec-472f-8ce0-00aca1cda479">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be1e392a-81ec-472f-8ce0-00aca1cda479">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be1e392a-81ec-472f-8ce0-00aca1cda479">
											<gml:posList>35.66805969833617 139.73890995192298 12.92 35.66806000073471 139.7389162587984 12.92 35.66806000073471 139.7389162587984 20.276 35.66805969833617 139.73890995192298 20.276 35.66805969833617 139.73890995192298 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-450e5e23-75cb-4145-bd5f-a745daee1493">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-450e5e23-75cb-4145-bd5f-a745daee1493">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-450e5e23-75cb-4145-bd5f-a745daee1493">
											<gml:posList>35.66806072009744 139.73890254994015 12.92 35.66805969833617 139.73890995192298 12.92 35.66805969833617 139.73890995192298 20.276 35.66806072009744 139.73890254994015 20.276 35.66806072009744 139.73890254994015 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16b37a85-49e9-4e90-bf86-1d152e309d64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16b37a85-49e9-4e90-bf86-1d152e309d64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16b37a85-49e9-4e90-bf86-1d152e309d64">
											<gml:posList>35.66806000073471 139.7389162587984 12.92 35.66806205160518 139.73892232060453 12.92 35.66806205160518 139.73892232060453 20.276 35.66806000073471 139.7389162587984 20.276 35.66806000073471 139.7389162587984 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea69489d-3432-443b-8a1f-f3cce14586e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea69489d-3432-443b-8a1f-f3cce14586e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea69489d-3432-443b-8a1f-f3cce14586e4">
											<gml:posList>35.66806358008655 139.73889441676008 12.92 35.66806072009744 139.73890254994015 12.92 35.66806072009744 139.73890254994015 20.276 35.66806358008655 139.73889441676008 20.276 35.66806358008655 139.73889441676008 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65f8d002-d684-4d66-8ec3-9e8d3685b059">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65f8d002-d684-4d66-8ec3-9e8d3685b059">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65f8d002-d684-4d66-8ec3-9e8d3685b059">
											<gml:posList>35.66807467345622 139.7389831688819 30.115 35.66807467345622 139.7389831688819 33.95 35.668048413907705 139.73895692149392 33.95 35.668048413907705 139.73895692149392 12.92 35.66807854338236 139.73898704145398 12.92 35.66807854338236 139.73898704145398 30.115 35.66807467345622 139.7389831688819 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3127002d-f534-4c7b-9078-426612ed43f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3127002d-f534-4c7b-9078-426612ed43f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3127002d-f534-4c7b-9078-426612ed43f5">
											<gml:posList>35.66806205160518 139.73892232060453 12.92 35.66806767154704 139.73892791427943 12.92 35.66806767154704 139.73892791427943 20.276 35.66806205160518 139.73892232060453 20.276 35.66806205160518 139.73892232060453 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3955ecf9-d242-47eb-9f1f-3d9b7b75afbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3955ecf9-d242-47eb-9f1f-3d9b7b75afbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3955ecf9-d242-47eb-9f1f-3d9b7b75afbb">
											<gml:posList>35.66806661413424 139.73888985121323 12.92 35.66806358008655 139.73889441676008 12.92 35.66806358008655 139.73889441676008 20.276 35.66806661413424 139.73888985121323 20.276 35.66806661413424 139.73888985121323 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26051d79-118d-441d-aa78-d379f94552a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26051d79-118d-441d-aa78-d379f94552a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26051d79-118d-441d-aa78-d379f94552a5">
											<gml:posList>35.66807135137737 139.73888477554652 12.92 35.66806661413424 139.73888985121323 12.92 35.66806661413424 139.73888985121323 20.276 35.66807135137737 139.73888477554652 20.276 35.66807135137737 139.73888477554652 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc3787ac-fda6-49f8-a969-c7f849993a4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc3787ac-fda6-49f8-a969-c7f849993a4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc3787ac-fda6-49f8-a969-c7f849993a4c">
											<gml:posList>35.6680766391767 139.7388806160439 12.92 35.66807135137737 139.73888477554652 12.92 35.66807135137737 139.73888477554652 20.276 35.6680766391767 139.7388806160439 20.276 35.6680766391767 139.7388806160439 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50cf3e44-8067-4f78-b75b-af2b24fd6ad1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50cf3e44-8067-4f78-b75b-af2b24fd6ad1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50cf3e44-8067-4f78-b75b-af2b24fd6ad1">
											<gml:posList>35.66807829759711 139.7389839599253 30.115 35.66807829759711 139.7389839599253 29.635 35.6680771880347 139.73898284559075 29.635 35.6680771880347 139.73898284559075 30.115 35.66807829759711 139.7389839599253 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-410e88ea-b3ad-4527-af4a-e949a3be54a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-410e88ea-b3ad-4527-af4a-e949a3be54a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-410e88ea-b3ad-4527-af4a-e949a3be54a7">
											<gml:posList>35.668083254255 139.73887933796829 12.92 35.6680766391767 139.7388806160439 12.92 35.6680766391767 139.7388806160439 20.276 35.668083254255 139.73887933796829 20.276 35.668083254255 139.73887933796829 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84373f32-c52f-491b-98b1-c06ef0617a3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84373f32-c52f-491b-98b1-c06ef0617a3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84373f32-c52f-491b-98b1-c06ef0617a3f">
											<gml:posList>35.66806737444916 139.73892836751278 33.95 35.668093597940235 139.73895460389406 33.95 35.668093597940235 139.73895460389406 30.115 35.66806737444916 139.73892836751278 30.115 35.66806737444916 139.73892836751278 33.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fcbf37bb-c198-456f-a177-5df68e3f34c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcbf37bb-c198-456f-a177-5df68e3f34c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcbf37bb-c198-456f-a177-5df68e3f34c9">
											<gml:posList>35.66807854338236 139.73898704145398 12.92 35.66808295491511 139.7389804086976 12.92 35.66808295491511 139.7389804086976 30.115 35.66807854338236 139.73898704145398 30.115 35.66807854338236 139.73898704145398 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86f51662-0b11-4bd5-9c22-8595876b69f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86f51662-0b11-4bd5-9c22-8595876b69f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86f51662-0b11-4bd5-9c22-8595876b69f2">
											<gml:posList>35.668096112518654 139.73895428060197 30.115 35.668096112518654 139.73895428060197 29.635 35.66806988903617 139.7389280552659 29.635 35.66806988903617 139.7389280552659 30.115 35.668096112518654 139.73895428060197 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abc5d61b-2931-438f-9b96-511d3dd2d849">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abc5d61b-2931-438f-9b96-511d3dd2d849">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abc5d61b-2931-438f-9b96-511d3dd2d849">
											<gml:posList>35.668093597940235 139.73895460389406 33.95 35.66807467345622 139.7389831688819 33.95 35.66807467345622 139.7389831688819 30.115 35.668093597940235 139.73895460389406 30.115 35.668093597940235 139.73895460389406 33.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f17ca0e3-c3f6-41b4-997b-9d560eed6c8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f17ca0e3-c3f6-41b4-997b-9d560eed6c8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f17ca0e3-c3f6-41b4-997b-9d560eed6c8b">
											<gml:posList>35.668089059752 139.7389836490215 30.115 35.668089059752 139.7389836490215 29.635 35.6680827091297 139.73897732716878 29.635 35.6680827091297 139.73897732716878 30.115 35.668089059752 139.7389836490215 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0634a60f-8db7-46e4-af4b-aa73a19c5ba2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0634a60f-8db7-46e4-af4b-aa73a19c5ba2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0634a60f-8db7-46e4-af4b-aa73a19c5ba2">
											<gml:posList>35.66808877079377 139.73887950820512 12.92 35.668083254255 139.73887933796829 12.92 35.668083254255 139.73887933796829 20.276 35.66808877079377 139.73887950820512 20.276 35.66808877079377 139.73887950820512 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25c467bc-6ffb-4d05-a576-1f77657c43d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25c467bc-6ffb-4d05-a576-1f77657c43d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25c467bc-6ffb-4d05-a576-1f77657c43d1">
											<gml:posList>35.66808295491511 139.7389804086976 12.92 35.66808931455963 139.73898674158588 12.92 35.66808931455963 139.73898674158588 30.115 35.66808295491511 139.7389804086976 30.115 35.66808295491511 139.7389804086976 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-528ae093-8318-4036-a347-c22dc94c3a56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-528ae093-8318-4036-a347-c22dc94c3a56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-528ae093-8318-4036-a347-c22dc94c3a56">
											<gml:posList>35.6680771880347 139.73898284559075 30.115 35.6680771880347 139.73898284559075 29.635 35.668096112518654 139.73895428060197 29.635 35.668096112518654 139.73895428060197 30.115 35.6680771880347 139.73898284559075 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8a03de4-541b-4ab9-a16b-4b253dc9f032">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8a03de4-541b-4ab9-a16b-4b253dc9f032">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8a03de4-541b-4ab9-a16b-4b253dc9f032">
											<gml:posList>35.66809226905511 139.73888069704628 12.92 35.66808877079377 139.73887950820512 12.92 35.66808877079377 139.73887950820512 20.276 35.66809226905511 139.73888069704628 20.276 35.66809226905511 139.73888069704628 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-feb1080e-dbc4-475a-9da3-3d5104e210c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-feb1080e-dbc4-475a-9da3-3d5104e210c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-feb1080e-dbc4-475a-9da3-3d5104e210c0">
											<gml:posList>35.66809632841139 139.73888474612627 12.92 35.66809226905511 139.73888069704628 12.92 35.66809226905511 139.73888069704628 20.276 35.66809632841139 139.73888474612627 20.276 35.66809632841139 139.73888474612627 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6b383c9-37e7-4b74-bb95-1bdd1228f61a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6b383c9-37e7-4b74-bb95-1bdd1228f61a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6b383c9-37e7-4b74-bb95-1bdd1228f61a">
											<gml:posList>35.6681031405913 139.73896241319164 30.115 35.6681031405913 139.73896241319164 29.635 35.668089059752 139.7389836490215 29.635 35.668089059752 139.7389836490215 30.115 35.6681031405913 139.73896241319164 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e341c7c-eff0-4b81-a48f-9635cfb64313">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e341c7c-eff0-4b81-a48f-9635cfb64313">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e341c7c-eff0-4b81-a48f-9635cfb64313">
											<gml:posList>35.66808931455963 139.73898674158588 12.92 35.668103368375604 139.73896552788023 12.92 35.668103368375604 139.73896552788023 30.115 35.66808931455963 139.73898674158588 30.115 35.66808931455963 139.73898674158588 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b40ff9c-0587-483a-9124-c74431502496">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b40ff9c-0587-483a-9124-c74431502496">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b40ff9c-0587-483a-9124-c74431502496">
											<gml:posList>35.66818138959995 139.73875661225287 12.92 35.66809632841139 139.73888474612627 12.92 35.66809632841139 139.73888474612627 20.276 35.66806767154704 139.73892791427943 20.276 35.66806767154704 139.73892791427943 12.92 35.668048413907705 139.73895692149392 12.92 35.668048413907705 139.73895692149392 33.95 35.66806737444916 139.73892836751278 33.95 35.66806737444916 139.73892836751278 30.115 35.66818138959995 139.73875661225287 30.115 35.66818138959995 139.73875661225287 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47529900-d1bd-404b-9827-c6a4f410adae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47529900-d1bd-404b-9827-c6a4f410adae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47529900-d1bd-404b-9827-c6a4f410adae">
											<gml:posList>35.668103368375604 139.73896552788023 12.92 35.668137684326986 139.7390008897651 12.92 35.668137684326986 139.7390008897651 30.115 35.668103368375604 139.73896552788023 30.115 35.668103368375604 139.73896552788023 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8ad8ba0-3fcc-4b7a-8661-23352533f920">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8ad8ba0-3fcc-4b7a-8661-23352533f920">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8ad8ba0-3fcc-4b7a-8661-23352533f920">
											<gml:posList>35.66813881872381 139.73899918735412 30.115 35.66813881872381 139.73899918735412 29.635 35.6681031405913 139.73896241319164 29.635 35.6681031405913 139.73896241319164 30.115 35.66813881872381 139.73899918735412 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba470aa3-9e43-4765-ba40-4d38d887d1da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba470aa3-9e43-4765-ba40-4d38d887d1da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba470aa3-9e43-4765-ba40-4d38d887d1da">
											<gml:posList>35.668137684326986 139.7390008897651 12.92 35.66814652478694 139.73900982658552 12.92 35.66814652478694 139.73900982658552 30.115 35.668137684326986 139.7390008897651 30.115 35.668137684326986 139.7390008897651 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba634bab-9772-46d1-9fe7-2d01985941be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba634bab-9772-46d1-9fe7-2d01985941be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba634bab-9772-46d1-9fe7-2d01985941be">
											<gml:posList>35.66814627899363 139.7390067340082 30.115 35.66814627899363 139.7390067340082 29.635 35.66813881872381 139.73899918735412 29.635 35.66813881872381 139.73899918735412 30.115 35.66814627899363 139.7390067340082 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d142d4c9-772d-4966-b15d-bdb7a7abeb9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d142d4c9-772d-4966-b15d-bdb7a7abeb9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d142d4c9-772d-4966-b15d-bdb7a7abeb9f">
											<gml:posList>35.66814652478694 139.73900982658552 12.92 35.66826158449162 139.73883660092682 12.92 35.66826158449162 139.73883660092682 30.115 35.66814652478694 139.73900982658552 30.115 35.66814652478694 139.73900982658552 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-303ac92e-4f24-45e7-9d9e-eea6d9459176">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-303ac92e-4f24-45e7-9d9e-eea6d9459176">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-303ac92e-4f24-45e7-9d9e-eea6d9459176">
											<gml:posList>35.66818164439606 139.7387596827282 30.115 35.66818164439606 139.7387596827282 29.635 35.66825907891865 139.73883691316672 29.635 35.66825907891865 139.73883691316672 30.115 35.66818164439606 139.7387596827282 30.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a36d13f-0843-453a-bac1-4a79a009a7cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a36d13f-0843-453a-bac1-4a79a009a7cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a36d13f-0843-453a-bac1-4a79a009a7cb">
											<gml:posList>35.66826158449162 139.73883660092682 12.92 35.66818138959995 139.73875661225287 12.92 35.66818138959995 139.73875661225287 30.115 35.66826158449162 139.73883660092682 30.115 35.66826158449162 139.73883660092682 12.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2401</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">259.5396</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1002</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">12</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>