<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_258f1741-a402-4946-a860-64f3026996e8">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67454226539127 139.7397426716376 0 35.67454859022021 139.73966951212063 0 35.674580159476804 139.73967361779984 0 35.67458476018869 139.7396204660837 0 35.67445395781212 139.7396034632785 0 35.67444303228618 139.73972977433624 0 35.67454226539127 139.7397426716376 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67454226539127 139.7397426716376 26.36 35.67444303228618 139.73972977433624 26.36 35.67445395781212 139.7396034632785 26.36 35.67458476018869 139.7396204660837 26.36 35.674580159476804 139.73967361779984 26.36 35.67454859022021 139.73966951212063 26.36 35.67454226539127 139.7397426716376 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67454226539127 139.7397426716376 26.36 35.67454859022021 139.73966951212063 26.36 35.67454859022021 139.73966951212063 29.36 35.67454226539127 139.7397426716376 29.36 35.67454226539127 139.7397426716376 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67454859022021 139.73966951212063 26.36 35.674580159476804 139.73967361779984 26.36 35.674580159476804 139.73967361779984 29.36 35.67454859022021 139.73966951212063 29.36 35.67454859022021 139.73966951212063 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674580159476804 139.73967361779984 26.36 35.67458476018869 139.7396204660837 26.36 35.67458476018869 139.7396204660837 29.36 35.674580159476804 139.73967361779984 29.36 35.674580159476804 139.73967361779984 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67458476018869 139.7396204660837 26.36 35.67445395781212 139.7396034632785 26.36 35.67445395781212 139.7396034632785 29.36 35.67458476018869 139.7396204660837 29.36 35.67458476018869 139.7396204660837 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67445395781212 139.7396034632785 26.36 35.67444303228618 139.73972977433624 26.36 35.67444303228618 139.73972977433624 29.36 35.67445395781212 139.7396034632785 29.36 35.67445395781212 139.7396034632785 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67444303228618 139.73972977433624 26.36 35.67454226539127 139.7397426716376 26.36 35.67454226539127 139.7397426716376 29.36 35.67444303228618 139.73972977433624 29.36 35.67444303228618 139.73972977433624 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67454226539127 139.7397426716376 29.36 35.67454859022021 139.73966951212063 29.36 35.674580159476804 139.73967361779984 29.36 35.67458476018869 139.7396204660837 29.36 35.67445395781212 139.7396034632785 29.36 35.67444303228618 139.73972977433624 29.36 35.67454226539127 139.7397426716376 29.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f9b530c3-9ab7-47a0-9b40-ca24e4333d69"/>
							<gml:surfaceMember xlink:href="#poly-0a2947d7-9452-47e6-b7e5-2644e83d2f07"/>
							<gml:surfaceMember xlink:href="#poly-ff476494-24f6-4379-8941-15c4912e6745"/>
							<gml:surfaceMember xlink:href="#poly-32cfb603-efcb-4570-8a05-92cc4c07df22"/>
							<gml:surfaceMember xlink:href="#poly-c7a66782-e5a2-41ea-867c-daea3a7040a1"/>
							<gml:surfaceMember xlink:href="#poly-48dbb812-0850-4659-b968-93445347e532"/>
							<gml:surfaceMember xlink:href="#poly-0db3b836-e35e-4c00-8346-83c266829942"/>
							<gml:surfaceMember xlink:href="#poly-120f93a1-8c9a-4c7b-b126-f2e3ff70d147"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f9b530c3-9ab7-47a0-9b40-ca24e4333d69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9b530c3-9ab7-47a0-9b40-ca24e4333d69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9b530c3-9ab7-47a0-9b40-ca24e4333d69">
											<gml:posList>35.674584760188644 139.7396204660837 26.36 35.67458016849051 139.7396736177893 26.36 35.67454859022022 139.73966951212063 26.36 35.674542265391246 139.7397426716376 26.36 35.67444303228616 139.7397297743362 26.36 35.67445395781212 139.73960346327848 26.36 35.674584760188644 139.7396204660837 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a2947d7-9452-47e6-b7e5-2644e83d2f07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a2947d7-9452-47e6-b7e5-2644e83d2f07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a2947d7-9452-47e6-b7e5-2644e83d2f07">
											<gml:posList>35.67444303228616 139.7397297743362 28.118 35.674542265391246 139.7397426716376 28.118 35.67454859022022 139.73966951212063 28.118 35.67458016849051 139.7396736177893 28.118 35.674584760188644 139.7396204660837 28.118 35.67445395781212 139.73960346327848 28.118 35.67444303228616 139.7397297743362 28.118</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff476494-24f6-4379-8941-15c4912e6745">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff476494-24f6-4379-8941-15c4912e6745">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff476494-24f6-4379-8941-15c4912e6745">
											<gml:posList>35.67445395781212 139.73960346327848 26.36 35.67444303228616 139.7397297743362 26.36 35.67444303228616 139.7397297743362 28.118 35.67445395781212 139.73960346327848 28.118 35.67445395781212 139.73960346327848 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32cfb603-efcb-4570-8a05-92cc4c07df22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32cfb603-efcb-4570-8a05-92cc4c07df22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32cfb603-efcb-4570-8a05-92cc4c07df22">
											<gml:posList>35.67444303228616 139.7397297743362 26.36 35.674542265391246 139.7397426716376 26.36 35.674542265391246 139.7397426716376 28.118 35.67444303228616 139.7397297743362 28.118 35.67444303228616 139.7397297743362 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7a66782-e5a2-41ea-867c-daea3a7040a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7a66782-e5a2-41ea-867c-daea3a7040a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7a66782-e5a2-41ea-867c-daea3a7040a1">
											<gml:posList>35.674584760188644 139.7396204660837 26.36 35.67445395781212 139.73960346327848 26.36 35.67445395781212 139.73960346327848 28.118 35.674584760188644 139.7396204660837 28.118 35.674584760188644 139.7396204660837 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48dbb812-0850-4659-b968-93445347e532">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48dbb812-0850-4659-b968-93445347e532">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48dbb812-0850-4659-b968-93445347e532">
											<gml:posList>35.674542265391246 139.7397426716376 26.36 35.67454859022022 139.73966951212063 26.36 35.67454859022022 139.73966951212063 28.118 35.674542265391246 139.7397426716376 28.118 35.674542265391246 139.7397426716376 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0db3b836-e35e-4c00-8346-83c266829942">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0db3b836-e35e-4c00-8346-83c266829942">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0db3b836-e35e-4c00-8346-83c266829942">
											<gml:posList>35.67454859022022 139.73966951212063 26.36 35.67458016849051 139.7396736177893 26.36 35.67458016849051 139.7396736177893 28.118 35.67454859022022 139.73966951212063 28.118 35.67454859022022 139.73966951212063 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-120f93a1-8c9a-4c7b-b126-f2e3ff70d147">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-120f93a1-8c9a-4c7b-b126-f2e3ff70d147">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-120f93a1-8c9a-4c7b-b126-f2e3ff70d147">
											<gml:posList>35.67458016849051 139.7396736177893 26.36 35.674584760188644 139.7396204660837 26.36 35.674584760188644 139.7396204660837 28.118 35.67458016849051 139.7396736177893 28.118 35.67458016849051 139.7396736177893 26.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4590</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>