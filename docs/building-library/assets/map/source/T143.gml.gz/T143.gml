<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_260963f6-12d9-477c-b0c9-3cc41a7b5654">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門一・二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:measuredHeight uom="m">3.8</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66803641359325 139.74769569658068 0 35.66810684433655 139.74765405546157 0 35.668109580431654 139.74766098939287 0 35.668119085922115 139.7476553678949 0 35.66809017167845 139.74758194325818 0 35.667919198989566 139.74768303058974 0 35.66793191328769 139.74771531528728 0 35.66792213750005 139.74772110274242 0 35.66793569157978 139.7477555184141 0 35.667944025784905 139.74775059408293 0 35.66794937155952 139.74776416381943 0 35.66804184967623 139.7477094981974 0 35.66803641359325 139.74769569658068 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66803641359325 139.74769569658068 5.457 35.66804184967623 139.7477094981974 5.457 35.66794937155952 139.74776416381943 5.457 35.667944025784905 139.74775059408293 5.457 35.66793569157978 139.7477555184141 5.457 35.66792213750005 139.74772110274242 5.457 35.66793191328769 139.74771531528728 5.457 35.667919198989566 139.74768303058974 5.457 35.66809017167845 139.74758194325818 5.457 35.668119085922115 139.7476553678949 5.457 35.668109580431654 139.74766098939287 5.457 35.66810684433655 139.74765405546157 5.457 35.66803641359325 139.74769569658068 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66803641359325 139.74769569658068 5.457 35.66810684433655 139.74765405546157 5.457 35.66810684433655 139.74765405546157 9.24 35.66803641359325 139.74769569658068 9.24 35.66803641359325 139.74769569658068 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66810684433655 139.74765405546157 5.457 35.668109580431654 139.74766098939287 5.457 35.668109580431654 139.74766098939287 9.24 35.66810684433655 139.74765405546157 9.24 35.66810684433655 139.74765405546157 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668109580431654 139.74766098939287 5.457 35.668119085922115 139.7476553678949 5.457 35.668119085922115 139.7476553678949 9.24 35.668109580431654 139.74766098939287 9.24 35.668109580431654 139.74766098939287 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668119085922115 139.7476553678949 5.457 35.66809017167845 139.74758194325818 5.457 35.66809017167845 139.74758194325818 9.24 35.668119085922115 139.7476553678949 9.24 35.668119085922115 139.7476553678949 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66809017167845 139.74758194325818 5.457 35.667919198989566 139.74768303058974 5.457 35.667919198989566 139.74768303058974 9.24 35.66809017167845 139.74758194325818 9.24 35.66809017167845 139.74758194325818 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667919198989566 139.74768303058974 5.457 35.66793191328769 139.74771531528728 5.457 35.66793191328769 139.74771531528728 9.24 35.667919198989566 139.74768303058974 9.24 35.667919198989566 139.74768303058974 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66793191328769 139.74771531528728 5.457 35.66792213750005 139.74772110274242 5.457 35.66792213750005 139.74772110274242 9.24 35.66793191328769 139.74771531528728 9.24 35.66793191328769 139.74771531528728 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66792213750005 139.74772110274242 5.457 35.66793569157978 139.7477555184141 5.457 35.66793569157978 139.7477555184141 9.24 35.66792213750005 139.74772110274242 9.24 35.66792213750005 139.74772110274242 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66793569157978 139.7477555184141 5.457 35.667944025784905 139.74775059408293 5.457 35.667944025784905 139.74775059408293 9.24 35.66793569157978 139.7477555184141 9.24 35.66793569157978 139.7477555184141 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667944025784905 139.74775059408293 5.457 35.66794937155952 139.74776416381943 5.457 35.66794937155952 139.74776416381943 9.24 35.667944025784905 139.74775059408293 9.24 35.667944025784905 139.74775059408293 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66794937155952 139.74776416381943 5.457 35.66804184967623 139.7477094981974 5.457 35.66804184967623 139.7477094981974 9.24 35.66794937155952 139.74776416381943 9.24 35.66794937155952 139.74776416381943 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66804184967623 139.7477094981974 5.457 35.66803641359325 139.74769569658068 5.457 35.66803641359325 139.74769569658068 9.24 35.66804184967623 139.7477094981974 9.24 35.66804184967623 139.7477094981974 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66803641359325 139.74769569658068 9.24 35.66810684433655 139.74765405546157 9.24 35.668109580431654 139.74766098939287 9.24 35.668119085922115 139.7476553678949 9.24 35.66809017167845 139.74758194325818 9.24 35.667919198989566 139.74768303058974 9.24 35.66793191328769 139.74771531528728 9.24 35.66792213750005 139.74772110274242 9.24 35.66793569157978 139.7477555184141 9.24 35.667944025784905 139.74775059408293 9.24 35.66794937155952 139.74776416381943 9.24 35.66804184967623 139.7477094981974 9.24 35.66803641359325 139.74769569658068 9.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-13ec034d-f245-4686-b5e2-922f1e532cd5"/>
							<gml:surfaceMember xlink:href="#poly-ada4ba55-a1a6-439f-9e97-8a44bee85faf"/>
							<gml:surfaceMember xlink:href="#poly-f0a5ab2b-3077-4e2b-9e8f-25f8ddd5ab2d"/>
							<gml:surfaceMember xlink:href="#poly-b53be34c-a25f-4aee-a2a3-3c772e1daa9d"/>
							<gml:surfaceMember xlink:href="#poly-db52a3e8-8848-4a35-be31-21b8e2e5da67"/>
							<gml:surfaceMember xlink:href="#poly-c5855fe7-46b9-4d9e-a3d6-ca932b192770"/>
							<gml:surfaceMember xlink:href="#poly-a8e4109b-122c-4eda-b69e-4a2e56c1b049"/>
							<gml:surfaceMember xlink:href="#poly-d733ed02-f1a3-4e97-b02f-45fd3f3fab22"/>
							<gml:surfaceMember xlink:href="#poly-94781031-74fd-444e-bd7b-10ce0ef720af"/>
							<gml:surfaceMember xlink:href="#poly-3cc67bb4-7591-4847-972c-d09fa414ca86"/>
							<gml:surfaceMember xlink:href="#poly-f5593a3b-6fbb-4d96-b58b-832ac5984171"/>
							<gml:surfaceMember xlink:href="#poly-73b16fe8-9d8f-4197-a5f6-3488823fdee4"/>
							<gml:surfaceMember xlink:href="#poly-90b33f29-b119-4a76-86ac-f5e739884778"/>
							<gml:surfaceMember xlink:href="#poly-1ec98099-9ffa-4676-a299-ef86abfd0fa4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-13ec034d-f245-4686-b5e2-922f1e532cd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13ec034d-f245-4686-b5e2-922f1e532cd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13ec034d-f245-4686-b5e2-922f1e532cd5">
											<gml:posList>35.66803641359322 139.74769569658068 5.457 35.66804184967622 139.7477094981974 5.457 35.66794937155952 139.74776416381943 5.457 35.66794402578488 139.7477505940829 5.457 35.667935691579736 139.74775551841407 5.457 35.66792213750002 139.74772110274242 5.457 35.667931913287674 139.74771531528728 5.457 35.667919198989566 139.74768303058974 5.457 35.66809017167844 139.7475819432582 5.457 35.6681190859221 139.7476553678949 5.457 35.66810958043162 139.7476609893929 5.457 35.66810684433653 139.74765405546157 5.457 35.66803641359322 139.74769569658068 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ada4ba55-a1a6-439f-9e97-8a44bee85faf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ada4ba55-a1a6-439f-9e97-8a44bee85faf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ada4ba55-a1a6-439f-9e97-8a44bee85faf">
											<gml:posList>35.66803641359322 139.74769569658068 8.3 35.66794402578488 139.7477505940829 8.3 35.66794937155952 139.74776416381943 8.3 35.66804184967622 139.7477094981974 8.3 35.66803641359322 139.74769569658068 8.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0a5ab2b-3077-4e2b-9e8f-25f8ddd5ab2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0a5ab2b-3077-4e2b-9e8f-25f8ddd5ab2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0a5ab2b-3077-4e2b-9e8f-25f8ddd5ab2d">
											<gml:posList>35.66810684433653 139.74765405546157 9.6 35.66810958043162 139.7476609893929 9.6 35.6681190859221 139.7476553678949 9.6 35.66809017167844 139.7475819432582 9.6 35.667919198989566 139.74768303058974 9.6 35.667931913287674 139.74771531528728 9.6 35.66792213750002 139.74772110274242 9.6 35.667935691579736 139.74775551841407 9.6 35.66810684433653 139.74765405546157 9.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b53be34c-a25f-4aee-a2a3-3c772e1daa9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b53be34c-a25f-4aee-a2a3-3c772e1daa9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b53be34c-a25f-4aee-a2a3-3c772e1daa9d">
											<gml:posList>35.6681190859221 139.7476553678949 5.457 35.66809017167844 139.7475819432582 5.457 35.66809017167844 139.7475819432582 9.6 35.6681190859221 139.7476553678949 9.6 35.6681190859221 139.7476553678949 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db52a3e8-8848-4a35-be31-21b8e2e5da67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db52a3e8-8848-4a35-be31-21b8e2e5da67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db52a3e8-8848-4a35-be31-21b8e2e5da67">
											<gml:posList>35.66809017167844 139.7475819432582 5.457 35.667919198989566 139.74768303058974 5.457 35.667919198989566 139.74768303058974 9.6 35.66809017167844 139.7475819432582 9.6 35.66809017167844 139.7475819432582 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c5855fe7-46b9-4d9e-a3d6-ca932b192770">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5855fe7-46b9-4d9e-a3d6-ca932b192770">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5855fe7-46b9-4d9e-a3d6-ca932b192770">
											<gml:posList>35.66810684433653 139.74765405546157 5.457 35.66810958043162 139.7476609893929 5.457 35.66810958043162 139.7476609893929 9.6 35.66810684433653 139.74765405546157 9.6 35.66810684433653 139.74765405546157 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8e4109b-122c-4eda-b69e-4a2e56c1b049">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8e4109b-122c-4eda-b69e-4a2e56c1b049">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8e4109b-122c-4eda-b69e-4a2e56c1b049">
											<gml:posList>35.66810958043162 139.7476609893929 5.457 35.6681190859221 139.7476553678949 5.457 35.6681190859221 139.7476553678949 9.6 35.66810958043162 139.7476609893929 9.6 35.66810958043162 139.7476609893929 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d733ed02-f1a3-4e97-b02f-45fd3f3fab22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d733ed02-f1a3-4e97-b02f-45fd3f3fab22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d733ed02-f1a3-4e97-b02f-45fd3f3fab22">
											<gml:posList>35.667919198989566 139.74768303058974 5.457 35.667931913287674 139.74771531528728 5.457 35.667931913287674 139.74771531528728 9.6 35.667919198989566 139.74768303058974 9.6 35.667919198989566 139.74768303058974 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94781031-74fd-444e-bd7b-10ce0ef720af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94781031-74fd-444e-bd7b-10ce0ef720af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94781031-74fd-444e-bd7b-10ce0ef720af">
											<gml:posList>35.66804184967622 139.7477094981974 5.457 35.66803641359322 139.74769569658068 5.457 35.66803641359322 139.74769569658068 8.3 35.66804184967622 139.7477094981974 8.3 35.66804184967622 139.7477094981974 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cc67bb4-7591-4847-972c-d09fa414ca86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cc67bb4-7591-4847-972c-d09fa414ca86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cc67bb4-7591-4847-972c-d09fa414ca86">
											<gml:posList>35.66803641359322 139.74769569658068 8.3 35.66803641359322 139.74769569658068 5.457 35.66810684433653 139.74765405546157 5.457 35.66810684433653 139.74765405546157 9.6 35.667935691579736 139.74775551841407 9.6 35.667935691579736 139.74775551841407 5.457 35.66794402578488 139.7477505940829 5.457 35.66794402578488 139.7477505940829 8.3 35.66803641359322 139.74769569658068 8.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5593a3b-6fbb-4d96-b58b-832ac5984171">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5593a3b-6fbb-4d96-b58b-832ac5984171">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5593a3b-6fbb-4d96-b58b-832ac5984171">
											<gml:posList>35.667931913287674 139.74771531528728 5.457 35.66792213750002 139.74772110274242 5.457 35.66792213750002 139.74772110274242 9.6 35.667931913287674 139.74771531528728 9.6 35.667931913287674 139.74771531528728 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73b16fe8-9d8f-4197-a5f6-3488823fdee4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73b16fe8-9d8f-4197-a5f6-3488823fdee4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73b16fe8-9d8f-4197-a5f6-3488823fdee4">
											<gml:posList>35.66794937155952 139.74776416381943 5.457 35.66804184967622 139.7477094981974 5.457 35.66804184967622 139.7477094981974 8.3 35.66794937155952 139.74776416381943 8.3 35.66794937155952 139.74776416381943 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90b33f29-b119-4a76-86ac-f5e739884778">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90b33f29-b119-4a76-86ac-f5e739884778">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90b33f29-b119-4a76-86ac-f5e739884778">
											<gml:posList>35.66792213750002 139.74772110274242 5.457 35.667935691579736 139.74775551841407 5.457 35.667935691579736 139.74775551841407 9.6 35.66792213750002 139.74772110274242 9.6 35.66792213750002 139.74772110274242 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ec98099-9ffa-4676-a299-ef86abfd0fa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ec98099-9ffa-4676-a299-ef86abfd0fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ec98099-9ffa-4676-a299-ef86abfd0fa4">
											<gml:posList>35.66794402578488 139.7477505940829 5.457 35.66794937155952 139.74776416381943 5.457 35.66794937155952 139.74776416381943 8.3 35.66794402578488 139.7477505940829 8.3 35.66794402578488 139.7477505940829 5.457</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7779</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">224</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.41</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>