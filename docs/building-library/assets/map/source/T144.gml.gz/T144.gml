<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2667838a-e5bb-4a0d-94ac-6aa40b7f6da0">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">4.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6684285753769 139.74206503671246 0 35.668478338093 139.74207414824818 0 35.668482279934885 139.74204222082724 0 35.66843242699544 139.7420329989537 0 35.6684285753769 139.74206503671246 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6684285753769 139.74206503671246 16.44 35.66843242699544 139.7420329989537 16.44 35.668482279934885 139.74204222082724 16.44 35.668478338093 139.74207414824818 16.44 35.6684285753769 139.74206503671246 16.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6684285753769 139.74206503671246 16.44 35.668478338093 139.74207414824818 16.44 35.668478338093 139.74207414824818 21.34 35.6684285753769 139.74206503671246 21.34 35.6684285753769 139.74206503671246 16.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668478338093 139.74207414824818 16.44 35.668482279934885 139.74204222082724 16.44 35.668482279934885 139.74204222082724 21.34 35.668478338093 139.74207414824818 21.34 35.668478338093 139.74207414824818 16.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668482279934885 139.74204222082724 16.44 35.66843242699544 139.7420329989537 16.44 35.66843242699544 139.7420329989537 21.34 35.668482279934885 139.74204222082724 21.34 35.668482279934885 139.74204222082724 16.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66843242699544 139.7420329989537 16.44 35.6684285753769 139.74206503671246 16.44 35.6684285753769 139.74206503671246 21.34 35.66843242699544 139.7420329989537 21.34 35.66843242699544 139.7420329989537 16.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6684285753769 139.74206503671246 21.34 35.668478338093 139.74207414824818 21.34 35.668482279934885 139.74204222082724 21.34 35.66843242699544 139.7420329989537 21.34 35.6684285753769 139.74206503671246 21.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f125f1ac-c283-4b48-978c-7b96ec522824"/>
							<gml:surfaceMember xlink:href="#poly-03051a5e-9706-4b7c-9dc5-cca6daed1046"/>
							<gml:surfaceMember xlink:href="#poly-bc93d68d-ef1f-4c50-b0f2-893150e44ea4"/>
							<gml:surfaceMember xlink:href="#poly-814b5b0b-cdb5-45c9-bf5a-7598df8da036"/>
							<gml:surfaceMember xlink:href="#poly-cc875635-46d5-428a-ac4e-45d1a5b038ca"/>
							<gml:surfaceMember xlink:href="#poly-33f0e00b-1e3e-4741-b31c-f19ea56fe0ae"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f125f1ac-c283-4b48-978c-7b96ec522824">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f125f1ac-c283-4b48-978c-7b96ec522824">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f125f1ac-c283-4b48-978c-7b96ec522824">
											<gml:posList>35.66842857537689 139.74206503671243 16.44 35.668432426995395 139.74203299895368 16.44 35.66848227993485 139.74204222082722 16.44 35.66847833809298 139.74207414824818 16.44 35.66842857537689 139.74206503671243 16.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03051a5e-9706-4b7c-9dc5-cca6daed1046">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03051a5e-9706-4b7c-9dc5-cca6daed1046">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03051a5e-9706-4b7c-9dc5-cca6daed1046">
											<gml:posList>35.668432426995395 139.74203299895368 22.2 35.66842857537689 139.74206503671243 22.2 35.66847833809298 139.74207414824818 22.2 35.66848227993485 139.74204222082722 22.2 35.668432426995395 139.74203299895368 22.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc93d68d-ef1f-4c50-b0f2-893150e44ea4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc93d68d-ef1f-4c50-b0f2-893150e44ea4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc93d68d-ef1f-4c50-b0f2-893150e44ea4">
											<gml:posList>35.66848227993485 139.74204222082722 16.44 35.668432426995395 139.74203299895368 16.44 35.668432426995395 139.74203299895368 22.2 35.66848227993485 139.74204222082722 22.2 35.66848227993485 139.74204222082722 16.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-814b5b0b-cdb5-45c9-bf5a-7598df8da036">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-814b5b0b-cdb5-45c9-bf5a-7598df8da036">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-814b5b0b-cdb5-45c9-bf5a-7598df8da036">
											<gml:posList>35.668432426995395 139.74203299895368 16.44 35.66842857537689 139.74206503671243 16.44 35.66842857537689 139.74206503671243 22.2 35.668432426995395 139.74203299895368 22.2 35.668432426995395 139.74203299895368 16.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc875635-46d5-428a-ac4e-45d1a5b038ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc875635-46d5-428a-ac4e-45d1a5b038ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc875635-46d5-428a-ac4e-45d1a5b038ca">
											<gml:posList>35.66847833809298 139.74207414824818 16.44 35.66848227993485 139.74204222082722 16.44 35.66848227993485 139.74204222082722 22.2 35.66847833809298 139.74207414824818 22.2 35.66847833809298 139.74207414824818 16.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33f0e00b-1e3e-4741-b31c-f19ea56fe0ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33f0e00b-1e3e-4741-b31c-f19ea56fe0ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33f0e00b-1e3e-4741-b31c-f19ea56fe0ae">
											<gml:posList>35.66842857537689 139.74206503671243 16.44 35.66847833809298 139.74207414824818 16.44 35.66847833809298 139.74207414824818 22.2 35.66842857537689 139.74206503671243 22.2 35.66842857537689 139.74206503671243 16.44</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1721</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.33</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>