<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_26df9d58-09f6-4ead-95c0-8405ff4ec06d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">11.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67224758849925 139.73981415921006 0 35.67228405450185 139.7397631922081 0 35.672212245179075 139.7396859504355 0 35.67217577929463 139.73973702789175 0 35.67224758849925 139.73981415921006 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67224758849925 139.73981415921006 7.94 35.67217577929463 139.73973702789175 7.94 35.672212245179075 139.7396859504355 7.94 35.67228405450185 139.7397631922081 7.94 35.67224758849925 139.73981415921006 7.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67224758849925 139.73981415921006 7.94 35.67228405450185 139.7397631922081 7.94 35.67228405450185 139.7397631922081 19.54 35.67224758849925 139.73981415921006 19.54 35.67224758849925 139.73981415921006 7.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67228405450185 139.7397631922081 7.94 35.672212245179075 139.7396859504355 7.94 35.672212245179075 139.7396859504355 19.54 35.67228405450185 139.7397631922081 19.54 35.67228405450185 139.7397631922081 7.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672212245179075 139.7396859504355 7.94 35.67217577929463 139.73973702789175 7.94 35.67217577929463 139.73973702789175 19.54 35.672212245179075 139.7396859504355 19.54 35.672212245179075 139.7396859504355 7.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67217577929463 139.73973702789175 7.94 35.67224758849925 139.73981415921006 7.94 35.67224758849925 139.73981415921006 19.54 35.67217577929463 139.73973702789175 19.54 35.67217577929463 139.73973702789175 7.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67224758849925 139.73981415921006 19.54 35.67228405450185 139.7397631922081 19.54 35.672212245179075 139.7396859504355 19.54 35.67217577929463 139.73973702789175 19.54 35.67224758849925 139.73981415921006 19.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9608d263-2367-4c58-acd5-d09153d73837"/>
							<gml:surfaceMember xlink:href="#poly-74897b74-9ee9-4b55-885c-6ada5db44150"/>
							<gml:surfaceMember xlink:href="#poly-71d2647b-229f-40a2-8b5c-93532c2ad9c4"/>
							<gml:surfaceMember xlink:href="#poly-c1fb2fd5-f7e5-4f1b-b54d-d391fb15c6d1"/>
							<gml:surfaceMember xlink:href="#poly-9e5d4c86-ae8d-4fd6-ac9f-529525bf77f7"/>
							<gml:surfaceMember xlink:href="#poly-dfecd1dd-e06d-47ab-b9f7-9ca5b0701097"/>
							<gml:surfaceMember xlink:href="#poly-110f05bc-e6a3-4f3e-91c5-c5519448ded6"/>
							<gml:surfaceMember xlink:href="#poly-693a366d-9909-47fb-814c-5b2557b785df"/>
							<gml:surfaceMember xlink:href="#poly-38bb0193-c626-41e6-a86b-c5da06315360"/>
							<gml:surfaceMember xlink:href="#poly-ed391225-a631-4971-8fb7-1b256dbb2f25"/>
							<gml:surfaceMember xlink:href="#poly-5798213b-6afa-4115-84a1-f83f68ba2759"/>
							<gml:surfaceMember xlink:href="#poly-bc21b070-5f35-4545-8453-23bb8d15e01b"/>
							<gml:surfaceMember xlink:href="#poly-dd972805-2e7e-4bef-aff0-ee2de509ed36"/>
							<gml:surfaceMember xlink:href="#poly-c6a0cfcb-729b-4501-afdf-c18c69445dc6"/>
							<gml:surfaceMember xlink:href="#poly-0692c573-3303-4876-99f2-ec37716b15bd"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9608d263-2367-4c58-acd5-d09153d73837">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9608d263-2367-4c58-acd5-d09153d73837">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9608d263-2367-4c58-acd5-d09153d73837">
											<gml:posList>35.672247588499275 139.73981415921006 7.94 35.67217577929462 139.73973702789172 7.94 35.67221224517906 139.73968595043547 7.94 35.67228405450182 139.7397631922081 7.94 35.672247588499275 139.73981415921006 7.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74897b74-9ee9-4b55-885c-6ada5db44150">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74897b74-9ee9-4b55-885c-6ada5db44150">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74897b74-9ee9-4b55-885c-6ada5db44150">
											<gml:posList>35.67217577929462 139.73973702789172 20.036 35.67218025884718 139.73973668022037 20.036 35.672212546901534 139.7396914401994 20.036 35.67221224517906 139.73968595043547 20.036 35.67217577929462 139.73973702789172 20.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71d2647b-229f-40a2-8b5c-93532c2ad9c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71d2647b-229f-40a2-8b5c-93532c2ad9c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71d2647b-229f-40a2-8b5c-93532c2ad9c4">
											<gml:posList>35.67223168402912 139.7397970777579 20.036 35.67223139133377 139.73979159902822 20.036 35.67218025884718 139.73973668022037 20.036 35.67217577929462 139.73973702789172 20.036 35.67223168402912 139.7397970777579 20.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1fb2fd5-f7e5-4f1b-b54d-d391fb15c6d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1fb2fd5-f7e5-4f1b-b54d-d391fb15c6d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1fb2fd5-f7e5-4f1b-b54d-d391fb15c6d1">
											<gml:posList>35.6722637155578 139.73974648046996 19.697 35.672212546901534 139.7396914401994 19.697 35.67218025884718 139.73973668022037 19.697 35.67223139133377 139.73979159902822 19.697 35.6722637155578 139.73974648046996 19.697</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e5d4c86-ae8d-4fd6-ac9f-529525bf77f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e5d4c86-ae8d-4fd6-ac9f-529525bf77f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e5d4c86-ae8d-4fd6-ac9f-529525bf77f7">
											<gml:posList>35.67221224517906 139.73968595043547 20.036 35.672212546901534 139.7396914401994 20.036 35.6722637155578 139.73974648046996 20.036 35.672268186088004 139.73974612176275 20.036 35.67221224517906 139.73968595043547 20.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dfecd1dd-e06d-47ab-b9f7-9ca5b0701097">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfecd1dd-e06d-47ab-b9f7-9ca5b0701097">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfecd1dd-e06d-47ab-b9f7-9ca5b0701097">
											<gml:posList>35.672268186088004 139.73974612176275 20.036 35.6722637155578 139.73974648046996 20.036 35.67223139133377 139.73979159902822 20.036 35.67223168402912 139.7397970777579 20.036 35.672268186088004 139.73974612176275 20.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-110f05bc-e6a3-4f3e-91c5-c5519448ded6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-110f05bc-e6a3-4f3e-91c5-c5519448ded6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-110f05bc-e6a3-4f3e-91c5-c5519448ded6">
											<gml:posList>35.67223168402912 139.7397970777579 20.036 35.672247588499275 139.73981415921006 17.077 35.67228405450182 139.7397631922081 17.077 35.672268186088004 139.73974612176275 20.036 35.67223168402912 139.7397970777579 20.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-693a366d-9909-47fb-814c-5b2557b785df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-693a366d-9909-47fb-814c-5b2557b785df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-693a366d-9909-47fb-814c-5b2557b785df">
											<gml:posList>35.672212546901534 139.7396914401994 20.036 35.672212546901534 139.7396914401994 19.697 35.6722637155578 139.73974648046996 19.697 35.6722637155578 139.73974648046996 20.036 35.672212546901534 139.7396914401994 20.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38bb0193-c626-41e6-a86b-c5da06315360">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38bb0193-c626-41e6-a86b-c5da06315360">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38bb0193-c626-41e6-a86b-c5da06315360">
											<gml:posList>35.67223139133377 139.73979159902822 20.036 35.67223139133377 139.73979159902822 19.697 35.67218025884718 139.73973668022037 19.697 35.67218025884718 139.73973668022037 20.036 35.67223139133377 139.73979159902822 20.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed391225-a631-4971-8fb7-1b256dbb2f25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed391225-a631-4971-8fb7-1b256dbb2f25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed391225-a631-4971-8fb7-1b256dbb2f25">
											<gml:posList>35.67221224517906 139.73968595043547 7.94 35.67217577929462 139.73973702789172 7.94 35.67217577929462 139.73973702789172 20.036 35.67221224517906 139.73968595043547 20.036 35.67221224517906 139.73968595043547 7.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5798213b-6afa-4115-84a1-f83f68ba2759">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5798213b-6afa-4115-84a1-f83f68ba2759">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5798213b-6afa-4115-84a1-f83f68ba2759">
											<gml:posList>35.67218025884718 139.73973668022037 20.036 35.67218025884718 139.73973668022037 19.697 35.672212546901534 139.7396914401994 19.697 35.672212546901534 139.7396914401994 20.036 35.67218025884718 139.73973668022037 20.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc21b070-5f35-4545-8453-23bb8d15e01b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc21b070-5f35-4545-8453-23bb8d15e01b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc21b070-5f35-4545-8453-23bb8d15e01b">
											<gml:posList>35.67221224517906 139.73968595043547 20.036 35.672268186088004 139.73974612176275 20.036 35.67228405450182 139.7397631922081 17.077 35.67228405450182 139.7397631922081 7.94 35.67221224517906 139.73968595043547 7.94 35.67221224517906 139.73968595043547 20.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd972805-2e7e-4bef-aff0-ee2de509ed36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd972805-2e7e-4bef-aff0-ee2de509ed36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd972805-2e7e-4bef-aff0-ee2de509ed36">
											<gml:posList>35.6722637155578 139.73974648046996 20.036 35.6722637155578 139.73974648046996 19.697 35.67223139133377 139.73979159902822 19.697 35.67223139133377 139.73979159902822 20.036 35.6722637155578 139.73974648046996 20.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6a0cfcb-729b-4501-afdf-c18c69445dc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6a0cfcb-729b-4501-afdf-c18c69445dc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6a0cfcb-729b-4501-afdf-c18c69445dc6">
											<gml:posList>35.672247588499275 139.73981415921006 17.077 35.67223168402912 139.7397970777579 20.036 35.67217577929462 139.73973702789172 20.036 35.67217577929462 139.73973702789172 7.94 35.672247588499275 139.73981415921006 7.94 35.672247588499275 139.73981415921006 17.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0692c573-3303-4876-99f2-ec37716b15bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0692c573-3303-4876-99f2-ec37716b15bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0692c573-3303-4876-99f2-ec37716b15bd">
											<gml:posList>35.672247588499275 139.73981415921006 7.94 35.67228405450182 139.7397631922081 7.94 35.67228405450182 139.7397631922081 17.077 35.672247588499275 139.73981415921006 17.077 35.672247588499275 139.73981415921006 7.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4982</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">65.06515</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.14</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>