<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_27367e8c-bf1a-4be5-9047-2c187563b4ec">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="説明注記">
				<gen:value>車庫</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">18.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6728101599902 139.73926735935655 0 35.672770197710726 139.73922708619682 0 35.67273949666329 139.7392728550939 0 35.672779459013974 139.73931323872685 0 35.6728101599902 139.73926735935655 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6728101599902 139.73926735935655 7.8 35.672779459013974 139.73931323872685 7.8 35.67273949666329 139.7392728550939 7.8 35.672770197710726 139.73922708619682 7.8 35.6728101599902 139.73926735935655 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6728101599902 139.73926735935655 7.8 35.672770197710726 139.73922708619682 7.8 35.672770197710726 139.73922708619682 25.98 35.6728101599902 139.73926735935655 25.98 35.6728101599902 139.73926735935655 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672770197710726 139.73922708619682 7.8 35.67273949666329 139.7392728550939 7.8 35.67273949666329 139.7392728550939 25.98 35.672770197710726 139.73922708619682 25.98 35.672770197710726 139.73922708619682 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67273949666329 139.7392728550939 7.8 35.672779459013974 139.73931323872685 7.8 35.672779459013974 139.73931323872685 25.98 35.67273949666329 139.7392728550939 25.98 35.67273949666329 139.7392728550939 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672779459013974 139.73931323872685 7.8 35.6728101599902 139.73926735935655 7.8 35.6728101599902 139.73926735935655 25.98 35.672779459013974 139.73931323872685 25.98 35.672779459013974 139.73931323872685 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6728101599902 139.73926735935655 25.98 35.672770197710726 139.73922708619682 25.98 35.67273949666329 139.7392728550939 25.98 35.672779459013974 139.73931323872685 25.98 35.6728101599902 139.73926735935655 25.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-df585b88-a887-4ffa-b831-a1c2cef2aa60"/>
							<gml:surfaceMember xlink:href="#poly-90c505a6-e39d-4f75-a3cd-4dd96f1e59e6"/>
							<gml:surfaceMember xlink:href="#poly-5547d96c-7866-49f8-8e48-4cfcea95891f"/>
							<gml:surfaceMember xlink:href="#poly-d3573dc5-c383-4be1-8a47-c9391248a613"/>
							<gml:surfaceMember xlink:href="#poly-fcdbca7c-83ed-41d5-91f2-61d65d76756d"/>
							<gml:surfaceMember xlink:href="#poly-c873f98d-02e1-4da4-b8c1-715de8fac04f"/>
							<gml:surfaceMember xlink:href="#poly-51a884f6-cc69-4ef2-bd61-d1286e35632a"/>
							<gml:surfaceMember xlink:href="#poly-3ed4b2a4-d70c-453e-8751-4202fdfb0e85"/>
							<gml:surfaceMember xlink:href="#poly-0db535c8-c58c-40e6-b406-e3778c28c072"/>
							<gml:surfaceMember xlink:href="#poly-6c7dd93f-8abc-431b-b319-374a2ff4526d"/>
							<gml:surfaceMember xlink:href="#poly-15ad9740-593d-4164-ada8-07fb16c88286"/>
							<gml:surfaceMember xlink:href="#poly-4964026b-f85d-4ace-8fc9-052346431dd6"/>
							<gml:surfaceMember xlink:href="#poly-7293afc4-b6a3-4133-ba9d-579c5cb447bf"/>
							<gml:surfaceMember xlink:href="#poly-140e2931-3ff3-4e7f-83c3-57211a1fccca"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-df585b88-a887-4ffa-b831-a1c2cef2aa60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df585b88-a887-4ffa-b831-a1c2cef2aa60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df585b88-a887-4ffa-b831-a1c2cef2aa60">
											<gml:posList>35.672810159990206 139.73926735935655 7.8 35.67277945901397 139.73931323872685 7.8 35.67273949666329 139.7392728550939 7.8 35.672770197710705 139.73922708619682 7.8 35.672810159990206 139.73926735935655 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90c505a6-e39d-4f75-a3cd-4dd96f1e59e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90c505a6-e39d-4f75-a3cd-4dd96f1e59e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90c505a6-e39d-4f75-a3cd-4dd96f1e59e6">
											<gml:posList>35.67273949666329 139.7392728550939 26.656 35.67274787864519 139.73927185106697 26.656 35.67277102599642 139.73923736959867 26.656 35.672770197710705 139.73922708619682 26.656 35.67273949666329 139.7392728550939 26.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5547d96c-7866-49f8-8e48-4cfcea95891f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5547d96c-7866-49f8-8e48-4cfcea95891f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5547d96c-7866-49f8-8e48-4cfcea95891f">
											<gml:posList>35.67277945901397 139.73931323872685 26.656 35.67277863071748 139.73930293322996 26.656 35.67274787864519 139.73927185106697 26.656 35.67273949666329 139.7392728550939 26.656 35.67277945901397 139.73931323872685 26.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3573dc5-c383-4be1-8a47-c9391248a613">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3573dc5-c383-4be1-8a47-c9391248a613">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3573dc5-c383-4be1-8a47-c9391248a613">
											<gml:posList>35.67280177800845 139.7392683633847 25.535 35.67277102599642 139.73923736959867 25.535 35.67274787864519 139.73927185106697 25.535 35.67277863071748 139.73930293322996 25.535 35.67280177800845 139.7392683633847 25.535</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcdbca7c-83ed-41d5-91f2-61d65d76756d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcdbca7c-83ed-41d5-91f2-61d65d76756d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcdbca7c-83ed-41d5-91f2-61d65d76756d">
											<gml:posList>35.672770197710705 139.73922708619682 26.656 35.67277102599642 139.73923736959867 26.656 35.67280177800845 139.7392683633847 26.656 35.672810159990206 139.73926735935655 26.656 35.672770197710705 139.73922708619682 26.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c873f98d-02e1-4da4-b8c1-715de8fac04f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c873f98d-02e1-4da4-b8c1-715de8fac04f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c873f98d-02e1-4da4-b8c1-715de8fac04f">
											<gml:posList>35.672810159990206 139.73926735935655 26.656 35.67280177800845 139.7392683633847 26.656 35.67277863071748 139.73930293322996 26.656 35.67277945901397 139.73931323872685 26.656 35.672810159990206 139.73926735935655 26.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51a884f6-cc69-4ef2-bd61-d1286e35632a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51a884f6-cc69-4ef2-bd61-d1286e35632a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51a884f6-cc69-4ef2-bd61-d1286e35632a">
											<gml:posList>35.672810159990206 139.73926735935655 7.8 35.672770197710705 139.73922708619682 7.8 35.672770197710705 139.73922708619682 26.656 35.672810159990206 139.73926735935655 26.656 35.672810159990206 139.73926735935655 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ed4b2a4-d70c-453e-8751-4202fdfb0e85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ed4b2a4-d70c-453e-8751-4202fdfb0e85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ed4b2a4-d70c-453e-8751-4202fdfb0e85">
											<gml:posList>35.672770197710705 139.73922708619682 7.8 35.67273949666329 139.7392728550939 7.8 35.67273949666329 139.7392728550939 26.656 35.672770197710705 139.73922708619682 26.656 35.672770197710705 139.73922708619682 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0db535c8-c58c-40e6-b406-e3778c28c072">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0db535c8-c58c-40e6-b406-e3778c28c072">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0db535c8-c58c-40e6-b406-e3778c28c072">
											<gml:posList>35.67277102599642 139.73923736959867 26.656 35.67277102599642 139.73923736959867 25.535 35.67280177800845 139.7392683633847 25.535 35.67280177800845 139.7392683633847 26.656 35.67277102599642 139.73923736959867 26.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c7dd93f-8abc-431b-b319-374a2ff4526d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c7dd93f-8abc-431b-b319-374a2ff4526d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c7dd93f-8abc-431b-b319-374a2ff4526d">
											<gml:posList>35.67274787864519 139.73927185106697 26.656 35.67274787864519 139.73927185106697 25.535 35.67277102599642 139.73923736959867 25.535 35.67277102599642 139.73923736959867 26.656 35.67274787864519 139.73927185106697 26.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15ad9740-593d-4164-ada8-07fb16c88286">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15ad9740-593d-4164-ada8-07fb16c88286">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15ad9740-593d-4164-ada8-07fb16c88286">
											<gml:posList>35.67280177800845 139.7392683633847 26.656 35.67280177800845 139.7392683633847 25.535 35.67277863071748 139.73930293322996 25.535 35.67277863071748 139.73930293322996 26.656 35.67280177800845 139.7392683633847 26.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4964026b-f85d-4ace-8fc9-052346431dd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4964026b-f85d-4ace-8fc9-052346431dd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4964026b-f85d-4ace-8fc9-052346431dd6">
											<gml:posList>35.67277863071748 139.73930293322996 26.656 35.67277863071748 139.73930293322996 25.535 35.67274787864519 139.73927185106697 25.535 35.67274787864519 139.73927185106697 26.656 35.67277863071748 139.73930293322996 26.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7293afc4-b6a3-4133-ba9d-579c5cb447bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7293afc4-b6a3-4133-ba9d-579c5cb447bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7293afc4-b6a3-4133-ba9d-579c5cb447bf">
											<gml:posList>35.67277945901397 139.73931323872685 7.8 35.672810159990206 139.73926735935655 7.8 35.672810159990206 139.73926735935655 26.656 35.67277945901397 139.73931323872685 26.656 35.67277945901397 139.73931323872685 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-140e2931-3ff3-4e7f-83c3-57211a1fccca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-140e2931-3ff3-4e7f-83c3-57211a1fccca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-140e2931-3ff3-4e7f-83c3-57211a1fccca">
											<gml:posList>35.67273949666329 139.7392728550939 7.8 35.67277945901397 139.73931323872685 7.8 35.67277945901397 139.73931323872685 26.656 35.67273949666329 139.7392728550939 26.656 35.67273949666329 139.7392728550939 7.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8135</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">30.8259</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.32</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>