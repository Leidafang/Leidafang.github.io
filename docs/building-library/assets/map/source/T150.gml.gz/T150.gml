<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2787cc29-feec-45fb-8e15-c28614f6dc69">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">60.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66862037163236 139.7421629070326 0 35.66858573659066 139.74240759349664 0 35.66860867124587 139.7424125161042 0 35.668640008402825 139.7421931397534 0 35.66918905105303 139.74230984729851 0 35.66919262840532 139.74228454767754 0 35.66862037163236 139.7421629070326 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862037163236 139.7421629070326 10.02 35.66919262840532 139.74228454767754 10.02 35.66918905105303 139.74230984729851 10.02 35.668640008402825 139.7421931397534 10.02 35.66860867124587 139.7424125161042 10.02 35.66858573659066 139.74240759349664 10.02 35.66862037163236 139.7421629070326 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862037163236 139.7421629070326 10.02 35.66858573659066 139.74240759349664 10.02 35.66858573659066 139.74240759349664 70.9 35.66862037163236 139.7421629070326 70.9 35.66862037163236 139.7421629070326 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858573659066 139.74240759349664 10.02 35.66860867124587 139.7424125161042 10.02 35.66860867124587 139.7424125161042 70.9 35.66858573659066 139.74240759349664 70.9 35.66858573659066 139.74240759349664 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860867124587 139.7424125161042 10.02 35.668640008402825 139.7421931397534 10.02 35.668640008402825 139.7421931397534 70.9 35.66860867124587 139.7424125161042 70.9 35.66860867124587 139.7424125161042 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668640008402825 139.7421931397534 10.02 35.66918905105303 139.74230984729851 10.02 35.66918905105303 139.74230984729851 70.9 35.668640008402825 139.7421931397534 70.9 35.668640008402825 139.7421931397534 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66918905105303 139.74230984729851 10.02 35.66919262840532 139.74228454767754 10.02 35.66919262840532 139.74228454767754 70.9 35.66918905105303 139.74230984729851 70.9 35.66918905105303 139.74230984729851 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919262840532 139.74228454767754 10.02 35.66862037163236 139.7421629070326 10.02 35.66862037163236 139.7421629070326 70.9 35.66919262840532 139.74228454767754 70.9 35.66919262840532 139.74228454767754 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66862037163236 139.7421629070326 70.9 35.66858573659066 139.74240759349664 70.9 35.66860867124587 139.7424125161042 70.9 35.668640008402825 139.7421931397534 70.9 35.66918905105303 139.74230984729851 70.9 35.66919262840532 139.74228454767754 70.9 35.66862037163236 139.7421629070326 70.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ed8e7147-63bc-47ad-a0d2-56a4d72e0e78"/>
							<gml:surfaceMember xlink:href="#poly-46b2eaed-244d-4459-9d56-06ea457e2d49"/>
							<gml:surfaceMember xlink:href="#poly-2e4a0de5-f780-4c75-b2c8-982d50afccc1"/>
							<gml:surfaceMember xlink:href="#poly-90c4336b-4242-4e91-b53d-f2306baec736"/>
							<gml:surfaceMember xlink:href="#poly-9c8401b1-95a5-4eb6-8f7a-590f8c0c4d5b"/>
							<gml:surfaceMember xlink:href="#poly-84524ab7-32df-4ff2-9c87-9db1ad5e2587"/>
							<gml:surfaceMember xlink:href="#poly-7942f6b5-af1a-40a9-be7a-3d0930621d1c"/>
							<gml:surfaceMember xlink:href="#poly-f45eecc3-27a4-49a8-95e6-c9325384c953"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ed8e7147-63bc-47ad-a0d2-56a4d72e0e78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed8e7147-63bc-47ad-a0d2-56a4d72e0e78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed8e7147-63bc-47ad-a0d2-56a4d72e0e78">
											<gml:posList>35.66862037163234 139.7421629070326 10.02 35.66919262840529 139.74228454767754 10.02 35.66918905105299 139.7423098472985 10.02 35.668640008402804 139.74219313975337 10.02 35.66860867124584 139.74241251610417 10.02 35.668585736590664 139.74240759349664 10.02 35.66862037163234 139.7421629070326 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46b2eaed-244d-4459-9d56-06ea457e2d49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46b2eaed-244d-4459-9d56-06ea457e2d49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46b2eaed-244d-4459-9d56-06ea457e2d49">
											<gml:posList>35.66862037163234 139.7421629070326 20.8 35.668585736590664 139.74240759349664 20.8 35.66860867124584 139.74241251610417 20.8 35.668640008402804 139.74219313975337 20.8 35.66918905105299 139.7423098472985 20.8 35.66919262840529 139.74228454767754 20.8 35.66862037163234 139.7421629070326 20.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e4a0de5-f780-4c75-b2c8-982d50afccc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e4a0de5-f780-4c75-b2c8-982d50afccc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e4a0de5-f780-4c75-b2c8-982d50afccc1">
											<gml:posList>35.66860867124584 139.74241251610417 10.02 35.668640008402804 139.74219313975337 10.02 35.668640008402804 139.74219313975337 20.8 35.66860867124584 139.74241251610417 20.8 35.66860867124584 139.74241251610417 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90c4336b-4242-4e91-b53d-f2306baec736">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90c4336b-4242-4e91-b53d-f2306baec736">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90c4336b-4242-4e91-b53d-f2306baec736">
											<gml:posList>35.668640008402804 139.74219313975337 10.02 35.66918905105299 139.7423098472985 10.02 35.66918905105299 139.7423098472985 20.8 35.668640008402804 139.74219313975337 20.8 35.668640008402804 139.74219313975337 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c8401b1-95a5-4eb6-8f7a-590f8c0c4d5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c8401b1-95a5-4eb6-8f7a-590f8c0c4d5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c8401b1-95a5-4eb6-8f7a-590f8c0c4d5b">
											<gml:posList>35.66919262840529 139.74228454767754 10.02 35.66862037163234 139.7421629070326 10.02 35.66862037163234 139.7421629070326 20.8 35.66919262840529 139.74228454767754 20.8 35.66919262840529 139.74228454767754 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84524ab7-32df-4ff2-9c87-9db1ad5e2587">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84524ab7-32df-4ff2-9c87-9db1ad5e2587">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84524ab7-32df-4ff2-9c87-9db1ad5e2587">
											<gml:posList>35.66862037163234 139.7421629070326 10.02 35.668585736590664 139.74240759349664 10.02 35.668585736590664 139.74240759349664 20.8 35.66862037163234 139.7421629070326 20.8 35.66862037163234 139.7421629070326 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7942f6b5-af1a-40a9-be7a-3d0930621d1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7942f6b5-af1a-40a9-be7a-3d0930621d1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7942f6b5-af1a-40a9-be7a-3d0930621d1c">
											<gml:posList>35.66918905105299 139.7423098472985 10.02 35.66919262840529 139.74228454767754 10.02 35.66919262840529 139.74228454767754 20.8 35.66918905105299 139.7423098472985 20.8 35.66918905105299 139.7423098472985 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f45eecc3-27a4-49a8-95e6-c9325384c953">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f45eecc3-27a4-49a8-95e6-c9325384c953">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f45eecc3-27a4-49a8-95e6-c9325384c953">
											<gml:posList>35.668585736590664 139.74240759349664 10.02 35.66860867124584 139.74241251610417 10.02 35.66860867124584 139.74241251610417 20.8 35.668585736590664 139.74240759349664 20.8 35.668585736590664 139.74240759349664 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6828</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.33</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>