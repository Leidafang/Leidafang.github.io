<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_27afaf76-bb28-4431-b754-7d322d0481e3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67459755571515 139.73985888613043 0 35.67458042795626 139.73985671882787 0 35.67456330920246 139.73985454046888 0 35.674521860018196 139.7398492863234 0 35.67452071516474 139.73984914404966 0 35.67451941116002 139.7398646000851 0 35.67461139627012 139.73987627981558 0 35.67461270026773 139.7398608127158 0 35.67459755571515 139.73985888613043 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67459755571515 139.73985888613043 28.37 35.67461270026773 139.7398608127158 28.37 35.67461139627012 139.73987627981558 28.37 35.67451941116002 139.7398646000851 28.37 35.67452071516474 139.73984914404966 28.37 35.674521860018196 139.7398492863234 28.37 35.67456330920246 139.73985454046888 28.37 35.67458042795626 139.73985671882787 28.37 35.67459755571515 139.73985888613043 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67459755571515 139.73985888613043 28.37 35.67458042795626 139.73985671882787 28.37 35.67458042795626 139.73985671882787 31.37 35.67459755571515 139.73985888613043 31.37 35.67459755571515 139.73985888613043 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67458042795626 139.73985671882787 28.37 35.67456330920246 139.73985454046888 28.37 35.67456330920246 139.73985454046888 31.37 35.67458042795626 139.73985671882787 31.37 35.67458042795626 139.73985671882787 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67456330920246 139.73985454046888 28.37 35.674521860018196 139.7398492863234 28.37 35.674521860018196 139.7398492863234 31.37 35.67456330920246 139.73985454046888 31.37 35.67456330920246 139.73985454046888 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674521860018196 139.7398492863234 28.37 35.67452071516474 139.73984914404966 28.37 35.67452071516474 139.73984914404966 31.37 35.674521860018196 139.7398492863234 31.37 35.674521860018196 139.7398492863234 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67452071516474 139.73984914404966 28.37 35.67451941116002 139.7398646000851 28.37 35.67451941116002 139.7398646000851 31.37 35.67452071516474 139.73984914404966 31.37 35.67452071516474 139.73984914404966 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67451941116002 139.7398646000851 28.37 35.67461139627012 139.73987627981558 28.37 35.67461139627012 139.73987627981558 31.37 35.67451941116002 139.7398646000851 31.37 35.67451941116002 139.7398646000851 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67461139627012 139.73987627981558 28.37 35.67461270026773 139.7398608127158 28.37 35.67461270026773 139.7398608127158 31.37 35.67461139627012 139.73987627981558 31.37 35.67461139627012 139.73987627981558 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67461270026773 139.7398608127158 28.37 35.67459755571515 139.73985888613043 28.37 35.67459755571515 139.73985888613043 31.37 35.67461270026773 139.7398608127158 31.37 35.67461270026773 139.7398608127158 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67459755571515 139.73985888613043 31.37 35.67458042795626 139.73985671882787 31.37 35.67456330920246 139.73985454046888 31.37 35.674521860018196 139.7398492863234 31.37 35.67452071516474 139.73984914404966 31.37 35.67451941116002 139.7398646000851 31.37 35.67461139627012 139.73987627981558 31.37 35.67461270026773 139.7398608127158 31.37 35.67459755571515 139.73985888613043 31.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5e70e5ed-1f9d-4b64-9730-afe72166c794"/>
							<gml:surfaceMember xlink:href="#poly-6371a946-ba30-475a-b9b4-65c1663051be"/>
							<gml:surfaceMember xlink:href="#poly-1bd13796-ea89-41a7-a329-c64af3943c62"/>
							<gml:surfaceMember xlink:href="#poly-b22a99aa-b440-43d2-bd3d-7911d097d9af"/>
							<gml:surfaceMember xlink:href="#poly-28ed22e5-6a51-4650-bf59-3c2ed92d04ee"/>
							<gml:surfaceMember xlink:href="#poly-2c318c05-7464-41ec-a649-864e863f1f22"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5e70e5ed-1f9d-4b64-9730-afe72166c794">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e70e5ed-1f9d-4b64-9730-afe72166c794">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e70e5ed-1f9d-4b64-9730-afe72166c794">
											<gml:posList>35.67461139627011 139.73987627981558 28.37 35.67451941116001 139.73986460008507 28.37 35.67452059826086 139.73984949768453 28.37 35.674612700267694 139.7398608127158 28.37 35.67461139627011 139.73987627981558 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6371a946-ba30-475a-b9b4-65c1663051be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6371a946-ba30-475a-b9b4-65c1663051be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6371a946-ba30-475a-b9b4-65c1663051be">
											<gml:posList>35.67451941116001 139.73986460008507 29.746 35.67461139627011 139.73987627981558 29.746 35.674612700267694 139.7398608127158 29.746 35.67452059826086 139.73984949768453 29.746 35.67451941116001 139.73986460008507 29.746</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1bd13796-ea89-41a7-a329-c64af3943c62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bd13796-ea89-41a7-a329-c64af3943c62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bd13796-ea89-41a7-a329-c64af3943c62">
											<gml:posList>35.674612700267694 139.7398608127158 28.37 35.67452059826086 139.73984949768453 28.37 35.67452059826086 139.73984949768453 29.746 35.674612700267694 139.7398608127158 29.746 35.674612700267694 139.7398608127158 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b22a99aa-b440-43d2-bd3d-7911d097d9af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b22a99aa-b440-43d2-bd3d-7911d097d9af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b22a99aa-b440-43d2-bd3d-7911d097d9af">
											<gml:posList>35.67452059826086 139.73984949768453 28.37 35.67451941116001 139.73986460008507 28.37 35.67451941116001 139.73986460008507 29.746 35.67452059826086 139.73984949768453 29.746 35.67452059826086 139.73984949768453 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28ed22e5-6a51-4650-bf59-3c2ed92d04ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28ed22e5-6a51-4650-bf59-3c2ed92d04ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28ed22e5-6a51-4650-bf59-3c2ed92d04ee">
											<gml:posList>35.67451941116001 139.73986460008507 28.37 35.67461139627011 139.73987627981558 28.37 35.67461139627011 139.73987627981558 29.746 35.67451941116001 139.73986460008507 29.746 35.67451941116001 139.73986460008507 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c318c05-7464-41ec-a649-864e863f1f22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c318c05-7464-41ec-a649-864e863f1f22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c318c05-7464-41ec-a649-864e863f1f22">
											<gml:posList>35.67461139627011 139.73987627981558 28.37 35.674612700267694 139.7398608127158 28.37 35.674612700267694 139.7398608127158 29.746 35.67461139627011 139.73987627981558 29.746 35.67461139627011 139.73987627981558 28.37</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4598</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>