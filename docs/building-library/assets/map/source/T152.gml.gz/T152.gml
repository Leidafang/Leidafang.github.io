<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_27d6be0e-8928-4f19-bd5b-ebdc9cfcf64d">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">6.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.673025317457444 139.74647783499412 0 35.67303580750737 139.7464751613924 0 35.67300942009565 139.7463194878402 0 35.67299893004914 139.74632216146142 0 35.67289363302406 139.74634896434466 0 35.672857981273474 139.74635803914666 0 35.67286378377522 139.74639224417865 0 35.67294261128126 139.74648308336575 0 35.67296804623715 139.74653061149579 0 35.6730201630565 139.74651734330502 0 35.67301395323592 139.74648073047464 0 35.673025317457444 139.74647783499412 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673025317457444 139.74647783499412 10.95 35.67301395323592 139.74648073047464 10.95 35.6730201630565 139.74651734330502 10.95 35.67296804623715 139.74653061149579 10.95 35.67294261128126 139.74648308336575 10.95 35.67286378377522 139.74639224417865 10.95 35.672857981273474 139.74635803914666 10.95 35.67289363302406 139.74634896434466 10.95 35.67299893004914 139.74632216146142 10.95 35.67300942009565 139.7463194878402 10.95 35.67303580750737 139.7464751613924 10.95 35.673025317457444 139.74647783499412 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673025317457444 139.74647783499412 10.95 35.67303580750737 139.7464751613924 10.95 35.67303580750737 139.7464751613924 17.02 35.673025317457444 139.74647783499412 17.02 35.673025317457444 139.74647783499412 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67303580750737 139.7464751613924 10.95 35.67300942009565 139.7463194878402 10.95 35.67300942009565 139.7463194878402 17.02 35.67303580750737 139.7464751613924 17.02 35.67303580750737 139.7464751613924 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67300942009565 139.7463194878402 10.95 35.67299893004914 139.74632216146142 10.95 35.67299893004914 139.74632216146142 17.02 35.67300942009565 139.7463194878402 17.02 35.67300942009565 139.7463194878402 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67299893004914 139.74632216146142 10.95 35.67289363302406 139.74634896434466 10.95 35.67289363302406 139.74634896434466 17.02 35.67299893004914 139.74632216146142 17.02 35.67299893004914 139.74632216146142 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67289363302406 139.74634896434466 10.95 35.672857981273474 139.74635803914666 10.95 35.672857981273474 139.74635803914666 17.02 35.67289363302406 139.74634896434466 17.02 35.67289363302406 139.74634896434466 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672857981273474 139.74635803914666 10.95 35.67286378377522 139.74639224417865 10.95 35.67286378377522 139.74639224417865 17.02 35.672857981273474 139.74635803914666 17.02 35.672857981273474 139.74635803914666 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67286378377522 139.74639224417865 10.95 35.67294261128126 139.74648308336575 10.95 35.67294261128126 139.74648308336575 17.02 35.67286378377522 139.74639224417865 17.02 35.67286378377522 139.74639224417865 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67294261128126 139.74648308336575 10.95 35.67296804623715 139.74653061149579 10.95 35.67296804623715 139.74653061149579 17.02 35.67294261128126 139.74648308336575 17.02 35.67294261128126 139.74648308336575 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67296804623715 139.74653061149579 10.95 35.6730201630565 139.74651734330502 10.95 35.6730201630565 139.74651734330502 17.02 35.67296804623715 139.74653061149579 17.02 35.67296804623715 139.74653061149579 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6730201630565 139.74651734330502 10.95 35.67301395323592 139.74648073047464 10.95 35.67301395323592 139.74648073047464 17.02 35.6730201630565 139.74651734330502 17.02 35.6730201630565 139.74651734330502 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67301395323592 139.74648073047464 10.95 35.673025317457444 139.74647783499412 10.95 35.673025317457444 139.74647783499412 17.02 35.67301395323592 139.74648073047464 17.02 35.67301395323592 139.74648073047464 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673025317457444 139.74647783499412 17.02 35.67303580750737 139.7464751613924 17.02 35.67300942009565 139.7463194878402 17.02 35.67299893004914 139.74632216146142 17.02 35.67289363302406 139.74634896434466 17.02 35.672857981273474 139.74635803914666 17.02 35.67286378377522 139.74639224417865 17.02 35.67294261128126 139.74648308336575 17.02 35.67296804623715 139.74653061149579 17.02 35.6730201630565 139.74651734330502 17.02 35.67301395323592 139.74648073047464 17.02 35.673025317457444 139.74647783499412 17.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7891c17d-b09d-4e16-8840-c6052c866f63"/>
							<gml:surfaceMember xlink:href="#poly-540845fb-1b2e-4fc0-900a-b79efcab81b8"/>
							<gml:surfaceMember xlink:href="#poly-b859df2a-9840-4ce0-b896-eda1fa30e989"/>
							<gml:surfaceMember xlink:href="#poly-75f063fc-86c6-498f-a3b0-4670b4d4138a"/>
							<gml:surfaceMember xlink:href="#poly-d5f9b8c2-e7c9-485a-89c3-659286f6d230"/>
							<gml:surfaceMember xlink:href="#poly-b0b47396-bc48-444b-b5c0-291e63f6a56c"/>
							<gml:surfaceMember xlink:href="#poly-ae5e7d23-817d-45cf-9a6f-8c3127f5b225"/>
							<gml:surfaceMember xlink:href="#poly-85a8c163-29bb-4f02-90c0-194ee317236a"/>
							<gml:surfaceMember xlink:href="#poly-cc8a85d9-8fdb-4538-bd6a-54b302c1ec8e"/>
							<gml:surfaceMember xlink:href="#poly-ca3a03e2-5cbb-4bfe-bf9f-8452c7d0d1f7"/>
							<gml:surfaceMember xlink:href="#poly-797f0898-2780-463c-bf3f-4dc5e3ee6315"/>
							<gml:surfaceMember xlink:href="#poly-92bb91fa-b819-4f63-9f28-bd0a22a559aa"/>
							<gml:surfaceMember xlink:href="#poly-ea9c4816-ae2a-4e39-9fee-c29213bb5aa8"/>
							<gml:surfaceMember xlink:href="#poly-fd38ab52-cb1e-48c0-998f-2d6079cbb78d"/>
							<gml:surfaceMember xlink:href="#poly-385c7021-8a9b-484d-826f-df27e2617fbb"/>
							<gml:surfaceMember xlink:href="#poly-2c0c4c9a-b540-495b-9a61-d678d58b68ef"/>
							<gml:surfaceMember xlink:href="#poly-3cc00482-049a-40d4-9912-75229278b829"/>
							<gml:surfaceMember xlink:href="#poly-f85d6acd-36c9-4f28-87df-7b764659f55e"/>
							<gml:surfaceMember xlink:href="#poly-c455e55a-b2db-4fa1-9840-07bac8e4fb72"/>
							<gml:surfaceMember xlink:href="#poly-485ca19c-be52-4482-bb5d-e9e1cb7a0644"/>
							<gml:surfaceMember xlink:href="#poly-82f88fb7-4c0a-4f75-b6dc-8fcd76d34642"/>
							<gml:surfaceMember xlink:href="#poly-9555208a-50ba-449d-adbe-72ea5df8c5b2"/>
							<gml:surfaceMember xlink:href="#poly-a2ca7a7f-287a-44c0-852e-322d633bbff5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7891c17d-b09d-4e16-8840-c6052c866f63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7891c17d-b09d-4e16-8840-c6052c866f63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7891c17d-b09d-4e16-8840-c6052c866f63">
											<gml:posList>35.67301395323593 139.74648073047464 10.95 35.673020163056485 139.74651734330502 10.95 35.67296804623716 139.7465306114958 10.95 35.672942620294954 139.746483083356 10.95 35.672863783775206 139.74639224417865 10.95 35.67285798127348 139.74635803914663 10.95 35.673009420095624 139.74631948784017 10.95 35.673035807507375 139.7464751613924 10.95 35.67301395323593 139.74648073047464 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-540845fb-1b2e-4fc0-900a-b79efcab81b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-540845fb-1b2e-4fc0-900a-b79efcab81b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-540845fb-1b2e-4fc0-900a-b79efcab81b8">
											<gml:posList>35.672998930049125 139.7463221614614 13.643 35.673025317457444 139.74647783499412 13.643 35.673035807507375 139.7464751613924 13.643 35.673009420095624 139.74631948784017 13.643 35.672998930049125 139.7463221614614 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b859df2a-9840-4ce0-b896-eda1fa30e989">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b859df2a-9840-4ce0-b896-eda1fa30e989">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b859df2a-9840-4ce0-b896-eda1fa30e989">
											<gml:posList>35.67289363302405 139.74634896434466 16.443 35.672907320092705 139.74642972229347 16.443 35.672951542325634 139.7464184620434 16.443 35.67296423362407 139.7464933774811 16.443 35.673025317457444 139.74647783499412 16.443 35.672998930049125 139.7463221614614 16.443 35.67289363302405 139.74634896434466 16.443</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-75f063fc-86c6-498f-a3b0-4670b4d4138a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75f063fc-86c6-498f-a3b0-4670b4d4138a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75f063fc-86c6-498f-a3b0-4670b4d4138a">
											<gml:posList>35.672909122249635 139.7464413966051 13.643 35.67289363302405 139.74634896434466 13.643 35.67285798127348 139.74635803914663 13.643 35.672863783775206 139.74639224417865 13.643 35.672942620294954 139.746483083356 13.643 35.67296804623716 139.7465306114958 13.643 35.673020163056485 139.74651734330502 13.643 35.67301395323593 139.74648073047464 13.643 35.67296423362407 139.7464933774811 13.643 35.672961671817696 139.74647823534588 13.643 35.67294877550263 139.74648146388225 13.643 35.672940835759846 139.74643336448483 13.643 35.672909122249635 139.7464413966051 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d5f9b8c2-e7c9-485a-89c3-659286f6d230">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5f9b8c2-e7c9-485a-89c3-659286f6d230">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5f9b8c2-e7c9-485a-89c3-659286f6d230">
											<gml:posList>35.672951542325634 139.7464184620434 16.043 35.672907365153335 139.746429711198 16.043 35.672909122249635 139.7464413966051 16.043 35.672940835759846 139.74643336448483 16.043 35.67294877550263 139.74648146388225 16.043 35.672961671817696 139.74647823534588 16.043 35.672951542325634 139.7464184620434 16.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0b47396-bc48-444b-b5c0-291e63f6a56c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0b47396-bc48-444b-b5c0-291e63f6a56c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0b47396-bc48-444b-b5c0-291e63f6a56c">
											<gml:posList>35.673009420095624 139.74631948784017 10.95 35.67285798127348 139.74635803914663 10.95 35.67285798127348 139.74635803914663 13.643 35.67289363302405 139.74634896434466 13.643 35.67289363302405 139.74634896434466 16.443 35.672998930049125 139.7463221614614 16.443 35.672998930049125 139.7463221614614 13.643 35.673009420095624 139.74631948784017 13.643 35.673009420095624 139.74631948784017 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae5e7d23-817d-45cf-9a6f-8c3127f5b225">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae5e7d23-817d-45cf-9a6f-8c3127f5b225">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae5e7d23-817d-45cf-9a6f-8c3127f5b225">
											<gml:posList>35.67285798127348 139.74635803914663 13.643 35.67285798127348 139.74635803914663 10.95 35.672863783775206 139.74639224417865 10.95 35.672863783775206 139.74639224417865 13.643 35.67285798127348 139.74635803914663 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85a8c163-29bb-4f02-90c0-194ee317236a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85a8c163-29bb-4f02-90c0-194ee317236a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85a8c163-29bb-4f02-90c0-194ee317236a">
											<gml:posList>35.67289363302405 139.74634896434466 16.443 35.67289363302405 139.74634896434466 13.643 35.672907365153335 139.746429711198 16.043 35.67289363302405 139.74634896434466 16.443</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc8a85d9-8fdb-4538-bd6a-54b302c1ec8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc8a85d9-8fdb-4538-bd6a-54b302c1ec8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc8a85d9-8fdb-4538-bd6a-54b302c1ec8e">
											<gml:posList>35.672907320092705 139.74642972229347 16.443 35.67289363302405 139.74634896434466 16.443 35.672907365153335 139.746429711198 16.043 35.672907320092705 139.74642972229347 16.443</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca3a03e2-5cbb-4bfe-bf9f-8452c7d0d1f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca3a03e2-5cbb-4bfe-bf9f-8452c7d0d1f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca3a03e2-5cbb-4bfe-bf9f-8452c7d0d1f7">
											<gml:posList>35.67289363302405 139.74634896434466 13.643 35.672909122249635 139.7464413966051 13.643 35.672907365153335 139.746429711198 16.043 35.67289363302405 139.74634896434466 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-797f0898-2780-463c-bf3f-4dc5e3ee6315">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-797f0898-2780-463c-bf3f-4dc5e3ee6315">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-797f0898-2780-463c-bf3f-4dc5e3ee6315">
											<gml:posList>35.673035807507375 139.7464751613924 13.643 35.673035807507375 139.7464751613924 10.95 35.673009420095624 139.74631948784017 10.95 35.673009420095624 139.74631948784017 13.643 35.673035807507375 139.7464751613924 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92bb91fa-b819-4f63-9f28-bd0a22a559aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92bb91fa-b819-4f63-9f28-bd0a22a559aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92bb91fa-b819-4f63-9f28-bd0a22a559aa">
											<gml:posList>35.672998930049125 139.7463221614614 13.643 35.672998930049125 139.7463221614614 16.443 35.673025317457444 139.74647783499412 16.443 35.673025317457444 139.74647783499412 13.643 35.672998930049125 139.7463221614614 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea9c4816-ae2a-4e39-9fee-c29213bb5aa8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea9c4816-ae2a-4e39-9fee-c29213bb5aa8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea9c4816-ae2a-4e39-9fee-c29213bb5aa8">
											<gml:posList>35.672951542325634 139.7464184620434 16.443 35.672907320092705 139.74642972229347 16.443 35.672907365153335 139.746429711198 16.043 35.672951542325634 139.7464184620434 16.043 35.672951542325634 139.7464184620434 16.443</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd38ab52-cb1e-48c0-998f-2d6079cbb78d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd38ab52-cb1e-48c0-998f-2d6079cbb78d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd38ab52-cb1e-48c0-998f-2d6079cbb78d">
											<gml:posList>35.672909122249635 139.7464413966051 13.643 35.672909122249635 139.7464413966051 16.043 35.672907365153335 139.746429711198 16.043 35.672909122249635 139.7464413966051 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-385c7021-8a9b-484d-826f-df27e2617fbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-385c7021-8a9b-484d-826f-df27e2617fbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-385c7021-8a9b-484d-826f-df27e2617fbb">
											<gml:posList>35.672940835759846 139.74643336448483 13.643 35.672940835759846 139.74643336448483 16.043 35.672909122249635 139.7464413966051 16.043 35.672909122249635 139.7464413966051 13.643 35.672940835759846 139.74643336448483 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c0c4c9a-b540-495b-9a61-d678d58b68ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c0c4c9a-b540-495b-9a61-d678d58b68ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c0c4c9a-b540-495b-9a61-d678d58b68ef">
											<gml:posList>35.672863783775206 139.74639224417865 13.643 35.672863783775206 139.74639224417865 10.95 35.672942620294954 139.746483083356 10.95 35.672942620294954 139.746483083356 13.643 35.672863783775206 139.74639224417865 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cc00482-049a-40d4-9912-75229278b829">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cc00482-049a-40d4-9912-75229278b829">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cc00482-049a-40d4-9912-75229278b829">
											<gml:posList>35.67296423362407 139.7464933774811 16.443 35.672951542325634 139.7464184620434 16.443 35.672951542325634 139.7464184620434 16.043 35.672961671817696 139.74647823534588 16.043 35.672961671817696 139.74647823534588 13.643 35.67296423362407 139.7464933774811 13.643 35.67296423362407 139.7464933774811 16.443</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f85d6acd-36c9-4f28-87df-7b764659f55e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f85d6acd-36c9-4f28-87df-7b764659f55e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f85d6acd-36c9-4f28-87df-7b764659f55e">
											<gml:posList>35.67294877550263 139.74648146388225 13.643 35.67294877550263 139.74648146388225 16.043 35.672940835759846 139.74643336448483 16.043 35.672940835759846 139.74643336448483 13.643 35.67294877550263 139.74648146388225 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c455e55a-b2db-4fa1-9840-07bac8e4fb72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c455e55a-b2db-4fa1-9840-07bac8e4fb72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c455e55a-b2db-4fa1-9840-07bac8e4fb72">
											<gml:posList>35.672961671817696 139.74647823534588 13.643 35.672961671817696 139.74647823534588 16.043 35.67294877550263 139.74648146388225 16.043 35.67294877550263 139.74648146388225 13.643 35.672961671817696 139.74647823534588 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-485ca19c-be52-4482-bb5d-e9e1cb7a0644">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-485ca19c-be52-4482-bb5d-e9e1cb7a0644">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-485ca19c-be52-4482-bb5d-e9e1cb7a0644">
											<gml:posList>35.673035807507375 139.7464751613924 10.95 35.673035807507375 139.7464751613924 13.643 35.673025317457444 139.74647783499412 13.643 35.673025317457444 139.74647783499412 16.443 35.67296423362407 139.7464933774811 16.443 35.67296423362407 139.7464933774811 13.643 35.67301395323593 139.74648073047464 13.643 35.67301395323593 139.74648073047464 10.95 35.673035807507375 139.7464751613924 10.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82f88fb7-4c0a-4f75-b6dc-8fcd76d34642">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82f88fb7-4c0a-4f75-b6dc-8fcd76d34642">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82f88fb7-4c0a-4f75-b6dc-8fcd76d34642">
											<gml:posList>35.673020163056485 139.74651734330502 13.643 35.673020163056485 139.74651734330502 10.95 35.67301395323593 139.74648073047464 10.95 35.67301395323593 139.74648073047464 13.643 35.673020163056485 139.74651734330502 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9555208a-50ba-449d-adbe-72ea5df8c5b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9555208a-50ba-449d-adbe-72ea5df8c5b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9555208a-50ba-449d-adbe-72ea5df8c5b2">
											<gml:posList>35.672942620294954 139.746483083356 13.643 35.672942620294954 139.746483083356 10.95 35.67296804623716 139.7465306114958 10.95 35.67296804623716 139.7465306114958 13.643 35.672942620294954 139.746483083356 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2ca7a7f-287a-44c0-852e-322d633bbff5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2ca7a7f-287a-44c0-852e-322d633bbff5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2ca7a7f-287a-44c0-852e-322d633bbff5">
											<gml:posList>35.67296804623716 139.7465306114958 13.643 35.67296804623716 139.7465306114958 10.95 35.673020163056485 139.74651734330502 10.95 35.673020163056485 139.74651734330502 13.643 35.67296804623716 139.7465306114958 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4523</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">224</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.26</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>