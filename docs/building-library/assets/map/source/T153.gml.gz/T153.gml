<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_282d8ea8-b56b-4d00-bfce-f7627e05de62">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">16.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67191981532778 139.738583080912 0 35.67198160501802 139.73856091492763 0 35.67196116433664 139.73847245680926 0 35.671898923193524 139.738493629208 0 35.67191981532778 139.738583080912 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67191981532778 139.738583080912 9.957 35.671898923193524 139.738493629208 9.957 35.67196116433664 139.73847245680926 9.957 35.67198160501802 139.73856091492763 9.957 35.67191981532778 139.738583080912 9.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67191981532778 139.738583080912 9.957 35.67198160501802 139.73856091492763 9.957 35.67198160501802 139.73856091492763 26.03 35.67191981532778 139.738583080912 26.03 35.67191981532778 139.738583080912 9.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67198160501802 139.73856091492763 9.957 35.67196116433664 139.73847245680926 9.957 35.67196116433664 139.73847245680926 26.03 35.67198160501802 139.73856091492763 26.03 35.67198160501802 139.73856091492763 9.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67196116433664 139.73847245680926 9.957 35.671898923193524 139.738493629208 9.957 35.671898923193524 139.738493629208 26.03 35.67196116433664 139.73847245680926 26.03 35.67196116433664 139.73847245680926 9.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671898923193524 139.738493629208 9.957 35.67191981532778 139.738583080912 9.957 35.67191981532778 139.738583080912 26.03 35.671898923193524 139.738493629208 26.03 35.671898923193524 139.738493629208 9.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67191981532778 139.738583080912 26.03 35.67198160501802 139.73856091492763 26.03 35.67196116433664 139.73847245680926 26.03 35.671898923193524 139.738493629208 26.03 35.67191981532778 139.738583080912 26.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a0fe0978-3692-4cba-bec6-a08a00dfd839"/>
							<gml:surfaceMember xlink:href="#poly-d0fb343c-13e2-4aed-84b8-8c269dcc3067"/>
							<gml:surfaceMember xlink:href="#poly-45d05151-e40b-417b-87d3-94f87fb7e8b6"/>
							<gml:surfaceMember xlink:href="#poly-eb6f3964-62a7-4a60-9a78-b9336f135754"/>
							<gml:surfaceMember xlink:href="#poly-cd60434c-c898-452b-b1ca-e2bae79e8ed3"/>
							<gml:surfaceMember xlink:href="#poly-588136d6-49ba-4122-ae37-2cc2fdb90c2a"/>
							<gml:surfaceMember xlink:href="#poly-de00c025-fb3b-4fbc-8251-d406172a4363"/>
							<gml:surfaceMember xlink:href="#poly-89cf60ed-4189-4afa-b2ea-084f93d52c7d"/>
							<gml:surfaceMember xlink:href="#poly-af69039a-25f1-4361-8145-cff030585cae"/>
							<gml:surfaceMember xlink:href="#poly-f5fc8d06-37a3-4a3d-9669-28fbd75e8f36"/>
							<gml:surfaceMember xlink:href="#poly-98227ae7-cb4b-4c29-8ff7-0005a3340306"/>
							<gml:surfaceMember xlink:href="#poly-70e863a9-b125-4cfc-bae3-9b720c8edd2f"/>
							<gml:surfaceMember xlink:href="#poly-08438856-1d22-449f-97ab-816626846162"/>
							<gml:surfaceMember xlink:href="#poly-71b42e05-4e89-47ba-9411-806fdc404e9a"/>
							<gml:surfaceMember xlink:href="#poly-bf6805a4-6624-4a5d-be0b-e6da5b172e3b"/>
							<gml:surfaceMember xlink:href="#poly-063314d8-dfd0-4b93-aab2-755ad8f426d6"/>
							<gml:surfaceMember xlink:href="#poly-316846e3-486c-44fa-b0df-99ba35831e00"/>
							<gml:surfaceMember xlink:href="#poly-39ab392c-2316-4e9a-97d2-6999eb803fe9"/>
							<gml:surfaceMember xlink:href="#poly-758b20f1-6736-47ae-be1c-d44a68edd069"/>
							<gml:surfaceMember xlink:href="#poly-31d8c99d-5b8b-407e-8adc-29eeef9c30f2"/>
							<gml:surfaceMember xlink:href="#poly-52a80b41-ad85-4be1-b76b-a59a810dd9e9"/>
							<gml:surfaceMember xlink:href="#poly-59d03998-7e02-4111-858d-c322d05df17d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_282d8ea8-b56b-4d00-bfce-f7627e05de62_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee0a2068-1f3f-465c-9d64-9045014df36a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67194414227652 139.73850152917836 30.207 35.67194450201624 139.73850050143068 30.207 35.671945033121006 139.738499606038 30.207 35.67194569954467 139.7384988540894 30.207 35.6719464832946 139.73849828979212 30.207 35.6719473483333 139.73849793528166 30.207 35.67194824960957 139.73849781270434 30.207 35.67194915106856 139.73849792210274 30.207 35.671950016655366 139.7384982635196 30.207 35.6719508012753 139.73849880386882 30.207 35.67195147788719 139.73849954318234 30.207 35.67195201941507 139.7385004373063 30.207 35.671952389777985 139.738501453144 30.207 35.67195258893239 139.73850253546306 30.207 35.67195259882479 139.73850365114544 30.207 35.67195241038923 139.73850473392295 30.207 35.67195205064079 139.73850575062423 30.207 35.67195151954468 139.73850665706343 30.207 35.67195085312096 139.73850740901202 30.207 35.671950069371 139.73850797330925 30.207 35.67194921333729 139.73850831676248 30.207 35.671948312069695 139.73850845038615 30.207 35.67194741061072 139.7385083409876 30.207 35.67194654502394 139.73850799957066 30.207 35.671945751390325 139.73850745923207 30.207 35.671945074778485 139.73850671991852 30.207 35.67194454226436 139.7385058257839 30.207 35.67194416288778 139.73850480995694 30.207 35.671943972747094 139.73850372762735 30.207 35.67194396285472 139.7385026119451 30.207 35.67194414227652 139.73850152917836 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa12d52c-5254-47f8-a515-53e9cadda25b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa12d52c-5254-47f8-a515-53e9cadda25b_0">
											<gml:posList>35.67194396285472 139.7385026119451 30.207 35.671943972747094 139.73850372762735 30.207 35.671943972747094 139.73850372762735 31.872 35.67194396285472 139.7385026119451 31.872 35.67194396285472 139.7385026119451 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37e4c02c-c70b-4dae-8ef5-25caad70e15e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37e4c02c-c70b-4dae-8ef5-25caad70e15e_0">
											<gml:posList>35.67194396285472 139.7385026119451 30.207 35.67194396285472 139.7385026119451 31.872 35.67194414227652 139.73850152917836 31.872 35.67194414227652 139.73850152917836 30.207 35.67194396285472 139.7385026119451 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-252660b4-0ced-4006-b24e-65676b7151b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-252660b4-0ced-4006-b24e-65676b7151b5_0">
											<gml:posList>35.671943972747094 139.73850372762735 30.207 35.67194416288778 139.73850480995694 30.207 35.67194416288778 139.73850480995694 31.872 35.671943972747094 139.73850372762735 31.872 35.671943972747094 139.73850372762735 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0f05165-3577-4791-937c-3d9a6dcf7611">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0f05165-3577-4791-937c-3d9a6dcf7611_0">
											<gml:posList>35.67194450201624 139.73850050143068 30.207 35.67194414227652 139.73850152917836 30.207 35.67194414227652 139.73850152917836 31.872 35.67194450201624 139.73850050143068 31.872 35.67194450201624 139.73850050143068 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b83aaaf-2aad-49e0-a1b7-32189bc75ef7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b83aaaf-2aad-49e0-a1b7-32189bc75ef7_0">
											<gml:posList>35.67194416288778 139.73850480995694 30.207 35.67194454226436 139.7385058257839 30.207 35.67194454226436 139.7385058257839 31.872 35.67194416288778 139.73850480995694 31.872 35.67194416288778 139.73850480995694 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ec3fcdc-3338-4b3b-a293-ed89c5a8a994">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ec3fcdc-3338-4b3b-a293-ed89c5a8a994_0">
											<gml:posList>35.671945033121006 139.738499606038 30.207 35.67194450201624 139.73850050143068 30.207 35.67194450201624 139.73850050143068 31.872 35.671945033121006 139.738499606038 31.872 35.671945033121006 139.738499606038 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78613ae2-a8a6-460a-ac08-3fd5613881a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78613ae2-a8a6-460a-ac08-3fd5613881a6_0">
											<gml:posList>35.67194454226436 139.7385058257839 30.207 35.671945074778485 139.73850671991852 30.207 35.671945074778485 139.73850671991852 31.872 35.67194454226436 139.7385058257839 31.872 35.67194454226436 139.7385058257839 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25c1021e-b7fd-402b-a25e-715444891893">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25c1021e-b7fd-402b-a25e-715444891893_0">
											<gml:posList>35.671945033121006 139.738499606038 30.207 35.671945033121006 139.738499606038 31.872 35.67194569954467 139.7384988540894 31.872 35.67194569954467 139.7384988540894 30.207 35.671945033121006 139.738499606038 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4894adf-c1bb-410b-a7ed-0306daadcff2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4894adf-c1bb-410b-a7ed-0306daadcff2_0">
											<gml:posList>35.671945074778485 139.73850671991852 30.207 35.671945751390325 139.73850745923207 30.207 35.671945751390325 139.73850745923207 31.872 35.671945074778485 139.73850671991852 31.872 35.671945074778485 139.73850671991852 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11e347c6-1664-43ff-a7cc-d0547bcf3152">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11e347c6-1664-43ff-a7cc-d0547bcf3152_0">
											<gml:posList>35.6719464832946 139.73849828979212 30.207 35.67194569954467 139.7384988540894 30.207 35.67194569954467 139.7384988540894 31.872 35.6719464832946 139.73849828979212 31.872 35.6719464832946 139.73849828979212 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5af2ecf8-a7c4-4dba-a5eb-b57d5ab89e5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5af2ecf8-a7c4-4dba-a5eb-b57d5ab89e5a_0">
											<gml:posList>35.671945751390325 139.73850745923207 30.207 35.67194654502394 139.73850799957066 30.207 35.67194654502394 139.73850799957066 31.872 35.671945751390325 139.73850745923207 31.872 35.671945751390325 139.73850745923207 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21e17016-eb26-4761-81d3-6e5dc1b84b7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21e17016-eb26-4761-81d3-6e5dc1b84b7a_0">
											<gml:posList>35.6719473483333 139.73849793528166 30.207 35.6719464832946 139.73849828979212 30.207 35.6719464832946 139.73849828979212 31.872 35.6719473483333 139.73849793528166 31.872 35.6719473483333 139.73849793528166 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12b4a4ef-6a1a-4aaf-bc56-06e5ac45a599">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12b4a4ef-6a1a-4aaf-bc56-06e5ac45a599_0">
											<gml:posList>35.67194654502394 139.73850799957066 30.207 35.67194741061072 139.7385083409876 30.207 35.67194741061072 139.7385083409876 31.872 35.67194654502394 139.73850799957066 31.872 35.67194654502394 139.73850799957066 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c69fe734-1790-4807-94c4-a5857cfff9d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c69fe734-1790-4807-94c4-a5857cfff9d5_0">
											<gml:posList>35.67194824960957 139.73849781270434 30.207 35.6719473483333 139.73849793528166 30.207 35.6719473483333 139.73849793528166 31.872 35.67194824960957 139.73849781270434 31.872 35.67194824960957 139.73849781270434 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02a7fa06-3436-4e3f-b009-7728c52b40dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02a7fa06-3436-4e3f-b009-7728c52b40dd_0">
											<gml:posList>35.67194741061072 139.7385083409876 30.207 35.671948312069695 139.73850845038615 30.207 35.671948312069695 139.73850845038615 31.872 35.67194741061072 139.7385083409876 31.872 35.67194741061072 139.7385083409876 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-383fdae1-28f1-4504-a585-88b3a1c9956d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-383fdae1-28f1-4504-a585-88b3a1c9956d_0">
											<gml:posList>35.671943972747094 139.73850372762735 31.872 35.67194416288778 139.73850480995694 31.872 35.67194454226436 139.7385058257839 31.872 35.671945074778485 139.73850671991852 31.872 35.671945751390325 139.73850745923207 31.872 35.67194654502394 139.73850799957066 31.872 35.67194741061072 139.7385083409876 31.872 35.671948312069695 139.73850845038615 31.872 35.67194921333729 139.73850831676248 31.872 35.671950069371 139.73850797330925 31.872 35.67195085312096 139.73850740901202 31.872 35.67195151954468 139.73850665706343 31.872 35.67195205064079 139.73850575062423 31.872 35.67195241038923 139.73850473392295 31.872 35.67195259882479 139.73850365114544 31.872 35.67195258893239 139.73850253546306 31.872 35.671952389777985 139.738501453144 31.872 35.67195201941507 139.7385004373063 31.872 35.67195147788719 139.73849954318234 31.872 35.6719508012753 139.73849880386882 31.872 35.671950016655366 139.7384982635196 31.872 35.67194915106856 139.73849792210274 31.872 35.67194824960957 139.73849781270434 31.872 35.6719473483333 139.73849793528166 31.872 35.6719464832946 139.73849828979212 31.872 35.67194569954467 139.7384988540894 31.872 35.671945033121006 139.738499606038 31.872 35.67194450201624 139.73850050143068 31.872 35.67194414227652 139.73850152917836 31.872 35.67194396285472 139.7385026119451 31.872 35.671943972747094 139.73850372762735 31.872</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0652f92-4217-4946-9b7f-ce3814f26cdb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0652f92-4217-4946-9b7f-ce3814f26cdb_0">
											<gml:posList>35.67194915106856 139.73849792210274 30.207 35.67194824960957 139.73849781270434 30.207 35.67194824960957 139.73849781270434 31.872 35.67194915106856 139.73849792210274 31.872 35.67194915106856 139.73849792210274 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6eea055f-efec-4b9e-99cf-2ea210851044">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6eea055f-efec-4b9e-99cf-2ea210851044_0">
											<gml:posList>35.671948312069695 139.73850845038615 30.207 35.67194921333729 139.73850831676248 30.207 35.67194921333729 139.73850831676248 31.872 35.671948312069695 139.73850845038615 31.872 35.671948312069695 139.73850845038615 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ad6d843-9adc-4490-94c7-b4c24dfef113">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ad6d843-9adc-4490-94c7-b4c24dfef113_0">
											<gml:posList>35.67194915106856 139.73849792210274 30.207 35.67194915106856 139.73849792210274 31.872 35.671950016655366 139.7384982635196 31.872 35.671950016655366 139.7384982635196 30.207 35.67194915106856 139.73849792210274 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c047463-d3ae-43a0-ac89-5286d2061d75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c047463-d3ae-43a0-ac89-5286d2061d75_0">
											<gml:posList>35.67194921333729 139.73850831676248 30.207 35.671950069371 139.73850797330925 30.207 35.671950069371 139.73850797330925 31.872 35.67194921333729 139.73850831676248 31.872 35.67194921333729 139.73850831676248 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8511ba8-4e66-4b77-9a93-5d30b1710afd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8511ba8-4e66-4b77-9a93-5d30b1710afd_0">
											<gml:posList>35.6719508012753 139.73849880386882 30.207 35.671950016655366 139.7384982635196 30.207 35.671950016655366 139.7384982635196 31.872 35.6719508012753 139.73849880386882 31.872 35.6719508012753 139.73849880386882 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9071c9a-73fa-4e1d-9310-8e262fa0c30c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9071c9a-73fa-4e1d-9310-8e262fa0c30c_0">
											<gml:posList>35.671950069371 139.73850797330925 30.207 35.67195085312096 139.73850740901202 30.207 35.67195085312096 139.73850740901202 31.872 35.671950069371 139.73850797330925 31.872 35.671950069371 139.73850797330925 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31ad1ff8-2bc9-45fa-a5b7-4f28d7f1693a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31ad1ff8-2bc9-45fa-a5b7-4f28d7f1693a_0">
											<gml:posList>35.67195147788719 139.73849954318234 30.207 35.6719508012753 139.73849880386882 30.207 35.6719508012753 139.73849880386882 31.872 35.67195147788719 139.73849954318234 31.872 35.67195147788719 139.73849954318234 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67a8e2de-6a8b-4967-ae3b-fa5cf775a024">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67a8e2de-6a8b-4967-ae3b-fa5cf775a024_0">
											<gml:posList>35.67195085312096 139.73850740901202 30.207 35.67195151954468 139.73850665706343 30.207 35.67195151954468 139.73850665706343 31.872 35.67195085312096 139.73850740901202 31.872 35.67195085312096 139.73850740901202 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58b15969-e159-42e4-8229-f7ab155b4ff4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58b15969-e159-42e4-8229-f7ab155b4ff4_0">
											<gml:posList>35.67195201941507 139.7385004373063 30.207 35.67195147788719 139.73849954318234 30.207 35.67195147788719 139.73849954318234 31.872 35.67195201941507 139.7385004373063 31.872 35.67195201941507 139.7385004373063 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7710b8b-9b3f-4df6-ba3a-d0c58e484485">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7710b8b-9b3f-4df6-ba3a-d0c58e484485_0">
											<gml:posList>35.67195205064079 139.73850575062423 30.207 35.67195205064079 139.73850575062423 31.872 35.67195151954468 139.73850665706343 31.872 35.67195151954468 139.73850665706343 30.207 35.67195205064079 139.73850575062423 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-827469a8-03f1-45a1-a821-2bd2bdd96cbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-827469a8-03f1-45a1-a821-2bd2bdd96cbb_0">
											<gml:posList>35.671952389777985 139.738501453144 30.207 35.67195201941507 139.7385004373063 30.207 35.67195201941507 139.7385004373063 31.872 35.671952389777985 139.738501453144 31.872 35.671952389777985 139.738501453144 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f64e333-7d5e-40b2-a9c1-d87c6f0592cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f64e333-7d5e-40b2-a9c1-d87c6f0592cc_0">
											<gml:posList>35.67195205064079 139.73850575062423 30.207 35.67195241038923 139.73850473392295 30.207 35.67195241038923 139.73850473392295 31.872 35.67195205064079 139.73850575062423 31.872 35.67195205064079 139.73850575062423 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc692592-97a4-4a8a-8335-770853037cbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc692592-97a4-4a8a-8335-770853037cbc_0">
											<gml:posList>35.67195258893239 139.73850253546306 30.207 35.671952389777985 139.738501453144 30.207 35.671952389777985 139.738501453144 31.872 35.67195258893239 139.73850253546306 31.872 35.67195258893239 139.73850253546306 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bd321b2-4764-464a-a723-3648b3ced85c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bd321b2-4764-464a-a723-3648b3ced85c_0">
											<gml:posList>35.67195241038923 139.73850473392295 30.207 35.67195259882479 139.73850365114544 30.207 35.67195259882479 139.73850365114544 31.872 35.67195241038923 139.73850473392295 31.872 35.67195241038923 139.73850473392295 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1423a45-524d-44e3-a29e-56a7403742b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1423a45-524d-44e3-a29e-56a7403742b3_0">
											<gml:posList>35.67195259882479 139.73850365114544 30.207 35.67195258893239 139.73850253546306 30.207 35.67195258893239 139.73850253546306 31.872 35.67195259882479 139.73850365114544 31.872 35.67195259882479 139.73850365114544 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_282d8ea8-b56b-4d00-bfce-f7627e05de62_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b81da86-4587-491d-8fe5-a7ca9c3552a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b81da86-4587-491d-8fe5-a7ca9c3552a9_0">
											<gml:posList>35.671956310945426 139.73847881427574 25.594 35.671956310945426 139.73847881427574 25.902 35.67195797422097 139.73848484368412 25.594 35.671956310945426 139.73847881427574 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19c40b7f-56c4-4e27-af8f-c46b398dfdad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19c40b7f-56c4-4e27-af8f-c46b398dfdad_0">
											<gml:posList>35.67195797422097 139.73848484368412 25.594 35.671956310945426 139.73847881427574 25.902 35.67195797422097 139.73848484368412 27.458 35.67195797422097 139.73848484368412 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cacdf36-f997-4a19-9933-4553012abf85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cacdf36-f997-4a19-9933-4553012abf85_0">
											<gml:posList>35.67195797422097 139.73848484368412 27.458 35.671956310945426 139.73847881427574 25.902 35.6719552623517 139.73847500448204 27.458 35.67195797422097 139.73848484368412 27.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42fc890a-4830-4816-bc25-72d48597d891">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42fc890a-4830-4816-bc25-72d48597d891_0">
											<gml:posList>35.671956310945426 139.73847881427574 25.902 35.6719552623517 139.73847500448204 25.902 35.6719552623517 139.73847500448204 27.458 35.671956310945426 139.73847881427574 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abb14ef1-11c8-405d-bc3a-2ed567e2f2dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abb14ef1-11c8-405d-bc3a-2ed567e2f2dd_0">
											<gml:posList>35.671918478136696 139.73848747528416 25.902 35.6719552623517 139.73847500448204 27.458 35.6719552623517 139.73847500448204 25.902 35.671918478136696 139.73848747528416 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c74bd309-b143-4d12-a4ca-eb30b30592dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c74bd309-b143-4d12-a4ca-eb30b30592dc_0">
											<gml:posList>35.671918478136696 139.73848747528416 25.902 35.671918478136696 139.73848747528416 27.458 35.6719552623517 139.73847500448204 27.458 35.671918478136696 139.73848747528416 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8597b016-4858-445e-865b-e4709aff16da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8597b016-4858-445e-865b-e4709aff16da_0">
											<gml:posList>35.671956310945426 139.73847881427574 25.594 35.67191946368619 139.7384913514297 25.902 35.671956310945426 139.73847881427574 25.902 35.671956310945426 139.73847881427574 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c8d41bd-79a7-4a2a-a05e-035e983f5de5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c8d41bd-79a7-4a2a-a05e-035e983f5de5_0">
											<gml:posList>35.671956310945426 139.73847881427574 25.594 35.67191946368619 139.7384913514297 25.594 35.67191946368619 139.7384913514297 25.902 35.671956310945426 139.73847881427574 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e0425f6-4232-4071-afb3-9a1b59e5f93b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e0425f6-4232-4071-afb3-9a1b59e5f93b_0">
											<gml:posList>35.671927931954215 139.73849690883412 25.594 35.67195797422097 139.73848484368412 27.458 35.671927931954215 139.73849690883412 27.458 35.671927931954215 139.73849690883412 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e29d045f-d031-49be-9618-29c0898eadcf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e29d045f-d031-49be-9618-29c0898eadcf_0">
											<gml:posList>35.671927931954215 139.73849690883412 25.594 35.67195797422097 139.73848484368412 25.594 35.67195797422097 139.73848484368412 27.458 35.671927931954215 139.73849690883412 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b34a81dc-ac6b-4865-be51-cb92545dea06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b34a81dc-ac6b-4865-be51-cb92545dea06_0">
											<gml:posList>35.67191946368619 139.7384913514297 25.594 35.67192081092411 139.73849667423522 25.594 35.67191946368619 139.7384913514297 25.902 35.67191946368619 139.7384913514297 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1564470-2c42-4871-a001-d7c84cfac09a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1564470-2c42-4871-a001-d7c84cfac09a_0">
											<gml:posList>35.671918478136696 139.73848747528416 25.902 35.67191946368619 139.7384913514297 25.902 35.671918478136696 139.73848747528416 27.458 35.671918478136696 139.73848747528416 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc61a68e-f8ca-400a-ba98-50dece5f1517">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc61a68e-f8ca-400a-ba98-50dece5f1517_0">
											<gml:posList>35.671918478136696 139.73848747528416 27.458 35.67191946368619 139.7384913514297 25.902 35.67192081092411 139.73849667423522 27.458 35.671918478136696 139.73848747528416 27.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5027a2fc-64e1-4f66-83b7-4f5206d55de0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5027a2fc-64e1-4f66-83b7-4f5206d55de0_0">
											<gml:posList>35.67191946368619 139.7384913514297 25.902 35.67192081092411 139.73849667423522 25.594 35.67192081092411 139.73849667423522 27.458 35.67191946368619 139.7384913514297 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-761213f2-2d45-4385-9bc7-8caa134e3fc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-761213f2-2d45-4385-9bc7-8caa134e3fc9_0">
											<gml:posList>35.67192153423153 139.7384994791834 25.594 35.67192081092411 139.73849667423522 27.458 35.67192081092411 139.73849667423522 25.594 35.67192153423153 139.7384994791834 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e056b8db-9dd3-4f19-b838-216aa3627216">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e056b8db-9dd3-4f19-b838-216aa3627216_0">
											<gml:posList>35.67192153423153 139.7384994791834 25.594 35.67192153423153 139.7384994791834 27.458 35.67192081092411 139.73849667423522 27.458 35.67192153423153 139.7384994791834 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26f98909-b60c-444f-8342-dbc15578680e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26f98909-b60c-444f-8342-dbc15578680e_0">
											<gml:posList>35.67192153423153 139.7384994791834 25.594 35.671927931954215 139.73849690883412 27.458 35.67192153423153 139.7384994791834 27.458 35.67192153423153 139.7384994791834 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee6f3035-a67f-4301-9a6f-0fdd0441c2d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee6f3035-a67f-4301-9a6f-0fdd0441c2d2_0">
											<gml:posList>35.67192153423153 139.7384994791834 25.594 35.671927931954215 139.73849690883412 25.594 35.671927931954215 139.73849690883412 27.458 35.67192153423153 139.7384994791834 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b76ca348-d53d-4d44-bdc1-111f67577eac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b76ca348-d53d-4d44-bdc1-111f67577eac_0">
											<gml:posList>35.67192153423153 139.7384994791834 27.458 35.671927931954215 139.73849690883412 27.458 35.67192081092411 139.73849667423522 27.458 35.67192153423153 139.7384994791834 27.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad79028f-b561-4088-9570-e45e7d2422c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad79028f-b561-4088-9570-e45e7d2422c8_0">
											<gml:posList>35.67192081092411 139.73849667423522 27.458 35.671927931954215 139.73849690883412 27.458 35.671918478136696 139.73848747528416 27.458 35.67192081092411 139.73849667423522 27.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d1b66c8-db2d-427c-be2c-33d1f42a0b1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d1b66c8-db2d-427c-be2c-33d1f42a0b1a_0">
											<gml:posList>35.671918478136696 139.73848747528416 27.458 35.671927931954215 139.73849690883412 27.458 35.6719552623517 139.73847500448204 27.458 35.671918478136696 139.73848747528416 27.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-071252f6-0d26-4bba-86d5-6e064995785a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-071252f6-0d26-4bba-86d5-6e064995785a_0">
											<gml:posList>35.671927931954215 139.73849690883412 27.458 35.67195797422097 139.73848484368412 27.458 35.6719552623517 139.73847500448204 27.458 35.671927931954215 139.73849690883412 27.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae944381-57ad-458a-9c78-9a4a952c1545">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6719552623517 139.73847500448204 25.902 35.67191946368619 139.7384913514297 25.902 35.671918478136696 139.73848747528416 25.902 35.6719552623517 139.73847500448204 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec99f00b-5a9b-4637-a83d-7ce7566f2b45">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6719552623517 139.73847500448204 25.902 35.671956310945426 139.73847881427574 25.902 35.67191946368619 139.7384913514297 25.902 35.6719552623517 139.73847500448204 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91a18a17-335b-4b04-9862-d21c73117531">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671956310945426 139.73847881427574 25.594 35.67195797422097 139.73848484368412 25.594 35.671927931954215 139.73849690883412 25.594 35.671956310945426 139.73847881427574 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c4ad54a-b16d-4876-8739-b21a00a50207">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671956310945426 139.73847881427574 25.594 35.671927931954215 139.73849690883412 25.594 35.67191946368619 139.7384913514297 25.594 35.671956310945426 139.73847881427574 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-146e115a-0ee2-4644-8bea-f1cee1737943">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67191946368619 139.7384913514297 25.594 35.671927931954215 139.73849690883412 25.594 35.67192081092411 139.73849667423522 25.594 35.67191946368619 139.7384913514297 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-459d348a-a007-4dee-9fac-134d63eb17c6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671927931954215 139.73849690883412 25.594 35.67192153423153 139.7384994791834 25.594 35.67192081092411 139.73849667423522 25.594 35.671927931954215 139.73849690883412 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_282d8ea8-b56b-4d00-bfce-f7627e05de62_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b34b97b-5e43-48fa-94a5-82a312625823">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b34b97b-5e43-48fa-94a5-82a312625823_0">
											<gml:posList>35.671916900205105 139.7384982474601 25.594 35.67192081092411 139.73849667423522 25.902 35.67192081092411 139.73849667423522 25.594 35.671916900205105 139.7384982474601 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a4437f6-9875-49ff-8b0b-9565552ae547">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a4437f6-9875-49ff-8b0b-9565552ae547_0">
											<gml:posList>35.671916900205105 139.7384982474601 25.594 35.671916900205105 139.7384982474601 25.902 35.67192081092411 139.73849667423522 25.902 35.671916900205105 139.7384982474601 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2763f7d7-e417-4901-8e3b-f347f89db2e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2763f7d7-e417-4901-8e3b-f347f89db2e5_0">
											<gml:posList>35.671925217322965 139.7385293444874 25.902 35.671916900205105 139.7384982474601 25.594 35.671925217322965 139.7385293444874 25.594 35.671925217322965 139.7385293444874 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5c58c35-8a81-4b79-ab76-00fbeb09d3bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5c58c35-8a81-4b79-ab76-00fbeb09d3bc_0">
											<gml:posList>35.671925217322965 139.7385293444874 25.902 35.671916900205105 139.7384982474601 25.902 35.671916900205105 139.7384982474601 25.594 35.671925217322965 139.7385293444874 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e97fa6fa-67f1-4cc9-b350-e9899099319d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e97fa6fa-67f1-4cc9-b350-e9899099319d_0">
											<gml:posList>35.67192081092411 139.73849667423522 25.594 35.67192153423153 139.7384994791834 25.902 35.67192153423153 139.7384994791834 25.594 35.67192081092411 139.73849667423522 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af395737-1915-48d0-93ac-f468725fb0dd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af395737-1915-48d0-93ac-f468725fb0dd_0">
											<gml:posList>35.67192081092411 139.73849667423522 25.594 35.67192081092411 139.73849667423522 25.902 35.67192153423153 139.7384994791834 25.902 35.67192081092411 139.73849667423522 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7f64223-0d36-4225-a4ec-3f356cb63e9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7f64223-0d36-4225-a4ec-3f356cb63e9d_0">
											<gml:posList>35.67192153423153 139.7384994791834 25.594 35.671927931954215 139.73849690883412 25.902 35.671927931954215 139.73849690883412 25.594 35.67192153423153 139.7384994791834 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aba15955-e61f-4d39-bc46-31a45dfc73d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aba15955-e61f-4d39-bc46-31a45dfc73d6_0">
											<gml:posList>35.67192153423153 139.7384994791834 25.594 35.67192153423153 139.7384994791834 25.902 35.671927931954215 139.73849690883412 25.902 35.67192153423153 139.7384994791834 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75ffa508-c91c-4d46-9616-d1e325d33385">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75ffa508-c91c-4d46-9616-d1e325d33385_0">
											<gml:posList>35.671935498733184 139.73852521199507 25.594 35.671925217322965 139.7385293444874 25.902 35.671925217322965 139.7385293444874 25.594 35.671935498733184 139.73852521199507 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e29a6303-0451-4947-a4ab-e2e07bd6685e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e29a6303-0451-4947-a4ab-e2e07bd6685e_0">
											<gml:posList>35.671935498733184 139.73852521199507 25.594 35.671935498733184 139.73852521199507 25.902 35.671925217322965 139.7385293444874 25.902 35.671935498733184 139.73852521199507 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18535716-066c-413b-a4a7-cba627391ec3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18535716-066c-413b-a4a7-cba627391ec3_0">
											<gml:posList>35.67193445908505 139.7385213138194 25.594 35.671927931954215 139.73849690883412 25.902 35.67193445908505 139.7385213138194 25.902 35.67193445908505 139.7385213138194 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88532f08-e861-4497-afe4-a9a7f76bc681">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88532f08-e861-4497-afe4-a9a7f76bc681_0">
											<gml:posList>35.67193445908505 139.7385213138194 25.594 35.671927931954215 139.73849690883412 25.594 35.671927931954215 139.73849690883412 25.902 35.67193445908505 139.7385213138194 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81ca9f80-76bc-4431-b7eb-4e3c370e55ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81ca9f80-76bc-4431-b7eb-4e3c370e55ea_0">
											<gml:posList>35.67193445908505 139.7385213138194 25.902 35.671935498733184 139.73852521199507 25.594 35.67193445908505 139.7385213138194 25.594 35.67193445908505 139.7385213138194 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5c80c09-032e-4ae2-bafe-19e8a341e4e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5c80c09-032e-4ae2-bafe-19e8a341e4e1_0">
											<gml:posList>35.67193445908505 139.7385213138194 25.902 35.671935498733184 139.73852521199507 25.902 35.671935498733184 139.73852521199507 25.594 35.67193445908505 139.7385213138194 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf386496-decf-4dbb-88aa-e5ea06840b2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf386496-decf-4dbb-88aa-e5ea06840b2a_0">
											<gml:posList>35.67192081092411 139.73849667423522 25.902 35.671916900205105 139.7384982474601 25.902 35.67192153423153 139.7384994791834 25.902 35.67192081092411 139.73849667423522 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-519224b1-f1e9-47cb-b172-873e23b8aa4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-519224b1-f1e9-47cb-b172-873e23b8aa4d_0">
											<gml:posList>35.671927931954215 139.73849690883412 25.902 35.67192153423153 139.7384994791834 25.902 35.67193445908505 139.7385213138194 25.902 35.671927931954215 139.73849690883412 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2e2cbc97-3e48-4fc3-baff-b72c53cd6ee3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2e2cbc97-3e48-4fc3-baff-b72c53cd6ee3_0">
											<gml:posList>35.67193445908505 139.7385213138194 25.902 35.671925217322965 139.7385293444874 25.902 35.671935498733184 139.73852521199507 25.902 35.67193445908505 139.7385213138194 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45ac82a8-ddee-4498-944b-e40d6024b344">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45ac82a8-ddee-4498-944b-e40d6024b344_0">
											<gml:posList>35.67192153423153 139.7384994791834 25.902 35.671916900205105 139.7384982474601 25.902 35.671925217322965 139.7385293444874 25.902 35.67192153423153 139.7384994791834 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8db1e05-79f8-4711-9152-e654a669d22d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8db1e05-79f8-4711-9152-e654a669d22d_0">
											<gml:posList>35.67193445908505 139.7385213138194 25.902 35.67192153423153 139.7384994791834 25.902 35.671925217322965 139.7385293444874 25.902 35.67193445908505 139.7385213138194 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3225228-3209-4c34-a131-5e5aa7c2b64e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67192081092411 139.73849667423522 25.594 35.67192153423153 139.7384994791834 25.594 35.671916900205105 139.7384982474601 25.594 35.67192081092411 139.73849667423522 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3335100-bf98-4854-9f00-c7ff7e6b9c99">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671916900205105 139.7384982474601 25.594 35.67192153423153 139.7384994791834 25.594 35.671925217322965 139.7385293444874 25.594 35.671916900205105 139.7384982474601 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dfb0e89-6093-4e61-884d-1c2f536a9e78">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671935498733184 139.73852521199507 25.594 35.671925217322965 139.7385293444874 25.594 35.67193445908505 139.7385213138194 25.594 35.671935498733184 139.73852521199507 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bf33e4b-0c21-432f-9c83-1221ea529e3d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67192153423153 139.7384994791834 25.594 35.671927931954215 139.73849690883412 25.594 35.67193445908505 139.7385213138194 25.594 35.67192153423153 139.7384994791834 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e379e4c-6e80-4bbe-a30f-3640343759cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671925217322965 139.7385293444874 25.594 35.67192153423153 139.7384994791834 25.594 35.67193445908505 139.7385213138194 25.594 35.671925217322965 139.7385293444874 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a0fe0978-3692-4cba-bec6-a08a00dfd839">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0fe0978-3692-4cba-bec6-a08a00dfd839">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0fe0978-3692-4cba-bec6-a08a00dfd839">
											<gml:posList>35.67191981532775 139.73858308091198 9.957 35.67189892319349 139.73849362920797 9.957 35.67196116433663 139.73847245680926 9.957 35.67198160501802 139.73856091492763 9.957 35.67191981532775 139.73858308091198 9.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0fb343c-13e2-4aed-84b8-8c269dcc3067">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0fb343c-13e2-4aed-84b8-8c269dcc3067">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0fb343c-13e2-4aed-84b8-8c269dcc3067">
											<gml:posList>35.67191981532775 139.73858308091198 25.902 35.67192234376719 139.7385774663162 25.902 35.67190350465151 139.73849678307855 25.902 35.67189892319349 139.73849362920797 25.902 35.67191981532775 139.73858308091198 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45d05151-e40b-417b-87d3-94f87fb7e8b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45d05151-e40b-417b-87d3-94f87fb7e8b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45d05151-e40b-417b-87d3-94f87fb7e8b6">
											<gml:posList>35.671927931954215 139.73849690883412 25.594 35.67190350465151 139.73849678307855 25.594 35.67192234376719 139.7385774663162 25.594 35.67193445908505 139.7385213138194 25.594 35.671927931954215 139.73849690883412 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eb6f3964-62a7-4a60-9a78-b9336f135754">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb6f3964-62a7-4a60-9a78-b9336f135754">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb6f3964-62a7-4a60-9a78-b9336f135754">
											<gml:posList>35.67190350465151 139.73849678307855 25.902 35.67195861783986 139.73847802724657 25.902 35.67196116433663 139.73847245680926 25.902 35.67189892319349 139.73849362920797 25.902 35.67190350465151 139.73849678307855 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd60434c-c898-452b-b1ca-e2bae79e8ed3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd60434c-c898-452b-b1ca-e2bae79e8ed3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd60434c-c898-452b-b1ca-e2bae79e8ed3">
											<gml:posList>35.671927931954215 139.73849690883412 25.594 35.67195797422097 139.73848484368412 25.594 35.67195861783986 139.73847802724657 25.594 35.67190350465151 139.73849678307855 25.594 35.671927931954215 139.73849690883412 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-588136d6-49ba-4122-ae37-2cc2fdb90c2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-588136d6-49ba-4122-ae37-2cc2fdb90c2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-588136d6-49ba-4122-ae37-2cc2fdb90c2a">
											<gml:posList>35.671927931954215 139.73849690883412 30.207 35.67193445908505 139.7385213138194 30.207 35.671964501354246 139.73850924867753 30.207 35.67195797422097 139.73848484368412 30.207 35.671927931954215 139.73849690883412 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de00c025-fb3b-4fbc-8251-d406172a4363">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de00c025-fb3b-4fbc-8251-d406172a4363">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de00c025-fb3b-4fbc-8251-d406172a4363">
											<gml:posList>35.67197705967746 139.73855783833298 25.594 35.671964501354246 139.73850924867753 25.594 35.67193445908505 139.7385213138194 25.594 35.67192234376719 139.7385774663162 25.594 35.67197705967746 139.73855783833298 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89cf60ed-4189-4afa-b2ea-084f93d52c7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89cf60ed-4189-4afa-b2ea-084f93d52c7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89cf60ed-4189-4afa-b2ea-084f93d52c7d">
											<gml:posList>35.67192234376719 139.7385774663162 25.902 35.67191981532775 139.73858308091198 25.902 35.67198160501802 139.73856091492763 25.902 35.67197705967746 139.73855783833298 25.902 35.67192234376719 139.7385774663162 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af69039a-25f1-4361-8145-cff030585cae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af69039a-25f1-4361-8145-cff030585cae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af69039a-25f1-4361-8145-cff030585cae">
											<gml:posList>35.671964501354246 139.73850924867753 25.594 35.67197705967746 139.73855783833298 25.594 35.67195861783986 139.73847802724657 25.594 35.67195797422097 139.73848484368412 25.594 35.671964501354246 139.73850924867753 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5fc8d06-37a3-4a3d-9669-28fbd75e8f36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5fc8d06-37a3-4a3d-9669-28fbd75e8f36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5fc8d06-37a3-4a3d-9669-28fbd75e8f36">
											<gml:posList>35.67197705967746 139.73855783833298 25.902 35.67198160501802 139.73856091492763 25.902 35.67196116433663 139.73847245680926 25.902 35.67195861783986 139.73847802724657 25.902 35.67197705967746 139.73855783833298 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98227ae7-cb4b-4c29-8ff7-0005a3340306">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98227ae7-cb4b-4c29-8ff7-0005a3340306">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98227ae7-cb4b-4c29-8ff7-0005a3340306">
											<gml:posList>35.67189892319349 139.73849362920797 25.902 35.67189892319349 139.73849362920797 9.957 35.67191981532775 139.73858308091198 9.957 35.67191981532775 139.73858308091198 25.902 35.67189892319349 139.73849362920797 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70e863a9-b125-4cfc-bae3-9b720c8edd2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70e863a9-b125-4cfc-bae3-9b720c8edd2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70e863a9-b125-4cfc-bae3-9b720c8edd2f">
											<gml:posList>35.67190350465151 139.73849678307855 25.902 35.67192234376719 139.7385774663162 25.902 35.67192234376719 139.7385774663162 25.594 35.67190350465151 139.73849678307855 25.594 35.67190350465151 139.73849678307855 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08438856-1d22-449f-97ab-816626846162">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08438856-1d22-449f-97ab-816626846162">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08438856-1d22-449f-97ab-816626846162">
											<gml:posList>35.67196116433663 139.73847245680926 9.957 35.67189892319349 139.73849362920797 9.957 35.67189892319349 139.73849362920797 25.902 35.67196116433663 139.73847245680926 25.902 35.67196116433663 139.73847245680926 9.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71b42e05-4e89-47ba-9411-806fdc404e9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71b42e05-4e89-47ba-9411-806fdc404e9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71b42e05-4e89-47ba-9411-806fdc404e9a">
											<gml:posList>35.67195861783986 139.73847802724657 25.902 35.67190350465151 139.73849678307855 25.902 35.67190350465151 139.73849678307855 25.594 35.67195861783986 139.73847802724657 25.594 35.67195861783986 139.73847802724657 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf6805a4-6624-4a5d-be0b-e6da5b172e3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf6805a4-6624-4a5d-be0b-e6da5b172e3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf6805a4-6624-4a5d-be0b-e6da5b172e3b">
											<gml:posList>35.67193445908505 139.7385213138194 30.207 35.671927931954215 139.73849690883412 30.207 35.671927931954215 139.73849690883412 25.594 35.67193445908505 139.7385213138194 25.594 35.67193445908505 139.7385213138194 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-063314d8-dfd0-4b93-aab2-755ad8f426d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-063314d8-dfd0-4b93-aab2-755ad8f426d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-063314d8-dfd0-4b93-aab2-755ad8f426d6">
											<gml:posList>35.67195797422097 139.73848484368412 30.207 35.67195797422097 139.73848484368412 25.594 35.671927931954215 139.73849690883412 25.594 35.671927931954215 139.73849690883412 30.207 35.67195797422097 139.73848484368412 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-316846e3-486c-44fa-b0df-99ba35831e00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-316846e3-486c-44fa-b0df-99ba35831e00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-316846e3-486c-44fa-b0df-99ba35831e00">
											<gml:posList>35.671964501354246 139.73850924867753 30.207 35.67193445908505 139.7385213138194 30.207 35.67193445908505 139.7385213138194 25.594 35.671964501354246 139.73850924867753 25.594 35.671964501354246 139.73850924867753 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39ab392c-2316-4e9a-97d2-6999eb803fe9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39ab392c-2316-4e9a-97d2-6999eb803fe9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39ab392c-2316-4e9a-97d2-6999eb803fe9">
											<gml:posList>35.67197705967746 139.73855783833298 25.594 35.67192234376719 139.7385774663162 25.594 35.67192234376719 139.7385774663162 25.902 35.67197705967746 139.73855783833298 25.902 35.67197705967746 139.73855783833298 25.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-758b20f1-6736-47ae-be1c-d44a68edd069">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-758b20f1-6736-47ae-be1c-d44a68edd069">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-758b20f1-6736-47ae-be1c-d44a68edd069">
											<gml:posList>35.67191981532775 139.73858308091198 25.902 35.67191981532775 139.73858308091198 9.957 35.67198160501802 139.73856091492763 9.957 35.67198160501802 139.73856091492763 25.902 35.67191981532775 139.73858308091198 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31d8c99d-5b8b-407e-8adc-29eeef9c30f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31d8c99d-5b8b-407e-8adc-29eeef9c30f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31d8c99d-5b8b-407e-8adc-29eeef9c30f2">
											<gml:posList>35.67195797422097 139.73848484368412 30.207 35.671964501354246 139.73850924867753 30.207 35.671964501354246 139.73850924867753 25.594 35.67195797422097 139.73848484368412 25.594 35.67195797422097 139.73848484368412 30.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52a80b41-ad85-4be1-b76b-a59a810dd9e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52a80b41-ad85-4be1-b76b-a59a810dd9e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52a80b41-ad85-4be1-b76b-a59a810dd9e9">
											<gml:posList>35.67197705967746 139.73855783833298 25.902 35.67195861783986 139.73847802724657 25.902 35.67195861783986 139.73847802724657 25.594 35.67197705967746 139.73855783833298 25.594 35.67197705967746 139.73855783833298 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59d03998-7e02-4111-858d-c322d05df17d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59d03998-7e02-4111-858d-c322d05df17d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59d03998-7e02-4111-858d-c322d05df17d">
											<gml:posList>35.67196116433663 139.73847245680926 9.957 35.67196116433663 139.73847245680926 25.902 35.67198160501802 139.73856091492763 25.902 35.67198160501802 139.73856091492763 9.957 35.67196116433663 139.73847245680926 9.957</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2036</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">52.87575</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>