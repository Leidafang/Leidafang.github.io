<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2842d30a-43fc-482f-9230-a26cb1f3562a">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667865964170474 139.73808340452635 0 35.66788371723929 139.73806696920775 0 35.66786099151922 139.7380301470449 0 35.667843247469094 139.73804658235622 0 35.667865964170474 139.73808340452635 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667865964170474 139.73808340452635 29.82 35.667843247469094 139.73804658235622 29.82 35.66786099151922 139.7380301470449 29.82 35.66788371723929 139.73806696920775 29.82 35.667865964170474 139.73808340452635 29.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667865964170474 139.73808340452635 29.82 35.66788371723929 139.73806696920775 29.82 35.66788371723929 139.73806696920775 32.82 35.667865964170474 139.73808340452635 32.82 35.667865964170474 139.73808340452635 29.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66788371723929 139.73806696920775 29.82 35.66786099151922 139.7380301470449 29.82 35.66786099151922 139.7380301470449 32.82 35.66788371723929 139.73806696920775 32.82 35.66788371723929 139.73806696920775 29.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66786099151922 139.7380301470449 29.82 35.667843247469094 139.73804658235622 29.82 35.667843247469094 139.73804658235622 32.82 35.66786099151922 139.7380301470449 32.82 35.66786099151922 139.7380301470449 29.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667843247469094 139.73804658235622 29.82 35.667865964170474 139.73808340452635 29.82 35.667865964170474 139.73808340452635 32.82 35.667843247469094 139.73804658235622 32.82 35.667843247469094 139.73804658235622 29.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667865964170474 139.73808340452635 32.82 35.66788371723929 139.73806696920775 32.82 35.66786099151922 139.7380301470449 32.82 35.667843247469094 139.73804658235622 32.82 35.667865964170474 139.73808340452635 32.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-dd6396ee-38d6-41e5-afe2-ac549bafc0f8"/>
							<gml:surfaceMember xlink:href="#poly-99c743ba-a389-469d-b8b6-b3e9115942f7"/>
							<gml:surfaceMember xlink:href="#poly-741072bf-a101-4498-b4f0-67cfb62e226e"/>
							<gml:surfaceMember xlink:href="#poly-98074997-f8a0-48ca-911d-4aff5e071eb1"/>
							<gml:surfaceMember xlink:href="#poly-e9b55386-5053-4fb2-b6b3-4444208bf123"/>
							<gml:surfaceMember xlink:href="#poly-d17db92d-cb77-4f26-a980-9482ae283912"/>
							<gml:surfaceMember xlink:href="#poly-02f3bc5a-55f4-4eeb-8109-c8c693e85168"/>
							<gml:surfaceMember xlink:href="#poly-6b34103d-e23d-4d3d-bc8d-32b54d4bc53a"/>
							<gml:surfaceMember xlink:href="#poly-c343340d-98b4-4078-ae63-c9c747de7e3b"/>
							<gml:surfaceMember xlink:href="#poly-9c1315f0-50d4-4f7f-aee6-0fdbd35f2370"/>
							<gml:surfaceMember xlink:href="#poly-3d732670-3d86-41e1-a0d8-385b9f87f109"/>
							<gml:surfaceMember xlink:href="#poly-91e57491-4a02-415c-979f-2a78b937149a"/>
							<gml:surfaceMember xlink:href="#poly-68c56f7e-58f5-4b32-bae4-f6c496a791f8"/>
							<gml:surfaceMember xlink:href="#poly-9d4f6aaa-d4c1-45f6-96ba-b5ebe4895200"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-dd6396ee-38d6-41e5-afe2-ac549bafc0f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd6396ee-38d6-41e5-afe2-ac549bafc0f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd6396ee-38d6-41e5-afe2-ac549bafc0f8">
											<gml:posList>35.667865964170474 139.73808340452632 29.82 35.66784324746908 139.73804658235622 29.82 35.667860991519206 139.73803014704487 29.82 35.66788371723928 139.73806696920775 29.82 35.667865964170474 139.73808340452632 29.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99c743ba-a389-469d-b8b6-b3e9115942f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99c743ba-a389-469d-b8b6-b3e9115942f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99c743ba-a389-469d-b8b6-b3e9115942f7">
											<gml:posList>35.66784324746908 139.73804658235622 32.699 35.6678450865139 139.73804688945629 32.699 35.667860749932004 139.73803240069807 32.699 35.667860991519206 139.73803014704487 32.699 35.66784324746908 139.73804658235622 32.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-741072bf-a101-4498-b4f0-67cfb62e226e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-741072bf-a101-4498-b4f0-67cfb62e226e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-741072bf-a101-4498-b4f0-67cfb62e226e">
											<gml:posList>35.667860991519206 139.73803014704487 32.699 35.667860749932004 139.73803240069807 32.699 35.667881887208246 139.73806666209634 32.699 35.66788371723928 139.73806696920775 32.699 35.667860991519206 139.73803014704487 32.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98074997-f8a0-48ca-911d-4aff5e071eb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98074997-f8a0-48ca-911d-4aff5e071eb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98074997-f8a0-48ca-911d-4aff5e071eb1">
											<gml:posList>35.667881887208246 139.73806666209634 32.358 35.667860749932004 139.73803240069807 32.358 35.6678450865139 139.73804688945629 32.358 35.66786621477235 139.73808115086243 32.358 35.667881887208246 139.73806666209634 32.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9b55386-5053-4fb2-b6b3-4444208bf123">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9b55386-5053-4fb2-b6b3-4444208bf123">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9b55386-5053-4fb2-b6b3-4444208bf123">
											<gml:posList>35.667865964170474 139.73808340452632 32.699 35.66786621477235 139.73808115086243 32.699 35.6678450865139 139.73804688945629 32.699 35.66784324746908 139.73804658235622 32.699 35.667865964170474 139.73808340452632 32.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d17db92d-cb77-4f26-a980-9482ae283912">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d17db92d-cb77-4f26-a980-9482ae283912">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d17db92d-cb77-4f26-a980-9482ae283912">
											<gml:posList>35.66788371723928 139.73806696920775 32.699 35.667881887208246 139.73806666209634 32.699 35.66786621477235 139.73808115086243 32.699 35.667865964170474 139.73808340452632 32.699 35.66788371723928 139.73806696920775 32.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02f3bc5a-55f4-4eeb-8109-c8c693e85168">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02f3bc5a-55f4-4eeb-8109-c8c693e85168">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02f3bc5a-55f4-4eeb-8109-c8c693e85168">
											<gml:posList>35.66786621477235 139.73808115086243 32.699 35.66786621477235 139.73808115086243 32.358 35.6678450865139 139.73804688945629 32.358 35.6678450865139 139.73804688945629 32.699 35.66786621477235 139.73808115086243 32.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6b34103d-e23d-4d3d-bc8d-32b54d4bc53a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b34103d-e23d-4d3d-bc8d-32b54d4bc53a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b34103d-e23d-4d3d-bc8d-32b54d4bc53a">
											<gml:posList>35.667860749932004 139.73803240069807 32.699 35.667860749932004 139.73803240069807 32.358 35.667881887208246 139.73806666209634 32.358 35.667881887208246 139.73806666209634 32.699 35.667860749932004 139.73803240069807 32.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c343340d-98b4-4078-ae63-c9c747de7e3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c343340d-98b4-4078-ae63-c9c747de7e3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c343340d-98b4-4078-ae63-c9c747de7e3b">
											<gml:posList>35.667860991519206 139.73803014704487 29.82 35.66784324746908 139.73804658235622 29.82 35.66784324746908 139.73804658235622 32.699 35.667860991519206 139.73803014704487 32.699 35.667860991519206 139.73803014704487 29.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c1315f0-50d4-4f7f-aee6-0fdbd35f2370">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c1315f0-50d4-4f7f-aee6-0fdbd35f2370">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c1315f0-50d4-4f7f-aee6-0fdbd35f2370">
											<gml:posList>35.6678450865139 139.73804688945629 32.699 35.6678450865139 139.73804688945629 32.358 35.667860749932004 139.73803240069807 32.358 35.667860749932004 139.73803240069807 32.699 35.6678450865139 139.73804688945629 32.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d732670-3d86-41e1-a0d8-385b9f87f109">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d732670-3d86-41e1-a0d8-385b9f87f109">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d732670-3d86-41e1-a0d8-385b9f87f109">
											<gml:posList>35.66788371723928 139.73806696920775 29.82 35.667860991519206 139.73803014704487 29.82 35.667860991519206 139.73803014704487 32.699 35.66788371723928 139.73806696920775 32.699 35.66788371723928 139.73806696920775 29.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91e57491-4a02-415c-979f-2a78b937149a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91e57491-4a02-415c-979f-2a78b937149a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91e57491-4a02-415c-979f-2a78b937149a">
											<gml:posList>35.66784324746908 139.73804658235622 29.82 35.667865964170474 139.73808340452632 29.82 35.667865964170474 139.73808340452632 32.699 35.66784324746908 139.73804658235622 32.699 35.66784324746908 139.73804658235622 29.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68c56f7e-58f5-4b32-bae4-f6c496a791f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68c56f7e-58f5-4b32-bae4-f6c496a791f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68c56f7e-58f5-4b32-bae4-f6c496a791f8">
											<gml:posList>35.667881887208246 139.73806666209634 32.699 35.667881887208246 139.73806666209634 32.358 35.66786621477235 139.73808115086243 32.358 35.66786621477235 139.73808115086243 32.699 35.667881887208246 139.73806666209634 32.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d4f6aaa-d4c1-45f6-96ba-b5ebe4895200">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d4f6aaa-d4c1-45f6-96ba-b5ebe4895200">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d4f6aaa-d4c1-45f6-96ba-b5ebe4895200">
											<gml:posList>35.667865964170474 139.73808340452632 29.82 35.66788371723928 139.73806696920775 29.82 35.66788371723928 139.73806696920775 32.699 35.667865964170474 139.73808340452632 32.699 35.667865964170474 139.73808340452632 29.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1011</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">3</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>