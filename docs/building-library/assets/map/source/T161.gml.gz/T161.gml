<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_29929788-6dd8-40ac-8d1c-d50fa1320acc">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">415</bldg:usage>
			<bldg:measuredHeight uom="m">6.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66693801865168 139.73804982302173 0 35.66697314674942 139.73801763803212 0 35.66695175553292 139.737981433278 0 35.66694038476582 139.7379644362897 0 35.66693325421037 139.73795218394957 0 35.66689848676646 139.73798447898074 0 35.66693801865168 139.73804982302173 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693801865168 139.73804982302173 13.866 35.66689848676646 139.73798447898074 13.866 35.66693325421037 139.73795218394957 13.866 35.66694038476582 139.7379644362897 13.866 35.66695175553292 139.737981433278 13.866 35.66697314674942 139.73801763803212 13.866 35.66693801865168 139.73804982302173 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693801865168 139.73804982302173 13.866 35.66697314674942 139.73801763803212 13.866 35.66697314674942 139.73801763803212 20.34 35.66693801865168 139.73804982302173 20.34 35.66693801865168 139.73804982302173 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66697314674942 139.73801763803212 13.866 35.66695175553292 139.737981433278 13.866 35.66695175553292 139.737981433278 20.34 35.66697314674942 139.73801763803212 20.34 35.66697314674942 139.73801763803212 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66695175553292 139.737981433278 13.866 35.66694038476582 139.7379644362897 13.866 35.66694038476582 139.7379644362897 20.34 35.66695175553292 139.737981433278 20.34 35.66695175553292 139.737981433278 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66694038476582 139.7379644362897 13.866 35.66693325421037 139.73795218394957 13.866 35.66693325421037 139.73795218394957 20.34 35.66694038476582 139.7379644362897 20.34 35.66694038476582 139.7379644362897 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693325421037 139.73795218394957 13.866 35.66689848676646 139.73798447898074 13.866 35.66689848676646 139.73798447898074 20.34 35.66693325421037 139.73795218394957 20.34 35.66693325421037 139.73795218394957 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689848676646 139.73798447898074 13.866 35.66693801865168 139.73804982302173 13.866 35.66693801865168 139.73804982302173 20.34 35.66689848676646 139.73798447898074 20.34 35.66689848676646 139.73798447898074 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693801865168 139.73804982302173 20.34 35.66697314674942 139.73801763803212 20.34 35.66695175553292 139.737981433278 20.34 35.66694038476582 139.7379644362897 20.34 35.66693325421037 139.73795218394957 20.34 35.66689848676646 139.73798447898074 20.34 35.66693801865168 139.73804982302173 20.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-c24093da-31ff-4222-bc09-a50631b3f1cc"/>
							<gml:surfaceMember xlink:href="#poly-1fc77faf-e095-4265-8536-03f475b22df0"/>
							<gml:surfaceMember xlink:href="#poly-1d068597-6bcc-4988-aebe-1665a53b5958"/>
							<gml:surfaceMember xlink:href="#poly-e0829afd-e26b-4202-8e65-b31716ff7e3a"/>
							<gml:surfaceMember xlink:href="#poly-84ac71cc-a0f6-4c13-9161-6e82770765b8"/>
							<gml:surfaceMember xlink:href="#poly-98c63387-6e5d-42ed-b240-23c2e17b4c08"/>
							<gml:surfaceMember xlink:href="#poly-387f1033-5843-4368-ad4b-34b14e06cc14"/>
							<gml:surfaceMember xlink:href="#poly-1368e20d-e849-4517-98be-81eb8b0f7521"/>
							<gml:surfaceMember xlink:href="#poly-b02e48ec-dcd8-4715-b9a0-baab842b6835"/>
							<gml:surfaceMember xlink:href="#poly-333b1b7c-6411-485f-84b5-ac52f8cbf2da"/>
							<gml:surfaceMember xlink:href="#poly-1438f22b-c015-42c7-8e5f-cc8c77b772c7"/>
							<gml:surfaceMember xlink:href="#poly-d5c011b6-93dd-4446-b1f0-161bd7f01c34"/>
							<gml:surfaceMember xlink:href="#poly-238d338f-534e-468b-87e9-38c3fcff45fb"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_29929788-6dd8-40ac-8d1c-d50fa1320acc_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa6ec28c-5ca0-4918-9236-d7bd456c6c3f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666951755532914 139.73798143327798 13.866 35.66694038476583 139.73796443628967 13.866 35.66694696006259 139.73795846374495 13.866 35.666957880668974 139.73797612401643 13.866 35.666951755532914 139.73798143327798 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ca54ffc-361f-492d-bcbd-efcfb92dd20f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ca54ffc-361f-492d-bcbd-efcfb92dd20f_0">
											<gml:posList>35.66694696006259 139.73795846374495 19.809 35.66694696006259 139.73795846374495 13.866 35.66694038476583 139.73796443628967 13.866 35.66694038476583 139.73796443628967 19.809 35.66694696006259 139.73795846374495 19.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5e02e5d-0824-4f2c-b30e-a60f2efba6df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5e02e5d-0824-4f2c-b30e-a60f2efba6df_0">
											<gml:posList>35.666957880668974 139.73797612401643 13.866 35.66694696006259 139.73795846374495 13.866 35.66694696006259 139.73795846374495 19.809 35.666957880668974 139.73797612401643 19.809 35.666957880668974 139.73797612401643 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12dfa7a8-18fd-4762-91a8-92e1def961b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12dfa7a8-18fd-4762-91a8-92e1def961b3_0">
											<gml:posList>35.666951755532914 139.73798143327798 19.809 35.666957880668974 139.73797612401643 19.809 35.66694696006259 139.73795846374495 19.809 35.66694038476583 139.73796443628967 19.809 35.666951755532914 139.73798143327798 19.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-704689ce-6ca8-4b9c-8ea4-64bbcbdc86c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-704689ce-6ca8-4b9c-8ea4-64bbcbdc86c1_0">
											<gml:posList>35.666951755532914 139.73798143327798 13.866 35.666951755532914 139.73798143327798 19.809 35.66694038476583 139.73796443628967 19.809 35.66694038476583 139.73796443628967 13.866 35.666951755532914 139.73798143327798 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64ada51a-6614-42bc-8abe-a1b76c1f626f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64ada51a-6614-42bc-8abe-a1b76c1f626f_0">
											<gml:posList>35.666951755532914 139.73798143327798 19.809 35.666951755532914 139.73798143327798 13.866 35.666957880668974 139.73797612401643 13.866 35.666957880668974 139.73797612401643 19.809 35.666951755532914 139.73798143327798 19.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c24093da-31ff-4222-bc09-a50631b3f1cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c24093da-31ff-4222-bc09-a50631b3f1cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c24093da-31ff-4222-bc09-a50631b3f1cc">
											<gml:posList>35.66689848676646 139.73798447898074 13.866 35.66693325421037 139.73795218394957 13.866 35.66694038476583 139.73796443628967 13.866 35.666951755532914 139.73798143327798 13.866 35.66697314674942 139.73801763803212 13.866 35.66693801865168 139.73804982302173 13.866 35.66689848676646 139.73798447898074 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1fc77faf-e095-4265-8536-03f475b22df0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fc77faf-e095-4265-8536-03f475b22df0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fc77faf-e095-4265-8536-03f475b22df0">
											<gml:posList>35.666939286904245 139.73800087764064 20.897 35.66693325421037 139.73795218394957 19.809 35.66691795112966 139.7379663959823 20.897 35.666939286904245 139.73800087764064 20.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d068597-6bcc-4988-aebe-1665a53b5958">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d068597-6bcc-4988-aebe-1665a53b5958">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d068597-6bcc-4988-aebe-1665a53b5958">
											<gml:posList>35.666939286904245 139.73800087764064 20.897 35.66694038476583 139.73796443628967 19.809 35.66693325421037 139.73795218394957 19.809 35.666939286904245 139.73800087764064 20.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e0829afd-e26b-4202-8e65-b31716ff7e3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0829afd-e26b-4202-8e65-b31716ff7e3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0829afd-e26b-4202-8e65-b31716ff7e3a">
											<gml:posList>35.666939286904245 139.73800087764064 20.897 35.666951755532914 139.73798143327798 19.809 35.66694038476583 139.73796443628967 19.809 35.666939286904245 139.73800087764064 20.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-84ac71cc-a0f6-4c13-9161-6e82770765b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84ac71cc-a0f6-4c13-9161-6e82770765b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84ac71cc-a0f6-4c13-9161-6e82770765b8">
											<gml:posList>35.666939286904245 139.73800087764064 20.897 35.66697314674942 139.73801763803212 19.809 35.666951755532914 139.73798143327798 19.809 35.666939286904245 139.73800087764064 20.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98c63387-6e5d-42ed-b240-23c2e17b4c08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98c63387-6e5d-42ed-b240-23c2e17b4c08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98c63387-6e5d-42ed-b240-23c2e17b4c08">
											<gml:posList>35.66689848676646 139.73798447898074 19.809 35.66693801865168 139.73804982302173 19.809 35.666939286904245 139.73800087764064 20.897 35.66691795112966 139.7379663959823 20.897 35.66689848676646 139.73798447898074 19.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-387f1033-5843-4368-ad4b-34b14e06cc14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-387f1033-5843-4368-ad4b-34b14e06cc14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-387f1033-5843-4368-ad4b-34b14e06cc14">
											<gml:posList>35.66693801865168 139.73804982302173 19.809 35.66697314674942 139.73801763803212 19.809 35.666939286904245 139.73800087764064 20.897 35.66693801865168 139.73804982302173 19.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1368e20d-e849-4517-98be-81eb8b0f7521">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1368e20d-e849-4517-98be-81eb8b0f7521">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1368e20d-e849-4517-98be-81eb8b0f7521">
											<gml:posList>35.66694038476583 139.73796443628967 13.866 35.66693325421037 139.73795218394957 13.866 35.66693325421037 139.73795218394957 19.809 35.66694038476583 139.73796443628967 19.809 35.66694038476583 139.73796443628967 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b02e48ec-dcd8-4715-b9a0-baab842b6835">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b02e48ec-dcd8-4715-b9a0-baab842b6835">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b02e48ec-dcd8-4715-b9a0-baab842b6835">
											<gml:posList>35.66691795112966 139.7379663959823 20.897 35.66693325421037 139.73795218394957 19.809 35.66693325421037 139.73795218394957 13.866 35.66689848676646 139.73798447898074 13.866 35.66689848676646 139.73798447898074 19.809 35.66691795112966 139.7379663959823 20.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-333b1b7c-6411-485f-84b5-ac52f8cbf2da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-333b1b7c-6411-485f-84b5-ac52f8cbf2da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-333b1b7c-6411-485f-84b5-ac52f8cbf2da">
											<gml:posList>35.666951755532914 139.73798143327798 13.866 35.66694038476583 139.73796443628967 13.866 35.66694038476583 139.73796443628967 19.809 35.666951755532914 139.73798143327798 19.809 35.666951755532914 139.73798143327798 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1438f22b-c015-42c7-8e5f-cc8c77b772c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1438f22b-c015-42c7-8e5f-cc8c77b772c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1438f22b-c015-42c7-8e5f-cc8c77b772c7">
											<gml:posList>35.66697314674942 139.73801763803212 13.866 35.666951755532914 139.73798143327798 13.866 35.666951755532914 139.73798143327798 19.809 35.66697314674942 139.73801763803212 19.809 35.66697314674942 139.73801763803212 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5c011b6-93dd-4446-b1f0-161bd7f01c34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5c011b6-93dd-4446-b1f0-161bd7f01c34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5c011b6-93dd-4446-b1f0-161bd7f01c34">
											<gml:posList>35.66689848676646 139.73798447898074 13.866 35.66693801865168 139.73804982302173 13.866 35.66693801865168 139.73804982302173 19.809 35.66689848676646 139.73798447898074 19.809 35.66689848676646 139.73798447898074 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-238d338f-534e-468b-87e9-38c3fcff45fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-238d338f-534e-468b-87e9-38c3fcff45fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-238d338f-534e-468b-87e9-38c3fcff45fb">
											<gml:posList>35.66693801865168 139.73804982302173 13.866 35.66697314674942 139.73801763803212 13.866 35.66697314674942 139.73801763803212 19.809 35.66693801865168 139.73804982302173 19.809 35.66693801865168 139.73804982302173 13.866</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2416</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">37.68245</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1420</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">22</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>