<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_29c15864-440e-441c-9ce9-107048c2869f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">28.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67119774269289 139.7379540701354 0 35.67117684798835 139.73786196827552 0 35.671066369542416 139.73789965743384 0 35.671087354355535 139.7379917590696 0 35.67119774269289 139.7379540701354 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119774269289 139.7379540701354 13.63 35.671087354355535 139.7379917590696 13.63 35.671066369542416 139.73789965743384 13.63 35.67117684798835 139.73786196827552 13.63 35.67119774269289 139.7379540701354 13.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119774269289 139.7379540701354 13.63 35.67117684798835 139.73786196827552 13.63 35.67117684798835 139.73786196827552 42.04 35.67119774269289 139.7379540701354 42.04 35.67119774269289 139.7379540701354 13.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117684798835 139.73786196827552 13.63 35.671066369542416 139.73789965743384 13.63 35.671066369542416 139.73789965743384 42.04 35.67117684798835 139.73786196827552 42.04 35.67117684798835 139.73786196827552 13.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671066369542416 139.73789965743384 13.63 35.671087354355535 139.7379917590696 13.63 35.671087354355535 139.7379917590696 42.04 35.671066369542416 139.73789965743384 42.04 35.671066369542416 139.73789965743384 13.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671087354355535 139.7379917590696 13.63 35.67119774269289 139.7379540701354 13.63 35.67119774269289 139.7379540701354 42.04 35.671087354355535 139.7379917590696 42.04 35.671087354355535 139.7379917590696 13.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119774269289 139.7379540701354 42.04 35.67117684798835 139.73786196827552 42.04 35.671066369542416 139.73789965743384 42.04 35.671087354355535 139.7379917590696 42.04 35.67119774269289 139.7379540701354 42.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-639f28eb-5f98-46b9-a67a-5fae60fdef51"/>
							<gml:surfaceMember xlink:href="#poly-5dcc98fc-4d9a-45ad-a51a-8e2508b151a8"/>
							<gml:surfaceMember xlink:href="#poly-18a50209-16c8-4449-bef0-1770c7a9e1b6"/>
							<gml:surfaceMember xlink:href="#poly-4425017d-afe1-4d70-824d-598cda00141f"/>
							<gml:surfaceMember xlink:href="#poly-7c7e2ede-6760-4b53-b5b5-e8b1a4d92dac"/>
							<gml:surfaceMember xlink:href="#poly-a2cb3c2d-d9ec-4cfb-b630-f894003bcdcd"/>
							<gml:surfaceMember xlink:href="#poly-61ec1a2f-ba4f-4248-8c48-c715bf1c9c95"/>
							<gml:surfaceMember xlink:href="#poly-c4ec076a-ded0-4f4f-a2cc-25548c690b0f"/>
							<gml:surfaceMember xlink:href="#poly-4846c5e7-8550-4c9a-b9a1-7a7bf0399c77"/>
							<gml:surfaceMember xlink:href="#poly-6a9f942b-17b7-4c78-a8fd-01a2a80d84b1"/>
							<gml:surfaceMember xlink:href="#poly-ec630b9f-e0da-4c80-8f24-edd986982a86"/>
							<gml:surfaceMember xlink:href="#poly-872e59d6-a6ea-4a16-b35c-56d41df738c1"/>
							<gml:surfaceMember xlink:href="#poly-708d856b-032f-4fef-a3e3-22bb61c07881"/>
							<gml:surfaceMember xlink:href="#poly-61e5ce90-2fbe-4546-b1b8-40d2e0e14290"/>
							<gml:surfaceMember xlink:href="#poly-2d490819-6073-4e2d-90c8-5955a546208c"/>
							<gml:surfaceMember xlink:href="#poly-8aed9631-5526-405c-91b2-6c3d0887c24b"/>
							<gml:surfaceMember xlink:href="#poly-9326cc75-c3cf-4666-8b5d-36d2f49ca25f"/>
							<gml:surfaceMember xlink:href="#poly-ed26e50a-4b72-42a8-99b0-2a1eac1ea747"/>
							<gml:surfaceMember xlink:href="#poly-24744c19-7a93-448e-9439-0baba8fbeed0"/>
							<gml:surfaceMember xlink:href="#poly-9b4a2f3d-1849-487a-acef-d9d3be01a3be"/>
							<gml:surfaceMember xlink:href="#poly-db395a51-c4e9-49a2-872c-16897e413013"/>
							<gml:surfaceMember xlink:href="#poly-56f4a66e-d936-4192-8ee7-c5081018df30"/>
							<gml:surfaceMember xlink:href="#poly-5e991450-4c19-45be-8306-18ba77134031"/>
							<gml:surfaceMember xlink:href="#poly-3683e364-3c90-4d17-b4d5-8bc52bccd4fb"/>
							<gml:surfaceMember xlink:href="#poly-e4adfd1f-40d1-4354-9112-c390e8efa575"/>
							<gml:surfaceMember xlink:href="#poly-e751e5e4-a680-47be-ab90-7b72ea7eb78d"/>
							<gml:surfaceMember xlink:href="#poly-d95779fb-6114-4adf-b230-fb4b8796ce70"/>
							<gml:surfaceMember xlink:href="#poly-c7db2beb-de53-4267-83c4-446db6decfa1"/>
							<gml:surfaceMember xlink:href="#poly-ca266898-5879-4397-8c49-0635cf40574a"/>
							<gml:surfaceMember xlink:href="#poly-d1e5e712-b83e-45dc-ad3d-6333c071dda8"/>
							<gml:surfaceMember xlink:href="#poly-5dda189c-a23d-4b94-833a-5f6a084654b2"/>
							<gml:surfaceMember xlink:href="#poly-6efa4fd6-2664-4d22-a9be-2233acd40b8e"/>
							<gml:surfaceMember xlink:href="#poly-ab1e71c4-40bc-484a-81dc-4b921670f138"/>
							<gml:surfaceMember xlink:href="#poly-0b55d540-c4aa-44b7-a5c8-c517451a5051"/>
							<gml:surfaceMember xlink:href="#poly-0eb6199d-5c57-4362-add8-5534ebb809ee"/>
							<gml:surfaceMember xlink:href="#poly-d79075dc-a49c-4a98-bbf8-0a7cac5cf6fd"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-639f28eb-5f98-46b9-a67a-5fae60fdef51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-639f28eb-5f98-46b9-a67a-5fae60fdef51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-639f28eb-5f98-46b9-a67a-5fae60fdef51">
											<gml:posList>35.671197742692875 139.7379540701354 13.63 35.67108735435552 139.7379917590696 13.63 35.6710663695424 139.73789965743384 13.63 35.67117684798835 139.7378619682755 13.63 35.671197742692875 139.7379540701354 13.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5dcc98fc-4d9a-45ad-a51a-8e2508b151a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dcc98fc-4d9a-45ad-a51a-8e2508b151a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dcc98fc-4d9a-45ad-a51a-8e2508b151a8">
											<gml:posList>35.67108970279164 139.73789549832256 42.53 35.67116873181939 139.73786852843622 42.53 35.67117684798835 139.7378619682755 42.53 35.6710663695424 139.73789965743384 42.53 35.67108970279164 139.73789549832256 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18a50209-16c8-4449-bef0-1770c7a9e1b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18a50209-16c8-4449-bef0-1770c7a9e1b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18a50209-16c8-4449-bef0-1770c7a9e1b6">
											<gml:posList>35.67116873181939 139.73786852843622 42.208 35.67108970279164 139.73789549832256 42.208 35.67109301336081 139.73791006452717 42.208 35.67111317402831 139.73791759624265 42.208 35.6711480941084 139.7379073478434 42.208 35.671151131023244 139.7379064494732 42.208 35.67116790167078 139.73790152492504 42.208 35.671170686271424 139.7379007152257 42.208 35.67117564243462 139.7378989640001 42.208 35.67116873181939 139.73786852843622 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4425017d-afe1-4d70-824d-598cda00141f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4425017d-afe1-4d70-824d-598cda00141f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4425017d-afe1-4d70-824d-598cda00141f">
											<gml:posList>35.67117564243462 139.7378989640001 42.53 35.671170686271424 139.7379007152257 42.53 35.671174042993975 139.73791665113998 42.53 35.6711781160316 139.73791517712556 42.53 35.671186132364205 139.7379532554697 42.53 35.671197742692875 139.7379540701354 42.53 35.67117684798835 139.7378619682755 42.53 35.67116873181939 139.73786852843622 42.53 35.67117564243462 139.7378989640001 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7c7e2ede-6760-4b53-b5b5-e8b1a4d92dac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c7e2ede-6760-4b53-b5b5-e8b1a4d92dac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c7e2ede-6760-4b53-b5b5-e8b1a4d92dac">
											<gml:posList>35.67117109620752 139.73791753835644 42.208 35.671174042993975 139.73791665113998 42.208 35.671170686271424 139.7379007152257 42.208 35.67116790167078 139.73790152492504 42.208 35.67117109620752 139.73791753835644 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a2cb3c2d-d9ec-4cfb-b630-f894003bcdcd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2cb3c2d-d9ec-4cfb-b630-f894003bcdcd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2cb3c2d-d9ec-4cfb-b630-f894003bcdcd">
											<gml:posList>35.67117109620752 139.73791753835644 41.207 35.67116790167078 139.73790152492504 41.207 35.671151131023244 139.7379064494732 41.207 35.67115434366555 139.7379225622972 41.207 35.67117109620752 139.73791753835644 41.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-61ec1a2f-ba4f-4248-8c48-c715bf1c9c95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61ec1a2f-ba4f-4248-8c48-c715bf1c9c95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61ec1a2f-ba4f-4248-8c48-c715bf1c9c95">
											<gml:posList>35.67115434366555 139.7379225622972 42.208 35.671151131023244 139.7379064494732 42.208 35.6711480941084 139.7379073478434 42.208 35.67115131576431 139.73792346065608 42.208 35.67115434366555 139.7379225622972 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c4ec076a-ded0-4f4f-a2cc-25548c690b0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4ec076a-ded0-4f4f-a2cc-25548c690b0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4ec076a-ded0-4f4f-a2cc-25548c690b0f">
											<gml:posList>35.67111317402831 139.73791759624265 41.207 35.671116458936424 139.73793390780796 41.207 35.67115131576431 139.73792346065608 41.207 35.6711480941084 139.7379073478434 41.207 35.67111317402831 139.73791759624265 41.207</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4846c5e7-8550-4c9a-b9a1-7a7bf0399c77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4846c5e7-8550-4c9a-b9a1-7a7bf0399c77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4846c5e7-8550-4c9a-b9a1-7a7bf0399c77">
											<gml:posList>35.67109301336081 139.73791006452717 42.208 35.67107834297097 139.73791506389384 42.208 35.67108595004616 139.7379485473932 42.208 35.67110150353701 139.73794323768342 42.208 35.671116458936424 139.73793390780796 42.208 35.67111317402831 139.73791759624265 42.208 35.67109301336081 139.73791006452717 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a9f942b-17b7-4c78-a8fd-01a2a80d84b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a9f942b-17b7-4c78-a8fd-01a2a80d84b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a9f942b-17b7-4c78-a8fd-01a2a80d84b1">
											<gml:posList>35.67107834297097 139.73791506389384 42.53 35.67109301336081 139.73791006452717 42.53 35.67108970279164 139.73789549832256 42.53 35.6710663695424 139.73789965743384 42.53 35.67108735435552 139.7379917590696 42.53 35.67110930055731 139.73797756049257 42.53 35.67110150353701 139.73794323768342 42.53 35.67108595004616 139.7379485473932 42.53 35.67107834297097 139.73791506389384 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec630b9f-e0da-4c80-8f24-edd986982a86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec630b9f-e0da-4c80-8f24-edd986982a86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec630b9f-e0da-4c80-8f24-edd986982a86">
											<gml:posList>35.67115434366555 139.7379225622972 42.208 35.67115131576431 139.73792346065608 42.208 35.671116458936424 139.73793390780796 42.208 35.67110150353701 139.73794323768342 42.208 35.67110930055731 139.73797756049257 42.208 35.671186132364205 139.7379532554697 42.208 35.6711781160316 139.73791517712556 42.208 35.671174042993975 139.73791665113998 42.208 35.67117109620752 139.73791753835644 42.208 35.67115434366555 139.7379225622972 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-872e59d6-a6ea-4a16-b35c-56d41df738c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-872e59d6-a6ea-4a16-b35c-56d41df738c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-872e59d6-a6ea-4a16-b35c-56d41df738c1">
											<gml:posList>35.67110930055731 139.73797756049257 42.53 35.67108735435552 139.7379917590696 42.53 35.671197742692875 139.7379540701354 42.53 35.671186132364205 139.7379532554697 42.53 35.67110930055731 139.73797756049257 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-708d856b-032f-4fef-a3e3-22bb61c07881">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-708d856b-032f-4fef-a3e3-22bb61c07881">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-708d856b-032f-4fef-a3e3-22bb61c07881">
											<gml:posList>35.67117564243462 139.7378989640001 42.53 35.67117564243462 139.7378989640001 42.208 35.671170686271424 139.7379007152257 42.208 35.671170686271424 139.7379007152257 42.53 35.67117564243462 139.7378989640001 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61e5ce90-2fbe-4546-b1b8-40d2e0e14290">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61e5ce90-2fbe-4546-b1b8-40d2e0e14290">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61e5ce90-2fbe-4546-b1b8-40d2e0e14290">
											<gml:posList>35.67117684798835 139.7378619682755 13.63 35.6710663695424 139.73789965743384 13.63 35.6710663695424 139.73789965743384 42.53 35.67117684798835 139.7378619682755 42.53 35.67117684798835 139.7378619682755 13.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d490819-6073-4e2d-90c8-5955a546208c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d490819-6073-4e2d-90c8-5955a546208c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d490819-6073-4e2d-90c8-5955a546208c">
											<gml:posList>35.67108970279164 139.73789549832256 42.53 35.67108970279164 139.73789549832256 42.208 35.67116873181939 139.73786852843622 42.208 35.67116873181939 139.73786852843622 42.53 35.67108970279164 139.73789549832256 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8aed9631-5526-405c-91b2-6c3d0887c24b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8aed9631-5526-405c-91b2-6c3d0887c24b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8aed9631-5526-405c-91b2-6c3d0887c24b">
											<gml:posList>35.67116873181939 139.73786852843622 42.53 35.67116873181939 139.73786852843622 42.208 35.67117564243462 139.7378989640001 42.208 35.67117564243462 139.7378989640001 42.53 35.67116873181939 139.73786852843622 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9326cc75-c3cf-4666-8b5d-36d2f49ca25f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9326cc75-c3cf-4666-8b5d-36d2f49ca25f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9326cc75-c3cf-4666-8b5d-36d2f49ca25f">
											<gml:posList>35.6710663695424 139.73789965743384 13.63 35.67108735435552 139.7379917590696 13.63 35.67108735435552 139.7379917590696 42.53 35.6710663695424 139.73789965743384 42.53 35.6710663695424 139.73789965743384 13.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ed26e50a-4b72-42a8-99b0-2a1eac1ea747">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed26e50a-4b72-42a8-99b0-2a1eac1ea747">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed26e50a-4b72-42a8-99b0-2a1eac1ea747">
											<gml:posList>35.67108595004616 139.7379485473932 42.53 35.67108595004616 139.7379485473932 42.208 35.67107834297097 139.73791506389384 42.208 35.67107834297097 139.73791506389384 42.53 35.67108595004616 139.7379485473932 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24744c19-7a93-448e-9439-0baba8fbeed0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24744c19-7a93-448e-9439-0baba8fbeed0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24744c19-7a93-448e-9439-0baba8fbeed0">
											<gml:posList>35.67107834297097 139.73791506389384 42.53 35.67107834297097 139.73791506389384 42.208 35.67109301336081 139.73791006452717 42.208 35.67109301336081 139.73791006452717 42.53 35.67107834297097 139.73791506389384 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b4a2f3d-1849-487a-acef-d9d3be01a3be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b4a2f3d-1849-487a-acef-d9d3be01a3be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b4a2f3d-1849-487a-acef-d9d3be01a3be">
											<gml:posList>35.67109301336081 139.73791006452717 42.53 35.67109301336081 139.73791006452717 42.208 35.67108970279164 139.73789549832256 42.208 35.67108970279164 139.73789549832256 42.53 35.67109301336081 139.73791006452717 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db395a51-c4e9-49a2-872c-16897e413013">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db395a51-c4e9-49a2-872c-16897e413013">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db395a51-c4e9-49a2-872c-16897e413013">
											<gml:posList>35.67110150353701 139.73794323768342 42.53 35.67110150353701 139.73794323768342 42.208 35.67108595004616 139.7379485473932 42.208 35.67108595004616 139.7379485473932 42.53 35.67110150353701 139.73794323768342 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56f4a66e-d936-4192-8ee7-c5081018df30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56f4a66e-d936-4192-8ee7-c5081018df30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56f4a66e-d936-4192-8ee7-c5081018df30">
											<gml:posList>35.67110930055731 139.73797756049257 42.53 35.67110930055731 139.73797756049257 42.208 35.67110150353701 139.73794323768342 42.208 35.67110150353701 139.73794323768342 42.53 35.67110930055731 139.73797756049257 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e991450-4c19-45be-8306-18ba77134031">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e991450-4c19-45be-8306-18ba77134031">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e991450-4c19-45be-8306-18ba77134031">
											<gml:posList>35.671116458936424 139.73793390780796 42.208 35.671116458936424 139.73793390780796 41.207 35.67111317402831 139.73791759624265 41.207 35.67111317402831 139.73791759624265 42.208 35.671116458936424 139.73793390780796 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3683e364-3c90-4d17-b4d5-8bc52bccd4fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3683e364-3c90-4d17-b4d5-8bc52bccd4fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3683e364-3c90-4d17-b4d5-8bc52bccd4fb">
											<gml:posList>35.67111317402831 139.73791759624265 42.208 35.67111317402831 139.73791759624265 41.207 35.6711480941084 139.7379073478434 41.207 35.6711480941084 139.7379073478434 42.208 35.67111317402831 139.73791759624265 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4adfd1f-40d1-4354-9112-c390e8efa575">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4adfd1f-40d1-4354-9112-c390e8efa575">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4adfd1f-40d1-4354-9112-c390e8efa575">
											<gml:posList>35.67115131576431 139.73792346065608 42.208 35.67115131576431 139.73792346065608 41.207 35.671116458936424 139.73793390780796 41.207 35.671116458936424 139.73793390780796 42.208 35.67115131576431 139.73792346065608 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e751e5e4-a680-47be-ab90-7b72ea7eb78d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e751e5e4-a680-47be-ab90-7b72ea7eb78d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e751e5e4-a680-47be-ab90-7b72ea7eb78d">
											<gml:posList>35.67108735435552 139.7379917590696 13.63 35.671197742692875 139.7379540701354 13.63 35.671197742692875 139.7379540701354 42.53 35.67108735435552 139.7379917590696 42.53 35.67108735435552 139.7379917590696 13.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d95779fb-6114-4adf-b230-fb4b8796ce70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d95779fb-6114-4adf-b230-fb4b8796ce70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d95779fb-6114-4adf-b230-fb4b8796ce70">
											<gml:posList>35.671186132364205 139.7379532554697 42.53 35.671186132364205 139.7379532554697 42.208 35.67110930055731 139.73797756049257 42.208 35.67110930055731 139.73797756049257 42.53 35.671186132364205 139.7379532554697 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7db2beb-de53-4267-83c4-446db6decfa1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7db2beb-de53-4267-83c4-446db6decfa1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7db2beb-de53-4267-83c4-446db6decfa1">
											<gml:posList>35.6711480941084 139.7379073478434 42.208 35.6711480941084 139.7379073478434 41.207 35.67115131576431 139.73792346065608 41.207 35.67115131576431 139.73792346065608 42.208 35.6711480941084 139.7379073478434 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca266898-5879-4397-8c49-0635cf40574a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca266898-5879-4397-8c49-0635cf40574a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca266898-5879-4397-8c49-0635cf40574a">
											<gml:posList>35.67115434366555 139.7379225622972 42.208 35.67115434366555 139.7379225622972 41.207 35.671151131023244 139.7379064494732 41.207 35.671151131023244 139.7379064494732 42.208 35.67115434366555 139.7379225622972 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1e5e712-b83e-45dc-ad3d-6333c071dda8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1e5e712-b83e-45dc-ad3d-6333c071dda8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1e5e712-b83e-45dc-ad3d-6333c071dda8">
											<gml:posList>35.671151131023244 139.7379064494732 42.208 35.671151131023244 139.7379064494732 41.207 35.67116790167078 139.73790152492504 41.207 35.67116790167078 139.73790152492504 42.208 35.671151131023244 139.7379064494732 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5dda189c-a23d-4b94-833a-5f6a084654b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dda189c-a23d-4b94-833a-5f6a084654b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dda189c-a23d-4b94-833a-5f6a084654b2">
											<gml:posList>35.67117109620752 139.73791753835644 42.208 35.67117109620752 139.73791753835644 41.207 35.67115434366555 139.7379225622972 41.207 35.67115434366555 139.7379225622972 42.208 35.67117109620752 139.73791753835644 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6efa4fd6-2664-4d22-a9be-2233acd40b8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6efa4fd6-2664-4d22-a9be-2233acd40b8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6efa4fd6-2664-4d22-a9be-2233acd40b8e">
											<gml:posList>35.67116790167078 139.73790152492504 42.208 35.67116790167078 139.73790152492504 41.207 35.67117109620752 139.73791753835644 41.207 35.67117109620752 139.73791753835644 42.208 35.67116790167078 139.73790152492504 42.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab1e71c4-40bc-484a-81dc-4b921670f138">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab1e71c4-40bc-484a-81dc-4b921670f138">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab1e71c4-40bc-484a-81dc-4b921670f138">
											<gml:posList>35.671170686271424 139.7379007152257 42.53 35.671170686271424 139.7379007152257 42.208 35.671174042993975 139.73791665113998 42.208 35.671174042993975 139.73791665113998 42.53 35.671170686271424 139.7379007152257 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b55d540-c4aa-44b7-a5c8-c517451a5051">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b55d540-c4aa-44b7-a5c8-c517451a5051">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b55d540-c4aa-44b7-a5c8-c517451a5051">
											<gml:posList>35.671174042993975 139.73791665113998 42.53 35.671174042993975 139.73791665113998 42.208 35.6711781160316 139.73791517712556 42.208 35.6711781160316 139.73791517712556 42.53 35.671174042993975 139.73791665113998 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0eb6199d-5c57-4362-add8-5534ebb809ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0eb6199d-5c57-4362-add8-5534ebb809ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0eb6199d-5c57-4362-add8-5534ebb809ee">
											<gml:posList>35.6711781160316 139.73791517712556 42.53 35.6711781160316 139.73791517712556 42.208 35.671186132364205 139.7379532554697 42.208 35.671186132364205 139.7379532554697 42.53 35.6711781160316 139.73791517712556 42.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d79075dc-a49c-4a98-bbf8-0a7cac5cf6fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d79075dc-a49c-4a98-bbf8-0a7cac5cf6fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d79075dc-a49c-4a98-bbf8-0a7cac5cf6fd">
											<gml:posList>35.671197742692875 139.7379540701354 13.63 35.67117684798835 139.7378619682755 13.63 35.67117684798835 139.7378619682755 42.53 35.671197742692875 139.7379540701354 42.53 35.671197742692875 139.7379540701354 13.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8871</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">110.0777</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>