<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2afc9a76-5a14-45c9-9f0e-00da2a32963b">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67100145523551 139.73841608504335 0 35.6709866941124 139.7384203553605 0 35.67099153623317 139.7384454469207 0 35.67100628833473 139.73844116557225 0 35.67100145523551 139.73841608504335 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67100145523551 139.73841608504335 17.72 35.67100628833473 139.73844116557225 17.72 35.67099153623317 139.7384454469207 17.72 35.6709866941124 139.7384203553605 17.72 35.67100145523551 139.73841608504335 17.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67100145523551 139.73841608504335 17.72 35.6709866941124 139.7384203553605 17.72 35.6709866941124 139.7384203553605 20.72 35.67100145523551 139.73841608504335 20.72 35.67100145523551 139.73841608504335 17.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6709866941124 139.7384203553605 17.72 35.67099153623317 139.7384454469207 17.72 35.67099153623317 139.7384454469207 20.72 35.6709866941124 139.7384203553605 20.72 35.6709866941124 139.7384203553605 17.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67099153623317 139.7384454469207 17.72 35.67100628833473 139.73844116557225 17.72 35.67100628833473 139.73844116557225 20.72 35.67099153623317 139.7384454469207 20.72 35.67099153623317 139.7384454469207 17.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67100628833473 139.73844116557225 17.72 35.67100145523551 139.73841608504335 17.72 35.67100145523551 139.73841608504335 20.72 35.67100628833473 139.73844116557225 20.72 35.67100628833473 139.73844116557225 17.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67100145523551 139.73841608504335 20.72 35.6709866941124 139.7384203553605 20.72 35.67099153623317 139.7384454469207 20.72 35.67100628833473 139.73844116557225 20.72 35.67100145523551 139.73841608504335 20.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9958118f-9dc0-4408-b68a-f1a5f7001782"/>
							<gml:surfaceMember xlink:href="#poly-b01538ec-aca9-4b88-9aba-85ba58278e19"/>
							<gml:surfaceMember xlink:href="#poly-1b6ecf8b-3b9f-485d-82de-48aa9525aabc"/>
							<gml:surfaceMember xlink:href="#poly-c125104d-ae43-4405-94ee-eddf8f98c6d2"/>
							<gml:surfaceMember xlink:href="#poly-513c6a53-1b65-49f7-b91b-9eff99d2a0a8"/>
							<gml:surfaceMember xlink:href="#poly-9d95bc85-b460-43ee-a821-41143b2a4eac"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9958118f-9dc0-4408-b68a-f1a5f7001782">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9958118f-9dc0-4408-b68a-f1a5f7001782">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9958118f-9dc0-4408-b68a-f1a5f7001782">
											<gml:posList>35.6710014552355 139.73841608504335 17.72 35.671006288334716 139.73844116557223 17.72 35.67099153623315 139.7384454469207 17.72 35.6709866941124 139.7384203553605 17.72 35.6710014552355 139.73841608504335 17.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b01538ec-aca9-4b88-9aba-85ba58278e19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b01538ec-aca9-4b88-9aba-85ba58278e19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b01538ec-aca9-4b88-9aba-85ba58278e19">
											<gml:posList>35.671006288334716 139.73844116557223 20.895 35.6710014552355 139.73841608504335 20.895 35.6709866941124 139.7384203553605 20.895 35.67099153623315 139.7384454469207 20.895 35.671006288334716 139.73844116557223 20.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b6ecf8b-3b9f-485d-82de-48aa9525aabc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b6ecf8b-3b9f-485d-82de-48aa9525aabc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b6ecf8b-3b9f-485d-82de-48aa9525aabc">
											<gml:posList>35.6710014552355 139.73841608504335 17.72 35.6709866941124 139.7384203553605 17.72 35.6709866941124 139.7384203553605 20.895 35.6710014552355 139.73841608504335 20.895 35.6710014552355 139.73841608504335 17.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c125104d-ae43-4405-94ee-eddf8f98c6d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c125104d-ae43-4405-94ee-eddf8f98c6d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c125104d-ae43-4405-94ee-eddf8f98c6d2">
											<gml:posList>35.671006288334716 139.73844116557223 17.72 35.6710014552355 139.73841608504335 17.72 35.6710014552355 139.73841608504335 20.895 35.671006288334716 139.73844116557223 20.895 35.671006288334716 139.73844116557223 17.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-513c6a53-1b65-49f7-b91b-9eff99d2a0a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-513c6a53-1b65-49f7-b91b-9eff99d2a0a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-513c6a53-1b65-49f7-b91b-9eff99d2a0a8">
											<gml:posList>35.6709866941124 139.7384203553605 17.72 35.67099153623315 139.7384454469207 17.72 35.67099153623315 139.7384454469207 20.895 35.6709866941124 139.7384203553605 20.895 35.6709866941124 139.7384203553605 17.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d95bc85-b460-43ee-a821-41143b2a4eac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d95bc85-b460-43ee-a821-41143b2a4eac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d95bc85-b460-43ee-a821-41143b2a4eac">
											<gml:posList>35.67099153623315 139.7384454469207 17.72 35.671006288334716 139.73844116557223 17.72 35.671006288334716 139.73844116557223 20.895 35.67099153623315 139.7384454469207 20.895 35.67099153623315 139.7384454469207 17.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10502</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>