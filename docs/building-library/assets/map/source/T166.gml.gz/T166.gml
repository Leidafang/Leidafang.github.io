<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2b4e114f-4d50-47e2-8132-769e6a2aca4b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">13.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66906082443218 139.7396340694883 0 35.66903635547727 139.73969628748034 0 35.66910462080279 139.73973663642516 0 35.669129089778174 139.73967441839235 0 35.66906082443218 139.7396340694883 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66906082443218 139.7396340694883 11.287 35.669129089778174 139.73967441839235 11.287 35.66910462080279 139.73973663642516 11.287 35.66903635547727 139.73969628748034 11.287 35.66906082443218 139.7396340694883 11.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66906082443218 139.7396340694883 11.287 35.66903635547727 139.73969628748034 11.287 35.66903635547727 139.73969628748034 24.36 35.66906082443218 139.7396340694883 24.36 35.66906082443218 139.7396340694883 11.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903635547727 139.73969628748034 11.287 35.66910462080279 139.73973663642516 11.287 35.66910462080279 139.73973663642516 24.36 35.66903635547727 139.73969628748034 24.36 35.66903635547727 139.73969628748034 11.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910462080279 139.73973663642516 11.287 35.669129089778174 139.73967441839235 11.287 35.669129089778174 139.73967441839235 24.36 35.66910462080279 139.73973663642516 24.36 35.66910462080279 139.73973663642516 11.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669129089778174 139.73967441839235 11.287 35.66906082443218 139.7396340694883 11.287 35.66906082443218 139.7396340694883 24.36 35.669129089778174 139.73967441839235 24.36 35.669129089778174 139.73967441839235 11.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66906082443218 139.7396340694883 24.36 35.66903635547727 139.73969628748034 24.36 35.66910462080279 139.73973663642516 24.36 35.669129089778174 139.73967441839235 24.36 35.66906082443218 139.7396340694883 24.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-574d0dc8-b8b0-4a35-8c17-486c55eeadca"/>
							<gml:surfaceMember xlink:href="#poly-c932f2a3-6e4c-4b13-8838-21d73e9eac0c"/>
							<gml:surfaceMember xlink:href="#poly-6a6caaf1-82ab-44e3-91b4-aee5be73005e"/>
							<gml:surfaceMember xlink:href="#poly-0393336b-14eb-4b0d-ad77-1136ae1a02b9"/>
							<gml:surfaceMember xlink:href="#poly-677b0b71-b541-4028-a413-8a9c20142dd3"/>
							<gml:surfaceMember xlink:href="#poly-037197b4-ffd3-4afb-904d-7e52b588e1d3"/>
							<gml:surfaceMember xlink:href="#poly-a64ca6fa-dbfb-4e80-a1f3-e1d011daf3d6"/>
							<gml:surfaceMember xlink:href="#poly-650bde17-12d9-4944-9f59-b6af6e45eeda"/>
							<gml:surfaceMember xlink:href="#poly-889a7c53-2698-40d6-91d6-3fc169bcaa6d"/>
							<gml:surfaceMember xlink:href="#poly-5cc5efbb-9e4e-4cf3-9936-c4fedd1a4f82"/>
							<gml:surfaceMember xlink:href="#poly-9d34b12d-5b9a-4aa1-8278-f688a47ca676"/>
							<gml:surfaceMember xlink:href="#poly-58d62b16-e440-467e-b6bc-6a1ef8338682"/>
							<gml:surfaceMember xlink:href="#poly-cfd03c21-a280-4e9e-a5a3-d93f9c7ccc63"/>
							<gml:surfaceMember xlink:href="#poly-904c6c8e-45d0-4403-b89b-e961c794b625"/>
							<gml:surfaceMember xlink:href="#poly-46ffa3b9-aadf-48f2-ab31-725988d4fbc3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-574d0dc8-b8b0-4a35-8c17-486c55eeadca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-574d0dc8-b8b0-4a35-8c17-486c55eeadca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-574d0dc8-b8b0-4a35-8c17-486c55eeadca">
											<gml:posList>35.66906082443215 139.73963406948826 11.287 35.66912908977819 139.73967441839233 11.287 35.66910462080278 139.73973663642514 11.287 35.66903635547724 139.73969628748034 11.287 35.66906082443215 139.73963406948826 11.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c932f2a3-6e4c-4b13-8838-21d73e9eac0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c932f2a3-6e4c-4b13-8838-21d73e9eac0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c932f2a3-6e4c-4b13-8838-21d73e9eac0c">
											<gml:posList>35.66906082443215 139.73963406948826 25.116 35.66906190899285 139.73963781284124 25.116 35.669110677695635 139.73966665240974 25.116 35.66911373232571 139.73966533435728 25.116 35.66906082443215 139.73963406948826 25.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a6caaf1-82ab-44e3-91b4-aee5be73005e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a6caaf1-82ab-44e3-91b4-aee5be73005e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a6caaf1-82ab-44e3-91b4-aee5be73005e">
											<gml:posList>35.66903635547724 139.73969628748034 25.116 35.66903941012486 139.73969499152236 25.116 35.66906190899285 139.73963781284124 25.116 35.66906082443215 139.73963406948826 25.116 35.66903635547724 139.73969628748034 25.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0393336b-14eb-4b0d-ad77-1136ae1a02b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0393336b-14eb-4b0d-ad77-1136ae1a02b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0393336b-14eb-4b0d-ad77-1136ae1a02b9">
											<gml:posList>35.669110677695635 139.73966665240974 24.604 35.66906190899285 139.73963781284124 24.604 35.66903941012486 139.73969499152236 24.604 35.66908816978327 139.739723809036 24.604 35.669110677695635 139.73966665240974 24.604</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-677b0b71-b541-4028-a413-8a9c20142dd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-677b0b71-b541-4028-a413-8a9c20142dd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-677b0b71-b541-4028-a413-8a9c20142dd3">
											<gml:posList>35.66911373232571 139.73966533435728 25.116 35.669110677695635 139.73966665240974 25.116 35.66908816978327 139.739723809036 25.116 35.66908924531886 139.73972754135588 25.116 35.66911373232571 139.73966533435728 25.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-037197b4-ffd3-4afb-904d-7e52b588e1d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-037197b4-ffd3-4afb-904d-7e52b588e1d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-037197b4-ffd3-4afb-904d-7e52b588e1d3">
											<gml:posList>35.66908924531886 139.73972754135588 25.116 35.66910462080278 139.73973663642514 21.718 35.66912908977819 139.73967441839233 21.718 35.66911373232571 139.73966533435728 25.116 35.66908924531886 139.73972754135588 25.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a64ca6fa-dbfb-4e80-a1f3-e1d011daf3d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a64ca6fa-dbfb-4e80-a1f3-e1d011daf3d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a64ca6fa-dbfb-4e80-a1f3-e1d011daf3d6">
											<gml:posList>35.66908924531886 139.73972754135588 25.116 35.66908816978327 139.739723809036 25.116 35.66903941012486 139.73969499152236 25.116 35.66903635547724 139.73969628748034 25.116 35.66908924531886 139.73972754135588 25.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-650bde17-12d9-4944-9f59-b6af6e45eeda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-650bde17-12d9-4944-9f59-b6af6e45eeda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-650bde17-12d9-4944-9f59-b6af6e45eeda">
											<gml:posList>35.66906190899285 139.73963781284124 25.116 35.66906190899285 139.73963781284124 24.604 35.669110677695635 139.73966665240974 24.604 35.669110677695635 139.73966665240974 25.116 35.66906190899285 139.73963781284124 25.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-889a7c53-2698-40d6-91d6-3fc169bcaa6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-889a7c53-2698-40d6-91d6-3fc169bcaa6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-889a7c53-2698-40d6-91d6-3fc169bcaa6d">
											<gml:posList>35.66906082443215 139.73963406948826 25.116 35.66911373232571 139.73966533435728 25.116 35.66912908977819 139.73967441839233 21.718 35.66912908977819 139.73967441839233 11.287 35.66906082443215 139.73963406948826 11.287 35.66906082443215 139.73963406948826 25.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cc5efbb-9e4e-4cf3-9936-c4fedd1a4f82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cc5efbb-9e4e-4cf3-9936-c4fedd1a4f82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cc5efbb-9e4e-4cf3-9936-c4fedd1a4f82">
											<gml:posList>35.66906082443215 139.73963406948826 11.287 35.66903635547724 139.73969628748034 11.287 35.66903635547724 139.73969628748034 25.116 35.66906082443215 139.73963406948826 25.116 35.66906082443215 139.73963406948826 11.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d34b12d-5b9a-4aa1-8278-f688a47ca676">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d34b12d-5b9a-4aa1-8278-f688a47ca676">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d34b12d-5b9a-4aa1-8278-f688a47ca676">
											<gml:posList>35.66903941012486 139.73969499152236 25.116 35.66903941012486 139.73969499152236 24.604 35.66906190899285 139.73963781284124 24.604 35.66906190899285 139.73963781284124 25.116 35.66903941012486 139.73969499152236 25.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58d62b16-e440-467e-b6bc-6a1ef8338682">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58d62b16-e440-467e-b6bc-6a1ef8338682">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58d62b16-e440-467e-b6bc-6a1ef8338682">
											<gml:posList>35.669110677695635 139.73966665240974 25.116 35.669110677695635 139.73966665240974 24.604 35.66908816978327 139.739723809036 24.604 35.66908816978327 139.739723809036 25.116 35.669110677695635 139.73966665240974 25.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfd03c21-a280-4e9e-a5a3-d93f9c7ccc63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfd03c21-a280-4e9e-a5a3-d93f9c7ccc63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfd03c21-a280-4e9e-a5a3-d93f9c7ccc63">
											<gml:posList>35.66910462080278 139.73973663642514 11.287 35.66912908977819 139.73967441839233 11.287 35.66912908977819 139.73967441839233 21.718 35.66910462080278 139.73973663642514 21.718 35.66910462080278 139.73973663642514 11.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-904c6c8e-45d0-4403-b89b-e961c794b625">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-904c6c8e-45d0-4403-b89b-e961c794b625">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-904c6c8e-45d0-4403-b89b-e961c794b625">
											<gml:posList>35.66908816978327 139.739723809036 25.116 35.66908816978327 139.739723809036 24.604 35.66903941012486 139.73969499152236 24.604 35.66903941012486 139.73969499152236 25.116 35.66908816978327 139.739723809036 25.116</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46ffa3b9-aadf-48f2-ab31-725988d4fbc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46ffa3b9-aadf-48f2-ab31-725988d4fbc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46ffa3b9-aadf-48f2-ab31-725988d4fbc3">
											<gml:posList>35.66910462080278 139.73973663642514 21.718 35.66908924531886 139.73972754135588 25.116 35.66903635547724 139.73969628748034 25.116 35.66903635547724 139.73969628748034 11.287 35.66910462080278 139.73973663642514 11.287 35.66910462080278 139.73973663642514 21.718</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-338</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">52.5743</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">2</uro:rank>
					<uro:depth uom="m">0.85</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>