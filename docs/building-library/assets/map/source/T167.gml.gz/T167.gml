<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2bec31e2-4ba9-4dc5-9a1e-1fd39114c427">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">21.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66693165380843 139.74264752786576 0 35.66694262917524 139.74261912778329 0 35.66676732552962 139.74251748417356 0 35.6667557204745 139.74254754178477 0 35.66674021011551 139.74253861228078 0 35.666666531191495 139.74272923485915 0 35.66674723937647 139.7427760881443 0 35.66674157177435 139.74279078540346 0 35.666786209329146 139.74281680300646 0 35.666791337190276 139.74280354229978 0 35.66686627398563 139.74284697805433 0 35.66694121260284 139.74265315040634 0 35.66693165380843 139.74264752786576 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693165380843 139.74264752786576 26.07 35.66694121260284 139.74265315040634 26.07 35.66686627398563 139.74284697805433 26.07 35.666791337190276 139.74280354229978 26.07 35.666786209329146 139.74281680300646 26.07 35.66674157177435 139.74279078540346 26.07 35.66674723937647 139.7427760881443 26.07 35.666666531191495 139.74272923485915 26.07 35.66674021011551 139.74253861228078 26.07 35.6667557204745 139.74254754178477 26.07 35.66676732552962 139.74251748417356 26.07 35.66694262917524 139.74261912778329 26.07 35.66693165380843 139.74264752786576 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693165380843 139.74264752786576 26.07 35.66694262917524 139.74261912778329 26.07 35.66694262917524 139.74261912778329 47.59 35.66693165380843 139.74264752786576 47.59 35.66693165380843 139.74264752786576 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66694262917524 139.74261912778329 26.07 35.66676732552962 139.74251748417356 26.07 35.66676732552962 139.74251748417356 47.59 35.66694262917524 139.74261912778329 47.59 35.66694262917524 139.74261912778329 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676732552962 139.74251748417356 26.07 35.6667557204745 139.74254754178477 26.07 35.6667557204745 139.74254754178477 47.59 35.66676732552962 139.74251748417356 47.59 35.66676732552962 139.74251748417356 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6667557204745 139.74254754178477 26.07 35.66674021011551 139.74253861228078 26.07 35.66674021011551 139.74253861228078 47.59 35.6667557204745 139.74254754178477 47.59 35.6667557204745 139.74254754178477 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674021011551 139.74253861228078 26.07 35.666666531191495 139.74272923485915 26.07 35.666666531191495 139.74272923485915 47.59 35.66674021011551 139.74253861228078 47.59 35.66674021011551 139.74253861228078 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666666531191495 139.74272923485915 26.07 35.66674723937647 139.7427760881443 26.07 35.66674723937647 139.7427760881443 47.59 35.666666531191495 139.74272923485915 47.59 35.666666531191495 139.74272923485915 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674723937647 139.7427760881443 26.07 35.66674157177435 139.74279078540346 26.07 35.66674157177435 139.74279078540346 47.59 35.66674723937647 139.7427760881443 47.59 35.66674723937647 139.7427760881443 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674157177435 139.74279078540346 26.07 35.666786209329146 139.74281680300646 26.07 35.666786209329146 139.74281680300646 47.59 35.66674157177435 139.74279078540346 47.59 35.66674157177435 139.74279078540346 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666786209329146 139.74281680300646 26.07 35.666791337190276 139.74280354229978 26.07 35.666791337190276 139.74280354229978 47.59 35.666786209329146 139.74281680300646 47.59 35.666786209329146 139.74281680300646 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666791337190276 139.74280354229978 26.07 35.66686627398563 139.74284697805433 26.07 35.66686627398563 139.74284697805433 47.59 35.666791337190276 139.74280354229978 47.59 35.666791337190276 139.74280354229978 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66686627398563 139.74284697805433 26.07 35.66694121260284 139.74265315040634 26.07 35.66694121260284 139.74265315040634 47.59 35.66686627398563 139.74284697805433 47.59 35.66686627398563 139.74284697805433 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66694121260284 139.74265315040634 26.07 35.66693165380843 139.74264752786576 26.07 35.66693165380843 139.74264752786576 47.59 35.66694121260284 139.74265315040634 47.59 35.66694121260284 139.74265315040634 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693165380843 139.74264752786576 47.59 35.66694262917524 139.74261912778329 47.59 35.66676732552962 139.74251748417356 47.59 35.6667557204745 139.74254754178477 47.59 35.66674021011551 139.74253861228078 47.59 35.666666531191495 139.74272923485915 47.59 35.66674723937647 139.7427760881443 47.59 35.66674157177435 139.74279078540346 47.59 35.666786209329146 139.74281680300646 47.59 35.666791337190276 139.74280354229978 47.59 35.66686627398563 139.74284697805433 47.59 35.66694121260284 139.74265315040634 47.59 35.66693165380843 139.74264752786576 47.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-df1c5c85-8f86-4fe0-86cf-a25be1666fc0"/>
							<gml:surfaceMember xlink:href="#poly-7290d719-fa61-4b8a-8a59-34f0b5b249ae"/>
							<gml:surfaceMember xlink:href="#poly-c66731d2-e789-4600-afcd-6bff09c7e87d"/>
							<gml:surfaceMember xlink:href="#poly-4a051e8b-cdf9-49b7-a9b5-dd589aaad4f8"/>
							<gml:surfaceMember xlink:href="#poly-11989e3b-1f58-4f9b-ad56-0931c37f387d"/>
							<gml:surfaceMember xlink:href="#poly-0539898b-79c5-4990-896e-5b563fa6388c"/>
							<gml:surfaceMember xlink:href="#poly-48c6e7cd-7f3b-4a71-afd0-e640c2f7de8c"/>
							<gml:surfaceMember xlink:href="#poly-7a4825fe-3210-4ff4-a079-c354faab332e"/>
							<gml:surfaceMember xlink:href="#poly-641f67d2-1b93-440d-8daf-990d936b75ba"/>
							<gml:surfaceMember xlink:href="#poly-6498bd6a-f9f5-4ea5-a8c8-d280dd508e7e"/>
							<gml:surfaceMember xlink:href="#poly-bc1f77ed-419f-4631-9abe-6b363ab21fc2"/>
							<gml:surfaceMember xlink:href="#poly-a44b845c-71bb-470b-bf0d-a4163980d087"/>
							<gml:surfaceMember xlink:href="#poly-10f89bce-0268-45bd-a2ee-bf49f9ef7bc5"/>
							<gml:surfaceMember xlink:href="#poly-42607ca3-5cb2-413b-84ba-2b6398e6c34c"/>
							<gml:surfaceMember xlink:href="#poly-a4e12841-3497-45c7-b965-43d5177baf5b"/>
							<gml:surfaceMember xlink:href="#poly-424a19d5-9823-4431-9e4d-1f8e082bd260"/>
							<gml:surfaceMember xlink:href="#poly-b6ec0cc3-58c9-4d72-ac1d-d4b4ac99e95d"/>
							<gml:surfaceMember xlink:href="#poly-95a3c790-b56d-4630-a5b1-f6467cbd6569"/>
							<gml:surfaceMember xlink:href="#poly-12e3b998-ebe0-48da-9e6f-f6cce4168972"/>
							<gml:surfaceMember xlink:href="#poly-91679374-fd62-4bc5-bf45-e0d76c4def7b"/>
							<gml:surfaceMember xlink:href="#poly-d85ca252-af02-44c7-877b-4ead95a9974a"/>
							<gml:surfaceMember xlink:href="#poly-bedfb4a8-479c-435e-9b07-cf7b90639899"/>
							<gml:surfaceMember xlink:href="#poly-28b60c89-7f33-4ffc-a740-cb030846794c"/>
							<gml:surfaceMember xlink:href="#poly-78b36f89-ad9d-4026-8009-6f95ede37e69"/>
							<gml:surfaceMember xlink:href="#poly-0189791b-e932-4b65-b57c-39d41a16ccba"/>
							<gml:surfaceMember xlink:href="#poly-29219be7-8621-467d-b582-de2e1285c3f3"/>
							<gml:surfaceMember xlink:href="#poly-a086dcc6-abb4-48f3-9ce2-7824ccad1e6d"/>
							<gml:surfaceMember xlink:href="#poly-f9ce99f1-5c33-4661-9528-1bc456a670aa"/>
							<gml:surfaceMember xlink:href="#poly-10a35aec-7169-4c52-8577-9e6b1493e3a2"/>
							<gml:surfaceMember xlink:href="#poly-f74a54fc-14c4-497b-bfe9-80b1c3d7f924"/>
							<gml:surfaceMember xlink:href="#poly-d43bf1de-2f24-42a6-bcce-e5be52973dc3"/>
							<gml:surfaceMember xlink:href="#poly-48f05352-164a-4e3e-86b4-8eddefadf547"/>
							<gml:surfaceMember xlink:href="#poly-41d2ed9b-eced-4304-b5d3-09ea11e99fda"/>
							<gml:surfaceMember xlink:href="#poly-3540e4e0-3b81-4302-b2b2-2c443f556fd2"/>
							<gml:surfaceMember xlink:href="#poly-3c96d042-9b8e-4d3b-a835-af48988d45a1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2bec31e2-4ba9-4dc5-9a1e-1fd39114c427_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96e3a007-46aa-475e-afc1-b45359b7f95a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96e3a007-46aa-475e-afc1-b45359b7f95a_0">
											<gml:posList>35.666670415136224 139.74272793811812 45.734 35.666670415136224 139.74272793811812 46.5 35.66666983035752 139.74272941890916 48.366 35.666670415136224 139.74272793811812 45.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-baf3e282-f322-49b4-b663-551b16d6d057">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-baf3e282-f322-49b4-b663-551b16d6d057_0">
											<gml:posList>35.66666983035752 139.74272941890916 48.366 35.666670415136224 139.74272793811812 46.5 35.66666983035752 139.74272941890916 46.5 35.66666983035752 139.74272941890916 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a52a6b77-6d19-4a9c-a3b4-f57591197ac3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a52a6b77-6d19-4a9c-a3b4-f57591197ac3_0">
											<gml:posList>35.66686032869255 139.74284000383346 46.5 35.66686032869255 139.74284000383346 45.73 35.66685986087515 139.7428411973051 48.366 35.66686032869255 139.74284000383346 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-332623f9-552f-4f72-9636-9d90739a76c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-332623f9-552f-4f72-9636-9d90739a76c9_0">
											<gml:posList>35.66666983035752 139.74272941890916 48.366 35.66668947096818 139.7427409726648 48.366 35.66670044678986 139.7427131470595 49.495 35.66666983035752 139.74272941890916 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d9ee9c8-895e-4431-a7f0-c48306fdd1f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d9ee9c8-895e-4431-a7f0-c48306fdd1f1_0">
											<gml:posList>35.66668069807003 139.74270167075156 48.366 35.66666983035752 139.74272941890916 48.366 35.66670044678986 139.7427131470595 49.495 35.66668069807003 139.74270167075156 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81735517-08c1-478d-80ce-066cb8e4833d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81735517-08c1-478d-80ce-066cb8e4833d_0">
											<gml:posList>35.6667619472752 139.7425572550049 48.366 35.66674189183247 139.74254545874686 48.366 35.66675287874578 139.74258022940575 49.495 35.6667619472752 139.7425572550049 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7ba4bee-01cd-4f71-a070-702ea3b13b4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7ba4bee-01cd-4f71-a070-702ea3b13b4f_0">
											<gml:posList>35.66678561882873 139.74257117900834 48.366 35.6667619472752 139.7425572550049 48.366 35.66675287874578 139.74258022940575 49.495 35.66678561882873 139.74257117900834 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfe64ac8-c3a8-4b47-a613-37613b29f882">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfe64ac8-c3a8-4b47-a613-37613b29f882_0">
											<gml:posList>35.66677488976423 139.742663290724 48.366 35.66678817268344 139.74267084205368 48.366 35.666794856193796 139.74265265316677 49.623 35.66677488976423 139.742663290724 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02de245a-22af-4e90-94d7-bc054e0b0d64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02de245a-22af-4e90-94d7-bc054e0b0d64_0">
											<gml:posList>35.666794856193796 139.74265265316677 49.623 35.66680167463276 139.74263409961387 51.065 35.66680990534499 139.74261172262445 49.623 35.666794856193796 139.74265265316677 49.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30ae185e-8e6c-4d45-aeb1-3e45a6832fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30ae185e-8e6c-4d45-aeb1-3e45a6832fd5_0">
											<gml:posList>35.66680990534499 139.74261172262445 49.623 35.66681563535544 139.742596141608 48.366 35.666803019730544 139.74258896508906 48.366 35.66680990534499 139.74261172262445 49.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f545640-6b78-4ae7-877a-09383063de4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f545640-6b78-4ae7-877a-09383063de4d_0">
											<gml:posList>35.66682344049346 139.7426908833884 48.366 35.66683656108892 139.74269833549877 48.366 35.66683021457652 139.7426732687728 49.623 35.66682344049346 139.7426908833884 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eaad0725-97e3-4b63-9d7b-6ce48bf48d5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eaad0725-97e3-4b63-9d7b-6ce48bf48d5a_0">
											<gml:posList>35.66684603879879 139.74263218269877 49.623 35.66683797825402 139.7426531125077 51.065 35.66683021457652 139.7426732687728 49.623 35.66684603879879 139.74263218269877 49.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd5f0daf-03f4-4f76-975f-bb37e2c781cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd5f0daf-03f4-4f76-975f-bb37e2c781cf_0">
											<gml:posList>35.66683661318089 139.74282751573764 48.366 35.66685986087515 139.7428411973051 48.366 35.66684800303923 139.74279887223844 49.495 35.66683661318089 139.74282751573764 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2c54ae2-fca1-421f-84d6-874b2f736fd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2c54ae2-fca1-421f-84d6-874b2f736fd7_0">
											<gml:posList>35.666864691084825 139.7426240208646 48.366 35.66685196725534 139.74261678923042 48.366 35.66684603879879 139.74263218269877 49.623 35.666864691084825 139.7426240208646 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34216f4c-23ca-4692-8e9a-ebc81b2bd92f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34216f4c-23ca-4692-8e9a-ebc81b2bd92f_0">
											<gml:posList>35.66685986087515 139.7428411973051 48.366 35.66687116944707 139.74281233297575 48.366 35.66684800303923 139.74279887223844 49.495 35.66685986087515 139.7428411973051 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c24faf02-c10d-483d-a4f3-91f6f7d252d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c24faf02-c10d-483d-a4f3-91f6f7d252d1_0">
											<gml:posList>35.66686032869255 139.74284000383346 46.5 35.66685986087515 139.7428411973051 48.366 35.66685986087515 139.7428411973051 46.5 35.66686032869255 139.74284000383346 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb0e7dcc-405b-4aa5-9ffd-ec468901fa0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb0e7dcc-405b-4aa5-9ffd-ec468901fa0d_0">
											<gml:posList>35.66688795181272 139.74263104175859 48.366 35.66689912237721 139.7426703300089 49.495 35.66690966651306 139.7426438192574 48.366 35.66688795181272 139.74263104175859 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e8a939c-6950-4012-8fab-cc571225fae9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e8a939c-6950-4012-8fab-cc571225fae9_0">
											<gml:posList>35.66693203047489 139.74265696053985 48.366 35.66690966651306 139.7426438192574 48.366 35.66689912237721 139.7426703300089 49.495 35.66693203047489 139.74265696053985 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45b2c6d0-adec-46a4-8134-da50cafcf4e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45b2c6d0-adec-46a4-8134-da50cafcf4e5_0">
											<gml:posList>35.666767918405 139.74262241824133 45.73 35.66678455168961 139.74257847042065 48.366 35.66678455168961 139.74257847042065 45.73 35.666767918405 139.74262241824133 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5fa4830-adee-4d78-ad6f-8ffadd7b515d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5fa4830-adee-4d78-ad6f-8ffadd7b515d_0">
											<gml:posList>35.666767918405 139.74262241824133 45.73 35.666767918405 139.74262241824133 48.366 35.66678455168961 139.74257847042065 48.366 35.666767918405 139.74262241824133 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d30cb399-bc03-4aaf-a9b5-83b88d122ff3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d30cb399-bc03-4aaf-a9b5-83b88d122ff3_0">
											<gml:posList>35.666864691084825 139.7426240208646 45.73 35.66683656108892 139.74269833549877 48.366 35.66683656108892 139.74269833549877 45.73 35.666864691084825 139.7426240208646 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b63f8cf-654b-43c5-97f2-7334fdf02d3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b63f8cf-654b-43c5-97f2-7334fdf02d3c_0">
											<gml:posList>35.666864691084825 139.7426240208646 45.73 35.666864691084825 139.7426240208646 48.366 35.66683656108892 139.74269833549877 48.366 35.666864691084825 139.7426240208646 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0701bfc6-3844-4563-9f05-b44f26e6d72d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0701bfc6-3844-4563-9f05-b44f26e6d72d_0">
											<gml:posList>35.66674189183247 139.74254545874686 45.73 35.666670415136224 139.74272793811812 45.73 35.66668069807003 139.74270167075156 48.366 35.66674189183247 139.74254545874686 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78205a6c-b4ca-432c-9855-3abab238a5fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78205a6c-b4ca-432c-9855-3abab238a5fa_0">
											<gml:posList>35.66674189183247 139.74254545874686 45.73 35.66668069807003 139.74270167075156 48.366 35.66674189183247 139.74254545874686 48.366 35.66674189183247 139.74254545874686 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-884564c7-3df1-4774-acfa-2f35fe87096f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-884564c7-3df1-4774-acfa-2f35fe87096f_0">
											<gml:posList>35.666670415136224 139.74272793811812 45.73 35.66666983035752 139.74272941890916 48.366 35.66668069807003 139.74270167075156 48.366 35.666670415136224 139.74272793811812 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba4f3f5f-7337-4033-8fa1-71c7bc508250">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba4f3f5f-7337-4033-8fa1-71c7bc508250_0">
											<gml:posList>35.666670415136224 139.74272793811812 46.5 35.66674839097399 139.74277321494634 45.73 35.66674839097399 139.74277321494634 46.5 35.666670415136224 139.74272793811812 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5e7883e-4c80-44d5-be97-d6eabcb71305">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5e7883e-4c80-44d5-be97-d6eabcb71305_0">
											<gml:posList>35.666670415136224 139.74272793811812 46.5 35.666670415136224 139.74272793811812 45.73 35.66674839097399 139.74277321494634 45.73 35.666670415136224 139.74272793811812 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-002d9cd1-bdda-44d6-946f-e935e0702d42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-002d9cd1-bdda-44d6-946f-e935e0702d42_0">
											<gml:posList>35.66668069807003 139.74270167075156 48.366 35.66670044678986 139.7427131470595 49.495 35.66675287874578 139.74258022940575 49.495 35.66668069807003 139.74270167075156 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-accee5cc-1288-46ea-baa0-e7b1c720a7ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-accee5cc-1288-46ea-baa0-e7b1c720a7ec_0">
											<gml:posList>35.66674189183247 139.74254545874686 48.366 35.66668069807003 139.74270167075156 48.366 35.66675287874578 139.74258022940575 49.495 35.66674189183247 139.74254545874686 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64e0038c-c0f9-47c5-9939-0ab87d6bc269">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64e0038c-c0f9-47c5-9939-0ab87d6bc269_0">
											<gml:posList>35.66673505883737 139.74270023963723 48.366 35.66675287874578 139.74258022940575 49.495 35.66670044678986 139.7427131470595 49.495 35.66673505883737 139.74270023963723 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-331b4db2-f454-40d7-8638-40f0bdcff3f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-331b4db2-f454-40d7-8638-40f0bdcff3f1_0">
											<gml:posList>35.66673505883737 139.74270023963723 48.366 35.66678561882873 139.74257117900834 48.366 35.66675287874578 139.74258022940575 49.495 35.66673505883737 139.74270023963723 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6e8b541-8d35-43fb-8919-788f51c0d3ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6e8b541-8d35-43fb-8919-788f51c0d3ad_0">
											<gml:posList>35.66678561882873 139.74257117900834 45.73 35.66673505883737 139.74270023963723 48.366 35.66673505883737 139.74270023963723 45.73 35.66678561882873 139.74257117900834 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6440822e-fd53-4de2-ab0e-6eb6eae62915">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6440822e-fd53-4de2-ab0e-6eb6eae62915_0">
											<gml:posList>35.66678561882873 139.74257117900834 45.73 35.66678561882873 139.74257117900834 48.366 35.66673505883737 139.74270023963723 48.366 35.66678561882873 139.74257117900834 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7db61c7-8a51-48c5-a0bc-a772c026a482">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7db61c7-8a51-48c5-a0bc-a772c026a482_0">
											<gml:posList>35.66678561882873 139.74257117900834 48.366 35.66678561882873 139.74257117900834 45.73 35.6667619472752 139.7425572550049 48.366 35.66678561882873 139.74257117900834 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a45bc5e5-cc9f-4019-a141-5f3113e732fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a45bc5e5-cc9f-4019-a141-5f3113e732fa_0">
											<gml:posList>35.66678561882873 139.74257117900834 45.73 35.66674189183247 139.74254545874686 45.73 35.6667619472752 139.7425572550049 48.366 35.66678561882873 139.74257117900834 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-011c5d99-b8a0-4ba9-addc-dd4086ddc476">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-011c5d99-b8a0-4ba9-addc-dd4086ddc476_0">
											<gml:posList>35.66674189183247 139.74254545874686 45.73 35.66674189183247 139.74254545874686 48.366 35.6667619472752 139.7425572550049 48.366 35.66674189183247 139.74254545874686 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b693d3c8-8646-47df-b23c-c288da8775e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b693d3c8-8646-47df-b23c-c288da8775e6_0">
											<gml:posList>35.66683661318089 139.74282751573764 48.366 35.66685986087515 139.7428411973051 46.5 35.66685986087515 139.7428411973051 48.366 35.66683661318089 139.74282751573764 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83880ab0-1de3-4478-8f03-d197266fc374">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83880ab0-1de3-4478-8f03-d197266fc374_0">
											<gml:posList>35.66666983035752 139.74272941890916 46.5 35.66685986087515 139.7428411973051 46.5 35.66683661318089 139.74282751573764 48.366 35.66666983035752 139.74272941890916 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8811e89c-4e3a-4159-9fdf-3efd8f61bc96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8811e89c-4e3a-4159-9fdf-3efd8f61bc96_0">
											<gml:posList>35.66666983035752 139.74272941890916 48.366 35.66666983035752 139.74272941890916 46.5 35.66668947096818 139.7427409726648 48.366 35.66666983035752 139.74272941890916 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41d13876-0fca-435c-b407-91d3ef224c74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41d13876-0fca-435c-b407-91d3ef224c74_0">
											<gml:posList>35.66666983035752 139.74272941890916 46.5 35.66683661318089 139.74282751573764 48.366 35.66668947096818 139.7427409726648 48.366 35.66666983035752 139.74272941890916 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43da774c-b75f-4379-8780-dda9dbb6602d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43da774c-b75f-4379-8780-dda9dbb6602d_0">
											<gml:posList>35.66670044678986 139.7427131470595 49.495 35.66683661318089 139.74282751573764 48.366 35.66684800303923 139.74279887223844 49.495 35.66670044678986 139.7427131470595 49.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-826e3743-9b73-4f92-a7df-cd6ec367426b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-826e3743-9b73-4f92-a7df-cd6ec367426b_0">
											<gml:posList>35.66670044678986 139.7427131470595 49.495 35.66668947096818 139.7427409726648 48.366 35.66683661318089 139.74282751573764 48.366 35.66670044678986 139.7427131470595 49.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90188006-ed07-499d-ad5d-69c8f44c3b22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90188006-ed07-499d-ad5d-69c8f44c3b22_0">
											<gml:posList>35.66674839097399 139.74277321494634 46.5 35.66679245271689 139.74280064704985 45.73 35.66679245271689 139.74280064704985 46.5 35.66674839097399 139.74277321494634 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-645963ed-eb99-4b64-a235-2ea6c61d775e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-645963ed-eb99-4b64-a235-2ea6c61d775e_0">
											<gml:posList>35.66674839097399 139.74277321494634 46.5 35.66674839097399 139.74277321494634 45.73 35.66679245271689 139.74280064704985 45.73 35.66674839097399 139.74277321494634 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4513899b-db30-4d29-a998-d722b62a07fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4513899b-db30-4d29-a998-d722b62a07fb_0">
											<gml:posList>35.66673505883737 139.74270023963723 48.366 35.66670044678986 139.7427131470595 49.495 35.66684800303923 139.74279887223844 49.495 35.66673505883737 139.74270023963723 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff2db57f-c247-4e8e-8539-a209a94d3a5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff2db57f-c247-4e8e-8539-a209a94d3a5c_0">
											<gml:posList>35.66683729280662 139.742760367725 48.366 35.66673505883737 139.74270023963723 48.366 35.66684800303923 139.74279887223844 49.495 35.66683729280662 139.742760367725 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41ec8689-2b14-48ff-9ba8-68ebfe717395">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41ec8689-2b14-48ff-9ba8-68ebfe717395_0">
											<gml:posList>35.66678638644217 139.74263291291768 45.73 35.666767918405 139.74262241824133 48.366 35.666767918405 139.74262241824133 45.73 35.66678638644217 139.74263291291768 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b295c07-ffc6-4117-9111-714239ecbf7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b295c07-ffc6-4117-9111-714239ecbf7d_0">
											<gml:posList>35.66678638644217 139.74263291291768 45.73 35.66678638644217 139.74263291291768 48.366 35.666767918405 139.74262241824133 48.366 35.66678638644217 139.74263291291768 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc1e2b3f-5aea-4477-ba7d-efb4628bab2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc1e2b3f-5aea-4477-ba7d-efb4628bab2d_0">
											<gml:posList>35.66677488976423 139.742663290724 48.366 35.66678638644217 139.74263291291768 45.73 35.66677488976423 139.742663290724 45.73 35.66677488976423 139.742663290724 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-350956a9-0d55-44d4-8dcf-50b66e8d0e64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-350956a9-0d55-44d4-8dcf-50b66e8d0e64_0">
											<gml:posList>35.66677488976423 139.742663290724 48.366 35.66678638644217 139.74263291291768 48.366 35.66678638644217 139.74263291291768 45.73 35.66677488976423 139.742663290724 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0580aad-9ed2-4fd9-944a-2155ab5c8f3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0580aad-9ed2-4fd9-944a-2155ab5c8f3c_0">
											<gml:posList>35.66678638644217 139.74263291291768 48.366 35.66678455168961 139.74257847042065 48.366 35.666767918405 139.74262241824133 48.366 35.66678638644217 139.74263291291768 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c03829a-c651-4e75-84e0-c433aa66124b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c03829a-c651-4e75-84e0-c433aa66124b_0">
											<gml:posList>35.66678638644217 139.74263291291768 48.366 35.666803019730544 139.74258896508906 48.366 35.66678455168961 139.74257847042065 48.366 35.66678638644217 139.74263291291768 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6160397d-f450-4fde-b084-1529e65441ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6160397d-f450-4fde-b084-1529e65441ee_0">
											<gml:posList>35.66673505883737 139.74270023963723 48.366 35.66683729280662 139.742760367725 45.73 35.66673505883737 139.74270023963723 45.73 35.66673505883737 139.74270023963723 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0328b77-9363-4cdf-8534-05cc6e950bda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0328b77-9363-4cdf-8534-05cc6e950bda_0">
											<gml:posList>35.66673505883737 139.74270023963723 48.366 35.66683729280662 139.742760367725 48.366 35.66683729280662 139.742760367725 45.73 35.66673505883737 139.74270023963723 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db236c69-e025-4fe1-9fd6-6aa0eec1dac2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db236c69-e025-4fe1-9fd6-6aa0eec1dac2_0">
											<gml:posList>35.666803019730544 139.74258896508906 48.366 35.66678638644217 139.74263291291768 48.366 35.66680990534499 139.74261172262445 49.623 35.666803019730544 139.74258896508906 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fac9ece-c5f6-4542-b499-871c66e0a44a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fac9ece-c5f6-4542-b499-871c66e0a44a_0">
											<gml:posList>35.66680990534499 139.74261172262445 49.623 35.66678638644217 139.74263291291768 48.366 35.666794856193796 139.74265265316677 49.623 35.66680990534499 139.74261172262445 49.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2ffb4b9-0ff4-420b-b006-1f2fd5b56435">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2ffb4b9-0ff4-420b-b006-1f2fd5b56435_0">
											<gml:posList>35.66678638644217 139.74263291291768 48.366 35.66677488976423 139.742663290724 48.366 35.666794856193796 139.74265265316677 49.623 35.66678638644217 139.74263291291768 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a31fae5-3482-4ff8-b17e-137457bf3d74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a31fae5-3482-4ff8-b17e-137457bf3d74_0">
											<gml:posList>35.66677488976423 139.742663290724 48.366 35.66677488976423 139.742663290724 45.73 35.66678817268344 139.74267084205368 48.366 35.66677488976423 139.742663290724 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8133ffb0-f81b-4905-8c4f-bcf81d39405b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8133ffb0-f81b-4905-8c4f-bcf81d39405b_0">
											<gml:posList>35.66677488976423 139.742663290724 45.73 35.66683656108892 139.74269833549877 45.73 35.66678817268344 139.74267084205368 48.366 35.66677488976423 139.742663290724 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f45d64c1-1536-4d38-95d5-bf1668402e47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f45d64c1-1536-4d38-95d5-bf1668402e47_0">
											<gml:posList>35.66678817268344 139.74267084205368 48.366 35.66683656108892 139.74269833549877 45.73 35.66682344049346 139.7426908833884 48.366 35.66678817268344 139.74267084205368 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad5b766c-9fa6-4f9b-8612-933742973094">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad5b766c-9fa6-4f9b-8612-933742973094_0">
											<gml:posList>35.66683656108892 139.74269833549877 45.73 35.66683656108892 139.74269833549877 48.366 35.66682344049346 139.7426908833884 48.366 35.66683656108892 139.74269833549877 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce7a43a9-f69f-4f2e-947f-9e1baad44379">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce7a43a9-f69f-4f2e-947f-9e1baad44379_0">
											<gml:posList>35.66678817268344 139.74267084205368 48.366 35.66683021457652 139.7426732687728 49.623 35.666794856193796 139.74265265316677 49.623 35.66678817268344 139.74267084205368 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cee11d1-effe-4ad3-852e-dc1b8b9c288b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cee11d1-effe-4ad3-852e-dc1b8b9c288b_0">
											<gml:posList>35.66678817268344 139.74267084205368 48.366 35.66682344049346 139.7426908833884 48.366 35.66683021457652 139.7426732687728 49.623 35.66678817268344 139.74267084205368 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50c87025-222f-4e8d-a416-1a329832251e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50c87025-222f-4e8d-a416-1a329832251e_0">
											<gml:posList>35.66683021457652 139.7426732687728 49.623 35.66680167463276 139.74263409961387 51.065 35.666794856193796 139.74265265316677 49.623 35.66683021457652 139.7426732687728 49.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6025df1b-bf6d-4c4f-8cf9-748369b606be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6025df1b-bf6d-4c4f-8cf9-748369b606be_0">
											<gml:posList>35.66683021457652 139.7426732687728 49.623 35.66683797825402 139.7426531125077 51.065 35.66680167463276 139.74263409961387 51.065 35.66683021457652 139.7426732687728 49.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d8e6f0c-e6d4-446e-a84a-cfef78653862">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d8e6f0c-e6d4-446e-a84a-cfef78653862_0">
											<gml:posList>35.66683797825402 139.7426531125077 51.065 35.66680990534499 139.74261172262445 49.623 35.66680167463276 139.74263409961387 51.065 35.66683797825402 139.7426531125077 51.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f8e79f4-8dd1-46c6-8bca-9c672edb3636">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f8e79f4-8dd1-46c6-8bca-9c672edb3636_0">
											<gml:posList>35.66683797825402 139.7426531125077 51.065 35.66684603879879 139.74263218269877 49.623 35.66680990534499 139.74261172262445 49.623 35.66683797825402 139.7426531125077 51.065</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05aab01f-397a-45e9-8302-2499729d81a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05aab01f-397a-45e9-8302-2499729d81a5_0">
											<gml:posList>35.66681563535544 139.742596141608 48.366 35.666864691084825 139.7426240208646 45.73 35.66678455168961 139.74257847042065 45.73 35.66681563535544 139.742596141608 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2edfb54-3c4d-4b5d-bfd6-36697ac26722">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2edfb54-3c4d-4b5d-bfd6-36697ac26722_0">
											<gml:posList>35.66678455168961 139.74257847042065 45.73 35.66678455168961 139.74257847042065 48.366 35.666803019730544 139.74258896508906 48.366 35.66678455168961 139.74257847042065 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfff7fc9-18e6-445a-874f-a79e6ad7954b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfff7fc9-18e6-445a-874f-a79e6ad7954b_0">
											<gml:posList>35.66685196725534 139.74261678923042 48.366 35.666864691084825 139.7426240208646 48.366 35.666864691084825 139.7426240208646 45.73 35.66685196725534 139.74261678923042 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e901165c-f596-42b0-be8a-cfb2bdf8776a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e901165c-f596-42b0-be8a-cfb2bdf8776a_0">
											<gml:posList>35.66681563535544 139.742596141608 48.366 35.66678455168961 139.74257847042065 45.73 35.666803019730544 139.74258896508906 48.366 35.66681563535544 139.742596141608 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db7ce219-cb0f-400b-bec5-a86f58be33b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db7ce219-cb0f-400b-bec5-a86f58be33b9_0">
											<gml:posList>35.66681563535544 139.742596141608 48.366 35.66685196725534 139.74261678923042 48.366 35.666864691084825 139.7426240208646 45.73 35.66681563535544 139.742596141608 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46305e5f-d9b1-4b79-947c-1265a69fb09e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46305e5f-d9b1-4b79-947c-1265a69fb09e_0">
											<gml:posList>35.66686032869255 139.74284000383346 45.73 35.66679245271689 139.74280064704985 46.5 35.66679245271689 139.74280064704985 45.73 35.66686032869255 139.74284000383346 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbfe68f7-1020-473e-bd92-8be88d560af6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbfe68f7-1020-473e-bd92-8be88d560af6_0">
											<gml:posList>35.66686032869255 139.74284000383346 45.73 35.66686032869255 139.74284000383346 46.5 35.66679245271689 139.74280064704985 46.5 35.66686032869255 139.74284000383346 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60fc1d14-e584-4ec9-9065-bd498afadedd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60fc1d14-e584-4ec9-9065-bd498afadedd_0">
											<gml:posList>35.66685196725534 139.74261678923042 48.366 35.66681563535544 139.742596141608 48.366 35.66680990534499 139.74261172262445 49.623 35.66685196725534 139.74261678923042 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f9686cc-179c-48a6-b2b6-4ed83281acd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f9686cc-179c-48a6-b2b6-4ed83281acd8_0">
											<gml:posList>35.66684603879879 139.74263218269877 49.623 35.66685196725534 139.74261678923042 48.366 35.66680990534499 139.74261172262445 49.623 35.66684603879879 139.74263218269877 49.623</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f920f111-0392-4547-a51c-7afbc33c6ef0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f920f111-0392-4547-a51c-7afbc33c6ef0_0">
											<gml:posList>35.666864691084825 139.7426240208646 48.366 35.66684603879879 139.74263218269877 49.623 35.66683021457652 139.7426732687728 49.623 35.666864691084825 139.7426240208646 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f04a7790-6673-4deb-a53b-f20c7b0a5c50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f04a7790-6673-4deb-a53b-f20c7b0a5c50_0">
											<gml:posList>35.66683656108892 139.74269833549877 48.366 35.666864691084825 139.7426240208646 48.366 35.66683021457652 139.7426732687728 49.623 35.66683656108892 139.74269833549877 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7155f8e9-b5fd-41d8-8b96-7cf11f0b764a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7155f8e9-b5fd-41d8-8b96-7cf11f0b764a_0">
											<gml:posList>35.66688795181272 139.74263104175859 48.366 35.66683729280662 139.742760367725 45.73 35.66683729280662 139.742760367725 48.366 35.66688795181272 139.74263104175859 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66fde1b5-9c99-4eb9-93c0-bc56ab4938c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66fde1b5-9c99-4eb9-93c0-bc56ab4938c5_0">
											<gml:posList>35.66688795181272 139.74263104175859 48.366 35.66688795181272 139.74263104175859 45.73 35.66683729280662 139.742760367725 45.73 35.66688795181272 139.74263104175859 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f0dbd5b-c6d1-4843-b4c2-3dee4493dfd2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f0dbd5b-c6d1-4843-b4c2-3dee4493dfd2_0">
											<gml:posList>35.66683729280662 139.742760367725 48.366 35.66684800303923 139.74279887223844 49.495 35.66689912237721 139.7426703300089 49.495 35.66683729280662 139.742760367725 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a2b75ed-0a0a-4662-b4e7-c8d7b1190270">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a2b75ed-0a0a-4662-b4e7-c8d7b1190270_0">
											<gml:posList>35.66688795181272 139.74263104175859 48.366 35.66683729280662 139.742760367725 48.366 35.66689912237721 139.7426703300089 49.495 35.66688795181272 139.74263104175859 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a859d676-3388-4f89-85f0-87944cfa0f9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a859d676-3388-4f89-85f0-87944cfa0f9b_0">
											<gml:posList>35.66687116944707 139.74281233297575 48.366 35.66689912237721 139.7426703300089 49.495 35.66684800303923 139.74279887223844 49.495 35.66687116944707 139.74281233297575 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b96e937a-4d67-4032-bdbd-5134e47c6997">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b96e937a-4d67-4032-bdbd-5134e47c6997_0">
											<gml:posList>35.66687116944707 139.74281233297575 48.366 35.66693203047489 139.74265696053985 48.366 35.66689912237721 139.7426703300089 49.495 35.66687116944707 139.74281233297575 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83961fdd-cd42-454f-8103-4af53d11f1d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83961fdd-cd42-454f-8103-4af53d11f1d6_0">
											<gml:posList>35.66685986087515 139.7428411973051 48.366 35.66686032869255 139.74284000383346 45.73 35.66687116944707 139.74281233297575 48.366 35.66685986087515 139.7428411973051 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19e7f642-afd5-4657-a296-a846a8e8d75c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19e7f642-afd5-4657-a296-a846a8e8d75c_0">
											<gml:posList>35.66687116944707 139.74281233297575 48.366 35.66693203047489 139.74265696053985 45.73 35.66693203047489 139.74265696053985 48.366 35.66687116944707 139.74281233297575 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa8f7ff5-a4a5-487f-8126-8848bfb9ce2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa8f7ff5-a4a5-487f-8126-8848bfb9ce2e_0">
											<gml:posList>35.66687116944707 139.74281233297575 48.366 35.66686032869255 139.74284000383346 45.73 35.66693203047489 139.74265696053985 45.73 35.66687116944707 139.74281233297575 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d10ad7c-d4ee-44ba-a9f0-58f3c05a7fe5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d10ad7c-d4ee-44ba-a9f0-58f3c05a7fe5_0">
											<gml:posList>35.66693203047489 139.74265696053985 48.366 35.66693203047489 139.74265696053985 45.73 35.66690966651306 139.7426438192574 48.366 35.66693203047489 139.74265696053985 48.366</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f5271d5-6480-40bc-aebf-82ede49296cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f5271d5-6480-40bc-aebf-82ede49296cb_0">
											<gml:posList>35.66693203047489 139.74265696053985 45.73 35.66688795181272 139.74263104175859 45.73 35.66690966651306 139.7426438192574 48.366 35.66693203047489 139.74265696053985 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9fb98f9-e51f-4c21-be0f-cc6cb7e96919">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9fb98f9-e51f-4c21-be0f-cc6cb7e96919_0">
											<gml:posList>35.66688795181272 139.74263104175859 45.73 35.66688795181272 139.74263104175859 48.366 35.66690966651306 139.7426438192574 48.366 35.66688795181272 139.74263104175859 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4fec25e-b7a0-473f-8eb9-86a6d771da7a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66686032869255 139.74284000383346 46.5 35.66685986087515 139.7428411973051 46.5 35.66679245271689 139.74280064704985 46.5 35.66686032869255 139.74284000383346 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8e4e24d-3ca4-461a-9abf-0ebcb27680a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674839097399 139.74277321494634 46.5 35.66679245271689 139.74280064704985 46.5 35.66666983035752 139.74272941890916 46.5 35.66674839097399 139.74277321494634 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ea75d6f-5b3d-4d37-bda6-e9a076dca0f0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674839097399 139.74277321494634 46.5 35.66666983035752 139.74272941890916 46.5 35.666670415136224 139.74272793811812 46.5 35.66674839097399 139.74277321494634 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-402d9cca-20ed-49fe-866b-f448a99c69a8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66679245271689 139.74280064704985 46.5 35.66685986087515 139.7428411973051 46.5 35.66666983035752 139.74272941890916 46.5 35.66679245271689 139.74280064704985 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62e622af-cf84-4668-bd0a-bcba7d774032">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66673505883737 139.74270023963723 45.73 35.66674189183247 139.74254545874686 45.73 35.66678561882873 139.74257117900834 45.73 35.66673505883737 139.74270023963723 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82cf8419-3201-4626-9912-834e307c2081">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666670415136224 139.74272793811812 45.73 35.66674189183247 139.74254545874686 45.73 35.66673505883737 139.74270023963723 45.73 35.666670415136224 139.74272793811812 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81ad4788-2576-4386-8348-90da85081f93">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66688795181272 139.74263104175859 45.73 35.66693203047489 139.74265696053985 45.73 35.66683729280662 139.742760367725 45.73 35.66688795181272 139.74263104175859 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b34c9226-37ac-4a28-8321-094b93612e14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693203047489 139.74265696053985 45.73 35.66686032869255 139.74284000383346 45.73 35.66683729280662 139.742760367725 45.73 35.66693203047489 139.74265696053985 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aec4e38-45b0-4061-8121-8cb9ba30b226">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674839097399 139.74277321494634 45.73 35.66673505883737 139.74270023963723 45.73 35.66683729280662 139.742760367725 45.73 35.66674839097399 139.74277321494634 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-590d6cfe-2553-4fad-871a-173acfe394d6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666670415136224 139.74272793811812 45.73 35.66673505883737 139.74270023963723 45.73 35.66674839097399 139.74277321494634 45.73 35.666670415136224 139.74272793811812 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e715f486-bc82-460d-a8d8-eddc2583d798">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674839097399 139.74277321494634 45.73 35.66683729280662 139.742760367725 45.73 35.66679245271689 139.74280064704985 45.73 35.66674839097399 139.74277321494634 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e47ed8d-c4fe-4e7a-a078-c5df603ff4ba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66683729280662 139.742760367725 45.73 35.66686032869255 139.74284000383346 45.73 35.66679245271689 139.74280064704985 45.73 35.66683729280662 139.742760367725 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fc7da90-0065-46da-bf73-986b223606fe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666767918405 139.74262241824133 45.73 35.66678455168961 139.74257847042065 45.73 35.66678638644217 139.74263291291768 45.73 35.666767918405 139.74262241824133 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9305cce7-4612-4ac1-83f1-cb693db6c091">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66677488976423 139.742663290724 45.73 35.66678638644217 139.74263291291768 45.73 35.66683656108892 139.74269833549877 45.73 35.66677488976423 139.742663290724 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f251f9e5-c36c-4b61-a109-13439a53b0a5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66683656108892 139.74269833549877 45.73 35.66678638644217 139.74263291291768 45.73 35.666864691084825 139.7426240208646 45.73 35.66683656108892 139.74269833549877 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12d93ffe-db1b-45da-9bf9-2893e4fc4d9c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66678638644217 139.74263291291768 45.73 35.66678455168961 139.74257847042065 45.73 35.666864691084825 139.7426240208646 45.73 35.66678638644217 139.74263291291768 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2bec31e2-4ba9-4dc5-9a1e-1fd39114c427_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46c75a99-28da-4b51-8b3a-a79c5ba4968b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687066065678 139.74267518919285 45.73 35.666861273198975 139.74266966587282 45.73 35.66687507374056 139.74263443633293 45.73 35.666884461199956 139.7426399596498 45.73 35.66687066065678 139.74267518919285 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41a6b578-33de-42c7-a2af-eb5e806831e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41a6b578-33de-42c7-a2af-eb5e806831e2_0">
											<gml:posList>35.66687066065678 139.74267518919285 47.653 35.666861273198975 139.74266966587282 47.653 35.666861273198975 139.74266966587282 45.73 35.66687066065678 139.74267518919285 45.73 35.66687066065678 139.74267518919285 47.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ea6ae64-418b-4ea8-a3c4-473ea4dc4702">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ea6ae64-418b-4ea8-a3c4-473ea4dc4702_0">
											<gml:posList>35.666861273198975 139.74266966587282 45.73 35.666861273198975 139.74266966587282 47.653 35.66687507374056 139.74263443633293 47.653 35.66687507374056 139.74263443633293 45.73 35.666861273198975 139.74266966587282 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-311999e6-d107-43bb-80ea-3bc3799440f4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-311999e6-d107-43bb-80ea-3bc3799440f4_0">
											<gml:posList>35.66687507374056 139.74263443633293 47.653 35.666861273198975 139.74266966587282 47.653 35.66687066065678 139.74267518919285 47.653 35.666884461199956 139.7426399596498 47.653 35.66687507374056 139.74263443633293 47.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94572bbc-edd7-439b-b366-be7ca5c982b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94572bbc-edd7-439b-b366-be7ca5c982b7_0">
											<gml:posList>35.666884461199956 139.7426399596498 45.73 35.666884461199956 139.7426399596498 47.653 35.66687066065678 139.74267518919285 47.653 35.66687066065678 139.74267518919285 45.73 35.666884461199956 139.7426399596498 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3eb82aa5-4f56-44af-9deb-cd8996cd50e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3eb82aa5-4f56-44af-9deb-cd8996cd50e8_0">
											<gml:posList>35.66687507374056 139.74263443633293 47.653 35.666884461199956 139.7426399596498 47.653 35.666884461199956 139.7426399596498 45.73 35.66687507374056 139.74263443633293 45.73 35.66687507374056 139.74263443633293 47.653</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-df1c5c85-8f86-4fe0-86cf-a25be1666fc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df1c5c85-8f86-4fe0-86cf-a25be1666fc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df1c5c85-8f86-4fe0-86cf-a25be1666fc0">
											<gml:posList>35.66693165380841 139.74264752786576 26.07 35.66694121260283 139.74265315040634 26.07 35.6668662739856 139.74284697805433 26.07 35.666791337190254 139.74280354229975 26.07 35.66678620932915 139.74281680300643 26.07 35.666741571774324 139.74279078540346 26.07 35.66674723937647 139.7427760881443 26.07 35.66666653119148 139.74272923485915 26.07 35.6667402101155 139.74253861228078 26.07 35.66675572047451 139.74254754178477 26.07 35.666767325529605 139.74251748417353 26.07 35.66694262917523 139.74261912778326 26.07 35.66693165380841 139.74264752786576 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7290d719-fa61-4b8a-8a59-34f0b5b249ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7290d719-fa61-4b8a-8a59-34f0b5b249ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7290d719-fa61-4b8a-8a59-34f0b5b249ae">
											<gml:posList>35.66666653119148 139.74272923485915 46.5 35.666670009343896 139.7427277066159 46.5 35.66674145721644 139.7425428634857 46.5 35.6667402101155 139.74253861228078 46.5 35.66666653119148 139.74272923485915 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c66731d2-e789-4600-afcd-6bff09c7e87d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c66731d2-e789-4600-afcd-6bff09c7e87d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c66731d2-e789-4600-afcd-6bff09c7e87d">
											<gml:posList>35.66674723937647 139.7427760881443 46.5 35.66674839097399 139.74277321494634 46.5 35.666670009343896 139.7427277066159 46.5 35.66666653119148 139.74272923485915 46.5 35.66674723937647 139.7427760881443 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a051e8b-cdf9-49b7-a9b5-dd589aaad4f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a051e8b-cdf9-49b7-a9b5-dd589aaad4f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a051e8b-cdf9-49b7-a9b5-dd589aaad4f8">
											<gml:posList>35.666791337190254 139.74280354229975 44.3 35.66674723937647 139.7427760881443 44.3 35.666741571774324 139.74279078540346 44.3 35.66678620932915 139.74281680300643 44.3 35.666791337190254 139.74280354229975 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11989e3b-1f58-4f9b-ad56-0931c37f387d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11989e3b-1f58-4f9b-ad56-0931c37f387d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11989e3b-1f58-4f9b-ad56-0931c37f387d">
											<gml:posList>35.666791337190254 139.74280354229975 46.5 35.66679245271689 139.74280064704985 46.5 35.66674839097399 139.74277321494634 46.5 35.66674723937647 139.7427760881443 46.5 35.666791337190254 139.74280354229975 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0539898b-79c5-4990-896e-5b563fa6388c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0539898b-79c5-4990-896e-5b563fa6388c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0539898b-79c5-4990-896e-5b563fa6388c">
											<gml:posList>35.666865017873384 139.74284271580242 45.73 35.666937725429484 139.74265466762242 45.73 35.66693051124432 139.7426504231534 45.73 35.66674145721644 139.7425428634857 45.73 35.666670009343896 139.7427277066159 45.73 35.66674839097399 139.74277321494634 45.73 35.66679245271689 139.74280064704985 45.73 35.666865017873384 139.74284271580242 45.73</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48c6e7cd-7f3b-4a71-afd0-e640c2f7de8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48c6e7cd-7f3b-4a71-afd0-e640c2f7de8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48c6e7cd-7f3b-4a71-afd0-e640c2f7de8c">
											<gml:posList>35.666791337190254 139.74280354229975 46.5 35.6668662739856 139.74284697805433 46.5 35.666865017873384 139.74284271580242 46.5 35.66679245271689 139.74280064704985 46.5 35.666791337190254 139.74280354229975 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a4825fe-3210-4ff4-a079-c354faab332e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a4825fe-3210-4ff4-a079-c354faab332e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a4825fe-3210-4ff4-a079-c354faab332e">
											<gml:posList>35.66693165380841 139.74264752786576 46.5 35.6667402101155 139.74253861228078 46.5 35.66674145721644 139.7425428634857 46.5 35.66693051124432 139.7426504231534 46.5 35.66693165380841 139.74264752786576 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-641f67d2-1b93-440d-8daf-990d936b75ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-641f67d2-1b93-440d-8daf-990d936b75ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-641f67d2-1b93-440d-8daf-990d936b75ba">
											<gml:posList>35.66693165380841 139.74264752786576 45.3 35.66694262917523 139.74261912778326 45.3 35.666767325529605 139.74251748417353 45.3 35.66675572047451 139.74254754178477 45.3 35.66693165380841 139.74264752786576 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6498bd6a-f9f5-4ea5-a8c8-d280dd508e7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6498bd6a-f9f5-4ea5-a8c8-d280dd508e7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6498bd6a-f9f5-4ea5-a8c8-d280dd508e7e">
											<gml:posList>35.66694121260283 139.74265315040634 46.5 35.666937725429484 139.74265466762242 46.5 35.666865017873384 139.74284271580242 46.5 35.6668662739856 139.74284697805433 46.5 35.66694121260283 139.74265315040634 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc1f77ed-419f-4631-9abe-6b363ab21fc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc1f77ed-419f-4631-9abe-6b363ab21fc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc1f77ed-419f-4631-9abe-6b363ab21fc2">
											<gml:posList>35.66693165380841 139.74264752786576 46.5 35.66693051124432 139.7426504231534 46.5 35.666937725429484 139.74265466762242 46.5 35.66694121260283 139.74265315040634 46.5 35.66693165380841 139.74264752786576 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a44b845c-71bb-470b-bf0d-a4163980d087">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a44b845c-71bb-470b-bf0d-a4163980d087">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a44b845c-71bb-470b-bf0d-a4163980d087">
											<gml:posList>35.666767325529605 139.74251748417353 26.07 35.66675572047451 139.74254754178477 26.07 35.66675572047451 139.74254754178477 45.3 35.666767325529605 139.74251748417353 45.3 35.666767325529605 139.74251748417353 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10f89bce-0268-45bd-a2ee-bf49f9ef7bc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10f89bce-0268-45bd-a2ee-bf49f9ef7bc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10f89bce-0268-45bd-a2ee-bf49f9ef7bc5">
											<gml:posList>35.6667402101155 139.74253861228078 46.5 35.66675572047451 139.74254754178477 45.3 35.66675572047451 139.74254754178477 26.07 35.6667402101155 139.74253861228078 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42607ca3-5cb2-413b-84ba-2b6398e6c34c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42607ca3-5cb2-413b-84ba-2b6398e6c34c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42607ca3-5cb2-413b-84ba-2b6398e6c34c">
											<gml:posList>35.6667402101155 139.74253861228078 46.5 35.66675572047451 139.74254754178477 26.07 35.6667402101155 139.74253861228078 26.07 35.6667402101155 139.74253861228078 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4e12841-3497-45c7-b965-43d5177baf5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4e12841-3497-45c7-b965-43d5177baf5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4e12841-3497-45c7-b965-43d5177baf5b">
											<gml:posList>35.66694262917523 139.74261912778326 26.07 35.666767325529605 139.74251748417353 26.07 35.666767325529605 139.74251748417353 45.3 35.66694262917523 139.74261912778326 45.3 35.66694262917523 139.74261912778326 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-424a19d5-9823-4431-9e4d-1f8e082bd260">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-424a19d5-9823-4431-9e4d-1f8e082bd260">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-424a19d5-9823-4431-9e4d-1f8e082bd260">
											<gml:posList>35.6667402101155 139.74253861228078 46.5 35.66693165380841 139.74264752786576 46.5 35.66693165380841 139.74264752786576 45.3 35.6667402101155 139.74253861228078 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6ec0cc3-58c9-4d72-ac1d-d4b4ac99e95d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6ec0cc3-58c9-4d72-ac1d-d4b4ac99e95d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6ec0cc3-58c9-4d72-ac1d-d4b4ac99e95d">
											<gml:posList>35.6667402101155 139.74253861228078 46.5 35.66693165380841 139.74264752786576 45.3 35.66675572047451 139.74254754178477 45.3 35.6667402101155 139.74253861228078 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95a3c790-b56d-4630-a5b1-f6467cbd6569">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95a3c790-b56d-4630-a5b1-f6467cbd6569">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95a3c790-b56d-4630-a5b1-f6467cbd6569">
											<gml:posList>35.66674145721644 139.7425428634857 46.5 35.66674145721644 139.7425428634857 45.73 35.66693051124432 139.7426504231534 45.73 35.66693051124432 139.7426504231534 46.5 35.66674145721644 139.7425428634857 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12e3b998-ebe0-48da-9e6f-f6cce4168972">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12e3b998-ebe0-48da-9e6f-f6cce4168972">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12e3b998-ebe0-48da-9e6f-f6cce4168972">
											<gml:posList>35.66693165380841 139.74264752786576 26.07 35.66694262917523 139.74261912778326 26.07 35.66694262917523 139.74261912778326 45.3 35.66693165380841 139.74264752786576 45.3 35.66693165380841 139.74264752786576 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91679374-fd62-4bc5-bf45-e0d76c4def7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91679374-fd62-4bc5-bf45-e0d76c4def7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91679374-fd62-4bc5-bf45-e0d76c4def7b">
											<gml:posList>35.6667402101155 139.74253861228078 26.07 35.66666653119148 139.74272923485915 26.07 35.66666653119148 139.74272923485915 46.5 35.6667402101155 139.74253861228078 46.5 35.6667402101155 139.74253861228078 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d85ca252-af02-44c7-877b-4ead95a9974a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d85ca252-af02-44c7-877b-4ead95a9974a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d85ca252-af02-44c7-877b-4ead95a9974a">
											<gml:posList>35.666670009343896 139.7427277066159 46.5 35.666670009343896 139.7427277066159 45.73 35.66674145721644 139.7425428634857 45.73 35.66674145721644 139.7425428634857 46.5 35.666670009343896 139.7427277066159 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bedfb4a8-479c-435e-9b07-cf7b90639899">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bedfb4a8-479c-435e-9b07-cf7b90639899">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bedfb4a8-479c-435e-9b07-cf7b90639899">
											<gml:posList>35.66694121260283 139.74265315040634 46.5 35.66693165380841 139.74264752786576 45.3 35.66693165380841 139.74264752786576 46.5 35.66694121260283 139.74265315040634 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28b60c89-7f33-4ffc-a740-cb030846794c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28b60c89-7f33-4ffc-a740-cb030846794c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28b60c89-7f33-4ffc-a740-cb030846794c">
											<gml:posList>35.66694121260283 139.74265315040634 46.5 35.66694121260283 139.74265315040634 26.07 35.66693165380841 139.74264752786576 26.07 35.66693165380841 139.74264752786576 45.3 35.66694121260283 139.74265315040634 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78b36f89-ad9d-4026-8009-6f95ede37e69">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78b36f89-ad9d-4026-8009-6f95ede37e69">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78b36f89-ad9d-4026-8009-6f95ede37e69">
											<gml:posList>35.66693051124432 139.7426504231534 46.5 35.66693051124432 139.7426504231534 45.73 35.666937725429484 139.74265466762242 45.73 35.666937725429484 139.74265466762242 46.5 35.66693051124432 139.7426504231534 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0189791b-e932-4b65-b57c-39d41a16ccba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0189791b-e932-4b65-b57c-39d41a16ccba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0189791b-e932-4b65-b57c-39d41a16ccba">
											<gml:posList>35.666937725429484 139.74265466762242 46.5 35.666937725429484 139.74265466762242 45.73 35.666865017873384 139.74284271580242 45.73 35.666865017873384 139.74284271580242 46.5 35.666937725429484 139.74265466762242 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29219be7-8621-467d-b582-de2e1285c3f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29219be7-8621-467d-b582-de2e1285c3f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29219be7-8621-467d-b582-de2e1285c3f3">
											<gml:posList>35.6668662739856 139.74284697805433 26.07 35.66694121260283 139.74265315040634 26.07 35.66694121260283 139.74265315040634 46.5 35.6668662739856 139.74284697805433 46.5 35.6668662739856 139.74284697805433 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a086dcc6-abb4-48f3-9ce2-7824ccad1e6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a086dcc6-abb4-48f3-9ce2-7824ccad1e6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a086dcc6-abb4-48f3-9ce2-7824ccad1e6d">
											<gml:posList>35.66674839097399 139.74277321494634 46.5 35.66674839097399 139.74277321494634 45.73 35.666670009343896 139.7427277066159 45.73 35.666670009343896 139.7427277066159 46.5 35.66674839097399 139.74277321494634 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9ce99f1-5c33-4661-9528-1bc456a670aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9ce99f1-5c33-4661-9528-1bc456a670aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9ce99f1-5c33-4661-9528-1bc456a670aa">
											<gml:posList>35.66666653119148 139.74272923485915 46.5 35.66666653119148 139.74272923485915 26.07 35.66674723937647 139.7427760881443 26.07 35.66674723937647 139.7427760881443 44.3 35.66674723937647 139.7427760881443 46.5 35.66666653119148 139.74272923485915 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-10a35aec-7169-4c52-8577-9e6b1493e3a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10a35aec-7169-4c52-8577-9e6b1493e3a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10a35aec-7169-4c52-8577-9e6b1493e3a2">
											<gml:posList>35.66674723937647 139.7427760881443 26.07 35.666741571774324 139.74279078540346 26.07 35.666741571774324 139.74279078540346 44.3 35.66674723937647 139.7427760881443 44.3 35.66674723937647 139.7427760881443 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f74a54fc-14c4-497b-bfe9-80b1c3d7f924">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f74a54fc-14c4-497b-bfe9-80b1c3d7f924">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f74a54fc-14c4-497b-bfe9-80b1c3d7f924">
											<gml:posList>35.66679245271689 139.74280064704985 46.5 35.66679245271689 139.74280064704985 45.73 35.66674839097399 139.74277321494634 45.73 35.66674839097399 139.74277321494634 46.5 35.66679245271689 139.74280064704985 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d43bf1de-2f24-42a6-bcce-e5be52973dc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d43bf1de-2f24-42a6-bcce-e5be52973dc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d43bf1de-2f24-42a6-bcce-e5be52973dc3">
											<gml:posList>35.666791337190254 139.74280354229975 44.3 35.666791337190254 139.74280354229975 46.5 35.66674723937647 139.7427760881443 46.5 35.66674723937647 139.7427760881443 44.3 35.666791337190254 139.74280354229975 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48f05352-164a-4e3e-86b4-8eddefadf547">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48f05352-164a-4e3e-86b4-8eddefadf547">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48f05352-164a-4e3e-86b4-8eddefadf547">
											<gml:posList>35.666741571774324 139.74279078540346 26.07 35.66678620932915 139.74281680300643 26.07 35.66678620932915 139.74281680300643 44.3 35.666741571774324 139.74279078540346 44.3 35.666741571774324 139.74279078540346 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41d2ed9b-eced-4304-b5d3-09ea11e99fda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41d2ed9b-eced-4304-b5d3-09ea11e99fda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41d2ed9b-eced-4304-b5d3-09ea11e99fda">
											<gml:posList>35.66678620932915 139.74281680300643 26.07 35.666791337190254 139.74280354229975 26.07 35.666791337190254 139.74280354229975 44.3 35.66678620932915 139.74281680300643 44.3 35.66678620932915 139.74281680300643 26.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3540e4e0-3b81-4302-b2b2-2c443f556fd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3540e4e0-3b81-4302-b2b2-2c443f556fd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3540e4e0-3b81-4302-b2b2-2c443f556fd2">
											<gml:posList>35.666865017873384 139.74284271580242 46.5 35.666865017873384 139.74284271580242 45.73 35.66679245271689 139.74280064704985 45.73 35.66679245271689 139.74280064704985 46.5 35.666865017873384 139.74284271580242 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c96d042-9b8e-4d3b-a835-af48988d45a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c96d042-9b8e-4d3b-a835-af48988d45a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c96d042-9b8e-4d3b-a835-af48988d45a1">
											<gml:posList>35.6668662739856 139.74284697805433 46.5 35.666791337190254 139.74280354229975 46.5 35.666791337190254 139.74280354229975 44.3 35.666791337190254 139.74280354229975 26.07 35.6668662739856 139.74284697805433 26.07 35.6668662739856 139.74284697805433 46.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8133</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">544.26745</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1121</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>