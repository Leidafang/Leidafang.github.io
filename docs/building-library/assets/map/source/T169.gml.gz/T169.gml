<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2c803c29-23be-4128-8160-8cc1924556f8">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670916205824334 139.73758805342516 0 35.6708915140164 139.73759536244305 0 35.67089763199379 139.73762642846512 0 35.670922323812384 139.73761913050257 0 35.670916205824334 139.73758805342516 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670916205824334 139.73758805342516 13.106 35.670922323812384 139.73761913050257 13.106 35.67089763199379 139.73762642846512 13.106 35.6708915140164 139.73759536244305 13.106 35.670916205824334 139.73758805342516 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670916205824334 139.73758805342516 13.106 35.6708915140164 139.73759536244305 13.106 35.6708915140164 139.73759536244305 16.29 35.670916205824334 139.73758805342516 16.29 35.670916205824334 139.73758805342516 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708915140164 139.73759536244305 13.106 35.67089763199379 139.73762642846512 13.106 35.67089763199379 139.73762642846512 16.29 35.6708915140164 139.73759536244305 16.29 35.6708915140164 139.73759536244305 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089763199379 139.73762642846512 13.106 35.670922323812384 139.73761913050257 13.106 35.670922323812384 139.73761913050257 16.29 35.67089763199379 139.73762642846512 16.29 35.67089763199379 139.73762642846512 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670922323812384 139.73761913050257 13.106 35.670916205824334 139.73758805342516 13.106 35.670916205824334 139.73758805342516 16.29 35.670922323812384 139.73761913050257 16.29 35.670922323812384 139.73761913050257 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670916205824334 139.73758805342516 16.29 35.6708915140164 139.73759536244305 16.29 35.67089763199379 139.73762642846512 16.29 35.670922323812384 139.73761913050257 16.29 35.670916205824334 139.73758805342516 16.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ca3cba1e-7a3c-4ce1-9279-e77a03a229b7"/>
							<gml:surfaceMember xlink:href="#poly-b034b78e-f28c-4aac-b8ea-b054c66ed08b"/>
							<gml:surfaceMember xlink:href="#poly-3811556e-e39c-4bd5-bfea-4f483216555c"/>
							<gml:surfaceMember xlink:href="#poly-165cb425-f880-40fa-a7cd-5eb3df3bf195"/>
							<gml:surfaceMember xlink:href="#poly-b5b6d1c8-06f5-4143-b7e3-47bfb720dcaa"/>
							<gml:surfaceMember xlink:href="#poly-366cdf2e-093a-46f5-90ff-242e22df69ec"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ca3cba1e-7a3c-4ce1-9279-e77a03a229b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca3cba1e-7a3c-4ce1-9279-e77a03a229b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca3cba1e-7a3c-4ce1-9279-e77a03a229b7">
											<gml:posList>35.67091620582431 139.73758805342516 13.106 35.670922323812356 139.73761913050257 13.106 35.67089763199376 139.73762642846512 13.106 35.670891514016375 139.73759536244305 13.106 35.67091620582431 139.73758805342516 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b034b78e-f28c-4aac-b8ea-b054c66ed08b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b034b78e-f28c-4aac-b8ea-b054c66ed08b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b034b78e-f28c-4aac-b8ea-b054c66ed08b">
											<gml:posList>35.67089763199376 139.73762642846512 16.232 35.670922323812356 139.73761913050257 16.232 35.67091620582431 139.73758805342516 16.232 35.670891514016375 139.73759536244305 16.232 35.67089763199376 139.73762642846512 16.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3811556e-e39c-4bd5-bfea-4f483216555c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3811556e-e39c-4bd5-bfea-4f483216555c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3811556e-e39c-4bd5-bfea-4f483216555c">
											<gml:posList>35.67091620582431 139.73758805342516 13.106 35.670891514016375 139.73759536244305 13.106 35.670891514016375 139.73759536244305 16.232 35.67091620582431 139.73758805342516 16.232 35.67091620582431 139.73758805342516 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-165cb425-f880-40fa-a7cd-5eb3df3bf195">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-165cb425-f880-40fa-a7cd-5eb3df3bf195">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-165cb425-f880-40fa-a7cd-5eb3df3bf195">
											<gml:posList>35.670922323812356 139.73761913050257 13.106 35.67091620582431 139.73758805342516 13.106 35.67091620582431 139.73758805342516 16.232 35.670922323812356 139.73761913050257 16.232 35.670922323812356 139.73761913050257 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5b6d1c8-06f5-4143-b7e3-47bfb720dcaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5b6d1c8-06f5-4143-b7e3-47bfb720dcaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5b6d1c8-06f5-4143-b7e3-47bfb720dcaa">
											<gml:posList>35.670891514016375 139.73759536244305 13.106 35.67089763199376 139.73762642846512 13.106 35.67089763199376 139.73762642846512 16.232 35.670891514016375 139.73759536244305 16.232 35.670891514016375 139.73759536244305 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-366cdf2e-093a-46f5-90ff-242e22df69ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-366cdf2e-093a-46f5-90ff-242e22df69ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-366cdf2e-093a-46f5-90ff-242e22df69ec">
											<gml:posList>35.67089763199376 139.73762642846512 13.106 35.670922323812356 139.73761913050257 13.106 35.670922323812356 139.73761913050257 16.232 35.67089763199376 139.73762642846512 16.232 35.67089763199376 139.73762642846512 13.106</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7885</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>