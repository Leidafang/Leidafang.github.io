<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2f9b44f1-35fd-41d5-becf-0ee21029169f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">8.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66872787449369 139.73977231304323 0 35.668756018683155 139.73979978483177 0 35.66882903285195 139.73968758229626 0 35.66880088863723 139.73966011052218 0 35.66872787449369 139.73977231304323 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872787449369 139.73977231304323 11.309 35.66880088863723 139.73966011052218 11.309 35.66882903285195 139.73968758229626 11.309 35.668756018683155 139.73979978483177 11.309 35.66872787449369 139.73977231304323 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872787449369 139.73977231304323 11.309 35.668756018683155 139.73979978483177 11.309 35.668756018683155 139.73979978483177 20.03 35.66872787449369 139.73977231304323 20.03 35.66872787449369 139.73977231304323 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668756018683155 139.73979978483177 11.309 35.66882903285195 139.73968758229626 11.309 35.66882903285195 139.73968758229626 20.03 35.668756018683155 139.73979978483177 20.03 35.668756018683155 139.73979978483177 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66882903285195 139.73968758229626 11.309 35.66880088863723 139.73966011052218 11.309 35.66880088863723 139.73966011052218 20.03 35.66882903285195 139.73968758229626 20.03 35.66882903285195 139.73968758229626 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880088863723 139.73966011052218 11.309 35.66872787449369 139.73977231304323 11.309 35.66872787449369 139.73977231304323 20.03 35.66880088863723 139.73966011052218 20.03 35.66880088863723 139.73966011052218 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872787449369 139.73977231304323 20.03 35.668756018683155 139.73979978483177 20.03 35.66882903285195 139.73968758229626 20.03 35.66880088863723 139.73966011052218 20.03 35.66872787449369 139.73977231304323 20.03</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-57aa503d-3a24-4d80-918b-fd6e65befa85"/>
							<gml:surfaceMember xlink:href="#poly-48720b52-9ccf-402c-ad43-67604ade36e1"/>
							<gml:surfaceMember xlink:href="#poly-3aed0067-841e-4156-8b99-5af1eb2d631b"/>
							<gml:surfaceMember xlink:href="#poly-e5ab20d6-c6d5-480f-89af-defc19b7af04"/>
							<gml:surfaceMember xlink:href="#poly-a58802e3-6942-456b-9bbe-c2f0a9647ed7"/>
							<gml:surfaceMember xlink:href="#poly-7cfcf9ee-e3b6-440d-bcee-12c27048740e"/>
							<gml:surfaceMember xlink:href="#poly-2621dbaa-e30b-4ebe-8e4e-6ec546057e97"/>
							<gml:surfaceMember xlink:href="#poly-21bf330f-b9ee-42fa-a006-15adf02312f5"/>
							<gml:surfaceMember xlink:href="#poly-a49e4577-ef3d-488c-9845-41d25fa5b2d9"/>
							<gml:surfaceMember xlink:href="#poly-331dca6b-d5c8-4f03-9c02-a6d1fec778c2"/>
							<gml:surfaceMember xlink:href="#poly-a03eabd1-324a-4d49-a7c0-68b06d4efe26"/>
							<gml:surfaceMember xlink:href="#poly-aba68541-e23b-4ea3-8253-49b368c9a591"/>
							<gml:surfaceMember xlink:href="#poly-3ce3dc7a-a3fe-4f53-8f7b-c8a0abfe9b02"/>
							<gml:surfaceMember xlink:href="#poly-60748d59-fdd2-44a5-a1bc-19ceda49bdcd"/>
							<gml:surfaceMember xlink:href="#poly-6da75bcf-7491-4c45-be0b-e828a6fa3d49"/>
							<gml:surfaceMember xlink:href="#poly-1d988499-529e-4318-98f6-147b21ecf947"/>
							<gml:surfaceMember xlink:href="#poly-4fc4b8be-c730-44a1-a5f9-0dbd8f4328d3"/>
							<gml:surfaceMember xlink:href="#poly-e1716c2b-8e32-49f5-9254-0fcb59535a24"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2f9b44f1-35fd-41d5-becf-0ee21029169f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e43ac118-aa13-45ca-80fb-e85f8a6bc8a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66875681623472 139.7397357721244 20.367 35.66876092160772 139.7397294821375 20.367 35.66878451945575 139.7397525408123 20.355 35.66878042309529 139.73975883078933 20.355 35.66875681623472 139.7397357721244 20.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3c07ca7-6929-4077-9f7e-470cfc772a9d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668806903506244 139.73970995428562 20.357 35.66878711215658 139.73969038171984 20.368 35.66879150562276 139.7396836495502 20.366 35.66881136898882 139.73970310052474 20.357 35.668806903506244 139.73970995428562 20.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ad0e60c-2356-4acc-b934-2e9c13802a17">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ad0e60c-2356-4acc-b934-2e9c13802a17_0">
											<gml:posList>35.66878711215658 139.73969038171984 20.368 35.668787031136134 139.73969051436697 22.459 35.66879150562276 139.7396836495502 22.459 35.66879150562276 139.7396836495502 20.366 35.66878711215658 139.73969038171984 20.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-948d9d54-2dbf-4f59-b394-f370f625a8a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-948d9d54-2dbf-4f59-b394-f370f625a8a2_0">
											<gml:posList>35.66879150562276 139.7396836495502 22.459 35.66881136898882 139.73970310052474 22.459 35.66881136898882 139.73970310052474 20.357 35.66879150562276 139.7396836495502 20.366 35.66879150562276 139.7396836495502 22.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8663f07a-8228-47e7-bf61-2b8883b8eb03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8663f07a-8228-47e7-bf61-2b8883b8eb03_0">
											<gml:posList>35.66879150562276 139.7396836495502 22.459 35.668787031136134 139.73969051436697 22.459 35.66880688549597 139.73970997639873 22.459 35.66881136898882 139.73970310052474 22.459 35.66879150562276 139.7396836495502 22.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8664b8bf-2e77-4aaf-b293-626c23bd7fc1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8664b8bf-2e77-4aaf-b293-626c23bd7fc1_0">
											<gml:posList>35.66880688549597 139.73970997639873 22.459 35.668787031136134 139.73969051436697 22.459 35.66878711215658 139.73969038171984 20.368 35.668806903506244 139.73970995428562 20.357 35.66880688549597 139.73970997639873 22.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-665b2adb-d849-4794-8add-83e3e693c4e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-665b2adb-d849-4794-8add-83e3e693c4e5_0">
											<gml:posList>35.66881136898882 139.73970310052474 22.459 35.66880688549597 139.73970997639873 22.459 35.668806903506244 139.73970995428562 20.357 35.66881136898882 139.73970310052474 20.357 35.66881136898882 139.73970310052474 22.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3d4ff00-d26a-4da5-82ca-7f5fc86ca519">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3d4ff00-d26a-4da5-82ca-7f5fc86ca519_0">
											<gml:posList>35.66875681623472 139.7397357721244 22.459 35.66876092160772 139.7397294821375 22.459 35.66876092160772 139.7397294821375 20.367 35.66875681623472 139.7397357721244 20.367 35.66875681623472 139.7397357721244 22.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83b92dc9-5b38-4e14-b5f2-48c0dabdb893">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83b92dc9-5b38-4e14-b5f2-48c0dabdb893_0">
											<gml:posList>35.66876092160772 139.7397294821375 20.367 35.66876092160772 139.7397294821375 22.459 35.66878451945575 139.7397525408123 22.459 35.66878451945575 139.7397525408123 20.355 35.66876092160772 139.7397294821375 20.367</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2258fb7-cc05-45fb-8d89-ff12a8484313">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2258fb7-cc05-45fb-8d89-ff12a8484313_0">
											<gml:posList>35.66878042309529 139.73975883078933 22.459 35.66878451945575 139.7397525408123 22.459 35.66876092160772 139.7397294821375 22.459 35.66875681623472 139.7397357721244 22.459 35.66878042309529 139.73975883078933 22.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-676814fe-cbde-42dd-97d6-6d0475f9fc3e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-676814fe-cbde-42dd-97d6-6d0475f9fc3e_0">
											<gml:posList>35.66878042309529 139.73975883078933 22.459 35.66875681623472 139.7397357721244 22.459 35.66875681623472 139.7397357721244 20.367 35.66878042309529 139.73975883078933 20.355 35.66878042309529 139.73975883078933 22.459</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9d012b1-fe65-4aa4-97cd-41c37e39b994">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9d012b1-fe65-4aa4-97cd-41c37e39b994_0">
											<gml:posList>35.66878042309529 139.73975883078933 20.355 35.66878451945575 139.7397525408123 20.355 35.66878451945575 139.7397525408123 22.459 35.66878042309529 139.73975883078933 22.459 35.66878042309529 139.73975883078933 20.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-57aa503d-3a24-4d80-918b-fd6e65befa85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57aa503d-3a24-4d80-918b-fd6e65befa85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57aa503d-3a24-4d80-918b-fd6e65befa85">
											<gml:posList>35.668727874493676 139.7397723130432 11.309 35.66880088863722 139.73966011052218 11.309 35.66882903285192 139.73968758229626 11.309 35.66875601868313 139.73979978483177 11.309 35.668727874493676 139.7397723130432 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48720b52-9ccf-402c-ad43-67604ade36e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48720b52-9ccf-402c-ad43-67604ade36e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48720b52-9ccf-402c-ad43-67604ade36e1">
											<gml:posList>35.66882903285192 139.73968758229626 20.355 35.66880088863722 139.73966011052218 20.355 35.66878265762408 139.7396881335302 20.37 35.668810657776056 139.7397158153509 20.355 35.66882903285192 139.73968758229626 20.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3aed0067-841e-4156-8b99-5af1eb2d631b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3aed0067-841e-4156-8b99-5af1eb2d631b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3aed0067-841e-4156-8b99-5af1eb2d631b">
											<gml:posList>35.668782549588244 139.73968829934697 23.051 35.66878286779169 139.7396918005698 23.051 35.66880779171212 139.7397162053087 23.051 35.668810657776056 139.7397158153509 23.051 35.668782549588244 139.73968829934697 23.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5ab20d6-c6d5-480f-89af-defc19b7af04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5ab20d6-c6d5-480f-89af-defc19b7af04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5ab20d6-c6d5-480f-89af-defc19b7af04">
											<gml:posList>35.66875775538599 139.73972639294368 23.051 35.668760612427675 139.739725991951 23.051 35.66878286779169 139.7396918005698 23.051 35.668782549588244 139.73968829934697 23.051 35.66875775538599 139.73972639294368 23.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a58802e3-6942-456b-9bbe-c2f0a9647ed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a58802e3-6942-456b-9bbe-c2f0a9647ed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a58802e3-6942-456b-9bbe-c2f0a9647ed7">
											<gml:posList>35.66880779171212 139.7397162053087 22.682 35.66878286779169 139.7396918005698 22.682 35.668760612427675 139.739725991951 22.682 35.66878555435155 139.7397503745807 22.682 35.66880779171212 139.7397162053087 22.682</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7cfcf9ee-e3b6-440d-bcee-12c27048740e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cfcf9ee-e3b6-440d-bcee-12c27048740e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cfcf9ee-e3b6-440d-bcee-12c27048740e">
											<gml:posList>35.668810657776056 139.7397158153509 23.051 35.66880779171212 139.7397162053087 23.051 35.66878555435155 139.7397503745807 23.051 35.66878588157551 139.7397538868394 23.051 35.668810657776056 139.7397158153509 23.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2621dbaa-e30b-4ebe-8e4e-6ec546057e97">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2621dbaa-e30b-4ebe-8e4e-6ec546057e97">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2621dbaa-e30b-4ebe-8e4e-6ec546057e97">
											<gml:posList>35.66878588157551 139.7397538868394 23.051 35.66878555435155 139.7397503745807 23.051 35.668760612427675 139.739725991951 23.051 35.66875775538599 139.73972639294368 23.051 35.66878588157551 139.7397538868394 23.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21bf330f-b9ee-42fa-a006-15adf02312f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21bf330f-b9ee-42fa-a006-15adf02312f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21bf330f-b9ee-42fa-a006-15adf02312f5">
											<gml:posList>35.66875780043745 139.73972637079902 20.369 35.668727874493676 139.7397723130432 20.355 35.66875601868313 139.73979978483177 20.355 35.66878588157551 139.7397538868394 20.355 35.66875780043745 139.73972637079902 20.369</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a49e4577-ef3d-488c-9845-41d25fa5b2d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a49e4577-ef3d-488c-9845-41d25fa5b2d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a49e4577-ef3d-488c-9845-41d25fa5b2d9">
											<gml:posList>35.66880088863722 139.73966011052218 11.309 35.668727874493676 139.7397723130432 11.309 35.668727874493676 139.7397723130432 20.355 35.66875780043745 139.73972637079902 20.369 35.66875775538599 139.73972639294368 23.051 35.668782549588244 139.73968829934697 23.051 35.66878265762408 139.7396881335302 20.37 35.66880088863722 139.73966011052218 20.355 35.66880088863722 139.73966011052218 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-331dca6b-d5c8-4f03-9c02-a6d1fec778c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-331dca6b-d5c8-4f03-9c02-a6d1fec778c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-331dca6b-d5c8-4f03-9c02-a6d1fec778c2">
											<gml:posList>35.668760612427675 139.739725991951 23.051 35.668760612427675 139.739725991951 22.682 35.66878286779169 139.7396918005698 22.682 35.66878286779169 139.7396918005698 23.051 35.668760612427675 139.739725991951 23.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a03eabd1-324a-4d49-a7c0-68b06d4efe26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a03eabd1-324a-4d49-a7c0-68b06d4efe26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a03eabd1-324a-4d49-a7c0-68b06d4efe26">
											<gml:posList>35.66882903285192 139.73968758229626 11.309 35.66880088863722 139.73966011052218 11.309 35.66880088863722 139.73966011052218 20.355 35.66882903285192 139.73968758229626 20.355 35.66882903285192 139.73968758229626 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aba68541-e23b-4ea3-8253-49b368c9a591">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aba68541-e23b-4ea3-8253-49b368c9a591">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aba68541-e23b-4ea3-8253-49b368c9a591">
											<gml:posList>35.668810657776056 139.7397158153509 20.355 35.66878265762408 139.7396881335302 20.37 35.668782549588244 139.73968829934697 23.051 35.668810657776056 139.7397158153509 23.051 35.668810657776056 139.7397158153509 20.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ce3dc7a-a3fe-4f53-8f7b-c8a0abfe9b02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ce3dc7a-a3fe-4f53-8f7b-c8a0abfe9b02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ce3dc7a-a3fe-4f53-8f7b-c8a0abfe9b02">
											<gml:posList>35.66878286779169 139.7396918005698 23.051 35.66878286779169 139.7396918005698 22.682 35.66880779171212 139.7397162053087 22.682 35.66880779171212 139.7397162053087 23.051 35.66878286779169 139.7396918005698 23.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60748d59-fdd2-44a5-a1bc-19ceda49bdcd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60748d59-fdd2-44a5-a1bc-19ceda49bdcd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60748d59-fdd2-44a5-a1bc-19ceda49bdcd">
											<gml:posList>35.66878555435155 139.7397503745807 23.051 35.66878555435155 139.7397503745807 22.682 35.668760612427675 139.739725991951 22.682 35.668760612427675 139.739725991951 23.051 35.66878555435155 139.7397503745807 23.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6da75bcf-7491-4c45-be0b-e828a6fa3d49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6da75bcf-7491-4c45-be0b-e828a6fa3d49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6da75bcf-7491-4c45-be0b-e828a6fa3d49">
											<gml:posList>35.66875780043745 139.73972637079902 20.369 35.66878588157551 139.7397538868394 20.355 35.66878588157551 139.7397538868394 23.051 35.66875775538599 139.73972639294368 23.051 35.66875780043745 139.73972637079902 20.369</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d988499-529e-4318-98f6-147b21ecf947">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d988499-529e-4318-98f6-147b21ecf947">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d988499-529e-4318-98f6-147b21ecf947">
											<gml:posList>35.66875601868313 139.73979978483177 11.309 35.66882903285192 139.73968758229626 11.309 35.66882903285192 139.73968758229626 20.355 35.668810657776056 139.7397158153509 20.355 35.668810657776056 139.7397158153509 23.051 35.66878588157551 139.7397538868394 23.051 35.66878588157551 139.7397538868394 20.355 35.66875601868313 139.73979978483177 20.355 35.66875601868313 139.73979978483177 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4fc4b8be-c730-44a1-a5f9-0dbd8f4328d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4fc4b8be-c730-44a1-a5f9-0dbd8f4328d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4fc4b8be-c730-44a1-a5f9-0dbd8f4328d3">
											<gml:posList>35.668727874493676 139.7397723130432 11.309 35.66875601868313 139.73979978483177 11.309 35.66875601868313 139.73979978483177 20.355 35.668727874493676 139.7397723130432 20.355 35.668727874493676 139.7397723130432 11.309</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1716c2b-8e32-49f5-9254-0fcb59535a24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1716c2b-8e32-49f5-9254-0fcb59535a24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1716c2b-8e32-49f5-9254-0fcb59535a24">
											<gml:posList>35.66880779171212 139.7397162053087 23.051 35.66880779171212 139.7397162053087 22.682 35.66878555435155 139.7397503745807 22.682 35.66878555435155 139.7397503745807 23.051 35.66880779171212 139.7397162053087 23.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6458</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">51.8619</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>