<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_2fe4f5ce-a0be-4e93-9ca6-c2641b19b826">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">19.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67061615409302 139.74086000303808 0 35.67062524719494 139.7408694592237 0 35.67063332356303 139.7408578071154 0 35.67066062994215 139.74088621983796 0 35.67065200434484 139.740898667914 0 35.670704226542185 139.7409530218018 0 35.67077685084033 139.7408482190651 0 35.67074344628786 139.74081345067663 0 35.670728283965836 139.74083531776935 0 35.67071440073041 139.7408208631259 0 35.67069061169977 139.74079506432045 0 35.670704369419255 139.7407752092793 0 35.67063250853195 139.7407004204551 0 35.670615734566454 139.74072462016804 0 35.67060780514947 139.74071636670143 0 35.67053378537298 139.74082317032307 0 35.670596471894186 139.7408884147023 0 35.67061615409302 139.74086000303808 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061615409302 139.74086000303808 10.43 35.670596471894186 139.7408884147023 10.43 35.67053378537298 139.74082317032307 10.43 35.67060780514947 139.74071636670143 10.43 35.670615734566454 139.74072462016804 10.43 35.67063250853195 139.7407004204551 10.43 35.670704369419255 139.7407752092793 10.43 35.67069061169977 139.74079506432045 10.43 35.67071440073041 139.7408208631259 10.43 35.670728283965836 139.74083531776935 10.43 35.67074344628786 139.74081345067663 10.43 35.67077685084033 139.7408482190651 10.43 35.670704226542185 139.7409530218018 10.43 35.67065200434484 139.740898667914 10.43 35.67066062994215 139.74088621983796 10.43 35.67063332356303 139.7408578071154 10.43 35.67062524719494 139.7408694592237 10.43 35.67061615409302 139.74086000303808 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061615409302 139.74086000303808 10.43 35.67062524719494 139.7408694592237 10.43 35.67062524719494 139.7408694592237 30.34 35.67061615409302 139.74086000303808 30.34 35.67061615409302 139.74086000303808 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67062524719494 139.7408694592237 10.43 35.67063332356303 139.7408578071154 10.43 35.67063332356303 139.7408578071154 30.34 35.67062524719494 139.7408694592237 30.34 35.67062524719494 139.7408694592237 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063332356303 139.7408578071154 10.43 35.67066062994215 139.74088621983796 10.43 35.67066062994215 139.74088621983796 30.34 35.67063332356303 139.7408578071154 30.34 35.67063332356303 139.7408578071154 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67066062994215 139.74088621983796 10.43 35.67065200434484 139.740898667914 10.43 35.67065200434484 139.740898667914 30.34 35.67066062994215 139.74088621983796 30.34 35.67066062994215 139.74088621983796 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67065200434484 139.740898667914 10.43 35.670704226542185 139.7409530218018 10.43 35.670704226542185 139.7409530218018 30.34 35.67065200434484 139.740898667914 30.34 35.67065200434484 139.740898667914 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670704226542185 139.7409530218018 10.43 35.67077685084033 139.7408482190651 10.43 35.67077685084033 139.7408482190651 30.34 35.670704226542185 139.7409530218018 30.34 35.670704226542185 139.7409530218018 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077685084033 139.7408482190651 10.43 35.67074344628786 139.74081345067663 10.43 35.67074344628786 139.74081345067663 30.34 35.67077685084033 139.7408482190651 30.34 35.67077685084033 139.7408482190651 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67074344628786 139.74081345067663 10.43 35.670728283965836 139.74083531776935 10.43 35.670728283965836 139.74083531776935 30.34 35.67074344628786 139.74081345067663 30.34 35.67074344628786 139.74081345067663 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670728283965836 139.74083531776935 10.43 35.67071440073041 139.7408208631259 10.43 35.67071440073041 139.7408208631259 30.34 35.670728283965836 139.74083531776935 30.34 35.670728283965836 139.74083531776935 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67071440073041 139.7408208631259 10.43 35.67069061169977 139.74079506432045 10.43 35.67069061169977 139.74079506432045 30.34 35.67071440073041 139.7408208631259 30.34 35.67071440073041 139.7408208631259 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67069061169977 139.74079506432045 10.43 35.670704369419255 139.7407752092793 10.43 35.670704369419255 139.7407752092793 30.34 35.67069061169977 139.74079506432045 30.34 35.67069061169977 139.74079506432045 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670704369419255 139.7407752092793 10.43 35.67063250853195 139.7407004204551 10.43 35.67063250853195 139.7407004204551 30.34 35.670704369419255 139.7407752092793 30.34 35.670704369419255 139.7407752092793 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67063250853195 139.7407004204551 10.43 35.670615734566454 139.74072462016804 10.43 35.670615734566454 139.74072462016804 30.34 35.67063250853195 139.7407004204551 30.34 35.67063250853195 139.7407004204551 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670615734566454 139.74072462016804 10.43 35.67060780514947 139.74071636670143 10.43 35.67060780514947 139.74071636670143 30.34 35.670615734566454 139.74072462016804 30.34 35.670615734566454 139.74072462016804 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67060780514947 139.74071636670143 10.43 35.67053378537298 139.74082317032307 10.43 35.67053378537298 139.74082317032307 30.34 35.67060780514947 139.74071636670143 30.34 35.67060780514947 139.74071636670143 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053378537298 139.74082317032307 10.43 35.670596471894186 139.7408884147023 10.43 35.670596471894186 139.7408884147023 30.34 35.67053378537298 139.74082317032307 30.34 35.67053378537298 139.74082317032307 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670596471894186 139.7408884147023 10.43 35.67061615409302 139.74086000303808 10.43 35.67061615409302 139.74086000303808 30.34 35.670596471894186 139.7408884147023 30.34 35.670596471894186 139.7408884147023 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061615409302 139.74086000303808 30.34 35.67062524719494 139.7408694592237 30.34 35.67063332356303 139.7408578071154 30.34 35.67066062994215 139.74088621983796 30.34 35.67065200434484 139.740898667914 30.34 35.670704226542185 139.7409530218018 30.34 35.67077685084033 139.7408482190651 30.34 35.67074344628786 139.74081345067663 30.34 35.670728283965836 139.74083531776935 30.34 35.67071440073041 139.7408208631259 30.34 35.67069061169977 139.74079506432045 30.34 35.670704369419255 139.7407752092793 30.34 35.67063250853195 139.7407004204551 30.34 35.670615734566454 139.74072462016804 30.34 35.67060780514947 139.74071636670143 30.34 35.67053378537298 139.74082317032307 30.34 35.670596471894186 139.7408884147023 30.34 35.67061615409302 139.74086000303808 30.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-13b30269-386e-44ea-9ebc-62b5e0cf2a9c"/>
							<gml:surfaceMember xlink:href="#poly-210ffbd7-03d9-4e3b-97a1-685feb52605e"/>
							<gml:surfaceMember xlink:href="#poly-f62e5f4a-3606-4a26-b922-f2e4ba0e8a6e"/>
							<gml:surfaceMember xlink:href="#poly-929468d0-8f1b-4bb9-8f2e-b696e2b012d0"/>
							<gml:surfaceMember xlink:href="#poly-47748649-30cb-43a9-91ac-21ededf7d809"/>
							<gml:surfaceMember xlink:href="#poly-f13692e7-e9d7-4a9e-9d86-e6917c1c25a6"/>
							<gml:surfaceMember xlink:href="#poly-1d370896-edd5-4b5f-b2b7-d52ef6b947c9"/>
							<gml:surfaceMember xlink:href="#poly-b2aec928-7b11-42c1-b6a2-32669b027935"/>
							<gml:surfaceMember xlink:href="#poly-dffe0091-6854-4ad1-81ee-6c9354cea34f"/>
							<gml:surfaceMember xlink:href="#poly-6c2c7ac3-5ae9-45cb-a7fe-5c63f17ce818"/>
							<gml:surfaceMember xlink:href="#poly-ae1fbb7f-b0d9-48d4-b0c7-49aca13ec246"/>
							<gml:surfaceMember xlink:href="#poly-2f308ca1-020e-466e-a107-6a65a5130c1e"/>
							<gml:surfaceMember xlink:href="#poly-cc300380-328b-4be3-88ad-71dd786737ef"/>
							<gml:surfaceMember xlink:href="#poly-1eb33150-fccb-48ec-8611-6f0e229972cd"/>
							<gml:surfaceMember xlink:href="#poly-16708d8c-2f3e-44b6-b6e7-dcbfa5ff859b"/>
							<gml:surfaceMember xlink:href="#poly-24ce9915-5b58-4798-ba4e-eedc9b9ed163"/>
							<gml:surfaceMember xlink:href="#poly-94fb3bc5-5717-4513-8e91-ef44531108d9"/>
							<gml:surfaceMember xlink:href="#poly-e8608fb5-9969-435a-88f7-fc1ff9224cfc"/>
							<gml:surfaceMember xlink:href="#poly-ee814e82-e8a5-4551-9347-7920842f6e0d"/>
							<gml:surfaceMember xlink:href="#poly-adbc20a7-8090-4512-bed4-3a1e57f89ccb"/>
							<gml:surfaceMember xlink:href="#poly-8a8846c0-f5e0-4fe5-bc51-37e0ac65cbb6"/>
							<gml:surfaceMember xlink:href="#poly-3da1a9df-467e-46fe-8fac-66a829cc3402"/>
							<gml:surfaceMember xlink:href="#poly-fa6ef234-2300-4ecc-a3ec-916654c5b67e"/>
							<gml:surfaceMember xlink:href="#poly-41333853-a87e-431c-a007-aa3db3d45f19"/>
							<gml:surfaceMember xlink:href="#poly-799c7e63-dd0d-4b82-9088-18aed387684f"/>
							<gml:surfaceMember xlink:href="#poly-fd8a71f5-3ff4-4438-af9d-9e09bd4899cd"/>
							<gml:surfaceMember xlink:href="#poly-6a86fe5e-e2d3-49f8-b401-b914a3556e7b"/>
							<gml:surfaceMember xlink:href="#poly-5d15ad1a-8590-4c3e-875c-9d40f88a8f9f"/>
							<gml:surfaceMember xlink:href="#poly-061bd510-498d-42e0-bd8b-872c2b345d8b"/>
							<gml:surfaceMember xlink:href="#poly-5773d13a-d28e-4441-ac21-054a57bec296"/>
							<gml:surfaceMember xlink:href="#poly-5fbe90b5-29cd-424b-b5e7-1a33d20361fc"/>
							<gml:surfaceMember xlink:href="#poly-914c1069-d566-4c7c-8f8a-2a1c7a017664"/>
							<gml:surfaceMember xlink:href="#poly-97b1d323-de23-4cac-aea5-216adb194f7e"/>
							<gml:surfaceMember xlink:href="#poly-49bb1eab-fbee-4554-ae26-52a7ee45dc19"/>
							<gml:surfaceMember xlink:href="#poly-21b98144-a13a-4d6a-9621-a1dcc300c868"/>
							<gml:surfaceMember xlink:href="#poly-cf64e4ea-0243-4335-9e15-059a3a1797cb"/>
							<gml:surfaceMember xlink:href="#poly-d097d796-804c-41fc-a6c6-837050be1302"/>
							<gml:surfaceMember xlink:href="#poly-cb0c89af-b687-4eb7-a9b5-3feb4c9fddbe"/>
							<gml:surfaceMember xlink:href="#poly-9cbf12c0-12c2-4231-9ade-f62f3fed5545"/>
							<gml:surfaceMember xlink:href="#poly-de585103-9f5e-4974-8fee-f21d1a3e25b7"/>
							<gml:surfaceMember xlink:href="#poly-45c6847a-d73b-497f-8d61-64083f2904fe"/>
							<gml:surfaceMember xlink:href="#poly-2e05bc95-3bc4-4410-ada7-69bbaa30db2a"/>
							<gml:surfaceMember xlink:href="#poly-c149e99d-1c0c-456d-887c-c4c3fbf934ae"/>
							<gml:surfaceMember xlink:href="#poly-b672ffd1-06f6-4f8e-b779-692d04baea78"/>
							<gml:surfaceMember xlink:href="#poly-190a1d48-2a85-4eaa-ac40-4baabe7b5609"/>
							<gml:surfaceMember xlink:href="#poly-cfa37289-87a9-4a39-b5d2-de2ec11450bd"/>
							<gml:surfaceMember xlink:href="#poly-6f19f7f5-d118-4dfd-bae8-12ba6cdeb5ac"/>
							<gml:surfaceMember xlink:href="#poly-ff2a9862-727d-4b19-8d7f-c1aa3d7ec83d"/>
							<gml:surfaceMember xlink:href="#poly-fc85911a-df8b-49f9-8866-8458ee85308f"/>
							<gml:surfaceMember xlink:href="#poly-d938d0fc-015b-4033-a394-a80ed3b9a935"/>
							<gml:surfaceMember xlink:href="#poly-b661cd2d-3d6e-4188-a502-861eb63255a5"/>
							<gml:surfaceMember xlink:href="#poly-2bb04cd1-1413-4241-9b06-cac023362931"/>
							<gml:surfaceMember xlink:href="#poly-56842c1f-0159-4857-887b-687bd275b124"/>
							<gml:surfaceMember xlink:href="#poly-217e4531-c840-42bb-92b3-04999d45ac66"/>
							<gml:surfaceMember xlink:href="#poly-725d2ca0-b08c-49ab-bb9d-4b44a3e5a0ca"/>
							<gml:surfaceMember xlink:href="#poly-e511f5c4-fe1b-4387-99d4-3b519961634a"/>
							<gml:surfaceMember xlink:href="#poly-20abb607-ae42-40c4-84bf-600a4dc5c496"/>
							<gml:surfaceMember xlink:href="#poly-00ff2f45-4e92-4784-881c-dc6d558e3809"/>
							<gml:surfaceMember xlink:href="#poly-20b1fd54-7456-4e14-aa32-4352d934f12a"/>
							<gml:surfaceMember xlink:href="#poly-ec633e85-5214-4804-9af2-05dcadfc8cb3"/>
							<gml:surfaceMember xlink:href="#poly-c7755cdb-3cf2-426f-983f-baec5ae6a897"/>
							<gml:surfaceMember xlink:href="#poly-40cd8910-04ad-4466-bf55-c926fcf9eb39"/>
							<gml:surfaceMember xlink:href="#poly-abd55722-79f2-4c2f-b13e-03ea35634a60"/>
							<gml:surfaceMember xlink:href="#poly-58f2eff3-57cd-429c-ad9d-219af8da50f1"/>
							<gml:surfaceMember xlink:href="#poly-9f6042f3-9ccf-40c1-a3e0-3ea50f812ae6"/>
							<gml:surfaceMember xlink:href="#poly-0bc15bea-c269-49d0-aad4-7eb127f1e48a"/>
							<gml:surfaceMember xlink:href="#poly-6f52488f-0654-4920-8dbb-1baea76735e7"/>
							<gml:surfaceMember xlink:href="#poly-ca5cd950-0647-45c3-ba15-34868113e7b5"/>
							<gml:surfaceMember xlink:href="#poly-8381b321-a312-4852-91c3-8232b9d59053"/>
							<gml:surfaceMember xlink:href="#poly-3ecbcd8f-00e0-44d8-b89b-82274b27cf2d"/>
							<gml:surfaceMember xlink:href="#poly-bf58c290-8c28-4ff2-ba25-35b49cce70a1"/>
							<gml:surfaceMember xlink:href="#poly-14bd1dca-1583-4da0-9468-f6152de7b450"/>
							<gml:surfaceMember xlink:href="#poly-917dcd1f-8faa-4b2d-be39-75da5fd68d42"/>
							<gml:surfaceMember xlink:href="#poly-a409003e-8ea3-443f-95de-963371c55ec3"/>
							<gml:surfaceMember xlink:href="#poly-ecfa4c66-6aa4-4dc4-8c23-61bd9beaf036"/>
							<gml:surfaceMember xlink:href="#poly-84d6efe5-5287-4331-a17c-d3174dd37c5c"/>
							<gml:surfaceMember xlink:href="#poly-789dfbb0-ee8a-4b5e-b99e-ab3b78d9de94"/>
							<gml:surfaceMember xlink:href="#poly-b746542f-90df-499c-9b2f-c7934052c238"/>
							<gml:surfaceMember xlink:href="#poly-25c3380c-6446-4892-9465-698238d11b39"/>
							<gml:surfaceMember xlink:href="#poly-221143dc-217d-444d-abe1-1e9793f73a62"/>
							<gml:surfaceMember xlink:href="#poly-48fc3223-d943-4dc0-8b7b-5044ed2aae0f"/>
							<gml:surfaceMember xlink:href="#poly-e25c8f18-24db-4ebd-a3c3-10f954206c92"/>
							<gml:surfaceMember xlink:href="#poly-f5926d5d-1b84-4d35-86e5-7ea5afbe9804"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_2fe4f5ce-a0be-4e93-9ca6-c2641b19b826_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-598105dd-4d6a-4d24-a027-bdc78c3f95a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67069061169977 139.74079506432042 10.43 35.67070436941925 139.7407752092793 10.43 35.67072857262691 139.7408004111047 10.43 35.670714400730404 139.7408208631259 10.43 35.67069061169977 139.74079506432042 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13b12f00-0e05-4ee3-8f3f-96ac60740179">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13b12f00-0e05-4ee3-8f3f-96ac60740179_0">
											<gml:posList>35.67070436941925 139.7407752092793 33.31 35.67070436941925 139.7407752092793 10.43 35.67069061169977 139.74079506432042 10.43 35.67069061169977 139.74079506432042 33.31 35.67070436941925 139.7407752092793 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7accf519-2a42-4922-81b8-f2550edc05ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7accf519-2a42-4922-81b8-f2550edc05ce_0">
											<gml:posList>35.67072857262691 139.7408004111047 33.31 35.67072857262691 139.7408004111047 10.43 35.67070436941925 139.7407752092793 10.43 35.67070436941925 139.7407752092793 33.31 35.67072857262691 139.7408004111047 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ed198cd-598a-4c57-984c-5d77bd02a272">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ed198cd-598a-4c57-984c-5d77bd02a272_0">
											<gml:posList>35.670714400730404 139.7408208631259 33.31 35.67072857262691 139.7408004111047 33.31 35.67070436941925 139.7407752092793 33.31 35.67069061169977 139.74079506432042 33.31 35.670714400730404 139.7408208631259 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21fad2a9-720a-4cb9-9491-200a01882a43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21fad2a9-720a-4cb9-9491-200a01882a43_0">
											<gml:posList>35.67069061169977 139.74079506432042 33.31 35.67069061169977 139.74079506432042 10.43 35.670714400730404 139.7408208631259 10.43 35.670714400730404 139.7408208631259 33.31 35.67069061169977 139.74079506432042 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db72e5fa-82f7-4d58-ba5e-32d64c325488">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db72e5fa-82f7-4d58-ba5e-32d64c325488_0">
											<gml:posList>35.670714400730404 139.7408208631259 33.31 35.670714400730404 139.7408208631259 10.43 35.67072857262691 139.7408004111047 10.43 35.67072857262691 139.7408004111047 33.31 35.670714400730404 139.7408208631259 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-13b30269-386e-44ea-9ebc-62b5e0cf2a9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13b30269-386e-44ea-9ebc-62b5e0cf2a9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13b30269-386e-44ea-9ebc-62b5e0cf2a9c">
											<gml:posList>35.67061615409299 139.74086000303808 10.43 35.67059647189416 139.7408884147023 10.43 35.670533785372974 139.74082317032307 10.43 35.67060780514946 139.7407163667014 10.43 35.67061573456647 139.74072462016804 10.43 35.67063250853193 139.74070042045508 10.43 35.67070436941925 139.7407752092793 10.43 35.67069061169977 139.74079506432042 10.43 35.670714400730404 139.7408208631259 10.43 35.67072828396585 139.74083531776935 10.43 35.670743446287844 139.74081345067663 10.43 35.67077685084032 139.7408482190651 10.43 35.670704226542185 139.7409530218018 10.43 35.67065200434483 139.740898667914 10.43 35.67066062994214 139.74088621983796 10.43 35.670633323563 139.74085780711536 10.43 35.670625247194934 139.7408694592237 10.43 35.67061615409299 139.74086000303808 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-210ffbd7-03d9-4e3b-97a1-685feb52605e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-210ffbd7-03d9-4e3b-97a1-685feb52605e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-210ffbd7-03d9-4e3b-97a1-685feb52605e">
											<gml:posList>35.67057958473343 139.74080048363666 24.454 35.67063250853193 139.74070042045508 21.878 35.67061573456647 139.74072462016804 21.878 35.67057958473343 139.74080048363666 24.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f62e5f4a-3606-4a26-b922-f2e4ba0e8a6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f62e5f4a-3606-4a26-b922-f2e4ba0e8a6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f62e5f4a-3606-4a26-b922-f2e4ba0e8a6e">
											<gml:posList>35.67057958473343 139.74080048363666 24.454 35.67061573456647 139.74072462016804 21.878 35.670570274659966 139.74079019924326 21.878 35.67057958473343 139.74080048363666 24.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-929468d0-8f1b-4bb9-8f2e-b696e2b012d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-929468d0-8f1b-4bb9-8f2e-b696e2b012d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-929468d0-8f1b-4bb9-8f2e-b696e2b012d0">
											<gml:posList>35.670533785372974 139.74082317032307 21.878 35.67054170576905 139.74083142380306 21.878 35.670570274659966 139.74079019924326 21.878 35.67061573456647 139.74072462016804 21.878 35.67060780514946 139.7407163667014 21.878 35.670533785372974 139.74082317032307 21.878</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47748649-30cb-43a9-91ac-21ededf7d809">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47748649-30cb-43a9-91ac-21ededf7d809">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47748649-30cb-43a9-91ac-21ededf7d809">
											<gml:posList>35.67057958473343 139.74080048363666 24.454 35.670570274659966 139.74079019924326 24.444 35.670570640387325 139.7407969370554 24.445 35.67057958473343 139.74080048363666 24.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f13692e7-e9d7-4a9e-9d86-e6917c1c25a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f13692e7-e9d7-4a9e-9d86-e6917c1c25a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f13692e7-e9d7-4a9e-9d86-e6917c1c25a6">
											<gml:posList>35.670570640387325 139.7407969370554 24.445 35.670577036566286 139.74080402138924 24.445 35.67057958473343 139.74080048363666 24.454 35.670570640387325 139.7407969370554 24.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d370896-edd5-4b5f-b2b7-d52ef6b947c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d370896-edd5-4b5f-b2b7-d52ef6b947c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d370896-edd5-4b5f-b2b7-d52ef6b947c9">
											<gml:posList>35.67054170576905 139.74083142380306 24.444 35.67054712260048 139.74083087628568 24.445 35.670570640387325 139.7407969370554 24.445 35.670570274659966 139.74079019924326 24.444 35.67054170576905 139.74083142380306 24.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b2aec928-7b11-42c1-b6a2-32669b027935">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2aec928-7b11-42c1-b6a2-32669b027935">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2aec928-7b11-42c1-b6a2-32669b027935">
											<gml:posList>35.67057958473343 139.74080048363666 24.454 35.670577036566286 139.74080402138924 24.445 35.67062793373875 139.74085831041515 24.445 35.67057958473343 139.74080048363666 24.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dffe0091-6854-4ad1-81ee-6c9354cea34f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dffe0091-6854-4ad1-81ee-6c9354cea34f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dffe0091-6854-4ad1-81ee-6c9354cea34f">
											<gml:posList>35.67062793373875 139.74085831041515 24.445 35.670633323563 139.74085780711536 24.444 35.67057958473343 139.74080048363666 24.454 35.67062793373875 139.74085831041515 24.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c2c7ac3-5ae9-45cb-a7fe-5c63f17ce818">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c2c7ac3-5ae9-45cb-a7fe-5c63f17ce818">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c2c7ac3-5ae9-45cb-a7fe-5c63f17ce818">
											<gml:posList>35.67061569830828 139.7408533647423 24.192 35.670624800432954 139.740862831963 24.192 35.67062793373875 139.74085831041515 24.192 35.670577036566286 139.74080402138924 24.192 35.670570640387325 139.7407969370554 24.192 35.67054712260048 139.74083087628568 24.192 35.67059601611102 139.740881776408 24.192 35.67061569830828 139.7408533647423 24.192</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae1fbb7f-b0d9-48d4-b0c7-49aca13ec246">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae1fbb7f-b0d9-48d4-b0c7-49aca13ec246">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae1fbb7f-b0d9-48d4-b0c7-49aca13ec246">
											<gml:posList>35.67059647189416 139.7408884147023 24.444 35.67059601611102 139.740881776408 24.445 35.67054712260048 139.74083087628568 24.445 35.67054170576905 139.74083142380306 24.444 35.67059647189416 139.7408884147023 24.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2f308ca1-020e-466e-a107-6a65a5130c1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f308ca1-020e-466e-a107-6a65a5130c1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f308ca1-020e-466e-a107-6a65a5130c1e">
											<gml:posList>35.67061615409299 139.74086000303808 24.444 35.670625247194934 139.7408694592237 24.444 35.670624800432954 139.740862831963 24.445 35.67061569830828 139.7408533647423 24.445 35.67061615409299 139.74086000303808 24.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc300380-328b-4be3-88ad-71dd786737ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc300380-328b-4be3-88ad-71dd786737ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc300380-328b-4be3-88ad-71dd786737ef">
											<gml:posList>35.67061615409299 139.74086000303808 24.444 35.67061569830828 139.7408533647423 24.445 35.67059601611102 139.740881776408 24.445 35.67059647189416 139.7408884147023 24.444 35.67061615409299 139.74086000303808 24.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1eb33150-fccb-48ec-8611-6f0e229972cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1eb33150-fccb-48ec-8611-6f0e229972cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1eb33150-fccb-48ec-8611-6f0e229972cd">
											<gml:posList>35.67057958473343 139.74080048363666 24.454 35.67067518665653 139.74074484355077 33.31 35.67063250853193 139.74070042045508 21.878 35.67057958473343 139.74080048363666 24.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16708d8c-2f3e-44b6-b6e7-dcbfa5ff859b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16708d8c-2f3e-44b6-b6e7-dcbfa5ff859b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16708d8c-2f3e-44b6-b6e7-dcbfa5ff859b">
											<gml:posList>35.67068574117095 139.74075583347872 33.31 35.67067518665653 139.74074484355077 33.31 35.67067546040618 139.74074918443063 33.31 35.67068411149614 139.74075818822263 33.31 35.67068574117095 139.74075583347872 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24ce9915-5b58-4798-ba4e-eedc9b9ed163">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24ce9915-5b58-4798-ba4e-eedc9b9ed163">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24ce9915-5b58-4798-ba4e-eedc9b9ed163">
											<gml:posList>35.67068574117095 139.74075583347872 37.41 35.670685932820064 139.74075890412925 37.41 35.67070185477753 139.74077545520095 37.41 35.67070436941925 139.7407752092793 37.41 35.67068574117095 139.74075583347872 37.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94fb3bc5-5717-4513-8e91-ef44531108d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94fb3bc5-5717-4513-8e91-ef44531108d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94fb3bc5-5717-4513-8e91-ef44531108d9">
											<gml:posList>35.67066161114228 139.74079065718038 37.41 35.67066411676184 139.74079040022346 37.41 35.670685932820064 139.74075890412925 37.41 35.67068574117095 139.74075583347872 37.41 35.67066161114228 139.74079065718038 37.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8608fb5-9969-435a-88f7-fc1ff9224cfc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8608fb5-9969-435a-88f7-fc1ff9224cfc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8608fb5-9969-435a-88f7-fc1ff9224cfc">
											<gml:posList>35.67070185477753 139.74077545520095 36.989 35.670685932820064 139.74075890412925 36.989 35.67066411676184 139.74079040022346 36.989 35.67068002970979 139.7408069623536 36.989 35.67070185477753 139.74077545520095 36.989</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee814e82-e8a5-4551-9347-7920842f6e0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee814e82-e8a5-4551-9347-7920842f6e0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee814e82-e8a5-4551-9347-7920842f6e0d">
											<gml:posList>35.67057958473343 139.74080048363666 24.454 35.6706112047007 139.74083541970205 33.31 35.67067518665653 139.74074484355077 33.31 35.67057958473343 139.74080048363666 24.454</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-adbc20a7-8090-4512-bed4-3a1e57f89ccb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adbc20a7-8090-4512-bed4-3a1e57f89ccb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adbc20a7-8090-4512-bed4-3a1e57f89ccb">
											<gml:posList>35.6706112047007 139.74083541970205 33.31 35.67061479188221 139.740835051036 33.31 35.67065006031052 139.74078513631812 33.31 35.67067546040618 139.74074918443063 33.31 35.67067518665653 139.74074484355077 33.31 35.6706112047007 139.74083541970205 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a8846c0-f5e0-4fe5-bc51-37e0ac65cbb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a8846c0-f5e0-4fe5-bc51-37e0ac65cbb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a8846c0-f5e0-4fe5-bc51-37e0ac65cbb6">
											<gml:posList>35.67070436941925 139.7407752092793 37.41 35.67070185477753 139.74077545520095 37.41 35.67068002970979 139.7408069623536 37.41 35.67068023037982 139.74081004403996 37.41 35.67070436941925 139.7407752092793 37.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3da1a9df-467e-46fe-8fac-66a829cc3402">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3da1a9df-467e-46fe-8fac-66a829cc3402">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3da1a9df-467e-46fe-8fac-66a829cc3402">
											<gml:posList>35.67068023037982 139.74081004403996 37.41 35.67068002970979 139.7408069623536 37.41 35.67066411676184 139.74079040022346 37.41 35.67066161114228 139.74079065718038 37.41 35.67068023037982 139.74081004403996 37.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa6ef234-2300-4ecc-a3ec-916654c5b67e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa6ef234-2300-4ecc-a3ec-916654c5b67e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa6ef234-2300-4ecc-a3ec-916654c5b67e">
											<gml:posList>35.67069061169977 139.74079506432042 33.31 35.67068894601175 139.74079747433677 33.31 35.67071274400468 139.74082320685426 33.31 35.670714400730404 139.7408208631259 33.31 35.67069061169977 139.74079506432042 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41333853-a87e-431c-a007-aa3db3d45f19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41333853-a87e-431c-a007-aa3db3d45f19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41333853-a87e-431c-a007-aa3db3d45f19">
											<gml:posList>35.67061479188221 139.740835051036 32.611 35.67062638352655 139.74084676882654 32.611 35.6706604706442 139.74079618164583 32.611 35.67065006031052 139.74078513631812 32.611 35.67061479188221 139.740835051036 32.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-799c7e63-dd0d-4b82-9088-18aed387684f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-799c7e63-dd0d-4b82-9088-18aed387684f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-799c7e63-dd0d-4b82-9088-18aed387684f">
											<gml:posList>35.67072828396585 139.74083531776935 33.31 35.67072856673444 139.74083966968826 33.31 35.67074372906571 139.7408178136426 33.31 35.670743446287844 139.74081345067663 33.31 35.67072828396585 139.74083531776935 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd8a71f5-3ff4-4438-af9d-9e09bd4899cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd8a71f5-3ff4-4438-af9d-9e09bd4899cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd8a71f5-3ff4-4438-af9d-9e09bd4899cd">
											<gml:posList>35.67072828396585 139.74083531776935 33.31 35.670714400730404 139.7408208631259 33.31 35.67071274400468 139.74082320685426 33.31 35.67072856673444 139.74083966968826 33.31 35.67072828396585 139.74083531776935 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a86fe5e-e2d3-49f8-b401-b914a3556e7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a86fe5e-e2d3-49f8-b401-b914a3556e7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a86fe5e-e2d3-49f8-b401-b914a3556e7b">
											<gml:posList>35.670743446287844 139.74081345067663 33.31 35.67074372906571 139.7408178136426 33.31 35.67077329069154 139.74084857665386 33.31 35.67077685084032 139.7408482190651 33.31 35.670743446287844 139.74081345067663 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d15ad1a-8590-4c3e-875c-9d40f88a8f9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d15ad1a-8590-4c3e-875c-9d40f88a8f9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d15ad1a-8590-4c3e-875c-9d40f88a8f9f">
											<gml:posList>35.670633323563 139.74085780711536 33.31 35.67063494421757 139.74085544133908 33.31 35.67062638352655 139.74084676882654 33.31 35.67061479188221 139.740835051036 33.31 35.6706112047007 139.74083541970205 33.31 35.670633323563 139.74085780711536 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-061bd510-498d-42e0-bd8b-872c2b345d8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-061bd510-498d-42e0-bd8b-872c2b345d8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-061bd510-498d-42e0-bd8b-872c2b345d8b">
											<gml:posList>35.670703925750246 139.74094866990455 33.025 35.67077329069154 139.74084857665386 33.025 35.67074372906571 139.7408178136426 33.025 35.67072856673444 139.74083966968826 33.025 35.67071274400468 139.74082320685426 33.025 35.67068894601175 139.74079747433677 33.025 35.67068023037982 139.74081004403996 33.025 35.67066161114228 139.74079065718038 33.025 35.67068411149614 139.74075818822263 33.025 35.67067546040618 139.74074918443063 33.025 35.67065006031052 139.74078513631812 33.025 35.6706604706442 139.74079618164583 33.025 35.67062638352655 139.74084676882654 33.025 35.67063494421757 139.74085544133908 33.025 35.67066418107738 139.7408858622618 33.025 35.67065555548011 139.7408983103384 33.025 35.670703925750246 139.74094866990455 33.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5773d13a-d28e-4441-ac21-054a57bec296">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5773d13a-d28e-4441-ac21-054a57bec296">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5773d13a-d28e-4441-ac21-054a57bec296">
											<gml:posList>35.670633323563 139.74085780711536 24.444 35.67062793373875 139.74085831041515 24.445 35.670624800432954 139.740862831963 24.445 35.670625247194934 139.7408694592237 24.444 35.670633323563 139.74085780711536 24.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5fbe90b5-29cd-424b-b5e7-1a33d20361fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fbe90b5-29cd-424b-b5e7-1a33d20361fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fbe90b5-29cd-424b-b5e7-1a33d20361fc">
											<gml:posList>35.67066062994214 139.74088621983796 33.31 35.67066418107738 139.7408858622618 33.31 35.67063494421757 139.74085544133908 33.31 35.670633323563 139.74085780711536 33.31 35.67066062994214 139.74088621983796 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-914c1069-d566-4c7c-8f8a-2a1c7a017664">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-914c1069-d566-4c7c-8f8a-2a1c7a017664">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-914c1069-d566-4c7c-8f8a-2a1c7a017664">
											<gml:posList>35.67066062994214 139.74088621983796 33.31 35.67065200434483 139.740898667914 33.31 35.67065555548011 139.7408983103384 33.31 35.67066418107738 139.7408858622618 33.31 35.67066062994214 139.74088621983796 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97b1d323-de23-4cac-aea5-216adb194f7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97b1d323-de23-4cac-aea5-216adb194f7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97b1d323-de23-4cac-aea5-216adb194f7e">
											<gml:posList>35.67077685084032 139.7408482190651 33.31 35.67077329069154 139.74084857665386 33.31 35.670703925750246 139.74094866990455 33.31 35.670704226542185 139.7409530218018 33.31 35.67077685084032 139.7408482190651 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-49bb1eab-fbee-4554-ae26-52a7ee45dc19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49bb1eab-fbee-4554-ae26-52a7ee45dc19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49bb1eab-fbee-4554-ae26-52a7ee45dc19">
											<gml:posList>35.670704226542185 139.7409530218018 33.31 35.670703925750246 139.74094866990455 33.31 35.67065555548011 139.7408983103384 33.31 35.67065200434483 139.740898667914 33.31 35.670704226542185 139.7409530218018 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21b98144-a13a-4d6a-9621-a1dcc300c868">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21b98144-a13a-4d6a-9621-a1dcc300c868">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21b98144-a13a-4d6a-9621-a1dcc300c868">
											<gml:posList>35.67066411676184 139.74079040022346 37.41 35.67066411676184 139.74079040022346 36.989 35.670685932820064 139.74075890412925 36.989 35.670685932820064 139.74075890412925 37.41 35.67066411676184 139.74079040022346 37.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf64e4ea-0243-4335-9e15-059a3a1797cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf64e4ea-0243-4335-9e15-059a3a1797cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf64e4ea-0243-4335-9e15-059a3a1797cb">
											<gml:posList>35.67070185477753 139.74077545520095 37.41 35.67070185477753 139.74077545520095 36.989 35.67068002970979 139.7408069623536 36.989 35.67068002970979 139.7408069623536 37.41 35.67070185477753 139.74077545520095 37.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d097d796-804c-41fc-a6c6-837050be1302">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d097d796-804c-41fc-a6c6-837050be1302">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d097d796-804c-41fc-a6c6-837050be1302">
											<gml:posList>35.670577036566286 139.74080402138924 24.445 35.670577036566286 139.74080402138924 24.192 35.67062793373875 139.74085831041515 24.192 35.67062793373875 139.74085831041515 24.445 35.670577036566286 139.74080402138924 24.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb0c89af-b687-4eb7-a9b5-3feb4c9fddbe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb0c89af-b687-4eb7-a9b5-3feb4c9fddbe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb0c89af-b687-4eb7-a9b5-3feb4c9fddbe">
											<gml:posList>35.67061573456647 139.74072462016804 10.43 35.67060780514946 139.7407163667014 10.43 35.67060780514946 139.7407163667014 21.878 35.67061573456647 139.74072462016804 21.878 35.67061573456647 139.74072462016804 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cbf12c0-12c2-4231-9ade-f62f3fed5545">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cbf12c0-12c2-4231-9ade-f62f3fed5545">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cbf12c0-12c2-4231-9ade-f62f3fed5545">
											<gml:posList>35.67063250853193 139.74070042045508 10.43 35.67061573456647 139.74072462016804 10.43 35.67061573456647 139.74072462016804 21.878 35.67063250853193 139.74070042045508 21.878 35.67063250853193 139.74070042045508 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de585103-9f5e-4974-8fee-f21d1a3e25b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de585103-9f5e-4974-8fee-f21d1a3e25b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de585103-9f5e-4974-8fee-f21d1a3e25b7">
											<gml:posList>35.67054170576905 139.74083142380306 24.444 35.670570274659966 139.74079019924326 24.444 35.670570274659966 139.74079019924326 21.878 35.67054170576905 139.74083142380306 21.878 35.67054170576905 139.74083142380306 24.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45c6847a-d73b-497f-8d61-64083f2904fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45c6847a-d73b-497f-8d61-64083f2904fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45c6847a-d73b-497f-8d61-64083f2904fe">
											<gml:posList>35.67054712260048 139.74083087628568 24.445 35.67054712260048 139.74083087628568 24.192 35.670570640387325 139.7407969370554 24.192 35.670570640387325 139.7407969370554 24.445 35.67054712260048 139.74083087628568 24.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e05bc95-3bc4-4410-ada7-69bbaa30db2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e05bc95-3bc4-4410-ada7-69bbaa30db2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e05bc95-3bc4-4410-ada7-69bbaa30db2a">
											<gml:posList>35.67059647189416 139.7408884147023 10.43 35.67059647189416 139.7408884147023 24.444 35.67054170576905 139.74083142380306 24.444 35.67054170576905 139.74083142380306 21.878 35.670533785372974 139.74082317032307 21.878 35.670533785372974 139.74082317032307 10.43 35.67059647189416 139.7408884147023 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c149e99d-1c0c-456d-887c-c4c3fbf934ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c149e99d-1c0c-456d-887c-c4c3fbf934ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c149e99d-1c0c-456d-887c-c4c3fbf934ae">
											<gml:posList>35.67060780514946 139.7407163667014 10.43 35.670533785372974 139.74082317032307 10.43 35.670533785372974 139.74082317032307 21.878 35.67060780514946 139.7407163667014 21.878 35.67060780514946 139.7407163667014 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b672ffd1-06f6-4f8e-b779-692d04baea78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b672ffd1-06f6-4f8e-b779-692d04baea78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b672ffd1-06f6-4f8e-b779-692d04baea78">
											<gml:posList>35.67059601611102 139.740881776408 24.445 35.67059601611102 139.740881776408 24.192 35.67054712260048 139.74083087628568 24.192 35.67054712260048 139.74083087628568 24.445 35.67059601611102 139.740881776408 24.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-190a1d48-2a85-4eaa-ac40-4baabe7b5609">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-190a1d48-2a85-4eaa-ac40-4baabe7b5609">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-190a1d48-2a85-4eaa-ac40-4baabe7b5609">
											<gml:posList>35.670570640387325 139.7407969370554 24.445 35.670570640387325 139.7407969370554 24.192 35.670577036566286 139.74080402138924 24.192 35.670577036566286 139.74080402138924 24.445 35.670570640387325 139.7407969370554 24.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfa37289-87a9-4a39-b5d2-de2ec11450bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfa37289-87a9-4a39-b5d2-de2ec11450bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfa37289-87a9-4a39-b5d2-de2ec11450bd">
											<gml:posList>35.670570274659966 139.74079019924326 21.878 35.670570274659966 139.74079019924326 24.444 35.67057958473343 139.74080048363666 24.454 35.670570274659966 139.74079019924326 21.878</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f19f7f5-d118-4dfd-bae8-12ba6cdeb5ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f19f7f5-d118-4dfd-bae8-12ba6cdeb5ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f19f7f5-d118-4dfd-bae8-12ba6cdeb5ac">
											<gml:posList>35.67061569830828 139.7408533647423 24.445 35.67061569830828 139.7408533647423 24.192 35.67059601611102 139.740881776408 24.192 35.67059601611102 139.740881776408 24.445 35.67061569830828 139.7408533647423 24.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff2a9862-727d-4b19-8d7f-c1aa3d7ec83d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff2a9862-727d-4b19-8d7f-c1aa3d7ec83d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff2a9862-727d-4b19-8d7f-c1aa3d7ec83d">
											<gml:posList>35.67059647189416 139.7408884147023 10.43 35.67061615409299 139.74086000303808 10.43 35.67061615409299 139.74086000303808 24.444 35.67059647189416 139.7408884147023 24.444 35.67059647189416 139.7408884147023 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc85911a-df8b-49f9-8866-8458ee85308f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc85911a-df8b-49f9-8866-8458ee85308f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc85911a-df8b-49f9-8866-8458ee85308f">
											<gml:posList>35.6706112047007 139.74083541970205 33.31 35.67057958473343 139.74080048363666 24.454 35.670633323563 139.74085780711536 24.444 35.6706112047007 139.74083541970205 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d938d0fc-015b-4033-a394-a80ed3b9a935">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d938d0fc-015b-4033-a394-a80ed3b9a935">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d938d0fc-015b-4033-a394-a80ed3b9a935">
											<gml:posList>35.670624800432954 139.740862831963 24.445 35.670624800432954 139.740862831963 24.192 35.67061569830828 139.7408533647423 24.192 35.67061569830828 139.7408533647423 24.445 35.670624800432954 139.740862831963 24.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b661cd2d-3d6e-4188-a502-861eb63255a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b661cd2d-3d6e-4188-a502-861eb63255a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b661cd2d-3d6e-4188-a502-861eb63255a5">
											<gml:posList>35.67061479188221 139.740835051036 33.31 35.67062638352655 139.74084676882654 33.31 35.67062638352655 139.74084676882654 33.025 35.67062638352655 139.74084676882654 32.611 35.67061479188221 139.740835051036 32.611 35.67061479188221 139.740835051036 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2bb04cd1-1413-4241-9b06-cac023362931">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2bb04cd1-1413-4241-9b06-cac023362931">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2bb04cd1-1413-4241-9b06-cac023362931">
											<gml:posList>35.67061615409299 139.74086000303808 10.43 35.670625247194934 139.7408694592237 10.43 35.670625247194934 139.7408694592237 24.444 35.67061615409299 139.74086000303808 24.444 35.67061615409299 139.74086000303808 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56842c1f-0159-4857-887b-687bd275b124">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56842c1f-0159-4857-887b-687bd275b124">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56842c1f-0159-4857-887b-687bd275b124">
											<gml:posList>35.670633323563 139.74085780711536 24.444 35.670633323563 139.74085780711536 33.31 35.6706112047007 139.74083541970205 33.31 35.670633323563 139.74085780711536 24.444</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-217e4531-c840-42bb-92b3-04999d45ac66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-217e4531-c840-42bb-92b3-04999d45ac66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-217e4531-c840-42bb-92b3-04999d45ac66">
											<gml:posList>35.67062793373875 139.74085831041515 24.445 35.67062793373875 139.74085831041515 24.192 35.670624800432954 139.740862831963 24.192 35.670624800432954 139.740862831963 24.445 35.67062793373875 139.74085831041515 24.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-725d2ca0-b08c-49ab-bb9d-4b44a3e5a0ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-725d2ca0-b08c-49ab-bb9d-4b44a3e5a0ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-725d2ca0-b08c-49ab-bb9d-4b44a3e5a0ca">
											<gml:posList>35.670625247194934 139.7408694592237 10.43 35.670633323563 139.74085780711536 10.43 35.670633323563 139.74085780711536 24.444 35.670625247194934 139.7408694592237 24.444 35.670625247194934 139.7408694592237 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e511f5c4-fe1b-4387-99d4-3b519961634a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e511f5c4-fe1b-4387-99d4-3b519961634a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e511f5c4-fe1b-4387-99d4-3b519961634a">
											<gml:posList>35.67063494421757 139.74085544133908 33.31 35.67063494421757 139.74085544133908 33.025 35.67062638352655 139.74084676882654 33.025 35.67062638352655 139.74084676882654 33.31 35.67063494421757 139.74085544133908 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20abb607-ae42-40c4-84bf-600a4dc5c496">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20abb607-ae42-40c4-84bf-600a4dc5c496">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20abb607-ae42-40c4-84bf-600a4dc5c496">
											<gml:posList>35.67061479188221 139.740835051036 33.31 35.67061479188221 139.740835051036 32.611 35.67065006031052 139.74078513631812 32.611 35.67065006031052 139.74078513631812 33.025 35.67065006031052 139.74078513631812 33.31 35.67061479188221 139.740835051036 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00ff2f45-4e92-4784-881c-dc6d558e3809">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00ff2f45-4e92-4784-881c-dc6d558e3809">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00ff2f45-4e92-4784-881c-dc6d558e3809">
											<gml:posList>35.67062638352655 139.74084676882654 33.025 35.6706604706442 139.74079618164583 33.025 35.6706604706442 139.74079618164583 32.611 35.67062638352655 139.74084676882654 32.611 35.67062638352655 139.74084676882654 33.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20b1fd54-7456-4e14-aa32-4352d934f12a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20b1fd54-7456-4e14-aa32-4352d934f12a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20b1fd54-7456-4e14-aa32-4352d934f12a">
											<gml:posList>35.67066062994214 139.74088621983796 33.31 35.670633323563 139.74085780711536 33.31 35.670633323563 139.74085780711536 24.444 35.670633323563 139.74085780711536 10.43 35.67066062994214 139.74088621983796 10.43 35.67066062994214 139.74088621983796 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec633e85-5214-4804-9af2-05dcadfc8cb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec633e85-5214-4804-9af2-05dcadfc8cb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec633e85-5214-4804-9af2-05dcadfc8cb3">
											<gml:posList>35.67066418107738 139.7408858622618 33.31 35.67066418107738 139.7408858622618 33.025 35.67063494421757 139.74085544133908 33.025 35.67063494421757 139.74085544133908 33.31 35.67066418107738 139.7408858622618 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7755cdb-3cf2-426f-983f-baec5ae6a897">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7755cdb-3cf2-426f-983f-baec5ae6a897">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7755cdb-3cf2-426f-983f-baec5ae6a897">
											<gml:posList>35.6706604706442 139.74079618164583 33.025 35.67065006031052 139.74078513631812 33.025 35.67065006031052 139.74078513631812 32.611 35.6706604706442 139.74079618164583 32.611 35.6706604706442 139.74079618164583 33.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40cd8910-04ad-4466-bf55-c926fcf9eb39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40cd8910-04ad-4466-bf55-c926fcf9eb39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40cd8910-04ad-4466-bf55-c926fcf9eb39">
											<gml:posList>35.67066062994214 139.74088621983796 10.43 35.67065200434483 139.740898667914 10.43 35.67065200434483 139.740898667914 33.31 35.67066062994214 139.74088621983796 33.31 35.67066062994214 139.74088621983796 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-abd55722-79f2-4c2f-b13e-03ea35634a60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abd55722-79f2-4c2f-b13e-03ea35634a60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abd55722-79f2-4c2f-b13e-03ea35634a60">
											<gml:posList>35.67065555548011 139.7408983103384 33.31 35.67065555548011 139.7408983103384 33.025 35.67066418107738 139.7408858622618 33.025 35.67066418107738 139.7408858622618 33.31 35.67065555548011 139.7408983103384 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58f2eff3-57cd-429c-ad9d-219af8da50f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58f2eff3-57cd-429c-ad9d-219af8da50f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58f2eff3-57cd-429c-ad9d-219af8da50f1">
											<gml:posList>35.67065006031052 139.74078513631812 33.31 35.67065006031052 139.74078513631812 33.025 35.67067546040618 139.74074918443063 33.025 35.67067546040618 139.74074918443063 33.31 35.67065006031052 139.74078513631812 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9f6042f3-9ccf-40c1-a3e0-3ea50f812ae6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f6042f3-9ccf-40c1-a3e0-3ea50f812ae6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f6042f3-9ccf-40c1-a3e0-3ea50f812ae6">
											<gml:posList>35.67070436941925 139.7407752092793 37.41 35.67070436941925 139.7407752092793 10.43 35.67063250853193 139.74070042045508 10.43 35.67063250853193 139.74070042045508 21.878 35.67067518665653 139.74074484355077 33.31 35.67068574117095 139.74075583347872 33.31 35.67068574117095 139.74075583347872 37.41 35.67070436941925 139.7407752092793 37.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bc15bea-c269-49d0-aad4-7eb127f1e48a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bc15bea-c269-49d0-aad4-7eb127f1e48a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bc15bea-c269-49d0-aad4-7eb127f1e48a">
											<gml:posList>35.67066161114228 139.74079065718038 33.025 35.67068023037982 139.74081004403996 33.025 35.67068023037982 139.74081004403996 37.41 35.67066161114228 139.74079065718038 37.41 35.67066161114228 139.74079065718038 33.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f52488f-0654-4920-8dbb-1baea76735e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f52488f-0654-4920-8dbb-1baea76735e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f52488f-0654-4920-8dbb-1baea76735e7">
											<gml:posList>35.67068002970979 139.7408069623536 37.41 35.67068002970979 139.7408069623536 36.989 35.67066411676184 139.74079040022346 36.989 35.67066411676184 139.74079040022346 37.41 35.67068002970979 139.7408069623536 37.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca5cd950-0647-45c3-ba15-34868113e7b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca5cd950-0647-45c3-ba15-34868113e7b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca5cd950-0647-45c3-ba15-34868113e7b5">
											<gml:posList>35.67066161114228 139.74079065718038 33.025 35.67066161114228 139.74079065718038 37.41 35.67068574117095 139.74075583347872 37.41 35.67068574117095 139.74075583347872 33.31 35.67068411149614 139.74075818822263 33.31 35.67068411149614 139.74075818822263 33.025 35.67066161114228 139.74079065718038 33.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8381b321-a312-4852-91c3-8232b9d59053">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8381b321-a312-4852-91c3-8232b9d59053">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8381b321-a312-4852-91c3-8232b9d59053">
											<gml:posList>35.67065200434483 139.740898667914 10.43 35.670704226542185 139.7409530218018 10.43 35.670704226542185 139.7409530218018 33.31 35.67065200434483 139.740898667914 33.31 35.67065200434483 139.740898667914 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ecbcd8f-00e0-44d8-b89b-82274b27cf2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ecbcd8f-00e0-44d8-b89b-82274b27cf2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ecbcd8f-00e0-44d8-b89b-82274b27cf2d">
											<gml:posList>35.670703925750246 139.74094866990455 33.31 35.670703925750246 139.74094866990455 33.025 35.67065555548011 139.7408983103384 33.025 35.67065555548011 139.7408983103384 33.31 35.670703925750246 139.74094866990455 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf58c290-8c28-4ff2-ba25-35b49cce70a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf58c290-8c28-4ff2-ba25-35b49cce70a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf58c290-8c28-4ff2-ba25-35b49cce70a1">
											<gml:posList>35.67067546040618 139.74074918443063 33.31 35.67067546040618 139.74074918443063 33.025 35.67068411149614 139.74075818822263 33.025 35.67068411149614 139.74075818822263 33.31 35.67067546040618 139.74074918443063 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14bd1dca-1583-4da0-9468-f6152de7b450">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14bd1dca-1583-4da0-9468-f6152de7b450">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14bd1dca-1583-4da0-9468-f6152de7b450">
											<gml:posList>35.67068023037982 139.74081004403996 33.025 35.67068894601175 139.74079747433677 33.025 35.67068894601175 139.74079747433677 33.31 35.67069061169977 139.74079506432042 33.31 35.67069061169977 139.74079506432042 10.43 35.67070436941925 139.7407752092793 10.43 35.67070436941925 139.7407752092793 37.41 35.67068023037982 139.74081004403996 37.41 35.67068023037982 139.74081004403996 33.025</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-917dcd1f-8faa-4b2d-be39-75da5fd68d42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-917dcd1f-8faa-4b2d-be39-75da5fd68d42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-917dcd1f-8faa-4b2d-be39-75da5fd68d42">
											<gml:posList>35.670685932820064 139.74075890412925 37.41 35.670685932820064 139.74075890412925 36.989 35.67070185477753 139.74077545520095 36.989 35.67070185477753 139.74077545520095 37.41 35.670685932820064 139.74075890412925 37.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a409003e-8ea3-443f-95de-963371c55ec3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a409003e-8ea3-443f-95de-963371c55ec3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a409003e-8ea3-443f-95de-963371c55ec3">
											<gml:posList>35.67068894601175 139.74079747433677 33.31 35.67068894601175 139.74079747433677 33.025 35.67071274400468 139.74082320685426 33.025 35.67071274400468 139.74082320685426 33.31 35.67068894601175 139.74079747433677 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecfa4c66-6aa4-4dc4-8c23-61bd9beaf036">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecfa4c66-6aa4-4dc4-8c23-61bd9beaf036">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecfa4c66-6aa4-4dc4-8c23-61bd9beaf036">
											<gml:posList>35.670714400730404 139.7408208631259 10.43 35.67069061169977 139.74079506432042 10.43 35.67069061169977 139.74079506432042 33.31 35.670714400730404 139.7408208631259 33.31 35.670714400730404 139.7408208631259 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84d6efe5-5287-4331-a17c-d3174dd37c5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84d6efe5-5287-4331-a17c-d3174dd37c5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84d6efe5-5287-4331-a17c-d3174dd37c5c">
											<gml:posList>35.67071274400468 139.74082320685426 33.31 35.67071274400468 139.74082320685426 33.025 35.67072856673444 139.74083966968826 33.025 35.67072856673444 139.74083966968826 33.31 35.67071274400468 139.74082320685426 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-789dfbb0-ee8a-4b5e-b99e-ab3b78d9de94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-789dfbb0-ee8a-4b5e-b99e-ab3b78d9de94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-789dfbb0-ee8a-4b5e-b99e-ab3b78d9de94">
											<gml:posList>35.67072828396585 139.74083531776935 10.43 35.670714400730404 139.7408208631259 10.43 35.670714400730404 139.7408208631259 33.31 35.67072828396585 139.74083531776935 33.31 35.67072828396585 139.74083531776935 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b746542f-90df-499c-9b2f-c7934052c238">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b746542f-90df-499c-9b2f-c7934052c238">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b746542f-90df-499c-9b2f-c7934052c238">
											<gml:posList>35.670743446287844 139.74081345067663 10.43 35.67072828396585 139.74083531776935 10.43 35.67072828396585 139.74083531776935 33.31 35.670743446287844 139.74081345067663 33.31 35.670743446287844 139.74081345067663 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25c3380c-6446-4892-9465-698238d11b39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25c3380c-6446-4892-9465-698238d11b39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25c3380c-6446-4892-9465-698238d11b39">
											<gml:posList>35.67072856673444 139.74083966968826 33.31 35.67072856673444 139.74083966968826 33.025 35.67074372906571 139.7408178136426 33.025 35.67074372906571 139.7408178136426 33.31 35.67072856673444 139.74083966968826 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-221143dc-217d-444d-abe1-1e9793f73a62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-221143dc-217d-444d-abe1-1e9793f73a62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-221143dc-217d-444d-abe1-1e9793f73a62">
											<gml:posList>35.67077329069154 139.74084857665386 33.31 35.67077329069154 139.74084857665386 33.025 35.670703925750246 139.74094866990455 33.025 35.670703925750246 139.74094866990455 33.31 35.67077329069154 139.74084857665386 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48fc3223-d943-4dc0-8b7b-5044ed2aae0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48fc3223-d943-4dc0-8b7b-5044ed2aae0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48fc3223-d943-4dc0-8b7b-5044ed2aae0f">
											<gml:posList>35.670704226542185 139.7409530218018 10.43 35.67077685084032 139.7408482190651 10.43 35.67077685084032 139.7408482190651 33.31 35.670704226542185 139.7409530218018 33.31 35.670704226542185 139.7409530218018 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e25c8f18-24db-4ebd-a3c3-10f954206c92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e25c8f18-24db-4ebd-a3c3-10f954206c92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e25c8f18-24db-4ebd-a3c3-10f954206c92">
											<gml:posList>35.67074372906571 139.7408178136426 33.31 35.67074372906571 139.7408178136426 33.025 35.67077329069154 139.74084857665386 33.025 35.67077329069154 139.74084857665386 33.31 35.67074372906571 139.7408178136426 33.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5926d5d-1b84-4d35-86e5-7ea5afbe9804">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5926d5d-1b84-4d35-86e5-7ea5afbe9804">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5926d5d-1b84-4d35-86e5-7ea5afbe9804">
											<gml:posList>35.67077685084032 139.7408482190651 10.43 35.670743446287844 139.74081345067663 10.43 35.670743446287844 139.74081345067663 33.31 35.67077685084032 139.7408482190651 33.31 35.67077685084032 139.7408482190651 10.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8727</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">283.0197</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>