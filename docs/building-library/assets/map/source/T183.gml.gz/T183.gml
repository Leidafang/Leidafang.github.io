<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_304051c9-d248-4bde-8890-81ef3b758947">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.6</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66840881863935 139.74273527452536 0 35.66840557307089 139.74275840849057 0 35.66845116274563 139.74276801119123 0 35.668454408315895 139.74274487721323 0 35.66840881863935 139.74273527452536 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840881863935 139.74273527452536 16.348 35.668454408315895 139.74274487721323 16.348 35.66845116274563 139.74276801119123 16.348 35.66840557307089 139.74275840849057 16.348 35.66840881863935 139.74273527452536 16.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840881863935 139.74273527452536 16.348 35.66840557307089 139.74275840849057 16.348 35.66840557307089 139.74275840849057 19.95 35.66840881863935 139.74273527452536 19.95 35.66840881863935 139.74273527452536 16.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840557307089 139.74275840849057 16.348 35.66845116274563 139.74276801119123 16.348 35.66845116274563 139.74276801119123 19.95 35.66840557307089 139.74275840849057 19.95 35.66840557307089 139.74275840849057 16.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845116274563 139.74276801119123 16.348 35.668454408315895 139.74274487721323 16.348 35.668454408315895 139.74274487721323 19.95 35.66845116274563 139.74276801119123 19.95 35.66845116274563 139.74276801119123 16.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668454408315895 139.74274487721323 16.348 35.66840881863935 139.74273527452536 16.348 35.66840881863935 139.74273527452536 19.95 35.668454408315895 139.74274487721323 19.95 35.668454408315895 139.74274487721323 16.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840881863935 139.74273527452536 19.95 35.66840557307089 139.74275840849057 19.95 35.66845116274563 139.74276801119123 19.95 35.668454408315895 139.74274487721323 19.95 35.66840881863935 139.74273527452536 19.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-addfa4cd-7f93-4d94-a976-2666368da45e"/>
							<gml:surfaceMember xlink:href="#poly-ae68ca7a-d498-46d9-90e5-fb1eee7f88c4"/>
							<gml:surfaceMember xlink:href="#poly-84822773-a7d8-4b00-b975-b7123b8d2f62"/>
							<gml:surfaceMember xlink:href="#poly-00de4ade-c427-4aae-8e03-8818b1a05d4a"/>
							<gml:surfaceMember xlink:href="#poly-e59f2706-f91a-4dad-82aa-93b7ac92fbf8"/>
							<gml:surfaceMember xlink:href="#poly-50a253e0-9438-4efa-a9d4-7196ba56bafe"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-addfa4cd-7f93-4d94-a976-2666368da45e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-addfa4cd-7f93-4d94-a976-2666368da45e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-addfa4cd-7f93-4d94-a976-2666368da45e">
											<gml:posList>35.668408818639335 139.74273527452533 16.348 35.668454408315895 139.74274487721323 16.348 35.66845116274564 139.74276801119123 16.348 35.66840557307088 139.74275840849057 16.348 35.668408818639335 139.74273527452533 16.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae68ca7a-d498-46d9-90e5-fb1eee7f88c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae68ca7a-d498-46d9-90e5-fb1eee7f88c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae68ca7a-d498-46d9-90e5-fb1eee7f88c4">
											<gml:posList>35.668454408315895 139.74274487721323 20.206 35.668408818639335 139.74273527452533 20.206 35.66840557307088 139.74275840849057 20.206 35.66845116274564 139.74276801119123 20.206 35.668454408315895 139.74274487721323 20.206</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84822773-a7d8-4b00-b975-b7123b8d2f62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84822773-a7d8-4b00-b975-b7123b8d2f62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84822773-a7d8-4b00-b975-b7123b8d2f62">
											<gml:posList>35.668454408315895 139.74274487721323 16.348 35.668408818639335 139.74273527452533 16.348 35.668408818639335 139.74273527452533 20.206 35.668454408315895 139.74274487721323 20.206 35.668454408315895 139.74274487721323 16.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00de4ade-c427-4aae-8e03-8818b1a05d4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00de4ade-c427-4aae-8e03-8818b1a05d4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00de4ade-c427-4aae-8e03-8818b1a05d4a">
											<gml:posList>35.668408818639335 139.74273527452533 16.348 35.66840557307088 139.74275840849057 16.348 35.66840557307088 139.74275840849057 20.206 35.668408818639335 139.74273527452533 20.206 35.668408818639335 139.74273527452533 16.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e59f2706-f91a-4dad-82aa-93b7ac92fbf8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e59f2706-f91a-4dad-82aa-93b7ac92fbf8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e59f2706-f91a-4dad-82aa-93b7ac92fbf8">
											<gml:posList>35.66845116274564 139.74276801119123 16.348 35.668454408315895 139.74274487721323 16.348 35.668454408315895 139.74274487721323 20.206 35.66845116274564 139.74276801119123 20.206 35.66845116274564 139.74276801119123 16.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50a253e0-9438-4efa-a9d4-7196ba56bafe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50a253e0-9438-4efa-a9d4-7196ba56bafe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50a253e0-9438-4efa-a9d4-7196ba56bafe">
											<gml:posList>35.66840557307088 139.74275840849057 16.348 35.66845116274564 139.74276801119123 16.348 35.66845116274564 139.74276801119123 20.206 35.66840557307088 139.74275840849057 20.206 35.66840557307088 139.74275840849057 16.348</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8779</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>