<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3076af9b-6283-450a-b691-e12deceb694d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">45.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>15</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66680471106154 139.7381708442033 0 35.66678167287763 139.73819482980466 0 35.666764661760894 139.73816923486723 0 35.66672019422144 139.7382113498745 0 35.666806554039034 139.73833595413998 0 35.666849423210145 139.7382900633964 0 35.66684625907653 139.73827824817025 0 35.66690100086853 139.73820008961505 0 35.66689998762656 139.7381725868255 0 35.66686361847328 139.73811718019627 0 35.66685632172099 139.73812271174742 0 35.666847841568085 139.738113553825 0 35.66679221958039 139.73815000462326 0 35.66680471106154 139.7381708442033 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66680471106154 139.7381708442033 12.45 35.66679221958039 139.73815000462326 12.45 35.666847841568085 139.738113553825 12.45 35.66685632172099 139.73812271174742 12.45 35.66686361847328 139.73811718019627 12.45 35.66689998762656 139.7381725868255 12.45 35.66690100086853 139.73820008961505 12.45 35.66684625907653 139.73827824817025 12.45 35.666849423210145 139.7382900633964 12.45 35.666806554039034 139.73833595413998 12.45 35.66672019422144 139.7382113498745 12.45 35.666764661760894 139.73816923486723 12.45 35.66678167287763 139.73819482980466 12.45 35.66680471106154 139.7381708442033 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66680471106154 139.7381708442033 12.45 35.66678167287763 139.73819482980466 12.45 35.66678167287763 139.73819482980466 57.61 35.66680471106154 139.7381708442033 57.61 35.66680471106154 139.7381708442033 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66678167287763 139.73819482980466 12.45 35.666764661760894 139.73816923486723 12.45 35.666764661760894 139.73816923486723 57.61 35.66678167287763 139.73819482980466 57.61 35.66678167287763 139.73819482980466 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666764661760894 139.73816923486723 12.45 35.66672019422144 139.7382113498745 12.45 35.66672019422144 139.7382113498745 57.61 35.666764661760894 139.73816923486723 57.61 35.666764661760894 139.73816923486723 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66672019422144 139.7382113498745 12.45 35.666806554039034 139.73833595413998 12.45 35.666806554039034 139.73833595413998 57.61 35.66672019422144 139.7382113498745 57.61 35.66672019422144 139.7382113498745 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666806554039034 139.73833595413998 12.45 35.666849423210145 139.7382900633964 12.45 35.666849423210145 139.7382900633964 57.61 35.666806554039034 139.73833595413998 57.61 35.666806554039034 139.73833595413998 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666849423210145 139.7382900633964 12.45 35.66684625907653 139.73827824817025 12.45 35.66684625907653 139.73827824817025 57.61 35.666849423210145 139.7382900633964 57.61 35.666849423210145 139.7382900633964 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66684625907653 139.73827824817025 12.45 35.66690100086853 139.73820008961505 12.45 35.66690100086853 139.73820008961505 57.61 35.66684625907653 139.73827824817025 57.61 35.66684625907653 139.73827824817025 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66690100086853 139.73820008961505 12.45 35.66689998762656 139.7381725868255 12.45 35.66689998762656 139.7381725868255 57.61 35.66690100086853 139.73820008961505 57.61 35.66690100086853 139.73820008961505 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66689998762656 139.7381725868255 12.45 35.66686361847328 139.73811718019627 12.45 35.66686361847328 139.73811718019627 57.61 35.66689998762656 139.7381725868255 57.61 35.66689998762656 139.7381725868255 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66686361847328 139.73811718019627 12.45 35.66685632172099 139.73812271174742 12.45 35.66685632172099 139.73812271174742 57.61 35.66686361847328 139.73811718019627 57.61 35.66686361847328 139.73811718019627 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66685632172099 139.73812271174742 12.45 35.666847841568085 139.738113553825 12.45 35.666847841568085 139.738113553825 57.61 35.66685632172099 139.73812271174742 57.61 35.66685632172099 139.73812271174742 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666847841568085 139.738113553825 12.45 35.66679221958039 139.73815000462326 12.45 35.66679221958039 139.73815000462326 57.61 35.666847841568085 139.738113553825 57.61 35.666847841568085 139.738113553825 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66679221958039 139.73815000462326 12.45 35.66680471106154 139.7381708442033 12.45 35.66680471106154 139.7381708442033 57.61 35.66679221958039 139.73815000462326 57.61 35.66679221958039 139.73815000462326 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66680471106154 139.7381708442033 57.61 35.66678167287763 139.73819482980466 57.61 35.666764661760894 139.73816923486723 57.61 35.66672019422144 139.7382113498745 57.61 35.666806554039034 139.73833595413998 57.61 35.666849423210145 139.7382900633964 57.61 35.66684625907653 139.73827824817025 57.61 35.66690100086853 139.73820008961505 57.61 35.66689998762656 139.7381725868255 57.61 35.66686361847328 139.73811718019627 57.61 35.66685632172099 139.73812271174742 57.61 35.666847841568085 139.738113553825 57.61 35.66679221958039 139.73815000462326 57.61 35.66680471106154 139.7381708442033 57.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ed3f1701-4a97-4cc0-ba15-e6b21021edd3"/>
							<gml:surfaceMember xlink:href="#poly-b17f2828-1f17-4a27-90aa-a91057fe6eac"/>
							<gml:surfaceMember xlink:href="#poly-c61e6185-98e0-4491-ba65-c98b7100373e"/>
							<gml:surfaceMember xlink:href="#poly-08459234-401b-4c5a-885f-630d0b110939"/>
							<gml:surfaceMember xlink:href="#poly-d49190e8-2e7b-49a8-975a-c71e88efbaa8"/>
							<gml:surfaceMember xlink:href="#poly-c391bd2f-9ba0-4116-aa90-cc5b191605e0"/>
							<gml:surfaceMember xlink:href="#poly-d2d154fb-8855-4070-afc8-13e9028afe53"/>
							<gml:surfaceMember xlink:href="#poly-cf321888-05b2-4095-a64a-cda0644cc5df"/>
							<gml:surfaceMember xlink:href="#poly-a9f987b3-85d2-447c-a210-188728bb6b46"/>
							<gml:surfaceMember xlink:href="#poly-cfc53621-d9bc-4db1-bff4-e686eeb734c9"/>
							<gml:surfaceMember xlink:href="#poly-74ba4051-8de5-4122-aff1-7a035c4344fd"/>
							<gml:surfaceMember xlink:href="#poly-c09f55de-0b76-4dd1-abb5-8569b5a4733d"/>
							<gml:surfaceMember xlink:href="#poly-1c11350e-6350-475c-a3a2-3c79534e0427"/>
							<gml:surfaceMember xlink:href="#poly-66d4e77f-c3b9-4300-941f-ac6fa36ad6b1"/>
							<gml:surfaceMember xlink:href="#poly-129b6ff8-6079-44e2-a7d9-10797ddaaeb4"/>
							<gml:surfaceMember xlink:href="#poly-06a6f462-5222-432f-8ea6-d41ca6a2447f"/>
							<gml:surfaceMember xlink:href="#poly-50cfcc60-13f2-4e8a-a2b5-2baa20a43e2f"/>
							<gml:surfaceMember xlink:href="#poly-e4b4b049-0a17-4085-a460-f8cb1acb7bc6"/>
							<gml:surfaceMember xlink:href="#poly-180e53e5-d066-431f-b096-eb672c81f012"/>
							<gml:surfaceMember xlink:href="#poly-612f3317-02ef-4238-b5aa-cdef96a5236b"/>
							<gml:surfaceMember xlink:href="#poly-c40b54ce-f448-47d9-aac6-66df814c65f3"/>
							<gml:surfaceMember xlink:href="#poly-fe94eb83-c18e-408f-850c-c5214c063a29"/>
							<gml:surfaceMember xlink:href="#poly-565d5c59-2343-4883-b6ca-ae537c3cdba0"/>
							<gml:surfaceMember xlink:href="#poly-2a0fb8d8-0607-4fb7-85ea-71eba167088f"/>
							<gml:surfaceMember xlink:href="#poly-863c4550-5d68-4917-898a-9e51d66549bd"/>
							<gml:surfaceMember xlink:href="#poly-f880cfdb-b913-437f-83b0-ae261a3e94ef"/>
							<gml:surfaceMember xlink:href="#poly-e93fa866-a583-464f-99ed-b31f08d38440"/>
							<gml:surfaceMember xlink:href="#poly-4a37f5ff-94bd-49d4-a42c-9b54e53fc9fc"/>
							<gml:surfaceMember xlink:href="#poly-9150e59d-dc87-483e-b816-a4b3c7cf00e5"/>
							<gml:surfaceMember xlink:href="#poly-9e219ac4-f4df-4565-9b6d-62807e642336"/>
							<gml:surfaceMember xlink:href="#poly-19cc7d05-ce6d-4863-96e5-ac9cdadb3906"/>
							<gml:surfaceMember xlink:href="#poly-61f553f8-fc62-4c41-b683-8d5c78b1252f"/>
							<gml:surfaceMember xlink:href="#poly-85307b8e-4364-4fa6-acee-1f45f2c54c36"/>
							<gml:surfaceMember xlink:href="#poly-53e1da85-b0ed-473d-8a55-98192a08fa38"/>
							<gml:surfaceMember xlink:href="#poly-d631b234-af09-41ab-bf91-42c19d367a70"/>
							<gml:surfaceMember xlink:href="#poly-15ee525e-29b1-44b6-a6f5-7e96dd05ffc6"/>
							<gml:surfaceMember xlink:href="#poly-4738b30f-238f-4d8f-a4bf-be7baff1ea3c"/>
							<gml:surfaceMember xlink:href="#poly-0e5f9fdb-23d8-4564-a9a2-3322ac9275be"/>
							<gml:surfaceMember xlink:href="#poly-8c52ed8d-6f9c-4a7e-8e49-78a7f0ec257a"/>
							<gml:surfaceMember xlink:href="#poly-7739a9ee-f26d-435f-815f-c89a0491176a"/>
							<gml:surfaceMember xlink:href="#poly-d2af9d13-d249-47fc-b695-0ba02364f7e3"/>
							<gml:surfaceMember xlink:href="#poly-83659ab1-6fae-4225-9e5c-b0a557127064"/>
							<gml:surfaceMember xlink:href="#poly-08d7f52b-3531-40fb-a84e-bf90767bebcc"/>
							<gml:surfaceMember xlink:href="#poly-3e34a9af-e379-4b6c-b272-e6816ed54a57"/>
							<gml:surfaceMember xlink:href="#poly-8ab71e85-55bd-4a3e-b53a-d23524fcf35f"/>
							<gml:surfaceMember xlink:href="#poly-d6825736-b168-41df-a04d-b8791ffdd80b"/>
							<gml:surfaceMember xlink:href="#poly-b7e4b51c-7edc-4c00-8efc-c89aed3b0cc5"/>
							<gml:surfaceMember xlink:href="#poly-c926d16e-57d7-4dda-8118-1ac452b47bcd"/>
							<gml:surfaceMember xlink:href="#poly-110afc71-4183-44a8-bc28-f19b854ac543"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3076af9b-6283-450a-b691-e12deceb694d_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f5a1683-5610-437a-a231-264643bd3fea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676865185671 139.73816545248144 12.5 35.666792219580365 139.73815000462326 12.5 35.66680471106151 139.7381708442033 12.5 35.66678167287762 139.73819482980463 12.5 35.666764661760865 139.73816923486723 12.5 35.66676865185671 139.73816545248144 12.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb9243f0-7ebe-437d-b36f-a23b32cb0c88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb9243f0-7ebe-437d-b36f-a23b32cb0c88_0">
											<gml:posList>35.666792219580365 139.73815000462326 12.5 35.66676865185671 139.73816545248144 12.5 35.66676865185671 139.73816545248144 57.72 35.666792219580365 139.73815000462326 57.72 35.666792219580365 139.73815000462326 12.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2de4e1ba-9833-4ea0-919e-83d15f5da964">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2de4e1ba-9833-4ea0-919e-83d15f5da964_0">
											<gml:posList>35.666792219580365 139.73815000462326 57.72 35.66680471106151 139.7381708442033 57.72 35.66680471106151 139.7381708442033 12.5 35.666792219580365 139.73815000462326 12.5 35.666792219580365 139.73815000462326 57.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dc02421-6c68-4109-befd-553c0a039fac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dc02421-6c68-4109-befd-553c0a039fac_0">
											<gml:posList>35.666764661760865 139.73816923486723 12.5 35.666764661760865 139.73816923486723 57.72 35.66676865185671 139.73816545248144 57.72 35.66676865185671 139.73816545248144 12.5 35.666764661760865 139.73816923486723 12.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7edfd6f-293d-42b8-b55a-e5e57d806d99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7edfd6f-293d-42b8-b55a-e5e57d806d99_0">
											<gml:posList>35.66678167287762 139.73819482980463 57.72 35.66680471106151 139.7381708442033 57.72 35.666792219580365 139.73815000462326 57.72 35.66676865185671 139.73816545248144 57.72 35.666764661760865 139.73816923486723 57.72 35.66678167287762 139.73819482980463 57.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4aafb8d5-0fce-4909-b0da-523bf62b9211">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4aafb8d5-0fce-4909-b0da-523bf62b9211_0">
											<gml:posList>35.66678167287762 139.73819482980463 12.5 35.66678167287762 139.73819482980463 57.72 35.666764661760865 139.73816923486723 57.72 35.666764661760865 139.73816923486723 12.5 35.66678167287762 139.73819482980463 12.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a98b753b-d822-44bd-9ab1-4d01d3348877">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a98b753b-d822-44bd-9ab1-4d01d3348877_0">
											<gml:posList>35.66680471106151 139.7381708442033 57.72 35.66678167287762 139.73819482980463 57.72 35.66678167287762 139.73819482980463 12.5 35.66680471106151 139.7381708442033 12.5 35.66680471106151 139.7381708442033 57.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3076af9b-6283-450a-b691-e12deceb694d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15452610-c9c2-4ab5-bdd8-2f369b6f27cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66677441317019 139.73822444106128 58.115 35.666781870211295 139.73821642403814 58.115 35.66678880040537 139.7382261029532 58.115 35.666781352377384 139.73823411996543 58.115 35.66677441317019 139.73822444106128 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6ddb1e1-9d35-4b76-90b6-7c1ef9c023af">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66679885105052 139.738180880713 58.926 35.666798986413546 139.73818107937618 58.926 35.666790934756825 139.73818946162007 58.926 35.66679079038009 139.7381892629676 58.926 35.66679885105052 139.738180880713 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-888432ef-6fa9-411a-b726-ef777cdde437">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666790934756825 139.73818946162007 58.115 35.666798986413546 139.73818107937618 58.115 35.66680572736581 139.73819081374356 58.115 35.66679768472214 139.7381991959765 58.115 35.666790934756825 139.73818946162007 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ccd4391-6010-4138-b20b-da2515ed2028">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66683392547183 139.73822902074482 58.115 35.66684387795013 139.7382420981809 58.115 35.66683352150486 139.73825394048248 58.115 35.66682356002283 139.73824087410307 58.115 35.66683392547183 139.73822902074482 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a9bbf2e-34ac-49f6-a876-54ee6ce114ff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6668520487191 139.7381905157766 58.115 35.66683001012163 139.73821331830337 58.115 35.666816058886546 139.7381930658678 58.115 35.66683810649396 139.73817026332878 58.115 35.6668520487191 139.7381905157766 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de573bfd-4767-47b1-bfbe-5216e8dcca67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de573bfd-4767-47b1-bfbe-5216e8dcca67_0">
											<gml:posList>35.66683810649396 139.73817026332878 58.115 35.66683810649396 139.73817026332878 58.552 35.6668520487191 139.7381905157766 58.552 35.6668520487191 139.7381905157766 58.115 35.66683810649396 139.73817026332878 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc89b50e-fa78-4c1e-be8b-783116b29ba6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc89b50e-fa78-4c1e-be8b-783116b29ba6_0">
											<gml:posList>35.666816058886546 139.7381930658678 58.115 35.666816058886546 139.7381930658678 58.552 35.66683810649396 139.73817026332878 58.552 35.66683810649396 139.73817026332878 58.115 35.666816058886546 139.7381930658678 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32c400a3-c441-4e79-bfdc-f98acfc4e471">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32c400a3-c441-4e79-bfdc-f98acfc4e471_0">
											<gml:posList>35.66679079038009 139.7381892629676 58.926 35.66679079038009 139.7381892629676 59.076 35.66679885105052 139.738180880713 59.076 35.66679885105052 139.738180880713 58.926 35.66679079038009 139.7381892629676 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bb6565b-d2dd-45c4-82d0-8f1c024e0b21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bb6565b-d2dd-45c4-82d0-8f1c024e0b21_0">
											<gml:posList>35.666790934756825 139.73818946162007 58.926 35.666798986413546 139.73818107937618 58.926 35.666798986413546 139.73818107937618 58.115 35.666790934756825 139.73818946162007 58.115 35.666790934756825 139.73818946162007 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f081bf2a-f2eb-460e-aff2-479670ef9643">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f081bf2a-f2eb-460e-aff2-479670ef9643_0">
											<gml:posList>35.66679885105052 139.738180880713 59.076 35.66680572736581 139.73819081374356 59.076 35.66680572736581 139.73819081374356 58.115 35.666798986413546 139.73818107937618 58.115 35.666798986413546 139.73818107937618 58.926 35.66679885105052 139.738180880713 58.926 35.66679885105052 139.738180880713 59.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f1f97d3-6708-4ce6-a22e-82e2cb56f993">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f1f97d3-6708-4ce6-a22e-82e2cb56f993_0">
											<gml:posList>35.66679079038009 139.7381892629676 59.076 35.66679768472214 139.7381991959765 59.076 35.66680572736581 139.73819081374356 59.076 35.66679885105052 139.738180880713 59.076 35.66679079038009 139.7381892629676 59.076</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26b14def-a0b5-4fcc-994f-17b301fddba7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26b14def-a0b5-4fcc-994f-17b301fddba7_0">
											<gml:posList>35.6668520487191 139.7381905157766 58.552 35.66683810649396 139.73817026332878 58.552 35.666816058886546 139.7381930658678 58.552 35.66683001012163 139.73821331830337 58.552 35.6668520487191 139.7381905157766 58.552</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f18ec93-060e-450a-8fd5-f68f95022db3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f18ec93-060e-450a-8fd5-f68f95022db3_0">
											<gml:posList>35.66679768472214 139.7381991959765 58.115 35.66679768472214 139.7381991959765 59.076 35.66679079038009 139.7381892629676 59.076 35.66679079038009 139.7381892629676 58.926 35.666790934756825 139.73818946162007 58.926 35.666790934756825 139.73818946162007 58.115 35.66679768472214 139.7381991959765 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38ad350a-b385-4888-9d03-2abb7de04490">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38ad350a-b385-4888-9d03-2abb7de04490_0">
											<gml:posList>35.66679768472214 139.7381991959765 58.115 35.66680572736581 139.73819081374356 58.115 35.66680572736581 139.73819081374356 59.076 35.66679768472214 139.7381991959765 59.076 35.66679768472214 139.7381991959765 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7c89bba-8ad5-4999-b681-5525f5b81680">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7c89bba-8ad5-4999-b681-5525f5b81680_0">
											<gml:posList>35.66683001012163 139.73821331830337 58.115 35.6668520487191 139.7381905157766 58.115 35.6668520487191 139.7381905157766 58.552 35.66683001012163 139.73821331830337 58.552 35.66683001012163 139.73821331830337 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37d925d0-27ba-4a12-a3c4-3da321be1a23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37d925d0-27ba-4a12-a3c4-3da321be1a23_0">
											<gml:posList>35.666816058886546 139.7381930658678 58.115 35.66683001012163 139.73821331830337 58.115 35.66683001012163 139.73821331830337 58.552 35.666816058886546 139.7381930658678 58.552 35.666816058886546 139.7381930658678 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4d74b79-643a-4ab4-809e-8e77434360f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4d74b79-643a-4ab4-809e-8e77434360f5_0">
											<gml:posList>35.66677441317019 139.73822444106128 59.219 35.666781870211295 139.73821642403814 59.219 35.666781870211295 139.73821642403814 58.115 35.66677441317019 139.73822444106128 58.115 35.66677441317019 139.73822444106128 59.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38eb3a6a-40aa-4f17-878b-10f6e6aababc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38eb3a6a-40aa-4f17-878b-10f6e6aababc_0">
											<gml:posList>35.66678880040537 139.7382261029532 58.115 35.666781870211295 139.73821642403814 58.115 35.666781870211295 139.73821642403814 59.219 35.66678880040537 139.7382261029532 59.219 35.66678880040537 139.7382261029532 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7525ac7a-2fb4-4be3-b9ab-c72c26e400e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7525ac7a-2fb4-4be3-b9ab-c72c26e400e4_0">
											<gml:posList>35.66677441317019 139.73822444106128 59.219 35.666781352377384 139.73823411996543 59.219 35.66678880040537 139.7382261029532 59.219 35.666781870211295 139.73821642403814 59.219 35.66677441317019 139.73822444106128 59.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6157351b-168d-4512-99f0-5608da43409f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6157351b-168d-4512-99f0-5608da43409f_0">
											<gml:posList>35.66677441317019 139.73822444106128 58.115 35.666781352377384 139.73823411996543 58.115 35.666781352377384 139.73823411996543 59.219 35.66677441317019 139.73822444106128 59.219 35.66677441317019 139.73822444106128 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f882c268-8c80-4e46-b271-82a9714dbd4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f882c268-8c80-4e46-b271-82a9714dbd4c_0">
											<gml:posList>35.666781352377384 139.73823411996543 58.115 35.66678880040537 139.7382261029532 58.115 35.66678880040537 139.7382261029532 59.219 35.666781352377384 139.73823411996543 59.219 35.666781352377384 139.73823411996543 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b577826-bf6a-466a-8940-2deceee93ba7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b577826-bf6a-466a-8940-2deceee93ba7_0">
											<gml:posList>35.66683392547183 139.73822902074482 58.115 35.66682356002283 139.73824087410307 58.115 35.66682356002283 139.73824087410307 59.219 35.66683392547183 139.73822902074482 59.219 35.66683392547183 139.73822902074482 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a8e255b-1bfe-4222-8eaa-b2846f9a0d0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a8e255b-1bfe-4222-8eaa-b2846f9a0d0f_0">
											<gml:posList>35.66683392547183 139.73822902074482 58.115 35.66683392547183 139.73822902074482 59.219 35.66684387795013 139.7382420981809 59.219 35.66684387795013 139.7382420981809 58.115 35.66683392547183 139.73822902074482 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d10481f-f06c-4318-a3e2-4bd4923c663f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d10481f-f06c-4318-a3e2-4bd4923c663f_0">
											<gml:posList>35.66683392547183 139.73822902074482 59.219 35.66682356002283 139.73824087410307 59.219 35.66683352150486 139.73825394048248 59.219 35.66684387795013 139.7382420981809 59.219 35.66683392547183 139.73822902074482 59.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c214300-5ce7-4bcc-9b5a-25b0334f3c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c214300-5ce7-4bcc-9b5a-25b0334f3c7c_0">
											<gml:posList>35.66682356002283 139.73824087410307 58.115 35.66683352150486 139.73825394048248 58.115 35.66683352150486 139.73825394048248 59.219 35.66682356002283 139.73824087410307 59.219 35.66682356002283 139.73824087410307 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13059735-edd5-4a2d-bb66-591d30f10223">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13059735-edd5-4a2d-bb66-591d30f10223_0">
											<gml:posList>35.66683352150486 139.73825394048248 58.115 35.66684387795013 139.7382420981809 58.115 35.66684387795013 139.7382420981809 59.219 35.66683352150486 139.73825394048248 59.219 35.66683352150486 139.73825394048248 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ed3f1701-4a97-4cc0-ba15-e6b21021edd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed3f1701-4a97-4cc0-ba15-e6b21021edd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed3f1701-4a97-4cc0-ba15-e6b21021edd3">
											<gml:posList>35.66680655403903 139.73833595413998 12.45 35.66672019422142 139.7382113498745 12.45 35.666764661760865 139.73816923486723 12.45 35.66678167287762 139.73819482980463 12.45 35.66680471106151 139.7381708442033 12.45 35.666792219580365 139.73815000462326 12.45 35.666847841568085 139.738113553825 12.45 35.66685632172099 139.7381227117474 12.45 35.666863618473286 139.73811718019624 12.45 35.66689998762656 139.7381725868255 12.45 35.66690100086852 139.73820008961505 12.45 35.66684625907653 139.73827824817025 12.45 35.666849423210145 139.7382900633964 12.45 35.66680655403903 139.73833595413998 12.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b17f2828-1f17-4a27-90aa-a91057fe6eac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b17f2828-1f17-4a27-90aa-a91057fe6eac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b17f2828-1f17-4a27-90aa-a91057fe6eac">
											<gml:posList>35.66684747512337 139.73811749760094 58.926 35.666856045483115 139.7381267437828 58.926 35.66685632172099 139.7381227117474 58.926 35.666847841568085 139.738113553825 58.926 35.66684747512337 139.73811749760094 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c61e6185-98e0-4491-ba65-c98b7100373e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c61e6185-98e0-4491-ba65-c98b7100373e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c61e6185-98e0-4491-ba65-c98b7100373e">
											<gml:posList>35.666863017942276 139.73812146666992 58.926 35.666863618473286 139.73811718019624 58.926 35.66685632172099 139.7381227117474 58.926 35.666856045483115 139.7381267437828 58.926 35.666863017942276 139.73812146666992 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08459234-401b-4c5a-885f-630d0b110939">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08459234-401b-4c5a-885f-630d0b110939">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08459234-401b-4c5a-885f-630d0b110939">
											<gml:posList>35.666847841568085 139.738113553825 58.926 35.666792219580365 139.73815000462326 58.926 35.66679617747982 139.73815110450178 58.926 35.666813033449955 139.7381400608177 58.926 35.66681464607763 139.73813900955537 58.926 35.66684747512337 139.73811749760094 58.926 35.666847841568085 139.738113553825 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d49190e8-2e7b-49a8-975a-c71e88efbaa8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d49190e8-2e7b-49a8-975a-c71e88efbaa8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d49190e8-2e7b-49a8-975a-c71e88efbaa8">
											<gml:posList>35.666863017942276 139.73812146666992 58.926 35.666897374614535 139.73817381600793 58.926 35.66689998762656 139.7381725868255 58.926 35.666863618473286 139.73811718019624 58.926 35.666863017942276 139.73812146666992 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c391bd2f-9ba0-4116-aa90-cc5b191605e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c391bd2f-9ba0-4116-aa90-cc5b191605e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c391bd2f-9ba0-4116-aa90-cc5b191605e0">
											<gml:posList>35.66682259105386 139.73815531472457 58.926 35.666825286769495 139.7381560847288 58.926 35.66681464607763 139.73813900955537 58.926 35.666813033449955 139.7381400608177 58.926 35.66682259105386 139.73815531472457 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d2d154fb-8855-4070-afc8-13e9028afe53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2d154fb-8855-4070-afc8-13e9028afe53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2d154fb-8855-4070-afc8-13e9028afe53">
											<gml:posList>35.66680708044976 139.7381692949841 57.867 35.66682259105386 139.73815531472457 57.867 35.666813033449955 139.7381400608177 57.867 35.66679617747982 139.73815110450178 57.867 35.66680708044976 139.7381692949841 57.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf321888-05b2-4095-a64a-cda0644cc5df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf321888-05b2-4095-a64a-cda0644cc5df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf321888-05b2-4095-a64a-cda0644cc5df">
											<gml:posList>35.666792219580365 139.73815000462326 58.926 35.66680471106151 139.7381708442033 58.926 35.6668083259765 139.7381713590644 58.926 35.66680708044976 139.7381692949841 58.926 35.66679617747982 139.73815110450178 58.926 35.666792219580365 139.73815000462326 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a9f987b3-85d2-447c-a210-188728bb6b46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9f987b3-85d2-447c-a210-188728bb6b46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9f987b3-85d2-447c-a210-188728bb6b46">
											<gml:posList>35.6668083259765 139.7381713590644 58.926 35.666825286769495 139.7381560847288 58.926 35.66682259105386 139.73815531472457 58.926 35.66680708044976 139.7381692949841 58.926 35.6668083259765 139.7381713590644 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cfc53621-d9bc-4db1-bff4-e686eeb734c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfc53621-d9bc-4db1-bff4-e686eeb734c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfc53621-d9bc-4db1-bff4-e686eeb734c9">
											<gml:posList>35.66676425069957 139.73817375307135 58.926 35.666781334003716 139.7381994473358 58.926 35.66678167287762 139.73819482980463 58.926 35.666764661760865 139.73816923486723 58.926 35.66676425069957 139.73817375307135 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74ba4051-8de5-4122-aff1-7a035c4344fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74ba4051-8de5-4122-aff1-7a035c4344fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74ba4051-8de5-4122-aff1-7a035c4344fd">
											<gml:posList>35.6668083259765 139.7381713590644 58.926 35.66680471106151 139.7381708442033 58.926 35.66678167287762 139.73819482980463 58.926 35.666781334003716 139.7381994473358 58.926 35.6668083259765 139.7381713590644 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c09f55de-0b76-4dd1-abb5-8569b5a4733d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c09f55de-0b76-4dd1-abb5-8569b5a4733d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c09f55de-0b76-4dd1-abb5-8569b5a4733d">
											<gml:posList>35.66689830486522 139.73819895509823 58.926 35.66690100086852 139.73820008961505 58.926 35.66689998762656 139.7381725868255 58.926 35.666897374614535 139.73817381600793 58.926 35.66689830486522 139.73819895509823 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c11350e-6350-475c-a3a2-3c79534e0427">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c11350e-6350-475c-a3a2-3c79534e0427">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c11350e-6350-475c-a3a2-3c79534e0427">
											<gml:posList>35.66676425069957 139.73817375307135 58.926 35.666764661760865 139.73816923486723 58.926 35.66672019422142 139.7382113498745 58.926 35.6667240254483 139.73821184238878 58.926 35.66676425069957 139.73817375307135 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66d4e77f-c3b9-4300-941f-ac6fa36ad6b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66d4e77f-c3b9-4300-941f-ac6fa36ad6b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66d4e77f-c3b9-4300-941f-ac6fa36ad6b1">
											<gml:posList>35.666825286769495 139.7381560847288 58.115 35.6668083259765 139.7381713590644 58.115 35.666781334003716 139.7381994473358 58.115 35.66676425069957 139.73817375307135 58.115 35.6667240254483 139.73821184238878 58.115 35.66680684784081 139.73833132561558 58.115 35.666846348718295 139.7382890397836 58.115 35.66684327495727 139.73827752268667 58.115 35.66689830486522 139.73819895509823 58.115 35.666897374614535 139.73817381600793 58.115 35.666863017942276 139.73812146666992 58.115 35.666856045483115 139.7381267437828 58.115 35.66684747512337 139.73811749760094 58.115 35.66681464607763 139.73813900955537 58.115 35.666825286769495 139.7381560847288 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-129b6ff8-6079-44e2-a7d9-10797ddaaeb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-129b6ff8-6079-44e2-a7d9-10797ddaaeb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-129b6ff8-6079-44e2-a7d9-10797ddaaeb4">
											<gml:posList>35.66689830486522 139.73819895509823 58.926 35.66684327495727 139.73827752268667 58.926 35.66684625907653 139.73827824817025 58.926 35.66690100086852 139.73820008961505 58.926 35.66689830486522 139.73819895509823 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06a6f462-5222-432f-8ea6-d41ca6a2447f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06a6f462-5222-432f-8ea6-d41ca6a2447f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06a6f462-5222-432f-8ea6-d41ca6a2447f">
											<gml:posList>35.6667240254483 139.73821184238878 58.926 35.66672019422142 139.7382113498745 58.926 35.66680655403903 139.73833595413998 58.926 35.66680684784081 139.73833132561558 58.926 35.6667240254483 139.73821184238878 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50cfcc60-13f2-4e8a-a2b5-2baa20a43e2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50cfcc60-13f2-4e8a-a2b5-2baa20a43e2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50cfcc60-13f2-4e8a-a2b5-2baa20a43e2f">
											<gml:posList>35.666846348718295 139.7382890397836 58.926 35.666849423210145 139.7382900633964 58.926 35.66684625907653 139.73827824817025 58.926 35.66684327495727 139.73827752268667 58.926 35.666846348718295 139.7382890397836 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4b4b049-0a17-4085-a460-f8cb1acb7bc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4b4b049-0a17-4085-a460-f8cb1acb7bc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4b4b049-0a17-4085-a460-f8cb1acb7bc6">
											<gml:posList>35.66680684784081 139.73833132561558 58.926 35.66680655403903 139.73833595413998 58.926 35.666849423210145 139.7382900633964 58.926 35.666846348718295 139.7382890397836 58.926 35.66680684784081 139.73833132561558 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-180e53e5-d066-431f-b096-eb672c81f012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-180e53e5-d066-431f-b096-eb672c81f012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-180e53e5-d066-431f-b096-eb672c81f012">
											<gml:posList>35.666847841568085 139.738113553825 58.926 35.66685632172099 139.7381227117474 58.926 35.66685632172099 139.7381227117474 12.45 35.666847841568085 139.738113553825 12.45 35.666847841568085 139.738113553825 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-612f3317-02ef-4238-b5aa-cdef96a5236b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-612f3317-02ef-4238-b5aa-cdef96a5236b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-612f3317-02ef-4238-b5aa-cdef96a5236b">
											<gml:posList>35.66685632172099 139.7381227117474 58.926 35.666863618473286 139.73811718019624 58.926 35.666863618473286 139.73811718019624 12.45 35.66685632172099 139.7381227117474 12.45 35.66685632172099 139.7381227117474 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c40b54ce-f448-47d9-aac6-66df814c65f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c40b54ce-f448-47d9-aac6-66df814c65f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c40b54ce-f448-47d9-aac6-66df814c65f3">
											<gml:posList>35.666856045483115 139.7381267437828 58.115 35.666856045483115 139.7381267437828 58.926 35.66684747512337 139.73811749760094 58.926 35.66684747512337 139.73811749760094 58.115 35.666856045483115 139.7381267437828 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe94eb83-c18e-408f-850c-c5214c063a29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe94eb83-c18e-408f-850c-c5214c063a29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe94eb83-c18e-408f-850c-c5214c063a29">
											<gml:posList>35.666863017942276 139.73812146666992 58.115 35.666863017942276 139.73812146666992 58.926 35.666856045483115 139.7381267437828 58.926 35.666856045483115 139.7381267437828 58.115 35.666863017942276 139.73812146666992 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-565d5c59-2343-4883-b6ca-ae537c3cdba0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-565d5c59-2343-4883-b6ca-ae537c3cdba0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-565d5c59-2343-4883-b6ca-ae537c3cdba0">
											<gml:posList>35.66684747512337 139.73811749760094 58.115 35.66684747512337 139.73811749760094 58.926 35.66681464607763 139.73813900955537 58.926 35.66681464607763 139.73813900955537 58.115 35.66684747512337 139.73811749760094 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a0fb8d8-0607-4fb7-85ea-71eba167088f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a0fb8d8-0607-4fb7-85ea-71eba167088f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a0fb8d8-0607-4fb7-85ea-71eba167088f">
											<gml:posList>35.666792219580365 139.73815000462326 58.926 35.666847841568085 139.738113553825 58.926 35.666847841568085 139.738113553825 12.45 35.666792219580365 139.73815000462326 12.45 35.666792219580365 139.73815000462326 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-863c4550-5d68-4917-898a-9e51d66549bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-863c4550-5d68-4917-898a-9e51d66549bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-863c4550-5d68-4917-898a-9e51d66549bd">
											<gml:posList>35.666813033449955 139.7381400608177 57.867 35.666813033449955 139.7381400608177 58.926 35.66679617747982 139.73815110450178 58.926 35.66679617747982 139.73815110450178 57.867 35.666813033449955 139.7381400608177 57.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f880cfdb-b913-437f-83b0-ae261a3e94ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f880cfdb-b913-437f-83b0-ae261a3e94ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f880cfdb-b913-437f-83b0-ae261a3e94ef">
											<gml:posList>35.66681464607763 139.73813900955537 58.115 35.66681464607763 139.73813900955537 58.926 35.666825286769495 139.7381560847288 58.926 35.666825286769495 139.7381560847288 58.115 35.66681464607763 139.73813900955537 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e93fa866-a583-464f-99ed-b31f08d38440">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e93fa866-a583-464f-99ed-b31f08d38440">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e93fa866-a583-464f-99ed-b31f08d38440">
											<gml:posList>35.66682259105386 139.73815531472457 57.867 35.66682259105386 139.73815531472457 58.926 35.666813033449955 139.7381400608177 58.926 35.666813033449955 139.7381400608177 57.867 35.66682259105386 139.73815531472457 57.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a37f5ff-94bd-49d4-a42c-9b54e53fc9fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a37f5ff-94bd-49d4-a42c-9b54e53fc9fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a37f5ff-94bd-49d4-a42c-9b54e53fc9fc">
											<gml:posList>35.66679617747982 139.73815110450178 57.867 35.66679617747982 139.73815110450178 58.926 35.66680708044976 139.7381692949841 58.926 35.66680708044976 139.7381692949841 57.867 35.66679617747982 139.73815110450178 57.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9150e59d-dc87-483e-b816-a4b3c7cf00e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9150e59d-dc87-483e-b816-a4b3c7cf00e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9150e59d-dc87-483e-b816-a4b3c7cf00e5">
											<gml:posList>35.66680471106151 139.7381708442033 58.926 35.666792219580365 139.73815000462326 58.926 35.666792219580365 139.73815000462326 12.45 35.66680471106151 139.7381708442033 12.45 35.66680471106151 139.7381708442033 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e219ac4-f4df-4565-9b6d-62807e642336">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e219ac4-f4df-4565-9b6d-62807e642336">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e219ac4-f4df-4565-9b6d-62807e642336">
											<gml:posList>35.66680708044976 139.7381692949841 57.867 35.66680708044976 139.7381692949841 58.926 35.66682259105386 139.73815531472457 58.926 35.66682259105386 139.73815531472457 57.867 35.66680708044976 139.7381692949841 57.867</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19cc7d05-ce6d-4863-96e5-ac9cdadb3906">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19cc7d05-ce6d-4863-96e5-ac9cdadb3906">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19cc7d05-ce6d-4863-96e5-ac9cdadb3906">
											<gml:posList>35.666825286769495 139.7381560847288 58.115 35.666825286769495 139.7381560847288 58.926 35.6668083259765 139.7381713590644 58.926 35.6668083259765 139.7381713590644 58.115 35.666825286769495 139.7381560847288 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61f553f8-fc62-4c41-b683-8d5c78b1252f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61f553f8-fc62-4c41-b683-8d5c78b1252f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61f553f8-fc62-4c41-b683-8d5c78b1252f">
											<gml:posList>35.666764661760865 139.73816923486723 58.926 35.66678167287762 139.73819482980463 58.926 35.66678167287762 139.73819482980463 12.45 35.666764661760865 139.73816923486723 12.45 35.666764661760865 139.73816923486723 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85307b8e-4364-4fa6-acee-1f45f2c54c36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85307b8e-4364-4fa6-acee-1f45f2c54c36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85307b8e-4364-4fa6-acee-1f45f2c54c36">
											<gml:posList>35.66678167287762 139.73819482980463 58.926 35.66680471106151 139.7381708442033 58.926 35.66680471106151 139.7381708442033 12.45 35.66678167287762 139.73819482980463 12.45 35.66678167287762 139.73819482980463 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53e1da85-b0ed-473d-8a55-98192a08fa38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53e1da85-b0ed-473d-8a55-98192a08fa38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53e1da85-b0ed-473d-8a55-98192a08fa38">
											<gml:posList>35.6668083259765 139.7381713590644 58.115 35.6668083259765 139.7381713590644 58.926 35.666781334003716 139.7381994473358 58.926 35.666781334003716 139.7381994473358 58.115 35.6668083259765 139.7381713590644 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d631b234-af09-41ab-bf91-42c19d367a70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d631b234-af09-41ab-bf91-42c19d367a70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d631b234-af09-41ab-bf91-42c19d367a70">
											<gml:posList>35.666781334003716 139.7381994473358 58.115 35.666781334003716 139.7381994473358 58.926 35.66676425069957 139.73817375307135 58.926 35.66676425069957 139.73817375307135 58.115 35.666781334003716 139.7381994473358 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15ee525e-29b1-44b6-a6f5-7e96dd05ffc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15ee525e-29b1-44b6-a6f5-7e96dd05ffc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15ee525e-29b1-44b6-a6f5-7e96dd05ffc6">
											<gml:posList>35.66672019422142 139.7382113498745 58.926 35.666764661760865 139.73816923486723 58.926 35.666764661760865 139.73816923486723 12.45 35.66672019422142 139.7382113498745 12.45 35.66672019422142 139.7382113498745 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4738b30f-238f-4d8f-a4bf-be7baff1ea3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4738b30f-238f-4d8f-a4bf-be7baff1ea3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4738b30f-238f-4d8f-a4bf-be7baff1ea3c">
											<gml:posList>35.66676425069957 139.73817375307135 58.115 35.66676425069957 139.73817375307135 58.926 35.6667240254483 139.73821184238878 58.926 35.6667240254483 139.73821184238878 58.115 35.66676425069957 139.73817375307135 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e5f9fdb-23d8-4564-a9a2-3322ac9275be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e5f9fdb-23d8-4564-a9a2-3322ac9275be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e5f9fdb-23d8-4564-a9a2-3322ac9275be">
											<gml:posList>35.66684327495727 139.73827752268667 58.115 35.66684327495727 139.73827752268667 58.926 35.66689830486522 139.73819895509823 58.926 35.66689830486522 139.73819895509823 58.115 35.66684327495727 139.73827752268667 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c52ed8d-6f9c-4a7e-8e49-78a7f0ec257a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c52ed8d-6f9c-4a7e-8e49-78a7f0ec257a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c52ed8d-6f9c-4a7e-8e49-78a7f0ec257a">
											<gml:posList>35.66690100086852 139.73820008961505 58.926 35.66684625907653 139.73827824817025 58.926 35.66684625907653 139.73827824817025 12.45 35.66690100086852 139.73820008961505 12.45 35.66690100086852 139.73820008961505 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7739a9ee-f26d-435f-815f-c89a0491176a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7739a9ee-f26d-435f-815f-c89a0491176a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7739a9ee-f26d-435f-815f-c89a0491176a">
											<gml:posList>35.6667240254483 139.73821184238878 58.115 35.6667240254483 139.73821184238878 58.926 35.66680684784081 139.73833132561558 58.926 35.66680684784081 139.73833132561558 58.115 35.6667240254483 139.73821184238878 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2af9d13-d249-47fc-b695-0ba02364f7e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2af9d13-d249-47fc-b695-0ba02364f7e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2af9d13-d249-47fc-b695-0ba02364f7e3">
											<gml:posList>35.66680655403903 139.73833595413998 58.926 35.66672019422142 139.7382113498745 58.926 35.66672019422142 139.7382113498745 12.45 35.66680655403903 139.73833595413998 12.45 35.66680655403903 139.73833595413998 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83659ab1-6fae-4225-9e5c-b0a557127064">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83659ab1-6fae-4225-9e5c-b0a557127064">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83659ab1-6fae-4225-9e5c-b0a557127064">
											<gml:posList>35.666846348718295 139.7382890397836 58.115 35.666846348718295 139.7382890397836 58.926 35.66684327495727 139.73827752268667 58.926 35.66684327495727 139.73827752268667 58.115 35.666846348718295 139.7382890397836 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08d7f52b-3531-40fb-a84e-bf90767bebcc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08d7f52b-3531-40fb-a84e-bf90767bebcc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08d7f52b-3531-40fb-a84e-bf90767bebcc">
											<gml:posList>35.66684625907653 139.73827824817025 58.926 35.666849423210145 139.7382900633964 58.926 35.666849423210145 139.7382900633964 12.45 35.66684625907653 139.73827824817025 12.45 35.66684625907653 139.73827824817025 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e34a9af-e379-4b6c-b272-e6816ed54a57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e34a9af-e379-4b6c-b272-e6816ed54a57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e34a9af-e379-4b6c-b272-e6816ed54a57">
											<gml:posList>35.66680684784081 139.73833132561558 58.115 35.66680684784081 139.73833132561558 58.926 35.666846348718295 139.7382890397836 58.926 35.666846348718295 139.7382890397836 58.115 35.66680684784081 139.73833132561558 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ab71e85-55bd-4a3e-b53a-d23524fcf35f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ab71e85-55bd-4a3e-b53a-d23524fcf35f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ab71e85-55bd-4a3e-b53a-d23524fcf35f">
											<gml:posList>35.666849423210145 139.7382900633964 58.926 35.66680655403903 139.73833595413998 58.926 35.66680655403903 139.73833595413998 12.45 35.666849423210145 139.7382900633964 12.45 35.666849423210145 139.7382900633964 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6825736-b168-41df-a04d-b8791ffdd80b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6825736-b168-41df-a04d-b8791ffdd80b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6825736-b168-41df-a04d-b8791ffdd80b">
											<gml:posList>35.666863618473286 139.73811718019624 58.926 35.66689998762656 139.7381725868255 58.926 35.66689998762656 139.7381725868255 12.45 35.666863618473286 139.73811718019624 12.45 35.666863618473286 139.73811718019624 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7e4b51c-7edc-4c00-8efc-c89aed3b0cc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7e4b51c-7edc-4c00-8efc-c89aed3b0cc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7e4b51c-7edc-4c00-8efc-c89aed3b0cc5">
											<gml:posList>35.666897374614535 139.73817381600793 58.115 35.666897374614535 139.73817381600793 58.926 35.666863017942276 139.73812146666992 58.926 35.666863017942276 139.73812146666992 58.115 35.666897374614535 139.73817381600793 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c926d16e-57d7-4dda-8118-1ac452b47bcd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c926d16e-57d7-4dda-8118-1ac452b47bcd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c926d16e-57d7-4dda-8118-1ac452b47bcd">
											<gml:posList>35.66689998762656 139.7381725868255 58.926 35.66690100086852 139.73820008961505 58.926 35.66690100086852 139.73820008961505 12.45 35.66689998762656 139.7381725868255 12.45 35.66689998762656 139.7381725868255 58.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-110afc71-4183-44a8-bc28-f19b854ac543">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-110afc71-4183-44a8-bc28-f19b854ac543">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-110afc71-4183-44a8-bc28-f19b854ac543">
											<gml:posList>35.66689830486522 139.73819895509823 58.115 35.66689830486522 139.73819895509823 58.926 35.666897374614535 139.73817381600793 58.926 35.666897374614535 139.73817381600793 58.115 35.66689830486522 139.73819895509823 58.115</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4244</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">218.25615</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>