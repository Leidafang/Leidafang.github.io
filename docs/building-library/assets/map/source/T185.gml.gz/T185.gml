<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_30b37cad-48c1-407c-8dbd-8fd49c0ac052">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">421</bldg:usage>
			<bldg:measuredHeight uom="m">43.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6689885732721 139.74346945913223 0 35.669051164406255 139.74303538863234 0 35.668254761770704 139.74286297427884 0 35.66823422730951 139.74300549038384 0 35.668404704711364 139.7430424128569 0 35.6683839996048 139.74318603397313 0 35.66821276565545 139.74314986318032 0 35.668191630337496 139.74329693074705 0 35.6689885732721 139.74346945913223 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
							<gml:interior>
								<gml:LinearRing>
									<gml:posList>35.668709933656 139.74325488195606 0 35.66873027756544 139.7431102886291 0 35.668838999979876 139.74313270022859 0 35.66881858433917 139.74327783508272 0 35.668709933656 139.74325488195606 0</gml:posList>
								</gml:LinearRing>
							</gml:interior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689885732721 139.74346945913223 10.02 35.668191630337496 139.74329693074705 10.02 35.66821276565545 139.74314986318032 10.02 35.6683839996048 139.74318603397313 10.02 35.668404704711364 139.7430424128569 10.02 35.66823422730951 139.74300549038384 10.02 35.668254761770704 139.74286297427884 10.02 35.669051164406255 139.74303538863234 10.02 35.6689885732721 139.74346945913223 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
									<gml:interior>
										<gml:LinearRing>
											<gml:posList>35.668709933656 139.74325488195606 10.02 35.66881858433917 139.74327783508272 10.02 35.668838999979876 139.74313270022859 10.02 35.66873027756544 139.7431102886291 10.02 35.668709933656 139.74325488195606 10.02</gml:posList>
										</gml:LinearRing>
									</gml:interior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689885732721 139.74346945913223 10.02 35.669051164406255 139.74303538863234 10.02 35.669051164406255 139.74303538863234 25.53 35.6689885732721 139.74346945913223 25.53 35.6689885732721 139.74346945913223 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669051164406255 139.74303538863234 10.02 35.668254761770704 139.74286297427884 10.02 35.668254761770704 139.74286297427884 25.53 35.669051164406255 139.74303538863234 25.53 35.669051164406255 139.74303538863234 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668254761770704 139.74286297427884 10.02 35.66823422730951 139.74300549038384 10.02 35.66823422730951 139.74300549038384 25.53 35.668254761770704 139.74286297427884 25.53 35.668254761770704 139.74286297427884 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66823422730951 139.74300549038384 10.02 35.668404704711364 139.7430424128569 10.02 35.668404704711364 139.7430424128569 25.53 35.66823422730951 139.74300549038384 25.53 35.66823422730951 139.74300549038384 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668404704711364 139.7430424128569 10.02 35.6683839996048 139.74318603397313 10.02 35.6683839996048 139.74318603397313 25.53 35.668404704711364 139.7430424128569 25.53 35.668404704711364 139.7430424128569 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683839996048 139.74318603397313 10.02 35.66821276565545 139.74314986318032 10.02 35.66821276565545 139.74314986318032 25.53 35.6683839996048 139.74318603397313 25.53 35.6683839996048 139.74318603397313 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66821276565545 139.74314986318032 10.02 35.668191630337496 139.74329693074705 10.02 35.668191630337496 139.74329693074705 25.53 35.66821276565545 139.74314986318032 25.53 35.66821276565545 139.74314986318032 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668191630337496 139.74329693074705 10.02 35.6689885732721 139.74346945913223 10.02 35.6689885732721 139.74346945913223 25.53 35.668191630337496 139.74329693074705 25.53 35.668191630337496 139.74329693074705 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668709933656 139.74325488195606 10.02 35.66873027756544 139.7431102886291 10.02 35.66873027756544 139.7431102886291 25.53 35.668709933656 139.74325488195606 25.53 35.668709933656 139.74325488195606 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66873027756544 139.7431102886291 10.02 35.668838999979876 139.74313270022859 10.02 35.668838999979876 139.74313270022859 25.53 35.66873027756544 139.7431102886291 25.53 35.66873027756544 139.7431102886291 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668838999979876 139.74313270022859 10.02 35.66881858433917 139.74327783508272 10.02 35.66881858433917 139.74327783508272 25.53 35.668838999979876 139.74313270022859 25.53 35.668838999979876 139.74313270022859 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881858433917 139.74327783508272 10.02 35.668709933656 139.74325488195606 10.02 35.668709933656 139.74325488195606 25.53 35.66881858433917 139.74327783508272 25.53 35.66881858433917 139.74327783508272 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689885732721 139.74346945913223 25.53 35.669051164406255 139.74303538863234 25.53 35.668254761770704 139.74286297427884 25.53 35.66823422730951 139.74300549038384 25.53 35.668404704711364 139.7430424128569 25.53 35.6683839996048 139.74318603397313 25.53 35.66821276565545 139.74314986318032 25.53 35.668191630337496 139.74329693074705 25.53 35.6689885732721 139.74346945913223 25.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
									<gml:interior>
										<gml:LinearRing>
											<gml:posList>35.668709933656 139.74325488195606 25.53 35.66873027756544 139.7431102886291 25.53 35.668838999979876 139.74313270022859 25.53 35.66881858433917 139.74327783508272 25.53 35.668709933656 139.74325488195606 25.53</gml:posList>
										</gml:LinearRing>
									</gml:interior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7a0682bd-6aeb-42c0-a4be-7357f6b1301f"/>
							<gml:surfaceMember xlink:href="#poly-c87f3089-1cd8-4d87-91ee-2bdcb321376f"/>
							<gml:surfaceMember xlink:href="#poly-ee6c9a9b-3e44-4427-ab04-ec1a4a3193d4"/>
							<gml:surfaceMember xlink:href="#poly-318e9107-f047-492f-b0df-fde5e6296390"/>
							<gml:surfaceMember xlink:href="#poly-bdec4fab-5af9-4e58-a8c6-884f6cdc233e"/>
							<gml:surfaceMember xlink:href="#poly-bbc29389-6b88-4b9f-b6d2-c90730298818"/>
							<gml:surfaceMember xlink:href="#poly-985152fc-ff32-4fc0-a65f-34d737db6aad"/>
							<gml:surfaceMember xlink:href="#poly-35f406db-0128-40ce-8337-2b3570b546b4"/>
							<gml:surfaceMember xlink:href="#poly-a3b8ece8-505e-49e3-bbc3-a48e985fc552"/>
							<gml:surfaceMember xlink:href="#poly-b9282ce7-bcce-4df4-b5ce-4ed9cd1965f3"/>
							<gml:surfaceMember xlink:href="#poly-55dadbe3-f9ce-4524-a4c3-45c879a06b8f"/>
							<gml:surfaceMember xlink:href="#poly-a3c4c766-2842-48b4-83f5-eb4ef6e771a3"/>
							<gml:surfaceMember xlink:href="#poly-3de06d60-7da4-48ed-a919-4cfc5badc004"/>
							<gml:surfaceMember xlink:href="#poly-c559b22e-8ecf-45a2-8d62-3dc3de4e88c5"/>
							<gml:surfaceMember xlink:href="#poly-97e37d63-93c3-4e2a-8ae5-1159dce315bb"/>
							<gml:surfaceMember xlink:href="#poly-6d81a5a6-298a-42d4-b546-ae82657ac605"/>
							<gml:surfaceMember xlink:href="#poly-6caad63d-3704-4dba-8651-4c9dbc2fd2aa"/>
							<gml:surfaceMember xlink:href="#poly-e4388de2-8b02-4266-9c5d-1d4cd2f68b4f"/>
							<gml:surfaceMember xlink:href="#poly-5ea7aaef-a819-4c40-af53-fbb19bbc85b9"/>
							<gml:surfaceMember xlink:href="#poly-bc446328-5111-42ec-bb17-cda6af8b5969"/>
							<gml:surfaceMember xlink:href="#poly-c3e1fa8e-45d4-4412-b81e-7d75b8e7509c"/>
							<gml:surfaceMember xlink:href="#poly-bd6e2198-f7f3-4cab-b430-18262960a151"/>
							<gml:surfaceMember xlink:href="#poly-dd7d81f1-fcfd-4090-ab80-81bd5c935445"/>
							<gml:surfaceMember xlink:href="#poly-8534429d-84d3-4ee3-8c2e-e0eb6d7ecddd"/>
							<gml:surfaceMember xlink:href="#poly-b52d9382-46ad-4e59-b1ce-d3c3f01c78a0"/>
							<gml:surfaceMember xlink:href="#poly-0ae120e8-044d-4836-9cd3-a3c347162ded"/>
							<gml:surfaceMember xlink:href="#poly-cd9c7110-bff6-42fa-af80-d6882712ee48"/>
							<gml:surfaceMember xlink:href="#poly-19d4203b-7ec4-4d4e-9acb-a80d32adefe6"/>
							<gml:surfaceMember xlink:href="#poly-b0b29e3e-f0e9-49f8-83e2-f5e49f12f81d"/>
							<gml:surfaceMember xlink:href="#poly-22d2ac3c-3da1-4ec0-b484-55e7b77e0da2"/>
							<gml:surfaceMember xlink:href="#poly-132623c8-3f4a-47b7-9eb7-52a23b79ae28"/>
							<gml:surfaceMember xlink:href="#poly-65a3ed31-d7b1-485e-9819-73cf931e54e4"/>
							<gml:surfaceMember xlink:href="#poly-e78fbd52-9905-43cf-9489-dbd7e9291ea7"/>
							<gml:surfaceMember xlink:href="#poly-e4fcd824-26b0-458d-9096-1ad9e603eeaa"/>
							<gml:surfaceMember xlink:href="#poly-75709687-82f7-4b50-acfe-410597d65261"/>
							<gml:surfaceMember xlink:href="#poly-e652e20f-eece-4577-9239-4eff20375efd"/>
							<gml:surfaceMember xlink:href="#poly-c6e4ad63-35e3-4d52-b4f8-9fa1de0ef906"/>
							<gml:surfaceMember xlink:href="#poly-69f835f3-343f-4c29-ad62-1765319afe7e"/>
							<gml:surfaceMember xlink:href="#poly-8fc1b9c4-eebc-421b-8c98-23fe852c887d"/>
							<gml:surfaceMember xlink:href="#poly-e5f21659-8c9a-46b9-a855-1bf125043756"/>
							<gml:surfaceMember xlink:href="#poly-2a598526-91ce-4b25-a931-2f8474b80725"/>
							<gml:surfaceMember xlink:href="#poly-e7324419-b706-4361-a95b-c388201b3620"/>
							<gml:surfaceMember xlink:href="#poly-16b0cf2f-46b5-406e-b4fc-dcb52431b97c"/>
							<gml:surfaceMember xlink:href="#poly-78c74f53-0af0-4182-ac6c-21b02b6398b7"/>
							<gml:surfaceMember xlink:href="#poly-30108ddb-7a75-4963-ab03-702a3728be55"/>
							<gml:surfaceMember xlink:href="#poly-3e27a0ff-7eec-44fd-b5de-7a55f8ae7263"/>
							<gml:surfaceMember xlink:href="#poly-6deec83e-96fe-4e1b-b6be-e9f8001c2207"/>
							<gml:surfaceMember xlink:href="#poly-b69d9b01-4c51-4efc-9100-72bb1e7cf75b"/>
							<gml:surfaceMember xlink:href="#poly-e93d6830-3f6a-4279-a24c-fafbb5fcb5fd"/>
							<gml:surfaceMember xlink:href="#poly-fa4a8ddd-a679-4a53-b031-0d30c4791e18"/>
							<gml:surfaceMember xlink:href="#poly-a51cb135-0fb1-48ee-b2d8-ac0b12cefb29"/>
							<gml:surfaceMember xlink:href="#poly-150f49a5-7681-483a-8e5d-6ef54c2e4bb5"/>
							<gml:surfaceMember xlink:href="#poly-34275d73-fb7c-4e0e-a3d5-d14c8e55f603"/>
							<gml:surfaceMember xlink:href="#poly-94efcdf5-c8e6-40f6-a1b8-d64eee923137"/>
							<gml:surfaceMember xlink:href="#poly-e2fb375c-8daf-4a14-b5c6-b509ad11bf8b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_30b37cad-48c1-407c-8dbd-8fd49c0ac052_BuildingInstallation_1030">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f72626cd-ee8e-4f00-8153-12ef2dbc3685">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668584169622534 139.74324897002646 59.394 35.668582071912624 139.74326434843192 59.394 35.66857174960987 139.74326223919286 59.394 35.66857384731951 139.74324686078933 59.394 35.668584169622534 139.74324897002646 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1add00b-49bc-4bed-bfbe-34ec0335ce4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1add00b-49bc-4bed-bfbe-34ec0335ce4d_0">
											<gml:posList>35.66857174960987 139.74326223919286 61.159 35.668582071912624 139.74326434843192 61.159 35.668584169622534 139.74324897002646 61.159 35.66857384731951 139.74324686078933 61.159 35.66857174960987 139.74326223919286 61.159</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78b7a819-d401-477e-98c1-43c21a7346de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78b7a819-d401-477e-98c1-43c21a7346de_0">
											<gml:posList>35.66857384731951 139.74324686078933 59.394 35.66857384731951 139.74324686078933 61.159 35.668584169622534 139.74324897002646 61.159 35.668584169622534 139.74324897002646 59.394 35.66857384731951 139.74324686078933 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb6709a1-800b-4d71-9f36-8c25a8c30add">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb6709a1-800b-4d71-9f36-8c25a8c30add_0">
											<gml:posList>35.668584169622534 139.74324897002646 59.394 35.668584169622534 139.74324897002646 61.159 35.668582071912624 139.74326434843192 61.159 35.668582071912624 139.74326434843192 59.394 35.668584169622534 139.74324897002646 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11ad4abb-066b-4b4b-a465-3c4adba78b7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11ad4abb-066b-4b4b-a465-3c4adba78b7d_0">
											<gml:posList>35.668582071912624 139.74326434843192 59.394 35.668582071912624 139.74326434843192 61.159 35.66857174960987 139.74326223919286 61.159 35.66857174960987 139.74326223919286 59.394 35.668582071912624 139.74326434843192 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-926459a8-a49c-40fd-8d05-d3652ed6a959">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-926459a8-a49c-40fd-8d05-d3652ed6a959_0">
											<gml:posList>35.66857174960987 139.74326223919286 59.394 35.66857174960987 139.74326223919286 61.159 35.66857384731951 139.74324686078933 61.159 35.66857384731951 139.74324686078933 59.394 35.66857174960987 139.74326223919286 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_30b37cad-48c1-407c-8dbd-8fd49c0ac052_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a74e0c19-fb03-48b5-93ca-db0bc195cdac">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668557310147996 139.7432870647483 59.394 35.668645737969726 139.74330325832338 59.394 35.66864064935087 139.74334497380875 59.394 35.66855222154287 139.74332879123466 59.394 35.668557310147996 139.7432870647483 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7848355c-619f-4cfe-92aa-18519238f6b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7848355c-619f-4cfe-92aa-18519238f6b3_0">
											<gml:posList>35.66855222154287 139.74332879123466 59.394 35.66855222154287 139.74332879123466 63.628 35.668557310147996 139.7432870647483 63.628 35.668557310147996 139.7432870647483 59.394 35.66855222154287 139.74332879123466 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac67d5aa-25de-426f-988b-892bbf91a18e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac67d5aa-25de-426f-988b-892bbf91a18e_0">
											<gml:posList>35.66864064935087 139.74334497380875 59.394 35.66864064935087 139.74334497380875 63.628 35.66855222154287 139.74332879123466 63.628 35.66855222154287 139.74332879123466 59.394 35.66864064935087 139.74334497380875 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a30e0cf9-b306-4f63-b106-a2a475c7a639">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a30e0cf9-b306-4f63-b106-a2a475c7a639_0">
											<gml:posList>35.66864064935087 139.74334497380875 63.628 35.668645737969726 139.74330325832338 63.628 35.668557310147996 139.7432870647483 63.628 35.66855222154287 139.74332879123466 63.628 35.66864064935087 139.74334497380875 63.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f144511-921a-4d25-ae78-d89ec6f8f6d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f144511-921a-4d25-ae78-d89ec6f8f6d6_0">
											<gml:posList>35.668557310147996 139.7432870647483 63.628 35.668645737969726 139.74330325832338 63.628 35.668645737969726 139.74330325832338 59.394 35.668557310147996 139.7432870647483 59.394 35.668557310147996 139.7432870647483 63.628</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28d4fb62-1d06-421d-a103-50875dd7265e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28d4fb62-1d06-421d-a103-50875dd7265e_0">
											<gml:posList>35.668645737969726 139.74330325832338 59.394 35.668645737969726 139.74330325832338 63.628 35.66864064935087 139.74334497380875 63.628 35.66864064935087 139.74334497380875 59.394 35.668645737969726 139.74330325832338 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_30b37cad-48c1-407c-8dbd-8fd49c0ac052_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e106efee-3f5f-49a2-b725-c9c137f2ca33">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668224228386094 139.7432425369611 59.394 35.66822728467684 139.74321929282078 59.394 35.66833015561792 139.74323963435975 59.394 35.668327099323335 139.74326287852912 59.394 35.668224228386094 139.7432425369611 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f665719-1cf7-4250-8dee-c8d5b393f05d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66823307210559 139.74317194331528 59.394 35.66833755708207 139.743193045153 59.394 35.66833485896472 139.74321310768207 59.394 35.66823037399995 139.7431920168649 59.394 35.66823307210559 139.74317194331528 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc1f36b5-356a-4b70-9ddf-e8ed87fcf2cb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683614460557 139.7432446693076 59.394 35.66838007068702 139.74324768602787 59.394 35.66837883535345 139.7432591310552 59.394 35.66836021071414 139.74325610328634 59.394 35.6683614460557 139.7432446693076 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e215b246-977e-4eca-bea6-6eb074bf0878">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66836291204831 139.74326442892198 59.394 35.66837885009297 139.74326678590558 59.394 35.66837790183375 139.74327640802267 59.394 35.66836196378928 139.74327405103716 59.394 35.66836291204831 139.74326442892198 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97eb224d-9685-45e6-81a6-7c8b8028e15b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683968009792 139.74329696546914 59.394 35.66839441962967 139.7433187729198 59.394 35.66837622769204 139.74331579988063 59.394 35.66837860001906 139.743293981399 59.394 35.6683968009792 139.74329696546914 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b3316ad-bc42-4ba6-8520-82d01eea6f03">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840038281721 139.74321714314533 59.394 35.66839917432108 139.74322831199618 59.394 35.66838166752366 139.74322547075923 59.394 35.66838286701407 139.74321431296687 59.394 35.66840038281721 139.74321714314533 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da7716bb-3841-4531-8bb6-e29bf4bd02b2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66839994833142 139.7432147024705 59.394 35.66838392889774 139.74321199211664 59.394 35.6683850033853 139.74320242508608 59.394 35.6684010228192 139.7432051354381 59.394 35.66839994833142 139.7432147024705 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7afa427-2bc4-434c-8797-de180239f04b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668425857339756 139.74323147430272 59.394 35.668417663093855 139.7432304562336 59.394 35.668419208482156 139.74321176468266 59.394 35.66842740272822 139.7432127827499 59.394 35.668425857339756 139.74323147430272 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6da4a269-ddd2-4ce4-929d-54d36c6ca9b7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668491552112606 139.74323505670733 59.394 35.66850649877983 139.7432375915388 59.394 35.668504886953166 139.74325182059962 59.394 35.66848994028622 139.7432492857656 59.394 35.668491552112606 139.74323505670733 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42a276c9-d9ef-4983-81ed-2d1663a6429c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66860559240811 139.74328129973688 59.394 35.66860660324324 139.74327098162325 59.394 35.668626399583204 139.74327389762857 59.394 35.66862538874783 139.74328421574467 59.394 35.66860559240811 139.74328129973688 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f9c08a6-b2f2-40fa-b14f-d27a94bc9912">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668629630429216 139.7432550494921 59.394 35.668628179377 139.7432673122026 59.394 35.6686079498823 139.7432637339245 59.394 35.66860939191217 139.74325146018114 59.394 35.668629630429216 139.7432550494921 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6256981-53d8-4eac-b0b7-cd38a86cdb47">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865135427738 139.74328015478625 59.394 35.66867248456581 139.74328295883709 59.394 35.66867158182832 139.7432931884694 59.394 35.6686504515401 139.74329038441596 59.394 35.66865135427738 139.74328015478625 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d111e932-d68f-43f7-b945-5260480edf44">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66865088905051 139.74326071431094 59.394 35.66869388135929 139.7432684866032 59.394 35.66869266305175 139.74327859508657 59.394 35.668649670743605 139.74327082278901 59.394 35.66865088905051 139.74326071431094 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21effca9-a3ea-47a8-b1c2-6e899f0a87d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21effca9-a3ea-47a8-b1c2-6e899f0a87d6_0">
											<gml:posList>35.66838392889774 139.74321199211664 59.394 35.66839994833142 139.7432147024705 59.394 35.66839994833142 139.7432147024705 61.932 35.66838392889774 139.74321199211664 61.932 35.66838392889774 139.74321199211664 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07f63146-2731-494d-a21f-ee984929c64b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07f63146-2731-494d-a21f-ee984929c64b_0">
											<gml:posList>35.66823307210559 139.74317194331528 59.394 35.66823037399995 139.7431920168649 59.394 35.66823037399995 139.7431920168649 63.355 35.66823307210559 139.74317194331528 63.355 35.66823307210559 139.74317194331528 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bee13e8-7043-4981-92c4-3409359c1e11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9bee13e8-7043-4981-92c4-3409359c1e11_0">
											<gml:posList>35.66823307210559 139.74317194331528 59.394 35.66823307210559 139.74317194331528 63.355 35.66833755708207 139.743193045153 63.355 35.66833755708207 139.743193045153 59.394 35.66823307210559 139.74317194331528 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4499c390-7162-4493-9c00-4db4169740a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4499c390-7162-4493-9c00-4db4169740a4_0">
											<gml:posList>35.66833485896472 139.74321310768207 63.355 35.66833755708207 139.743193045153 63.355 35.66823307210559 139.74317194331528 63.355 35.66823037399995 139.7431920168649 63.355 35.66833485896472 139.74321310768207 63.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dd4dd2b-dda4-47bb-94a2-7287d27eec3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1dd4dd2b-dda4-47bb-94a2-7287d27eec3d_0">
											<gml:posList>35.66823037399995 139.7431920168649 59.394 35.66833485896472 139.74321310768207 59.394 35.66833485896472 139.74321310768207 63.355 35.66823037399995 139.7431920168649 63.355 35.66823037399995 139.7431920168649 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6f62c07-ce9e-4a15-91f4-880045bc4b66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6f62c07-ce9e-4a15-91f4-880045bc4b66_0">
											<gml:posList>35.66833485896472 139.74321310768207 59.394 35.66833755708207 139.743193045153 59.394 35.66833755708207 139.743193045153 63.355 35.66833485896472 139.74321310768207 63.355 35.66833485896472 139.74321310768207 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e0fc10c-d936-443a-b353-5dab6a3468ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e0fc10c-d936-443a-b353-5dab6a3468ac_0">
											<gml:posList>35.6683850033853 139.74320242508608 59.394 35.6683850033853 139.74320242508608 61.932 35.6684010228192 139.7432051354381 61.932 35.6684010228192 139.7432051354381 59.394 35.6683850033853 139.74320242508608 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13104058-a692-476a-8c51-1d629ff06d1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13104058-a692-476a-8c51-1d629ff06d1b_0">
											<gml:posList>35.6683850033853 139.74320242508608 59.394 35.66838392889774 139.74321199211664 59.394 35.66838392889774 139.74321199211664 61.932 35.6683850033853 139.74320242508608 61.932 35.6683850033853 139.74320242508608 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1c369db-82fe-4c2a-93e3-73f1b43e2717">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1c369db-82fe-4c2a-93e3-73f1b43e2717_0">
											<gml:posList>35.66839994833142 139.7432147024705 61.932 35.6684010228192 139.7432051354381 61.932 35.6683850033853 139.74320242508608 61.932 35.66838392889774 139.74321199211664 61.932 35.66839994833142 139.7432147024705 61.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d07bb4fe-2c77-4c0b-9df7-fc9a6136dbfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d07bb4fe-2c77-4c0b-9df7-fc9a6136dbfa_0">
											<gml:posList>35.66839994833142 139.7432147024705 59.394 35.6684010228192 139.7432051354381 59.394 35.6684010228192 139.7432051354381 61.932 35.66839994833142 139.7432147024705 61.932 35.66839994833142 139.7432147024705 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2b4a5fc-e881-436d-bee9-87bdb5a9d6fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2b4a5fc-e881-436d-bee9-87bdb5a9d6fa_0">
											<gml:posList>35.66842740272822 139.7432127827499 59.394 35.668419208482156 139.74321176468266 59.394 35.668419208482156 139.74321176468266 62.128 35.66842740272822 139.7432127827499 62.128 35.66842740272822 139.7432127827499 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f19c4fc-3a72-4780-9bbb-122908b06a01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f19c4fc-3a72-4780-9bbb-122908b06a01_0">
											<gml:posList>35.66840038281721 139.74321714314533 59.394 35.66838286701407 139.74321431296687 59.394 35.66838286701407 139.74321431296687 61.932 35.66840038281721 139.74321714314533 61.932 35.66840038281721 139.74321714314533 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73739100-ab95-46a3-b531-eb3e77ffa793">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73739100-ab95-46a3-b531-eb3e77ffa793_0">
											<gml:posList>35.66838286701407 139.74321431296687 59.394 35.66838166752366 139.74322547075923 59.394 35.66838166752366 139.74322547075923 61.932 35.66838286701407 139.74321431296687 61.932 35.66838286701407 139.74321431296687 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-660665c1-905c-4ed0-85cd-890ce0beb863">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-660665c1-905c-4ed0-85cd-890ce0beb863_0">
											<gml:posList>35.668417663093855 139.7432304562336 59.394 35.668417663093855 139.7432304562336 62.128 35.668419208482156 139.74321176468266 62.128 35.668419208482156 139.74321176468266 59.394 35.668417663093855 139.7432304562336 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9becabbf-ba13-4c05-9266-5739aec7c4ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9becabbf-ba13-4c05-9266-5739aec7c4ee_0">
											<gml:posList>35.66838166752366 139.74322547075923 61.932 35.66839917432108 139.74322831199618 61.932 35.66840038281721 139.74321714314533 61.932 35.66838286701407 139.74321431296687 61.932 35.66838166752366 139.74322547075923 61.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a171748f-3bd4-4305-b0c1-39b3b747b0e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a171748f-3bd4-4305-b0c1-39b3b747b0e8_0">
											<gml:posList>35.668425857339756 139.74323147430272 62.128 35.66842740272822 139.7432127827499 62.128 35.668419208482156 139.74321176468266 62.128 35.668417663093855 139.7432304562336 62.128 35.668425857339756 139.74323147430272 62.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e962952-9b5b-46fc-973e-2c980b0d3767">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e962952-9b5b-46fc-973e-2c980b0d3767_0">
											<gml:posList>35.668425857339756 139.74323147430272 59.394 35.66842740272822 139.7432127827499 59.394 35.66842740272822 139.7432127827499 62.128 35.668425857339756 139.74323147430272 62.128 35.668425857339756 139.74323147430272 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e49e5ae-e7bb-4409-aa6f-d828e9afe37c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e49e5ae-e7bb-4409-aa6f-d828e9afe37c_0">
											<gml:posList>35.66839917432108 139.74322831199618 59.394 35.66840038281721 139.74321714314533 59.394 35.66840038281721 139.74321714314533 61.932 35.66839917432108 139.74322831199618 61.932 35.66839917432108 139.74322831199618 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cea6c84-9610-4929-b2c5-f22c69441542">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cea6c84-9610-4929-b2c5-f22c69441542_0">
											<gml:posList>35.66838166752366 139.74322547075923 59.394 35.66839917432108 139.74322831199618 59.394 35.66839917432108 139.74322831199618 61.932 35.66838166752366 139.74322547075923 61.932 35.66838166752366 139.74322547075923 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88604a73-a462-42cb-9a63-68f52cd63a48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88604a73-a462-42cb-9a63-68f52cd63a48_0">
											<gml:posList>35.66833015561792 139.74323963435975 59.394 35.66822728467684 139.74321929282078 59.394 35.66822728467684 139.74321929282078 63.355 35.66833015561792 139.74323963435975 63.355 35.66833015561792 139.74323963435975 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ce355b4-5331-4728-a602-3842b8a51d16">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ce355b4-5331-4728-a602-3842b8a51d16_0">
											<gml:posList>35.66822728467684 139.74321929282078 59.394 35.668224228386094 139.7432425369611 59.394 35.668224228386094 139.7432425369611 63.355 35.66822728467684 139.74321929282078 63.355 35.66822728467684 139.74321929282078 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-048412f8-5847-46a2-8910-aa6726c97042">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-048412f8-5847-46a2-8910-aa6726c97042_0">
											<gml:posList>35.668425857339756 139.74323147430272 59.394 35.668425857339756 139.74323147430272 62.128 35.668417663093855 139.7432304562336 62.128 35.668417663093855 139.7432304562336 59.394 35.668425857339756 139.74323147430272 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5d1fab2-270d-4f55-94e8-0afadac28b42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5d1fab2-270d-4f55-94e8-0afadac28b42_0">
											<gml:posList>35.668491552112606 139.74323505670733 59.394 35.668491552112606 139.74323505670733 63.057 35.66850649877983 139.7432375915388 63.057 35.66850649877983 139.7432375915388 59.394 35.668491552112606 139.74323505670733 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7173e11c-c425-4f6d-9201-510274971143">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7173e11c-c425-4f6d-9201-510274971143_0">
											<gml:posList>35.668224228386094 139.7432425369611 63.355 35.668327099323335 139.74326287852912 63.355 35.66833015561792 139.74323963435975 63.355 35.66822728467684 139.74321929282078 63.355 35.668224228386094 139.7432425369611 63.355</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52076019-6d47-4918-9440-4355c902c3f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52076019-6d47-4918-9440-4355c902c3f2_0">
											<gml:posList>35.668491552112606 139.74323505670733 59.394 35.66848994028622 139.7432492857656 59.394 35.66848994028622 139.7432492857656 63.057 35.668491552112606 139.74323505670733 63.057 35.668491552112606 139.74323505670733 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6281f283-ac97-4052-a683-61c899809f2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6281f283-ac97-4052-a683-61c899809f2c_0">
											<gml:posList>35.668504886953166 139.74325182059962 63.057 35.66850649877983 139.7432375915388 63.057 35.668491552112606 139.74323505670733 63.057 35.66848994028622 139.7432492857656 63.057 35.668504886953166 139.74325182059962 63.057</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0299753-c255-4889-b5c7-7e80c6358240">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0299753-c255-4889-b5c7-7e80c6358240_0">
											<gml:posList>35.668504886953166 139.74325182059962 59.394 35.66850649877983 139.7432375915388 59.394 35.66850649877983 139.7432375915388 63.057 35.668504886953166 139.74325182059962 63.057 35.668504886953166 139.74325182059962 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d98970a-3daa-40a0-aa76-46b67a0869df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d98970a-3daa-40a0-aa76-46b67a0869df_0">
											<gml:posList>35.66838007068702 139.74324768602787 59.394 35.6683614460557 139.7432446693076 59.394 35.6683614460557 139.7432446693076 62.698 35.66838007068702 139.74324768602787 62.698 35.66838007068702 139.74324768602787 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c932077d-1f2f-4a8a-9496-2419fb3e6384">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c932077d-1f2f-4a8a-9496-2419fb3e6384_0">
											<gml:posList>35.66836021071414 139.74325610328634 59.394 35.66836021071414 139.74325610328634 62.698 35.6683614460557 139.7432446693076 62.698 35.6683614460557 139.7432446693076 59.394 35.66836021071414 139.74325610328634 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-185940df-78f5-420a-9e5e-f61e8bf361d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-185940df-78f5-420a-9e5e-f61e8bf361d1_0">
											<gml:posList>35.66848994028622 139.7432492857656 59.394 35.668504886953166 139.74325182059962 59.394 35.668504886953166 139.74325182059962 63.057 35.66848994028622 139.7432492857656 63.057 35.66848994028622 139.7432492857656 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebd711c0-727e-412a-b636-3511bf2c39a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebd711c0-727e-412a-b636-3511bf2c39a9_0">
											<gml:posList>35.668327099323335 139.74326287852912 59.394 35.66833015561792 139.74323963435975 59.394 35.66833015561792 139.74323963435975 63.355 35.668327099323335 139.74326287852912 63.355 35.668327099323335 139.74326287852912 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc55d7d4-769c-4778-98f6-7d9fd4298dbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc55d7d4-769c-4778-98f6-7d9fd4298dbc_0">
											<gml:posList>35.66837883535345 139.7432591310552 62.698 35.66838007068702 139.74324768602787 62.698 35.6683614460557 139.7432446693076 62.698 35.66836021071414 139.74325610328634 62.698 35.66837883535345 139.7432591310552 62.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4499158-c483-4f5a-9ec4-bd99ec2be959">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4499158-c483-4f5a-9ec4-bd99ec2be959_0">
											<gml:posList>35.668224228386094 139.7432425369611 59.394 35.668327099323335 139.74326287852912 59.394 35.668327099323335 139.74326287852912 63.355 35.668224228386094 139.7432425369611 63.355 35.668224228386094 139.7432425369611 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f46e8b3-f801-4efe-92ba-5110b291ea82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f46e8b3-f801-4efe-92ba-5110b291ea82_0">
											<gml:posList>35.66837883535345 139.7432591310552 59.394 35.66838007068702 139.74324768602787 59.394 35.66838007068702 139.74324768602787 62.698 35.66837883535345 139.7432591310552 62.698 35.66837883535345 139.7432591310552 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4653c834-1528-4a4d-ac78-e5ba7993d146">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4653c834-1528-4a4d-ac78-e5ba7993d146_0">
											<gml:posList>35.668629630429216 139.7432550494921 59.394 35.66860939191217 139.74325146018114 59.394 35.66860939191217 139.74325146018114 60.121 35.668629630429216 139.7432550494921 60.121 35.668629630429216 139.7432550494921 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3865608f-42c1-4cd5-b4d0-cbc23447d31c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3865608f-42c1-4cd5-b4d0-cbc23447d31c_0">
											<gml:posList>35.66836021071414 139.74325610328634 59.394 35.66837883535345 139.7432591310552 59.394 35.66837883535345 139.7432591310552 62.698 35.66836021071414 139.74325610328634 62.698 35.66836021071414 139.74325610328634 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6552ad84-5bb5-48fb-ba88-13b984b42f31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6552ad84-5bb5-48fb-ba88-13b984b42f31_0">
											<gml:posList>35.66860939191217 139.74325146018114 59.394 35.6686079498823 139.7432637339245 59.394 35.6686079498823 139.7432637339245 60.121 35.66860939191217 139.74325146018114 60.121 35.66860939191217 139.74325146018114 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edb1ff37-d608-45c4-a92f-b153a4790c88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edb1ff37-d608-45c4-a92f-b153a4790c88_0">
											<gml:posList>35.6686079498823 139.7432637339245 60.121 35.668628179377 139.7432673122026 60.121 35.668629630429216 139.7432550494921 60.121 35.66860939191217 139.74325146018114 60.121 35.6686079498823 139.7432637339245 60.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ce9a572-2880-4465-ae0a-b4de4297338f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ce9a572-2880-4465-ae0a-b4de4297338f_0">
											<gml:posList>35.668628179377 139.7432673122026 59.394 35.668629630429216 139.7432550494921 59.394 35.668629630429216 139.7432550494921 60.121 35.668628179377 139.7432673122026 60.121 35.668628179377 139.7432673122026 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d00590b-c584-47f0-94c2-e1c2745218c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d00590b-c584-47f0-94c2-e1c2745218c0_0">
											<gml:posList>35.66869388135929 139.7432684866032 59.394 35.66865088905051 139.74326071431094 59.394 35.66865088905051 139.74326071431094 60.249 35.66869388135929 139.7432684866032 60.249 35.66869388135929 139.7432684866032 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9143b3c4-49c5-42fc-8b35-d171587a0e87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9143b3c4-49c5-42fc-8b35-d171587a0e87_0">
											<gml:posList>35.66837885009297 139.74326678590558 59.394 35.66836291204831 139.74326442892198 59.394 35.66836291204831 139.74326442892198 62.698 35.66837885009297 139.74326678590558 62.698 35.66837885009297 139.74326678590558 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-571c4906-d610-4452-8755-3ec0a655e811">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-571c4906-d610-4452-8755-3ec0a655e811_0">
											<gml:posList>35.6686079498823 139.7432637339245 59.394 35.668628179377 139.7432673122026 59.394 35.668628179377 139.7432673122026 60.121 35.6686079498823 139.7432637339245 60.121 35.6686079498823 139.7432637339245 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-100ddf17-617f-4395-8451-5dcea390f51e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-100ddf17-617f-4395-8451-5dcea390f51e_0">
											<gml:posList>35.66865088905051 139.74326071431094 59.394 35.668649670743605 139.74327082278901 59.394 35.668649670743605 139.74327082278901 60.249 35.66865088905051 139.74326071431094 60.249 35.66865088905051 139.74326071431094 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e6a70a3-bb8c-4140-8996-3c4ba9b85406">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e6a70a3-bb8c-4140-8996-3c4ba9b85406_0">
											<gml:posList>35.66836196378928 139.74327405103716 59.394 35.66836196378928 139.74327405103716 62.698 35.66836291204831 139.74326442892198 62.698 35.66836291204831 139.74326442892198 59.394 35.66836196378928 139.74327405103716 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33d3159f-9d59-4e94-8fa8-b4f6dfb606e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33d3159f-9d59-4e94-8fa8-b4f6dfb606e5_0">
											<gml:posList>35.66869266305175 139.74327859508657 60.249 35.66869388135929 139.7432684866032 60.249 35.66865088905051 139.74326071431094 60.249 35.668649670743605 139.74327082278901 60.249 35.66869266305175 139.74327859508657 60.249</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2957004e-7211-45f3-bc76-78c22192f020">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2957004e-7211-45f3-bc76-78c22192f020_0">
											<gml:posList>35.66837790183375 139.74327640802267 62.698 35.66837885009297 139.74326678590558 62.698 35.66836291204831 139.74326442892198 62.698 35.66836196378928 139.74327405103716 62.698 35.66837790183375 139.74327640802267 62.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29d249db-86cb-4ea3-af08-753399ca7ae1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29d249db-86cb-4ea3-af08-753399ca7ae1_0">
											<gml:posList>35.66837885009297 139.74326678590558 59.394 35.66837885009297 139.74326678590558 62.698 35.66837790183375 139.74327640802267 62.698 35.66837790183375 139.74327640802267 59.394 35.66837885009297 139.74326678590558 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99b36273-78a3-4ffc-84ac-9f1899824633">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99b36273-78a3-4ffc-84ac-9f1899824633_0">
											<gml:posList>35.668626399583204 139.74327389762857 59.394 35.66860660324324 139.74327098162325 59.394 35.66860660324324 139.74327098162325 60.121 35.668626399583204 139.74327389762857 60.121 35.668626399583204 139.74327389762857 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51811b16-5ad0-4722-b6f5-7b6e1c147e81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-51811b16-5ad0-4722-b6f5-7b6e1c147e81_0">
											<gml:posList>35.66869266305175 139.74327859508657 59.394 35.66869388135929 139.7432684866032 59.394 35.66869388135929 139.7432684866032 60.249 35.66869266305175 139.74327859508657 60.249 35.66869266305175 139.74327859508657 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-facb5b21-ecfe-47f8-8704-276b14af9593">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-facb5b21-ecfe-47f8-8704-276b14af9593_0">
											<gml:posList>35.668649670743605 139.74327082278901 59.394 35.66869266305175 139.74327859508657 59.394 35.66869266305175 139.74327859508657 60.249 35.668649670743605 139.74327082278901 60.249 35.668649670743605 139.74327082278901 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99b1c182-0e1c-45cc-ac94-eef48a6327a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99b1c182-0e1c-45cc-ac94-eef48a6327a7_0">
											<gml:posList>35.66836196378928 139.74327405103716 59.394 35.66837790183375 139.74327640802267 59.394 35.66837790183375 139.74327640802267 62.698 35.66836196378928 139.74327405103716 62.698 35.66836196378928 139.74327405103716 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc4157dc-7eab-47d1-ac70-29fc5493bd41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc4157dc-7eab-47d1-ac70-29fc5493bd41_0">
											<gml:posList>35.66860660324324 139.74327098162325 59.394 35.66860559240811 139.74328129973688 59.394 35.66860559240811 139.74328129973688 60.121 35.66860660324324 139.74327098162325 60.121 35.66860660324324 139.74327098162325 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d70e9407-50db-4283-90b1-c06a4f827d87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d70e9407-50db-4283-90b1-c06a4f827d87_0">
											<gml:posList>35.66860559240811 139.74328129973688 60.121 35.66862538874783 139.74328421574467 60.121 35.668626399583204 139.74327389762857 60.121 35.66860660324324 139.74327098162325 60.121 35.66860559240811 139.74328129973688 60.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8708ba7d-b66f-46ce-a78e-dfd6025d2e6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8708ba7d-b66f-46ce-a78e-dfd6025d2e6b_0">
											<gml:posList>35.66862538874783 139.74328421574467 59.394 35.668626399583204 139.74327389762857 59.394 35.668626399583204 139.74327389762857 60.121 35.66862538874783 139.74328421574467 60.121 35.66862538874783 139.74328421574467 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f410874-2f7c-48a4-8771-18adee5b747f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f410874-2f7c-48a4-8771-18adee5b747f_0">
											<gml:posList>35.66867248456581 139.74328295883709 59.394 35.66865135427738 139.74328015478625 59.394 35.66865135427738 139.74328015478625 59.997 35.66867248456581 139.74328295883709 59.997 35.66867248456581 139.74328295883709 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b704b83-430a-4442-bb72-62bf90aaff15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b704b83-430a-4442-bb72-62bf90aaff15_0">
											<gml:posList>35.66860559240811 139.74328129973688 59.394 35.66862538874783 139.74328421574467 59.394 35.66862538874783 139.74328421574467 60.121 35.66860559240811 139.74328129973688 60.121 35.66860559240811 139.74328129973688 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4b2c674-25f5-48c3-af3e-3b5d6ce867b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4b2c674-25f5-48c3-af3e-3b5d6ce867b4_0">
											<gml:posList>35.66865135427738 139.74328015478625 59.394 35.6686504515401 139.74329038441596 59.394 35.6686504515401 139.74329038441596 59.997 35.66865135427738 139.74328015478625 59.997 35.66865135427738 139.74328015478625 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10dd0d90-a51b-4f11-a29f-3198ff307e4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10dd0d90-a51b-4f11-a29f-3198ff307e4f_0">
											<gml:posList>35.66867158182832 139.7432931884694 59.997 35.66867248456581 139.74328295883709 59.997 35.66865135427738 139.74328015478625 59.997 35.6686504515401 139.74329038441596 59.997 35.66867158182832 139.7432931884694 59.997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f81958a0-4233-40c0-963a-f959cbe45a74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f81958a0-4233-40c0-963a-f959cbe45a74_0">
											<gml:posList>35.66867158182832 139.7432931884694 59.394 35.66867248456581 139.74328295883709 59.394 35.66867248456581 139.74328295883709 59.997 35.66867158182832 139.7432931884694 59.997 35.66867158182832 139.7432931884694 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f41c0543-ab48-4178-8760-99c29a4614fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f41c0543-ab48-4178-8760-99c29a4614fc_0">
											<gml:posList>35.6686504515401 139.74329038441596 59.394 35.66867158182832 139.7432931884694 59.394 35.66867158182832 139.7432931884694 59.997 35.6686504515401 139.74329038441596 59.997 35.6686504515401 139.74329038441596 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbbb7915-3430-46c1-8254-10d4bbc50244">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbbb7915-3430-46c1-8254-10d4bbc50244_0">
											<gml:posList>35.6683968009792 139.74329696546914 59.394 35.66837860001906 139.743293981399 59.394 35.66837860001906 139.743293981399 61.651 35.6683968009792 139.74329696546914 61.651 35.6683968009792 139.74329696546914 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c70748d-9870-44b1-ad2b-4b91abb9f8e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c70748d-9870-44b1-ad2b-4b91abb9f8e1_0">
											<gml:posList>35.66837860001906 139.743293981399 59.394 35.66837622769204 139.74331579988063 59.394 35.66837622769204 139.74331579988063 61.651 35.66837860001906 139.743293981399 61.651 35.66837860001906 139.743293981399 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cd3fc17-a75a-4fbe-b9d7-8c6ecc12b393">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cd3fc17-a75a-4fbe-b9d7-8c6ecc12b393_0">
											<gml:posList>35.66837622769204 139.74331579988063 61.651 35.66839441962967 139.7433187729198 61.651 35.6683968009792 139.74329696546914 61.651 35.66837860001906 139.743293981399 61.651 35.66837622769204 139.74331579988063 61.651</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-993b775f-d8a4-4da8-883e-a3ec0fa67286">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-993b775f-d8a4-4da8-883e-a3ec0fa67286_0">
											<gml:posList>35.66839441962967 139.7433187729198 59.394 35.6683968009792 139.74329696546914 59.394 35.6683968009792 139.74329696546914 61.651 35.66839441962967 139.7433187729198 61.651 35.66839441962967 139.7433187729198 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61269b78-d11d-4968-8150-ea83ca0f66d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61269b78-d11d-4968-8150-ea83ca0f66d1_0">
											<gml:posList>35.66837622769204 139.74331579988063 59.394 35.66839441962967 139.7433187729198 59.394 35.66839441962967 139.7433187729198 61.651 35.66837622769204 139.74331579988063 61.651 35.66837622769204 139.74331579988063 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_30b37cad-48c1-407c-8dbd-8fd49c0ac052_BuildingInstallation_1033">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a5bfd3b-6890-4b9d-8736-60645450e79a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66828466102168 139.74287589746783 26.1 35.66829159099242 139.7428737798693 26.1 35.668298236564965 139.74287704198005 26.1 35.668298744154804 139.74288079703823 26.1 35.66828233649259 139.74287724769863 26.1 35.66828466102168 139.74287589746783 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-413418e6-a563-4075-8809-5a651db34938">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668299161101146 139.74288387839437 23.354 35.66829663483987 139.7428926627923 23.354 35.66828999246547 139.7429056603471 23.354 35.668281632845186 139.74291248513856 23.354 35.668270313694904 139.742915281487 23.354 35.66826513712024 139.7429116973846 23.354 35.66826367979694 139.7429035581495 23.354 35.668268204044985 139.74289069553953 23.354 35.668277642374 139.74287995925675 23.354 35.66828233649259 139.74287724769863 23.354 35.668298744154804 139.74288079703823 23.354 35.668299161101146 139.74288387839437 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18c6df2d-04c2-4ffb-8706-9ff92ce5cd61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668862713362515 139.74303415382656 23.354 35.66886245804421 139.7430422619152 23.354 35.66885645477593 139.74305412108677 23.354 35.668844193836186 139.74306312637484 23.354 35.668830919003085 139.7430663225812 23.354 35.66882675138269 139.74306195303888 23.354 35.66882581924246 139.74305698336784 23.354 35.66882699532002 139.7430506857976 23.354 35.668832865361715 139.74304146678531 23.354 35.668837557826876 139.74303654601022 23.354 35.668844170049724 139.74303140215153 23.354 35.66885118028455 139.74302813567206 23.354 35.668859770828966 139.74302874457572 23.354 35.668862713362515 139.74303415382656 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4a5f032-0761-44cc-a589-dc02a8beceae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4a5f032-0761-44cc-a589-dc02a8beceae_0">
											<gml:posList>35.66829159099242 139.7428737798693 26.1 35.66828466102168 139.74287589746783 26.1 35.66828466102168 139.74287589746783 28.4 35.66829159099242 139.7428737798693 28.4 35.66829159099242 139.7428737798693 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae9c6867-2210-4e0a-b91b-f3e82d36b875">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae9c6867-2210-4e0a-b91b-f3e82d36b875_0">
											<gml:posList>35.668298236564965 139.74287704198005 26.1 35.66829159099242 139.7428737798693 26.1 35.66829159099242 139.7428737798693 28.4 35.668298236564965 139.74287704198005 28.4 35.668298236564965 139.74287704198005 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f41e7bc5-97f0-4594-96f3-ffc293869670">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f41e7bc5-97f0-4594-96f3-ffc293869670_0">
											<gml:posList>35.66828233649259 139.74287724769863 26.1 35.66828233649259 139.74287724769863 23.354 35.668277642374 139.74287995925675 23.354 35.668277642374 139.74287995925675 28.4 35.66828466102168 139.74287589746783 28.4 35.66828466102168 139.74287589746783 26.1 35.66828233649259 139.74287724769863 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4b6a040-1d47-479c-8f8b-f19a461eaaee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4b6a040-1d47-479c-8f8b-f19a461eaaee_0">
											<gml:posList>35.66828233649259 139.74287724769863 26.1 35.668298744154804 139.74288079703823 26.1 35.668298744154804 139.74288079703823 23.354 35.66828233649259 139.74287724769863 23.354 35.66828233649259 139.74287724769863 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9da4d717-6813-4074-bb57-21947be47823">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9da4d717-6813-4074-bb57-21947be47823_0">
											<gml:posList>35.668298236564965 139.74287704198005 28.4 35.668299161101146 139.74288387839437 28.4 35.668299161101146 139.74288387839437 23.354 35.668298744154804 139.74288079703823 23.354 35.668298744154804 139.74288079703823 26.1 35.668298236564965 139.74287704198005 26.1 35.668298236564965 139.74287704198005 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcd2c568-aec1-4af1-9c19-5a69fedb76f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcd2c568-aec1-4af1-9c19-5a69fedb76f5_0">
											<gml:posList>35.668277642374 139.74287995925675 23.354 35.668268204044985 139.74289069553953 23.354 35.668268204044985 139.74289069553953 28.4 35.668277642374 139.74287995925675 28.4 35.668277642374 139.74287995925675 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72eebd5a-56a6-42ab-8263-a8ac45d0f7c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72eebd5a-56a6-42ab-8263-a8ac45d0f7c6_0">
											<gml:posList>35.66829663483987 139.7428926627923 23.354 35.668299161101146 139.74288387839437 23.354 35.668299161101146 139.74288387839437 28.4 35.66829663483987 139.7428926627923 28.4 35.66829663483987 139.7428926627923 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b532c3d-a2f7-4ed6-a301-18d6b37e9baa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b532c3d-a2f7-4ed6-a301-18d6b37e9baa_0">
											<gml:posList>35.66829159099242 139.7428737798693 28.4 35.66828466102168 139.74287589746783 28.4 35.668277642374 139.74287995925675 28.4 35.668268204044985 139.74289069553953 28.4 35.66826367979694 139.7429035581495 28.4 35.66826513712024 139.7429116973846 28.4 35.668270313694904 139.742915281487 28.4 35.668281632845186 139.74291248513856 28.4 35.66828999246547 139.7429056603471 28.4 35.66829663483987 139.7428926627923 28.4 35.668299161101146 139.74288387839437 28.4 35.668298236564965 139.74287704198005 28.4 35.66829159099242 139.7428737798693 28.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-062285bc-3b06-48a6-a68d-3d1233bd05ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-062285bc-3b06-48a6-a68d-3d1233bd05ef_0">
											<gml:posList>35.668268204044985 139.74289069553953 23.354 35.66826367979694 139.7429035581495 23.354 35.66826367979694 139.7429035581495 28.4 35.668268204044985 139.74289069553953 28.4 35.668268204044985 139.74289069553953 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccd39fb7-29cc-429a-b7bc-5bee348a9e12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccd39fb7-29cc-429a-b7bc-5bee348a9e12_0">
											<gml:posList>35.66828999246547 139.7429056603471 23.354 35.66829663483987 139.7428926627923 23.354 35.66829663483987 139.7428926627923 28.4 35.66828999246547 139.7429056603471 28.4 35.66828999246547 139.7429056603471 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a063ba0-c6a5-4b12-8575-a34c5f2de8e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a063ba0-c6a5-4b12-8575-a34c5f2de8e2_0">
											<gml:posList>35.66826367979694 139.7429035581495 23.354 35.66826513712024 139.7429116973846 23.354 35.66826513712024 139.7429116973846 28.4 35.66826367979694 139.7429035581495 28.4 35.66826367979694 139.7429035581495 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7219ce6-aaf4-46c6-b683-16070d0c5bd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7219ce6-aaf4-46c6-b683-16070d0c5bd6_0">
											<gml:posList>35.668281632845186 139.74291248513856 23.354 35.66828999246547 139.7429056603471 23.354 35.66828999246547 139.7429056603471 28.4 35.668281632845186 139.74291248513856 28.4 35.668281632845186 139.74291248513856 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0def4620-ef83-4185-bd10-12741c783022">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0def4620-ef83-4185-bd10-12741c783022_0">
											<gml:posList>35.66826513712024 139.7429116973846 23.354 35.668270313694904 139.742915281487 23.354 35.668270313694904 139.742915281487 28.4 35.66826513712024 139.7429116973846 28.4 35.66826513712024 139.7429116973846 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82a4eb33-4f36-4176-902d-fd1ebe686fa2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82a4eb33-4f36-4176-902d-fd1ebe686fa2_0">
											<gml:posList>35.668281632845186 139.74291248513856 23.354 35.668281632845186 139.74291248513856 28.4 35.668270313694904 139.742915281487 28.4 35.668270313694904 139.742915281487 23.354 35.668281632845186 139.74291248513856 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b45bee7d-363e-4cba-8f7f-4c4267f214d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b45bee7d-363e-4cba-8f7f-4c4267f214d6_0">
											<gml:posList>35.66885118028455 139.74302813567206 23.354 35.66885118028455 139.74302813567206 27.6 35.668859770828966 139.74302874457572 27.6 35.668859770828966 139.74302874457572 23.354 35.66885118028455 139.74302813567206 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d13aceb4-536a-4c7a-ab52-992627a3aaa3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d13aceb4-536a-4c7a-ab52-992627a3aaa3_0">
											<gml:posList>35.66885118028455 139.74302813567206 23.354 35.668844170049724 139.74303140215153 23.354 35.668844170049724 139.74303140215153 27.6 35.66885118028455 139.74302813567206 27.6 35.66885118028455 139.74302813567206 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c02b3578-2c4a-4ad5-b20e-dc0213ac31aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c02b3578-2c4a-4ad5-b20e-dc0213ac31aa_0">
											<gml:posList>35.668859770828966 139.74302874457572 27.6 35.668862713362515 139.74303415382656 27.6 35.668862713362515 139.74303415382656 23.354 35.668859770828966 139.74302874457572 23.354 35.668859770828966 139.74302874457572 27.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acb014f3-aff1-4449-89bd-02b2b768dac1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acb014f3-aff1-4449-89bd-02b2b768dac1_0">
											<gml:posList>35.668844170049724 139.74303140215153 23.354 35.668837557826876 139.74303654601022 23.354 35.668837557826876 139.74303654601022 27.6 35.668844170049724 139.74303140215153 27.6 35.668844170049724 139.74303140215153 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67974792-0a00-413c-b344-a429f360862f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67974792-0a00-413c-b344-a429f360862f_0">
											<gml:posList>35.668862713362515 139.74303415382656 23.354 35.668862713362515 139.74303415382656 27.6 35.66886245804421 139.7430422619152 27.6 35.66886245804421 139.7430422619152 23.354 35.668862713362515 139.74303415382656 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e671a4fc-e991-4393-8c0a-62145aec43dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e671a4fc-e991-4393-8c0a-62145aec43dc_0">
											<gml:posList>35.668837557826876 139.74303654601022 23.354 35.668832865361715 139.74304146678531 23.354 35.668832865361715 139.74304146678531 27.6 35.668837557826876 139.74303654601022 27.6 35.668837557826876 139.74303654601022 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37e1f7cd-cb99-4fea-895a-732b650b927e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37e1f7cd-cb99-4fea-895a-732b650b927e_0">
											<gml:posList>35.668832865361715 139.74304146678531 23.354 35.66882699532002 139.7430506857976 23.354 35.66882699532002 139.7430506857976 27.6 35.668832865361715 139.74304146678531 27.6 35.668832865361715 139.74304146678531 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74db8933-1516-4196-932b-c7e874663828">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74db8933-1516-4196-932b-c7e874663828_0">
											<gml:posList>35.66885118028455 139.74302813567206 27.6 35.668844170049724 139.74303140215153 27.6 35.668837557826876 139.74303654601022 27.6 35.668832865361715 139.74304146678531 27.6 35.66882699532002 139.7430506857976 27.6 35.66882581924246 139.74305698336784 27.6 35.66882675138269 139.74306195303888 27.6 35.668830919003085 139.7430663225812 27.6 35.668844193836186 139.74306312637484 27.6 35.66885645477593 139.74305412108677 27.6 35.66886245804421 139.7430422619152 27.6 35.668862713362515 139.74303415382656 27.6 35.668859770828966 139.74302874457572 27.6 35.66885118028455 139.74302813567206 27.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7777287d-6a0b-4574-94e5-a65db75dd130">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7777287d-6a0b-4574-94e5-a65db75dd130_0">
											<gml:posList>35.66886245804421 139.7430422619152 23.354 35.66886245804421 139.7430422619152 27.6 35.66885645477593 139.74305412108677 27.6 35.66885645477593 139.74305412108677 23.354 35.66886245804421 139.7430422619152 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-979ed4f8-faf8-4fea-8847-588855327b38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-979ed4f8-faf8-4fea-8847-588855327b38_0">
											<gml:posList>35.66882699532002 139.7430506857976 23.354 35.66882581924246 139.74305698336784 23.354 35.66882581924246 139.74305698336784 27.6 35.66882699532002 139.7430506857976 27.6 35.66882699532002 139.7430506857976 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb7228d0-f83d-43fc-b84e-9bd40aa97ec1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb7228d0-f83d-43fc-b84e-9bd40aa97ec1_0">
											<gml:posList>35.66885645477593 139.74305412108677 23.354 35.66885645477593 139.74305412108677 27.6 35.668844193836186 139.74306312637484 27.6 35.668844193836186 139.74306312637484 23.354 35.66885645477593 139.74305412108677 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b042d005-ab87-444b-9032-059625057b3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b042d005-ab87-444b-9032-059625057b3b_0">
											<gml:posList>35.66882675138269 139.74306195303888 23.354 35.66882675138269 139.74306195303888 27.6 35.66882581924246 139.74305698336784 27.6 35.66882581924246 139.74305698336784 23.354 35.66882675138269 139.74306195303888 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6480e63-c7ec-4abc-aebc-9709fb6054ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6480e63-c7ec-4abc-aebc-9709fb6054ce_0">
											<gml:posList>35.66882675138269 139.74306195303888 23.354 35.668830919003085 139.7430663225812 23.354 35.668830919003085 139.7430663225812 27.6 35.66882675138269 139.74306195303888 27.6 35.66882675138269 139.74306195303888 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d6393cf-0bb2-4f40-b305-9e69b2945c78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d6393cf-0bb2-4f40-b305-9e69b2945c78_0">
											<gml:posList>35.668830919003085 139.7430663225812 23.354 35.668844193836186 139.74306312637484 23.354 35.668844193836186 139.74306312637484 27.6 35.668830919003085 139.7430663225812 27.6 35.668830919003085 139.7430663225812 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7a0682bd-6aeb-42c0-a4be-7357f6b1301f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a0682bd-6aeb-42c0-a4be-7357f6b1301f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a0682bd-6aeb-42c0-a4be-7357f6b1301f">
											<gml:posList>35.66905116440625 139.7430353886323 10.02 35.66898857327212 139.74346945913223 10.02 35.66881858433916 139.74327783508272 10.02 35.668838999979855 139.74313270022859 10.02 35.66905116440625 139.7430353886323 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-c87f3089-1cd8-4d87-91ee-2bdcb321376f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c87f3089-1cd8-4d87-91ee-2bdcb321376f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c87f3089-1cd8-4d87-91ee-2bdcb321376f">
											<gml:posList>35.668404704711364 139.7430424128569 10.02 35.6682342273095 139.74300549038384 10.02 35.6682547617707 139.74286297427884 10.02 35.66905116440625 139.7430353886323 10.02 35.668838999979855 139.74313270022859 10.02 35.668730277565416 139.7431102886291 10.02 35.668709933656004 139.74325488195603 10.02 35.66881858433916 139.74327783508272 10.02 35.66898857327212 139.74346945913223 10.02 35.668191630337475 139.74329693074705 10.02 35.66821276565542 139.74314986318032 10.02 35.66838399960477 139.7431860339731 10.02 35.668404704711364 139.7430424128569 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee6c9a9b-3e44-4427-ab04-ec1a4a3193d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee6c9a9b-3e44-4427-ab04-ec1a4a3193d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee6c9a9b-3e44-4427-ab04-ec1a4a3193d4">
											<gml:posList>35.668191630337475 139.74329693074705 62.3 35.66819794491278 139.74329151113665 62.3 35.66821712543168 139.7431580654264 62.3 35.66821275671614 139.74314996260404 62.3 35.668191630337475 139.74329693074705 62.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-318e9107-f047-492f-b0df-fde5e6296390">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-318e9107-f047-492f-b0df-fde5e6296390">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-318e9107-f047-492f-b0df-fde5e6296390">
											<gml:posList>35.6682342273095 139.74300549038384 26.1 35.66824195613172 139.74299887619011 26.1 35.668260168113015 139.74287244561913 26.1 35.6682547617707 139.74286297427884 26.1 35.6682342273095 139.74300549038384 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdec4fab-5af9-4e58-a8c6-884f6cdc233e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdec4fab-5af9-4e58-a8c6-884f6cdc233e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdec4fab-5af9-4e58-a8c6-884f6cdc233e">
											<gml:posList>35.668383981651736 139.74318613340716 62.3 35.66821275671614 139.74314996260404 62.3 35.66821712543168 139.7431580654264 62.3 35.66838289682876 139.74319393309187 62.3 35.668383981651736 139.74318613340716 62.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bbc29389-6b88-4b9f-b6d2-c90730298818">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbc29389-6b88-4b9f-b6d2-c90730298818">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbc29389-6b88-4b9f-b6d2-c90730298818">
											<gml:posList>35.668404704711364 139.7430424128569 26.1 35.66841243353539 139.7430357986526 26.1 35.66824195613172 139.74299887619011 26.1 35.6682342273095 139.74300549038384 26.1 35.668404704711364 139.7430424128569 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-985152fc-ff32-4fc0-a65f-34d737db6aad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-985152fc-ff32-4fc0-a65f-34d737db6aad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-985152fc-ff32-4fc0-a65f-34d737db6aad">
											<gml:posList>35.668404704711364 139.7430424128569 26.1 35.66838399061585 139.74318606712117 26.1 35.66839063478239 139.74318746249153 26.1 35.66841243353539 139.7430357986526 26.1 35.668404704711364 139.7430424128569 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35f406db-0128-40ce-8337-2b3570b546b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35f406db-0128-40ce-8337-2b3570b546b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35f406db-0128-40ce-8337-2b3570b546b4">
											<gml:posList>35.66870309824715 139.7434076451657 62.3 35.66869860361225 139.74339988484874 62.3 35.66819794491278 139.74329151113665 62.3 35.668191630337475 139.74329693074705 62.3 35.66870309824715 139.7434076451657 62.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3b8ece8-505e-49e3-bbc3-a48e985fc552">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3b8ece8-505e-49e3-bbc3-a48e985fc552">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3b8ece8-505e-49e3-bbc3-a48e985fc552">
											<gml:posList>35.66869860361225 139.74339988484874 59.394 35.668716762582584 139.74326227512478 59.394 35.66838289682876 139.74319393309187 59.394 35.66821712543168 139.7431580654264 59.394 35.66819794491278 139.74329151113665 59.394 35.66869860361225 139.74339988484874 59.394</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b9282ce7-bcce-4df4-b5ce-4ed9cd1965f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9282ce7-bcce-4df4-b5ce-4ed9cd1965f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9282ce7-bcce-4df4-b5ce-4ed9cd1965f3">
											<gml:posList>35.668383981651736 139.74318613340716 62.3 35.66838289682876 139.74319393309187 62.3 35.668716762582584 139.74326227512478 62.3 35.66872287047625 139.74325770625265 62.3 35.668383981651736 139.74318613340716 62.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55dadbe3-f9ce-4524-a4c3-45c879a06b8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55dadbe3-f9ce-4524-a4c3-45c879a06b8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55dadbe3-f9ce-4524-a4c3-45c879a06b8f">
											<gml:posList>35.66861818641388 139.74323553299044 26.1 35.668624776488976 139.7432369173837 26.1 35.66864426396574 139.74309218157146 26.1 35.66863875865555 139.7430829312028 26.1 35.66861818641388 139.74323553299044 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3c4c766-2842-48b4-83f5-eb4ef6e771a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3c4c766-2842-48b4-83f5-eb4ef6e771a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3c4c766-2842-48b4-83f5-eb4ef6e771a3">
											<gml:posList>35.66904343559972 139.74304202498158 23.354 35.668260168113015 139.74287244561913 23.354 35.66824195613172 139.74299887619011 23.354 35.66841243353539 139.7430357986526 23.354 35.66839063478239 139.74318746249153 23.354 35.66861818640562 139.74323552194443 23.354 35.66863875865555 139.7430829312028 23.354 35.66902606616887 139.74316235836983 23.354 35.66904343559972 139.74304202498158 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3de06d60-7da4-48ed-a919-4cfc5badc004">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3de06d60-7da4-48ed-a919-4cfc5badc004">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3de06d60-7da4-48ed-a919-4cfc5badc004">
											<gml:posList>35.6682547617707 139.74286297427884 26.1 35.668260168113015 139.74287244561913 26.1 35.66904343559972 139.74304202498158 26.1 35.66905116440625 139.7430353886323 26.1 35.6682547617707 139.74286297427884 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c559b22e-8ecf-45a2-8d62-3dc3de4e88c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c559b22e-8ecf-45a2-8d62-3dc3de4e88c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c559b22e-8ecf-45a2-8d62-3dc3de4e88c5">
											<gml:posList>35.66870993366427 139.74325489300205 18.1 35.668730304465896 139.7431101008163 18.1 35.66864424607901 139.74309236937395 18.1 35.66862477648071 139.7432369063377 18.1 35.66870993366427 139.74325489300205 18.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97e37d63-93c3-4e2a-8ae5-1159dce315bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97e37d63-93c3-4e2a-8ae5-1159dce315bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97e37d63-93c3-4e2a-8ae5-1159dce315bb">
											<gml:posList>35.66872287047625 139.74325770625265 62.3 35.668716762582584 139.74326227512478 62.3 35.66869860361225 139.74339988484874 62.3 35.66870309824715 139.7434076451657 62.3 35.66872287047625 139.74325770625265 62.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d81a5a6-298a-42d4-b546-ae82657ac605">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d81a5a6-298a-42d4-b546-ae82657ac605">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d81a5a6-298a-42d4-b546-ae82657ac605">
											<gml:posList>35.66864426396574 139.74309218157146 26.1 35.66903146358917 139.74317198447642 26.1 35.66902606616887 139.74316235836983 26.1 35.66863875865555 139.7430829312028 26.1 35.66864426396574 139.74309218157146 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6caad63d-3704-4dba-8651-4c9dbc2fd2aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6caad63d-3704-4dba-8651-4c9dbc2fd2aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6caad63d-3704-4dba-8651-4c9dbc2fd2aa">
											<gml:posList>35.66881858434742 139.74327784612876 17.728 35.66883392814559 139.74328108747932 17.728 35.66885413623447 139.7431356324963 17.728 35.66883901787491 139.7431325234717 17.728 35.66881858434742 139.74327784612876 17.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4388de2-8b02-4266-9c5d-1d4cd2f68b4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4388de2-8b02-4266-9c5d-1d4cd2f68b4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4388de2-8b02-4266-9c5d-1d4cd2f68b4f">
											<gml:posList>35.66870309824715 139.7434076451657 57.699 35.66898857327212 139.74346945913223 57.699 35.66898989144732 139.74346028941824 57.699 35.66898313005665 139.74345882786994 57.699 35.66870430826954 139.74339849769675 57.699 35.66870309824715 139.7434076451657 57.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ea7aaef-a819-4c40-af53-fbb19bbc85b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ea7aaef-a819-4c40-af53-fbb19bbc85b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ea7aaef-a819-4c40-af53-fbb19bbc85b9">
											<gml:posList>35.66872169635423 139.74326663276486 55.382 35.66870430826954 139.74339849769675 55.382 35.66898313005665 139.74345882786994 55.382 35.669002077828154 139.74332729212367 55.382 35.66872169635423 139.74326663276486 55.382</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc446328-5111-42ec-bb17-cda6af8b5969">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc446328-5111-42ec-bb17-cda6af8b5969">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc446328-5111-42ec-bb17-cda6af8b5969">
											<gml:posList>35.669002077828154 139.74332729212367 57.699 35.6690088482341 139.74332875365116 57.699 35.66901033679235 139.74331842390382 57.699 35.66872287047625 139.74325770625265 57.699 35.66872169635423 139.74326663276486 57.699 35.669002077828154 139.74332729212367 57.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c3e1fa8e-45d4-4412-b81e-7d75b8e7509c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c3e1fa8e-45d4-4412-b81e-7d75b8e7509c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c3e1fa8e-45d4-4412-b81e-7d75b8e7509c">
											<gml:posList>35.66900357536697 139.74331691818287 16.577 35.66902462127834 139.74317079919447 16.577 35.66885413625929 139.7431356656344 16.577 35.66883392814559 139.74328108747932 16.577 35.66900357536697 139.74331691818287 16.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd6e2198-f7f3-4cab-b430-18262960a151">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd6e2198-f7f3-4cab-b430-18262960a151">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd6e2198-f7f3-4cab-b430-18262960a151">
											<gml:posList>35.66898989144732 139.74346028941824 57.699 35.6690088482341 139.74332875365116 57.699 35.669002077828154 139.74332729212367 57.699 35.66898313005665 139.74345882786994 57.699 35.66898989144732 139.74346028941824 57.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dd7d81f1-fcfd-4090-ab80-81bd5c935445">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd7d81f1-fcfd-4090-ab80-81bd5c935445">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd7d81f1-fcfd-4090-ab80-81bd5c935445">
											<gml:posList>35.669010345756526 139.74331835761734 17.728 35.669031436696876 139.743172183336 17.728 35.66902463027552 139.7431707770922 17.728 35.66900357536697 139.74331691818287 17.728 35.669010345756526 139.74331835761734 17.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8534429d-84d3-4ee3-8c2e-e0eb6d7ecddd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8534429d-84d3-4ee3-8c2e-e0eb6d7ecddd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8534429d-84d3-4ee3-8c2e-e0eb6d7ecddd">
											<gml:posList>35.66905116440625 139.7430353886323 26.1 35.66904343559972 139.74304202498158 26.1 35.66902606616887 139.74316235836983 26.1 35.66903146358917 139.74317198447642 26.1 35.66905116440625 139.7430353886323 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b52d9382-46ad-4e59-b1ce-d3c3f01c78a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b52d9382-46ad-4e59-b1ce-d3c3f01c78a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b52d9382-46ad-4e59-b1ce-d3c3f01c78a0">
											<gml:posList>35.66841243353539 139.7430357986526 26.1 35.66841243353539 139.7430357986526 23.354 35.66824195613172 139.74299887619011 23.354 35.66824195613172 139.74299887619011 26.1 35.66841243353539 139.7430357986526 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ae120e8-044d-4836-9cd3-a3c347162ded">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ae120e8-044d-4836-9cd3-a3c347162ded">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ae120e8-044d-4836-9cd3-a3c347162ded">
											<gml:posList>35.66869860361225 139.74339988484874 62.3 35.66869860361225 139.74339988484874 59.394 35.66819794491278 139.74329151113665 59.394 35.66819794491278 139.74329151113665 62.3 35.66869860361225 139.74339988484874 62.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cd9c7110-bff6-42fa-af80-d6882712ee48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd9c7110-bff6-42fa-af80-d6882712ee48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd9c7110-bff6-42fa-af80-d6882712ee48">
											<gml:posList>35.66872169635423 139.74326663276486 57.699 35.66872169635423 139.74326663276486 55.382 35.669002077828154 139.74332729212367 55.382 35.669002077828154 139.74332729212367 57.699 35.66872169635423 139.74326663276486 57.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19d4203b-7ec4-4d4e-9acb-a80d32adefe6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19d4203b-7ec4-4d4e-9acb-a80d32adefe6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19d4203b-7ec4-4d4e-9acb-a80d32adefe6">
											<gml:posList>35.6682547617707 139.74286297427884 10.02 35.6682342273095 139.74300549038384 10.02 35.6682342273095 139.74300549038384 26.1 35.6682547617707 139.74286297427884 26.1 35.6682547617707 139.74286297427884 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0b29e3e-f0e9-49f8-83e2-f5e49f12f81d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0b29e3e-f0e9-49f8-83e2-f5e49f12f81d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0b29e3e-f0e9-49f8-83e2-f5e49f12f81d">
											<gml:posList>35.66824195613172 139.74299887619011 26.1 35.66824195613172 139.74299887619011 23.354 35.668260168113015 139.74287244561913 23.354 35.668260168113015 139.74287244561913 26.1 35.66824195613172 139.74299887619011 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22d2ac3c-3da1-4ec0-b484-55e7b77e0da2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22d2ac3c-3da1-4ec0-b484-55e7b77e0da2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22d2ac3c-3da1-4ec0-b484-55e7b77e0da2">
											<gml:posList>35.66905116440625 139.7430353886323 10.02 35.6682547617707 139.74286297427884 10.02 35.6682547617707 139.74286297427884 26.1 35.66905116440625 139.7430353886323 26.1 35.66905116440625 139.7430353886323 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-132623c8-3f4a-47b7-9eb7-52a23b79ae28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-132623c8-3f4a-47b7-9eb7-52a23b79ae28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-132623c8-3f4a-47b7-9eb7-52a23b79ae28">
											<gml:posList>35.668260168113015 139.74287244561913 26.1 35.668260168113015 139.74287244561913 23.354 35.66904343559972 139.74304202498158 23.354 35.66904343559972 139.74304202498158 26.1 35.668260168113015 139.74287244561913 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65a3ed31-d7b1-485e-9819-73cf931e54e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65a3ed31-d7b1-485e-9819-73cf931e54e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65a3ed31-d7b1-485e-9819-73cf931e54e4">
											<gml:posList>35.6682342273095 139.74300549038384 10.02 35.668404704711364 139.7430424128569 10.02 35.668404704711364 139.7430424128569 26.1 35.6682342273095 139.74300549038384 26.1 35.6682342273095 139.74300549038384 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e78fbd52-9905-43cf-9489-dbd7e9291ea7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e78fbd52-9905-43cf-9489-dbd7e9291ea7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e78fbd52-9905-43cf-9489-dbd7e9291ea7">
											<gml:posList>35.66904343559972 139.74304202498158 26.1 35.66904343559972 139.74304202498158 23.354 35.66902606616887 139.74316235836983 23.354 35.66902606616887 139.74316235836983 26.1 35.66904343559972 139.74304202498158 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4fcd824-26b0-458d-9096-1ad9e603eeaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4fcd824-26b0-458d-9096-1ad9e603eeaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4fcd824-26b0-458d-9096-1ad9e603eeaa">
											<gml:posList>35.66841243353539 139.7430357986526 23.354 35.66841243353539 139.7430357986526 26.1 35.66839063478239 139.74318746249153 26.1 35.66839063478239 139.74318746249153 23.354 35.66841243353539 139.7430357986526 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75709687-82f7-4b50-acfe-410597d65261">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75709687-82f7-4b50-acfe-410597d65261">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75709687-82f7-4b50-acfe-410597d65261">
											<gml:posList>35.668404704711364 139.7430424128569 10.02 35.66838399960477 139.7431860339731 10.02 35.66838399061585 139.74318606712117 26.1 35.668404704711364 139.7430424128569 26.1 35.668404704711364 139.7430424128569 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e652e20f-eece-4577-9239-4eff20375efd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e652e20f-eece-4577-9239-4eff20375efd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e652e20f-eece-4577-9239-4eff20375efd">
											<gml:posList>35.66902606616887 139.74316235836983 26.1 35.66902606616887 139.74316235836983 23.354 35.66863875865555 139.7430829312028 23.354 35.66863875865555 139.7430829312028 26.1 35.66902606616887 139.74316235836983 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6e4ad63-35e3-4d52-b4f8-9fa1de0ef906">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6e4ad63-35e3-4d52-b4f8-9fa1de0ef906">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6e4ad63-35e3-4d52-b4f8-9fa1de0ef906">
											<gml:posList>35.66902463027552 139.7431707770922 17.728 35.669031436696876 139.743172183336 17.728 35.66903146358917 139.74317198447642 26.1 35.66864426396574 139.74309218157146 26.1 35.66864424607901 139.74309236937395 18.1 35.668730304465896 139.7431101008163 18.1 35.668730277565416 139.7431102886291 10.02 35.668838999979855 139.74313270022859 10.02 35.66883901787491 139.7431325234717 17.728 35.66885413623447 139.7431356324963 17.728 35.66885413625929 139.7431356656344 16.577 35.66902462127834 139.74317079919447 16.577 35.66902463027552 139.7431707770922 17.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69f835f3-343f-4c29-ad62-1765319afe7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69f835f3-343f-4c29-ad62-1765319afe7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69f835f3-343f-4c29-ad62-1765319afe7e">
											<gml:posList>35.66861818640562 139.74323552194443 23.354 35.66861818641388 139.74323553299044 26.1 35.66863875865555 139.7430829312028 26.1 35.66863875865555 139.7430829312028 23.354 35.66861818640562 139.74323552194443 23.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fc1b9c4-eebc-421b-8c98-23fe852c887d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fc1b9c4-eebc-421b-8c98-23fe852c887d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fc1b9c4-eebc-421b-8c98-23fe852c887d">
											<gml:posList>35.66864426396574 139.74309218157146 26.1 35.668624776488976 139.7432369173837 26.1 35.66862477648071 139.7432369063377 18.1 35.66864424607901 139.74309236937395 18.1 35.66864426396574 139.74309218157146 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5f21659-8c9a-46b9-a855-1bf125043756">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5f21659-8c9a-46b9-a855-1bf125043756">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5f21659-8c9a-46b9-a855-1bf125043756">
											<gml:posList>35.66821712543168 139.7431580654264 62.3 35.66821712543168 139.7431580654264 59.394 35.66838289682876 139.74319393309187 59.394 35.66838289682876 139.74319393309187 62.3 35.66821712543168 139.7431580654264 62.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a598526-91ce-4b25-a931-2f8474b80725">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a598526-91ce-4b25-a931-2f8474b80725">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a598526-91ce-4b25-a931-2f8474b80725">
											<gml:posList>35.668730277565416 139.7431102886291 10.02 35.668730304465896 139.7431101008163 18.1 35.66870993366427 139.74325489300205 18.1 35.668709933656004 139.74325488195603 10.02 35.668730277565416 139.7431102886291 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7324419-b706-4361-a95b-c388201b3620">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7324419-b706-4361-a95b-c388201b3620">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7324419-b706-4361-a95b-c388201b3620">
											<gml:posList>35.66883901787491 139.7431325234717 17.728 35.668838999979855 139.74313270022859 10.02 35.66881858433916 139.74327783508272 10.02 35.66881858434742 139.74327784612876 17.728 35.66883901787491 139.7431325234717 17.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16b0cf2f-46b5-406e-b4fc-dcb52431b97c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16b0cf2f-46b5-406e-b4fc-dcb52431b97c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16b0cf2f-46b5-406e-b4fc-dcb52431b97c">
											<gml:posList>35.66883392814559 139.74328108747932 16.577 35.66885413625929 139.7431356656344 16.577 35.66885413623447 139.7431356324963 17.728 35.66883392814559 139.74328108747932 17.728 35.66883392814559 139.74328108747932 16.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78c74f53-0af0-4182-ac6c-21b02b6398b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78c74f53-0af0-4182-ac6c-21b02b6398b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78c74f53-0af0-4182-ac6c-21b02b6398b7">
											<gml:posList>35.66821276565542 139.74314986318032 10.02 35.668191630337475 139.74329693074705 10.02 35.668191630337475 139.74329693074705 62.3 35.66821275671614 139.74314996260404 62.3 35.66821276565542 139.74314986318032 10.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30108ddb-7a75-4963-ab03-702a3728be55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30108ddb-7a75-4963-ab03-702a3728be55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30108ddb-7a75-4963-ab03-702a3728be55">
											<gml:posList>35.66819794491278 139.74329151113665 62.3 35.66819794491278 139.74329151113665 59.394 35.66821712543168 139.7431580654264 59.394 35.66821712543168 139.7431580654264 62.3 35.66819794491278 139.74329151113665 62.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e27a0ff-7eec-44fd-b5de-7a55f8ae7263">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e27a0ff-7eec-44fd-b5de-7a55f8ae7263">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e27a0ff-7eec-44fd-b5de-7a55f8ae7263">
											<gml:posList>35.66838289682876 139.74319393309187 62.3 35.66838289682876 139.74319393309187 59.394 35.668716762582584 139.74326227512478 59.394 35.668716762582584 139.74326227512478 62.3 35.66838289682876 139.74319393309187 62.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6deec83e-96fe-4e1b-b6be-e9f8001c2207">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6deec83e-96fe-4e1b-b6be-e9f8001c2207">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6deec83e-96fe-4e1b-b6be-e9f8001c2207">
											<gml:posList>35.66872287047625 139.74325770625265 57.699 35.66901033679235 139.74331842390382 57.699 35.669010345756526 139.74331835761734 17.728 35.66900357536697 139.74331691818287 17.728 35.66900357536697 139.74331691818287 16.577 35.66883392814559 139.74328108747932 16.577 35.66883392814559 139.74328108747932 17.728 35.66881858434742 139.74327784612876 17.728 35.66881858433916 139.74327783508272 10.02 35.668709933656004 139.74325488195603 10.02 35.66870993366427 139.74325489300205 18.1 35.66862477648071 139.7432369063377 18.1 35.668624776488976 139.7432369173837 26.1 35.66861818641388 139.74323553299044 26.1 35.66861818640562 139.74323552194443 23.354 35.66839063478239 139.74318746249153 23.354 35.66839063478239 139.74318746249153 26.1 35.66838399061585 139.74318606712117 26.1 35.66838399960477 139.7431860339731 10.02 35.66821276565542 139.74314986318032 10.02 35.66821275671614 139.74314996260404 62.3 35.668383981651736 139.74318613340716 62.3 35.66872287047625 139.74325770625265 62.3 35.66872287047625 139.74325770625265 57.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b69d9b01-4c51-4efc-9100-72bb1e7cf75b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b69d9b01-4c51-4efc-9100-72bb1e7cf75b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b69d9b01-4c51-4efc-9100-72bb1e7cf75b">
											<gml:posList>35.66902462127834 139.74317079919447 16.577 35.66900357536697 139.74331691818287 16.577 35.66900357536697 139.74331691818287 17.728 35.66902463027552 139.7431707770922 17.728 35.66902462127834 139.74317079919447 16.577</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e93d6830-3f6a-4279-a24c-fafbb5fcb5fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e93d6830-3f6a-4279-a24c-fafbb5fcb5fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e93d6830-3f6a-4279-a24c-fafbb5fcb5fd">
											<gml:posList>35.669031436696876 139.743172183336 17.728 35.669010345756526 139.74331835761734 17.728 35.66898857327212 139.74346945913223 10.02 35.66905116440625 139.7430353886323 10.02 35.66905116440625 139.7430353886323 26.1 35.66903146358917 139.74317198447642 26.1 35.669031436696876 139.743172183336 17.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa4a8ddd-a679-4a53-b031-0d30c4791e18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa4a8ddd-a679-4a53-b031-0d30c4791e18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa4a8ddd-a679-4a53-b031-0d30c4791e18">
											<gml:posList>35.668716762582584 139.74326227512478 62.3 35.668716762582584 139.74326227512478 59.394 35.66869860361225 139.74339988484874 59.394 35.66869860361225 139.74339988484874 62.3 35.668716762582584 139.74326227512478 62.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a51cb135-0fb1-48ee-b2d8-ac0b12cefb29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a51cb135-0fb1-48ee-b2d8-ac0b12cefb29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a51cb135-0fb1-48ee-b2d8-ac0b12cefb29">
											<gml:posList>35.66870430826954 139.74339849769675 57.699 35.66870430826954 139.74339849769675 55.382 35.66872169635423 139.74326663276486 55.382 35.66872169635423 139.74326663276486 57.699 35.66872287047625 139.74325770625265 57.699 35.66872287047625 139.74325770625265 62.3 35.66870309824715 139.7434076451657 62.3 35.66870309824715 139.7434076451657 57.699 35.66870430826954 139.74339849769675 57.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-150f49a5-7681-483a-8e5d-6ef54c2e4bb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-150f49a5-7681-483a-8e5d-6ef54c2e4bb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-150f49a5-7681-483a-8e5d-6ef54c2e4bb5">
											<gml:posList>35.66870309824715 139.7434076451657 57.699 35.66870309824715 139.7434076451657 62.3 35.668191630337475 139.74329693074705 62.3 35.668191630337475 139.74329693074705 10.02 35.66898857327212 139.74346945913223 10.02 35.66898857327212 139.74346945913223 57.699 35.66870309824715 139.7434076451657 57.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34275d73-fb7c-4e0e-a3d5-d14c8e55f603">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34275d73-fb7c-4e0e-a3d5-d14c8e55f603">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34275d73-fb7c-4e0e-a3d5-d14c8e55f603">
											<gml:posList>35.669002077828154 139.74332729212367 57.699 35.669002077828154 139.74332729212367 55.382 35.66898313005665 139.74345882786994 55.382 35.66898313005665 139.74345882786994 57.699 35.669002077828154 139.74332729212367 57.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94efcdf5-c8e6-40f6-a1b8-d64eee923137">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94efcdf5-c8e6-40f6-a1b8-d64eee923137">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94efcdf5-c8e6-40f6-a1b8-d64eee923137">
											<gml:posList>35.669010345756526 139.74331835761734 17.728 35.66901033679235 139.74331842390382 57.699 35.6690088482341 139.74332875365116 57.699 35.66898989144732 139.74346028941824 57.699 35.66898857327212 139.74346945913223 57.699 35.66898857327212 139.74346945913223 10.02 35.669010345756526 139.74331835761734 17.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2fb375c-8daf-4a14-b5c6-b509ad11bf8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2fb375c-8daf-4a14-b5c6-b509ad11bf8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2fb375c-8daf-4a14-b5c6-b509ad11bf8b">
											<gml:posList>35.66898313005665 139.74345882786994 57.699 35.66898313005665 139.74345882786994 55.382 35.66870430826954 139.74339849769675 55.382 35.66870430826954 139.74339849769675 57.699 35.66898313005665 139.74345882786994 57.699</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10971</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">3037.69039</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1110</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">2</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>