<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_30e2dee6-71ad-40a8-aed9-f1664c355284">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門一・二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">13.9</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668141293513145 139.7475635743991 0 35.66812990201038 139.74754087611066 0 35.668103352789345 139.74756088663392 0 35.668108236147425 139.7475706128897 0 35.66809158770684 139.74758316784374 0 35.66812485047947 139.7476494190146 0 35.66819658836253 139.7475953497071 0 35.66816983369014 139.74754204844115 0 35.668141293513145 139.7475635743991 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668141293513145 139.7475635743991 5.422 35.66816983369014 139.74754204844115 5.422 35.66819658836253 139.7475953497071 5.422 35.66812485047947 139.7476494190146 5.422 35.66809158770684 139.74758316784374 5.422 35.668108236147425 139.7475706128897 5.422 35.668103352789345 139.74756088663392 5.422 35.66812990201038 139.74754087611066 5.422 35.668141293513145 139.7475635743991 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668141293513145 139.7475635743991 5.422 35.66812990201038 139.74754087611066 5.422 35.66812990201038 139.74754087611066 19.28 35.668141293513145 139.7475635743991 19.28 35.668141293513145 139.7475635743991 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66812990201038 139.74754087611066 5.422 35.668103352789345 139.74756088663392 5.422 35.668103352789345 139.74756088663392 19.28 35.66812990201038 139.74754087611066 19.28 35.66812990201038 139.74754087611066 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668103352789345 139.74756088663392 5.422 35.668108236147425 139.7475706128897 5.422 35.668108236147425 139.7475706128897 19.28 35.668103352789345 139.74756088663392 19.28 35.668103352789345 139.74756088663392 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668108236147425 139.7475706128897 5.422 35.66809158770684 139.74758316784374 5.422 35.66809158770684 139.74758316784374 19.28 35.668108236147425 139.7475706128897 19.28 35.668108236147425 139.7475706128897 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66809158770684 139.74758316784374 5.422 35.66812485047947 139.7476494190146 5.422 35.66812485047947 139.7476494190146 19.28 35.66809158770684 139.74758316784374 19.28 35.66809158770684 139.74758316784374 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66812485047947 139.7476494190146 5.422 35.66819658836253 139.7475953497071 5.422 35.66819658836253 139.7475953497071 19.28 35.66812485047947 139.7476494190146 19.28 35.66812485047947 139.7476494190146 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66819658836253 139.7475953497071 5.422 35.66816983369014 139.74754204844115 5.422 35.66816983369014 139.74754204844115 19.28 35.66819658836253 139.7475953497071 19.28 35.66819658836253 139.7475953497071 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66816983369014 139.74754204844115 5.422 35.668141293513145 139.7475635743991 5.422 35.668141293513145 139.7475635743991 19.28 35.66816983369014 139.74754204844115 19.28 35.66816983369014 139.74754204844115 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668141293513145 139.7475635743991 19.28 35.66812990201038 139.74754087611066 19.28 35.668103352789345 139.74756088663392 19.28 35.668108236147425 139.7475706128897 19.28 35.66809158770684 139.74758316784374 19.28 35.66812485047947 139.7476494190146 19.28 35.66819658836253 139.7475953497071 19.28 35.66816983369014 139.74754204844115 19.28 35.668141293513145 139.7475635743991 19.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-620643b4-ffcf-42c6-b84e-44b30ac51363"/>
							<gml:surfaceMember xlink:href="#poly-7aac2475-15d4-41ee-be56-7334fa1861be"/>
							<gml:surfaceMember xlink:href="#poly-1979e17f-83ca-45f8-af16-ae6ae3f0f6f1"/>
							<gml:surfaceMember xlink:href="#poly-dbc72e08-ad96-4dfb-b686-ad229cef3096"/>
							<gml:surfaceMember xlink:href="#poly-75e26362-3510-478f-9682-5499a60bbaaf"/>
							<gml:surfaceMember xlink:href="#poly-966803fe-b74b-45f7-8836-f21ae321eb8a"/>
							<gml:surfaceMember xlink:href="#poly-6857a87e-aba2-4ef5-bf67-b2b8ee50abdb"/>
							<gml:surfaceMember xlink:href="#poly-1a25bfc2-8d06-498b-8ed2-1c68df589dcf"/>
							<gml:surfaceMember xlink:href="#poly-41ea863d-b523-429b-b14c-2b9b9f1fc220"/>
							<gml:surfaceMember xlink:href="#poly-0c5b7972-76bd-4131-9d9c-eef2f02793f9"/>
							<gml:surfaceMember xlink:href="#poly-24c4631c-c746-499b-bb3f-b1c09d594dcf"/>
							<gml:surfaceMember xlink:href="#poly-a26217e0-ce46-4c3d-870b-ef0d83a95144"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-620643b4-ffcf-42c6-b84e-44b30ac51363">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-620643b4-ffcf-42c6-b84e-44b30ac51363">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-620643b4-ffcf-42c6-b84e-44b30ac51363">
											<gml:posList>35.66810823614742 139.7475706128897 5.422 35.66810335278932 139.74756088663392 5.422 35.66812990201037 139.74754087611066 5.422 35.66814129351314 139.7475635743991 5.422 35.66816983369012 139.74754204844115 5.422 35.668196588362505 139.7475953497071 5.422 35.668124850479444 139.7476494190146 5.422 35.66809158770684 139.74758316784374 5.422 35.66810823614742 139.7475706128897 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7aac2475-15d4-41ee-be56-7334fa1861be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7aac2475-15d4-41ee-be56-7334fa1861be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7aac2475-15d4-41ee-be56-7334fa1861be">
											<gml:posList>35.66810335278932 139.74756088663392 14.2 35.66810823614742 139.7475706128897 14.2 35.66811501440916 139.74758317592872 14.2 35.66814129351314 139.7475635743991 14.2 35.66812990201037 139.74754087611066 14.2 35.66810335278932 139.74756088663392 14.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1979e17f-83ca-45f8-af16-ae6ae3f0f6f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1979e17f-83ca-45f8-af16-ae6ae3f0f6f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1979e17f-83ca-45f8-af16-ae6ae3f0f6f1">
											<gml:posList>35.66809158770684 139.74758316784374 19.2 35.668124850479444 139.7476494190146 19.2 35.668196588362505 139.7475953497071 19.2 35.66816983369012 139.74754204844115 19.2 35.66811501440916 139.74758317592872 19.2 35.66810823614742 139.7475706128897 19.2 35.66809158770684 139.74758316784374 19.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dbc72e08-ad96-4dfb-b686-ad229cef3096">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbc72e08-ad96-4dfb-b686-ad229cef3096">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbc72e08-ad96-4dfb-b686-ad229cef3096">
											<gml:posList>35.66812990201037 139.74754087611066 5.422 35.66810335278932 139.74756088663392 5.422 35.66810335278932 139.74756088663392 14.2 35.66812990201037 139.74754087611066 14.2 35.66812990201037 139.74754087611066 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75e26362-3510-478f-9682-5499a60bbaaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75e26362-3510-478f-9682-5499a60bbaaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75e26362-3510-478f-9682-5499a60bbaaf">
											<gml:posList>35.66814129351314 139.7475635743991 5.422 35.66812990201037 139.74754087611066 5.422 35.66812990201037 139.74754087611066 14.2 35.66814129351314 139.7475635743991 14.2 35.66814129351314 139.7475635743991 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-966803fe-b74b-45f7-8836-f21ae321eb8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-966803fe-b74b-45f7-8836-f21ae321eb8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-966803fe-b74b-45f7-8836-f21ae321eb8a">
											<gml:posList>35.66816983369012 139.74754204844115 19.2 35.66816983369012 139.74754204844115 5.422 35.66814129351314 139.7475635743991 5.422 35.66814129351314 139.7475635743991 14.2 35.66811501440916 139.74758317592872 14.2 35.66811501440916 139.74758317592872 19.2 35.66816983369012 139.74754204844115 19.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6857a87e-aba2-4ef5-bf67-b2b8ee50abdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6857a87e-aba2-4ef5-bf67-b2b8ee50abdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6857a87e-aba2-4ef5-bf67-b2b8ee50abdb">
											<gml:posList>35.66810335278932 139.74756088663392 5.422 35.66810823614742 139.7475706128897 5.422 35.66810823614742 139.7475706128897 14.2 35.66810335278932 139.74756088663392 14.2 35.66810335278932 139.74756088663392 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a25bfc2-8d06-498b-8ed2-1c68df589dcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a25bfc2-8d06-498b-8ed2-1c68df589dcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a25bfc2-8d06-498b-8ed2-1c68df589dcf">
											<gml:posList>35.668196588362505 139.7475953497071 5.422 35.66816983369012 139.74754204844115 5.422 35.66816983369012 139.74754204844115 19.2 35.668196588362505 139.7475953497071 19.2 35.668196588362505 139.7475953497071 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41ea863d-b523-429b-b14c-2b9b9f1fc220">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41ea863d-b523-429b-b14c-2b9b9f1fc220">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41ea863d-b523-429b-b14c-2b9b9f1fc220">
											<gml:posList>35.66809158770684 139.74758316784374 19.2 35.66810823614742 139.7475706128897 19.2 35.66810823614742 139.7475706128897 14.2 35.66810823614742 139.7475706128897 5.422 35.66809158770684 139.74758316784374 5.422 35.66809158770684 139.74758316784374 19.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c5b7972-76bd-4131-9d9c-eef2f02793f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c5b7972-76bd-4131-9d9c-eef2f02793f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c5b7972-76bd-4131-9d9c-eef2f02793f9">
											<gml:posList>35.66810823614742 139.7475706128897 19.2 35.66811501440916 139.74758317592872 19.2 35.66811501440916 139.74758317592872 14.2 35.66810823614742 139.7475706128897 14.2 35.66810823614742 139.7475706128897 19.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24c4631c-c746-499b-bb3f-b1c09d594dcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24c4631c-c746-499b-bb3f-b1c09d594dcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24c4631c-c746-499b-bb3f-b1c09d594dcf">
											<gml:posList>35.66809158770684 139.74758316784374 5.422 35.668124850479444 139.7476494190146 5.422 35.668124850479444 139.7476494190146 19.2 35.66809158770684 139.74758316784374 19.2 35.66809158770684 139.74758316784374 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a26217e0-ce46-4c3d-870b-ef0d83a95144">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a26217e0-ce46-4c3d-870b-ef0d83a95144">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a26217e0-ce46-4c3d-870b-ef0d83a95144">
											<gml:posList>35.668124850479444 139.7476494190146 5.422 35.668196588362505 139.7475953497071 5.422 35.668196588362505 139.7475953497071 19.2 35.668124850479444 139.7476494190146 19.2 35.668124850479444 139.7476494190146 5.422</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2708</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">224</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.41</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>