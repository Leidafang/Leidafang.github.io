<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_326044c7-ca9c-4a7a-91cb-705430659bd9">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">4.7</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6714390995279 139.7389329363575 0 35.671429525503406 139.7388851167016 0 35.67141216014444 139.73889034001368 0 35.67142174318925 139.73893817069563 0 35.6714390995279 139.7389329363575 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714390995279 139.7389329363575 15.6 35.67142174318925 139.73893817069563 15.6 35.67141216014444 139.73889034001368 15.6 35.671429525503406 139.7388851167016 15.6 35.6714390995279 139.7389329363575 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714390995279 139.7389329363575 15.6 35.671429525503406 139.7388851167016 15.6 35.671429525503406 139.7388851167016 20.25 35.6714390995279 139.7389329363575 20.25 35.6714390995279 139.7389329363575 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671429525503406 139.7388851167016 15.6 35.67141216014444 139.73889034001368 15.6 35.67141216014444 139.73889034001368 20.25 35.671429525503406 139.7388851167016 20.25 35.671429525503406 139.7388851167016 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67141216014444 139.73889034001368 15.6 35.67142174318925 139.73893817069563 15.6 35.67142174318925 139.73893817069563 20.25 35.67141216014444 139.73889034001368 20.25 35.67141216014444 139.73889034001368 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67142174318925 139.73893817069563 15.6 35.6714390995279 139.7389329363575 15.6 35.6714390995279 139.7389329363575 20.25 35.67142174318925 139.73893817069563 20.25 35.67142174318925 139.73893817069563 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714390995279 139.7389329363575 20.25 35.671429525503406 139.7388851167016 20.25 35.67141216014444 139.73889034001368 20.25 35.67142174318925 139.73893817069563 20.25 35.6714390995279 139.7389329363575 20.25</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9c006555-6be9-4101-b54f-fa7c4e99eeba"/>
							<gml:surfaceMember xlink:href="#poly-22fa0e64-c7a9-4330-87bd-305c34dcb748"/>
							<gml:surfaceMember xlink:href="#poly-1ebf6e04-66ba-4b4a-be3a-51aef6267527"/>
							<gml:surfaceMember xlink:href="#poly-073ccacf-c524-4e72-b878-431140f75f8e"/>
							<gml:surfaceMember xlink:href="#poly-579c442b-ff40-4c61-8ba8-e46bda2332be"/>
							<gml:surfaceMember xlink:href="#poly-4cfc6895-5678-4568-8325-8bc66934fc54"/>
							<gml:surfaceMember xlink:href="#poly-8886bc25-35b0-40ce-8547-783ede566f15"/>
							<gml:surfaceMember xlink:href="#poly-88498e6e-632e-4dc8-8121-2a2bf06339ec"/>
							<gml:surfaceMember xlink:href="#poly-5f62d472-7759-4c55-9133-232b5a92f91e"/>
							<gml:surfaceMember xlink:href="#poly-5d397eb2-d967-43fe-920e-ce4816955748"/>
							<gml:surfaceMember xlink:href="#poly-18b7d0fc-15a3-4690-b037-8dcfab6d3454"/>
							<gml:surfaceMember xlink:href="#poly-d0f58627-3472-4c30-ab70-16c6748ed229"/>
							<gml:surfaceMember xlink:href="#poly-c2070a64-5e5d-4644-903a-0170ecd4b47b"/>
							<gml:surfaceMember xlink:href="#poly-61a5dd71-2327-4296-92d6-75ae91691520"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9c006555-6be9-4101-b54f-fa7c4e99eeba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c006555-6be9-4101-b54f-fa7c4e99eeba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c006555-6be9-4101-b54f-fa7c4e99eeba">
											<gml:posList>35.67143909952789 139.7389329363575 15.6 35.67142174318925 139.73893817069563 15.6 35.67141216014444 139.73889034001365 15.6 35.6714295255034 139.7388851167016 15.6 35.67143909952789 139.7389329363575 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22fa0e64-c7a9-4330-87bd-305c34dcb748">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22fa0e64-c7a9-4330-87bd-305c34dcb748">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22fa0e64-c7a9-4330-87bd-305c34dcb748">
											<gml:posList>35.67142174318925 139.73893817069563 20.576 35.67142325511288 139.7389351311547 20.576 35.671414649386904 139.73889219287693 20.576 35.67141216014444 139.73889034001365 20.576 35.67142174318925 139.73893817069563 20.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ebf6e04-66ba-4b4a-be3a-51aef6267527">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ebf6e04-66ba-4b4a-be3a-51aef6267527">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ebf6e04-66ba-4b4a-be3a-51aef6267527">
											<gml:posList>35.67141216014444 139.73889034001365 20.576 35.671414649386904 139.73889219287693 20.576 35.67142802260341 139.73888816727947 20.576 35.6714295255034 139.7388851167016 20.576 35.67141216014444 139.73889034001365 20.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-073ccacf-c524-4e72-b878-431140f75f8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-073ccacf-c524-4e72-b878-431140f75f8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-073ccacf-c524-4e72-b878-431140f75f8e">
											<gml:posList>35.67143661930843 139.73893109452817 20.125 35.67142802260341 139.73888816727947 20.125 35.671414649386904 139.73889219287693 20.125 35.67142325511288 139.7389351311547 20.125 35.67143661930843 139.73893109452817 20.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-579c442b-ff40-4c61-8ba8-e46bda2332be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-579c442b-ff40-4c61-8ba8-e46bda2332be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-579c442b-ff40-4c61-8ba8-e46bda2332be">
											<gml:posList>35.67143909952789 139.7389329363575 20.576 35.67143661930843 139.73893109452817 20.576 35.67142325511288 139.7389351311547 20.576 35.67142174318925 139.73893817069563 20.576 35.67143909952789 139.7389329363575 20.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4cfc6895-5678-4568-8325-8bc66934fc54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cfc6895-5678-4568-8325-8bc66934fc54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cfc6895-5678-4568-8325-8bc66934fc54">
											<gml:posList>35.6714295255034 139.7388851167016 20.576 35.67142802260341 139.73888816727947 20.576 35.67143661930843 139.73893109452817 20.576 35.67143909952789 139.7389329363575 20.576 35.6714295255034 139.7388851167016 20.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8886bc25-35b0-40ce-8547-783ede566f15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8886bc25-35b0-40ce-8547-783ede566f15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8886bc25-35b0-40ce-8547-783ede566f15">
											<gml:posList>35.6714295255034 139.7388851167016 15.6 35.67141216014444 139.73889034001365 15.6 35.67141216014444 139.73889034001365 20.576 35.6714295255034 139.7388851167016 20.576 35.6714295255034 139.7388851167016 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88498e6e-632e-4dc8-8121-2a2bf06339ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88498e6e-632e-4dc8-8121-2a2bf06339ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88498e6e-632e-4dc8-8121-2a2bf06339ec">
											<gml:posList>35.671414649386904 139.73889219287693 20.576 35.671414649386904 139.73889219287693 20.125 35.67142802260341 139.73888816727947 20.125 35.67142802260341 139.73888816727947 20.576 35.671414649386904 139.73889219287693 20.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f62d472-7759-4c55-9133-232b5a92f91e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f62d472-7759-4c55-9133-232b5a92f91e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f62d472-7759-4c55-9133-232b5a92f91e">
											<gml:posList>35.67143909952789 139.7389329363575 15.6 35.6714295255034 139.7388851167016 15.6 35.6714295255034 139.7388851167016 20.576 35.67143909952789 139.7389329363575 20.576 35.67143909952789 139.7389329363575 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d397eb2-d967-43fe-920e-ce4816955748">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d397eb2-d967-43fe-920e-ce4816955748">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d397eb2-d967-43fe-920e-ce4816955748">
											<gml:posList>35.67142802260341 139.73888816727947 20.576 35.67142802260341 139.73888816727947 20.125 35.67143661930843 139.73893109452817 20.125 35.67143661930843 139.73893109452817 20.576 35.67142802260341 139.73888816727947 20.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18b7d0fc-15a3-4690-b037-8dcfab6d3454">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18b7d0fc-15a3-4690-b037-8dcfab6d3454">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18b7d0fc-15a3-4690-b037-8dcfab6d3454">
											<gml:posList>35.67142325511288 139.7389351311547 20.576 35.67142325511288 139.7389351311547 20.125 35.671414649386904 139.73889219287693 20.125 35.671414649386904 139.73889219287693 20.576 35.67142325511288 139.7389351311547 20.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0f58627-3472-4c30-ab70-16c6748ed229">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0f58627-3472-4c30-ab70-16c6748ed229">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0f58627-3472-4c30-ab70-16c6748ed229">
											<gml:posList>35.67141216014444 139.73889034001365 15.6 35.67142174318925 139.73893817069563 15.6 35.67142174318925 139.73893817069563 20.576 35.67141216014444 139.73889034001365 20.576 35.67141216014444 139.73889034001365 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2070a64-5e5d-4644-903a-0170ecd4b47b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2070a64-5e5d-4644-903a-0170ecd4b47b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2070a64-5e5d-4644-903a-0170ecd4b47b">
											<gml:posList>35.67143661930843 139.73893109452817 20.576 35.67143661930843 139.73893109452817 20.125 35.67142325511288 139.7389351311547 20.125 35.67142325511288 139.7389351311547 20.576 35.67143661930843 139.73893109452817 20.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61a5dd71-2327-4296-92d6-75ae91691520">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61a5dd71-2327-4296-92d6-75ae91691520">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61a5dd71-2327-4296-92d6-75ae91691520">
											<gml:posList>35.67142174318925 139.73893817069563 15.6 35.67143909952789 139.7389329363575 15.6 35.67143909952789 139.7389329363575 20.576 35.67142174318925 139.73893817069563 20.576 35.67142174318925 139.73893817069563 15.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10736</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.3</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>