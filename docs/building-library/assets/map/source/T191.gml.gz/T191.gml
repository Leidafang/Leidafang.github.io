<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3295ce08-3d00-4893-b389-f5b20e2b6322">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67188294130245 139.73976023594574 0 35.67179977013231 139.73967715321203 0 35.67173899862608 139.73976868878114 0 35.67182216964815 139.73985166108267 0 35.67188294130245 139.73976023594574 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67188294130245 139.73976023594574 9.47 35.67182216964815 139.73985166108267 9.47 35.67173899862608 139.73976868878114 9.47 35.67179977013231 139.73967715321203 9.47 35.67188294130245 139.73976023594574 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67188294130245 139.73976023594574 9.47 35.67179977013231 139.73967715321203 9.47 35.67179977013231 139.73967715321203 26.369999999999997 35.67188294130245 139.73976023594574 26.369999999999997 35.67188294130245 139.73976023594574 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67179977013231 139.73967715321203 9.47 35.67173899862608 139.73976868878114 9.47 35.67173899862608 139.73976868878114 26.369999999999997 35.67179977013231 139.73967715321203 26.369999999999997 35.67179977013231 139.73967715321203 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67173899862608 139.73976868878114 9.47 35.67182216964815 139.73985166108267 9.47 35.67182216964815 139.73985166108267 26.369999999999997 35.67173899862608 139.73976868878114 26.369999999999997 35.67173899862608 139.73976868878114 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67182216964815 139.73985166108267 9.47 35.67188294130245 139.73976023594574 9.47 35.67188294130245 139.73976023594574 26.369999999999997 35.67182216964815 139.73985166108267 26.369999999999997 35.67182216964815 139.73985166108267 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67188294130245 139.73976023594574 26.369999999999997 35.67179977013231 139.73967715321203 26.369999999999997 35.67173899862608 139.73976868878114 26.369999999999997 35.67182216964815 139.73985166108267 26.369999999999997 35.67188294130245 139.73976023594574 26.369999999999997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-62c51cbd-9bb2-4da7-934e-d46dfed622fd"/>
							<gml:surfaceMember xlink:href="#poly-50f7abe7-6f9e-4d0c-a1de-ac937cffcc85"/>
							<gml:surfaceMember xlink:href="#poly-448053b8-f916-4c27-a0f1-9a0abdc25ab0"/>
							<gml:surfaceMember xlink:href="#poly-837188a7-31fd-4afa-9231-6ad530048a65"/>
							<gml:surfaceMember xlink:href="#poly-4d660c6a-dfa7-4213-a015-bc86b02c53cf"/>
							<gml:surfaceMember xlink:href="#poly-494cf666-e733-4625-b49a-3b2cd76bd597"/>
							<gml:surfaceMember xlink:href="#poly-068d1209-263e-4c5f-9a18-f082cc018dde"/>
							<gml:surfaceMember xlink:href="#poly-8e64cbcf-bb9b-4131-9334-646cf7ded2e0"/>
							<gml:surfaceMember xlink:href="#poly-4a69ee03-d5b7-4b67-9f85-9d9dbc9be68f"/>
							<gml:surfaceMember xlink:href="#poly-a7d29806-85b9-47d8-a393-a56b1f07aee3"/>
							<gml:surfaceMember xlink:href="#poly-0fdeeeca-d9dd-4911-95a6-7b914e7e4500"/>
							<gml:surfaceMember xlink:href="#poly-174d20f8-cb9d-45e6-9c52-6b74b7e55a7c"/>
							<gml:surfaceMember xlink:href="#poly-f0d0290f-8a3d-4440-b9d3-1388da9cbc10"/>
							<gml:surfaceMember xlink:href="#poly-b62bd89d-0e31-4d33-8be9-cfd0125d59bf"/>
							<gml:surfaceMember xlink:href="#poly-ea867ddb-30e3-4c86-8537-af86455047d3"/>
							<gml:surfaceMember xlink:href="#poly-d18944bd-4698-470a-a93f-d97c839f5a7d"/>
							<gml:surfaceMember xlink:href="#poly-24ed2da4-a227-4390-bead-f66cc2fc0a14"/>
							<gml:surfaceMember xlink:href="#poly-7f4df24d-c47a-4aea-9899-7893e320a84b"/>
							<gml:surfaceMember xlink:href="#poly-d04a05d6-0c25-483f-9c67-69c94f38b829"/>
							<gml:surfaceMember xlink:href="#poly-8945e910-d8eb-4913-89d3-9ac38adaab8d"/>
							<gml:surfaceMember xlink:href="#poly-33f5abff-4303-46b7-9dfd-f08b584b9008"/>
							<gml:surfaceMember xlink:href="#poly-f8cab6bd-f0fe-44d9-a147-51543b356d8c"/>
							<gml:surfaceMember xlink:href="#poly-51379e4d-9e0e-43b2-8883-6accfe58808a"/>
							<gml:surfaceMember xlink:href="#poly-3f75e1f8-a003-46ed-8d0e-7024601efa37"/>
							<gml:surfaceMember xlink:href="#poly-cb4ed928-e53f-4f9d-8258-332223757f44"/>
							<gml:surfaceMember xlink:href="#poly-37e432bf-6f67-47c4-8c98-2cee16788d71"/>
							<gml:surfaceMember xlink:href="#poly-fd076968-23d5-424e-b505-51b95ffe1876"/>
							<gml:surfaceMember xlink:href="#poly-6f971590-19b7-40a5-bbed-919f3b7b5799"/>
							<gml:surfaceMember xlink:href="#poly-26c27ada-bc4c-4b82-bfff-c08863ddf31b"/>
							<gml:surfaceMember xlink:href="#poly-30bf8b97-f761-4cf6-b8d8-d483b5cabc56"/>
							<gml:surfaceMember xlink:href="#poly-47763556-e1af-413a-bff0-1548bb2c1dd4"/>
							<gml:surfaceMember xlink:href="#poly-ebfed059-bdb6-4831-9212-bd202e2a1179"/>
							<gml:surfaceMember xlink:href="#poly-ecd8957e-0410-4b7c-810c-c5471baa70a4"/>
							<gml:surfaceMember xlink:href="#poly-4f554885-1b94-48a5-8f6e-79cdab185e6f"/>
							<gml:surfaceMember xlink:href="#poly-05357926-3a18-49b5-8d04-fe6d8e892235"/>
							<gml:surfaceMember xlink:href="#poly-8531272c-faed-4fd1-987a-a1553538b364"/>
							<gml:surfaceMember xlink:href="#poly-49f55682-bfb5-4f99-8f72-af2c26bd376f"/>
							<gml:surfaceMember xlink:href="#poly-2cbd772e-3e3e-42d0-b6b5-7b737a98c1f3"/>
							<gml:surfaceMember xlink:href="#poly-8272c5cc-3090-4d84-bf17-7d3505988bef"/>
							<gml:surfaceMember xlink:href="#poly-c8e102d7-fb84-4ea0-aa72-70d062eebc15"/>
							<gml:surfaceMember xlink:href="#poly-d65c6652-5541-4f41-bf58-c0598548f8d9"/>
							<gml:surfaceMember xlink:href="#poly-b6859368-cef0-4f0e-8379-c630ec8d809e"/>
							<gml:surfaceMember xlink:href="#poly-57e48b67-24c1-4302-82ae-8291f2213ba3"/>
							<gml:surfaceMember xlink:href="#poly-5c2d9f78-cdf1-4b90-8b9d-a42dc8dc3390"/>
							<gml:surfaceMember xlink:href="#poly-96f1e33d-5264-4f0f-b05b-9a9a51480260"/>
							<gml:surfaceMember xlink:href="#poly-d8dc6121-0a87-436f-8aaa-ef92998c97d2"/>
							<gml:surfaceMember xlink:href="#poly-708446ba-f6ee-470c-8bf8-21f053f5caeb"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3295ce08-3d00-4893-b389-f5b20e2b6322_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-481cd67b-0507-44ce-ad96-dbfbe92de8c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-481cd67b-0507-44ce-ad96-dbfbe92de8c7_0">
											<gml:posList>35.6717890043771 139.73974238404958 26.583 35.6718013837996 139.73972378946073 28.975 35.6718013837996 139.73972378946073 26.583 35.6717890043771 139.73974238404958 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c07a9da-b3fe-44a9-85c4-0d03f008261d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c07a9da-b3fe-44a9-85c4-0d03f008261d_0">
											<gml:posList>35.6717890043771 139.73974238404958 26.583 35.6717890043771 139.73974238404958 28.975 35.6718013837996 139.73972378946073 28.975 35.6717890043771 139.73974238404958 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b7370ed-accc-42a7-bc95-4b1cbee908a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b7370ed-accc-42a7-bc95-4b1cbee908a0_0">
											<gml:posList>35.6717890043771 139.73974238404958 26.583 35.6718086154609 139.739761990709 28.975 35.6717890043771 139.73974238404958 28.975 35.6717890043771 139.73974238404958 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98bc4569-356e-4b46-9582-b8d32a12cbd0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98bc4569-356e-4b46-9582-b8d32a12cbd0_0">
											<gml:posList>35.6717890043771 139.73974238404958 26.583 35.6718086154609 139.739761990709 26.583 35.6718086154609 139.739761990709 28.975 35.6717890043771 139.73974238404958 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4afd53b8-c6fb-4172-bd54-910c6418748e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4afd53b8-c6fb-4172-bd54-910c6418748e_0">
											<gml:posList>35.6718013837996 139.73972378946073 28.975 35.6718086154609 139.739761990709 28.975 35.671820994877784 139.73974338507225 28.975 35.6718013837996 139.73972378946073 28.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab13d66f-babc-431c-a376-c411692021b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab13d66f-babc-431c-a376-c411692021b1_0">
											<gml:posList>35.6718013837996 139.73972378946073 28.975 35.6717890043771 139.73974238404958 28.975 35.6718086154609 139.739761990709 28.975 35.6718013837996 139.73972378946073 28.975</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f00ea23-bfa2-4526-9813-fefc6b36104d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f00ea23-bfa2-4526-9813-fefc6b36104d_0">
											<gml:posList>35.671820994877784 139.73974338507225 26.583 35.6718013837996 139.73972378946073 28.975 35.671820994877784 139.73974338507225 28.975 35.671820994877784 139.73974338507225 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab90077f-8dab-4f91-9df8-849bde253c71">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab90077f-8dab-4f91-9df8-849bde253c71_0">
											<gml:posList>35.671820994877784 139.73974338507225 26.583 35.6718013837996 139.73972378946073 26.583 35.6718013837996 139.73972378946073 28.975 35.671820994877784 139.73974338507225 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8a9d8ca-0662-4f58-8d23-a8316d9cc22d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8a9d8ca-0662-4f58-8d23-a8316d9cc22d_0">
											<gml:posList>35.6718086154609 139.739761990709 26.583 35.671820994877784 139.73974338507225 28.975 35.6718086154609 139.739761990709 28.975 35.6718086154609 139.739761990709 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bee77cb2-6d6e-4521-bb74-2b09e84fedee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bee77cb2-6d6e-4521-bb74-2b09e84fedee_0">
											<gml:posList>35.6718086154609 139.739761990709 26.583 35.671820994877784 139.73974338507225 26.583 35.671820994877784 139.73974338507225 28.975 35.6718086154609 139.739761990709 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e6b7e51-fbac-4ee1-86b5-6df041f6a233">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e6b7e51-fbac-4ee1-86b5-6df041f6a233_0">
											<gml:posList>35.671851548548155 139.73977448938214 26.583 35.671839889374596 139.73979200058133 27.484 35.671851548548155 139.73977448938214 27.484 35.671851548548155 139.73977448938214 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4afb4c4c-9438-4dbf-b9aa-cc4effeea99e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4afb4c4c-9438-4dbf-b9aa-cc4effeea99e_0">
											<gml:posList>35.671851548548155 139.73977448938214 26.583 35.671839889374596 139.73979200058133 26.583 35.671839889374596 139.73979200058133 27.484 35.671851548548155 139.73977448938214 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cd8d01f-0995-44e0-9be9-806921fa0aad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cd8d01f-0995-44e0-9be9-806921fa0aad_0">
											<gml:posList>35.671857736775216 139.73978067922644 26.583 35.671851548548155 139.73977448938214 27.484 35.671857736775216 139.73978067922644 27.484 35.671857736775216 139.73978067922644 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a357ac69-0458-4b1d-acdc-e70d15cda50a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a357ac69-0458-4b1d-acdc-e70d15cda50a_0">
											<gml:posList>35.671857736775216 139.73978067922644 26.583 35.671851548548155 139.73977448938214 26.583 35.671851548548155 139.73977448938214 27.484 35.671857736775216 139.73978067922644 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60f66f2d-5840-485c-8800-e0bb7532c860">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60f66f2d-5840-485c-8800-e0bb7532c860_0">
											<gml:posList>35.671857736775216 139.73978067922644 27.484 35.671839889374596 139.73979200058133 27.484 35.67184607760077 139.7397981904261 27.484 35.671857736775216 139.73978067922644 27.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9363a032-ee98-4644-a1e8-8a92213d63ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9363a032-ee98-4644-a1e8-8a92213d63ce_0">
											<gml:posList>35.671857736775216 139.73978067922644 27.484 35.671851548548155 139.73977448938214 27.484 35.671839889374596 139.73979200058133 27.484 35.671857736775216 139.73978067922644 27.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19862933-1b4b-495e-9e18-9316d1d9e743">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19862933-1b4b-495e-9e18-9316d1d9e743_0">
											<gml:posList>35.671857736775216 139.73978067922644 26.583 35.67184607760077 139.7397981904261 27.484 35.67184607760077 139.7397981904261 26.583 35.671857736775216 139.73978067922644 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e71263f-ca10-4a94-9662-40b4019b9c1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e71263f-ca10-4a94-9662-40b4019b9c1e_0">
											<gml:posList>35.671857736775216 139.73978067922644 26.583 35.671857736775216 139.73978067922644 27.484 35.67184607760077 139.7397981904261 27.484 35.671857736775216 139.73978067922644 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f3c1937-ac69-4b51-9771-26a54e9dc3e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f3c1937-ac69-4b51-9771-26a54e9dc3e0_0">
											<gml:posList>35.67184607760077 139.7397981904261 26.583 35.671839889374596 139.73979200058133 27.484 35.671839889374596 139.73979200058133 26.583 35.67184607760077 139.7397981904261 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d52527b-18ca-4417-befa-2e4e91365c4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d52527b-18ca-4417-befa-2e4e91365c4a_0">
											<gml:posList>35.67184607760077 139.7397981904261 26.583 35.67184607760077 139.7397981904261 27.484 35.671839889374596 139.73979200058133 27.484 35.67184607760077 139.7397981904261 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eaa1c3bb-cac2-4b5c-8c83-88bc60638a62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eaa1c3bb-cac2-4b5c-8c83-88bc60638a62_0">
											<gml:posList>35.67183756592799 139.73981790724127 30.734 35.671820742289604 139.73980112520226 32.839 35.67183756592799 139.73981790724127 32.839 35.67183756592799 139.73981790724127 30.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b1bfb55-e110-4256-abb8-1ee80a2f2371">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b1bfb55-e110-4256-abb8-1ee80a2f2371_0">
											<gml:posList>35.67183756592799 139.73981790724127 30.734 35.671820742289604 139.73980112520226 30.734 35.671820742289604 139.73980112520226 32.839 35.67183756592799 139.73981790724127 30.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5736b29-3929-4a22-bf8a-1d96ae43f45f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5736b29-3929-4a22-bf8a-1d96ae43f45f_0">
											<gml:posList>35.671804707599776 139.73982528041432 30.734 35.671820742289604 139.73980112520226 32.839 35.671820742289604 139.73980112520226 30.734 35.671804707599776 139.73982528041432 30.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9edbcb22-7853-4693-85a9-a3e08cf4ad4b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9edbcb22-7853-4693-85a9-a3e08cf4ad4b_0">
											<gml:posList>35.671804707599776 139.73982528041432 30.734 35.671804707599776 139.73982528041432 32.839 35.671820742289604 139.73980112520226 32.839 35.671804707599776 139.73982528041432 30.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-763f9510-506c-49c8-af69-2c328be70d94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-763f9510-506c-49c8-af69-2c328be70d94_0">
											<gml:posList>35.67182932011538 139.73982015929053 32.839 35.67182111126407 139.73981197239348 33.698 35.67182932011538 139.73982015929053 33.698 35.67182932011538 139.73982015929053 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f9407be-10de-4bda-b99d-92b8bb98a350">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f9407be-10de-4bda-b99d-92b8bb98a350_0">
											<gml:posList>35.67182932011538 139.73982015929053 32.839 35.67182111126407 139.73981197239348 32.839 35.67182111126407 139.73981197239348 33.698 35.67182932011538 139.73982015929053 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63a216cf-e814-4ee3-a8cb-8e466490cef3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63a216cf-e814-4ee3-a8cb-8e466490cef3_0">
											<gml:posList>35.67182111126407 139.73981197239348 32.839 35.67181450290596 139.7398219108669 33.698 35.67182111126407 139.73981197239348 33.698 35.67182111126407 139.73981197239348 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ad7cdfa-0f99-4f8f-bfb4-e7363bc3a92e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ad7cdfa-0f99-4f8f-bfb4-e7363bc3a92e_0">
											<gml:posList>35.67182111126407 139.73981197239348 32.839 35.67181450290596 139.7398219108669 32.839 35.67181450290596 139.7398219108669 33.698 35.67182111126407 139.73981197239348 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2d7ee32-2f6d-40d4-b31f-5d36c3909548">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2d7ee32-2f6d-40d4-b31f-5d36c3909548_0">
											<gml:posList>35.67182111126407 139.73981197239348 33.698 35.67181450290596 139.7398219108669 33.698 35.67182271175661 139.7398300977643 33.698 35.67182111126407 139.73981197239348 33.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07c58f4d-b938-4544-943e-637b6adcf206">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07c58f4d-b938-4544-943e-637b6adcf206_0">
											<gml:posList>35.67182932011538 139.73982015929053 33.698 35.67182111126407 139.73981197239348 33.698 35.67182271175661 139.7398300977643 33.698 35.67182932011538 139.73982015929053 33.698</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-262fa1c1-cc49-4388-872e-523e9801e75a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-262fa1c1-cc49-4388-872e-523e9801e75a_0">
											<gml:posList>35.671820742289604 139.73980112520226 32.839 35.671804707599776 139.73982528041432 32.839 35.67181450290596 139.7398219108669 32.839 35.671820742289604 139.73980112520226 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e21e71a-32ab-43af-97e5-2fb791490276">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e21e71a-32ab-43af-97e5-2fb791490276_0">
											<gml:posList>35.671804707599776 139.73982528041432 32.839 35.67182152221253 139.73984205141915 32.839 35.67181450290596 139.7398219108669 32.839 35.671804707599776 139.73982528041432 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e9b9aa6-517e-4d31-8d1f-f3931232d4ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e9b9aa6-517e-4d31-8d1f-f3931232d4ff_0">
											<gml:posList>35.67182111126407 139.73981197239348 32.839 35.67183756592799 139.73981790724127 32.839 35.671820742289604 139.73980112520226 32.839 35.67182111126407 139.73981197239348 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d10d1141-68f1-436d-abdf-f7646c0d2a4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d10d1141-68f1-436d-abdf-f7646c0d2a4c_0">
											<gml:posList>35.67183756592799 139.73981790724127 32.839 35.67182271175661 139.7398300977643 32.839 35.67182152221253 139.73984205141915 32.839 35.67183756592799 139.73981790724127 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dc0483b-f4de-4078-adbf-1be92b6f0fac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dc0483b-f4de-4078-adbf-1be92b6f0fac_0">
											<gml:posList>35.67182111126407 139.73981197239348 32.839 35.671820742289604 139.73980112520226 32.839 35.67181450290596 139.7398219108669 32.839 35.67182111126407 139.73981197239348 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-481a0456-abd5-4994-9638-5ff5cb3e80cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-481a0456-abd5-4994-9638-5ff5cb3e80cf_0">
											<gml:posList>35.67182152221253 139.73984205141915 32.839 35.67182271175661 139.7398300977643 32.839 35.67181450290596 139.7398219108669 32.839 35.67182152221253 139.73984205141915 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9fe4741-f80f-4ba0-8185-6e246447596a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9fe4741-f80f-4ba0-8185-6e246447596a_0">
											<gml:posList>35.67182932011538 139.73982015929053 32.839 35.67183756592799 139.73981790724127 32.839 35.67182111126407 139.73981197239348 32.839 35.67182932011538 139.73982015929053 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f69f1b54-2e63-46c5-a1cb-247509e9afe8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f69f1b54-2e63-46c5-a1cb-247509e9afe8_0">
											<gml:posList>35.67182932011538 139.73982015929053 32.839 35.67182271175661 139.7398300977643 32.839 35.67183756592799 139.73981790724127 32.839 35.67182932011538 139.73982015929053 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35cecac8-9adf-4db3-9117-0bfcfdbfc89e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35cecac8-9adf-4db3-9117-0bfcfdbfc89e_0">
											<gml:posList>35.67182271175661 139.7398300977643 32.839 35.67182932011538 139.73982015929053 33.698 35.67182271175661 139.7398300977643 33.698 35.67182271175661 139.7398300977643 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a714e9b-9843-4142-a64c-70df03b2e68b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a714e9b-9843-4142-a64c-70df03b2e68b_0">
											<gml:posList>35.67182271175661 139.7398300977643 32.839 35.67182932011538 139.73982015929053 32.839 35.67182932011538 139.73982015929053 33.698 35.67182271175661 139.7398300977643 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e413050-dc65-4adb-bfc0-9595abf0ca30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e413050-dc65-4adb-bfc0-9595abf0ca30_0">
											<gml:posList>35.67182271175661 139.7398300977643 32.839 35.67181450290596 139.7398219108669 33.698 35.67181450290596 139.7398219108669 32.839 35.67182271175661 139.7398300977643 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8784badd-5693-463b-8343-64319e14e90f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8784badd-5693-463b-8343-64319e14e90f_0">
											<gml:posList>35.67182271175661 139.7398300977643 32.839 35.67182271175661 139.7398300977643 33.698 35.67181450290596 139.7398219108669 33.698 35.67182271175661 139.7398300977643 32.839</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4df520aa-a75a-478e-bb7c-c43906a75fbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4df520aa-a75a-478e-bb7c-c43906a75fbe_0">
											<gml:posList>35.67182152221253 139.73984205141915 30.734 35.67183756592799 139.73981790724127 32.839 35.67182152221253 139.73984205141915 32.839 35.67182152221253 139.73984205141915 30.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46fd7b98-f27a-4c9d-8607-d759036477d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46fd7b98-f27a-4c9d-8607-d759036477d6_0">
											<gml:posList>35.67182152221253 139.73984205141915 30.734 35.67183756592799 139.73981790724127 30.734 35.67183756592799 139.73981790724127 32.839 35.67182152221253 139.73984205141915 30.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57c303ec-eec4-4a08-a39e-e0d20530541d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57c303ec-eec4-4a08-a39e-e0d20530541d_0">
											<gml:posList>35.671804707599776 139.73982528041432 30.734 35.67182152221253 139.73984205141915 32.839 35.671804707599776 139.73982528041432 32.839 35.671804707599776 139.73982528041432 30.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-573fd6ee-7023-41e2-9bdd-1a7669f2a0e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-573fd6ee-7023-41e2-9bdd-1a7669f2a0e6_0">
											<gml:posList>35.671804707599776 139.73982528041432 30.734 35.67182152221253 139.73984205141915 30.734 35.67182152221253 139.73984205141915 32.839 35.671804707599776 139.73982528041432 30.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcc93588-1c93-4858-838d-8e1268ec18d9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6718013837996 139.73972378946073 26.583 35.6718086154609 139.739761990709 26.583 35.6717890043771 139.73974238404958 26.583 35.6718013837996 139.73972378946073 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-801d8198-38e9-458f-838d-5303643cca3b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6718013837996 139.73972378946073 26.583 35.671820994877784 139.73974338507225 26.583 35.6718086154609 139.739761990709 26.583 35.6718013837996 139.73972378946073 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e012e7c-5444-4f8e-9853-3317fb905cd1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67182152221253 139.73984205141915 30.734 35.671804707599776 139.73982528041432 30.734 35.671820742289604 139.73980112520226 30.734 35.67182152221253 139.73984205141915 30.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccec0699-cc09-4034-9721-6127bd7a8f15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67183756592799 139.73981790724127 30.734 35.67182152221253 139.73984205141915 30.734 35.671820742289604 139.73980112520226 30.734 35.67183756592799 139.73981790724127 30.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf23c640-6d53-42b1-90a3-7670dbc7e9d9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671839889374596 139.73979200058133 26.583 35.671857736775216 139.73978067922644 26.583 35.67184607760077 139.7397981904261 26.583 35.671839889374596 139.73979200058133 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de9138ff-13f6-4df3-8865-405a8eaab32d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671839889374596 139.73979200058133 26.583 35.671851548548155 139.73977448938214 26.583 35.671857736775216 139.73978067922644 26.583 35.671839889374596 139.73979200058133 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3295ce08-3d00-4893-b389-f5b20e2b6322_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e25d045a-63d6-4cac-92d5-9ea91a49862e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671821405894875 139.73977353037614 26.583 35.67184519356971 139.73979730774053 26.583 35.671839098377134 139.7398064502744 26.583 35.67182395255923 139.73979130115566 26.583 35.67181531070408 139.7397826729091 26.583 35.671821405894875 139.73977353037614 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-036297cc-9b12-46ec-b474-9c46d838c1e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-036297cc-9b12-46ec-b474-9c46d838c1e1_0">
											<gml:posList>35.67181531070408 139.7397826729091 26.583 35.67181531070408 139.7397826729091 27.484 35.671821405894875 139.73977353037614 27.484 35.671821405894875 139.73977353037614 26.583 35.67181531070408 139.7397826729091 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de2ae8b5-b337-4633-a201-0e94849e9c2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de2ae8b5-b337-4633-a201-0e94849e9c2e_0">
											<gml:posList>35.671821405894875 139.73977353037614 26.583 35.671821405894875 139.73977353037614 27.484 35.67184519356971 139.73979730774053 27.484 35.67184519356971 139.73979730774053 26.583 35.671821405894875 139.73977353037614 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff2f1d96-b512-4d96-a3d8-f1432e902c4f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff2f1d96-b512-4d96-a3d8-f1432e902c4f_0">
											<gml:posList>35.67181531070408 139.7397826729091 27.484 35.67181531070408 139.7397826729091 26.583 35.67182395255923 139.73979130115566 26.583 35.67182395255923 139.73979130115566 26.743 35.671825323708816 139.73979266931673 27.484 35.67181531070408 139.7397826729091 27.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe818da9-0a19-464f-9f29-0efa7e90d9c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe818da9-0a19-464f-9f29-0efa7e90d9c9_0">
											<gml:posList>35.671825323708816 139.73979266931673 27.484 35.671839098377134 139.7398064502744 27.484 35.67184519356971 139.73979730774053 27.484 35.671821405894875 139.73977353037614 27.484 35.67181531070408 139.7397826729091 27.484 35.671825323708816 139.73979266931673 27.484</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd271957-6a3b-469c-ab6d-36e13cd875a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd271957-6a3b-469c-ab6d-36e13cd875a0_0">
											<gml:posList>35.671839098377134 139.7398064502744 26.583 35.671839098377134 139.7398064502744 27.484 35.671825323708816 139.73979266931673 27.484 35.67182395255923 139.73979130115566 26.743 35.67182395255923 139.73979130115566 26.583 35.671839098377134 139.7398064502744 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3120d499-18ef-42ed-b04c-cf3ffff7fa2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3120d499-18ef-42ed-b04c-cf3ffff7fa2d_0">
											<gml:posList>35.671839098377134 139.7398064502744 26.583 35.67184519356971 139.73979730774053 26.583 35.67184519356971 139.73979730774053 27.484 35.671839098377134 139.7398064502744 27.484 35.671839098377134 139.7398064502744 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-62c51cbd-9bb2-4da7-934e-d46dfed622fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62c51cbd-9bb2-4da7-934e-d46dfed622fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62c51cbd-9bb2-4da7-934e-d46dfed622fd">
											<gml:posList>35.67188294130242 139.73976023594574 9.47 35.671822169648145 139.73985166108267 9.47 35.67173899862606 139.73976868878117 9.47 35.67179977013231 139.73967715321203 9.47 35.67188294130242 139.73976023594574 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50f7abe7-6f9e-4d0c-a1de-ac937cffcc85">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50f7abe7-6f9e-4d0c-a1de-ac937cffcc85">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50f7abe7-6f9e-4d0c-a1de-ac937cffcc85">
											<gml:posList>35.67176467632939 139.73976558790145 26.817 35.67175888484251 139.73975957434558 26.592 35.67173899862606 139.73976868878117 25.093 35.67176467632939 139.73976558790145 26.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-448053b8-f916-4c27-a0f1-9a0abdc25ab0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-448053b8-f916-4c27-a0f1-9a0abdc25ab0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-448053b8-f916-4c27-a0f1-9a0abdc25ab0">
											<gml:posList>35.67176467632939 139.73976558790145 26.817 35.67173899862606 139.73976868878117 25.093 35.67175339569885 139.73978305445542 26.817 35.67176467632939 139.73976558790145 26.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-837188a7-31fd-4afa-9231-6ad530048a65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-837188a7-31fd-4afa-9231-6ad530048a65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-837188a7-31fd-4afa-9231-6ad530048a65">
											<gml:posList>35.67176467632939 139.73976558790145 26.85 35.67175339569885 139.73978305445542 26.85 35.67175764972863 139.73978247507623 26.85 35.67176890336941 139.73976507483144 26.85 35.67176467632939 139.73976558790145 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d660c6a-dfa7-4213-a015-bc86b02c53cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d660c6a-dfa7-4213-a015-bc86b02c53cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d660c6a-dfa7-4213-a015-bc86b02c53cf">
											<gml:posList>35.67175764972863 139.73978247507623 26.85 35.67175339569885 139.73978305445542 26.85 35.67176807240977 139.73979769596983 26.85 35.67176999908912 139.73979478850546 26.85 35.67175764972863 139.73978247507623 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-494cf666-e733-4625-b49a-3b2cd76bd597">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-494cf666-e733-4625-b49a-3b2cd76bd597">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-494cf666-e733-4625-b49a-3b2cd76bd597">
											<gml:posList>35.67176467632939 139.73976558790145 26.85 35.67176890336941 139.73976507483144 26.85 35.67176310286021 139.73975905023943 26.85 35.67175888484251 139.73975957434558 26.85 35.67176467632939 139.73976558790145 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-068d1209-263e-4c5f-9a18-f082cc018dde">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-068d1209-263e-4c5f-9a18-f082cc018dde">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-068d1209-263e-4c5f-9a18-f082cc018dde">
											<gml:posList>35.67179977013231 139.73967715321203 25.093 35.67173899862606 139.73976868878117 25.093 35.67175888484251 139.73975957434558 26.592 35.67179977013231 139.73967715321203 25.093</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8e64cbcf-bb9b-4131-9334-646cf7ded2e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e64cbcf-bb9b-4131-9334-646cf7ded2e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e64cbcf-bb9b-4131-9334-646cf7ded2e0">
											<gml:posList>35.67175888484251 139.73975957434558 26.85 35.67176310286021 139.73975905023943 26.85 35.671799708492784 139.73970220664384 26.85 35.67179925366643 139.73969688278376 26.85 35.67175888484251 139.73975957434558 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4a69ee03-d5b7-4b67-9f85-9d9dbc9be68f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a69ee03-d5b7-4b67-9f85-9d9dbc9be68f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a69ee03-d5b7-4b67-9f85-9d9dbc9be68f">
											<gml:posList>35.67175888484251 139.73975957434558 26.592 35.67179925366643 139.73969688278376 26.592 35.67179977013231 139.73967715321203 25.093 35.67175888484251 139.73975957434558 26.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7d29806-85b9-47d8-a393-a56b1f07aee3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7d29806-85b9-47d8-a393-a56b1f07aee3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7d29806-85b9-47d8-a393-a56b1f07aee3">
											<gml:posList>35.67176807240977 139.73979769596983 31.226 35.6717711457881 139.73979730575846 31.226 35.67179323964198 139.73976405224838 31.226 35.67179292123457 139.73976028577914 31.226 35.67176807240977 139.73979769596983 31.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fdeeeca-d9dd-4911-95a6-7b914e7e4500">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fdeeeca-d9dd-4911-95a6-7b914e7e4500">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fdeeeca-d9dd-4911-95a6-7b914e7e4500">
											<gml:posList>35.671822169648145 139.73985166108267 31.226 35.67182184222116 139.73984788357578 31.226 35.6717711457881 139.73979730575846 31.226 35.67176807240977 139.73979769596983 31.226 35.671822169648145 139.73985166108267 31.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-174d20f8-cb9d-45e6-9c52-6b74b7e55a7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-174d20f8-cb9d-45e6-9c52-6b74b7e55a7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-174d20f8-cb9d-45e6-9c52-6b74b7e55a7c">
											<gml:posList>35.671843909099124 139.7398146963688 30.734 35.67179323964198 139.73976405224838 30.734 35.6717711457881 139.73979730575846 30.734 35.67182184222116 139.73984788357578 30.734 35.671843909099124 139.7398146963688 30.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0d0290f-8a3d-4440-b9d3-1388da9cbc10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0d0290f-8a3d-4440-b9d3-1388da9cbc10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0d0290f-8a3d-4440-b9d3-1388da9cbc10">
											<gml:posList>35.67176890336941 139.73976507483144 26.583 35.67175764972863 139.73978247507623 26.583 35.67176999908912 139.73979478850546 26.583 35.67179292123457 139.73976028577914 26.583 35.671844610041596 139.7398119560288 26.583 35.67186372385943 139.73978321292688 26.583 35.67185314253468 139.73977263171636 26.583 35.671858245142424 139.7397621095289 26.583 35.671799708492784 139.73970220664384 26.583 35.67176310286021 139.73975905023943 26.583 35.67176890336941 139.73976507483144 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b62bd89d-0e31-4d33-8be9-cfd0125d59bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b62bd89d-0e31-4d33-8be9-cfd0125d59bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b62bd89d-0e31-4d33-8be9-cfd0125d59bf">
											<gml:posList>35.67179292123457 139.73976028577914 31.226 35.67179323964198 139.73976405224838 31.226 35.671843909099124 139.7398146963688 31.226 35.67184698249465 139.7398143282506 31.226 35.67179292123457 139.73976028577914 31.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea867ddb-30e3-4c86-8537-af86455047d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea867ddb-30e3-4c86-8537-af86455047d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea867ddb-30e3-4c86-8537-af86455047d3">
											<gml:posList>35.671862192516684 139.73976128748356 26.85 35.67179925366643 139.73969688278376 26.85 35.671799708492784 139.73970220664384 26.85 35.671858245142424 139.7397621095289 26.85 35.671862192516684 139.73976128748356 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d18944bd-4698-470a-a93f-d97c839f5a7d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d18944bd-4698-470a-a93f-d97c839f5a7d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d18944bd-4698-470a-a93f-d97c839f5a7d">
											<gml:posList>35.67179977013231 139.73967715321203 25.093 35.67179925366643 139.73969688278376 26.592 35.671862192516684 139.73976128748356 26.592 35.67179977013231 139.73967715321203 25.093</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24ed2da4-a227-4390-bead-f66cc2fc0a14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24ed2da4-a227-4390-bead-f66cc2fc0a14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24ed2da4-a227-4390-bead-f66cc2fc0a14">
											<gml:posList>35.67184698249465 139.7398143282506 31.226 35.671843909099124 139.7398146963688 31.226 35.67182184222116 139.73984788357578 31.226 35.671822169648145 139.73985166108267 31.226 35.67184698249465 139.7398143282506 31.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f4df24d-c47a-4aea-9899-7893e320a84b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f4df24d-c47a-4aea-9899-7893e320a84b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f4df24d-c47a-4aea-9899-7893e320a84b">
											<gml:posList>35.671862192516684 139.73976128748356 26.592 35.67188294130242 139.73976023594574 25.093 35.67179977013231 139.73967715321203 25.093 35.671862192516684 139.73976128748356 26.592</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d04a05d6-0c25-483f-9c67-69c94f38b829">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d04a05d6-0c25-483f-9c67-69c94f38b829">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d04a05d6-0c25-483f-9c67-69c94f38b829">
											<gml:posList>35.67186372385943 139.73978321292688 26.85 35.671844610041596 139.7398119560288 26.85 35.67184698249465 139.7398143282506 26.85 35.67186801398693 139.7397826887371 26.85 35.67186372385943 139.73978321292688 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8945e910-d8eb-4913-89d3-9ac38adaab8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8945e910-d8eb-4913-89d3-9ac38adaab8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8945e910-d8eb-4913-89d3-9ac38adaab8d">
											<gml:posList>35.671857098905576 139.73977178756815 26.85 35.671862192516684 139.73976128748356 26.85 35.671858245142424 139.7397621095289 26.85 35.67185314253468 139.73977263171636 26.85 35.671857098905576 139.73977178756815 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33f5abff-4303-46b7-9dfd-f08b584b9008">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33f5abff-4303-46b7-9dfd-f08b584b9008">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33f5abff-4303-46b7-9dfd-f08b584b9008">
											<gml:posList>35.671857098905576 139.73977178756815 26.85 35.67185314253468 139.73977263171636 26.85 35.67186372385943 139.73978321292688 26.85 35.67186801398693 139.7397826887371 26.85 35.671857098905576 139.73977178756815 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8cab6bd-f0fe-44d9-a147-51543b356d8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8cab6bd-f0fe-44d9-a147-51543b356d8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8cab6bd-f0fe-44d9-a147-51543b356d8c">
											<gml:posList>35.67188294130242 139.73976023594574 25.093 35.671857098905576 139.73977178756815 26.787 35.67186801398693 139.7397826887371 26.787 35.67188294130242 139.73976023594574 25.093</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51379e4d-9e0e-43b2-8883-6accfe58808a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51379e4d-9e0e-43b2-8883-6accfe58808a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51379e4d-9e0e-43b2-8883-6accfe58808a">
											<gml:posList>35.671857098905576 139.73977178756815 26.787 35.67188294130242 139.73976023594574 25.093 35.671862192516684 139.73976128748356 26.592 35.671857098905576 139.73977178756815 26.787</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f75e1f8-a003-46ed-8d0e-7024601efa37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f75e1f8-a003-46ed-8d0e-7024601efa37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f75e1f8-a003-46ed-8d0e-7024601efa37">
											<gml:posList>35.67179323964198 139.73976405224838 31.226 35.67179323964198 139.73976405224838 30.734 35.671843909099124 139.7398146963688 30.734 35.671843909099124 139.7398146963688 31.226 35.67179323964198 139.73976405224838 31.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb4ed928-e53f-4f9d-8258-332223757f44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb4ed928-e53f-4f9d-8258-332223757f44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb4ed928-e53f-4f9d-8258-332223757f44">
											<gml:posList>35.67176807240977 139.73979769596983 26.85 35.67175339569885 139.73978305445542 26.85 35.67175339569885 139.73978305445542 26.817 35.67173899862606 139.73976868878117 25.093 35.67173899862606 139.73976868878117 9.47 35.671822169648145 139.73985166108267 9.47 35.671822169648145 139.73985166108267 31.226 35.67176807240977 139.73979769596983 31.226 35.67176807240977 139.73979769596983 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37e432bf-6f67-47c4-8c98-2cee16788d71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37e432bf-6f67-47c4-8c98-2cee16788d71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37e432bf-6f67-47c4-8c98-2cee16788d71">
											<gml:posList>35.67182184222116 139.73984788357578 31.226 35.67182184222116 139.73984788357578 30.734 35.6717711457881 139.73979730575846 30.734 35.6717711457881 139.73979730575846 31.226 35.67182184222116 139.73984788357578 31.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd076968-23d5-424e-b505-51b95ffe1876">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd076968-23d5-424e-b505-51b95ffe1876">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd076968-23d5-424e-b505-51b95ffe1876">
											<gml:posList>35.67188294130242 139.73976023594574 9.47 35.67179977013231 139.73967715321203 9.47 35.67179977013231 139.73967715321203 25.093 35.67188294130242 139.73976023594574 25.093 35.67188294130242 139.73976023594574 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f971590-19b7-40a5-bbed-919f3b7b5799">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f971590-19b7-40a5-bbed-919f3b7b5799">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f971590-19b7-40a5-bbed-919f3b7b5799">
											<gml:posList>35.67179977013231 139.73967715321203 9.47 35.67173899862606 139.73976868878117 9.47 35.67173899862606 139.73976868878117 25.093 35.67179977013231 139.73967715321203 25.093 35.67179977013231 139.73967715321203 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26c27ada-bc4c-4b82-bfff-c08863ddf31b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26c27ada-bc4c-4b82-bfff-c08863ddf31b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26c27ada-bc4c-4b82-bfff-c08863ddf31b">
											<gml:posList>35.67175888484251 139.73975957434558 26.85 35.67179925366643 139.73969688278376 26.85 35.67179925366643 139.73969688278376 26.592 35.67175888484251 139.73975957434558 26.592 35.67175888484251 139.73975957434558 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30bf8b97-f761-4cf6-b8d8-d483b5cabc56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30bf8b97-f761-4cf6-b8d8-d483b5cabc56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30bf8b97-f761-4cf6-b8d8-d483b5cabc56">
											<gml:posList>35.67179925366643 139.73969688278376 26.85 35.671862192516684 139.73976128748356 26.85 35.671862192516684 139.73976128748356 26.592 35.67179925366643 139.73969688278376 26.592 35.67179925366643 139.73969688278376 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47763556-e1af-413a-bff0-1548bb2c1dd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47763556-e1af-413a-bff0-1548bb2c1dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47763556-e1af-413a-bff0-1548bb2c1dd4">
											<gml:posList>35.67176310286021 139.73975905023943 26.85 35.67176310286021 139.73975905023943 26.583 35.671799708492784 139.73970220664384 26.583 35.671799708492784 139.73970220664384 26.85 35.67176310286021 139.73975905023943 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebfed059-bdb6-4831-9212-bd202e2a1179">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebfed059-bdb6-4831-9212-bd202e2a1179">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebfed059-bdb6-4831-9212-bd202e2a1179">
											<gml:posList>35.671799708492784 139.73970220664384 26.85 35.671799708492784 139.73970220664384 26.583 35.671858245142424 139.7397621095289 26.583 35.671858245142424 139.7397621095289 26.85 35.671799708492784 139.73970220664384 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecd8957e-0410-4b7c-810c-c5471baa70a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecd8957e-0410-4b7c-810c-c5471baa70a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecd8957e-0410-4b7c-810c-c5471baa70a4">
											<gml:posList>35.67176890336941 139.73976507483144 26.85 35.67176890336941 139.73976507483144 26.583 35.67176310286021 139.73975905023943 26.583 35.67176310286021 139.73975905023943 26.85 35.67176890336941 139.73976507483144 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f554885-1b94-48a5-8f6e-79cdab185e6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f554885-1b94-48a5-8f6e-79cdab185e6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f554885-1b94-48a5-8f6e-79cdab185e6f">
											<gml:posList>35.67176467632939 139.73976558790145 26.817 35.67176467632939 139.73976558790145 26.85 35.67175888484251 139.73975957434558 26.85 35.67175888484251 139.73975957434558 26.592 35.67176467632939 139.73976558790145 26.817</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05357926-3a18-49b5-8d04-fe6d8e892235">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05357926-3a18-49b5-8d04-fe6d8e892235">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05357926-3a18-49b5-8d04-fe6d8e892235">
											<gml:posList>35.671862192516684 139.73976128748356 26.85 35.671857098905576 139.73977178756815 26.85 35.671857098905576 139.73977178756815 26.787 35.671862192516684 139.73976128748356 26.592 35.671862192516684 139.73976128748356 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8531272c-faed-4fd1-987a-a1553538b364">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8531272c-faed-4fd1-987a-a1553538b364">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8531272c-faed-4fd1-987a-a1553538b364">
											<gml:posList>35.671858245142424 139.7397621095289 26.85 35.671858245142424 139.7397621095289 26.583 35.67185314253468 139.73977263171636 26.583 35.67185314253468 139.73977263171636 26.85 35.671858245142424 139.7397621095289 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49f55682-bfb5-4f99-8f72-af2c26bd376f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49f55682-bfb5-4f99-8f72-af2c26bd376f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49f55682-bfb5-4f99-8f72-af2c26bd376f">
											<gml:posList>35.67175764972863 139.73978247507623 26.85 35.67175764972863 139.73978247507623 26.583 35.67176890336941 139.73976507483144 26.583 35.67176890336941 139.73976507483144 26.85 35.67175764972863 139.73978247507623 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2cbd772e-3e3e-42d0-b6b5-7b737a98c1f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2cbd772e-3e3e-42d0-b6b5-7b737a98c1f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2cbd772e-3e3e-42d0-b6b5-7b737a98c1f3">
											<gml:posList>35.67175339569885 139.73978305445542 26.85 35.67176467632939 139.73976558790145 26.85 35.67176467632939 139.73976558790145 26.817 35.67175339569885 139.73978305445542 26.817 35.67175339569885 139.73978305445542 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8272c5cc-3090-4d84-bf17-7d3505988bef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8272c5cc-3090-4d84-bf17-7d3505988bef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8272c5cc-3090-4d84-bf17-7d3505988bef">
											<gml:posList>35.671857098905576 139.73977178756815 26.85 35.67186801398693 139.7397826887371 26.85 35.67186801398693 139.7397826887371 26.787 35.671857098905576 139.73977178756815 26.787 35.671857098905576 139.73977178756815 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8e102d7-fb84-4ea0-aa72-70d062eebc15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8e102d7-fb84-4ea0-aa72-70d062eebc15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8e102d7-fb84-4ea0-aa72-70d062eebc15">
											<gml:posList>35.67185314253468 139.73977263171636 26.85 35.67185314253468 139.73977263171636 26.583 35.67186372385943 139.73978321292688 26.583 35.67186372385943 139.73978321292688 26.85 35.67185314253468 139.73977263171636 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d65c6652-5541-4f41-bf58-c0598548f8d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d65c6652-5541-4f41-bf58-c0598548f8d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d65c6652-5541-4f41-bf58-c0598548f8d9">
											<gml:posList>35.67176999908912 139.73979478850546 26.85 35.67176807240977 139.73979769596983 26.85 35.67176807240977 139.73979769596983 31.226 35.67179292123457 139.73976028577914 31.226 35.67179292123457 139.73976028577914 26.583 35.67176999908912 139.73979478850546 26.583 35.67176999908912 139.73979478850546 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6859368-cef0-4f0e-8379-c630ec8d809e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6859368-cef0-4f0e-8379-c630ec8d809e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6859368-cef0-4f0e-8379-c630ec8d809e">
											<gml:posList>35.6717711457881 139.73979730575846 31.226 35.6717711457881 139.73979730575846 30.734 35.67179323964198 139.73976405224838 30.734 35.67179323964198 139.73976405224838 31.226 35.6717711457881 139.73979730575846 31.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57e48b67-24c1-4302-82ae-8291f2213ba3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57e48b67-24c1-4302-82ae-8291f2213ba3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57e48b67-24c1-4302-82ae-8291f2213ba3">
											<gml:posList>35.67179292123457 139.73976028577914 26.583 35.67179292123457 139.73976028577914 31.226 35.67184698249465 139.7398143282506 31.226 35.67184698249465 139.7398143282506 26.85 35.671844610041596 139.7398119560288 26.85 35.671844610041596 139.7398119560288 26.583 35.67179292123457 139.73976028577914 26.583</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c2d9f78-cdf1-4b90-8b9d-a42dc8dc3390">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c2d9f78-cdf1-4b90-8b9d-a42dc8dc3390">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c2d9f78-cdf1-4b90-8b9d-a42dc8dc3390">
											<gml:posList>35.67176999908912 139.73979478850546 26.85 35.67176999908912 139.73979478850546 26.583 35.67175764972863 139.73978247507623 26.583 35.67175764972863 139.73978247507623 26.85 35.67176999908912 139.73979478850546 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96f1e33d-5264-4f0f-b05b-9a9a51480260">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96f1e33d-5264-4f0f-b05b-9a9a51480260">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96f1e33d-5264-4f0f-b05b-9a9a51480260">
											<gml:posList>35.67186372385943 139.73978321292688 26.85 35.67186372385943 139.73978321292688 26.583 35.671844610041596 139.7398119560288 26.583 35.671844610041596 139.7398119560288 26.85 35.67186372385943 139.73978321292688 26.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8dc6121-0a87-436f-8aaa-ef92998c97d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8dc6121-0a87-436f-8aaa-ef92998c97d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8dc6121-0a87-436f-8aaa-ef92998c97d2">
											<gml:posList>35.671822169648145 139.73985166108267 31.226 35.671822169648145 139.73985166108267 9.47 35.67188294130242 139.73976023594574 9.47 35.67188294130242 139.73976023594574 25.093 35.67186801398693 139.7397826887371 26.787 35.67186801398693 139.7397826887371 26.85 35.67184698249465 139.7398143282506 26.85 35.67184698249465 139.7398143282506 31.226 35.671822169648145 139.73985166108267 31.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-708446ba-f6ee-470c-8bf8-21f053f5caeb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-708446ba-f6ee-470c-8bf8-21f053f5caeb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-708446ba-f6ee-470c-8bf8-21f053f5caeb">
											<gml:posList>35.671843909099124 139.7398146963688 31.226 35.671843909099124 139.7398146963688 30.734 35.67182184222116 139.73984788357578 30.734 35.67182184222116 139.73984788357578 31.226 35.671843909099124 139.7398146963688 31.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9989</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">127.08925</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>