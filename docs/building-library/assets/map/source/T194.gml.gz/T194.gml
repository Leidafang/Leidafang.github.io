<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_33517997-3be7-422d-8041-f4ba7bfb3305">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">15.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66895319024032 139.73873331153104 0 35.668803504458616 139.73857952839862 0 35.66871559568761 139.73870837376177 0 35.66886606655837 139.73886350365987 0 35.66895319024032 139.73873331153104 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895319024032 139.73873331153104 14.166 35.66886606655837 139.73886350365987 14.166 35.66871559568761 139.73870837376177 14.166 35.668803504458616 139.73857952839862 14.166 35.66895319024032 139.73873331153104 14.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895319024032 139.73873331153104 14.166 35.668803504458616 139.73857952839862 14.166 35.668803504458616 139.73857952839862 29.41 35.66895319024032 139.73873331153104 29.41 35.66895319024032 139.73873331153104 14.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668803504458616 139.73857952839862 14.166 35.66871559568761 139.73870837376177 14.166 35.66871559568761 139.73870837376177 29.41 35.668803504458616 139.73857952839862 29.41 35.668803504458616 139.73857952839862 14.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66871559568761 139.73870837376177 14.166 35.66886606655837 139.73886350365987 14.166 35.66886606655837 139.73886350365987 29.41 35.66871559568761 139.73870837376177 29.41 35.66871559568761 139.73870837376177 14.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66886606655837 139.73886350365987 14.166 35.66895319024032 139.73873331153104 14.166 35.66895319024032 139.73873331153104 29.41 35.66886606655837 139.73886350365987 29.41 35.66886606655837 139.73886350365987 14.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66895319024032 139.73873331153104 29.41 35.668803504458616 139.73857952839862 29.41 35.66871559568761 139.73870837376177 29.41 35.66886606655837 139.73886350365987 29.41 35.66895319024032 139.73873331153104 29.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f316dcd7-942d-4e01-ad1e-085c92f6ea8c"/>
							<gml:surfaceMember xlink:href="#poly-b240cf9b-5221-4e24-9947-ac28c836bcb7"/>
							<gml:surfaceMember xlink:href="#poly-675aca8c-4cf9-4f3c-90a4-52124cf9fce5"/>
							<gml:surfaceMember xlink:href="#poly-e4e999bd-9429-4f79-8ca0-dc25518aa3cf"/>
							<gml:surfaceMember xlink:href="#poly-cb9afc43-cf0e-43b2-873a-034f1dc14916"/>
							<gml:surfaceMember xlink:href="#poly-b6fa2ec1-2acf-44bf-a533-e23c9ee83b0c"/>
							<gml:surfaceMember xlink:href="#poly-f1c267dc-5c50-40da-a5fb-d05b900812c8"/>
							<gml:surfaceMember xlink:href="#poly-235c2eeb-5f76-41e4-98d0-4564cd6bc186"/>
							<gml:surfaceMember xlink:href="#poly-503beff3-0c6f-4a94-9b5a-0652c4565a44"/>
							<gml:surfaceMember xlink:href="#poly-da0f1046-4792-4f8c-93d0-205d9cb779f3"/>
							<gml:surfaceMember xlink:href="#poly-6ff975d0-2935-4512-8c85-2177928fbb0d"/>
							<gml:surfaceMember xlink:href="#poly-c9cdc376-2cbd-4ae0-9721-8bf9e0df5996"/>
							<gml:surfaceMember xlink:href="#poly-cb8ff31c-c8fb-4cb0-8e1a-1f9ceb4e2fcd"/>
							<gml:surfaceMember xlink:href="#poly-ea9512ff-4bad-494e-9206-e406b8145792"/>
							<gml:surfaceMember xlink:href="#poly-b7e446f7-62e5-4c09-a612-51dac57fe4cb"/>
							<gml:surfaceMember xlink:href="#poly-9af653ed-0c69-4471-be67-c67913bc4a43"/>
							<gml:surfaceMember xlink:href="#poly-77a8e3ba-4ab3-4a6a-814d-119c5b1928ee"/>
							<gml:surfaceMember xlink:href="#poly-1c64c60b-203b-4f63-9fa1-4fb2cc072fc0"/>
							<gml:surfaceMember xlink:href="#poly-07a5d3c3-75cd-46a0-8a10-d85023f919a0"/>
							<gml:surfaceMember xlink:href="#poly-fa005ce4-1590-44ab-9a8a-ddea008adaee"/>
							<gml:surfaceMember xlink:href="#poly-ec6fe5e1-5b85-4e51-b657-451456f4be38"/>
							<gml:surfaceMember xlink:href="#poly-d3b950e0-fc53-4f17-92c7-66eabe0c162a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_33517997-3be7-422d-8041-f4ba7bfb3305_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3d625b7-0144-44cb-bc34-62fc2b98db05">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66888906519968 139.73870865507234 29.397 35.66887084276182 139.7386899535201 29.397 35.66888440184524 139.73867010985006 29.397 35.66890262428614 139.73868881140095 29.397 35.66888906519968 139.73870865507234 29.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba07ba6a-4692-42c3-bffc-5cdf14ebc5e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba07ba6a-4692-42c3-bffc-5cdf14ebc5e1_0">
											<gml:posList>35.66888440184524 139.73867010985006 29.397 35.66888440184524 139.73867010985006 30.57 35.66890262428614 139.73868881140095 30.57 35.66890262428614 139.73868881140095 29.397 35.66888440184524 139.73867010985006 29.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34e0770c-3d11-441b-8bd6-40300ead2a8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34e0770c-3d11-441b-8bd6-40300ead2a8c_0">
											<gml:posList>35.66887084276182 139.7386899535201 29.397 35.66887084276182 139.7386899535201 30.57 35.66888440184524 139.73867010985006 30.57 35.66888440184524 139.73867010985006 29.397 35.66887084276182 139.7386899535201 29.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26023ed1-e00e-46b4-af8f-901c5724f53d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26023ed1-e00e-46b4-af8f-901c5724f53d_0">
											<gml:posList>35.66888440184524 139.73867010985006 30.57 35.66887084276182 139.7386899535201 30.57 35.66888906519968 139.73870865507234 30.57 35.66890262428614 139.73868881140095 30.57 35.66888440184524 139.73867010985006 30.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4134a71c-6130-4a13-a71b-52c4004b0689">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4134a71c-6130-4a13-a71b-52c4004b0689_0">
											<gml:posList>35.66890262428614 139.73868881140095 29.397 35.66890262428614 139.73868881140095 30.57 35.66888906519968 139.73870865507234 30.57 35.66888906519968 139.73870865507234 29.397 35.66890262428614 139.73868881140095 29.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-423d8e27-e7fc-4f47-824d-49d784f4a3bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-423d8e27-e7fc-4f47-824d-49d784f4a3bf_0">
											<gml:posList>35.66888906519968 139.73870865507234 29.397 35.66888906519968 139.73870865507234 30.57 35.66887084276182 139.7386899535201 30.57 35.66887084276182 139.7386899535201 29.397 35.66888906519968 139.73870865507234 29.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f316dcd7-942d-4e01-ad1e-085c92f6ea8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f316dcd7-942d-4e01-ad1e-085c92f6ea8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f316dcd7-942d-4e01-ad1e-085c92f6ea8c">
											<gml:posList>35.668953190240316 139.738733311531 14.166 35.66886606655837 139.73886350365987 14.166 35.66871559568762 139.73870837376177 14.166 35.668803504458616 139.73857952839862 14.166 35.668953190240316 139.738733311531 14.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b240cf9b-5221-4e24-9947-ac28c836bcb7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b240cf9b-5221-4e24-9947-ac28c836bcb7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b240cf9b-5221-4e24-9947-ac28c836bcb7">
											<gml:posList>35.66880349546227 139.73857955050133 18.802 35.66871559568762 139.73870837376177 18.802 35.66873455791671 139.73872792495374 18.802 35.668820779751385 139.73859731420745 18.802 35.66880349546227 139.73857955050133 18.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-675aca8c-4cf9-4f3c-90a4-52124cf9fce5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-675aca8c-4cf9-4f3c-90a4-52124cf9fce5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-675aca8c-4cf9-4f3c-90a4-52124cf9fce5">
											<gml:posList>35.668736739029804 139.73872765727552 29.76 35.668820980199825 139.73860004234362 29.76 35.66882073472621 139.73859736949086 29.76 35.66873455791671 139.73872792495374 29.76 35.668736739029804 139.73872765727552 29.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4e999bd-9429-4f79-8ca0-dc25518aa3cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4e999bd-9429-4f79-8ca0-dc25518aa3cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4e999bd-9429-4f79-8ca0-dc25518aa3cf">
											<gml:posList>35.6688308284483 139.73882467414182 29.76 35.668736739029804 139.73872765727552 29.76 35.66873455791671 139.73872792495374 29.76 35.66883101985186 139.73882736915144 29.76 35.6688308284483 139.73882467414182 29.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb9afc43-cf0e-43b2-873a-034f1dc14916">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb9afc43-cf0e-43b2-873a-034f1dc14916">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb9afc43-cf0e-43b2-873a-034f1dc14916">
											<gml:posList>35.66891722539756 139.73869883503264 29.397 35.668820980199825 139.73860004234362 29.397 35.668736739029804 139.73872765727552 29.397 35.6688308284483 139.73882467414182 29.397 35.66891722539756 139.73869883503264 29.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b6fa2ec1-2acf-44bf-a533-e23c9ee83b0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6fa2ec1-2acf-44bf-a533-e23c9ee83b0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6fa2ec1-2acf-44bf-a533-e23c9ee83b0c">
											<gml:posList>35.66891722539756 139.73869883503264 29.76 35.668919578049085 139.73869892062442 29.76 35.66882073472621 139.73859736949086 29.76 35.668820980199825 139.73860004234362 29.76 35.66891722539756 139.73869883503264 29.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1c267dc-5c50-40da-a5fb-d05b900812c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1c267dc-5c50-40da-a5fb-d05b900812c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1c267dc-5c50-40da-a5fb-d05b900812c8">
											<gml:posList>35.66889732146671 139.73873120137318 29.76 35.668919578049085 139.73869892062442 29.76 35.66891722539756 139.73869883503264 29.76 35.6688308284483 139.73882467414182 29.76 35.66883101985186 139.73882736915144 29.76 35.66889732146671 139.73873120137318 29.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-235c2eeb-5f76-41e4-98d0-4564cd6bc186">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-235c2eeb-5f76-41e4-98d0-4564cd6bc186">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-235c2eeb-5f76-41e4-98d0-4564cd6bc186">
											<gml:posList>35.66883101985186 139.73882736915144 29.76 35.66886606655837 139.73886350365987 22.416 35.66895316323385 139.73873335574714 22.416 35.66883101985186 139.73882736915144 29.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-503beff3-0c6f-4a94-9b5a-0652c4565a44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-503beff3-0c6f-4a94-9b5a-0652c4565a44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-503beff3-0c6f-4a94-9b5a-0652c4565a44">
											<gml:posList>35.66895316323385 139.73873335574714 22.416 35.668937583965096 139.73871737943222 25.801 35.66891698658858 139.73875053086448 25.525 35.66889732146671 139.73873120137318 29.76 35.66883101985186 139.73882736915144 29.76 35.66895316323385 139.73873335574714 22.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da0f1046-4792-4f8c-93d0-205d9cb779f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da0f1046-4792-4f8c-93d0-205d9cb779f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da0f1046-4792-4f8c-93d0-205d9cb779f3">
											<gml:posList>35.66889748362697 139.73873109072133 22.639 35.66891698658858 139.73875053086448 22.639 35.66893759297013 139.73871736837555 22.639 35.66891960505553 139.7386988764083 22.639 35.66889748362697 139.73873109072133 22.639</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ff975d0-2935-4512-8c85-2177928fbb0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ff975d0-2935-4512-8c85-2177928fbb0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ff975d0-2935-4512-8c85-2177928fbb0d">
											<gml:posList>35.6688308284483 139.73882467414182 29.397 35.668736739029804 139.73872765727552 29.397 35.668736739029804 139.73872765727552 29.76 35.6688308284483 139.73882467414182 29.76 35.6688308284483 139.73882467414182 29.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9cdc376-2cbd-4ae0-9721-8bf9e0df5996">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9cdc376-2cbd-4ae0-9721-8bf9e0df5996">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9cdc376-2cbd-4ae0-9721-8bf9e0df5996">
											<gml:posList>35.66871559568762 139.73870837376177 14.166 35.66871559568762 139.73870837376177 18.802 35.66880349546227 139.73857955050133 18.802 35.668803504458616 139.73857952839862 14.166 35.66871559568762 139.73870837376177 14.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb8ff31c-c8fb-4cb0-8e1a-1f9ceb4e2fcd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb8ff31c-c8fb-4cb0-8e1a-1f9ceb4e2fcd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb8ff31c-c8fb-4cb0-8e1a-1f9ceb4e2fcd">
											<gml:posList>35.668820980199825 139.73860004234362 29.397 35.66891722539756 139.73869883503264 29.397 35.66891722539756 139.73869883503264 29.76 35.668820980199825 139.73860004234362 29.76 35.668820980199825 139.73860004234362 29.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ea9512ff-4bad-494e-9206-e406b8145792">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea9512ff-4bad-494e-9206-e406b8145792">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea9512ff-4bad-494e-9206-e406b8145792">
											<gml:posList>35.668820779751385 139.73859731420745 18.802 35.66882073472621 139.73859736949086 29.76 35.668919578049085 139.73869892062442 29.76 35.66891960505553 139.7386988764083 22.639 35.66893759297013 139.73871736837555 22.639 35.668937583965096 139.73871737943222 25.801 35.66895316323385 139.73873335574714 22.416 35.668953190240316 139.738733311531 14.166 35.668803504458616 139.73857952839862 14.166 35.66880349546227 139.73857955050133 18.802 35.668820779751385 139.73859731420745 18.802</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7e446f7-62e5-4c09-a612-51dac57fe4cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7e446f7-62e5-4c09-a612-51dac57fe4cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7e446f7-62e5-4c09-a612-51dac57fe4cb">
											<gml:posList>35.66873455791671 139.73872792495374 29.76 35.66882073472621 139.73859736949086 29.76 35.668820779751385 139.73859731420745 18.802 35.66873455791671 139.73872792495374 18.802 35.66873455791671 139.73872792495374 29.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9af653ed-0c69-4471-be67-c67913bc4a43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9af653ed-0c69-4471-be67-c67913bc4a43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9af653ed-0c69-4471-be67-c67913bc4a43">
											<gml:posList>35.668736739029804 139.73872765727552 29.397 35.668820980199825 139.73860004234362 29.397 35.668820980199825 139.73860004234362 29.76 35.668736739029804 139.73872765727552 29.76 35.668736739029804 139.73872765727552 29.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77a8e3ba-4ab3-4a6a-814d-119c5b1928ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77a8e3ba-4ab3-4a6a-814d-119c5b1928ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77a8e3ba-4ab3-4a6a-814d-119c5b1928ee">
											<gml:posList>35.66889748362697 139.73873109072133 22.639 35.66891960505553 139.7386988764083 22.639 35.668919578049085 139.73869892062442 29.76 35.66889732146671 139.73873120137318 29.76 35.66889748362697 139.73873109072133 22.639</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c64c60b-203b-4f63-9fa1-4fb2cc072fc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c64c60b-203b-4f63-9fa1-4fb2cc072fc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c64c60b-203b-4f63-9fa1-4fb2cc072fc0">
											<gml:posList>35.66891698658858 139.73875053086448 25.525 35.668937583965096 139.73871737943222 25.801 35.66893759297013 139.73871736837555 22.639 35.66891698658858 139.73875053086448 22.639 35.66891698658858 139.73875053086448 25.525</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07a5d3c3-75cd-46a0-8a10-d85023f919a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07a5d3c3-75cd-46a0-8a10-d85023f919a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07a5d3c3-75cd-46a0-8a10-d85023f919a0">
											<gml:posList>35.66889748362697 139.73873109072133 22.639 35.66889732146671 139.73873120137318 29.76 35.66891698658858 139.73875053086448 25.525 35.66891698658858 139.73875053086448 22.639 35.66889748362697 139.73873109072133 22.639</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa005ce4-1590-44ab-9a8a-ddea008adaee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa005ce4-1590-44ab-9a8a-ddea008adaee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa005ce4-1590-44ab-9a8a-ddea008adaee">
											<gml:posList>35.66891722539756 139.73869883503264 29.397 35.6688308284483 139.73882467414182 29.397 35.6688308284483 139.73882467414182 29.76 35.66891722539756 139.73869883503264 29.76 35.66891722539756 139.73869883503264 29.397</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec6fe5e1-5b85-4e51-b657-451456f4be38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec6fe5e1-5b85-4e51-b657-451456f4be38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec6fe5e1-5b85-4e51-b657-451456f4be38">
											<gml:posList>35.66871559568762 139.73870837376177 14.166 35.66886606655837 139.73886350365987 14.166 35.66886606655837 139.73886350365987 22.416 35.66883101985186 139.73882736915144 29.76 35.66873455791671 139.73872792495374 29.76 35.66873455791671 139.73872792495374 18.802 35.66871559568762 139.73870837376177 18.802 35.66871559568762 139.73870837376177 14.166</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3b950e0-fc53-4f17-92c7-66eabe0c162a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3b950e0-fc53-4f17-92c7-66eabe0c162a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3b950e0-fc53-4f17-92c7-66eabe0c162a">
											<gml:posList>35.66895316323385 139.73873335574714 22.416 35.66886606655837 139.73886350365987 22.416 35.66886606655837 139.73886350365987 14.166 35.668953190240316 139.738733311531 14.166 35.66895316323385 139.73873335574714 22.416</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5059</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">330.969</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>