<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3491ab20-6083-4c27-b5b6-7b476605dc40">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">3.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67407965847512 139.74689874558234 0 35.67408480765758 139.7469271302308 0 35.67416541065933 139.74690517072642 0 35.674160252458016 139.74687678606057 0 35.674155103263764 139.74684840138872 0 35.674074509286 139.7468703609376 0 35.67407965847512 139.74689874558234 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67407965847512 139.74689874558234 20.252 35.674074509286 139.7468703609376 20.252 35.674155103263764 139.74684840138872 20.252 35.674160252458016 139.74687678606057 20.252 35.67416541065933 139.74690517072642 20.252 35.67408480765758 139.7469271302308 20.252 35.67407965847512 139.74689874558234 20.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67407965847512 139.74689874558234 20.252 35.67408480765758 139.7469271302308 20.252 35.67408480765758 139.7469271302308 23.51 35.67407965847512 139.74689874558234 23.51 35.67407965847512 139.74689874558234 20.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67408480765758 139.7469271302308 20.252 35.67416541065933 139.74690517072642 20.252 35.67416541065933 139.74690517072642 23.51 35.67408480765758 139.7469271302308 23.51 35.67408480765758 139.7469271302308 20.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67416541065933 139.74690517072642 20.252 35.674160252458016 139.74687678606057 20.252 35.674160252458016 139.74687678606057 23.51 35.67416541065933 139.74690517072642 23.51 35.67416541065933 139.74690517072642 20.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674160252458016 139.74687678606057 20.252 35.674155103263764 139.74684840138872 20.252 35.674155103263764 139.74684840138872 23.51 35.674160252458016 139.74687678606057 23.51 35.674160252458016 139.74687678606057 20.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674155103263764 139.74684840138872 20.252 35.674074509286 139.7468703609376 20.252 35.674074509286 139.7468703609376 23.51 35.674155103263764 139.74684840138872 23.51 35.674155103263764 139.74684840138872 20.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674074509286 139.7468703609376 20.252 35.67407965847512 139.74689874558234 20.252 35.67407965847512 139.74689874558234 23.51 35.674074509286 139.7468703609376 23.51 35.674074509286 139.7468703609376 20.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67407965847512 139.74689874558234 23.51 35.67408480765758 139.7469271302308 23.51 35.67416541065933 139.74690517072642 23.51 35.674160252458016 139.74687678606057 23.51 35.674155103263764 139.74684840138872 23.51 35.674074509286 139.7468703609376 23.51 35.67407965847512 139.74689874558234 23.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e9243f28-1db5-4392-b9de-7619d1b0572c"/>
							<gml:surfaceMember xlink:href="#poly-63190270-087d-4522-a323-dd13e7cfa08b"/>
							<gml:surfaceMember xlink:href="#poly-e65405ca-7090-408b-a541-578501b345f2"/>
							<gml:surfaceMember xlink:href="#poly-7c53b9e9-15dc-4137-85f6-780196aa7709"/>
							<gml:surfaceMember xlink:href="#poly-b9c8fa65-4792-4704-94ad-a9a71210d320"/>
							<gml:surfaceMember xlink:href="#poly-778ecb33-3553-4e4b-8fd5-d25d80c2c055"/>
							<gml:surfaceMember xlink:href="#poly-221198ec-8e97-4cd8-8a52-01698b064ff0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e9243f28-1db5-4392-b9de-7619d1b0572c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9243f28-1db5-4392-b9de-7619d1b0572c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9243f28-1db5-4392-b9de-7619d1b0572c">
											<gml:posList>35.67415510326374 139.74684840138872 20.252 35.67416541065931 139.74690517072642 20.252 35.674084807657565 139.7469271302308 20.252 35.674074509286 139.74687036093758 20.252 35.67415510326374 139.74684840138872 20.252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63190270-087d-4522-a323-dd13e7cfa08b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63190270-087d-4522-a323-dd13e7cfa08b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63190270-087d-4522-a323-dd13e7cfa08b">
											<gml:posList>35.67416025245802 139.74687678606057 23.421 35.67415510326374 139.74684840138872 22.088 35.674074509286 139.74687036093758 22.088 35.67407965847512 139.74689874558234 23.421 35.67416025245802 139.74687678606057 23.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e65405ca-7090-408b-a541-578501b345f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e65405ca-7090-408b-a541-578501b345f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e65405ca-7090-408b-a541-578501b345f2">
											<gml:posList>35.674084807657565 139.7469271302308 22.088 35.67416541065931 139.74690517072642 22.088 35.67416025245802 139.74687678606057 23.421 35.67407965847512 139.74689874558234 23.421 35.674084807657565 139.7469271302308 22.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c53b9e9-15dc-4137-85f6-780196aa7709">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c53b9e9-15dc-4137-85f6-780196aa7709">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c53b9e9-15dc-4137-85f6-780196aa7709">
											<gml:posList>35.67415510326374 139.74684840138872 22.088 35.67415510326374 139.74684840138872 20.252 35.674074509286 139.74687036093758 20.252 35.674074509286 139.74687036093758 22.088 35.67415510326374 139.74684840138872 22.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b9c8fa65-4792-4704-94ad-a9a71210d320">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b9c8fa65-4792-4704-94ad-a9a71210d320">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b9c8fa65-4792-4704-94ad-a9a71210d320">
											<gml:posList>35.67416025245802 139.74687678606057 23.421 35.67416541065931 139.74690517072642 22.088 35.67416541065931 139.74690517072642 20.252 35.67415510326374 139.74684840138872 20.252 35.67415510326374 139.74684840138872 22.088 35.67416025245802 139.74687678606057 23.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-778ecb33-3553-4e4b-8fd5-d25d80c2c055">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-778ecb33-3553-4e4b-8fd5-d25d80c2c055">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-778ecb33-3553-4e4b-8fd5-d25d80c2c055">
											<gml:posList>35.67407965847512 139.74689874558234 23.421 35.674074509286 139.74687036093758 22.088 35.674074509286 139.74687036093758 20.252 35.674084807657565 139.7469271302308 20.252 35.674084807657565 139.7469271302308 22.088 35.67407965847512 139.74689874558234 23.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-221198ec-8e97-4cd8-8a52-01698b064ff0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-221198ec-8e97-4cd8-8a52-01698b064ff0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-221198ec-8e97-4cd8-8a52-01698b064ff0">
											<gml:posList>35.674084807657565 139.7469271302308 22.088 35.674084807657565 139.7469271302308 20.252 35.67416541065931 139.74690517072642 20.252 35.67416541065931 139.74690517072642 22.088 35.674084807657565 139.7469271302308 22.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4567</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">224</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>