<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_361833db-234b-4d06-869f-b9cf805e7d74">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">120.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>29</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>2</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67404816051614 139.7407342427091 0 35.67400714716797 139.74073307493933 0 35.674007837929764 139.7406936372107 0 35.673928434342606 139.74069145333814 0 35.673928840918606 139.74066927099747 0 35.673823918934445 139.74066638756355 0 35.67382351236743 139.7406885809219 0 35.67372191652021 139.74068579304273 0 35.67371912196793 139.74083782122642 0 35.67371361039981 139.74113794484163 0 35.67373380155074 139.7411384739572 0 35.67373342953087 139.7411588113994 0 35.67373189740459 139.74124154205705 0 35.67425182903915 139.74125584690645 0 35.674383423174085 139.7412594627216 0 35.67438922408581 139.7409483778359 0 35.67425752176932 139.74094475160908 0 35.67424274796505 139.74094434885725 0 35.67424441692804 139.74085227192313 0 35.67424685574331 139.74071819419214 0 35.674087498755235 139.74071384911932 0 35.674087289920706 139.74073531323515 0 35.67404816051614 139.7407342427091 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67404816051614 139.7407342427091 9.47 35.674087289920706 139.74073531323515 9.47 35.674087498755235 139.74071384911932 9.47 35.67424685574331 139.74071819419214 9.47 35.67424441692804 139.74085227192313 9.47 35.67424274796505 139.74094434885725 9.47 35.67425752176932 139.74094475160908 9.47 35.67438922408581 139.7409483778359 9.47 35.674383423174085 139.7412594627216 9.47 35.67425182903915 139.74125584690645 9.47 35.67373189740459 139.74124154205705 9.47 35.67373342953087 139.7411588113994 9.47 35.67373380155074 139.7411384739572 9.47 35.67371361039981 139.74113794484163 9.47 35.67371912196793 139.74083782122642 9.47 35.67372191652021 139.74068579304273 9.47 35.67382351236743 139.7406885809219 9.47 35.673823918934445 139.74066638756355 9.47 35.673928840918606 139.74066927099747 9.47 35.673928434342606 139.74069145333814 9.47 35.674007837929764 139.7406936372107 9.47 35.67400714716797 139.74073307493933 9.47 35.67404816051614 139.7407342427091 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67404816051614 139.7407342427091 9.47 35.67400714716797 139.74073307493933 9.47 35.67400714716797 139.74073307493933 84.76 35.67404816051614 139.7407342427091 84.76 35.67404816051614 139.7407342427091 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67400714716797 139.74073307493933 9.47 35.674007837929764 139.7406936372107 9.47 35.674007837929764 139.7406936372107 84.76 35.67400714716797 139.74073307493933 84.76 35.67400714716797 139.74073307493933 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674007837929764 139.7406936372107 9.47 35.673928434342606 139.74069145333814 9.47 35.673928434342606 139.74069145333814 84.76 35.674007837929764 139.7406936372107 84.76 35.674007837929764 139.7406936372107 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673928434342606 139.74069145333814 9.47 35.673928840918606 139.74066927099747 9.47 35.673928840918606 139.74066927099747 84.76 35.673928434342606 139.74069145333814 84.76 35.673928434342606 139.74069145333814 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673928840918606 139.74066927099747 9.47 35.673823918934445 139.74066638756355 9.47 35.673823918934445 139.74066638756355 84.76 35.673928840918606 139.74066927099747 84.76 35.673928840918606 139.74066927099747 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673823918934445 139.74066638756355 9.47 35.67382351236743 139.7406885809219 9.47 35.67382351236743 139.7406885809219 84.76 35.673823918934445 139.74066638756355 84.76 35.673823918934445 139.74066638756355 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67382351236743 139.7406885809219 9.47 35.67372191652021 139.74068579304273 9.47 35.67372191652021 139.74068579304273 84.76 35.67382351236743 139.7406885809219 84.76 35.67382351236743 139.7406885809219 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67372191652021 139.74068579304273 9.47 35.67371912196793 139.74083782122642 9.47 35.67371912196793 139.74083782122642 84.76 35.67372191652021 139.74068579304273 84.76 35.67372191652021 139.74068579304273 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67371912196793 139.74083782122642 9.47 35.67371361039981 139.74113794484163 9.47 35.67371361039981 139.74113794484163 84.76 35.67371912196793 139.74083782122642 84.76 35.67371912196793 139.74083782122642 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67371361039981 139.74113794484163 9.47 35.67373380155074 139.7411384739572 9.47 35.67373380155074 139.7411384739572 84.76 35.67371361039981 139.74113794484163 84.76 35.67371361039981 139.74113794484163 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67373380155074 139.7411384739572 9.47 35.67373342953087 139.7411588113994 9.47 35.67373342953087 139.7411588113994 84.76 35.67373380155074 139.7411384739572 84.76 35.67373380155074 139.7411384739572 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67373342953087 139.7411588113994 9.47 35.67373189740459 139.74124154205705 9.47 35.67373189740459 139.74124154205705 84.76 35.67373342953087 139.7411588113994 84.76 35.67373342953087 139.7411588113994 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67373189740459 139.74124154205705 9.47 35.67425182903915 139.74125584690645 9.47 35.67425182903915 139.74125584690645 84.76 35.67373189740459 139.74124154205705 84.76 35.67373189740459 139.74124154205705 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67425182903915 139.74125584690645 9.47 35.674383423174085 139.7412594627216 9.47 35.674383423174085 139.7412594627216 84.76 35.67425182903915 139.74125584690645 84.76 35.67425182903915 139.74125584690645 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674383423174085 139.7412594627216 9.47 35.67438922408581 139.7409483778359 9.47 35.67438922408581 139.7409483778359 84.76 35.674383423174085 139.7412594627216 84.76 35.674383423174085 139.7412594627216 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67438922408581 139.7409483778359 9.47 35.67425752176932 139.74094475160908 9.47 35.67425752176932 139.74094475160908 84.76 35.67438922408581 139.7409483778359 84.76 35.67438922408581 139.7409483778359 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67425752176932 139.74094475160908 9.47 35.67424274796505 139.74094434885725 9.47 35.67424274796505 139.74094434885725 84.76 35.67425752176932 139.74094475160908 84.76 35.67425752176932 139.74094475160908 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67424274796505 139.74094434885725 9.47 35.67424441692804 139.74085227192313 9.47 35.67424441692804 139.74085227192313 84.76 35.67424274796505 139.74094434885725 84.76 35.67424274796505 139.74094434885725 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67424441692804 139.74085227192313 9.47 35.67424685574331 139.74071819419214 9.47 35.67424685574331 139.74071819419214 84.76 35.67424441692804 139.74085227192313 84.76 35.67424441692804 139.74085227192313 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67424685574331 139.74071819419214 9.47 35.674087498755235 139.74071384911932 9.47 35.674087498755235 139.74071384911932 84.76 35.67424685574331 139.74071819419214 84.76 35.67424685574331 139.74071819419214 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674087498755235 139.74071384911932 9.47 35.674087289920706 139.74073531323515 9.47 35.674087289920706 139.74073531323515 84.76 35.674087498755235 139.74071384911932 84.76 35.674087498755235 139.74071384911932 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674087289920706 139.74073531323515 9.47 35.67404816051614 139.7407342427091 9.47 35.67404816051614 139.7407342427091 84.76 35.674087289920706 139.74073531323515 84.76 35.674087289920706 139.74073531323515 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67404816051614 139.7407342427091 84.76 35.67400714716797 139.74073307493933 84.76 35.674007837929764 139.7406936372107 84.76 35.673928434342606 139.74069145333814 84.76 35.673928840918606 139.74066927099747 84.76 35.673823918934445 139.74066638756355 84.76 35.67382351236743 139.7406885809219 84.76 35.67372191652021 139.74068579304273 84.76 35.67371912196793 139.74083782122642 84.76 35.67371361039981 139.74113794484163 84.76 35.67373380155074 139.7411384739572 84.76 35.67373342953087 139.7411588113994 84.76 35.67373189740459 139.74124154205705 84.76 35.67425182903915 139.74125584690645 84.76 35.674383423174085 139.7412594627216 84.76 35.67438922408581 139.7409483778359 84.76 35.67425752176932 139.74094475160908 84.76 35.67424274796505 139.74094434885725 84.76 35.67424441692804 139.74085227192313 84.76 35.67424685574331 139.74071819419214 84.76 35.674087498755235 139.74071384911932 84.76 35.674087289920706 139.74073531323515 84.76 35.67404816051614 139.7407342427091 84.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-902a467c-06f2-4d74-bea8-600bbb22cf7b"/>
							<gml:surfaceMember xlink:href="#poly-3b3e1e30-86c4-43ea-ae91-8707df7f3367"/>
							<gml:surfaceMember xlink:href="#poly-0f5eac23-f1bc-43f4-a51d-a6bd7c97c39b"/>
							<gml:surfaceMember xlink:href="#poly-d8be0c82-ee7f-405e-822d-cbad36792498"/>
							<gml:surfaceMember xlink:href="#poly-19518967-6277-4f3c-be8f-8e5ff52980f6"/>
							<gml:surfaceMember xlink:href="#poly-8d8e7da9-cce6-4fc7-87b6-6e4d5743119a"/>
							<gml:surfaceMember xlink:href="#poly-5fc77870-0740-43c5-936c-0b9883701f67"/>
							<gml:surfaceMember xlink:href="#poly-0520e7f9-0e90-4c90-a528-640db294db49"/>
							<gml:surfaceMember xlink:href="#poly-7731a8b1-2393-46be-be7a-541a17ae1d63"/>
							<gml:surfaceMember xlink:href="#poly-25e430f3-f915-45f0-ae95-fb8a5d6cc3f6"/>
							<gml:surfaceMember xlink:href="#poly-9e723068-0208-41c4-8cbc-749da78f8e66"/>
							<gml:surfaceMember xlink:href="#poly-0d96277f-d30a-4cf1-9489-6695c19b2ce6"/>
							<gml:surfaceMember xlink:href="#poly-3be9b886-b54b-4db3-9eab-ab3eb5e2e818"/>
							<gml:surfaceMember xlink:href="#poly-73ca27a0-788c-4a50-921c-9783f8380985"/>
							<gml:surfaceMember xlink:href="#poly-42405789-5ad1-4e38-b36a-c49c9456a665"/>
							<gml:surfaceMember xlink:href="#poly-24de30af-96b6-4aef-baf4-871ca2b5b4af"/>
							<gml:surfaceMember xlink:href="#poly-ba7a2594-2618-4c4c-9a53-ac4249ae21d2"/>
							<gml:surfaceMember xlink:href="#poly-c47bf00e-840f-4bf9-b1aa-d0879c4eeed8"/>
							<gml:surfaceMember xlink:href="#poly-1031e4c9-c8da-4f5a-afb4-d5876b10092d"/>
							<gml:surfaceMember xlink:href="#poly-ad0fa97e-bac0-49b7-8b13-ec5bad38e0bf"/>
							<gml:surfaceMember xlink:href="#poly-e32c4857-9003-43d7-8592-d3f08bd54616"/>
							<gml:surfaceMember xlink:href="#poly-3666bd16-bd3b-4bbd-b430-7cf83fb505f0"/>
							<gml:surfaceMember xlink:href="#poly-98814f39-d862-4f1d-a1e1-cf612ac09d37"/>
							<gml:surfaceMember xlink:href="#poly-25bf3d8c-73c6-40c4-9d02-b9b9dd922ab2"/>
							<gml:surfaceMember xlink:href="#poly-e3407f50-1a2d-4ebf-8cc4-0142a4289f40"/>
							<gml:surfaceMember xlink:href="#poly-4f2e8fd9-5ddb-46e8-be6c-febc703cea7b"/>
							<gml:surfaceMember xlink:href="#poly-9517df55-f3be-4a16-a4d6-52e9166ad268"/>
							<gml:surfaceMember xlink:href="#poly-ee38e548-a7d7-4e5b-ad69-f5f119d29f63"/>
							<gml:surfaceMember xlink:href="#poly-0ebf6d5a-0965-46a8-ad6c-d0c9977b1f39"/>
							<gml:surfaceMember xlink:href="#poly-11736b93-8730-48e1-bf1c-7c28bb432090"/>
							<gml:surfaceMember xlink:href="#poly-3ffd3fd8-c634-4c8b-ab06-57595cba325b"/>
							<gml:surfaceMember xlink:href="#poly-c2660ffe-d9a8-483c-ad68-5331f4b79e25"/>
							<gml:surfaceMember xlink:href="#poly-2b311ab9-76f8-42e5-bbc8-9fa7ad46c78a"/>
							<gml:surfaceMember xlink:href="#poly-40c805f5-e140-4526-9ea0-397273c56f96"/>
							<gml:surfaceMember xlink:href="#poly-51f833b6-b9ae-46bc-be7e-bdbb5c9302c4"/>
							<gml:surfaceMember xlink:href="#poly-5a67fe58-8e29-476b-9b07-b8f4e8904eb9"/>
							<gml:surfaceMember xlink:href="#poly-14630e95-2d52-4fad-b22f-790fcb212c93"/>
							<gml:surfaceMember xlink:href="#poly-4f2d653c-0a05-471f-a3cd-49c61f833240"/>
							<gml:surfaceMember xlink:href="#poly-d814f6ae-2fd7-4622-8580-b5b8a1bf034c"/>
							<gml:surfaceMember xlink:href="#poly-01c0645f-f672-4ad3-968e-a4b0d85cde94"/>
							<gml:surfaceMember xlink:href="#poly-8d6decb7-1c01-4809-9d16-0eaf317b4c99"/>
							<gml:surfaceMember xlink:href="#poly-1b752534-0ea5-4e6b-96c2-76e813cf77b1"/>
							<gml:surfaceMember xlink:href="#poly-acfe2ec1-02b2-448f-8b3d-50a2a5bfab65"/>
							<gml:surfaceMember xlink:href="#poly-cb5bf9f2-dfa2-49f3-ba0f-ffe8bf3ca65b"/>
							<gml:surfaceMember xlink:href="#poly-7b0e57aa-6907-4353-91e2-fd8e4773d770"/>
							<gml:surfaceMember xlink:href="#poly-69997bce-682d-4b41-ac34-cab759bcaa54"/>
							<gml:surfaceMember xlink:href="#poly-1c26e221-633c-40cd-8dff-417feec41f00"/>
							<gml:surfaceMember xlink:href="#poly-b675089c-6300-4d65-9db2-d368bf175bd5"/>
							<gml:surfaceMember xlink:href="#poly-d9b30619-86e6-43cd-b776-f668b7fca6a1"/>
							<gml:surfaceMember xlink:href="#poly-2a5346a2-0ee9-4784-aa7d-4754822d75f7"/>
							<gml:surfaceMember xlink:href="#poly-bc35638d-e8ae-4187-ac94-b34aff155e5f"/>
							<gml:surfaceMember xlink:href="#poly-9a9f2922-ae69-4e86-b4c5-e4f7ea6c7d22"/>
							<gml:surfaceMember xlink:href="#poly-e8774c6b-ddcf-4026-afca-91e1766c3d4a"/>
							<gml:surfaceMember xlink:href="#poly-ab2efb59-67ff-49e9-af6f-0172f608204e"/>
							<gml:surfaceMember xlink:href="#poly-aa9c0160-3a27-4246-b227-7e8d49b39245"/>
							<gml:surfaceMember xlink:href="#poly-cf676674-a3d6-4919-9578-cf1fdcae302e"/>
							<gml:surfaceMember xlink:href="#poly-5f52fab1-8c62-46eb-82dc-177aa92df796"/>
							<gml:surfaceMember xlink:href="#poly-6d1ca6fe-34da-4276-954c-444379139517"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-902a467c-06f2-4d74-bea8-600bbb22cf7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-902a467c-06f2-4d74-bea8-600bbb22cf7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-902a467c-06f2-4d74-bea8-600bbb22cf7b">
											<gml:posList>35.67382352138113 139.74068858091147 9.47 35.673823918934424 139.74066638756355 9.47 35.67392884091858 139.74066927099747 9.47 35.67392843435109 139.74069146438487 9.47 35.67400783792978 139.7406936372107 9.47 35.67400714716793 139.74073307493933 9.47 35.67408728992067 139.74073531323515 9.47 35.67408749875521 139.7407138491193 9.47 35.674246855743306 139.74071819419214 9.47 35.67424274796503 139.74094434885725 9.47 35.67438922408581 139.74094837783588 9.47 35.674383423174085 139.7412594627216 9.47 35.673731897404565 139.74124154205705 9.47 35.67373380155073 139.74113847395722 9.47 35.67371361039982 139.74113794484163 9.47 35.673721916520186 139.74068579304273 9.47 35.67382352138113 139.74068858091147 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3b3e1e30-86c4-43ea-ae91-8707df7f3367">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b3e1e30-86c4-43ea-ae91-8707df7f3367">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b3e1e30-86c4-43ea-ae91-8707df7f3367">
											<gml:posList>35.67371912196791 139.74083782122642 125.19 35.67371361039982 139.74113794484163 125.19 35.67376748733755 139.74111688305476 125.19 35.673772625600655 139.7408588918837 125.19 35.673789797454 139.74085981104767 125.19 35.67371912196791 139.74083782122642 125.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0f5eac23-f1bc-43f4-a51d-a6bd7c97c39b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f5eac23-f1bc-43f4-a51d-a6bd7c97c39b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f5eac23-f1bc-43f4-a51d-a6bd7c97c39b">
											<gml:posList>35.67376748733755 139.74111688305476 128.969 35.67382226786611 139.741051666405 128.969 35.67382427073312 139.7409599983004 128.969 35.673772625600655 139.7408588918837 128.969 35.67376748733755 139.74111688305476 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d8be0c82-ee7f-405e-822d-cbad36792498">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8be0c82-ee7f-405e-822d-cbad36792498">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8be0c82-ee7f-405e-822d-cbad36792498">
											<gml:posList>35.673823918934424 139.74066638756355 28.683 35.67382352138113 139.74068858091147 28.683 35.67392843435109 139.74069146438487 28.683 35.67392884091858 139.74066927099747 28.683 35.673823918934424 139.74066638756355 28.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-19518967-6277-4f3c-be8f-8e5ff52980f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19518967-6277-4f3c-be8f-8e5ff52980f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19518967-6277-4f3c-be8f-8e5ff52980f6">
											<gml:posList>35.67382427073312 139.7409599983004 128.969 35.67399856452599 139.74096572957745 128.969 35.67402062049112 139.74094142338382 128.969 35.673789797454 139.74085981104767 128.969 35.673772625600655 139.7408588918837 128.969 35.67382427073312 139.7409599983004 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d8e7da9-cce6-4fc7-87b6-6e4d5743119a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d8e7da9-cce6-4fc7-87b6-6e4d5743119a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d8e7da9-cce6-4fc7-87b6-6e4d5743119a">
											<gml:posList>35.67400714716793 139.74073307493933 76.4 35.67400783792978 139.7406936372107 76.4 35.673721916520186 139.74068579304273 76.4 35.67371912196791 139.74083782122642 76.4 35.674086195689654 139.74084794736714 76.4 35.67408728992067 139.74073531323515 76.4 35.67400714716793 139.74073307493933 76.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5fc77870-0740-43c5-936c-0b9883701f67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fc77870-0740-43c5-936c-0b9883701f67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fc77870-0740-43c5-936c-0b9883701f67">
											<gml:posList>35.673996552641256 139.74105739789158 129.7 35.67399856452599 139.74096572957745 129.7 35.67382427073312 139.7409599983004 129.7 35.67382226786611 139.741051666405 129.7 35.673996552641256 139.74105739789158 129.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0520e7f9-0e90-4c90-a528-640db294db49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0520e7f9-0e90-4c90-a528-640db294db49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0520e7f9-0e90-4c90-a528-640db294db49">
											<gml:posList>35.67424441692803 139.74085227192313 125.19 35.67371912196791 139.74083782122642 125.19 35.673789797454 139.74085981104767 125.19 35.67423140460374 139.74086855885625 125.19 35.67422769636892 139.74113422737722 125.19 35.67376743611876 139.7411323927173 125.19 35.67376748733755 139.74111688305476 125.19 35.67371361039982 139.74113794484163 125.19 35.67373380155073 139.74113847395722 125.19 35.67373342953087 139.7411588113994 125.19 35.67425346419796 139.74116639914374 125.19 35.67425752176932 139.74094475160905 125.19 35.67424274796503 139.74094434885725 125.19 35.67424441692803 139.74085227192313 125.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7731a8b1-2393-46be-be7a-541a17ae1d63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7731a8b1-2393-46be-be7a-541a17ae1d63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7731a8b1-2393-46be-be7a-541a17ae1d63">
											<gml:posList>35.67425182903912 139.74125584690643 76.4 35.67425346419796 139.74116639914374 76.4 35.67373342953087 139.7411588113994 76.4 35.673731897404565 139.74124154205705 76.4 35.67425182903912 139.74125584690643 76.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25e430f3-f915-45f0-ae95-fb8a5d6cc3f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25e430f3-f915-45f0-ae95-fb8a5d6cc3f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25e430f3-f915-45f0-ae95-fb8a5d6cc3f6">
											<gml:posList>35.67411605809036 139.74095353112438 128.969 35.674161857846784 139.74095485919455 128.969 35.67423140460374 139.74086855885625 128.969 35.67411467181265 139.74094417610422 128.969 35.6741122866913 139.74106631198333 128.969 35.67401901056047 139.74106356927427 128.969 35.673996552641256 139.74105739789158 128.969 35.67382226786611 139.741051666405 128.969 35.67376748733755 139.74111688305476 128.969 35.67376743611876 139.7411323927173 128.969 35.67422769636892 139.74113422737722 128.969 35.67416087761136 139.74100481386515 128.969 35.6741146271611 139.74100347523876 128.969 35.67411605809036 139.74095353112438 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e723068-0208-41c4-8cbc-749da78f8e66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e723068-0208-41c4-8cbc-749da78f8e66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e723068-0208-41c4-8cbc-749da78f8e66">
											<gml:posList>35.67401901056047 139.74106356927427 125.19 35.67402062049112 139.74094142338382 125.19 35.67399856452599 139.74096572957745 125.19 35.673996552641256 139.74105739789158 125.19 35.67401901056047 139.74106356927427 125.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d96277f-d30a-4cf1-9489-6695c19b2ce6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d96277f-d30a-4cf1-9489-6695c19b2ce6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d96277f-d30a-4cf1-9489-6695c19b2ce6">
											<gml:posList>35.67402062049112 139.74094142338382 128.969 35.67411467181265 139.74094417610422 128.969 35.67423140460374 139.74086855885625 128.969 35.673789797454 139.74085981104767 128.969 35.67402062049112 139.74094142338382 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3be9b886-b54b-4db3-9eab-ab3eb5e2e818">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3be9b886-b54b-4db3-9eab-ab3eb5e2e818">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3be9b886-b54b-4db3-9eab-ab3eb5e2e818">
											<gml:posList>35.67411467181265 139.74094417610422 128.692 35.67402062049112 139.74094142338382 128.692 35.67401901056047 139.74106356927427 128.692 35.6741122866913 139.74106631198333 128.692 35.67411467181265 139.74094417610422 128.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-73ca27a0-788c-4a50-921c-9783f8380985">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73ca27a0-788c-4a50-921c-9783f8380985">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73ca27a0-788c-4a50-921c-9783f8380985">
											<gml:posList>35.67411605809036 139.74095353112438 129.7 35.6741146271611 139.74100347523876 129.7 35.67416087761136 139.74100481386515 129.7 35.674161857846784 139.74095485919455 129.7 35.67411605809036 139.74095353112438 129.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42405789-5ad1-4e38-b36a-c49c9456a665">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42405789-5ad1-4e38-b36a-c49c9456a665">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42405789-5ad1-4e38-b36a-c49c9456a665">
											<gml:posList>35.67424441692803 139.74085227192313 24.066 35.674246855743306 139.74071819419214 24.066 35.67408749875521 139.7407138491193 31.4 35.67408728992067 139.74073531323515 31.4 35.674086195689654 139.74084794736714 31.4 35.67424441692803 139.74085227192313 24.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-24de30af-96b6-4aef-baf4-871ca2b5b4af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24de30af-96b6-4aef-baf4-871ca2b5b4af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24de30af-96b6-4aef-baf4-871ca2b5b4af">
											<gml:posList>35.67423140460374 139.74086855885625 128.969 35.674161857846784 139.74095485919455 128.969 35.67416087761136 139.74100481386515 128.969 35.67422769636892 139.74113422737722 128.969 35.67423140460374 139.74086855885625 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba7a2594-2618-4c4c-9a53-ac4249ae21d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba7a2594-2618-4c4c-9a53-ac4249ae21d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba7a2594-2618-4c4c-9a53-ac4249ae21d2">
											<gml:posList>35.67438922408581 139.74094837783588 48.4 35.67425752176932 139.74094475160905 48.4 35.67425182903912 139.74125584690643 48.4 35.674383423174085 139.7412594627216 48.4 35.67438922408581 139.74094837783588 48.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c47bf00e-840f-4bf9-b1aa-d0879c4eeed8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c47bf00e-840f-4bf9-b1aa-d0879c4eeed8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c47bf00e-840f-4bf9-b1aa-d0879c4eeed8">
											<gml:posList>35.673721916520186 139.74068579304273 9.47 35.67371361039982 139.74113794484163 9.47 35.67371361039982 139.74113794484163 125.19 35.67371912196791 139.74083782122642 125.19 35.67371912196791 139.74083782122642 76.4 35.673721916520186 139.74068579304273 76.4 35.673721916520186 139.74068579304273 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1031e4c9-c8da-4f5a-afb4-d5876b10092d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1031e4c9-c8da-4f5a-afb4-d5876b10092d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1031e4c9-c8da-4f5a-afb4-d5876b10092d">
											<gml:posList>35.67373380155073 139.74113847395722 9.47 35.67373380155073 139.74113847395722 125.19 35.67371361039982 139.74113794484163 125.19 35.67371361039982 139.74113794484163 9.47 35.67373380155073 139.74113847395722 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad0fa97e-bac0-49b7-8b13-ec5bad38e0bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad0fa97e-bac0-49b7-8b13-ec5bad38e0bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad0fa97e-bac0-49b7-8b13-ec5bad38e0bf">
											<gml:posList>35.67373342953087 139.7411588113994 76.4 35.67373342953087 139.7411588113994 125.19 35.67373380155073 139.74113847395722 125.19 35.67373380155073 139.74113847395722 9.47 35.673731897404565 139.74124154205705 9.47 35.673731897404565 139.74124154205705 76.4 35.67373342953087 139.7411588113994 76.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e32c4857-9003-43d7-8592-d3f08bd54616">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e32c4857-9003-43d7-8592-d3f08bd54616">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e32c4857-9003-43d7-8592-d3f08bd54616">
											<gml:posList>35.67376748733755 139.74111688305476 128.969 35.67376748733755 139.74111688305476 125.19 35.67376743611876 139.7411323927173 125.19 35.67376743611876 139.7411323927173 128.969 35.67376748733755 139.74111688305476 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3666bd16-bd3b-4bbd-b430-7cf83fb505f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3666bd16-bd3b-4bbd-b430-7cf83fb505f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3666bd16-bd3b-4bbd-b430-7cf83fb505f0">
											<gml:posList>35.673772625600655 139.7408588918837 128.969 35.673772625600655 139.7408588918837 125.19 35.67376748733755 139.74111688305476 125.19 35.67376748733755 139.74111688305476 128.969 35.673772625600655 139.7408588918837 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98814f39-d862-4f1d-a1e1-cf612ac09d37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98814f39-d862-4f1d-a1e1-cf612ac09d37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98814f39-d862-4f1d-a1e1-cf612ac09d37">
											<gml:posList>35.673772625600655 139.7408588918837 128.969 35.673789797454 139.74085981104767 128.969 35.673789797454 139.74085981104767 125.19 35.673772625600655 139.7408588918837 125.19 35.673772625600655 139.7408588918837 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25bf3d8c-73c6-40c4-9d02-b9b9dd922ab2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25bf3d8c-73c6-40c4-9d02-b9b9dd922ab2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25bf3d8c-73c6-40c4-9d02-b9b9dd922ab2">
											<gml:posList>35.67382427073312 139.7409599983004 129.7 35.67382427073312 139.7409599983004 128.969 35.67382226786611 139.741051666405 128.969 35.67382226786611 139.741051666405 129.7 35.67382427073312 139.7409599983004 129.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e3407f50-1a2d-4ebf-8cc4-0142a4289f40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3407f50-1a2d-4ebf-8cc4-0142a4289f40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3407f50-1a2d-4ebf-8cc4-0142a4289f40">
											<gml:posList>35.67382352138113 139.74068858091147 9.47 35.67382352138113 139.74068858091147 28.683 35.673823918934424 139.74066638756355 28.683 35.673823918934424 139.74066638756355 9.47 35.67382352138113 139.74068858091147 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f2e8fd9-5ddb-46e8-be6c-febc703cea7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f2e8fd9-5ddb-46e8-be6c-febc703cea7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f2e8fd9-5ddb-46e8-be6c-febc703cea7b">
											<gml:posList>35.67382352138113 139.74068858091147 28.683 35.67382352138113 139.74068858091147 9.47 35.673721916520186 139.74068579304273 9.47 35.673721916520186 139.74068579304273 76.4 35.67400783792978 139.7406936372107 76.4 35.67400783792978 139.7406936372107 9.47 35.67392843435109 139.74069146438487 9.47 35.67392843435109 139.74069146438487 28.683 35.67382352138113 139.74068858091147 28.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9517df55-f3be-4a16-a4d6-52e9166ad268">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9517df55-f3be-4a16-a4d6-52e9166ad268">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9517df55-f3be-4a16-a4d6-52e9166ad268">
											<gml:posList>35.673823918934424 139.74066638756355 28.683 35.67392884091858 139.74066927099747 28.683 35.67392884091858 139.74066927099747 9.47 35.673823918934424 139.74066638756355 9.47 35.673823918934424 139.74066638756355 28.683</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ee38e548-a7d7-4e5b-ad69-f5f119d29f63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee38e548-a7d7-4e5b-ad69-f5f119d29f63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee38e548-a7d7-4e5b-ad69-f5f119d29f63">
											<gml:posList>35.673996552641256 139.74105739789158 128.969 35.673996552641256 139.74105739789158 129.7 35.67382226786611 139.741051666405 129.7 35.67382226786611 139.741051666405 128.969 35.673996552641256 139.74105739789158 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0ebf6d5a-0965-46a8-ad6c-d0c9977b1f39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ebf6d5a-0965-46a8-ad6c-d0c9977b1f39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ebf6d5a-0965-46a8-ad6c-d0c9977b1f39">
											<gml:posList>35.67399856452599 139.74096572957745 129.7 35.67399856452599 139.74096572957745 128.969 35.67382427073312 139.7409599983004 128.969 35.67382427073312 139.7409599983004 129.7 35.67399856452599 139.74096572957745 129.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11736b93-8730-48e1-bf1c-7c28bb432090">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11736b93-8730-48e1-bf1c-7c28bb432090">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11736b93-8730-48e1-bf1c-7c28bb432090">
											<gml:posList>35.67392843435109 139.74069146438487 9.47 35.67392884091858 139.74066927099747 9.47 35.67392884091858 139.74066927099747 28.683 35.67392843435109 139.74069146438487 28.683 35.67392843435109 139.74069146438487 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ffd3fd8-c634-4c8b-ab06-57595cba325b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ffd3fd8-c634-4c8b-ab06-57595cba325b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ffd3fd8-c634-4c8b-ab06-57595cba325b">
											<gml:posList>35.674086195689654 139.74084794736714 76.4 35.67371912196791 139.74083782122642 76.4 35.67371912196791 139.74083782122642 125.19 35.67424441692803 139.74085227192313 125.19 35.67424441692803 139.74085227192313 24.066 35.674086195689654 139.74084794736714 31.4 35.674086195689654 139.74084794736714 76.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2660ffe-d9a8-483c-ad68-5331f4b79e25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2660ffe-d9a8-483c-ad68-5331f4b79e25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2660ffe-d9a8-483c-ad68-5331f4b79e25">
											<gml:posList>35.67425346419796 139.74116639914374 76.4 35.67425346419796 139.74116639914374 125.19 35.67373342953087 139.7411588113994 125.19 35.67373342953087 139.7411588113994 76.4 35.67425346419796 139.74116639914374 76.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b311ab9-76f8-42e5-bbc8-9fa7ad46c78a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b311ab9-76f8-42e5-bbc8-9fa7ad46c78a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b311ab9-76f8-42e5-bbc8-9fa7ad46c78a">
											<gml:posList>35.67376743611876 139.7411323927173 125.19 35.67422769636892 139.74113422737722 125.19 35.67422769636892 139.74113422737722 128.969 35.67376743611876 139.7411323927173 128.969 35.67376743611876 139.7411323927173 125.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40c805f5-e140-4526-9ea0-397273c56f96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40c805f5-e140-4526-9ea0-397273c56f96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40c805f5-e140-4526-9ea0-397273c56f96">
											<gml:posList>35.67399856452599 139.74096572957745 128.969 35.67399856452599 139.74096572957745 129.7 35.673996552641256 139.74105739789158 129.7 35.673996552641256 139.74105739789158 128.969 35.673996552641256 139.74105739789158 125.19 35.67399856452599 139.74096572957745 125.19 35.67399856452599 139.74096572957745 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51f833b6-b9ae-46bc-be7e-bdbb5c9302c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51f833b6-b9ae-46bc-be7e-bdbb5c9302c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51f833b6-b9ae-46bc-be7e-bdbb5c9302c4">
											<gml:posList>35.67400783792978 139.7406936372107 9.47 35.67400783792978 139.7406936372107 76.4 35.67400714716793 139.74073307493933 76.4 35.67400714716793 139.74073307493933 9.47 35.67400783792978 139.7406936372107 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a67fe58-8e29-476b-9b07-b8f4e8904eb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a67fe58-8e29-476b-9b07-b8f4e8904eb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a67fe58-8e29-476b-9b07-b8f4e8904eb9">
											<gml:posList>35.67401901056047 139.74106356927427 128.692 35.67401901056047 139.74106356927427 125.19 35.673996552641256 139.74105739789158 125.19 35.67401901056047 139.74106356927427 128.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14630e95-2d52-4fad-b22f-790fcb212c93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14630e95-2d52-4fad-b22f-790fcb212c93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14630e95-2d52-4fad-b22f-790fcb212c93">
											<gml:posList>35.673996552641256 139.74105739789158 128.969 35.67401901056047 139.74106356927427 128.969 35.67401901056047 139.74106356927427 128.692 35.673996552641256 139.74105739789158 125.19 35.673996552641256 139.74105739789158 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f2d653c-0a05-471f-a3cd-49c61f833240">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f2d653c-0a05-471f-a3cd-49c61f833240">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f2d653c-0a05-471f-a3cd-49c61f833240">
											<gml:posList>35.67402062049112 139.74094142338382 128.692 35.67402062049112 139.74094142338382 128.969 35.67399856452599 139.74096572957745 128.969 35.67399856452599 139.74096572957745 125.19 35.67402062049112 139.74094142338382 128.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d814f6ae-2fd7-4622-8580-b5b8a1bf034c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d814f6ae-2fd7-4622-8580-b5b8a1bf034c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d814f6ae-2fd7-4622-8580-b5b8a1bf034c">
											<gml:posList>35.67399856452599 139.74096572957745 125.19 35.67402062049112 139.74094142338382 125.19 35.67402062049112 139.74094142338382 128.692 35.67399856452599 139.74096572957745 125.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01c0645f-f672-4ad3-968e-a4b0d85cde94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01c0645f-f672-4ad3-968e-a4b0d85cde94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01c0645f-f672-4ad3-968e-a4b0d85cde94">
											<gml:posList>35.67423140460374 139.74086855885625 125.19 35.673789797454 139.74085981104767 125.19 35.673789797454 139.74085981104767 128.969 35.67423140460374 139.74086855885625 128.969 35.67423140460374 139.74086855885625 125.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d6decb7-1c01-4809-9d16-0eaf317b4c99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d6decb7-1c01-4809-9d16-0eaf317b4c99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d6decb7-1c01-4809-9d16-0eaf317b4c99">
											<gml:posList>35.67401901056047 139.74106356927427 128.692 35.67402062049112 139.74094142338382 128.692 35.67402062049112 139.74094142338382 125.19 35.67401901056047 139.74106356927427 125.19 35.67401901056047 139.74106356927427 128.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b752534-0ea5-4e6b-96c2-76e813cf77b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b752534-0ea5-4e6b-96c2-76e813cf77b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b752534-0ea5-4e6b-96c2-76e813cf77b1">
											<gml:posList>35.67400714716793 139.74073307493933 9.47 35.67400714716793 139.74073307493933 76.4 35.67408728992067 139.74073531323515 76.4 35.67408728992067 139.74073531323515 31.4 35.67408728992067 139.74073531323515 9.47 35.67400714716793 139.74073307493933 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-acfe2ec1-02b2-448f-8b3d-50a2a5bfab65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acfe2ec1-02b2-448f-8b3d-50a2a5bfab65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acfe2ec1-02b2-448f-8b3d-50a2a5bfab65">
											<gml:posList>35.674383423174085 139.7412594627216 9.47 35.674383423174085 139.7412594627216 48.4 35.67425182903912 139.74125584690643 48.4 35.67425182903912 139.74125584690643 76.4 35.673731897404565 139.74124154205705 76.4 35.673731897404565 139.74124154205705 9.47 35.674383423174085 139.7412594627216 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb5bf9f2-dfa2-49f3-ba0f-ffe8bf3ca65b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb5bf9f2-dfa2-49f3-ba0f-ffe8bf3ca65b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb5bf9f2-dfa2-49f3-ba0f-ffe8bf3ca65b">
											<gml:posList>35.6741122866913 139.74106631198333 128.692 35.67401901056047 139.74106356927427 128.692 35.67401901056047 139.74106356927427 128.969 35.6741122866913 139.74106631198333 128.969 35.6741122866913 139.74106631198333 128.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b0e57aa-6907-4353-91e2-fd8e4773d770">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b0e57aa-6907-4353-91e2-fd8e4773d770">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b0e57aa-6907-4353-91e2-fd8e4773d770">
											<gml:posList>35.67402062049112 139.74094142338382 128.969 35.67402062049112 139.74094142338382 128.692 35.67411467181265 139.74094417610422 128.692 35.67411467181265 139.74094417610422 128.969 35.67402062049112 139.74094142338382 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69997bce-682d-4b41-ac34-cab759bcaa54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69997bce-682d-4b41-ac34-cab759bcaa54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69997bce-682d-4b41-ac34-cab759bcaa54">
											<gml:posList>35.67408728992067 139.74073531323515 76.4 35.674086195689654 139.74084794736714 76.4 35.674086195689654 139.74084794736714 31.4 35.67408728992067 139.74073531323515 31.4 35.67408728992067 139.74073531323515 76.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c26e221-633c-40cd-8dff-417feec41f00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c26e221-633c-40cd-8dff-417feec41f00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c26e221-633c-40cd-8dff-417feec41f00">
											<gml:posList>35.67408749875521 139.7407138491193 9.47 35.67408728992067 139.74073531323515 9.47 35.67408728992067 139.74073531323515 31.4 35.67408749875521 139.7407138491193 31.4 35.67408749875521 139.7407138491193 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b675089c-6300-4d65-9db2-d368bf175bd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b675089c-6300-4d65-9db2-d368bf175bd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b675089c-6300-4d65-9db2-d368bf175bd5">
											<gml:posList>35.67411467181265 139.74094417610422 128.692 35.6741122866913 139.74106631198333 128.692 35.6741122866913 139.74106631198333 128.969 35.67411467181265 139.74094417610422 128.969 35.67411467181265 139.74094417610422 128.692</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9b30619-86e6-43cd-b776-f668b7fca6a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9b30619-86e6-43cd-b776-f668b7fca6a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9b30619-86e6-43cd-b776-f668b7fca6a1">
											<gml:posList>35.6741146271611 139.74100347523876 129.7 35.67411605809036 139.74095353112438 129.7 35.67411605809036 139.74095353112438 128.969 35.6741146271611 139.74100347523876 128.969 35.6741146271611 139.74100347523876 129.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a5346a2-0ee9-4784-aa7d-4754822d75f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a5346a2-0ee9-4784-aa7d-4754822d75f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a5346a2-0ee9-4784-aa7d-4754822d75f7">
											<gml:posList>35.67416087761136 139.74100481386515 128.969 35.67416087761136 139.74100481386515 129.7 35.6741146271611 139.74100347523876 129.7 35.6741146271611 139.74100347523876 128.969 35.67416087761136 139.74100481386515 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bc35638d-e8ae-4187-ac94-b34aff155e5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc35638d-e8ae-4187-ac94-b34aff155e5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc35638d-e8ae-4187-ac94-b34aff155e5f">
											<gml:posList>35.674161857846784 139.74095485919455 128.969 35.67411605809036 139.74095353112438 128.969 35.67411605809036 139.74095353112438 129.7 35.674161857846784 139.74095485919455 129.7 35.674161857846784 139.74095485919455 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a9f2922-ae69-4e86-b4c5-e4f7ea6c7d22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a9f2922-ae69-4e86-b4c5-e4f7ea6c7d22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a9f2922-ae69-4e86-b4c5-e4f7ea6c7d22">
											<gml:posList>35.674161857846784 139.74095485919455 128.969 35.674161857846784 139.74095485919455 129.7 35.67416087761136 139.74100481386515 129.7 35.67416087761136 139.74100481386515 128.969 35.674161857846784 139.74095485919455 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8774c6b-ddcf-4026-afca-91e1766c3d4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8774c6b-ddcf-4026-afca-91e1766c3d4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8774c6b-ddcf-4026-afca-91e1766c3d4a">
											<gml:posList>35.67408749875521 139.7407138491193 9.47 35.67408749875521 139.7407138491193 31.4 35.674246855743306 139.74071819419214 24.066 35.674246855743306 139.74071819419214 9.47 35.67408749875521 139.7407138491193 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab2efb59-67ff-49e9-af6f-0172f608204e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab2efb59-67ff-49e9-af6f-0172f608204e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab2efb59-67ff-49e9-af6f-0172f608204e">
											<gml:posList>35.67422769636892 139.74113422737722 128.969 35.67422769636892 139.74113422737722 125.19 35.67423140460374 139.74086855885625 125.19 35.67423140460374 139.74086855885625 128.969 35.67422769636892 139.74113422737722 128.969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa9c0160-3a27-4246-b227-7e8d49b39245">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa9c0160-3a27-4246-b227-7e8d49b39245">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa9c0160-3a27-4246-b227-7e8d49b39245">
											<gml:posList>35.67424441692803 139.74085227192313 24.066 35.67424441692803 139.74085227192313 125.19 35.67424274796503 139.74094434885725 125.19 35.67424274796503 139.74094434885725 9.47 35.674246855743306 139.74071819419214 9.47 35.674246855743306 139.74071819419214 24.066 35.67424441692803 139.74085227192313 24.066</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf676674-a3d6-4919-9578-cf1fdcae302e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf676674-a3d6-4919-9578-cf1fdcae302e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf676674-a3d6-4919-9578-cf1fdcae302e">
											<gml:posList>35.67425752176932 139.74094475160905 125.19 35.67425346419796 139.74116639914374 125.19 35.67425346419796 139.74116639914374 76.4 35.67425182903912 139.74125584690643 76.4 35.67425182903912 139.74125584690643 48.4 35.67425752176932 139.74094475160905 48.4 35.67425752176932 139.74094475160905 125.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f52fab1-8c62-46eb-82dc-177aa92df796">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f52fab1-8c62-46eb-82dc-177aa92df796">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f52fab1-8c62-46eb-82dc-177aa92df796">
											<gml:posList>35.67424274796503 139.74094434885725 9.47 35.67424274796503 139.74094434885725 125.19 35.67425752176932 139.74094475160905 125.19 35.67425752176932 139.74094475160905 48.4 35.67438922408581 139.74094837783588 48.4 35.67438922408581 139.74094837783588 9.47 35.67424274796503 139.74094434885725 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d1ca6fe-34da-4276-954c-444379139517">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d1ca6fe-34da-4276-954c-444379139517">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d1ca6fe-34da-4276-954c-444379139517">
											<gml:posList>35.67438922408581 139.74094837783588 9.47 35.67438922408581 139.74094837783588 48.4 35.674383423174085 139.7412594627216 48.4 35.674383423174085 139.7412594627216 9.47 35.67438922408581 139.74094837783588 9.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4556</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">3272.53665</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>