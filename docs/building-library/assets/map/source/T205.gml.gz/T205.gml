<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_37918de4-f8f9-4781-9d48-eb1229c873cb">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>霞が関三丁目南地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">7.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670594902420945 139.74734692785097 0 35.67059530979481 139.74733676482754 0 35.670456519617 139.74731608042492 0 35.670452814647966 139.74735348707037 0 35.670594902420945 139.74734692785097 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670594902420945 139.74734692785097 8.45 35.670452814647966 139.74735348707037 8.45 35.670456519617 139.74731608042492 8.45 35.67059530979481 139.74733676482754 8.45 35.670594902420945 139.74734692785097 8.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670594902420945 139.74734692785097 8.45 35.67059530979481 139.74733676482754 8.45 35.67059530979481 139.74733676482754 15.87 35.670594902420945 139.74734692785097 15.87 35.670594902420945 139.74734692785097 8.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059530979481 139.74733676482754 8.45 35.670456519617 139.74731608042492 8.45 35.670456519617 139.74731608042492 15.87 35.67059530979481 139.74733676482754 15.87 35.67059530979481 139.74733676482754 8.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670456519617 139.74731608042492 8.45 35.670452814647966 139.74735348707037 8.45 35.670452814647966 139.74735348707037 15.87 35.670456519617 139.74731608042492 15.87 35.670456519617 139.74731608042492 8.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670452814647966 139.74735348707037 8.45 35.670594902420945 139.74734692785097 8.45 35.670594902420945 139.74734692785097 15.87 35.670452814647966 139.74735348707037 15.87 35.670452814647966 139.74735348707037 8.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670594902420945 139.74734692785097 15.87 35.67059530979481 139.74733676482754 15.87 35.670456519617 139.74731608042492 15.87 35.670452814647966 139.74735348707037 15.87 35.670594902420945 139.74734692785097 15.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6193cce8-4a8c-45e7-93b8-52850a037074"/>
							<gml:surfaceMember xlink:href="#poly-e5f86362-752a-405c-862f-ca42ae59687b"/>
							<gml:surfaceMember xlink:href="#poly-90484678-c558-4239-89cd-df249f4bf13c"/>
							<gml:surfaceMember xlink:href="#poly-ce764fa5-ec2f-4fa1-8c26-a1da716cdef4"/>
							<gml:surfaceMember xlink:href="#poly-8d1d9fb6-10d7-457d-8e1f-8bfdc6bfea30"/>
							<gml:surfaceMember xlink:href="#poly-bb4cb80b-27f7-4789-baac-035884d078f4"/>
							<gml:surfaceMember xlink:href="#poly-4e8b99c8-61d2-43c7-9a0c-6d4252658fd2"/>
							<gml:surfaceMember xlink:href="#poly-a388b70c-f9f2-4113-bde2-e33fc26fff59"/>
							<gml:surfaceMember xlink:href="#poly-855c5216-1bb0-42c9-a3a9-30cd8a6d5700"/>
							<gml:surfaceMember xlink:href="#poly-fe4598b4-cc49-4fa3-8978-31281e7cdd9a"/>
							<gml:surfaceMember xlink:href="#poly-7e2735f2-5ec4-4aa6-88a0-b00ea4627a15"/>
							<gml:surfaceMember xlink:href="#poly-f380bfb6-4d01-442b-b6e2-18ec30dc78c1"/>
							<gml:surfaceMember xlink:href="#poly-e1619fba-06a0-4c00-9075-4f329478a3a6"/>
							<gml:surfaceMember xlink:href="#poly-9ba54f50-3270-4d41-8bc7-220b2e4f99fe"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6193cce8-4a8c-45e7-93b8-52850a037074">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6193cce8-4a8c-45e7-93b8-52850a037074">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6193cce8-4a8c-45e7-93b8-52850a037074">
											<gml:posList>35.67059490242096 139.74734692785097 8.45 35.67045281464795 139.74735348707037 8.45 35.670456519616984 139.74731608042492 8.45 35.67059530979477 139.7473367648275 8.45 35.67059490242096 139.74734692785097 8.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5f86362-752a-405c-862f-ca42ae59687b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5f86362-752a-405c-862f-ca42ae59687b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5f86362-752a-405c-862f-ca42ae59687b">
											<gml:posList>35.670456519616984 139.74731608042492 15.987 35.67045281464795 139.74735348707037 15.987 35.67045481407778 139.7473512204408 15.987 35.67045806268402 139.7473184868565 15.987 35.670456519616984 139.74731608042492 15.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90484678-c558-4239-89cd-df249f4bf13c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90484678-c558-4239-89cd-df249f4bf13c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90484678-c558-4239-89cd-df249f4bf13c">
											<gml:posList>35.67059490242096 139.74734692785097 15.987 35.67059322436952 139.74734483085564 15.987 35.67045481407778 139.7473512204408 15.987 35.67045281464795 139.74735348707037 15.987 35.67059490242096 139.74734692785097 15.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce764fa5-ec2f-4fa1-8c26-a1da716cdef4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce764fa5-ec2f-4fa1-8c26-a1da716cdef4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce764fa5-ec2f-4fa1-8c26-a1da716cdef4">
											<gml:posList>35.67059322436952 139.74734483085564 15.624 35.670593463338236 139.7473386667698 15.624 35.67045806268402 139.7473184868565 15.624 35.67045481407778 139.7473512204408 15.624 35.67059322436952 139.74734483085564 15.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d1d9fb6-10d7-457d-8e1f-8bfdc6bfea30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d1d9fb6-10d7-457d-8e1f-8bfdc6bfea30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d1d9fb6-10d7-457d-8e1f-8bfdc6bfea30">
											<gml:posList>35.670456519616984 139.74731608042492 15.987 35.67045806268402 139.7473184868565 15.987 35.670593463338236 139.7473386667698 15.987 35.67059530979477 139.7473367648275 15.987 35.670456519616984 139.74731608042492 15.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb4cb80b-27f7-4789-baac-035884d078f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb4cb80b-27f7-4789-baac-035884d078f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb4cb80b-27f7-4789-baac-035884d078f4">
											<gml:posList>35.67059530979477 139.7473367648275 15.987 35.670593463338236 139.7473386667698 15.987 35.67059322436952 139.74734483085564 15.987 35.67059490242096 139.74734692785097 15.987 35.67059530979477 139.7473367648275 15.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e8b99c8-61d2-43c7-9a0c-6d4252658fd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e8b99c8-61d2-43c7-9a0c-6d4252658fd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e8b99c8-61d2-43c7-9a0c-6d4252658fd2">
											<gml:posList>35.67059530979477 139.7473367648275 8.45 35.670456519616984 139.74731608042492 8.45 35.670456519616984 139.74731608042492 15.987 35.67059530979477 139.7473367648275 15.987 35.67059530979477 139.7473367648275 8.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a388b70c-f9f2-4113-bde2-e33fc26fff59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a388b70c-f9f2-4113-bde2-e33fc26fff59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a388b70c-f9f2-4113-bde2-e33fc26fff59">
											<gml:posList>35.67045806268402 139.7473184868565 15.987 35.67045806268402 139.7473184868565 15.624 35.670593463338236 139.7473386667698 15.624 35.670593463338236 139.7473386667698 15.987 35.67045806268402 139.7473184868565 15.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-855c5216-1bb0-42c9-a3a9-30cd8a6d5700">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-855c5216-1bb0-42c9-a3a9-30cd8a6d5700">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-855c5216-1bb0-42c9-a3a9-30cd8a6d5700">
											<gml:posList>35.670456519616984 139.74731608042492 8.45 35.67045281464795 139.74735348707037 8.45 35.67045281464795 139.74735348707037 15.987 35.670456519616984 139.74731608042492 15.987 35.670456519616984 139.74731608042492 8.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe4598b4-cc49-4fa3-8978-31281e7cdd9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe4598b4-cc49-4fa3-8978-31281e7cdd9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe4598b4-cc49-4fa3-8978-31281e7cdd9a">
											<gml:posList>35.67045481407778 139.7473512204408 15.987 35.67045481407778 139.7473512204408 15.624 35.67045806268402 139.7473184868565 15.624 35.67045806268402 139.7473184868565 15.987 35.67045481407778 139.7473512204408 15.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e2735f2-5ec4-4aa6-88a0-b00ea4627a15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e2735f2-5ec4-4aa6-88a0-b00ea4627a15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e2735f2-5ec4-4aa6-88a0-b00ea4627a15">
											<gml:posList>35.670593463338236 139.7473386667698 15.987 35.670593463338236 139.7473386667698 15.624 35.67059322436952 139.74734483085564 15.624 35.67059322436952 139.74734483085564 15.987 35.670593463338236 139.7473386667698 15.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f380bfb6-4d01-442b-b6e2-18ec30dc78c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f380bfb6-4d01-442b-b6e2-18ec30dc78c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f380bfb6-4d01-442b-b6e2-18ec30dc78c1">
											<gml:posList>35.67059490242096 139.74734692785097 8.45 35.67059530979477 139.7473367648275 8.45 35.67059530979477 139.7473367648275 15.987 35.67059490242096 139.74734692785097 15.987 35.67059490242096 139.74734692785097 8.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1619fba-06a0-4c00-9075-4f329478a3a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1619fba-06a0-4c00-9075-4f329478a3a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1619fba-06a0-4c00-9075-4f329478a3a6">
											<gml:posList>35.67059322436952 139.74734483085564 15.987 35.67059322436952 139.74734483085564 15.624 35.67045481407778 139.7473512204408 15.624 35.67045481407778 139.7473512204408 15.987 35.67059322436952 139.74734483085564 15.987</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ba54f50-3270-4d41-8bc7-220b2e4f99fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ba54f50-3270-4d41-8bc7-220b2e4f99fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ba54f50-3270-4d41-8bc7-220b2e4f99fe">
											<gml:posList>35.67045281464795 139.74735348707037 8.45 35.67059490242096 139.74734692785097 8.45 35.67059490242096 139.74734692785097 15.987 35.67045281464795 139.74735348707037 15.987 35.67045281464795 139.74735348707037 8.45</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-1848</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>