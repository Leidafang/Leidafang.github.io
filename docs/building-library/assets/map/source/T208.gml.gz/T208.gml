<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3974d06a-09a4-43af-bed4-5e63ab777824">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">22.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672476460229035 139.73824276378753 0 35.67246523379675 139.73822585379384 0 35.672426362572 139.7382435743727 0 35.67248429092964 139.7384341691029 0 35.67254321949278 139.73840725621463 0 35.67253291711301 139.73837335548666 0 35.67262239127515 139.7383325981365 0 35.672574765202505 139.73817590386335 0 35.6725345063794 139.73819426683764 0 35.67253468596715 139.7382162161314 0 35.672476460229035 139.73824276378753 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672476460229035 139.73824276378753 9.16 35.67253468596715 139.7382162161314 9.16 35.6725345063794 139.73819426683764 9.16 35.672574765202505 139.73817590386335 9.16 35.67262239127515 139.7383325981365 9.16 35.67253291711301 139.73837335548666 9.16 35.67254321949278 139.73840725621463 9.16 35.67248429092964 139.7384341691029 9.16 35.672426362572 139.7382435743727 9.16 35.67246523379675 139.73822585379384 9.16 35.672476460229035 139.73824276378753 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672476460229035 139.73824276378753 9.16 35.67246523379675 139.73822585379384 9.16 35.67246523379675 139.73822585379384 31.57 35.672476460229035 139.73824276378753 31.57 35.672476460229035 139.73824276378753 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67246523379675 139.73822585379384 9.16 35.672426362572 139.7382435743727 9.16 35.672426362572 139.7382435743727 31.57 35.67246523379675 139.73822585379384 31.57 35.67246523379675 139.73822585379384 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672426362572 139.7382435743727 9.16 35.67248429092964 139.7384341691029 9.16 35.67248429092964 139.7384341691029 31.57 35.672426362572 139.7382435743727 31.57 35.672426362572 139.7382435743727 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67248429092964 139.7384341691029 9.16 35.67254321949278 139.73840725621463 9.16 35.67254321949278 139.73840725621463 31.57 35.67248429092964 139.7384341691029 31.57 35.67248429092964 139.7384341691029 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67254321949278 139.73840725621463 9.16 35.67253291711301 139.73837335548666 9.16 35.67253291711301 139.73837335548666 31.57 35.67254321949278 139.73840725621463 31.57 35.67254321949278 139.73840725621463 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67253291711301 139.73837335548666 9.16 35.67262239127515 139.7383325981365 9.16 35.67262239127515 139.7383325981365 31.57 35.67253291711301 139.73837335548666 31.57 35.67253291711301 139.73837335548666 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67262239127515 139.7383325981365 9.16 35.672574765202505 139.73817590386335 9.16 35.672574765202505 139.73817590386335 31.57 35.67262239127515 139.7383325981365 31.57 35.67262239127515 139.7383325981365 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672574765202505 139.73817590386335 9.16 35.6725345063794 139.73819426683764 9.16 35.6725345063794 139.73819426683764 31.57 35.672574765202505 139.73817590386335 31.57 35.672574765202505 139.73817590386335 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6725345063794 139.73819426683764 9.16 35.67253468596715 139.7382162161314 9.16 35.67253468596715 139.7382162161314 31.57 35.6725345063794 139.73819426683764 31.57 35.6725345063794 139.73819426683764 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67253468596715 139.7382162161314 9.16 35.672476460229035 139.73824276378753 9.16 35.672476460229035 139.73824276378753 31.57 35.67253468596715 139.7382162161314 31.57 35.67253468596715 139.7382162161314 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672476460229035 139.73824276378753 31.57 35.67246523379675 139.73822585379384 31.57 35.672426362572 139.7382435743727 31.57 35.67248429092964 139.7384341691029 31.57 35.67254321949278 139.73840725621463 31.57 35.67253291711301 139.73837335548666 31.57 35.67262239127515 139.7383325981365 31.57 35.672574765202505 139.73817590386335 31.57 35.6725345063794 139.73819426683764 31.57 35.67253468596715 139.7382162161314 31.57 35.672476460229035 139.73824276378753 31.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f20ee0f3-131e-486e-a50a-e42882088c54"/>
							<gml:surfaceMember xlink:href="#poly-5ee31b9d-398e-4601-b367-7e14758ba658"/>
							<gml:surfaceMember xlink:href="#poly-0b1ad616-a54d-4dac-a8d0-d36dc69c4c6e"/>
							<gml:surfaceMember xlink:href="#poly-fd370288-4167-43ad-ae82-083d0b7a001a"/>
							<gml:surfaceMember xlink:href="#poly-0292415d-8a00-46bf-a5bf-f8cbcc997f2a"/>
							<gml:surfaceMember xlink:href="#poly-0d9f4d74-77d9-4978-832d-73e0e9031e00"/>
							<gml:surfaceMember xlink:href="#poly-bd3e4ee8-3916-4dd2-8ee6-d655fdfe84cc"/>
							<gml:surfaceMember xlink:href="#poly-fed9b648-8625-434b-bcb8-6e312637c065"/>
							<gml:surfaceMember xlink:href="#poly-14786922-5f79-4b9b-a189-fd9dcd814fc3"/>
							<gml:surfaceMember xlink:href="#poly-dcc8ee8b-406c-4942-a270-a87674edeeb9"/>
							<gml:surfaceMember xlink:href="#poly-f783728d-0516-4f35-913b-e3cc9278fe6a"/>
							<gml:surfaceMember xlink:href="#poly-384d4dd1-6f8d-4d72-aeaf-c7c311da5313"/>
							<gml:surfaceMember xlink:href="#poly-194ead58-d7c5-4ab7-9d41-b1ce69008015"/>
							<gml:surfaceMember xlink:href="#poly-56ccf9d2-a6d4-45cc-a47c-685f5120ee76"/>
							<gml:surfaceMember xlink:href="#poly-ae02de12-82ec-478c-bdf6-8085bc095139"/>
							<gml:surfaceMember xlink:href="#poly-2b3e0a8a-4cb7-4e00-baaa-e5a533d678df"/>
							<gml:surfaceMember xlink:href="#poly-e60d74fc-4453-42cd-af5f-3b13098692c4"/>
							<gml:surfaceMember xlink:href="#poly-e5700f97-80f9-4b2e-bb2c-000e815542e2"/>
							<gml:surfaceMember xlink:href="#poly-81043278-2b78-42e2-918f-852e34564773"/>
							<gml:surfaceMember xlink:href="#poly-7f0bbe53-96cb-4b2c-b51d-363c7552d4b5"/>
							<gml:surfaceMember xlink:href="#poly-75eff7c2-5258-4416-ae5e-5332ee4c2dea"/>
							<gml:surfaceMember xlink:href="#poly-bedd3467-540c-49d5-804e-dd94311f188d"/>
							<gml:surfaceMember xlink:href="#poly-ea68d620-d732-4304-b3fa-f984feb86ce1"/>
							<gml:surfaceMember xlink:href="#poly-34be0c0c-21f9-431d-afcc-3d4cbe456c53"/>
							<gml:surfaceMember xlink:href="#poly-dfde5e0f-228a-49fe-ab0e-63d4683684de"/>
							<gml:surfaceMember xlink:href="#poly-f5dc1624-f9f9-406d-b844-f2d095476a5c"/>
							<gml:surfaceMember xlink:href="#poly-9e85370b-1d93-4e2c-8ffa-25b1f893c1c0"/>
							<gml:surfaceMember xlink:href="#poly-a6a3ea05-4ce9-4478-a057-4d55b9201736"/>
							<gml:surfaceMember xlink:href="#poly-2be69616-d5cd-4f2b-979c-adfce1de337e"/>
							<gml:surfaceMember xlink:href="#poly-48096355-82ce-48d2-89cb-4f93292bab1f"/>
							<gml:surfaceMember xlink:href="#poly-42c1e503-cc65-40e7-9703-e0bac243d590"/>
							<gml:surfaceMember xlink:href="#poly-3a7f218a-1212-4161-bd75-34229fc62cf9"/>
							<gml:surfaceMember xlink:href="#poly-96a7b576-87a5-499a-bb41-41b49ef5e04e"/>
							<gml:surfaceMember xlink:href="#poly-f3157dc5-4bd2-4ea8-9610-323ccc2e959f"/>
							<gml:surfaceMember xlink:href="#poly-b3488911-8eed-43e9-acb7-1fda51620c26"/>
							<gml:surfaceMember xlink:href="#poly-49d7539d-7170-47f0-8b7f-30f62787ad20"/>
							<gml:surfaceMember xlink:href="#poly-df3a1373-d2cf-41a1-979f-72f459818062"/>
							<gml:surfaceMember xlink:href="#poly-62181c39-9a77-42b2-8129-47a9a6c724a1"/>
							<gml:surfaceMember xlink:href="#poly-70a252a7-6ba9-4845-8d71-60aebef20771"/>
							<gml:surfaceMember xlink:href="#poly-9fd053ed-4074-4a51-b483-b5c02374d6c4"/>
							<gml:surfaceMember xlink:href="#poly-66817e8f-f88b-4576-8b84-041ad52f058f"/>
							<gml:surfaceMember xlink:href="#poly-f9ca3e6d-17a9-4b8a-8133-03e4da6541d7"/>
							<gml:surfaceMember xlink:href="#poly-99122370-e3b4-4dbe-8ea7-76fbef6352fd"/>
							<gml:surfaceMember xlink:href="#poly-97408fb8-c567-475f-bccb-2e11a68e88a6"/>
							<gml:surfaceMember xlink:href="#poly-8c3dd6d5-7393-4b79-9b29-fd0a852c2d40"/>
							<gml:surfaceMember xlink:href="#poly-001ab24e-d7a4-40fc-9a01-a420932c9dee"/>
							<gml:surfaceMember xlink:href="#poly-4ba760e4-40b2-4c38-9512-c856350dd19a"/>
							<gml:surfaceMember xlink:href="#poly-c486b4a1-e0c8-4781-a8ea-4c61fcbf7732"/>
							<gml:surfaceMember xlink:href="#poly-d27a8fa0-9b39-4564-8eba-9d93b7f6b00d"/>
							<gml:surfaceMember xlink:href="#poly-2e8952e7-57bc-4607-ba0b-95301a032487"/>
							<gml:surfaceMember xlink:href="#poly-cdeca82d-d3b4-40bb-b7e3-40780a184ed0"/>
							<gml:surfaceMember xlink:href="#poly-a4be2cbd-6eaf-402c-9cca-b8ef9213d635"/>
							<gml:surfaceMember xlink:href="#poly-299c39f5-79c0-4f87-9480-85f1f70d63b9"/>
							<gml:surfaceMember xlink:href="#poly-9066b6d8-f3cf-4e1c-82c6-3ca8634f8f8e"/>
							<gml:surfaceMember xlink:href="#poly-3bf40d42-74af-46a6-8453-47215701b5f2"/>
							<gml:surfaceMember xlink:href="#poly-b538e6e2-ec14-489e-b85c-338d8db2ed44"/>
							<gml:surfaceMember xlink:href="#poly-d75fc26b-4223-4d88-9b45-046a0b90a530"/>
							<gml:surfaceMember xlink:href="#poly-e320c0d3-d27b-446c-b762-277abd7725f9"/>
							<gml:surfaceMember xlink:href="#poly-9266ed97-ae84-41c7-af02-478a82d2092c"/>
							<gml:surfaceMember xlink:href="#poly-2c4b4b25-591e-4c42-bb27-6b9364e75737"/>
							<gml:surfaceMember xlink:href="#poly-62e07824-f84f-4489-9dab-4528adbb9891"/>
							<gml:surfaceMember xlink:href="#poly-78bfeae3-1bf9-47ca-aed3-13767e9149f7"/>
							<gml:surfaceMember xlink:href="#poly-44f167de-4026-4cf5-aa14-3773a998afaa"/>
							<gml:surfaceMember xlink:href="#poly-335c9df8-2568-4f28-a546-7bc9bd170c53"/>
							<gml:surfaceMember xlink:href="#poly-761c18d0-e348-4b3c-aed8-b4a41d6e6734"/>
							<gml:surfaceMember xlink:href="#poly-5a101bf3-b71a-4a37-a951-04889c764c70"/>
							<gml:surfaceMember xlink:href="#poly-cedfa4bf-0a65-40fd-b02e-fbca4096261e"/>
							<gml:surfaceMember xlink:href="#poly-cc20d7e8-d126-412d-93df-1f2dbb0d8c2d"/>
							<gml:surfaceMember xlink:href="#poly-f1edc543-65c7-4acf-ad7b-3fad4bcb4682"/>
							<gml:surfaceMember xlink:href="#poly-c65f0a47-e7f2-481f-9928-6bd304c2bda0"/>
							<gml:surfaceMember xlink:href="#poly-a9ea405c-72dd-49f5-af8b-a7c15e9bc412"/>
							<gml:surfaceMember xlink:href="#poly-359ee70b-b717-4224-a746-9c5a247c16b6"/>
							<gml:surfaceMember xlink:href="#poly-c82dec81-d320-4b6d-bc28-70690d3b1fd2"/>
							<gml:surfaceMember xlink:href="#poly-f985eeca-00e4-45d2-baa8-aa2b115eab14"/>
							<gml:surfaceMember xlink:href="#poly-51f5e0fd-0132-44e0-b9fd-978253cd18ad"/>
							<gml:surfaceMember xlink:href="#poly-461202b6-ead6-47c9-8b52-e7b214bac3a4"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3974d06a-09a4-43af-bed4-5e63ab777824_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3db32018-96cd-40f1-aa0b-82bc7649c411">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67261316441934 139.73831380781328 36.404 35.672615884600575 139.7383227412622 36.404 35.67261048708269 139.73832490173928 36.404 35.67260807326344 139.738315835369 36.404 35.67261316441934 139.73831380781328 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8af03e0-52a1-455a-80f2-48dc199bd52d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672592682660785 139.73832197340622 36.404 35.67260006258661 139.73831903732045 36.404 35.67260288324317 139.73832964972698 36.404 35.672595503325816 139.7383325968584 36.404 35.672592682660785 139.73832197340622 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78dff663-a39a-4d54-b9d3-98ca5364a920">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6725491197047 139.7383338890364 36.404 35.6725559774307 139.73835456006873 36.404 35.672550219921064 139.73835742794824 36.404 35.67254336220427 139.7383367679637 36.404 35.6725491197047 139.7383338890364 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d05fc1f-ac7f-48b8-a449-f4f9859266e4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67254336220427 139.7383367679637 36.404 35.672550219921064 139.73835742794824 36.404 35.672550219921064 139.73835742794824 37.306 35.67254336220427 139.7383367679637 37.306 35.67254336220427 139.7383367679637 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69b7525c-a6ec-4a04-a40d-37040f99cf62">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672541569171415 139.73833765381283 36.404 35.67254842689677 139.73835832484357 36.404 35.672538029142764 139.73836350694975 36.404 35.67253116240458 139.73834283593195 36.404 35.672541569171415 139.73833765381283 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c26c3d5f-ab20-4043-86e1-35f27add0371">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67246950494721 139.7383497467991 36.404 35.67247259566416 139.7383599170076 36.404 35.67246615316395 139.73836285197447 36.404 35.67246306244724 139.73835268176663 36.404 35.67246950494721 139.7383497467991 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8af2e8b7-2cb7-4db2-bb2b-3a7cbd75b8ed">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67249804671222 139.73835520311985 36.404 35.67250586781452 139.7383516368645 36.404 35.67250816325036 139.73835917894033 36.404 35.67250034214784 139.73836274519505 36.404 35.67249804671222 139.73835520311985 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-111c12a9-a9e5-4b79-beb6-380c8fb21d15">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67247598004316 139.7383652816207 36.404 35.672483224476885 139.7383619811676 36.404 35.67248551990337 139.73836951219505 36.404 35.672478266464445 139.73837282370476 36.404 35.67247598004316 139.7383652816207 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-823d9018-2ce5-4342-8fa4-20a8550f7fde">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67247498145449 139.73836773513722 36.404 35.67247837039795 139.7383788881367 36.404 35.67247191889228 139.73838183415944 36.404 35.672468529940375 139.7383706701142 36.404 35.67247498145449 139.73836773513722 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c4955eb-ccfd-4182-b318-967ba6b91a18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c4955eb-ccfd-4182-b318-967ba6b91a18_0">
											<gml:posList>35.672541569171415 139.73833765381283 36.404 35.672541569171415 139.73833765381283 37.306 35.67254842689677 139.73835832484357 37.306 35.67254842689677 139.73835832484357 36.404 35.672541569171415 139.73833765381283 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7ac0f7b-81c3-47c6-8f8e-b4874dcf4603">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7ac0f7b-81c3-47c6-8f8e-b4874dcf4603_0">
											<gml:posList>35.67246615316395 139.73836285197447 37.406 35.67246306244724 139.73835268176663 37.406 35.67246306244724 139.73835268176663 36.404 35.67246615316395 139.73836285197447 36.404 35.67246615316395 139.73836285197447 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a067c415-92d9-484e-ac9e-b898c601d5aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a067c415-92d9-484e-ac9e-b898c601d5aa_0">
											<gml:posList>35.67246950494721 139.7383497467991 37.406 35.67246950494721 139.7383497467991 36.404 35.67246306244724 139.73835268176663 36.404 35.67246306244724 139.73835268176663 37.406 35.67246950494721 139.7383497467991 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e785ccf-2cfa-4887-90f3-7545b81db75d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e785ccf-2cfa-4887-90f3-7545b81db75d_0">
											<gml:posList>35.67246615316395 139.73836285197447 37.406 35.67247259566416 139.7383599170076 37.406 35.67246950494721 139.7383497467991 37.406 35.67246306244724 139.73835268176663 37.406 35.67246615316395 139.73836285197447 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65945b3a-2efb-4ec0-aa80-d50b6fad38c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65945b3a-2efb-4ec0-aa80-d50b6fad38c7_0">
											<gml:posList>35.67246615316395 139.73836285197447 36.404 35.67247259566416 139.7383599170076 36.404 35.67247259566416 139.7383599170076 37.406 35.67246615316395 139.73836285197447 37.406 35.67246615316395 139.73836285197447 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb0f700e-88bc-475d-99d4-c60a738b3be9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb0f700e-88bc-475d-99d4-c60a738b3be9_0">
											<gml:posList>35.67247191889228 139.73838183415944 37.406 35.672468529940375 139.7383706701142 37.406 35.672468529940375 139.7383706701142 36.404 35.67247191889228 139.73838183415944 36.404 35.67247191889228 139.73838183415944 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9412fcc4-d3d5-4dd7-a4fa-ab4ccd483def">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9412fcc4-d3d5-4dd7-a4fa-ab4ccd483def_0">
											<gml:posList>35.67247259566416 139.7383599170076 36.404 35.67246950494721 139.7383497467991 36.404 35.67246950494721 139.7383497467991 37.406 35.67247259566416 139.7383599170076 37.406 35.67247259566416 139.7383599170076 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-312d2684-4973-4e17-b879-ed913749fd52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-312d2684-4973-4e17-b879-ed913749fd52_0">
											<gml:posList>35.672468529940375 139.7383706701142 37.406 35.67247498145449 139.73836773513722 37.406 35.67247498145449 139.73836773513722 36.404 35.672468529940375 139.7383706701142 36.404 35.672468529940375 139.7383706701142 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96cffce2-7333-42e3-9cb7-53b920b59445">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96cffce2-7333-42e3-9cb7-53b920b59445_0">
											<gml:posList>35.67247191889228 139.73838183415944 37.406 35.67247837039795 139.7383788881367 37.406 35.67247498145449 139.73836773513722 37.406 35.672468529940375 139.7383706701142 37.406 35.67247191889228 139.73838183415944 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b829a257-7f48-4f80-88e8-ba2ec4757794">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b829a257-7f48-4f80-88e8-ba2ec4757794_0">
											<gml:posList>35.67247191889228 139.73838183415944 36.404 35.67247837039795 139.7383788881367 36.404 35.67247837039795 139.7383788881367 37.406 35.67247191889228 139.73838183415944 37.406 35.67247191889228 139.73838183415944 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d182d96c-2f01-4175-826a-9065abab8f47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d182d96c-2f01-4175-826a-9065abab8f47_0">
											<gml:posList>35.67247837039795 139.7383788881367 36.404 35.67247498145449 139.73836773513722 36.404 35.67247498145449 139.73836773513722 37.406 35.67247837039795 139.7383788881367 37.406 35.67247837039795 139.7383788881367 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b96d4e85-9d75-48f3-b141-96c0b7050774">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b96d4e85-9d75-48f3-b141-96c0b7050774_0">
											<gml:posList>35.67247598004316 139.7383652816207 36.404 35.672478266464445 139.73837282370476 36.404 35.672478266464445 139.73837282370476 37.406 35.67247598004316 139.7383652816207 37.406 35.67247598004316 139.7383652816207 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0e794d4-f2b3-40d4-82e3-9f61c1d81313">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0e794d4-f2b3-40d4-82e3-9f61c1d81313_0">
											<gml:posList>35.672483224476885 139.7383619811676 36.404 35.67247598004316 139.7383652816207 36.404 35.67247598004316 139.7383652816207 37.406 35.672483224476885 139.7383619811676 37.406 35.672483224476885 139.7383619811676 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fac2be2-ca91-4cd5-8135-b7b80a30eabe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fac2be2-ca91-4cd5-8135-b7b80a30eabe_0">
											<gml:posList>35.67248551990337 139.73836951219505 37.406 35.672483224476885 139.7383619811676 37.406 35.67247598004316 139.7383652816207 37.406 35.672478266464445 139.73837282370476 37.406 35.67248551990337 139.73836951219505 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c2558bf-82ad-476a-91bb-209ef753c195">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c2558bf-82ad-476a-91bb-209ef753c195_0">
											<gml:posList>35.672478266464445 139.73837282370476 36.404 35.67248551990337 139.73836951219505 36.404 35.67248551990337 139.73836951219505 37.406 35.672478266464445 139.73837282370476 37.406 35.672478266464445 139.73837282370476 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09fc1e95-eeb2-421c-9817-16866e9c88d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09fc1e95-eeb2-421c-9817-16866e9c88d2_0">
											<gml:posList>35.67248551990337 139.73836951219505 36.404 35.672483224476885 139.7383619811676 36.404 35.672483224476885 139.7383619811676 37.406 35.67248551990337 139.73836951219505 37.406 35.67248551990337 139.73836951219505 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-228dedd5-3f5f-4f0a-abc2-bf95eb3f9f15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-228dedd5-3f5f-4f0a-abc2-bf95eb3f9f15_0">
											<gml:posList>35.67250034214784 139.73836274519505 36.404 35.67250034214784 139.73836274519505 37.406 35.67249804671222 139.73835520311985 37.406 35.67249804671222 139.73835520311985 36.404 35.67250034214784 139.73836274519505 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e621f730-da80-4071-8515-4e52925edbf8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e621f730-da80-4071-8515-4e52925edbf8_0">
											<gml:posList>35.67250586781452 139.7383516368645 36.404 35.67249804671222 139.73835520311985 36.404 35.67249804671222 139.73835520311985 37.406 35.67250586781452 139.7383516368645 37.406 35.67250586781452 139.7383516368645 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22ce940f-d2d9-4f1f-a748-74635277eddb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22ce940f-d2d9-4f1f-a748-74635277eddb_0">
											<gml:posList>35.67250816325036 139.73835917894033 37.406 35.67250586781452 139.7383516368645 37.406 35.67249804671222 139.73835520311985 37.406 35.67250034214784 139.73836274519505 37.406 35.67250816325036 139.73835917894033 37.406</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a77aacce-5ee4-4a8b-9b9e-3ae5410259f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a77aacce-5ee4-4a8b-9b9e-3ae5410259f1_0">
											<gml:posList>35.67250034214784 139.73836274519505 36.404 35.67250816325036 139.73835917894033 36.404 35.67250816325036 139.73835917894033 37.406 35.67250034214784 139.73836274519505 37.406 35.67250034214784 139.73836274519505 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31586a99-953b-4944-be7b-e92ccf8186c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31586a99-953b-4944-be7b-e92ccf8186c1_0">
											<gml:posList>35.67250816325036 139.73835917894033 36.404 35.67250586781452 139.7383516368645 36.404 35.67250586781452 139.7383516368645 37.406 35.67250816325036 139.73835917894033 37.406 35.67250816325036 139.73835917894033 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b117541f-9c14-412b-9e1d-b29305f246a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b117541f-9c14-412b-9e1d-b29305f246a4_0">
											<gml:posList>35.67253116240458 139.73834283593195 36.404 35.672538029142764 139.73836350694975 36.404 35.672538029142764 139.73836350694975 37.306 35.67253116240458 139.73834283593195 37.306 35.67253116240458 139.73834283593195 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-214e8deb-352a-4572-bbc9-10f1800e4ee2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-214e8deb-352a-4572-bbc9-10f1800e4ee2_0">
											<gml:posList>35.672541569171415 139.73833765381283 36.404 35.67253116240458 139.73834283593195 36.404 35.67253116240458 139.73834283593195 37.306 35.672541569171415 139.73833765381283 37.306 35.672541569171415 139.73833765381283 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbd6d2ce-e17d-4e33-92c9-b1a34cfbf239">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbd6d2ce-e17d-4e33-92c9-b1a34cfbf239_0">
											<gml:posList>35.672538029142764 139.73836350694975 37.306 35.67254842689677 139.73835832484357 37.306 35.672541569171415 139.73833765381283 37.306 35.67253116240458 139.73834283593195 37.306 35.672538029142764 139.73836350694975 37.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35a7b63e-30fe-4d7a-9c48-8ac94aaa4c3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35a7b63e-30fe-4d7a-9c48-8ac94aaa4c3d_0">
											<gml:posList>35.672538029142764 139.73836350694975 36.404 35.67254842689677 139.73835832484357 36.404 35.67254842689677 139.73835832484357 37.306 35.672538029142764 139.73836350694975 37.306 35.672538029142764 139.73836350694975 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e470952-3fab-44d0-bf4a-f6bc13702127">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e470952-3fab-44d0-bf4a-f6bc13702127_0">
											<gml:posList>35.6725491197047 139.7383338890364 36.404 35.67254336220427 139.7383367679637 36.404 35.67254336220427 139.7383367679637 37.306 35.6725491197047 139.7383338890364 37.306 35.6725491197047 139.7383338890364 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef885f7e-ee8d-436b-9d0b-0c26a4da835f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef885f7e-ee8d-436b-9d0b-0c26a4da835f_0">
											<gml:posList>35.672550219921064 139.73835742794824 37.306 35.6725559774307 139.73835456006873 37.306 35.6725491197047 139.7383338890364 37.306 35.67254336220427 139.7383367679637 37.306 35.672550219921064 139.73835742794824 37.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fba40ab-5577-41d9-9c9d-57f579a216dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fba40ab-5577-41d9-9c9d-57f579a216dc_0">
											<gml:posList>35.6725491197047 139.7383338890364 37.306 35.6725559774307 139.73835456006873 37.306 35.6725559774307 139.73835456006873 36.404 35.6725491197047 139.7383338890364 36.404 35.6725491197047 139.7383338890364 37.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99185227-c987-4f30-9208-a03660ea9a7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99185227-c987-4f30-9208-a03660ea9a7e_0">
											<gml:posList>35.672550219921064 139.73835742794824 36.404 35.6725559774307 139.73835456006873 36.404 35.6725559774307 139.73835456006873 37.306 35.672550219921064 139.73835742794824 37.306 35.672550219921064 139.73835742794824 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaeb59b6-6600-46c1-aa2c-ed558168e0ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aaeb59b6-6600-46c1-aa2c-ed558168e0ec_0">
											<gml:posList>35.672592682660785 139.73832197340622 36.404 35.672595503325816 139.7383325968584 36.404 35.672595503325816 139.7383325968584 37.488 35.672592682660785 139.73832197340622 37.488 35.672592682660785 139.73832197340622 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff9f16dd-a328-4f91-ad11-9c5eeb502801">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff9f16dd-a328-4f91-ad11-9c5eeb502801_0">
											<gml:posList>35.67260006258661 139.73831903732045 36.404 35.672592682660785 139.73832197340622 36.404 35.672592682660785 139.73832197340622 37.488 35.67260006258661 139.73831903732045 37.488 35.67260006258661 139.73831903732045 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb5b1b7d-57e4-42f1-b1ce-05544a0927e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb5b1b7d-57e4-42f1-b1ce-05544a0927e1_0">
											<gml:posList>35.67260288324317 139.73832964972698 37.488 35.67260006258661 139.73831903732045 37.488 35.672592682660785 139.73832197340622 37.488 35.672595503325816 139.7383325968584 37.488 35.67260288324317 139.73832964972698 37.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9447a57-7d1e-4e2d-be83-fc71206b63ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9447a57-7d1e-4e2d-be83-fc71206b63ea_0">
											<gml:posList>35.672595503325816 139.7383325968584 36.404 35.67260288324317 139.73832964972698 36.404 35.67260288324317 139.73832964972698 37.488 35.672595503325816 139.7383325968584 37.488 35.672595503325816 139.7383325968584 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-228fe363-5324-4b97-a020-b27bfe410014">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-228fe363-5324-4b97-a020-b27bfe410014_0">
											<gml:posList>35.67260288324317 139.73832964972698 36.404 35.67260006258661 139.73831903732045 36.404 35.67260006258661 139.73831903732045 37.488 35.67260288324317 139.73832964972698 37.488 35.67260288324317 139.73832964972698 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ccb60ac-f42e-4d47-a5f1-2d81e6559b0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ccb60ac-f42e-4d47-a5f1-2d81e6559b0c_0">
											<gml:posList>35.67260807326344 139.738315835369 36.404 35.67261048708269 139.73832490173928 36.404 35.67261048708269 139.73832490173928 37.488 35.67260807326344 139.738315835369 37.488 35.67260807326344 139.738315835369 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-918f13f7-1472-4232-b5a1-d9251bb0cea1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-918f13f7-1472-4232-b5a1-d9251bb0cea1_0">
											<gml:posList>35.67261316441934 139.73831380781328 36.404 35.67260807326344 139.738315835369 36.404 35.67260807326344 139.738315835369 37.488 35.67261316441934 139.73831380781328 37.488 35.67261316441934 139.73831380781328 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-655ba5c2-8153-47c0-9b1a-116f7f218322">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-655ba5c2-8153-47c0-9b1a-116f7f218322_0">
											<gml:posList>35.67261316441934 139.73831380781328 37.488 35.67260807326344 139.738315835369 37.488 35.67261048708269 139.73832490173928 37.488 35.672615884600575 139.7383227412622 37.488 35.67261316441934 139.73831380781328 37.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a10df4c8-0105-490b-8ed7-6f62dcb64b52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a10df4c8-0105-490b-8ed7-6f62dcb64b52_0">
											<gml:posList>35.67261048708269 139.73832490173928 37.488 35.67261048708269 139.73832490173928 36.404 35.672615884600575 139.7383227412622 36.404 35.672615884600575 139.7383227412622 37.488 35.67261048708269 139.73832490173928 37.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3798486-82e2-4f71-9d12-3b0433d524d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3798486-82e2-4f71-9d12-3b0433d524d6_0">
											<gml:posList>35.672615884600575 139.7383227412622 37.488 35.672615884600575 139.7383227412622 36.404 35.67261316441934 139.73831380781328 36.404 35.67261316441934 139.73831380781328 37.488 35.672615884600575 139.7383227412622 37.488</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f20ee0f3-131e-486e-a50a-e42882088c54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f20ee0f3-131e-486e-a50a-e42882088c54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f20ee0f3-131e-486e-a50a-e42882088c54">
											<gml:posList>35.672484290929624 139.7384341691029 9.16 35.67242636257197 139.73824357437266 9.16 35.67246523379675 139.73822585379384 9.16 35.67247646022904 139.7382427637875 9.16 35.67253468596715 139.7382162161314 9.16 35.67253450637938 139.73819426683764 9.16 35.6725747652025 139.73817590386335 9.16 35.67262239127515 139.7383325981365 9.16 35.67253291711298 139.73837335548666 9.16 35.67254321949276 139.73840725621463 9.16 35.672484290929624 139.7384341691029 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5ee31b9d-398e-4601-b367-7e14758ba658">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ee31b9d-398e-4601-b367-7e14758ba658">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ee31b9d-398e-4601-b367-7e14758ba658">
											<gml:posList>35.67252072827457 139.73827907653768 22.129 35.67253569570136 139.73827353551357 21.434 35.67253509636083 139.73825650243467 21.434 35.67252072827457 139.73827907653768 22.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0b1ad616-a54d-4dac-a8d0-d36dc69c4c6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b1ad616-a54d-4dac-a8d0-d36dc69c4c6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b1ad616-a54d-4dac-a8d0-d36dc69c4c6e">
											<gml:posList>35.67243558954777 139.73827391932727 21.327 35.67246145863811 139.7382621130362 21.327 35.67244185158913 139.7382365083068 21.327 35.67242636257197 139.73824357437266 21.327 35.67243558954777 139.73827391932727 21.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fd370288-4167-43ad-ae82-083d0b7a001a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd370288-4167-43ad-ae82-083d0b7a001a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd370288-4167-43ad-ae82-083d0b7a001a">
											<gml:posList>35.672443045232434 139.73829844486002 25.126 35.67247669937931 139.7382830834043 25.126 35.67246145863811 139.7382621130362 25.126 35.67243558954777 139.73827391932727 25.126 35.672443045232434 139.73829844486002 25.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0292415d-8a00-46bf-a5bf-f8cbcc997f2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0292415d-8a00-46bf-a5bf-f8cbcc997f2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0292415d-8a00-46bf-a5bf-f8cbcc997f2a">
											<gml:posList>35.67246145863811 139.7382621130362 17.855 35.67248359857715 139.7382535146595 17.855 35.67246523379675 139.73822585379384 17.855 35.67244185158913 139.7382365083068 17.855 35.67246145863811 139.7382621130362 17.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d9f4d74-77d9-4978-832d-73e0e9031e00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d9f4d74-77d9-4978-832d-73e0e9031e00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d9f4d74-77d9-4978-832d-73e0e9031e00">
											<gml:posList>35.672450654563704 139.7383235004494 28.458 35.67249239110791 139.7383044398751 28.458 35.67247669937931 139.7382830834043 28.458 35.672443045232434 139.73829844486002 28.458 35.672450654563704 139.7383235004494 28.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd3e4ee8-3916-4dd2-8ee6-d655fdfe84cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd3e4ee8-3916-4dd2-8ee6-d655fdfe84cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd3e4ee8-3916-4dd2-8ee6-d655fdfe84cc">
											<gml:posList>35.672484290929624 139.7384341691029 37.825 35.67248624280595 139.73842896386768 37.825 35.67246053203557 139.73834435566891 37.825 35.67245630278873 139.73834206299838 37.825 35.672484290929624 139.7384341691029 37.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fed9b648-8625-434b-bcb8-6e312637c065">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fed9b648-8625-434b-bcb8-6e312637c065">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fed9b648-8625-434b-bcb8-6e312637c065">
											<gml:posList>35.67247669937931 139.7382830834043 21.327 35.67249899230011 139.73827416450038 21.327 35.6724909706094 139.73826341467196 21.327 35.67248359857715 139.7382535146595 21.327 35.67246145863811 139.7382621130362 21.327 35.67247669937931 139.7382830834043 21.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14786922-5f79-4b9b-a189-fd9dcd814fc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14786922-5f79-4b9b-a189-fd9dcd814fc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14786922-5f79-4b9b-a189-fd9dcd814fc3">
											<gml:posList>35.67251262864947 139.73829520306182 32.142 35.672450654563704 139.7383235004494 32.142 35.67245630278873 139.73834206299838 32.142 35.67252411415969 139.73830918543112 32.142 35.67251262864947 139.73829520306182 32.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dcc8ee8b-406c-4942-a270-a87674edeeb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcc8ee8b-406c-4942-a270-a87674edeeb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcc8ee8b-406c-4942-a270-a87674edeeb9">
											<gml:posList>35.67248359857715 139.7382535146595 17.69 35.67250625786671 139.7382291411856 19.386 35.67247646022904 139.7382427637875 17.69 35.67248359857715 139.7382535146595 17.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f783728d-0516-4f35-913b-e3cc9278fe6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f783728d-0516-4f35-913b-e3cc9278fe6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f783728d-0516-4f35-913b-e3cc9278fe6a">
											<gml:posList>35.67249239110791 139.7383044398751 25.126 35.67251262864947 139.73829520306182 25.126 35.67249899230011 139.73827416450038 25.126 35.67247669937931 139.7382830834043 25.126 35.67249239110791 139.7383044398751 25.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-384d4dd1-6f8d-4d72-aeaf-c7c311da5313">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-384d4dd1-6f8d-4d72-aeaf-c7c311da5313">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-384d4dd1-6f8d-4d72-aeaf-c7c311da5313">
											<gml:posList>35.67248359857715 139.7382535146595 17.69 35.67251335211323 139.73825252936945 19.386 35.67250625786671 139.7382291411856 19.386 35.67248359857715 139.7382535146595 17.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-194ead58-d7c5-4ab7-9d41-b1ce69008015">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-194ead58-d7c5-4ab7-9d41-b1ce69008015">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-194ead58-d7c5-4ab7-9d41-b1ce69008015">
											<gml:posList>35.67248359857715 139.7382535146595 17.69 35.6724909706094 139.73826341467196 17.69 35.67251335211323 139.73825252936945 19.386 35.67248359857715 139.7382535146595 17.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56ccf9d2-a6d4-45cc-a47c-685f5120ee76">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56ccf9d2-a6d4-45cc-a47c-685f5120ee76">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56ccf9d2-a6d4-45cc-a47c-685f5120ee76">
											<gml:posList>35.67251335209579 139.73825250727634 22.129 35.6724909706094 139.73826341467196 21.434 35.67249899230011 139.73827416450038 21.434 35.67251335209579 139.73825250727634 22.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae02de12-82ec-478c-bdf6-8085bc095139">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae02de12-82ec-478c-bdf6-8085bc095139">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae02de12-82ec-478c-bdf6-8085bc095139">
											<gml:posList>35.67251335209579 139.73825250727634 22.129 35.67249899230011 139.73827416450038 21.434 35.6725057698612 139.73828461754903 21.434 35.67251335209579 139.73825250727634 22.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2b3e0a8a-4cb7-4e00-baaa-e5a533d678df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b3e0a8a-4cb7-4e00-baaa-e5a533d678df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b3e0a8a-4cb7-4e00-baaa-e5a533d678df">
											<gml:posList>35.67251335209579 139.73825250727634 22.129 35.6725057698612 139.73828461754903 21.434 35.67252072827457 139.73827907653768 22.129 35.67251335209579 139.73825250727634 22.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e60d74fc-4453-42cd-af5f-3b13098692c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e60d74fc-4453-42cd-af5f-3b13098692c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e60d74fc-4453-42cd-af5f-3b13098692c4">
											<gml:posList>35.67254321949276 139.73840725621463 37.825 35.67253898116378 139.73840487517674 37.825 35.67248624280595 139.73842896386768 37.825 35.672484290929624 139.7384341691029 37.825 35.67254321949276 139.73840725621463 37.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5700f97-80f9-4b2e-bb2c-000e815542e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5700f97-80f9-4b2e-bb2c-000e815542e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5700f97-80f9-4b2e-bb2c-000e815542e2">
											<gml:posList>35.67250625786671 139.7382291411856 19.386 35.67251335211323 139.73825252936945 19.386 35.67253493167417 139.73824199850185 17.69 35.67250625786671 139.7382291411856 19.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81043278-2b78-42e2-918f-852e34564773">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81043278-2b78-42e2-918f-852e34564773">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81043278-2b78-42e2-918f-852e34564773">
											<gml:posList>35.67253493167417 139.73824199850185 17.69 35.67253468596715 139.7382162161314 17.69 35.67250625786671 139.7382291411856 19.386 35.67253493167417 139.73824199850185 17.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f0bbe53-96cb-4b2c-b51d-363c7552d4b5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f0bbe53-96cb-4b2c-b51d-363c7552d4b5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f0bbe53-96cb-4b2c-b51d-363c7552d4b5">
											<gml:posList>35.67253569570136 139.73827353551357 24.851 35.6725057698612 139.73828461754903 24.851 35.67251262864947 139.73829520306182 24.851 35.67252411415969 139.73830918543112 24.851 35.672536115847684 139.73830336071734 24.851 35.67253605537255 139.7382838415241 24.851 35.67253569570136 139.73827353551357 24.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-75eff7c2-5258-4416-ae5e-5332ee4c2dea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75eff7c2-5258-4416-ae5e-5332ee4c2dea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75eff7c2-5258-4416-ae5e-5332ee4c2dea">
											<gml:posList>35.67252072827457 139.73827907653768 22.129 35.67253493167417 139.73824199850185 21.434 35.67251335209579 139.73825250727634 22.129 35.67252072827457 139.73827907653768 22.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bedd3467-540c-49d5-804e-dd94311f188d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bedd3467-540c-49d5-804e-dd94311f188d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bedd3467-540c-49d5-804e-dd94311f188d">
											<gml:posList>35.67252072827457 139.73827907653768 22.129 35.67253509636083 139.73825650243467 21.434 35.67253493167417 139.73824199850185 21.434 35.67252072827457 139.73827907653768 22.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea68d620-d732-4304-b3fa-f984feb86ce1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea68d620-d732-4304-b3fa-f984feb86ce1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea68d620-d732-4304-b3fa-f984feb86ce1">
											<gml:posList>35.67245630278873 139.73834206299838 37.825 35.67246053203557 139.73834435566891 37.825 35.6726016510269 139.73827592069358 37.825 35.672603566789135 139.7382706492103 37.825 35.67245630278873 139.73834206299838 37.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-34be0c0c-21f9-431d-afcc-3d4cbe456c53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34be0c0c-21f9-431d-afcc-3d4cbe456c53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34be0c0c-21f9-431d-afcc-3d4cbe456c53">
											<gml:posList>35.67253291711298 139.73837335548666 37.825 35.67252867877461 139.73837096340435 37.825 35.67253898116378 139.73840487517674 37.825 35.67254321949276 139.73840725621463 37.825 35.67253291711298 139.73837335548666 37.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dfde5e0f-228a-49fe-ab0e-63d4683684de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfde5e0f-228a-49fe-ab0e-63d4683684de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfde5e0f-228a-49fe-ab0e-63d4683684de">
											<gml:posList>35.67252867877461 139.73837096340435 36.404 35.67261815294474 139.73833021710027 36.404 35.6726016510269 139.73827592069358 36.404 35.67246053203557 139.73834435566891 36.404 35.67248624280595 139.73842896386768 36.404 35.67253898116378 139.73840487517674 36.404 35.67252867877461 139.73837096340435 36.404</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f5dc1624-f9f9-406d-b844-f2d095476a5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5dc1624-f9f9-406d-b844-f2d095476a5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5dc1624-f9f9-406d-b844-f2d095476a5c">
											<gml:posList>35.6725549947222 139.73821726355277 17.855 35.672553932974395 139.73818540653713 17.855 35.67253450637938 139.73819426683764 17.855 35.672534776208884 139.73822775967545 17.855 35.6725549947222 139.73821726355277 17.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e85370b-1d93-4e2c-8ffa-25b1f893c1c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e85370b-1d93-4e2c-8ffa-25b1f893c1c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e85370b-1d93-4e2c-8ffa-25b1f893c1c0">
											<gml:posList>35.67253509636083 139.73825650243467 21.327 35.67255566626339 139.73824581811095 21.327 35.6725549947222 139.73821726355277 21.327 35.672534776208884 139.73822775967545 21.327 35.67253493167417 139.73824199850185 21.327 35.67253509636083 139.73825650243467 21.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a6a3ea05-4ce9-4478-a057-4d55b9201736">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6a3ea05-4ce9-4478-a057-4d55b9201736">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6a3ea05-4ce9-4478-a057-4d55b9201736">
											<gml:posList>35.67255611270777 139.73827469328674 25.126 35.67255566626339 139.73824581811095 25.126 35.67253509636083 139.73825650243467 25.126 35.67253605537255 139.7382838415241 25.126 35.67255611270777 139.73827469328674 25.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2be69616-d5cd-4f2b-979c-adfce1de337e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2be69616-d5cd-4f2b-979c-adfce1de337e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2be69616-d5cd-4f2b-979c-adfce1de337e">
											<gml:posList>35.672553932974395 139.73818540653713 21.327 35.6725549947222 139.73821726355277 21.327 35.67258339575377 139.73820430537893 21.327 35.6725747652025 139.73817590386335 21.327 35.672553932974395 139.73818540653713 21.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-48096355-82ce-48d2-89cb-4f93292bab1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48096355-82ce-48d2-89cb-4f93292bab1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48096355-82ce-48d2-89cb-4f93292bab1f">
											<gml:posList>35.672603566789135 139.7382706492103 32.142 35.6725988584223 139.73825517855582 32.142 35.67253605537255 139.7382838415241 32.142 35.672536115847684 139.73830336071734 32.142 35.672603566789135 139.7382706492103 32.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-42c1e503-cc65-40e7-9703-e0bac243d590">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42c1e503-cc65-40e7-9703-e0bac243d590">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42c1e503-cc65-40e7-9703-e0bac243d590">
											<gml:posList>35.6725549947222 139.73821726355277 25.126 35.67255566626339 139.73824581811095 25.126 35.67259110447355 139.7382296370494 25.126 35.67258339575377 139.73820430537893 25.126 35.6725549947222 139.73821726355277 25.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a7f218a-1212-4161-bd75-34229fc62cf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a7f218a-1212-4161-bd75-34229fc62cf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a7f218a-1212-4161-bd75-34229fc62cf9">
											<gml:posList>35.67253291711298 139.73837335548666 37.825 35.67262239127515 139.7383325981365 37.825 35.67261815294474 139.73833021710027 37.825 35.67252867877461 139.73837096340435 37.825 35.67253291711298 139.73837335548666 37.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96a7b576-87a5-499a-bb41-41b49ef5e04e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96a7b576-87a5-499a-bb41-41b49ef5e04e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96a7b576-87a5-499a-bb41-41b49ef5e04e">
											<gml:posList>35.6725988584223 139.73825517855582 28.458 35.67259110447355 139.7382296370494 28.458 35.67255566626339 139.73824581811095 28.458 35.67255611270777 139.73827469328674 28.458 35.6725988584223 139.73825517855582 28.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3157dc5-4bd2-4ea8-9610-323ccc2e959f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3157dc5-4bd2-4ea8-9610-323ccc2e959f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3157dc5-4bd2-4ea8-9610-323ccc2e959f">
											<gml:posList>35.672603566789135 139.7382706492103 37.825 35.6726016510269 139.73827592069358 37.825 35.67261815294474 139.73833021710027 37.825 35.67262239127515 139.7383325981365 37.825 35.672603566789135 139.7382706492103 37.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3488911-8eed-43e9-acb7-1fda51620c26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3488911-8eed-43e9-acb7-1fda51620c26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3488911-8eed-43e9-acb7-1fda51620c26">
											<gml:posList>35.67261815294474 139.73833021710027 37.825 35.67261815294474 139.73833021710027 36.404 35.67252867877461 139.73837096340435 36.404 35.67252867877461 139.73837096340435 37.825 35.67261815294474 139.73833021710027 37.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49d7539d-7170-47f0-8b7f-30f62787ad20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49d7539d-7170-47f0-8b7f-30f62787ad20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49d7539d-7170-47f0-8b7f-30f62787ad20">
											<gml:posList>35.67242636257197 139.73824357437266 9.16 35.67242636257197 139.73824357437266 21.327 35.67244185158913 139.7382365083068 21.327 35.67244185158913 139.7382365083068 17.855 35.67246523379675 139.73822585379384 17.855 35.67246523379675 139.73822585379384 9.16 35.67242636257197 139.73824357437266 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df3a1373-d2cf-41a1-979f-72f459818062">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df3a1373-d2cf-41a1-979f-72f459818062">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df3a1373-d2cf-41a1-979f-72f459818062">
											<gml:posList>35.67243558954777 139.73827391932727 25.126 35.67246145863811 139.7382621130362 25.126 35.67246145863811 139.7382621130362 21.327 35.67243558954777 139.73827391932727 21.327 35.67243558954777 139.73827391932727 25.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62181c39-9a77-42b2-8129-47a9a6c724a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62181c39-9a77-42b2-8129-47a9a6c724a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62181c39-9a77-42b2-8129-47a9a6c724a1">
											<gml:posList>35.67244185158913 139.7382365083068 17.855 35.67244185158913 139.7382365083068 21.327 35.67246145863811 139.7382621130362 21.327 35.67246145863811 139.7382621130362 17.855 35.67244185158913 139.7382365083068 17.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70a252a7-6ba9-4845-8d71-60aebef20771">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70a252a7-6ba9-4845-8d71-60aebef20771">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70a252a7-6ba9-4845-8d71-60aebef20771">
											<gml:posList>35.672484290929624 139.7384341691029 9.16 35.672484290929624 139.7384341691029 37.825 35.67245630278873 139.73834206299838 37.825 35.67245630278873 139.73834206299838 32.142 35.672450654563704 139.7383235004494 32.142 35.672450654563704 139.7383235004494 28.458 35.672443045232434 139.73829844486002 28.458 35.672443045232434 139.73829844486002 25.126 35.67243558954777 139.73827391932727 25.126 35.67243558954777 139.73827391932727 21.327 35.67242636257197 139.73824357437266 21.327 35.67242636257197 139.73824357437266 9.16 35.672484290929624 139.7384341691029 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fd053ed-4074-4a51-b483-b5c02374d6c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fd053ed-4074-4a51-b483-b5c02374d6c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fd053ed-4074-4a51-b483-b5c02374d6c4">
											<gml:posList>35.672443045232434 139.73829844486002 28.458 35.67247669937931 139.7382830834043 28.458 35.67247669937931 139.7382830834043 25.126 35.672443045232434 139.73829844486002 25.126 35.672443045232434 139.73829844486002 28.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66817e8f-f88b-4576-8b84-041ad52f058f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66817e8f-f88b-4576-8b84-041ad52f058f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66817e8f-f88b-4576-8b84-041ad52f058f">
											<gml:posList>35.67246145863811 139.7382621130362 25.126 35.67247669937931 139.7382830834043 25.126 35.67247669937931 139.7382830834043 21.327 35.67246145863811 139.7382621130362 21.327 35.67246145863811 139.7382621130362 25.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9ca3e6d-17a9-4b8a-8133-03e4da6541d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9ca3e6d-17a9-4b8a-8133-03e4da6541d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9ca3e6d-17a9-4b8a-8133-03e4da6541d7">
											<gml:posList>35.67246145863811 139.7382621130362 17.855 35.67246145863811 139.7382621130362 21.327 35.67248359857715 139.7382535146595 21.327 35.67248359857715 139.7382535146595 17.855 35.67246145863811 139.7382621130362 17.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99122370-e3b4-4dbe-8ea7-76fbef6352fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99122370-e3b4-4dbe-8ea7-76fbef6352fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99122370-e3b4-4dbe-8ea7-76fbef6352fd">
											<gml:posList>35.67248624280595 139.73842896386768 37.825 35.67248624280595 139.73842896386768 36.404 35.67246053203557 139.73834435566891 36.404 35.67246053203557 139.73834435566891 37.825 35.67248624280595 139.73842896386768 37.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97408fb8-c567-475f-bccb-2e11a68e88a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97408fb8-c567-475f-bccb-2e11a68e88a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97408fb8-c567-475f-bccb-2e11a68e88a6">
											<gml:posList>35.67247646022904 139.7382427637875 17.69 35.67247646022904 139.7382427637875 9.16 35.67246523379675 139.73822585379384 9.16 35.67246523379675 139.73822585379384 17.855 35.67248359857715 139.7382535146595 17.855 35.67248359857715 139.7382535146595 17.69 35.67247646022904 139.7382427637875 17.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c3dd6d5-7393-4b79-9b29-fd0a852c2d40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c3dd6d5-7393-4b79-9b29-fd0a852c2d40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c3dd6d5-7393-4b79-9b29-fd0a852c2d40">
											<gml:posList>35.67251262864947 139.73829520306182 32.142 35.67251262864947 139.73829520306182 25.126 35.67249239110791 139.7383044398751 25.126 35.67249239110791 139.7383044398751 28.458 35.672450654563704 139.7383235004494 28.458 35.672450654563704 139.7383235004494 32.142 35.67251262864947 139.73829520306182 32.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-001ab24e-d7a4-40fc-9a01-a420932c9dee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-001ab24e-d7a4-40fc-9a01-a420932c9dee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-001ab24e-d7a4-40fc-9a01-a420932c9dee">
											<gml:posList>35.67247669937931 139.7382830834043 28.458 35.67249239110791 139.7383044398751 28.458 35.67249239110791 139.7383044398751 25.126 35.67247669937931 139.7382830834043 25.126 35.67247669937931 139.7382830834043 28.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ba760e4-40b2-4c38-9512-c856350dd19a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ba760e4-40b2-4c38-9512-c856350dd19a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ba760e4-40b2-4c38-9512-c856350dd19a">
											<gml:posList>35.6724909706094 139.73826341467196 17.69 35.67248359857715 139.7382535146595 17.69 35.67248359857715 139.7382535146595 17.855 35.67248359857715 139.7382535146595 21.327 35.6724909706094 139.73826341467196 21.327 35.6724909706094 139.73826341467196 17.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c486b4a1-e0c8-4781-a8ea-4c61fcbf7732">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c486b4a1-e0c8-4781-a8ea-4c61fcbf7732">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c486b4a1-e0c8-4781-a8ea-4c61fcbf7732">
											<gml:posList>35.67247669937931 139.7382830834043 21.327 35.67247669937931 139.7382830834043 25.126 35.67249899230011 139.73827416450038 25.126 35.67249899230011 139.73827416450038 21.434 35.67249899230011 139.73827416450038 21.327 35.67247669937931 139.7382830834043 21.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d27a8fa0-9b39-4564-8eba-9d93b7f6b00d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d27a8fa0-9b39-4564-8eba-9d93b7f6b00d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d27a8fa0-9b39-4564-8eba-9d93b7f6b00d">
											<gml:posList>35.67249899230011 139.73827416450038 21.434 35.6724909706094 139.73826341467196 21.434 35.6724909706094 139.73826341467196 21.327 35.67249899230011 139.73827416450038 21.327 35.67249899230011 139.73827416450038 21.434</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2e8952e7-57bc-4607-ba0b-95301a032487">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e8952e7-57bc-4607-ba0b-95301a032487">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e8952e7-57bc-4607-ba0b-95301a032487">
											<gml:posList>35.67247646022904 139.7382427637875 17.69 35.67250625786671 139.7382291411856 19.386 35.67253468596715 139.7382162161314 17.69 35.67253468596715 139.7382162161314 9.16 35.67247646022904 139.7382427637875 9.16 35.67247646022904 139.7382427637875 17.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdeca82d-d3b4-40bb-b7e3-40780a184ed0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdeca82d-d3b4-40bb-b7e3-40780a184ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdeca82d-d3b4-40bb-b7e3-40780a184ed0">
											<gml:posList>35.6725057698612 139.73828461754903 24.851 35.6725057698612 139.73828461754903 21.434 35.67249899230011 139.73827416450038 21.434 35.67249899230011 139.73827416450038 25.126 35.67251262864947 139.73829520306182 25.126 35.67251262864947 139.73829520306182 24.851 35.6725057698612 139.73828461754903 24.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4be2cbd-6eaf-402c-9cca-b8ef9213d635">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4be2cbd-6eaf-402c-9cca-b8ef9213d635">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4be2cbd-6eaf-402c-9cca-b8ef9213d635">
											<gml:posList>35.67253898116378 139.73840487517674 37.825 35.67253898116378 139.73840487517674 36.404 35.67248624280595 139.73842896386768 36.404 35.67248624280595 139.73842896386768 37.825 35.67253898116378 139.73840487517674 37.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-299c39f5-79c0-4f87-9480-85f1f70d63b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-299c39f5-79c0-4f87-9480-85f1f70d63b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-299c39f5-79c0-4f87-9480-85f1f70d63b9">
											<gml:posList>35.6724909706094 139.73826341467196 21.327 35.6724909706094 139.73826341467196 21.434 35.67251335209579 139.73825250727634 22.129 35.67253493167417 139.73824199850185 21.434 35.67253493167417 139.73824199850185 21.327 35.67253493167417 139.73824199850185 17.69 35.67251335211323 139.73825252936945 19.386 35.6724909706094 139.73826341467196 17.69 35.6724909706094 139.73826341467196 21.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9066b6d8-f3cf-4e1c-82c6-3ca8634f8f8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9066b6d8-f3cf-4e1c-82c6-3ca8634f8f8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9066b6d8-f3cf-4e1c-82c6-3ca8634f8f8e">
											<gml:posList>35.672484290929624 139.7384341691029 9.16 35.67254321949276 139.73840725621463 9.16 35.67254321949276 139.73840725621463 37.825 35.672484290929624 139.7384341691029 37.825 35.672484290929624 139.7384341691029 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bf40d42-74af-46a6-8453-47215701b5f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bf40d42-74af-46a6-8453-47215701b5f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bf40d42-74af-46a6-8453-47215701b5f2">
											<gml:posList>35.67252411415969 139.73830918543112 24.851 35.67251262864947 139.73829520306182 24.851 35.67251262864947 139.73829520306182 25.126 35.67251262864947 139.73829520306182 32.142 35.67252411415969 139.73830918543112 32.142 35.67252411415969 139.73830918543112 24.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b538e6e2-ec14-489e-b85c-338d8db2ed44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b538e6e2-ec14-489e-b85c-338d8db2ed44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b538e6e2-ec14-489e-b85c-338d8db2ed44">
											<gml:posList>35.6725057698612 139.73828461754903 24.851 35.67253569570136 139.73827353551357 24.851 35.67253569570136 139.73827353551357 21.434 35.67252072827457 139.73827907653768 22.129 35.6725057698612 139.73828461754903 21.434 35.6725057698612 139.73828461754903 24.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d75fc26b-4223-4d88-9b45-046a0b90a530">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d75fc26b-4223-4d88-9b45-046a0b90a530">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d75fc26b-4223-4d88-9b45-046a0b90a530">
											<gml:posList>35.67252411415969 139.73830918543112 32.142 35.67245630278873 139.73834206299838 32.142 35.67245630278873 139.73834206299838 37.825 35.672603566789135 139.7382706492103 37.825 35.672603566789135 139.7382706492103 32.142 35.672536115847684 139.73830336071734 32.142 35.672536115847684 139.73830336071734 24.851 35.67252411415969 139.73830918543112 24.851 35.67252411415969 139.73830918543112 32.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e320c0d3-d27b-446c-b762-277abd7725f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e320c0d3-d27b-446c-b762-277abd7725f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e320c0d3-d27b-446c-b762-277abd7725f9">
											<gml:posList>35.67246053203557 139.73834435566891 37.825 35.67246053203557 139.73834435566891 36.404 35.6726016510269 139.73827592069358 36.404 35.6726016510269 139.73827592069358 37.825 35.67246053203557 139.73834435566891 37.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9266ed97-ae84-41c7-af02-478a82d2092c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9266ed97-ae84-41c7-af02-478a82d2092c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9266ed97-ae84-41c7-af02-478a82d2092c">
											<gml:posList>35.67252867877461 139.73837096340435 37.825 35.67252867877461 139.73837096340435 36.404 35.67253898116378 139.73840487517674 36.404 35.67253898116378 139.73840487517674 37.825 35.67252867877461 139.73837096340435 37.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c4b4b25-591e-4c42-bb27-6b9364e75737">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c4b4b25-591e-4c42-bb27-6b9364e75737">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c4b4b25-591e-4c42-bb27-6b9364e75737">
											<gml:posList>35.67253450637938 139.73819426683764 17.855 35.67253450637938 139.73819426683764 9.16 35.67253468596715 139.7382162161314 9.16 35.67253468596715 139.7382162161314 17.69 35.67253493167417 139.73824199850185 17.69 35.67253493167417 139.73824199850185 21.327 35.672534776208884 139.73822775967545 21.327 35.672534776208884 139.73822775967545 17.855 35.67253450637938 139.73819426683764 17.855</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-62e07824-f84f-4489-9dab-4528adbb9891">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62e07824-f84f-4489-9dab-4528adbb9891">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62e07824-f84f-4489-9dab-4528adbb9891">
											<gml:posList>35.67253493167417 139.73824199850185 21.327 35.67253493167417 139.73824199850185 21.434 35.67253509636083 139.73825650243467 21.434 35.67253509636083 139.73825650243467 21.327 35.67253493167417 139.73824199850185 21.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78bfeae3-1bf9-47ca-aed3-13767e9149f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78bfeae3-1bf9-47ca-aed3-13767e9149f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78bfeae3-1bf9-47ca-aed3-13767e9149f7">
											<gml:posList>35.67253509636083 139.73825650243467 25.126 35.67253509636083 139.73825650243467 21.434 35.67253569570136 139.73827353551357 21.434 35.67253569570136 139.73827353551357 24.851 35.67253605537255 139.7382838415241 24.851 35.67253605537255 139.7382838415241 25.126 35.67253509636083 139.73825650243467 25.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44f167de-4026-4cf5-aa14-3773a998afaa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44f167de-4026-4cf5-aa14-3773a998afaa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44f167de-4026-4cf5-aa14-3773a998afaa">
											<gml:posList>35.672536115847684 139.73830336071734 24.851 35.672536115847684 139.73830336071734 32.142 35.67253605537255 139.7382838415241 32.142 35.67253605537255 139.7382838415241 25.126 35.67253605537255 139.7382838415241 24.851 35.672536115847684 139.73830336071734 24.851</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-335c9df8-2568-4f28-a546-7bc9bd170c53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-335c9df8-2568-4f28-a546-7bc9bd170c53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-335c9df8-2568-4f28-a546-7bc9bd170c53">
											<gml:posList>35.67254321949276 139.73840725621463 9.16 35.67253291711298 139.73837335548666 9.16 35.67253291711298 139.73837335548666 37.825 35.67254321949276 139.73840725621463 37.825 35.67254321949276 139.73840725621463 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-761c18d0-e348-4b3c-aed8-b4a41d6e6734">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-761c18d0-e348-4b3c-aed8-b4a41d6e6734">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-761c18d0-e348-4b3c-aed8-b4a41d6e6734">
											<gml:posList>35.672534776208884 139.73822775967545 21.327 35.6725549947222 139.73821726355277 21.327 35.6725549947222 139.73821726355277 17.855 35.672534776208884 139.73822775967545 17.855 35.672534776208884 139.73822775967545 21.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a101bf3-b71a-4a37-a951-04889c764c70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a101bf3-b71a-4a37-a951-04889c764c70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a101bf3-b71a-4a37-a951-04889c764c70">
											<gml:posList>35.67255566626339 139.73824581811095 21.327 35.67253509636083 139.73825650243467 21.327 35.67253509636083 139.73825650243467 21.434 35.67253509636083 139.73825650243467 25.126 35.67255566626339 139.73824581811095 25.126 35.67255566626339 139.73824581811095 21.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cedfa4bf-0a65-40fd-b02e-fbca4096261e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cedfa4bf-0a65-40fd-b02e-fbca4096261e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cedfa4bf-0a65-40fd-b02e-fbca4096261e">
											<gml:posList>35.6725549947222 139.73821726355277 21.327 35.672553932974395 139.73818540653713 21.327 35.672553932974395 139.73818540653713 17.855 35.6725549947222 139.73821726355277 17.855 35.6725549947222 139.73821726355277 21.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc20d7e8-d126-412d-93df-1f2dbb0d8c2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc20d7e8-d126-412d-93df-1f2dbb0d8c2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc20d7e8-d126-412d-93df-1f2dbb0d8c2d">
											<gml:posList>35.67253450637938 139.73819426683764 9.16 35.67253450637938 139.73819426683764 17.855 35.672553932974395 139.73818540653713 17.855 35.672553932974395 139.73818540653713 21.327 35.6725747652025 139.73817590386335 21.327 35.6725747652025 139.73817590386335 9.16 35.67253450637938 139.73819426683764 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f1edc543-65c7-4acf-ad7b-3fad4bcb4682">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1edc543-65c7-4acf-ad7b-3fad4bcb4682">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1edc543-65c7-4acf-ad7b-3fad4bcb4682">
											<gml:posList>35.67255566626339 139.73824581811095 25.126 35.6725549947222 139.73821726355277 25.126 35.6725549947222 139.73821726355277 21.327 35.67255566626339 139.73824581811095 21.327 35.67255566626339 139.73824581811095 25.126</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c65f0a47-e7f2-481f-9928-6bd304c2bda0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c65f0a47-e7f2-481f-9928-6bd304c2bda0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c65f0a47-e7f2-481f-9928-6bd304c2bda0">
											<gml:posList>35.67255611270777 139.73827469328674 28.458 35.67255566626339 139.73824581811095 28.458 35.67255566626339 139.73824581811095 25.126 35.67255611270777 139.73827469328674 25.126 35.67255611270777 139.73827469328674 28.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9ea405c-72dd-49f5-af8b-a7c15e9bc412">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9ea405c-72dd-49f5-af8b-a7c15e9bc412">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9ea405c-72dd-49f5-af8b-a7c15e9bc412">
											<gml:posList>35.67255611270777 139.73827469328674 28.458 35.67255611270777 139.73827469328674 25.126 35.67253605537255 139.7382838415241 25.126 35.67253605537255 139.7382838415241 32.142 35.6725988584223 139.73825517855582 32.142 35.6725988584223 139.73825517855582 28.458 35.67255611270777 139.73827469328674 28.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-359ee70b-b717-4224-a746-9c5a247c16b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-359ee70b-b717-4224-a746-9c5a247c16b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-359ee70b-b717-4224-a746-9c5a247c16b6">
											<gml:posList>35.6725549947222 139.73821726355277 21.327 35.6725549947222 139.73821726355277 25.126 35.67258339575377 139.73820430537893 25.126 35.67258339575377 139.73820430537893 21.327 35.6725549947222 139.73821726355277 21.327</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c82dec81-d320-4b6d-bc28-70690d3b1fd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c82dec81-d320-4b6d-bc28-70690d3b1fd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c82dec81-d320-4b6d-bc28-70690d3b1fd2">
											<gml:posList>35.67255566626339 139.73824581811095 28.458 35.67259110447355 139.7382296370494 28.458 35.67259110447355 139.7382296370494 25.126 35.67255566626339 139.73824581811095 25.126 35.67255566626339 139.73824581811095 28.458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f985eeca-00e4-45d2-baa8-aa2b115eab14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f985eeca-00e4-45d2-baa8-aa2b115eab14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f985eeca-00e4-45d2-baa8-aa2b115eab14">
											<gml:posList>35.67253291711298 139.73837335548666 9.16 35.67262239127515 139.7383325981365 9.16 35.67262239127515 139.7383325981365 37.825 35.67253291711298 139.73837335548666 37.825 35.67253291711298 139.73837335548666 9.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51f5e0fd-0132-44e0-b9fd-978253cd18ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51f5e0fd-0132-44e0-b9fd-978253cd18ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51f5e0fd-0132-44e0-b9fd-978253cd18ad">
											<gml:posList>35.672603566789135 139.7382706492103 32.142 35.672603566789135 139.7382706492103 37.825 35.67262239127515 139.7383325981365 37.825 35.67262239127515 139.7383325981365 9.16 35.6725747652025 139.73817590386335 9.16 35.6725747652025 139.73817590386335 21.327 35.67258339575377 139.73820430537893 21.327 35.67258339575377 139.73820430537893 25.126 35.67259110447355 139.7382296370494 25.126 35.67259110447355 139.7382296370494 28.458 35.6725988584223 139.73825517855582 28.458 35.6725988584223 139.73825517855582 32.142 35.672603566789135 139.7382706492103 32.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-461202b6-ead6-47c9-8b52-e7b214bac3a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-461202b6-ead6-47c9-8b52-e7b214bac3a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-461202b6-ead6-47c9-8b52-e7b214bac3a4">
											<gml:posList>35.6726016510269 139.73827592069358 37.825 35.6726016510269 139.73827592069358 36.404 35.67261815294474 139.73833021710027 36.404 35.67261815294474 139.73833021710027 37.825 35.6726016510269 139.73827592069358 37.825</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6711</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">288.7268</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>