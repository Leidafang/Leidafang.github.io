<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3b0e03ff-b4f5-42e0-98e2-98083844e7a5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">4.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66694592038152 139.74672183854076 0 35.66695471116582 139.74670010198045 0 35.66696515363366 139.74670644202763 0 35.66698093565071 139.74666742228757 0 35.66686963042976 139.74659982092945 0 35.6668502313402 139.74664776952434 0 35.66683877888607 139.74664081202255 0 35.66681574471835 139.74669777786434 0 35.66688049163674 139.74673710820127 0 35.66687607374311 139.74674802620024 0 35.66692609477778 139.746778403324 0 35.66693756691452 139.74675005850034 0 35.666946223883016 139.74675531799335 0 35.66695703917185 139.74672858655381 0 35.66694592038152 139.74672183854076 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66694592038152 139.74672183854076 7.55 35.66695703917185 139.74672858655381 7.55 35.666946223883016 139.74675531799335 7.55 35.66693756691452 139.74675005850034 7.55 35.66692609477778 139.746778403324 7.55 35.66687607374311 139.74674802620024 7.55 35.66688049163674 139.74673710820127 7.55 35.66681574471835 139.74669777786434 7.55 35.66683877888607 139.74664081202255 7.55 35.6668502313402 139.74664776952434 7.55 35.66686963042976 139.74659982092945 7.55 35.66698093565071 139.74666742228757 7.55 35.66696515363366 139.74670644202763 7.55 35.66695471116582 139.74670010198045 7.55 35.66694592038152 139.74672183854076 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66694592038152 139.74672183854076 7.55 35.66695471116582 139.74670010198045 7.55 35.66695471116582 139.74670010198045 11.96 35.66694592038152 139.74672183854076 11.96 35.66694592038152 139.74672183854076 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66695471116582 139.74670010198045 7.55 35.66696515363366 139.74670644202763 7.55 35.66696515363366 139.74670644202763 11.96 35.66695471116582 139.74670010198045 11.96 35.66695471116582 139.74670010198045 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66696515363366 139.74670644202763 7.55 35.66698093565071 139.74666742228757 7.55 35.66698093565071 139.74666742228757 11.96 35.66696515363366 139.74670644202763 11.96 35.66696515363366 139.74670644202763 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66698093565071 139.74666742228757 7.55 35.66686963042976 139.74659982092945 7.55 35.66686963042976 139.74659982092945 11.96 35.66698093565071 139.74666742228757 11.96 35.66698093565071 139.74666742228757 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66686963042976 139.74659982092945 7.55 35.6668502313402 139.74664776952434 7.55 35.6668502313402 139.74664776952434 11.96 35.66686963042976 139.74659982092945 11.96 35.66686963042976 139.74659982092945 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6668502313402 139.74664776952434 7.55 35.66683877888607 139.74664081202255 7.55 35.66683877888607 139.74664081202255 11.96 35.6668502313402 139.74664776952434 11.96 35.6668502313402 139.74664776952434 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66683877888607 139.74664081202255 7.55 35.66681574471835 139.74669777786434 7.55 35.66681574471835 139.74669777786434 11.96 35.66683877888607 139.74664081202255 11.96 35.66683877888607 139.74664081202255 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66681574471835 139.74669777786434 7.55 35.66688049163674 139.74673710820127 7.55 35.66688049163674 139.74673710820127 11.96 35.66681574471835 139.74669777786434 11.96 35.66681574471835 139.74669777786434 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66688049163674 139.74673710820127 7.55 35.66687607374311 139.74674802620024 7.55 35.66687607374311 139.74674802620024 11.96 35.66688049163674 139.74673710820127 11.96 35.66688049163674 139.74673710820127 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687607374311 139.74674802620024 7.55 35.66692609477778 139.746778403324 7.55 35.66692609477778 139.746778403324 11.96 35.66687607374311 139.74674802620024 11.96 35.66687607374311 139.74674802620024 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66692609477778 139.746778403324 7.55 35.66693756691452 139.74675005850034 7.55 35.66693756691452 139.74675005850034 11.96 35.66692609477778 139.746778403324 11.96 35.66692609477778 139.746778403324 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66693756691452 139.74675005850034 7.55 35.666946223883016 139.74675531799335 7.55 35.666946223883016 139.74675531799335 11.96 35.66693756691452 139.74675005850034 11.96 35.66693756691452 139.74675005850034 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666946223883016 139.74675531799335 7.55 35.66695703917185 139.74672858655381 7.55 35.66695703917185 139.74672858655381 11.96 35.666946223883016 139.74675531799335 11.96 35.666946223883016 139.74675531799335 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66695703917185 139.74672858655381 7.55 35.66694592038152 139.74672183854076 7.55 35.66694592038152 139.74672183854076 11.96 35.66695703917185 139.74672858655381 11.96 35.66695703917185 139.74672858655381 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66694592038152 139.74672183854076 11.96 35.66695471116582 139.74670010198045 11.96 35.66696515363366 139.74670644202763 11.96 35.66698093565071 139.74666742228757 11.96 35.66686963042976 139.74659982092945 11.96 35.6668502313402 139.74664776952434 11.96 35.66683877888607 139.74664081202255 11.96 35.66681574471835 139.74669777786434 11.96 35.66688049163674 139.74673710820127 11.96 35.66687607374311 139.74674802620024 11.96 35.66692609477778 139.746778403324 11.96 35.66693756691452 139.74675005850034 11.96 35.666946223883016 139.74675531799335 11.96 35.66695703917185 139.74672858655381 11.96 35.66694592038152 139.74672183854076 11.96</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ee175e60-8b1a-4251-8262-711ac4968002"/>
							<gml:surfaceMember xlink:href="#poly-05218ea2-6f2e-4b8b-81e9-74bcf64bc609"/>
							<gml:surfaceMember xlink:href="#poly-762df859-66ae-4788-bf9b-bef01a4c9b84"/>
							<gml:surfaceMember xlink:href="#poly-15e4f304-daa1-4e67-9da1-b342bfaf6029"/>
							<gml:surfaceMember xlink:href="#poly-4309698f-aa3d-431d-b93f-7a044aa08279"/>
							<gml:surfaceMember xlink:href="#poly-f7a2cc33-643c-416d-8873-452beda737d4"/>
							<gml:surfaceMember xlink:href="#poly-6b594285-6c30-40be-a61d-f5921f46ec7b"/>
							<gml:surfaceMember xlink:href="#poly-f7578815-b201-486e-b159-8b0be3f4c20c"/>
							<gml:surfaceMember xlink:href="#poly-c696c1f7-79bd-43e0-8d04-083584b2997f"/>
							<gml:surfaceMember xlink:href="#poly-db378c83-b3f0-49cc-907e-19148d2c0330"/>
							<gml:surfaceMember xlink:href="#poly-2395e33b-c838-4a30-af36-602602b70dd1"/>
							<gml:surfaceMember xlink:href="#poly-fbbbee60-43a3-4017-9539-7a4a4c4bd4ea"/>
							<gml:surfaceMember xlink:href="#poly-51002039-8b25-4c70-b5c4-4a3363e3010a"/>
							<gml:surfaceMember xlink:href="#poly-bd28417b-41be-40d1-91ed-b3fcec77e32f"/>
							<gml:surfaceMember xlink:href="#poly-36b7d98d-84de-45ee-94be-7222ad68488e"/>
							<gml:surfaceMember xlink:href="#poly-13391c52-2bf6-4353-a0bb-e01e6f527c5b"/>
							<gml:surfaceMember xlink:href="#poly-ce77623d-059f-49b0-8eb9-dd6e592f05af"/>
							<gml:surfaceMember xlink:href="#poly-6ba15d50-bec2-4114-acb4-d35b631cea0d"/>
							<gml:surfaceMember xlink:href="#poly-fac2e4e8-f3a4-4fd3-b84c-b17eb277a5dd"/>
							<gml:surfaceMember xlink:href="#poly-19abf01f-834f-4b47-ac0e-3792110e105b"/>
							<gml:surfaceMember xlink:href="#poly-a74f79fc-176f-4418-9403-74604bd11870"/>
							<gml:surfaceMember xlink:href="#poly-b814e92e-7079-417c-a9b8-238c54ee7e7a"/>
							<gml:surfaceMember xlink:href="#poly-d8696a47-a7bc-46fc-b9de-550980657882"/>
							<gml:surfaceMember xlink:href="#poly-b5b7cdc8-72bd-407e-843a-30a2f7b056c3"/>
							<gml:surfaceMember xlink:href="#poly-b764a44d-7932-4f37-9038-10e1b427a088"/>
							<gml:surfaceMember xlink:href="#poly-cc80665c-13f2-4e48-8070-d85efd91ce93"/>
							<gml:surfaceMember xlink:href="#poly-7fd562ec-7ddb-4182-9f93-d111e0ef1893"/>
							<gml:surfaceMember xlink:href="#poly-297602fb-4083-4d03-a8fa-3f0768184fef"/>
							<gml:surfaceMember xlink:href="#poly-cc5abd8b-9f51-477f-9fb8-2c7b74457b99"/>
							<gml:surfaceMember xlink:href="#poly-4bd63a5b-c82a-42d8-83ac-53e2d58469e6"/>
							<gml:surfaceMember xlink:href="#poly-3604c145-e4f2-4efb-a02a-0c2dcbbc3a67"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ee175e60-8b1a-4251-8262-711ac4968002">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee175e60-8b1a-4251-8262-711ac4968002">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee175e60-8b1a-4251-8262-711ac4968002">
											<gml:posList>35.66688049163673 139.74673710820127 7.55 35.666815744718335 139.74669777786434 7.55 35.666838778886074 139.74664081202252 7.55 35.66685023134019 139.74664776952432 7.55 35.66686963042976 139.74659982092942 7.55 35.666980935650685 139.74666742228754 7.55 35.666965153633654 139.74670644202763 7.55 35.66695471116582 139.74670010198045 7.55 35.66694592038151 139.74672183854076 7.55 35.66695703917184 139.7467285865538 7.55 35.666946223883016 139.74675531799332 7.55 35.666937566914484 139.74675005850034 7.55 35.66692609477778 139.74677840332396 7.55 35.666876073743076 139.74674802620024 7.55 35.66688049163673 139.74673710820127 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05218ea2-6f2e-4b8b-81e9-74bcf64bc609">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05218ea2-6f2e-4b8b-81e9-74bcf64bc609">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05218ea2-6f2e-4b8b-81e9-74bcf64bc609">
											<gml:posList>35.666838778886074 139.74664081202252 13.98 35.666815744718335 139.74669777786434 13.98 35.666833987479414 139.74670885915518 13.74 35.666857030666044 139.7466518932938 13.74 35.666838778886074 139.74664081202252 13.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-762df859-66ae-4788-bf9b-bef01a4c9b84">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-762df859-66ae-4788-bf9b-bef01a4c9b84">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-762df859-66ae-4788-bf9b-bef01a4c9b84">
											<gml:posList>35.66684110242676 139.74671318141193 13.172 35.666864136601674 139.7466562155565 13.172 35.666857030666044 139.7466518932938 13.74 35.666833987479414 139.74670885915518 13.74 35.66684110242676 139.74671318141193 13.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15e4f304-daa1-4e67-9da1-b342bfaf6029">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15e4f304-daa1-4e67-9da1-b342bfaf6029">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15e4f304-daa1-4e67-9da1-b342bfaf6029">
											<gml:posList>35.66689642196185 139.74661609552237 13.3 35.66686682844179 139.74668925056298 13.3 35.6668761076306 139.7466948849289 13.3 35.666905701154036 139.74662172988192 13.3 35.66689642196185 139.74661609552237 13.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4309698f-aa3d-431d-b93f-7a044aa08279">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4309698f-aa3d-431d-b93f-7a044aa08279">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4309698f-aa3d-431d-b93f-7a044aa08279">
											<gml:posList>35.66688049163673 139.74673710820127 10.8 35.666876073743076 139.74674802620024 10.8 35.66692609477778 139.74677840332396 10.8 35.66694837318843 139.74672332707274 10.8 35.66694592038151 139.74672183854076 10.8 35.66695172391588 139.74670748379404 10.8 35.66693579854968 139.74669760397416 10.8 35.66692490227917 139.74672452327655 10.8 35.66686682844179 139.74668925056298 10.8 35.66689642196185 139.74661609552237 10.8 35.66686963042976 139.74659982092942 10.8 35.66685023134019 139.74664776952432 10.8 35.666864136601674 139.7466562155565 10.8 35.66684110242676 139.74671318141193 10.8 35.66688049163673 139.74673710820127 10.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7a2cc33-643c-416d-8873-452beda737d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7a2cc33-643c-416d-8873-452beda737d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7a2cc33-643c-416d-8873-452beda737d4">
											<gml:posList>35.666905701154036 139.74662172988192 13.3 35.6668761076306 139.7466948849289 13.3 35.66691111806954 139.74668386759467 15.643 35.66692096140221 139.74665928008983 15.643 35.666905701154036 139.74662172988192 13.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b594285-6c30-40be-a61d-f5921f46ec7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b594285-6c30-40be-a61d-f5921f46ec7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b594285-6c30-40be-a61d-f5921f46ec7b">
											<gml:posList>35.6668761076306 139.7466948849289 13.3 35.66692490227917 139.74672452327655 13.3 35.66691111806954 139.74668386759467 15.643 35.6668761076306 139.7466948849289 13.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f7578815-b201-486e-b159-8b0be3f4c20c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7578815-b201-486e-b159-8b0be3f4c20c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7578815-b201-486e-b159-8b0be3f4c20c">
											<gml:posList>35.66695449582032 139.74665136819593 13.3 35.666905701154036 139.74662172988192 13.3 35.66692096140221 139.74665928008983 15.643 35.66695449582032 139.74665136819593 13.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c696c1f7-79bd-43e0-8d04-083584b2997f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c696c1f7-79bd-43e0-8d04-083584b2997f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c696c1f7-79bd-43e0-8d04-083584b2997f">
											<gml:posList>35.66692096140221 139.74665928008983 15.643 35.66691111806954 139.74668386759467 15.643 35.66692490227917 139.74672452327655 13.3 35.66693579854968 139.74669760397416 13.3 35.66695449582032 139.74665136819593 13.3 35.66692096140221 139.74665928008983 15.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db378c83-b3f0-49cc-907e-19148d2c0330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db378c83-b3f0-49cc-907e-19148d2c0330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db378c83-b3f0-49cc-907e-19148d2c0330">
											<gml:posList>35.666937566914484 139.74675005850034 10.2 35.666946223883016 139.74675531799332 10.2 35.66695703917184 139.7467285865538 10.2 35.66694837318843 139.74672332707274 10.2 35.666937566914484 139.74675005850034 10.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2395e33b-c838-4a30-af36-602602b70dd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2395e33b-c838-4a30-af36-602602b70dd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2395e33b-c838-4a30-af36-602602b70dd1">
											<gml:posList>35.66695172391588 139.74670748379404 13.3 35.666970493180834 139.74666108224423 13.3 35.66695449582032 139.74665136819593 13.3 35.66693579854968 139.74669760397416 13.3 35.66695172391588 139.74670748379404 13.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fbbbee60-43a3-4017-9539-7a4a4c4bd4ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbbbee60-43a3-4017-9539-7a4a4c4bd4ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbbbee60-43a3-4017-9539-7a4a4c4bd4ea">
											<gml:posList>35.66695471116582 139.74670010198045 10.8 35.666965153633654 139.74670644202763 10.8 35.666980935650685 139.74666742228754 10.8 35.666970493180834 139.74666108224423 10.8 35.66695471116582 139.74670010198045 10.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-51002039-8b25-4c70-b5c4-4a3363e3010a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51002039-8b25-4c70-b5c4-4a3363e3010a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51002039-8b25-4c70-b5c4-4a3363e3010a">
											<gml:posList>35.666838778886074 139.74664081202252 13.98 35.666838778886074 139.74664081202252 7.55 35.666815744718335 139.74669777786434 7.55 35.666815744718335 139.74669777786434 13.98 35.666838778886074 139.74664081202252 13.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd28417b-41be-40d1-91ed-b3fcec77e32f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd28417b-41be-40d1-91ed-b3fcec77e32f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd28417b-41be-40d1-91ed-b3fcec77e32f">
											<gml:posList>35.66684110242676 139.74671318141193 10.8 35.66684110242676 139.74671318141193 13.172 35.666833987479414 139.74670885915518 13.74 35.666815744718335 139.74669777786434 13.98 35.666815744718335 139.74669777786434 7.55 35.66688049163673 139.74673710820127 7.55 35.66688049163673 139.74673710820127 10.8 35.66684110242676 139.74671318141193 10.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36b7d98d-84de-45ee-94be-7222ad68488e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36b7d98d-84de-45ee-94be-7222ad68488e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36b7d98d-84de-45ee-94be-7222ad68488e">
											<gml:posList>35.666864136601674 139.7466562155565 13.172 35.666864136601674 139.7466562155565 10.8 35.66685023134019 139.74664776952432 10.8 35.66685023134019 139.74664776952432 7.55 35.666838778886074 139.74664081202252 7.55 35.666838778886074 139.74664081202252 13.98 35.666857030666044 139.7466518932938 13.74 35.666864136601674 139.7466562155565 13.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13391c52-2bf6-4353-a0bb-e01e6f527c5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13391c52-2bf6-4353-a0bb-e01e6f527c5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13391c52-2bf6-4353-a0bb-e01e6f527c5b">
											<gml:posList>35.666864136601674 139.7466562155565 13.172 35.66684110242676 139.74671318141193 13.172 35.66684110242676 139.74671318141193 10.8 35.666864136601674 139.7466562155565 10.8 35.666864136601674 139.7466562155565 13.172</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce77623d-059f-49b0-8eb9-dd6e592f05af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce77623d-059f-49b0-8eb9-dd6e592f05af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce77623d-059f-49b0-8eb9-dd6e592f05af">
											<gml:posList>35.66686963042976 139.74659982092942 7.55 35.66685023134019 139.74664776952432 7.55 35.66685023134019 139.74664776952432 10.8 35.66686963042976 139.74659982092942 10.8 35.66686963042976 139.74659982092942 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ba15d50-bec2-4114-acb4-d35b631cea0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ba15d50-bec2-4114-acb4-d35b631cea0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ba15d50-bec2-4114-acb4-d35b631cea0d">
											<gml:posList>35.66688049163673 139.74673710820127 7.55 35.666876073743076 139.74674802620024 7.55 35.666876073743076 139.74674802620024 10.8 35.66688049163673 139.74673710820127 10.8 35.66688049163673 139.74673710820127 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fac2e4e8-f3a4-4fd3-b84c-b17eb277a5dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fac2e4e8-f3a4-4fd3-b84c-b17eb277a5dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fac2e4e8-f3a4-4fd3-b84c-b17eb277a5dd">
											<gml:posList>35.66686682844179 139.74668925056298 13.3 35.66689642196185 139.74661609552237 13.3 35.66689642196185 139.74661609552237 10.8 35.66686682844179 139.74668925056298 10.8 35.66686682844179 139.74668925056298 13.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19abf01f-834f-4b47-ac0e-3792110e105b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19abf01f-834f-4b47-ac0e-3792110e105b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19abf01f-834f-4b47-ac0e-3792110e105b">
											<gml:posList>35.66692490227917 139.74672452327655 10.8 35.66692490227917 139.74672452327655 13.3 35.6668761076306 139.7466948849289 13.3 35.66686682844179 139.74668925056298 13.3 35.66686682844179 139.74668925056298 10.8 35.66692490227917 139.74672452327655 10.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a74f79fc-176f-4418-9403-74604bd11870">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a74f79fc-176f-4418-9403-74604bd11870">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a74f79fc-176f-4418-9403-74604bd11870">
											<gml:posList>35.666876073743076 139.74674802620024 7.55 35.66692609477778 139.74677840332396 7.55 35.66692609477778 139.74677840332396 10.8 35.666876073743076 139.74674802620024 10.8 35.666876073743076 139.74674802620024 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b814e92e-7079-417c-a9b8-238c54ee7e7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b814e92e-7079-417c-a9b8-238c54ee7e7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b814e92e-7079-417c-a9b8-238c54ee7e7a">
											<gml:posList>35.66689642196185 139.74661609552237 10.8 35.66689642196185 139.74661609552237 13.3 35.666905701154036 139.74662172988192 13.3 35.66695449582032 139.74665136819593 13.3 35.666970493180834 139.74666108224423 13.3 35.666970493180834 139.74666108224423 10.8 35.666980935650685 139.74666742228754 10.8 35.666980935650685 139.74666742228754 7.55 35.66686963042976 139.74659982092942 7.55 35.66686963042976 139.74659982092942 10.8 35.66689642196185 139.74661609552237 10.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8696a47-a7bc-46fc-b9de-550980657882">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8696a47-a7bc-46fc-b9de-550980657882">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8696a47-a7bc-46fc-b9de-550980657882">
											<gml:posList>35.66693579854968 139.74669760397416 13.3 35.66692490227917 139.74672452327655 13.3 35.66692490227917 139.74672452327655 10.8 35.66693579854968 139.74669760397416 10.8 35.66693579854968 139.74669760397416 13.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5b7cdc8-72bd-407e-843a-30a2f7b056c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5b7cdc8-72bd-407e-843a-30a2f7b056c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5b7cdc8-72bd-407e-843a-30a2f7b056c3">
											<gml:posList>35.66692609477778 139.74677840332396 10.8 35.66692609477778 139.74677840332396 7.55 35.666937566914484 139.74675005850034 7.55 35.666937566914484 139.74675005850034 10.2 35.66694837318843 139.74672332707274 10.2 35.66694837318843 139.74672332707274 10.8 35.66692609477778 139.74677840332396 10.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b764a44d-7932-4f37-9038-10e1b427a088">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b764a44d-7932-4f37-9038-10e1b427a088">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b764a44d-7932-4f37-9038-10e1b427a088">
											<gml:posList>35.666937566914484 139.74675005850034 7.55 35.666946223883016 139.74675531799332 7.55 35.666946223883016 139.74675531799332 10.2 35.666937566914484 139.74675005850034 10.2 35.666937566914484 139.74675005850034 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc80665c-13f2-4e48-8070-d85efd91ce93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc80665c-13f2-4e48-8070-d85efd91ce93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc80665c-13f2-4e48-8070-d85efd91ce93">
											<gml:posList>35.66695172391588 139.74670748379404 13.3 35.66693579854968 139.74669760397416 13.3 35.66693579854968 139.74669760397416 10.8 35.66695172391588 139.74670748379404 10.8 35.66695172391588 139.74670748379404 13.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fd562ec-7ddb-4182-9f93-d111e0ef1893">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fd562ec-7ddb-4182-9f93-d111e0ef1893">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fd562ec-7ddb-4182-9f93-d111e0ef1893">
											<gml:posList>35.66694592038151 139.74672183854076 7.55 35.66694592038151 139.74672183854076 10.8 35.66694837318843 139.74672332707274 10.8 35.66694837318843 139.74672332707274 10.2 35.66695703917184 139.7467285865538 10.2 35.66695703917184 139.7467285865538 7.55 35.66694592038151 139.74672183854076 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-297602fb-4083-4d03-a8fa-3f0768184fef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-297602fb-4083-4d03-a8fa-3f0768184fef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-297602fb-4083-4d03-a8fa-3f0768184fef">
											<gml:posList>35.666946223883016 139.74675531799332 7.55 35.66695703917184 139.7467285865538 7.55 35.66695703917184 139.7467285865538 10.2 35.666946223883016 139.74675531799332 10.2 35.666946223883016 139.74675531799332 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc5abd8b-9f51-477f-9fb8-2c7b74457b99">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc5abd8b-9f51-477f-9fb8-2c7b74457b99">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc5abd8b-9f51-477f-9fb8-2c7b74457b99">
											<gml:posList>35.66694592038151 139.74672183854076 7.55 35.66695471116582 139.74670010198045 7.55 35.66695471116582 139.74670010198045 10.8 35.666970493180834 139.74666108224423 10.8 35.666970493180834 139.74666108224423 13.3 35.66695172391588 139.74670748379404 13.3 35.66695172391588 139.74670748379404 10.8 35.66694592038151 139.74672183854076 10.8 35.66694592038151 139.74672183854076 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4bd63a5b-c82a-42d8-83ac-53e2d58469e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4bd63a5b-c82a-42d8-83ac-53e2d58469e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4bd63a5b-c82a-42d8-83ac-53e2d58469e6">
											<gml:posList>35.66695471116582 139.74670010198045 7.55 35.666965153633654 139.74670644202763 7.55 35.666965153633654 139.74670644202763 10.8 35.66695471116582 139.74670010198045 10.8 35.66695471116582 139.74670010198045 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3604c145-e4f2-4efb-a02a-0c2dcbbc3a67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3604c145-e4f2-4efb-a02a-0c2dcbbc3a67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3604c145-e4f2-4efb-a02a-0c2dcbbc3a67">
											<gml:posList>35.666965153633654 139.74670644202763 7.55 35.666980935650685 139.74666742228754 7.55 35.666980935650685 139.74666742228754 10.8 35.666965153633654 139.74670644202763 10.8 35.666965153633654 139.74670644202763 7.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9286</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">146.0561</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">22</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>