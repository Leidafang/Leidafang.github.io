<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3b16f296-d56c-4f08-97b1-faccfa8c3ad2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">32.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67376685258993 139.73774857133623 0 35.673785251084155 139.7377390823533 0 35.67375519296529 139.7376516391867 0 35.6737186877521 139.7376407685979 0 35.67369464898727 139.73765316961368 0 35.67367569982574 139.7376956447484 0 35.67371843346615 139.73782001296595 0 35.67378791885462 139.73778413877852 0 35.6737803117358 139.73776201020297 0 35.67377280637842 139.73776588550479 0 35.67376685258993 139.73774857133623 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67376685258993 139.73774857133623 9.12 35.67377280637842 139.73776588550479 9.12 35.6737803117358 139.73776201020297 9.12 35.67378791885462 139.73778413877852 9.12 35.67371843346615 139.73782001296595 9.12 35.67367569982574 139.7376956447484 9.12 35.67369464898727 139.73765316961368 9.12 35.6737186877521 139.7376407685979 9.12 35.67375519296529 139.7376516391867 9.12 35.673785251084155 139.7377390823533 9.12 35.67376685258993 139.73774857133623 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67376685258993 139.73774857133623 9.12 35.673785251084155 139.7377390823533 9.12 35.673785251084155 139.7377390823533 41.4 35.67376685258993 139.73774857133623 41.4 35.67376685258993 139.73774857133623 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673785251084155 139.7377390823533 9.12 35.67375519296529 139.7376516391867 9.12 35.67375519296529 139.7376516391867 41.4 35.673785251084155 139.7377390823533 41.4 35.673785251084155 139.7377390823533 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67375519296529 139.7376516391867 9.12 35.6737186877521 139.7376407685979 9.12 35.6737186877521 139.7376407685979 41.4 35.67375519296529 139.7376516391867 41.4 35.67375519296529 139.7376516391867 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6737186877521 139.7376407685979 9.12 35.67369464898727 139.73765316961368 9.12 35.67369464898727 139.73765316961368 41.4 35.6737186877521 139.7376407685979 41.4 35.6737186877521 139.7376407685979 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67369464898727 139.73765316961368 9.12 35.67367569982574 139.7376956447484 9.12 35.67367569982574 139.7376956447484 41.4 35.67369464898727 139.73765316961368 41.4 35.67369464898727 139.73765316961368 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67367569982574 139.7376956447484 9.12 35.67371843346615 139.73782001296595 9.12 35.67371843346615 139.73782001296595 41.4 35.67367569982574 139.7376956447484 41.4 35.67367569982574 139.7376956447484 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67371843346615 139.73782001296595 9.12 35.67378791885462 139.73778413877852 9.12 35.67378791885462 139.73778413877852 41.4 35.67371843346615 139.73782001296595 41.4 35.67371843346615 139.73782001296595 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67378791885462 139.73778413877852 9.12 35.6737803117358 139.73776201020297 9.12 35.6737803117358 139.73776201020297 41.4 35.67378791885462 139.73778413877852 41.4 35.67378791885462 139.73778413877852 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6737803117358 139.73776201020297 9.12 35.67377280637842 139.73776588550479 9.12 35.67377280637842 139.73776588550479 41.4 35.6737803117358 139.73776201020297 41.4 35.6737803117358 139.73776201020297 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67377280637842 139.73776588550479 9.12 35.67376685258993 139.73774857133623 9.12 35.67376685258993 139.73774857133623 41.4 35.67377280637842 139.73776588550479 41.4 35.67377280637842 139.73776588550479 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67376685258993 139.73774857133623 41.4 35.673785251084155 139.7377390823533 41.4 35.67375519296529 139.7376516391867 41.4 35.6737186877521 139.7376407685979 41.4 35.67369464898727 139.73765316961368 41.4 35.67367569982574 139.7376956447484 41.4 35.67371843346615 139.73782001296595 41.4 35.67378791885462 139.73778413877852 41.4 35.6737803117358 139.73776201020297 41.4 35.67377280637842 139.73776588550479 41.4 35.67376685258993 139.73774857133623 41.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5ab128c9-9894-4164-af93-f7d43e5a11ce"/>
							<gml:surfaceMember xlink:href="#poly-e5d51a51-dd3e-47ed-851b-7bb804c73668"/>
							<gml:surfaceMember xlink:href="#poly-9d35a14b-ee4b-4963-9aab-7f7b353ba5b0"/>
							<gml:surfaceMember xlink:href="#poly-292e55ef-ad77-4ad2-9f18-77c24300405f"/>
							<gml:surfaceMember xlink:href="#poly-e8548c49-8bc4-429c-acdc-3e4bcc292d38"/>
							<gml:surfaceMember xlink:href="#poly-97ddf368-bb04-46aa-ab22-657fbb26b548"/>
							<gml:surfaceMember xlink:href="#poly-fcb0331d-f433-4ae6-8d62-a205b1405d2b"/>
							<gml:surfaceMember xlink:href="#poly-e16c41eb-7df1-497b-8d57-32e9692d791e"/>
							<gml:surfaceMember xlink:href="#poly-4306f24e-b091-400e-9bbd-f84348a88eee"/>
							<gml:surfaceMember xlink:href="#poly-d0855e37-2979-4209-b63d-45ffed8fe1da"/>
							<gml:surfaceMember xlink:href="#poly-cc727022-3e51-4de6-a97f-0f2a7b078739"/>
							<gml:surfaceMember xlink:href="#poly-ef70808e-174b-484e-a5dc-b0fc1be4761b"/>
							<gml:surfaceMember xlink:href="#poly-26cc020a-2900-4e99-bc9b-2b8c11c3962c"/>
							<gml:surfaceMember xlink:href="#poly-8dc9d3cc-cee3-4548-8a40-3e4416b59cce"/>
							<gml:surfaceMember xlink:href="#poly-cd239e21-e4df-4e29-84e6-cddaeb032280"/>
							<gml:surfaceMember xlink:href="#poly-fcb21bf7-c611-4e34-80f3-3fd450d14550"/>
							<gml:surfaceMember xlink:href="#poly-cff33998-d435-402d-bf95-6aa1a0c91c14"/>
							<gml:surfaceMember xlink:href="#poly-bc160ec9-3be9-4fd6-8bec-9f051dcbb1a7"/>
							<gml:surfaceMember xlink:href="#poly-378806d4-2a91-4404-8c4b-d5d50951c691"/>
							<gml:surfaceMember xlink:href="#poly-ae7584ce-5ff3-4b07-9465-7826ce36d993"/>
							<gml:surfaceMember xlink:href="#poly-5a350203-7730-419a-a0c3-77f50ae7f3c7"/>
							<gml:surfaceMember xlink:href="#poly-44c6c5c7-0911-436a-9998-bebea803ccd4"/>
							<gml:surfaceMember xlink:href="#poly-dc2748f6-9c72-43d5-9fc7-a5c1146e3fd6"/>
							<gml:surfaceMember xlink:href="#poly-8af9e408-3895-4c8b-b2d1-2141ed7e9bcc"/>
							<gml:surfaceMember xlink:href="#poly-284c1c2a-099a-4cbb-ab0a-2e192fc73599"/>
							<gml:surfaceMember xlink:href="#poly-be58c9bf-4e82-4505-aede-488ffc6283e3"/>
							<gml:surfaceMember xlink:href="#poly-a8d541cc-06ba-47e1-8b55-7e7f9b0e8add"/>
							<gml:surfaceMember xlink:href="#poly-a67bcda6-77c5-4319-9efa-df271331e965"/>
							<gml:surfaceMember xlink:href="#poly-73ffab7c-fafb-4cfe-86da-09935ca60e04"/>
							<gml:surfaceMember xlink:href="#poly-73d99117-f2ac-44b3-9684-f645a013e553"/>
							<gml:surfaceMember xlink:href="#poly-857ef857-023a-4dea-89f9-d283ddbfb2cc"/>
							<gml:surfaceMember xlink:href="#poly-73ca4421-b7bf-488c-b41a-29315b96cac6"/>
							<gml:surfaceMember xlink:href="#poly-bbf062d5-10b9-4aad-aa80-e6d593bec16d"/>
							<gml:surfaceMember xlink:href="#poly-314f9bfa-00ad-4df6-a1c6-9ee49204ae6a"/>
							<gml:surfaceMember xlink:href="#poly-a2719ea2-4302-4b53-bfbd-2d06278f6e70"/>
							<gml:surfaceMember xlink:href="#poly-04c2cbbc-219f-4e6f-ad8b-5b50675b4fe5"/>
							<gml:surfaceMember xlink:href="#poly-157e5784-9a86-4d00-b010-51589703bbcc"/>
							<gml:surfaceMember xlink:href="#poly-70f1aa31-4759-4f05-b847-0565ca04a38b"/>
							<gml:surfaceMember xlink:href="#poly-2daae87f-7c25-48e8-b282-6fd98fa93745"/>
							<gml:surfaceMember xlink:href="#poly-5bf81e71-83eb-4e9e-b30f-d93b4efe11de"/>
							<gml:surfaceMember xlink:href="#poly-d90c482d-5540-413d-874d-be9956f2ca0e"/>
							<gml:surfaceMember xlink:href="#poly-5c19327c-4f65-4a57-8fbb-d834102231f3"/>
							<gml:surfaceMember xlink:href="#poly-fb7d2507-b21d-4f36-87c1-47620b9f2e3e"/>
							<gml:surfaceMember xlink:href="#poly-650f5a3c-b987-4027-8444-b87e9992f38b"/>
							<gml:surfaceMember xlink:href="#poly-8926ba0e-d4e4-4cfa-a998-128a8aa6141c"/>
							<gml:surfaceMember xlink:href="#poly-e6e5a56f-253b-4e35-b652-4a2e353dcb51"/>
							<gml:surfaceMember xlink:href="#poly-58db5e23-24f8-4bd5-9f52-588115872a33"/>
							<gml:surfaceMember xlink:href="#poly-55b5bb4b-7f75-428c-98a8-60288a8875cb"/>
							<gml:surfaceMember xlink:href="#poly-f5c85f40-eebc-4da0-bd5c-cd8cc8f8e4d0"/>
							<gml:surfaceMember xlink:href="#poly-beb1a3f0-b584-48d4-a149-941ae275d085"/>
							<gml:surfaceMember xlink:href="#poly-5beb219b-5f4d-461b-bbba-0f5aba9bd8af"/>
							<gml:surfaceMember xlink:href="#poly-6e47021c-743f-426d-a948-36ae5f8dd090"/>
							<gml:surfaceMember xlink:href="#poly-95482d48-518c-494f-b239-8d42b62f7991"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3b16f296-d56c-4f08-97b1-faccfa8c3ad2_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2142725-b29e-42f7-ac85-1c6e09ab39ca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673705556579435 139.7377565538698 44.857 35.67373657006005 139.73774173638162 44.857 35.67374400693029 139.73776513551923 44.857 35.673712993446834 139.73777995299972 44.857 35.673705556579435 139.7377565538698 44.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5ad0dce-f7fc-40c2-aa48-3fa0c50c7045">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5ad0dce-f7fc-40c2-aa48-3fa0c50c7045_0">
											<gml:posList>35.673705556579435 139.7377565538698 44.857 35.673712993446834 139.73777995299972 44.857 35.673712993446834 139.73777995299972 47.737 35.673705556579435 139.7377565538698 47.737 35.673705556579435 139.7377565538698 44.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5209753c-9a90-4c19-b8cc-37234aa3db07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5209753c-9a90-4c19-b8cc-37234aa3db07_0">
											<gml:posList>35.67373657006005 139.73774173638162 47.737 35.67373657006005 139.73774173638162 44.857 35.673705556579435 139.7377565538698 44.857 35.673705556579435 139.7377565538698 47.737 35.67373657006005 139.73774173638162 47.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63441c77-de38-4db8-baaa-1cfb035d76b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63441c77-de38-4db8-baaa-1cfb035d76b7_0">
											<gml:posList>35.67374400693029 139.73776513551923 47.737 35.67373657006005 139.73774173638162 47.737 35.673705556579435 139.7377565538698 47.737 35.673712993446834 139.73777995299972 47.737 35.67374400693029 139.73776513551923 47.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff8554d8-0d4b-4fba-bdde-710799b650e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff8554d8-0d4b-4fba-bdde-710799b650e6_0">
											<gml:posList>35.673712993446834 139.73777995299972 47.737 35.673712993446834 139.73777995299972 44.857 35.67374400693029 139.73776513551923 44.857 35.67374400693029 139.73776513551923 47.737 35.673712993446834 139.73777995299972 47.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b9a6f3f-f97c-43d4-8b3b-e2db6a61dc39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b9a6f3f-f97c-43d4-8b3b-e2db6a61dc39_0">
											<gml:posList>35.67374400693029 139.73776513551923 44.857 35.67373657006005 139.73774173638162 44.857 35.67373657006005 139.73774173638162 47.737 35.67374400693029 139.73776513551923 47.737 35.67374400693029 139.73776513551923 44.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5ab128c9-9894-4164-af93-f7d43e5a11ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ab128c9-9894-4164-af93-f7d43e5a11ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ab128c9-9894-4164-af93-f7d43e5a11ce">
											<gml:posList>35.6737186877521 139.7376407685979 9.12 35.67375519296529 139.7376516391867 9.12 35.67378525108416 139.7377390823533 9.12 35.67376685258992 139.73774857133623 9.12 35.67377280637839 139.73776588550479 9.12 35.6737803117358 139.737762010203 9.12 35.673787918854615 139.73778413877852 9.12 35.67371843346615 139.73782001296595 9.12 35.67367569982573 139.7376956447484 9.12 35.67369464898726 139.73765316961365 9.12 35.6737186877521 139.7376407685979 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5d51a51-dd3e-47ed-851b-7bb804c73668">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5d51a51-dd3e-47ed-851b-7bb804c73668">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5d51a51-dd3e-47ed-851b-7bb804c73668">
											<gml:posList>35.67368835059408 139.7376672837858 25.128 35.67373366309143 139.73764522464464 25.128 35.6737186877521 139.7376407685979 25.128 35.67369464898726 139.73765316961365 25.128 35.67368835059408 139.7376672837858 25.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d35a14b-ee4b-4963-9aab-7f7b353ba5b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d35a14b-ee4b-4963-9aab-7f7b353ba5b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d35a14b-ee4b-4963-9aab-7f7b353ba5b0">
											<gml:posList>35.67368195322387 139.73768161900813 28.563 35.67374659183401 139.7376490755659 28.563 35.67373366309143 139.73764522464464 28.563 35.67368835059408 139.7376672837858 28.563 35.67368195322387 139.73768161900813 28.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-292e55ef-ad77-4ad2-9f18-77c24300405f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-292e55ef-ad77-4ad2-9f18-77c24300405f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-292e55ef-ad77-4ad2-9f18-77c24300405f">
											<gml:posList>35.67374659183401 139.7376490755659 31.386 35.67368195322387 139.73768161900813 31.386 35.67367569982573 139.7376956447484 31.386 35.67370154970279 139.73768242413044 31.386 35.67375661138426 139.73765574687528 31.386 35.67375519296529 139.7376516391867 31.386 35.67374659183401 139.7376490755659 31.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8548c49-8bc4-429c-acdc-3e4bcc292d38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8548c49-8bc4-429c-acdc-3e4bcc292d38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8548c49-8bc4-429c-acdc-3e4bcc292d38">
											<gml:posList>35.6737411001009 139.73769146839382 36.224 35.67376469737289 139.73767928884362 36.224 35.67375661138426 139.73765574687528 36.224 35.67373317564183 139.73766702040726 36.224 35.6737411001009 139.73769146839382 36.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-97ddf368-bb04-46aa-ab22-657fbb26b548">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97ddf368-bb04-46aa-ab22-657fbb26b548">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97ddf368-bb04-46aa-ab22-657fbb26b548">
											<gml:posList>35.67370154970279 139.73768242413044 45.388 35.673706283896195 139.73768492608676 45.388 35.67373114314948 139.73767282236116 45.388 35.67373317564183 139.73766702040726 45.388 35.67370154970279 139.73768242413044 45.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcb0331d-f433-4ae6-8d62-a205b1405d2b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcb0331d-f433-4ae6-8d62-a205b1405d2b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcb0331d-f433-4ae6-8d62-a205b1405d2b">
											<gml:posList>35.6737631506905 139.73768391926697 45.179 35.67376469737289 139.73767928884362 45.179 35.6737411001009 139.73769146839382 45.179 35.67374214825418 139.73769469278625 45.179 35.6737631506905 139.73768391926697 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e16c41eb-7df1-497b-8d57-32e9692d791e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e16c41eb-7df1-497b-8d57-32e9692d791e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e16c41eb-7df1-497b-8d57-32e9692d791e">
											<gml:posList>35.67373317564183 139.73766702040726 45.388 35.67373114314948 139.73767282236116 45.388 35.67374161573114 139.73770514362087 45.388 35.67374634090155 139.73770763454382 45.388 35.67373317564183 139.73766702040726 45.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4306f24e-b091-400e-9bbd-f84348a88eee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4306f24e-b091-400e-9bbd-f84348a88eee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4306f24e-b091-400e-9bbd-f84348a88eee">
											<gml:posList>35.67374161573114 139.73770514362087 45.101 35.67373114314948 139.73767282236116 45.101 35.673706283896195 139.73768492608676 45.101 35.67371675647464 139.73771724733805 45.101 35.67374161573114 139.73770514362087 45.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0855e37-2979-4209-b63d-45ffed8fe1da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0855e37-2979-4209-b63d-45ffed8fe1da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0855e37-2979-4209-b63d-45ffed8fe1da">
											<gml:posList>35.67370154970279 139.73768242413044 36.224 35.67367569982573 139.7376956447484 36.224 35.673683830989255 139.73771933025048 36.224 35.67370946511872 139.7377068389795 36.224 35.67370154970279 139.73768242413044 36.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc727022-3e51-4de6-a97f-0f2a7b078739">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc727022-3e51-4de6-a97f-0f2a7b078739">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc727022-3e51-4de6-a97f-0f2a7b078739">
											<gml:posList>35.673714714957356 139.73772303825353 45.388 35.67371675647464 139.73771724733805 45.388 35.673706283896195 139.73768492608676 45.388 35.67370154970279 139.73768242413044 45.388 35.673714714957356 139.73772303825353 45.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ef70808e-174b-484e-a5dc-b0fc1be4761b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef70808e-174b-484e-a5dc-b0fc1be4761b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef70808e-174b-484e-a5dc-b0fc1be4761b">
											<gml:posList>35.67376469737289 139.73767928884362 45.179 35.6737631506905 139.73768391926697 45.179 35.673781472828296 139.73773718682142 45.179 35.67378525108416 139.7377390823533 45.179 35.67376469737289 139.73767928884362 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26cc020a-2900-4e99-bc9b-2b8c11c3962c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26cc020a-2900-4e99-bc9b-2b8c11c3962c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26cc020a-2900-4e99-bc9b-2b8c11c3962c">
											<gml:posList>35.673687645352956 139.73772129201643 45.179 35.67371053136044 139.73771014067634 45.179 35.67370946511872 139.7377068389795 45.179 35.673683830989255 139.73771933025048 45.179 35.673687645352956 139.73772129201643 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8dc9d3cc-cee3-4548-8a40-3e4416b59cce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dc9d3cc-cee3-4548-8a40-3e4416b59cce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dc9d3cc-cee3-4548-8a40-3e4416b59cce">
											<gml:posList>35.67374634090155 139.73770763454382 45.388 35.67374161573114 139.73770514362087 45.388 35.67371675647464 139.73771724733805 45.388 35.673714714957356 139.73772303825353 45.388 35.67374634090155 139.73770763454382 45.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd239e21-e4df-4e29-84e6-cddaeb032280">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd239e21-e4df-4e29-84e6-cddaeb032280">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd239e21-e4df-4e29-84e6-cddaeb032280">
											<gml:posList>35.67376685258992 139.73774857133623 45.179 35.67378525108416 139.7377390823533 45.179 35.673781472828296 139.73773718682142 45.179 35.6737630743342 139.73774667580437 45.179 35.67376685258992 139.73774857133623 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcb21bf7-c611-4e34-80f3-3fd450d14550">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcb21bf7-c611-4e34-80f3-3fd450d14550">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcb21bf7-c611-4e34-80f3-3fd450d14550">
											<gml:posList>35.67378414059946 139.73778224324445 44.857 35.67377877405518 139.7377666295682 44.857 35.67377126869761 139.7377705048695 44.857 35.6737630743342 139.73774667580437 44.857 35.673781472828296 139.73773718682142 44.857 35.6737631506905 139.73768391926697 44.857 35.67374214825418 139.73769469278625 44.857 35.67374634090155 139.73770763454382 44.857 35.673714714957356 139.73772303825353 44.857 35.67371053136044 139.73771014067634 44.857 35.673687645352956 139.73772129201643 44.857 35.67371997113132 139.7378153715118 44.857 35.67378414059946 139.73778224324445 44.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cff33998-d435-402d-bf95-6aa1a0c91c14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cff33998-d435-402d-bf95-6aa1a0c91c14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cff33998-d435-402d-bf95-6aa1a0c91c14">
											<gml:posList>35.67376685258992 139.73774857133623 45.179 35.6737630743342 139.73774667580437 45.179 35.67377126869761 139.7377705048695 45.179 35.67377280637839 139.73776588550479 45.179 35.67376685258992 139.73774857133623 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc160ec9-3be9-4fd6-8bec-9f051dcbb1a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc160ec9-3be9-4fd6-8bec-9f051dcbb1a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc160ec9-3be9-4fd6-8bec-9f051dcbb1a7">
											<gml:posList>35.67377280637839 139.73776588550479 45.179 35.67377126869761 139.7377705048695 45.179 35.67377877405518 139.7377666295682 45.179 35.6737803117358 139.737762010203 45.179 35.67377280637839 139.73776588550479 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-378806d4-2a91-4404-8c4b-d5d50951c691">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-378806d4-2a91-4404-8c4b-d5d50951c691">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-378806d4-2a91-4404-8c4b-d5d50951c691">
											<gml:posList>35.67371843346615 139.73782001296595 45.179 35.67371997113132 139.7378153715118 45.179 35.673687645352956 139.73772129201643 45.179 35.673683830989255 139.73771933025048 45.179 35.67371843346615 139.73782001296595 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ae7584ce-5ff3-4b07-9465-7826ce36d993">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae7584ce-5ff3-4b07-9465-7826ce36d993">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae7584ce-5ff3-4b07-9465-7826ce36d993">
											<gml:posList>35.6737803117358 139.737762010203 45.179 35.67377877405518 139.7377666295682 45.179 35.67378414059946 139.73778224324445 45.179 35.673787918854615 139.73778413877852 45.179 35.6737803117358 139.737762010203 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5a350203-7730-419a-a0c3-77f50ae7f3c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a350203-7730-419a-a0c3-77f50ae7f3c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a350203-7730-419a-a0c3-77f50ae7f3c7">
											<gml:posList>35.673787918854615 139.73778413877852 45.179 35.67378414059946 139.73778224324445 45.179 35.67371997113132 139.7378153715118 45.179 35.67371843346615 139.73782001296595 45.179 35.673787918854615 139.73778413877852 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44c6c5c7-0911-436a-9998-bebea803ccd4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44c6c5c7-0911-436a-9998-bebea803ccd4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44c6c5c7-0911-436a-9998-bebea803ccd4">
											<gml:posList>35.6737186877521 139.7376407685979 9.12 35.6737186877521 139.7376407685979 25.128 35.67373366309143 139.73764522464464 25.128 35.67373366309143 139.73764522464464 28.563 35.67374659183401 139.7376490755659 28.563 35.67374659183401 139.7376490755659 31.386 35.67375519296529 139.7376516391867 31.386 35.67375519296529 139.7376516391867 9.12 35.6737186877521 139.7376407685979 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc2748f6-9c72-43d5-9fc7-a5c1146e3fd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc2748f6-9c72-43d5-9fc7-a5c1146e3fd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc2748f6-9c72-43d5-9fc7-a5c1146e3fd6">
											<gml:posList>35.6737186877521 139.7376407685979 9.12 35.67369464898726 139.73765316961365 9.12 35.67369464898726 139.73765316961365 25.128 35.6737186877521 139.7376407685979 25.128 35.6737186877521 139.7376407685979 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8af9e408-3895-4c8b-b2d1-2141ed7e9bcc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8af9e408-3895-4c8b-b2d1-2141ed7e9bcc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8af9e408-3895-4c8b-b2d1-2141ed7e9bcc">
											<gml:posList>35.67368835059408 139.7376672837858 25.128 35.67368835059408 139.7376672837858 28.563 35.67373366309143 139.73764522464464 28.563 35.67373366309143 139.73764522464464 25.128 35.67368835059408 139.7376672837858 25.128</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-284c1c2a-099a-4cbb-ab0a-2e192fc73599">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-284c1c2a-099a-4cbb-ab0a-2e192fc73599">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-284c1c2a-099a-4cbb-ab0a-2e192fc73599">
											<gml:posList>35.67368195322387 139.73768161900813 28.563 35.67368195322387 139.73768161900813 31.386 35.67374659183401 139.7376490755659 31.386 35.67374659183401 139.7376490755659 28.563 35.67368195322387 139.73768161900813 28.563</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be58c9bf-4e82-4505-aede-488ffc6283e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be58c9bf-4e82-4505-aede-488ffc6283e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be58c9bf-4e82-4505-aede-488ffc6283e3">
											<gml:posList>35.67373317564183 139.73766702040726 36.224 35.67375661138426 139.73765574687528 36.224 35.67375661138426 139.73765574687528 31.386 35.67370154970279 139.73768242413044 31.386 35.67370154970279 139.73768242413044 36.224 35.67370154970279 139.73768242413044 45.388 35.67373317564183 139.73766702040726 45.388 35.67373317564183 139.73766702040726 36.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a8d541cc-06ba-47e1-8b55-7e7f9b0e8add">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8d541cc-06ba-47e1-8b55-7e7f9b0e8add">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8d541cc-06ba-47e1-8b55-7e7f9b0e8add">
											<gml:posList>35.67369464898726 139.73765316961365 9.12 35.67367569982573 139.7376956447484 9.12 35.67367569982573 139.7376956447484 31.386 35.67368195322387 139.73768161900813 31.386 35.67368195322387 139.73768161900813 28.563 35.67368835059408 139.7376672837858 28.563 35.67368835059408 139.7376672837858 25.128 35.67369464898726 139.73765316961365 25.128 35.67369464898726 139.73765316961365 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a67bcda6-77c5-4319-9efa-df271331e965">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a67bcda6-77c5-4319-9efa-df271331e965">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a67bcda6-77c5-4319-9efa-df271331e965">
											<gml:posList>35.673706283896195 139.73768492608676 45.388 35.673706283896195 139.73768492608676 45.101 35.67373114314948 139.73767282236116 45.101 35.67373114314948 139.73767282236116 45.388 35.673706283896195 139.73768492608676 45.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73ffab7c-fafb-4cfe-86da-09935ca60e04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73ffab7c-fafb-4cfe-86da-09935ca60e04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73ffab7c-fafb-4cfe-86da-09935ca60e04">
											<gml:posList>35.6737411001009 139.73769146839382 45.179 35.67376469737289 139.73767928884362 45.179 35.67376469737289 139.73767928884362 36.224 35.6737411001009 139.73769146839382 36.224 35.6737411001009 139.73769146839382 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73d99117-f2ac-44b3-9684-f645a013e553">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73d99117-f2ac-44b3-9684-f645a013e553">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73d99117-f2ac-44b3-9684-f645a013e553">
											<gml:posList>35.6737411001009 139.73769146839382 45.179 35.6737411001009 139.73769146839382 36.224 35.67373317564183 139.73766702040726 36.224 35.67373317564183 139.73766702040726 45.388 35.67374634090155 139.73770763454382 45.388 35.67374634090155 139.73770763454382 44.857 35.67374214825418 139.73769469278625 44.857 35.67374214825418 139.73769469278625 45.179 35.6737411001009 139.73769146839382 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-857ef857-023a-4dea-89f9-d283ddbfb2cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-857ef857-023a-4dea-89f9-d283ddbfb2cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-857ef857-023a-4dea-89f9-d283ddbfb2cc">
											<gml:posList>35.67367569982573 139.7376956447484 31.386 35.67367569982573 139.7376956447484 36.224 35.67370154970279 139.73768242413044 36.224 35.67370154970279 139.73768242413044 31.386 35.67367569982573 139.7376956447484 31.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73ca4421-b7bf-488c-b41a-29315b96cac6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73ca4421-b7bf-488c-b41a-29315b96cac6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73ca4421-b7bf-488c-b41a-29315b96cac6">
											<gml:posList>35.67373114314948 139.73767282236116 45.388 35.67373114314948 139.73767282236116 45.101 35.67374161573114 139.73770514362087 45.101 35.67374161573114 139.73770514362087 45.388 35.67373114314948 139.73767282236116 45.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bbf062d5-10b9-4aad-aa80-e6d593bec16d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bbf062d5-10b9-4aad-aa80-e6d593bec16d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bbf062d5-10b9-4aad-aa80-e6d593bec16d">
											<gml:posList>35.67374214825418 139.73769469278625 45.179 35.67374214825418 139.73769469278625 44.857 35.6737631506905 139.73768391926697 44.857 35.6737631506905 139.73768391926697 45.179 35.67374214825418 139.73769469278625 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-314f9bfa-00ad-4df6-a1c6-9ee49204ae6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-314f9bfa-00ad-4df6-a1c6-9ee49204ae6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-314f9bfa-00ad-4df6-a1c6-9ee49204ae6a">
											<gml:posList>35.67375661138426 139.73765574687528 31.386 35.67375661138426 139.73765574687528 36.224 35.67376469737289 139.73767928884362 36.224 35.67376469737289 139.73767928884362 45.179 35.67378525108416 139.7377390823533 45.179 35.67378525108416 139.7377390823533 9.12 35.67375519296529 139.7376516391867 9.12 35.67375519296529 139.7376516391867 31.386 35.67375661138426 139.73765574687528 31.386</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2719ea2-4302-4b53-bfbd-2d06278f6e70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2719ea2-4302-4b53-bfbd-2d06278f6e70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2719ea2-4302-4b53-bfbd-2d06278f6e70">
											<gml:posList>35.67371675647464 139.73771724733805 45.388 35.67371675647464 139.73771724733805 45.101 35.673706283896195 139.73768492608676 45.101 35.673706283896195 139.73768492608676 45.388 35.67371675647464 139.73771724733805 45.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04c2cbbc-219f-4e6f-ad8b-5b50675b4fe5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04c2cbbc-219f-4e6f-ad8b-5b50675b4fe5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04c2cbbc-219f-4e6f-ad8b-5b50675b4fe5">
											<gml:posList>35.67371053136044 139.73771014067634 45.179 35.67371053136044 139.73771014067634 44.857 35.673714714957356 139.73772303825353 44.857 35.673714714957356 139.73772303825353 45.388 35.67370154970279 139.73768242413044 45.388 35.67370154970279 139.73768242413044 36.224 35.67370946511872 139.7377068389795 36.224 35.67370946511872 139.7377068389795 45.179 35.67371053136044 139.73771014067634 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-157e5784-9a86-4d00-b010-51589703bbcc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-157e5784-9a86-4d00-b010-51589703bbcc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-157e5784-9a86-4d00-b010-51589703bbcc">
											<gml:posList>35.6737631506905 139.73768391926697 45.179 35.6737631506905 139.73768391926697 44.857 35.673781472828296 139.73773718682142 44.857 35.673781472828296 139.73773718682142 45.179 35.6737631506905 139.73768391926697 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70f1aa31-4759-4f05-b847-0565ca04a38b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70f1aa31-4759-4f05-b847-0565ca04a38b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70f1aa31-4759-4f05-b847-0565ca04a38b">
											<gml:posList>35.67374161573114 139.73770514362087 45.388 35.67374161573114 139.73770514362087 45.101 35.67371675647464 139.73771724733805 45.101 35.67371675647464 139.73771724733805 45.388 35.67374161573114 139.73770514362087 45.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2daae87f-7c25-48e8-b282-6fd98fa93745">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2daae87f-7c25-48e8-b282-6fd98fa93745">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2daae87f-7c25-48e8-b282-6fd98fa93745">
											<gml:posList>35.673683830989255 139.73771933025048 45.179 35.67370946511872 139.7377068389795 45.179 35.67370946511872 139.7377068389795 36.224 35.673683830989255 139.73771933025048 36.224 35.673683830989255 139.73771933025048 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5bf81e71-83eb-4e9e-b30f-d93b4efe11de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bf81e71-83eb-4e9e-b30f-d93b4efe11de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bf81e71-83eb-4e9e-b30f-d93b4efe11de">
											<gml:posList>35.673714714957356 139.73772303825353 44.857 35.67374634090155 139.73770763454382 44.857 35.67374634090155 139.73770763454382 45.388 35.673714714957356 139.73772303825353 45.388 35.673714714957356 139.73772303825353 44.857</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d90c482d-5540-413d-874d-be9956f2ca0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d90c482d-5540-413d-874d-be9956f2ca0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d90c482d-5540-413d-874d-be9956f2ca0e">
											<gml:posList>35.673687645352956 139.73772129201643 45.179 35.673687645352956 139.73772129201643 44.857 35.67371053136044 139.73771014067634 44.857 35.67371053136044 139.73771014067634 45.179 35.673687645352956 139.73772129201643 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c19327c-4f65-4a57-8fbb-d834102231f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c19327c-4f65-4a57-8fbb-d834102231f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c19327c-4f65-4a57-8fbb-d834102231f3">
											<gml:posList>35.673781472828296 139.73773718682142 45.179 35.673781472828296 139.73773718682142 44.857 35.6737630743342 139.73774667580437 44.857 35.6737630743342 139.73774667580437 45.179 35.673781472828296 139.73773718682142 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb7d2507-b21d-4f36-87c1-47620b9f2e3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb7d2507-b21d-4f36-87c1-47620b9f2e3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb7d2507-b21d-4f36-87c1-47620b9f2e3e">
											<gml:posList>35.67376685258992 139.73774857133623 9.12 35.67378525108416 139.7377390823533 9.12 35.67378525108416 139.7377390823533 45.179 35.67376685258992 139.73774857133623 45.179 35.67376685258992 139.73774857133623 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-650f5a3c-b987-4027-8444-b87e9992f38b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-650f5a3c-b987-4027-8444-b87e9992f38b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-650f5a3c-b987-4027-8444-b87e9992f38b">
											<gml:posList>35.67377280637839 139.73776588550479 9.12 35.67376685258992 139.73774857133623 9.12 35.67376685258992 139.73774857133623 45.179 35.67377280637839 139.73776588550479 45.179 35.67377280637839 139.73776588550479 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8926ba0e-d4e4-4cfa-a998-128a8aa6141c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8926ba0e-d4e4-4cfa-a998-128a8aa6141c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8926ba0e-d4e4-4cfa-a998-128a8aa6141c">
											<gml:posList>35.673683830989255 139.73771933025048 36.224 35.67367569982573 139.7376956447484 36.224 35.67367569982573 139.7376956447484 31.386 35.67367569982573 139.7376956447484 9.12 35.67371843346615 139.73782001296595 9.12 35.67371843346615 139.73782001296595 45.179 35.673683830989255 139.73771933025048 45.179 35.673683830989255 139.73771933025048 36.224</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6e5a56f-253b-4e35-b652-4a2e353dcb51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6e5a56f-253b-4e35-b652-4a2e353dcb51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6e5a56f-253b-4e35-b652-4a2e353dcb51">
											<gml:posList>35.6737630743342 139.73774667580437 45.179 35.6737630743342 139.73774667580437 44.857 35.67377126869761 139.7377705048695 44.857 35.67377126869761 139.7377705048695 45.179 35.6737630743342 139.73774667580437 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58db5e23-24f8-4bd5-9f52-588115872a33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58db5e23-24f8-4bd5-9f52-588115872a33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58db5e23-24f8-4bd5-9f52-588115872a33">
											<gml:posList>35.6737803117358 139.737762010203 9.12 35.67377280637839 139.73776588550479 9.12 35.67377280637839 139.73776588550479 45.179 35.6737803117358 139.737762010203 45.179 35.6737803117358 139.737762010203 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55b5bb4b-7f75-428c-98a8-60288a8875cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55b5bb4b-7f75-428c-98a8-60288a8875cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55b5bb4b-7f75-428c-98a8-60288a8875cb">
											<gml:posList>35.67371997113132 139.7378153715118 45.179 35.67371997113132 139.7378153715118 44.857 35.673687645352956 139.73772129201643 44.857 35.673687645352956 139.73772129201643 45.179 35.67371997113132 139.7378153715118 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5c85f40-eebc-4da0-bd5c-cd8cc8f8e4d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5c85f40-eebc-4da0-bd5c-cd8cc8f8e4d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5c85f40-eebc-4da0-bd5c-cd8cc8f8e4d0">
											<gml:posList>35.67377126869761 139.7377705048695 45.179 35.67377126869761 139.7377705048695 44.857 35.67377877405518 139.7377666295682 44.857 35.67377877405518 139.7377666295682 45.179 35.67377126869761 139.7377705048695 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-beb1a3f0-b584-48d4-a149-941ae275d085">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-beb1a3f0-b584-48d4-a149-941ae275d085">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-beb1a3f0-b584-48d4-a149-941ae275d085">
											<gml:posList>35.673787918854615 139.73778413877852 9.12 35.6737803117358 139.737762010203 9.12 35.6737803117358 139.737762010203 45.179 35.673787918854615 139.73778413877852 45.179 35.673787918854615 139.73778413877852 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5beb219b-5f4d-461b-bbba-0f5aba9bd8af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5beb219b-5f4d-461b-bbba-0f5aba9bd8af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5beb219b-5f4d-461b-bbba-0f5aba9bd8af">
											<gml:posList>35.67377877405518 139.7377666295682 45.179 35.67377877405518 139.7377666295682 44.857 35.67378414059946 139.73778224324445 44.857 35.67378414059946 139.73778224324445 45.179 35.67377877405518 139.7377666295682 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e47021c-743f-426d-a948-36ae5f8dd090">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e47021c-743f-426d-a948-36ae5f8dd090">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e47021c-743f-426d-a948-36ae5f8dd090">
											<gml:posList>35.67378414059946 139.73778224324445 45.179 35.67378414059946 139.73778224324445 44.857 35.67371997113132 139.7378153715118 44.857 35.67371997113132 139.7378153715118 45.179 35.67378414059946 139.73778224324445 45.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95482d48-518c-494f-b239-8d42b62f7991">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95482d48-518c-494f-b239-8d42b62f7991">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95482d48-518c-494f-b239-8d42b62f7991">
											<gml:posList>35.67371843346615 139.73782001296595 9.12 35.673787918854615 139.73778413877852 9.12 35.673787918854615 139.73778413877852 45.179 35.67371843346615 139.73782001296595 45.179 35.67371843346615 139.73782001296595 9.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-881</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">102.14989</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.1</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>