<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3b74d756-e848-495d-9f8c-5b96edc5a69b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">403</bldg:usage>
			<bldg:measuredHeight uom="m">62.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>16</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.674676011078404 139.74095663073638 0 35.67456517228453 139.74094876055008 0 35.674564116771435 139.7409710763752 0 35.6745181442662 139.74096780424662 0 35.674516396988984 139.7410048683725 0 35.67450215452891 139.74100385742094 0 35.67448882283345 139.74128588718702 0 35.6745080681743 139.7412872459427 0 35.67450678210003 139.74131461041262 0 35.67454935623086 139.74131763256318 0 35.67454786602434 139.74134917298412 0 35.67467512869595 139.74135821793863 0 35.674676361744375 139.7413322232823 0 35.6747191882745 139.74133526725248 0 35.67472075836801 139.74130211383095 0 35.67473787636111 139.74130333142736 0 35.67475135895727 139.74101820749274 0 35.67473654859988 139.74101715300253 0 35.67473813629427 139.740983557673 0 35.67469307422689 139.74098035076264 0 35.67469413867054 139.74095792442293 0 35.674676011078404 139.74095663073638 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674676011078404 139.74095663073638 9.39 35.67469413867054 139.74095792442293 9.39 35.67469307422689 139.74098035076264 9.39 35.67473813629427 139.740983557673 9.39 35.67473654859988 139.74101715300253 9.39 35.67475135895727 139.74101820749274 9.39 35.67473787636111 139.74130333142736 9.39 35.67472075836801 139.74130211383095 9.39 35.6747191882745 139.74133526725248 9.39 35.674676361744375 139.7413322232823 9.39 35.67467512869595 139.74135821793863 9.39 35.67454786602434 139.74134917298412 9.39 35.67454935623086 139.74131763256318 9.39 35.67450678210003 139.74131461041262 9.39 35.6745080681743 139.7412872459427 9.39 35.67448882283345 139.74128588718702 9.39 35.67450215452891 139.74100385742094 9.39 35.674516396988984 139.7410048683725 9.39 35.6745181442662 139.74096780424662 9.39 35.674564116771435 139.7409710763752 9.39 35.67456517228453 139.74094876055008 9.39 35.674676011078404 139.74095663073638 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674676011078404 139.74095663073638 9.39 35.67456517228453 139.74094876055008 9.39 35.67456517228453 139.74094876055008 65.86 35.674676011078404 139.74095663073638 65.86 35.674676011078404 139.74095663073638 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67456517228453 139.74094876055008 9.39 35.674564116771435 139.7409710763752 9.39 35.674564116771435 139.7409710763752 65.86 35.67456517228453 139.74094876055008 65.86 35.67456517228453 139.74094876055008 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674564116771435 139.7409710763752 9.39 35.6745181442662 139.74096780424662 9.39 35.6745181442662 139.74096780424662 65.86 35.674564116771435 139.7409710763752 65.86 35.674564116771435 139.7409710763752 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6745181442662 139.74096780424662 9.39 35.674516396988984 139.7410048683725 9.39 35.674516396988984 139.7410048683725 65.86 35.6745181442662 139.74096780424662 65.86 35.6745181442662 139.74096780424662 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674516396988984 139.7410048683725 9.39 35.67450215452891 139.74100385742094 9.39 35.67450215452891 139.74100385742094 65.86 35.674516396988984 139.7410048683725 65.86 35.674516396988984 139.7410048683725 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67450215452891 139.74100385742094 9.39 35.67448882283345 139.74128588718702 9.39 35.67448882283345 139.74128588718702 65.86 35.67450215452891 139.74100385742094 65.86 35.67450215452891 139.74100385742094 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67448882283345 139.74128588718702 9.39 35.6745080681743 139.7412872459427 9.39 35.6745080681743 139.7412872459427 65.86 35.67448882283345 139.74128588718702 65.86 35.67448882283345 139.74128588718702 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6745080681743 139.7412872459427 9.39 35.67450678210003 139.74131461041262 9.39 35.67450678210003 139.74131461041262 65.86 35.6745080681743 139.7412872459427 65.86 35.6745080681743 139.7412872459427 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67450678210003 139.74131461041262 9.39 35.67454935623086 139.74131763256318 9.39 35.67454935623086 139.74131763256318 65.86 35.67450678210003 139.74131461041262 65.86 35.67450678210003 139.74131461041262 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67454935623086 139.74131763256318 9.39 35.67454786602434 139.74134917298412 9.39 35.67454786602434 139.74134917298412 65.86 35.67454935623086 139.74131763256318 65.86 35.67454935623086 139.74131763256318 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67454786602434 139.74134917298412 9.39 35.67467512869595 139.74135821793863 9.39 35.67467512869595 139.74135821793863 65.86 35.67454786602434 139.74134917298412 65.86 35.67454786602434 139.74134917298412 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67467512869595 139.74135821793863 9.39 35.674676361744375 139.7413322232823 9.39 35.674676361744375 139.7413322232823 65.86 35.67467512869595 139.74135821793863 65.86 35.67467512869595 139.74135821793863 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674676361744375 139.7413322232823 9.39 35.6747191882745 139.74133526725248 9.39 35.6747191882745 139.74133526725248 65.86 35.674676361744375 139.7413322232823 65.86 35.674676361744375 139.7413322232823 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6747191882745 139.74133526725248 9.39 35.67472075836801 139.74130211383095 9.39 35.67472075836801 139.74130211383095 65.86 35.6747191882745 139.74133526725248 65.86 35.6747191882745 139.74133526725248 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67472075836801 139.74130211383095 9.39 35.67473787636111 139.74130333142736 9.39 35.67473787636111 139.74130333142736 65.86 35.67472075836801 139.74130211383095 65.86 35.67472075836801 139.74130211383095 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67473787636111 139.74130333142736 9.39 35.67475135895727 139.74101820749274 9.39 35.67475135895727 139.74101820749274 65.86 35.67473787636111 139.74130333142736 65.86 35.67473787636111 139.74130333142736 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67475135895727 139.74101820749274 9.39 35.67473654859988 139.74101715300253 9.39 35.67473654859988 139.74101715300253 65.86 35.67475135895727 139.74101820749274 65.86 35.67475135895727 139.74101820749274 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67473654859988 139.74101715300253 9.39 35.67473813629427 139.740983557673 9.39 35.67473813629427 139.740983557673 65.86 35.67473654859988 139.74101715300253 65.86 35.67473654859988 139.74101715300253 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67473813629427 139.740983557673 9.39 35.67469307422689 139.74098035076264 9.39 35.67469307422689 139.74098035076264 65.86 35.67473813629427 139.740983557673 65.86 35.67473813629427 139.740983557673 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67469307422689 139.74098035076264 9.39 35.67469413867054 139.74095792442293 9.39 35.67469413867054 139.74095792442293 65.86 35.67469307422689 139.74098035076264 65.86 35.67469307422689 139.74098035076264 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67469413867054 139.74095792442293 9.39 35.674676011078404 139.74095663073638 9.39 35.674676011078404 139.74095663073638 65.86 35.67469413867054 139.74095792442293 65.86 35.67469413867054 139.74095792442293 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674676011078404 139.74095663073638 65.86 35.67456517228453 139.74094876055008 65.86 35.674564116771435 139.7409710763752 65.86 35.6745181442662 139.74096780424662 65.86 35.674516396988984 139.7410048683725 65.86 35.67450215452891 139.74100385742094 65.86 35.67448882283345 139.74128588718702 65.86 35.6745080681743 139.7412872459427 65.86 35.67450678210003 139.74131461041262 65.86 35.67454935623086 139.74131763256318 65.86 35.67454786602434 139.74134917298412 65.86 35.67467512869595 139.74135821793863 65.86 35.674676361744375 139.7413322232823 65.86 35.6747191882745 139.74133526725248 65.86 35.67472075836801 139.74130211383095 65.86 35.67473787636111 139.74130333142736 65.86 35.67475135895727 139.74101820749274 65.86 35.67473654859988 139.74101715300253 65.86 35.67473813629427 139.740983557673 65.86 35.67469307422689 139.74098035076264 65.86 35.67469413867054 139.74095792442293 65.86 35.674676011078404 139.74095663073638 65.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a2201dd8-4c74-4daa-9f9b-bb5da8e3dbbc"/>
							<gml:surfaceMember xlink:href="#poly-a60f91c7-6fe5-41f8-b506-c38999e5aca8"/>
							<gml:surfaceMember xlink:href="#poly-e8bf7c56-b1dc-463e-9992-cee65061dde1"/>
							<gml:surfaceMember xlink:href="#poly-6ab6eaf5-6400-4326-9c03-871255520a9b"/>
							<gml:surfaceMember xlink:href="#poly-fa1acc84-690b-4c9b-b221-ba24a4c49918"/>
							<gml:surfaceMember xlink:href="#poly-b8879f2f-89e1-4738-aec9-adb2137fe365"/>
							<gml:surfaceMember xlink:href="#poly-383b2ae6-d734-4d5b-bf57-3c5a98790971"/>
							<gml:surfaceMember xlink:href="#poly-15d4ea55-a989-4bab-948e-3eaba94e5c07"/>
							<gml:surfaceMember xlink:href="#poly-15255ff2-adab-47ab-bf7e-26290ddf681b"/>
							<gml:surfaceMember xlink:href="#poly-b67c35a2-9a3a-449e-a2e6-31ee039e18fb"/>
							<gml:surfaceMember xlink:href="#poly-7b83f629-096e-4343-8539-4cab57f0b866"/>
							<gml:surfaceMember xlink:href="#poly-539807a7-a1a5-46d1-985c-3d2d2d0b220f"/>
							<gml:surfaceMember xlink:href="#poly-8513fe21-7670-4421-8db2-38c3342ce764"/>
							<gml:surfaceMember xlink:href="#poly-8b83a33f-47ff-4295-ae9c-078f099a9a41"/>
							<gml:surfaceMember xlink:href="#poly-a37dad6d-ec0d-4c70-b445-0844f1144d94"/>
							<gml:surfaceMember xlink:href="#poly-803c47f3-e8af-4660-8584-427da1e7178d"/>
							<gml:surfaceMember xlink:href="#poly-6e9350fa-11e2-4b2d-b194-c2e2f7a32921"/>
							<gml:surfaceMember xlink:href="#poly-4b5a46f0-6047-4452-a9a9-5ba8627838ef"/>
							<gml:surfaceMember xlink:href="#poly-8ab2beea-e970-492d-9a63-e0ec2c2699cf"/>
							<gml:surfaceMember xlink:href="#poly-07d358ee-3391-48c8-9979-9e16fcccefc1"/>
							<gml:surfaceMember xlink:href="#poly-fc226fbe-e35e-4861-85fd-ffce7703fafd"/>
							<gml:surfaceMember xlink:href="#poly-ac9fa949-2363-459f-855e-0ae51863c5f9"/>
							<gml:surfaceMember xlink:href="#poly-ac7813e0-2bc4-4a8a-ad58-51dc165116b4"/>
							<gml:surfaceMember xlink:href="#poly-6ab00d7f-6fe8-4975-a220-3ce3e62a4d70"/>
							<gml:surfaceMember xlink:href="#poly-cec172dc-9756-4519-a601-153f71e97d71"/>
							<gml:surfaceMember xlink:href="#poly-316c6572-29bf-4771-91af-66cf81946e58"/>
							<gml:surfaceMember xlink:href="#poly-0b64bdd1-e0dc-4a69-92bd-7c90c1388e08"/>
							<gml:surfaceMember xlink:href="#poly-7f633f5b-8958-4842-bb0e-09eed47294b2"/>
							<gml:surfaceMember xlink:href="#poly-450bb398-461c-4ed3-938e-0534535ae87e"/>
							<gml:surfaceMember xlink:href="#poly-0c0d05cf-db24-415c-bef0-7687fb01e68d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a2201dd8-4c74-4daa-9f9b-bb5da8e3dbbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2201dd8-4c74-4daa-9f9b-bb5da8e3dbbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2201dd8-4c74-4daa-9f9b-bb5da8e3dbbc">
											<gml:posList>35.67448882283345 139.74128588718702 9.39 35.674502163542606 139.74100385741056 9.39 35.67451639698896 139.74100486837247 9.39 35.67451815327991 139.74096780423622 9.39 35.674564116771435 139.7409710763752 9.39 35.67456517228452 139.74094876055008 9.39 35.674694138670546 139.74095792442293 9.39 35.67469307422685 139.74098035076264 9.39 35.67473813629425 139.74098355767296 9.39 35.67473654859987 139.7410171530025 9.39 35.67475136797099 139.74101820748234 9.39 35.674737876352644 139.7413033203805 9.39 35.674720758368004 139.74130211383095 9.39 35.67471918827452 139.74133526725248 9.39 35.674676361744346 139.7413322232823 9.39 35.674675128695945 139.7413582179386 9.39 35.6745478660243 139.74134917298412 9.39 35.67454935623087 139.74131763256318 9.39 35.67450678210001 139.74131461041262 9.39 35.67450807718799 139.74128724593234 9.39 35.67448882283345 139.74128588718702 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a60f91c7-6fe5-41f8-b506-c38999e5aca8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a60f91c7-6fe5-41f8-b506-c38999e5aca8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a60f91c7-6fe5-41f8-b506-c38999e5aca8">
											<gml:posList>35.67448882283345 139.74128588718702 69.608 35.67456891321041 139.74121965781433 69.608 35.67457305556763 139.74113205163525 69.608 35.674502163542606 139.74100385741056 69.608 35.67448882283345 139.74128588718702 69.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e8bf7c56-b1dc-463e-9992-cee65061dde1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8bf7c56-b1dc-463e-9992-cee65061dde1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8bf7c56-b1dc-463e-9992-cee65061dde1">
											<gml:posList>35.67451815327991 139.74096780423622 65.893 35.67451639698896 139.74100486837247 65.893 35.67456236948477 139.74100812947543 65.893 35.674564116771435 139.7409710763752 65.893 35.67451815327991 139.74096780423622 65.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6ab6eaf5-6400-4326-9c03-871255520a9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ab6eaf5-6400-4326-9c03-871255520a9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ab6eaf5-6400-4326-9c03-871255520a9b">
											<gml:posList>35.67466776792294 139.7411387807026 71.608 35.67457305556763 139.74113205163525 71.608 35.67456891321041 139.74121965781433 71.608 35.67466362555259 139.74122637593806 71.608 35.67466776792294 139.7411387807026 71.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa1acc84-690b-4c9b-b221-ba24a4c49918">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa1acc84-690b-4c9b-b221-ba24a4c49918">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa1acc84-690b-4c9b-b221-ba24a4c49918">
											<gml:posList>35.67456236948477 139.74100812947543 69.608 35.674502163542606 139.74100385741056 69.608 35.67457305556763 139.74113205163525 69.608 35.67466776792294 139.7411387807026 69.608 35.67466362555259 139.74122637593806 69.608 35.67456891321041 139.74121965781433 69.608 35.67448882283345 139.74128588718702 69.608 35.67450807718799 139.74128724593234 69.608 35.67450678210001 139.74131461041262 69.608 35.67454935623087 139.74131763256318 69.608 35.6745478660243 139.74134917298412 69.608 35.674675128695945 139.7413582179386 69.608 35.674676361744346 139.7413322232823 69.608 35.67471918827452 139.74133526725248 69.608 35.674720758368004 139.74130211383095 69.608 35.674737876352644 139.7413033203805 69.608 35.67475136797099 139.74101820748234 69.608 35.67469148653331 139.74101394607334 69.608 35.674694138670546 139.74095792442293 69.608 35.67456517228452 139.74094876055008 69.608 35.67456236948477 139.74100812947543 69.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8879f2f-89e1-4738-aec9-adb2137fe365">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8879f2f-89e1-4738-aec9-adb2137fe365">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8879f2f-89e1-4738-aec9-adb2137fe365">
											<gml:posList>35.67469148653331 139.74101394607334 65.893 35.67473654859987 139.7410171530025 65.893 35.67473813629425 139.74098355767296 65.893 35.67469307422685 139.74098035076264 65.893 35.67469148653331 139.74101394607334 65.893</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-383b2ae6-d734-4d5b-bf57-3c5a98790971">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-383b2ae6-d734-4d5b-bf57-3c5a98790971">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-383b2ae6-d734-4d5b-bf57-3c5a98790971">
											<gml:posList>35.674502163542606 139.74100385741056 9.39 35.67448882283345 139.74128588718702 9.39 35.67448882283345 139.74128588718702 69.608 35.674502163542606 139.74100385741056 69.608 35.674502163542606 139.74100385741056 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15d4ea55-a989-4bab-948e-3eaba94e5c07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15d4ea55-a989-4bab-948e-3eaba94e5c07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15d4ea55-a989-4bab-948e-3eaba94e5c07">
											<gml:posList>35.67448882283345 139.74128588718702 9.39 35.67450807718799 139.74128724593234 9.39 35.67450807718799 139.74128724593234 69.608 35.67448882283345 139.74128588718702 69.608 35.67448882283345 139.74128588718702 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15255ff2-adab-47ab-bf7e-26290ddf681b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15255ff2-adab-47ab-bf7e-26290ddf681b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15255ff2-adab-47ab-bf7e-26290ddf681b">
											<gml:posList>35.67450807718799 139.74128724593234 9.39 35.67450678210001 139.74131461041262 9.39 35.67450678210001 139.74131461041262 69.608 35.67450807718799 139.74128724593234 69.608 35.67450807718799 139.74128724593234 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b67c35a2-9a3a-449e-a2e6-31ee039e18fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b67c35a2-9a3a-449e-a2e6-31ee039e18fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b67c35a2-9a3a-449e-a2e6-31ee039e18fb">
											<gml:posList>35.67451815327991 139.74096780423622 9.39 35.67451639698896 139.74100486837247 9.39 35.67451639698896 139.74100486837247 65.893 35.67451815327991 139.74096780423622 65.893 35.67451815327991 139.74096780423622 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b83f629-096e-4343-8539-4cab57f0b866">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b83f629-096e-4343-8539-4cab57f0b866">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b83f629-096e-4343-8539-4cab57f0b866">
											<gml:posList>35.67450678210001 139.74131461041262 9.39 35.67454935623087 139.74131763256318 9.39 35.67454935623087 139.74131763256318 69.608 35.67450678210001 139.74131461041262 69.608 35.67450678210001 139.74131461041262 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-539807a7-a1a5-46d1-985c-3d2d2d0b220f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-539807a7-a1a5-46d1-985c-3d2d2d0b220f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-539807a7-a1a5-46d1-985c-3d2d2d0b220f">
											<gml:posList>35.67456236948477 139.74100812947543 69.608 35.67456236948477 139.74100812947543 65.893 35.67451639698896 139.74100486837247 65.893 35.67451639698896 139.74100486837247 9.39 35.674502163542606 139.74100385741056 9.39 35.674502163542606 139.74100385741056 69.608 35.67456236948477 139.74100812947543 69.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8513fe21-7670-4421-8db2-38c3342ce764">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8513fe21-7670-4421-8db2-38c3342ce764">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8513fe21-7670-4421-8db2-38c3342ce764">
											<gml:posList>35.674564116771435 139.7409710763752 9.39 35.67451815327991 139.74096780423622 9.39 35.67451815327991 139.74096780423622 65.893 35.674564116771435 139.7409710763752 65.893 35.674564116771435 139.7409710763752 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b83a33f-47ff-4295-ae9c-078f099a9a41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b83a33f-47ff-4295-ae9c-078f099a9a41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b83a33f-47ff-4295-ae9c-078f099a9a41">
											<gml:posList>35.67454935623087 139.74131763256318 9.39 35.6745478660243 139.74134917298412 9.39 35.6745478660243 139.74134917298412 69.608 35.67454935623087 139.74131763256318 69.608 35.67454935623087 139.74131763256318 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a37dad6d-ec0d-4c70-b445-0844f1144d94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a37dad6d-ec0d-4c70-b445-0844f1144d94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a37dad6d-ec0d-4c70-b445-0844f1144d94">
											<gml:posList>35.67456517228452 139.74094876055008 9.39 35.674564116771435 139.7409710763752 9.39 35.674564116771435 139.7409710763752 65.893 35.67456236948477 139.74100812947543 65.893 35.67456236948477 139.74100812947543 69.608 35.67456517228452 139.74094876055008 69.608 35.67456517228452 139.74094876055008 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-803c47f3-e8af-4660-8584-427da1e7178d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-803c47f3-e8af-4660-8584-427da1e7178d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-803c47f3-e8af-4660-8584-427da1e7178d">
											<gml:posList>35.67456891321041 139.74121965781433 69.608 35.67456891321041 139.74121965781433 71.608 35.67457305556763 139.74113205163525 71.608 35.67457305556763 139.74113205163525 69.608 35.67456891321041 139.74121965781433 69.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e9350fa-11e2-4b2d-b194-c2e2f7a32921">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e9350fa-11e2-4b2d-b194-c2e2f7a32921">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e9350fa-11e2-4b2d-b194-c2e2f7a32921">
											<gml:posList>35.6745478660243 139.74134917298412 9.39 35.674675128695945 139.7413582179386 9.39 35.674675128695945 139.7413582179386 69.608 35.6745478660243 139.74134917298412 69.608 35.6745478660243 139.74134917298412 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b5a46f0-6047-4452-a9a9-5ba8627838ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b5a46f0-6047-4452-a9a9-5ba8627838ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b5a46f0-6047-4452-a9a9-5ba8627838ef">
											<gml:posList>35.67466362555259 139.74122637593806 69.608 35.67466362555259 139.74122637593806 71.608 35.67456891321041 139.74121965781433 71.608 35.67456891321041 139.74121965781433 69.608 35.67466362555259 139.74122637593806 69.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ab2beea-e970-492d-9a63-e0ec2c2699cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ab2beea-e970-492d-9a63-e0ec2c2699cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ab2beea-e970-492d-9a63-e0ec2c2699cf">
											<gml:posList>35.67457305556763 139.74113205163525 69.608 35.67457305556763 139.74113205163525 71.608 35.67466776792294 139.7411387807026 71.608 35.67466776792294 139.7411387807026 69.608 35.67457305556763 139.74113205163525 69.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07d358ee-3391-48c8-9979-9e16fcccefc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07d358ee-3391-48c8-9979-9e16fcccefc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07d358ee-3391-48c8-9979-9e16fcccefc1">
											<gml:posList>35.674694138670546 139.74095792442293 9.39 35.67456517228452 139.74094876055008 9.39 35.67456517228452 139.74094876055008 69.608 35.674694138670546 139.74095792442293 69.608 35.674694138670546 139.74095792442293 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc226fbe-e35e-4861-85fd-ffce7703fafd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc226fbe-e35e-4861-85fd-ffce7703fafd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc226fbe-e35e-4861-85fd-ffce7703fafd">
											<gml:posList>35.67473813629425 139.74098355767296 9.39 35.67469307422685 139.74098035076264 9.39 35.67469307422685 139.74098035076264 65.893 35.67473813629425 139.74098355767296 65.893 35.67473813629425 139.74098355767296 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac9fa949-2363-459f-855e-0ae51863c5f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac9fa949-2363-459f-855e-0ae51863c5f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac9fa949-2363-459f-855e-0ae51863c5f9">
											<gml:posList>35.67469148653331 139.74101394607334 69.608 35.67469148653331 139.74101394607334 65.893 35.67469307422685 139.74098035076264 65.893 35.67469307422685 139.74098035076264 9.39 35.674694138670546 139.74095792442293 9.39 35.674694138670546 139.74095792442293 69.608 35.67469148653331 139.74101394607334 69.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac7813e0-2bc4-4a8a-ad58-51dc165116b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac7813e0-2bc4-4a8a-ad58-51dc165116b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac7813e0-2bc4-4a8a-ad58-51dc165116b4">
											<gml:posList>35.67473654859987 139.7410171530025 9.39 35.67473813629425 139.74098355767296 9.39 35.67473813629425 139.74098355767296 65.893 35.67473654859987 139.7410171530025 65.893 35.67473654859987 139.7410171530025 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ab00d7f-6fe8-4975-a220-3ce3e62a4d70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ab00d7f-6fe8-4975-a220-3ce3e62a4d70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ab00d7f-6fe8-4975-a220-3ce3e62a4d70">
											<gml:posList>35.67475136797099 139.74101820748234 9.39 35.67473654859987 139.7410171530025 9.39 35.67473654859987 139.7410171530025 65.893 35.67469148653331 139.74101394607334 65.893 35.67469148653331 139.74101394607334 69.608 35.67475136797099 139.74101820748234 69.608 35.67475136797099 139.74101820748234 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cec172dc-9756-4519-a601-153f71e97d71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cec172dc-9756-4519-a601-153f71e97d71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cec172dc-9756-4519-a601-153f71e97d71">
											<gml:posList>35.674737876352644 139.7413033203805 9.39 35.67475136797099 139.74101820748234 9.39 35.67475136797099 139.74101820748234 69.608 35.674737876352644 139.7413033203805 69.608 35.674737876352644 139.7413033203805 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-316c6572-29bf-4771-91af-66cf81946e58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-316c6572-29bf-4771-91af-66cf81946e58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-316c6572-29bf-4771-91af-66cf81946e58">
											<gml:posList>35.67466776792294 139.7411387807026 69.608 35.67466776792294 139.7411387807026 71.608 35.67466362555259 139.74122637593806 71.608 35.67466362555259 139.74122637593806 69.608 35.67466776792294 139.7411387807026 69.608</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b64bdd1-e0dc-4a69-92bd-7c90c1388e08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b64bdd1-e0dc-4a69-92bd-7c90c1388e08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b64bdd1-e0dc-4a69-92bd-7c90c1388e08">
											<gml:posList>35.674720758368004 139.74130211383095 9.39 35.674737876352644 139.7413033203805 9.39 35.674737876352644 139.7413033203805 69.608 35.674720758368004 139.74130211383095 69.608 35.674720758368004 139.74130211383095 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f633f5b-8958-4842-bb0e-09eed47294b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f633f5b-8958-4842-bb0e-09eed47294b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f633f5b-8958-4842-bb0e-09eed47294b2">
											<gml:posList>35.67471918827452 139.74133526725248 9.39 35.674720758368004 139.74130211383095 9.39 35.674720758368004 139.74130211383095 69.608 35.67471918827452 139.74133526725248 69.608 35.67471918827452 139.74133526725248 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-450bb398-461c-4ed3-938e-0534535ae87e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-450bb398-461c-4ed3-938e-0534535ae87e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-450bb398-461c-4ed3-938e-0534535ae87e">
											<gml:posList>35.674676361744346 139.7413322232823 9.39 35.67471918827452 139.74133526725248 9.39 35.67471918827452 139.74133526725248 69.608 35.674676361744346 139.7413322232823 69.608 35.674676361744346 139.7413322232823 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c0d05cf-db24-415c-bef0-7687fb01e68d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c0d05cf-db24-415c-bef0-7687fb01e68d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c0d05cf-db24-415c-bef0-7687fb01e68d">
											<gml:posList>35.674675128695945 139.7413582179386 9.39 35.674676361744346 139.7413322232823 9.39 35.674676361744346 139.7413322232823 69.608 35.674675128695945 139.7413582179386 69.608 35.674675128695945 139.7413582179386 9.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4593</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">913.93305</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1241</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.34</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>