<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3c363f6f-a5a2-4f5b-91b8-595d6e793b46">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">10.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669148752433344 139.74921600812186 0 35.66916845166089 139.7491575536218 0 35.66908738867629 139.74911533222848 0 35.66906157055605 139.7491887053084 0 35.669130370295036 139.74922442243331 0 35.669148752433344 139.74921600812186 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669148752433344 139.74921600812186 6.19 35.669130370295036 139.74922442243331 6.19 35.66906157055605 139.7491887053084 6.19 35.66908738867629 139.74911533222848 6.19 35.66916845166089 139.7491575536218 6.19 35.669148752433344 139.74921600812186 6.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669148752433344 139.74921600812186 6.19 35.66916845166089 139.7491575536218 6.19 35.66916845166089 139.7491575536218 16.52 35.669148752433344 139.74921600812186 16.52 35.669148752433344 139.74921600812186 6.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916845166089 139.7491575536218 6.19 35.66908738867629 139.74911533222848 6.19 35.66908738867629 139.74911533222848 16.52 35.66916845166089 139.7491575536218 16.52 35.66916845166089 139.7491575536218 6.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908738867629 139.74911533222848 6.19 35.66906157055605 139.7491887053084 6.19 35.66906157055605 139.7491887053084 16.52 35.66908738867629 139.74911533222848 16.52 35.66908738867629 139.74911533222848 6.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66906157055605 139.7491887053084 6.19 35.669130370295036 139.74922442243331 6.19 35.669130370295036 139.74922442243331 16.52 35.66906157055605 139.7491887053084 16.52 35.66906157055605 139.7491887053084 6.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669130370295036 139.74922442243331 6.19 35.669148752433344 139.74921600812186 6.19 35.669148752433344 139.74921600812186 16.52 35.669130370295036 139.74922442243331 16.52 35.669130370295036 139.74922442243331 6.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669148752433344 139.74921600812186 16.52 35.66916845166089 139.7491575536218 16.52 35.66908738867629 139.74911533222848 16.52 35.66906157055605 139.7491887053084 16.52 35.669130370295036 139.74922442243331 16.52 35.669148752433344 139.74921600812186 16.52</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-22427594-6ea3-48e7-a616-bc0281c8765f"/>
							<gml:surfaceMember xlink:href="#poly-f1e9e5fe-2144-4a72-b483-00595c618b55"/>
							<gml:surfaceMember xlink:href="#poly-7e7f3327-fe63-4a86-bd32-abe050f2f887"/>
							<gml:surfaceMember xlink:href="#poly-57e6724a-7cf7-42a3-b269-bd5af868d2ba"/>
							<gml:surfaceMember xlink:href="#poly-8c60da35-0df1-4708-a166-9454b9987d1d"/>
							<gml:surfaceMember xlink:href="#poly-8de484c6-8257-43a6-95c3-08a4e24a07c4"/>
							<gml:surfaceMember xlink:href="#poly-7203e7ef-2dca-49d8-b9de-2ce52ce043b4"/>
							<gml:surfaceMember xlink:href="#poly-9b429c55-bcad-44cd-807c-d0afc510c7ff"/>
							<gml:surfaceMember xlink:href="#poly-e129bfb1-d957-4e05-a15f-3fb581b6027c"/>
							<gml:surfaceMember xlink:href="#poly-75239aa1-f4cd-42ef-966d-36df4dc9049b"/>
							<gml:surfaceMember xlink:href="#poly-c90579e0-cfe8-4f8b-beed-4f75e94c8bc3"/>
							<gml:surfaceMember xlink:href="#poly-82d3f718-511f-4473-9743-70e953dec19b"/>
							<gml:surfaceMember xlink:href="#poly-68b22705-cd82-43fc-bd2a-3be84687ab23"/>
							<gml:surfaceMember xlink:href="#poly-d7aab5ad-7788-4d39-a1e7-dfa41ab20a8f"/>
							<gml:surfaceMember xlink:href="#poly-c4cf6e2a-1231-4bc5-9b31-1e483e76fe59"/>
							<gml:surfaceMember xlink:href="#poly-04caeaf2-6e2b-49d4-ac4b-92f55d3e7acb"/>
							<gml:surfaceMember xlink:href="#poly-1a0ce645-c109-45b1-9514-15dce6cb0ca9"/>
							<gml:surfaceMember xlink:href="#poly-99c55bc7-ed01-4511-ad8f-b948175cc6f0"/>
							<gml:surfaceMember xlink:href="#poly-bfa5c766-0016-43f0-b4a7-507d9daf291a"/>
							<gml:surfaceMember xlink:href="#poly-2928a847-203f-40be-b2c8-42dabc72e20b"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3c363f6f-a5a2-4f5b-91b8-595d6e793b46_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9bdcfb63-043c-469d-ba87-abea2c0960f3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907507055643 139.74915923124445 16.7 35.6690729154804 139.74915809576058 16.7 35.669082118242834 139.74913194002465 16.7 35.66908427331911 139.74913307550793 16.7 35.66907507055643 139.74915923124445 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c28008ab-611c-4e6e-94b7-4c9621ec82a4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908427331911 139.74913307550793 16.227 35.669100963875266 139.7491418506637 16.227 35.66909176111072 139.74916800640466 16.227 35.66907507055643 139.74915923124445 16.227 35.66908427331911 139.74913307550793 16.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5746b636-d7d8-494b-a685-92218ef65f4c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691435814459 139.74918145033132 16.7 35.6691532786941 139.74915347145082 16.7 35.66912833762877 139.74914048534424 16.7 35.669129255183 139.74913784436578 16.7 35.6691562522123 139.749152021291 16.7 35.669145646384415 139.74918258591143 16.7 35.6691435814459 139.74918145033132 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8472a1fc-4376-41df-866d-aad671a5d32a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669118892320085 139.74916782328017 16.227 35.66912833762877 139.74914048534424 16.227 35.6691532786941 139.74915347145082 16.227 35.6691435814459 139.74918145033132 16.227 35.669118892320085 139.74916782328017 16.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2a1ee2b-c179-4524-9cbb-5d27fdd1ca99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2a1ee2b-c179-4524-9cbb-5d27fdd1ca99_0">
											<gml:posList>35.669082118242834 139.74913194002465 16.7 35.6690729154804 139.74915809576058 16.7 35.6690729154804 139.74915809576058 18.819 35.669082118242834 139.74913194002465 18.819 35.669082118242834 139.74913194002465 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b53962f-aff4-434a-b513-1039a7e5519e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b53962f-aff4-434a-b513-1039a7e5519e_0">
											<gml:posList>35.66907507055643 139.74915923124445 16.7 35.66908427331911 139.74913307550793 16.7 35.66908427331911 139.74913307550793 16.227 35.66907507055643 139.74915923124445 16.227 35.66907507055643 139.74915923124445 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6152c619-054e-41d4-b271-ae07ccac1b82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6152c619-054e-41d4-b271-ae07ccac1b82_0">
											<gml:posList>35.66909176111072 139.74916800640466 16.227 35.66909176111072 139.74916800640466 18.819 35.6690729154804 139.74915809576058 18.819 35.6690729154804 139.74915809576058 16.7 35.66907507055643 139.74915923124445 16.7 35.66907507055643 139.74915923124445 16.227 35.66909176111072 139.74916800640466 16.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a1871e7-6ae5-4950-84df-a3c47c2104bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a1871e7-6ae5-4950-84df-a3c47c2104bb_0">
											<gml:posList>35.669082118242834 139.74913194002465 18.819 35.6690729154804 139.74915809576058 18.819 35.66909176111072 139.74916800640466 18.819 35.669100963875266 139.7491418506637 18.819 35.669082118242834 139.74913194002465 18.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90b9d1ff-bd26-4549-a47d-20e2b301fb23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90b9d1ff-bd26-4549-a47d-20e2b301fb23_0">
											<gml:posList>35.66908427331911 139.74913307550793 16.7 35.669082118242834 139.74913194002465 16.7 35.669082118242834 139.74913194002465 18.819 35.669100963875266 139.7491418506637 18.819 35.669100963875266 139.7491418506637 16.227 35.66908427331911 139.74913307550793 16.227 35.66908427331911 139.74913307550793 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94f4f1be-3aef-47c9-a35f-0906b13fb11f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94f4f1be-3aef-47c9-a35f-0906b13fb11f_0">
											<gml:posList>35.66909176111072 139.74916800640466 16.227 35.669100963875266 139.7491418506637 16.227 35.669100963875266 139.7491418506637 18.819 35.66909176111072 139.74916800640466 18.819 35.66909176111072 139.74916800640466 16.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13520cf4-9db3-43a3-91d2-d6079800a983">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13520cf4-9db3-43a3-91d2-d6079800a983_0">
											<gml:posList>35.669118892320085 139.74916782328017 16.227 35.669118892320085 139.74916782328017 18.554 35.669129255183 139.74913784436578 18.554 35.669129255183 139.74913784436578 16.7 35.66912833762877 139.74914048534424 16.7 35.66912833762877 139.74914048534424 16.227 35.669118892320085 139.74916782328017 16.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d00af9d-26f4-4502-b442-0efd2686c040">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d00af9d-26f4-4502-b442-0efd2686c040_0">
											<gml:posList>35.669145646384415 139.74918258591143 18.554 35.669118892320085 139.74916782328017 18.554 35.669118892320085 139.74916782328017 16.227 35.6691435814459 139.74918145033132 16.227 35.6691435814459 139.74918145033132 16.7 35.669145646384415 139.74918258591143 16.7 35.669145646384415 139.74918258591143 18.554</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af249b5b-a18e-4281-92db-971add3fa03a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af249b5b-a18e-4281-92db-971add3fa03a_0">
											<gml:posList>35.6691562522123 139.749152021291 18.554 35.669129255183 139.74913784436578 18.554 35.669118892320085 139.74916782328017 18.554 35.669145646384415 139.74918258591143 18.554 35.6691562522123 139.749152021291 18.554</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9e8ce69-e224-4710-84ee-0cb927d1db07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9e8ce69-e224-4710-84ee-0cb927d1db07_0">
											<gml:posList>35.66912833762877 139.74914048534424 16.227 35.66912833762877 139.74914048534424 16.7 35.6691532786941 139.74915347145082 16.7 35.6691532786941 139.74915347145082 16.227 35.66912833762877 139.74914048534424 16.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce455567-e9cb-403f-80dc-427c1b3b5db0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce455567-e9cb-403f-80dc-427c1b3b5db0_0">
											<gml:posList>35.669129255183 139.74913784436578 16.7 35.669129255183 139.74913784436578 18.554 35.6691562522123 139.749152021291 18.554 35.6691562522123 139.749152021291 16.7 35.669129255183 139.74913784436578 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55b4f194-51e2-46d5-8a55-4ca860a8667b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55b4f194-51e2-46d5-8a55-4ca860a8667b_0">
											<gml:posList>35.6691532786941 139.74915347145082 16.7 35.6691435814459 139.74918145033132 16.7 35.6691435814459 139.74918145033132 16.227 35.6691532786941 139.74915347145082 16.227 35.6691532786941 139.74915347145082 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c480ff1c-3919-46f4-aaeb-8872379a25e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c480ff1c-3919-46f4-aaeb-8872379a25e5_0">
											<gml:posList>35.669145646384415 139.74918258591143 16.7 35.6691562522123 139.749152021291 16.7 35.6691562522123 139.749152021291 18.554 35.669145646384415 139.74918258591143 18.554 35.669145646384415 139.74918258591143 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3c363f6f-a5a2-4f5b-91b8-595d6e793b46_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-488e4646-16a7-4290-9157-c1d07c9f515f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909169184541 139.74915918065722 18.819 35.66909112428949 139.74915962309635 18.819 35.66909052064004 139.74916001034296 18.819 35.6690898899031 139.7491603313415 18.819 35.66908925009837 139.74916057502696 18.819 35.66908858320613 139.74916075246438 18.819 35.66908791626757 139.74916086362532 18.819 35.66908724026122 139.74916089747325 18.819 35.66908656420855 139.7491608650447 18.819 35.66908588810183 139.74916075529362 18.819 35.66908522997624 139.7491605792472 18.819 35.66908458081031 139.74916032586881 18.819 35.66908395863925 139.74916000618558 18.819 35.66908335445702 139.74915963125306 18.819 35.66908278627565 139.74915917896018 18.819 35.66908224509685 139.74915867140857 18.819 35.66908174894808 139.74915810857928 18.819 35.669081288823314 139.74915750152786 18.819 35.66908087372858 139.74915683919875 18.819 35.66908051269303 139.74915614367467 18.819 35.669080196695234 139.74915540391896 18.819 35.669079943778065 139.7491546420049 18.819 35.669079735906365 139.74915384690527 18.819 35.66907959112302 139.74915304069336 18.819 35.669079500406596 139.74915221233252 18.819 35.66907947278624 139.74915138390543 18.819 35.66907949924825 139.74915055542158 18.819 35.66907958880633 139.74914972687148 18.819 35.66907974147595 139.74914892034727 18.819 35.66907993922964 139.74914813586787 18.819 35.66908020008713 139.7491473623683 18.819 35.66908051505014 139.74914662195016 18.819 35.669080875112684 139.749145925669 18.819 35.66908128928074 139.74914526246926 18.819 35.66908174855605 139.74914465445255 18.819 35.66908224391715 139.7491440905823 18.819 35.669082784393225 139.74914359294112 18.819 35.66908336095509 139.74914313944637 18.819 35.66908395559847 139.74914276325524 18.819 35.66908458633537 139.74914244225658 18.819 35.6690852351538 139.74914219856151 18.819 35.66908589302456 139.74914201008738 18.819 35.66908655997082 139.7491419099723 18.819 35.66908723596944 139.7491418650782 18.819 35.66908791202984 139.74914190855264 18.819 35.669088588136574 139.74914201830356 18.819 35.6690892462622 139.74914219434984 18.819 35.669089895428165 139.7491424477281 18.819 35.66909051759155 139.74914275636513 18.819 35.66909112178155 139.74914314234363 18.819 35.66909168996298 139.74914359463642 18.819 35.669092231141846 139.749144102188 18.819 35.66909272728296 139.7491446539712 18.819 35.669093187415505 139.74914527206874 18.819 35.66909360250258 139.7491459233518 18.819 35.669093963545905 139.74914662992202 18.819 35.66909427954376 139.74914736967781 18.819 35.66909453246098 139.74914813159202 18.819 35.66909474033271 139.74914892669176 18.819 35.66909488511608 139.74914973290382 18.819 35.669094975832536 139.7491505612648 18.819 35.66909500345289 139.74915138969206 18.819 35.66909497699088 139.74915221817608 18.819 35.66909488742505 139.74915303568028 18.819 35.66909473476313 139.7491538532507 18.819 35.66909453700941 139.74915463773021 18.819 35.66909427615187 139.7491554112299 18.819 35.669093961181076 139.74915614060205 18.819 35.66909360112621 139.74915684792936 18.819 35.669093186950356 139.74915750008307 18.819 35.66909272768271 139.74915811914585 18.819 35.66909223231382 139.74915867197004 18.819 35.66909169184541 139.74915918065722 18.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ce90a8c-676c-456f-bbb0-19aeade24ba4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ce90a8c-676c-456f-bbb0-19aeade24ba4_0">
											<gml:posList>35.66908791202984 139.74914190855264 20.373 35.66908791202984 139.74914190855264 18.819 35.66908723596944 139.7491418650782 18.819 35.66908723596944 139.7491418650782 20.373 35.66908791202984 139.74914190855264 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-537864bb-dd5b-4f69-a78a-c770a79fd155">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-537864bb-dd5b-4f69-a78a-c770a79fd155_0">
											<gml:posList>35.66908723596944 139.7491418650782 20.373 35.66908723596944 139.7491418650782 18.819 35.66908655997082 139.7491419099723 18.819 35.66908655997082 139.7491419099723 20.373 35.66908723596944 139.7491418650782 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2619e4f-f4ad-45cd-ad57-5275410d5b54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2619e4f-f4ad-45cd-ad57-5275410d5b54_0">
											<gml:posList>35.66908655997082 139.7491419099723 20.373 35.66908655997082 139.7491419099723 18.819 35.66908589302456 139.74914201008738 18.819 35.66908589302456 139.74914201008738 20.373 35.66908655997082 139.7491419099723 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98927625-a481-4ffd-aaca-24af91c05c7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98927625-a481-4ffd-aaca-24af91c05c7b_0">
											<gml:posList>35.669088588136574 139.74914201830356 20.373 35.669088588136574 139.74914201830356 18.819 35.66908791202984 139.74914190855264 18.819 35.66908791202984 139.74914190855264 20.373 35.669088588136574 139.74914201830356 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5fcf460-8b5b-4f1c-b082-70e94a7b1927">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5fcf460-8b5b-4f1c-b082-70e94a7b1927_0">
											<gml:posList>35.66908589302456 139.74914201008738 20.373 35.66908589302456 139.74914201008738 18.819 35.6690852351538 139.74914219856151 18.819 35.6690852351538 139.74914219856151 20.373 35.66908589302456 139.74914201008738 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbc8eeeb-a9d5-4e05-9943-a32625e26f4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbc8eeeb-a9d5-4e05-9943-a32625e26f4d_0">
											<gml:posList>35.6690892462622 139.74914219434984 20.373 35.6690892462622 139.74914219434984 18.819 35.669088588136574 139.74914201830356 18.819 35.669088588136574 139.74914201830356 20.373 35.6690892462622 139.74914219434984 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cbf88c4-6423-4077-a639-f89d3f540052">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cbf88c4-6423-4077-a639-f89d3f540052_0">
											<gml:posList>35.6690852351538 139.74914219856151 20.373 35.6690852351538 139.74914219856151 18.819 35.66908458633537 139.74914244225658 18.819 35.66908458633537 139.74914244225658 20.373 35.6690852351538 139.74914219856151 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa6a8388-91f4-4416-b827-fb2f78f8f3f5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa6a8388-91f4-4416-b827-fb2f78f8f3f5_0">
											<gml:posList>35.669089895428165 139.7491424477281 20.373 35.669089895428165 139.7491424477281 18.819 35.6690892462622 139.74914219434984 18.819 35.6690892462622 139.74914219434984 20.373 35.669089895428165 139.7491424477281 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c440c7f-3a9f-476d-bb8c-4ba0e66c3647">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c440c7f-3a9f-476d-bb8c-4ba0e66c3647_0">
											<gml:posList>35.66908458633537 139.74914244225658 20.373 35.66908458633537 139.74914244225658 18.819 35.66908395559847 139.74914276325524 18.819 35.66908395559847 139.74914276325524 20.373 35.66908458633537 139.74914244225658 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4389854-d122-47f2-ae05-856008f85a6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4389854-d122-47f2-ae05-856008f85a6c_0">
											<gml:posList>35.66909051759155 139.74914275636513 20.373 35.66909051759155 139.74914275636513 18.819 35.669089895428165 139.7491424477281 18.819 35.669089895428165 139.7491424477281 20.373 35.66909051759155 139.74914275636513 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3665c9b7-4804-4ced-82f8-21cab4d4434e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3665c9b7-4804-4ced-82f8-21cab4d4434e_0">
											<gml:posList>35.66908395559847 139.74914276325524 20.373 35.66908395559847 139.74914276325524 18.819 35.66908336095509 139.74914313944637 18.819 35.66908336095509 139.74914313944637 20.373 35.66908395559847 139.74914276325524 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab693ac7-1c2f-4492-80fe-e05dc22604fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab693ac7-1c2f-4492-80fe-e05dc22604fc_0">
											<gml:posList>35.66909112178155 139.74914314234363 20.373 35.66909112178155 139.74914314234363 18.819 35.66909051759155 139.74914275636513 18.819 35.66909051759155 139.74914275636513 20.373 35.66909112178155 139.74914314234363 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00eec220-73c6-4bb7-b226-f1a9efeb7279">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00eec220-73c6-4bb7-b226-f1a9efeb7279_0">
											<gml:posList>35.66908336095509 139.74914313944637 20.373 35.66908336095509 139.74914313944637 18.819 35.669082784393225 139.74914359294112 18.819 35.669082784393225 139.74914359294112 20.373 35.66908336095509 139.74914313944637 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8407ba95-d44e-421b-a188-8a9993e0a402">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8407ba95-d44e-421b-a188-8a9993e0a402_0">
											<gml:posList>35.66909168996298 139.74914359463642 20.373 35.66909168996298 139.74914359463642 18.819 35.66909112178155 139.74914314234363 18.819 35.66909112178155 139.74914314234363 20.373 35.66909168996298 139.74914359463642 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16986e38-c967-4bc4-85c8-5cbd7f7afd46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16986e38-c967-4bc4-85c8-5cbd7f7afd46_0">
											<gml:posList>35.669082784393225 139.74914359294112 20.373 35.669082784393225 139.74914359294112 18.819 35.66908224391715 139.7491440905823 18.819 35.66908224391715 139.7491440905823 20.373 35.669082784393225 139.74914359294112 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0bf4a50-cde0-43af-a5f1-a039e11d0882">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0bf4a50-cde0-43af-a5f1-a039e11d0882_0">
											<gml:posList>35.669092231141846 139.749144102188 20.373 35.669092231141846 139.749144102188 18.819 35.66909168996298 139.74914359463642 18.819 35.66909168996298 139.74914359463642 20.373 35.669092231141846 139.749144102188 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4148181-10df-4788-868a-2f0eecc87803">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4148181-10df-4788-868a-2f0eecc87803_0">
											<gml:posList>35.66908224391715 139.7491440905823 20.373 35.66908224391715 139.7491440905823 18.819 35.66908174855605 139.74914465445255 18.819 35.66908174855605 139.74914465445255 20.373 35.66908224391715 139.7491440905823 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2b1818b-aefe-49ef-bc0c-a8e0d54e8c54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2b1818b-aefe-49ef-bc0c-a8e0d54e8c54_0">
											<gml:posList>35.66909272728296 139.7491446539712 20.373 35.66909272728296 139.7491446539712 18.819 35.669092231141846 139.749144102188 18.819 35.669092231141846 139.749144102188 20.373 35.66909272728296 139.7491446539712 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9994248-e5a9-4a90-8e06-86ad47800cdc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9994248-e5a9-4a90-8e06-86ad47800cdc_0">
											<gml:posList>35.66908174855605 139.74914465445255 20.373 35.66908174855605 139.74914465445255 18.819 35.66908128928074 139.74914526246926 18.819 35.66908128928074 139.74914526246926 20.373 35.66908174855605 139.74914465445255 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8eda980-d0de-4744-8ca1-846ae2fc60eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8eda980-d0de-4744-8ca1-846ae2fc60eb_0">
											<gml:posList>35.669093187415505 139.74914527206874 20.373 35.669093187415505 139.74914527206874 18.819 35.66909272728296 139.7491446539712 18.819 35.66909272728296 139.7491446539712 20.373 35.669093187415505 139.74914527206874 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe30bd56-e711-49b1-ab88-4eac9bfaf26c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe30bd56-e711-49b1-ab88-4eac9bfaf26c_0">
											<gml:posList>35.66908128928074 139.74914526246926 20.373 35.66908128928074 139.74914526246926 18.819 35.669080875112684 139.749145925669 18.819 35.669080875112684 139.749145925669 20.373 35.66908128928074 139.74914526246926 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f45f1ce-68f6-46df-9a18-f73bc44c37f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f45f1ce-68f6-46df-9a18-f73bc44c37f9_0">
											<gml:posList>35.66909360250258 139.7491459233518 20.373 35.66909360250258 139.7491459233518 18.819 35.669093187415505 139.74914527206874 18.819 35.669093187415505 139.74914527206874 20.373 35.66909360250258 139.7491459233518 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32d6547b-ab7c-4816-9c97-f79d9382bc65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32d6547b-ab7c-4816-9c97-f79d9382bc65_0">
											<gml:posList>35.669080875112684 139.749145925669 20.373 35.669080875112684 139.749145925669 18.819 35.66908051505014 139.74914662195016 18.819 35.66908051505014 139.74914662195016 20.373 35.669080875112684 139.749145925669 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acc69321-6820-4966-bd57-765bb54eb374">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-acc69321-6820-4966-bd57-765bb54eb374_0">
											<gml:posList>35.669093963545905 139.74914662992202 20.373 35.669093963545905 139.74914662992202 18.819 35.66909360250258 139.7491459233518 18.819 35.66909360250258 139.7491459233518 20.373 35.669093963545905 139.74914662992202 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a14ae62-7ced-4110-ac56-1c0d4288a763">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a14ae62-7ced-4110-ac56-1c0d4288a763_0">
											<gml:posList>35.66908051505014 139.74914662195016 20.373 35.66908051505014 139.74914662195016 18.819 35.66908020008713 139.7491473623683 18.819 35.66908020008713 139.7491473623683 20.373 35.66908051505014 139.74914662195016 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60ee6ebd-71f7-40d5-a856-7efc8b5624dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60ee6ebd-71f7-40d5-a856-7efc8b5624dc_0">
											<gml:posList>35.66909427954376 139.74914736967781 20.373 35.66909427954376 139.74914736967781 18.819 35.669093963545905 139.74914662992202 18.819 35.669093963545905 139.74914662992202 20.373 35.66909427954376 139.74914736967781 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9fce144-84e0-4cb3-bb48-066d67dcde1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9fce144-84e0-4cb3-bb48-066d67dcde1e_0">
											<gml:posList>35.66908020008713 139.7491473623683 20.373 35.66908020008713 139.7491473623683 18.819 35.66907993922964 139.74914813586787 18.819 35.66907993922964 139.74914813586787 20.373 35.66908020008713 139.7491473623683 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-200eebdf-3d04-4c5c-b683-e912265fa0c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-200eebdf-3d04-4c5c-b683-e912265fa0c6_0">
											<gml:posList>35.66909453246098 139.74914813159202 20.373 35.66909453246098 139.74914813159202 18.819 35.66909427954376 139.74914736967781 18.819 35.66909427954376 139.74914736967781 20.373 35.66909453246098 139.74914813159202 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c095d04f-b7be-452f-8fb2-4120355764e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c095d04f-b7be-452f-8fb2-4120355764e7_0">
											<gml:posList>35.66907993922964 139.74914813586787 20.373 35.66907993922964 139.74914813586787 18.819 35.66907974147595 139.74914892034727 18.819 35.66907974147595 139.74914892034727 20.373 35.66907993922964 139.74914813586787 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfb1b1e4-81f7-454d-a088-15330660ea37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfb1b1e4-81f7-454d-a088-15330660ea37_0">
											<gml:posList>35.66909474033271 139.74914892669176 20.373 35.66909474033271 139.74914892669176 18.819 35.66909453246098 139.74914813159202 18.819 35.66909453246098 139.74914813159202 20.373 35.66909474033271 139.74914892669176 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b93c92d1-acfc-4317-b690-5d884560fcf2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b93c92d1-acfc-4317-b690-5d884560fcf2_0">
											<gml:posList>35.66907974147595 139.74914892034727 20.373 35.66907974147595 139.74914892034727 18.819 35.66907958880633 139.74914972687148 18.819 35.66907958880633 139.74914972687148 20.373 35.66907974147595 139.74914892034727 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-235e20cb-d792-4c07-a830-ca3340cefc2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-235e20cb-d792-4c07-a830-ca3340cefc2b_0">
											<gml:posList>35.66909488511608 139.74914973290382 20.373 35.66909488511608 139.74914973290382 18.819 35.66909474033271 139.74914892669176 18.819 35.66909474033271 139.74914892669176 20.373 35.66909488511608 139.74914973290382 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7ed68c9-3f38-4a28-8916-3c874e9af3a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7ed68c9-3f38-4a28-8916-3c874e9af3a6_0">
											<gml:posList>35.66907958880633 139.74914972687148 20.373 35.66907958880633 139.74914972687148 18.819 35.66907949924825 139.74915055542158 18.819 35.66907949924825 139.74915055542158 20.373 35.66907958880633 139.74914972687148 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3079d201-adfd-4e8b-80e6-5cfcf1f3ea67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3079d201-adfd-4e8b-80e6-5cfcf1f3ea67_0">
											<gml:posList>35.669094975832536 139.7491505612648 20.373 35.669094975832536 139.7491505612648 18.819 35.66909488511608 139.74914973290382 18.819 35.66909488511608 139.74914973290382 20.373 35.669094975832536 139.7491505612648 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd613e13-6906-452d-a77c-27d4095aec7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd613e13-6906-452d-a77c-27d4095aec7b_0">
											<gml:posList>35.66907949924825 139.74915055542158 20.373 35.66907949924825 139.74915055542158 18.819 35.66907947278624 139.74915138390543 18.819 35.66907947278624 139.74915138390543 20.373 35.66907949924825 139.74915055542158 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-006990f1-7c77-48f1-ba2d-ca206e8a39af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-006990f1-7c77-48f1-ba2d-ca206e8a39af_0">
											<gml:posList>35.66909500345289 139.74915138969206 20.373 35.66909500345289 139.74915138969206 18.819 35.669094975832536 139.7491505612648 18.819 35.669094975832536 139.7491505612648 20.373 35.66909500345289 139.74915138969206 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1405c13-c7e8-4676-aade-820e480c95cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1405c13-c7e8-4676-aade-820e480c95cd_0">
											<gml:posList>35.669080875112684 139.749145925669 20.373 35.66908051505014 139.74914662195016 20.373 35.66908020008713 139.7491473623683 20.373 35.66907993922964 139.74914813586787 20.373 35.66907974147595 139.74914892034727 20.373 35.66907958880633 139.74914972687148 20.373 35.66907949924825 139.74915055542158 20.373 35.66907947278624 139.74915138390543 20.373 35.669079500406596 139.74915221233252 20.373 35.66907959112302 139.74915304069336 20.373 35.669079735906365 139.74915384690527 20.373 35.669079943778065 139.7491546420049 20.373 35.669080196695234 139.74915540391896 20.373 35.66908051269303 139.74915614367467 20.373 35.66908087372858 139.74915683919875 20.373 35.669081288823314 139.74915750152786 20.373 35.66908174894808 139.74915810857928 20.373 35.66908224509685 139.74915867140857 20.373 35.66908278627565 139.74915917896018 20.373 35.66908335445702 139.74915963125306 20.373 35.66908395863925 139.74916000618558 20.373 35.66908458081031 139.74916032586881 20.373 35.66908522997624 139.7491605792472 20.373 35.66908588810183 139.74916075529362 20.373 35.66908656420855 139.7491608650447 20.373 35.66908724026122 139.74916089747325 20.373 35.66908791626757 139.74916086362532 20.373 35.66908858320613 139.74916075246438 20.373 35.66908925009837 139.74916057502696 20.373 35.6690898899031 139.7491603313415 20.373 35.66909052064004 139.74916001034296 20.373 35.66909112428949 139.74915962309635 20.373 35.66909169184541 139.74915918065722 20.373 35.66909223231382 139.74915867197004 20.373 35.66909272768271 139.74915811914585 20.373 35.669093186950356 139.74915750008307 20.373 35.66909360112621 139.74915684792936 20.373 35.669093961181076 139.74915614060205 20.373 35.66909427615187 139.7491554112299 20.373 35.66909453700941 139.74915463773021 20.373 35.66909473476313 139.7491538532507 20.373 35.66909488742505 139.74915303568028 20.373 35.66909497699088 139.74915221817608 20.373 35.66909500345289 139.74915138969206 20.373 35.669094975832536 139.7491505612648 20.373 35.66909488511608 139.74914973290382 20.373 35.66909474033271 139.74914892669176 20.373 35.66909453246098 139.74914813159202 20.373 35.66909427954376 139.74914736967781 20.373 35.669093963545905 139.74914662992202 20.373 35.66909360250258 139.7491459233518 20.373 35.669093187415505 139.74914527206874 20.373 35.66909272728296 139.7491446539712 20.373 35.669092231141846 139.749144102188 20.373 35.66909168996298 139.74914359463642 20.373 35.66909112178155 139.74914314234363 20.373 35.66909051759155 139.74914275636513 20.373 35.669089895428165 139.7491424477281 20.373 35.6690892462622 139.74914219434984 20.373 35.669088588136574 139.74914201830356 20.373 35.66908791202984 139.74914190855264 20.373 35.66908723596944 139.7491418650782 20.373 35.66908655997082 139.7491419099723 20.373 35.66908589302456 139.74914201008738 20.373 35.6690852351538 139.74914219856151 20.373 35.66908458633537 139.74914244225658 20.373 35.66908395559847 139.74914276325524 20.373 35.66908336095509 139.74914313944637 20.373 35.669082784393225 139.74914359294112 20.373 35.66908224391715 139.7491440905823 20.373 35.66908174855605 139.74914465445255 20.373 35.66908128928074 139.74914526246926 20.373 35.669080875112684 139.749145925669 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc55ee39-0cf1-4c38-ad22-3005a9042e86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc55ee39-0cf1-4c38-ad22-3005a9042e86_0">
											<gml:posList>35.66907947278624 139.74915138390543 20.373 35.66907947278624 139.74915138390543 18.819 35.669079500406596 139.74915221233252 18.819 35.669079500406596 139.74915221233252 20.373 35.66907947278624 139.74915138390543 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48d53948-2636-46e0-84e1-c34cbf7576d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48d53948-2636-46e0-84e1-c34cbf7576d1_0">
											<gml:posList>35.66909497699088 139.74915221817608 20.373 35.66909497699088 139.74915221817608 18.819 35.66909500345289 139.74915138969206 18.819 35.66909500345289 139.74915138969206 20.373 35.66909497699088 139.74915221817608 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03cb15a3-e727-434c-bfc2-244f736d0565">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03cb15a3-e727-434c-bfc2-244f736d0565_0">
											<gml:posList>35.669079500406596 139.74915221233252 20.373 35.669079500406596 139.74915221233252 18.819 35.66907959112302 139.74915304069336 18.819 35.66907959112302 139.74915304069336 20.373 35.669079500406596 139.74915221233252 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a51d793-587f-4fe4-9061-0804d91cc0d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a51d793-587f-4fe4-9061-0804d91cc0d1_0">
											<gml:posList>35.66909488742505 139.74915303568028 20.373 35.66909488742505 139.74915303568028 18.819 35.66909497699088 139.74915221817608 18.819 35.66909497699088 139.74915221817608 20.373 35.66909488742505 139.74915303568028 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfb95b8b-fa2a-456e-943d-4b1656ea9889">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfb95b8b-fa2a-456e-943d-4b1656ea9889_0">
											<gml:posList>35.66907959112302 139.74915304069336 20.373 35.66907959112302 139.74915304069336 18.819 35.669079735906365 139.74915384690527 18.819 35.669079735906365 139.74915384690527 20.373 35.66907959112302 139.74915304069336 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-113bfad0-3e2e-4074-9bb5-4ab167cc7563">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-113bfad0-3e2e-4074-9bb5-4ab167cc7563_0">
											<gml:posList>35.66909473476313 139.7491538532507 20.373 35.66909473476313 139.7491538532507 18.819 35.66909488742505 139.74915303568028 18.819 35.66909488742505 139.74915303568028 20.373 35.66909473476313 139.7491538532507 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e44662ee-3341-4ff4-b0d4-485836f088b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e44662ee-3341-4ff4-b0d4-485836f088b7_0">
											<gml:posList>35.669079735906365 139.74915384690527 20.373 35.669079735906365 139.74915384690527 18.819 35.669079943778065 139.7491546420049 18.819 35.669079943778065 139.7491546420049 20.373 35.669079735906365 139.74915384690527 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a31bd4d8-77fc-4223-8fda-ab480acc1278">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a31bd4d8-77fc-4223-8fda-ab480acc1278_0">
											<gml:posList>35.66909453700941 139.74915463773021 20.373 35.66909453700941 139.74915463773021 18.819 35.66909473476313 139.7491538532507 18.819 35.66909473476313 139.7491538532507 20.373 35.66909453700941 139.74915463773021 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2260323-9b9d-4290-9261-1a8283979694">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2260323-9b9d-4290-9261-1a8283979694_0">
											<gml:posList>35.669079943778065 139.7491546420049 20.373 35.669079943778065 139.7491546420049 18.819 35.669080196695234 139.74915540391896 18.819 35.669080196695234 139.74915540391896 20.373 35.669079943778065 139.7491546420049 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ef4e953-0882-4952-8205-d24e0b5544e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ef4e953-0882-4952-8205-d24e0b5544e3_0">
											<gml:posList>35.66909427615187 139.7491554112299 20.373 35.66909427615187 139.7491554112299 18.819 35.66909453700941 139.74915463773021 18.819 35.66909453700941 139.74915463773021 20.373 35.66909427615187 139.7491554112299 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d2102a2-553d-4e62-8479-5eeb64939e53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d2102a2-553d-4e62-8479-5eeb64939e53_0">
											<gml:posList>35.669080196695234 139.74915540391896 20.373 35.669080196695234 139.74915540391896 18.819 35.66908051269303 139.74915614367467 18.819 35.66908051269303 139.74915614367467 20.373 35.669080196695234 139.74915540391896 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8e473a1-34c0-4cc2-9ca4-774af3ad7ca8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b8e473a1-34c0-4cc2-9ca4-774af3ad7ca8_0">
											<gml:posList>35.669093961181076 139.74915614060205 20.373 35.669093961181076 139.74915614060205 18.819 35.66909427615187 139.7491554112299 18.819 35.66909427615187 139.7491554112299 20.373 35.669093961181076 139.74915614060205 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b15007f0-e3c9-407c-bc36-a8d0737d48b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b15007f0-e3c9-407c-bc36-a8d0737d48b0_0">
											<gml:posList>35.66908051269303 139.74915614367467 20.373 35.66908051269303 139.74915614367467 18.819 35.66908087372858 139.74915683919875 18.819 35.66908087372858 139.74915683919875 20.373 35.66908051269303 139.74915614367467 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7b67b41-c97d-42d7-b394-e834dabc4543">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7b67b41-c97d-42d7-b394-e834dabc4543_0">
											<gml:posList>35.66909360112621 139.74915684792936 20.373 35.66909360112621 139.74915684792936 18.819 35.669093961181076 139.74915614060205 18.819 35.669093961181076 139.74915614060205 20.373 35.66909360112621 139.74915684792936 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cae11603-0a16-4319-9f7d-77257d7608da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cae11603-0a16-4319-9f7d-77257d7608da_0">
											<gml:posList>35.66908087372858 139.74915683919875 20.373 35.66908087372858 139.74915683919875 18.819 35.669081288823314 139.74915750152786 18.819 35.669081288823314 139.74915750152786 20.373 35.66908087372858 139.74915683919875 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62f4f68a-2783-41bc-88ec-1a2c6040d6b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62f4f68a-2783-41bc-88ec-1a2c6040d6b3_0">
											<gml:posList>35.669093186950356 139.74915750008307 20.373 35.669093186950356 139.74915750008307 18.819 35.66909360112621 139.74915684792936 18.819 35.66909360112621 139.74915684792936 20.373 35.669093186950356 139.74915750008307 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db4151bd-9a8e-4216-a3b2-4b5ff5c48201">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db4151bd-9a8e-4216-a3b2-4b5ff5c48201_0">
											<gml:posList>35.669081288823314 139.74915750152786 20.373 35.669081288823314 139.74915750152786 18.819 35.66908174894808 139.74915810857928 18.819 35.66908174894808 139.74915810857928 20.373 35.669081288823314 139.74915750152786 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c76f1eb-3c45-49de-b476-c0f661ef936b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c76f1eb-3c45-49de-b476-c0f661ef936b_0">
											<gml:posList>35.66909272768271 139.74915811914585 20.373 35.66909272768271 139.74915811914585 18.819 35.669093186950356 139.74915750008307 18.819 35.669093186950356 139.74915750008307 20.373 35.66909272768271 139.74915811914585 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bccf9bb-de33-41c9-b887-01e01c224ae3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bccf9bb-de33-41c9-b887-01e01c224ae3_0">
											<gml:posList>35.66908174894808 139.74915810857928 20.373 35.66908174894808 139.74915810857928 18.819 35.66908224509685 139.74915867140857 18.819 35.66908224509685 139.74915867140857 20.373 35.66908174894808 139.74915810857928 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc97c6a0-2380-4da9-8e11-ff88dd0138f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc97c6a0-2380-4da9-8e11-ff88dd0138f8_0">
											<gml:posList>35.66909223231382 139.74915867197004 20.373 35.66909223231382 139.74915867197004 18.819 35.66909272768271 139.74915811914585 18.819 35.66909272768271 139.74915811914585 20.373 35.66909223231382 139.74915867197004 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2852d56-00e2-4c2e-a6b3-d570c0bc4765">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2852d56-00e2-4c2e-a6b3-d570c0bc4765_0">
											<gml:posList>35.66908224509685 139.74915867140857 20.373 35.66908224509685 139.74915867140857 18.819 35.66908278627565 139.74915917896018 18.819 35.66908278627565 139.74915917896018 20.373 35.66908224509685 139.74915867140857 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a32ee6ac-f843-4549-9e5f-ec99b7d5da3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a32ee6ac-f843-4549-9e5f-ec99b7d5da3a_0">
											<gml:posList>35.66909169184541 139.74915918065722 20.373 35.66909169184541 139.74915918065722 18.819 35.66909223231382 139.74915867197004 18.819 35.66909223231382 139.74915867197004 20.373 35.66909169184541 139.74915918065722 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7639be9-3394-480d-8ac3-b0c845555a00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b7639be9-3394-480d-8ac3-b0c845555a00_0">
											<gml:posList>35.66908278627565 139.74915917896018 20.373 35.66908278627565 139.74915917896018 18.819 35.66908335445702 139.74915963125306 18.819 35.66908335445702 139.74915963125306 20.373 35.66908278627565 139.74915917896018 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f2a12eb-4254-4373-b746-16243970653a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f2a12eb-4254-4373-b746-16243970653a_0">
											<gml:posList>35.66909112428949 139.74915962309635 20.373 35.66909112428949 139.74915962309635 18.819 35.66909169184541 139.74915918065722 18.819 35.66909169184541 139.74915918065722 20.373 35.66909112428949 139.74915962309635 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59485196-9334-41a3-b113-e9b09899116e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59485196-9334-41a3-b113-e9b09899116e_0">
											<gml:posList>35.66908335445702 139.74915963125306 20.373 35.66908335445702 139.74915963125306 18.819 35.66908395863925 139.74916000618558 18.819 35.66908395863925 139.74916000618558 20.373 35.66908335445702 139.74915963125306 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cde0537-7f28-46ab-ae66-837993b0f584">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cde0537-7f28-46ab-ae66-837993b0f584_0">
											<gml:posList>35.66909052064004 139.74916001034296 20.373 35.66909052064004 139.74916001034296 18.819 35.66909112428949 139.74915962309635 18.819 35.66909112428949 139.74915962309635 20.373 35.66909052064004 139.74916001034296 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ad7ed2b-364f-48a6-85c4-e249b9ff082e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ad7ed2b-364f-48a6-85c4-e249b9ff082e_0">
											<gml:posList>35.66908395863925 139.74916000618558 20.373 35.66908395863925 139.74916000618558 18.819 35.66908458081031 139.74916032586881 18.819 35.66908458081031 139.74916032586881 20.373 35.66908395863925 139.74916000618558 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40eab536-a59d-4070-a105-7f88f195f35d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40eab536-a59d-4070-a105-7f88f195f35d_0">
											<gml:posList>35.6690898899031 139.7491603313415 20.373 35.6690898899031 139.7491603313415 18.819 35.66909052064004 139.74916001034296 18.819 35.66909052064004 139.74916001034296 20.373 35.6690898899031 139.7491603313415 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96da3696-6979-4f20-8f0a-a9c18afc6b2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96da3696-6979-4f20-8f0a-a9c18afc6b2f_0">
											<gml:posList>35.66908458081031 139.74916032586881 20.373 35.66908458081031 139.74916032586881 18.819 35.66908522997624 139.7491605792472 18.819 35.66908522997624 139.7491605792472 20.373 35.66908458081031 139.74916032586881 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82d629aa-b180-463b-b26f-27ff58410b90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82d629aa-b180-463b-b26f-27ff58410b90_0">
											<gml:posList>35.66908925009837 139.74916057502696 20.373 35.66908925009837 139.74916057502696 18.819 35.6690898899031 139.7491603313415 18.819 35.6690898899031 139.7491603313415 20.373 35.66908925009837 139.74916057502696 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c43b042-4234-48e4-984a-65f78a92e5c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c43b042-4234-48e4-984a-65f78a92e5c0_0">
											<gml:posList>35.66908858320613 139.74916075246438 20.373 35.66908858320613 139.74916075246438 18.819 35.66908925009837 139.74916057502696 18.819 35.66908925009837 139.74916057502696 20.373 35.66908858320613 139.74916075246438 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af78e954-19d2-4d16-8a5f-f93d07b2b26b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af78e954-19d2-4d16-8a5f-f93d07b2b26b_0">
											<gml:posList>35.66908522997624 139.7491605792472 20.373 35.66908522997624 139.7491605792472 18.819 35.66908588810183 139.74916075529362 18.819 35.66908588810183 139.74916075529362 20.373 35.66908522997624 139.7491605792472 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6e5a886-f089-49f7-b1a6-ef6c235cc5af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6e5a886-f089-49f7-b1a6-ef6c235cc5af_0">
											<gml:posList>35.66908588810183 139.74916075529362 20.373 35.66908588810183 139.74916075529362 18.819 35.66908656420855 139.7491608650447 18.819 35.66908656420855 139.7491608650447 20.373 35.66908588810183 139.74916075529362 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f5a7415-9ec7-4591-bdd2-b889f2ac6c88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f5a7415-9ec7-4591-bdd2-b889f2ac6c88_0">
											<gml:posList>35.66908791626757 139.74916086362532 20.373 35.66908791626757 139.74916086362532 18.819 35.66908858320613 139.74916075246438 18.819 35.66908858320613 139.74916075246438 20.373 35.66908791626757 139.74916086362532 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8900f35e-c90c-4d3d-8982-d0ebde9b2480">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8900f35e-c90c-4d3d-8982-d0ebde9b2480_0">
											<gml:posList>35.66908656420855 139.7491608650447 20.373 35.66908656420855 139.7491608650447 18.819 35.66908724026122 139.74916089747325 18.819 35.66908724026122 139.74916089747325 20.373 35.66908656420855 139.7491608650447 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbae24fb-6a5d-4561-8866-cdced48fa51c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbae24fb-6a5d-4561-8866-cdced48fa51c_0">
											<gml:posList>35.66908724026122 139.74916089747325 20.373 35.66908724026122 139.74916089747325 18.819 35.66908791626757 139.74916086362532 18.819 35.66908791626757 139.74916086362532 20.373 35.66908724026122 139.74916089747325 20.373</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-22427594-6ea3-48e7-a616-bc0281c8765f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22427594-6ea3-48e7-a616-bc0281c8765f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22427594-6ea3-48e7-a616-bc0281c8765f">
											<gml:posList>35.66914875243334 139.74921600812186 6.19 35.66913037029503 139.74922442243331 6.19 35.66906157055607 139.74918870530837 6.19 35.66908738867628 139.74911533222848 6.19 35.66916845166087 139.74915755362179 6.19 35.66914875243334 139.74921600812186 6.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1e9e5fe-2144-4a72-b483-00595c618b55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1e9e5fe-2144-4a72-b483-00595c618b55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1e9e5fe-2144-4a72-b483-00595c618b55">
											<gml:posList>35.669066716194855 139.74917408594544 16.7 35.66907053664852 139.7491721267793 16.7 35.66908889719786 139.74911994790645 16.7 35.66908738867628 139.74911533222848 16.7 35.669066716194855 139.74917408594544 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e7f3327-fe63-4a86-bd32-abe050f2f887">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e7f3327-fe63-4a86-bd32-abe050f2f887">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e7f3327-fe63-4a86-bd32-abe050f2f887">
											<gml:posList>35.669066716194855 139.74917408594544 16.7 35.66906157055607 139.74918870530837 15.1 35.66913037029503 139.74922442243331 15.1 35.669066716194855 139.74917408594544 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-57e6724a-7cf7-42a3-b269-bd5af868d2ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57e6724a-7cf7-42a3-b269-bd5af868d2ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57e6724a-7cf7-42a3-b269-bd5af868d2ba">
											<gml:posList>35.66913747071292 139.74920807781936 16.7 35.669135917180114 139.7492035395068 16.7 35.66907053664852 139.7491721267793 16.7 35.669066716194855 139.74917408594544 16.7 35.66913747071292 139.74920807781936 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c60da35-0df1-4708-a166-9454b9987d1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c60da35-0df1-4708-a166-9454b9987d1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c60da35-0df1-4708-a166-9454b9987d1d">
											<gml:posList>35.66913037029503 139.74922442243331 15.1 35.66913747071292 139.74920807781936 16.7 35.669066716194855 139.74917408594544 16.7 35.66913037029503 139.74922442243331 15.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8de484c6-8257-43a6-95c3-08a4e24a07c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8de484c6-8257-43a6-95c3-08a4e24a07c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8de484c6-8257-43a6-95c3-08a4e24a07c4">
											<gml:posList>35.669135917180114 139.7492035395068 16.227 35.6691532786941 139.74915347145082 16.227 35.66908889719786 139.74911994790645 16.227 35.66907053664852 139.7491721267793 16.227 35.669135917180114 139.7492035395068 16.227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7203e7ef-2dca-49d8-b9de-2ce52ce043b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7203e7ef-2dca-49d8-b9de-2ce52ce043b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7203e7ef-2dca-49d8-b9de-2ce52ce043b4">
											<gml:posList>35.66908738867628 139.74911533222848 16.7 35.66908889719786 139.74911994790645 16.7 35.6691532786941 139.74915347145082 16.7 35.66915705414824 139.74915161174368 16.7 35.66908738867628 139.74911533222848 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b429c55-bcad-44cd-807c-d0afc510c7ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b429c55-bcad-44cd-807c-d0afc510c7ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b429c55-bcad-44cd-807c-d0afc510c7ff">
											<gml:posList>35.66913747071292 139.74920807781936 16.7 35.66913037029503 139.74922442243331 15.1 35.66914875243334 139.74921600812186 15.1 35.66913747071292 139.74920807781936 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e129bfb1-d957-4e05-a15f-3fb581b6027c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e129bfb1-d957-4e05-a15f-3fb581b6027c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e129bfb1-d957-4e05-a15f-3fb581b6027c">
											<gml:posList>35.66915705414824 139.74915161174368 16.7 35.6691532786941 139.74915347145082 16.7 35.669135917180114 139.7492035395068 16.7 35.66913747071292 139.74920807781936 16.7 35.66915705414824 139.74915161174368 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-75239aa1-f4cd-42ef-966d-36df4dc9049b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75239aa1-f4cd-42ef-966d-36df4dc9049b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75239aa1-f4cd-42ef-966d-36df4dc9049b">
											<gml:posList>35.66913747071292 139.74920807781936 16.7 35.66914875243334 139.74921600812186 15.1 35.66916845166087 139.74915755362179 15.1 35.66913747071292 139.74920807781936 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c90579e0-cfe8-4f8b-beed-4f75e94c8bc3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c90579e0-cfe8-4f8b-beed-4f75e94c8bc3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c90579e0-cfe8-4f8b-beed-4f75e94c8bc3">
											<gml:posList>35.66916845166087 139.74915755362179 15.1 35.66915705414824 139.74915161174368 16.7 35.66913747071292 139.74920807781936 16.7 35.66916845166087 139.74915755362179 15.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82d3f718-511f-4473-9743-70e953dec19b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82d3f718-511f-4473-9743-70e953dec19b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82d3f718-511f-4473-9743-70e953dec19b">
											<gml:posList>35.66916845166087 139.74915755362179 6.19 35.66908738867628 139.74911533222848 6.19 35.66908738867628 139.74911533222848 16.7 35.66915705414824 139.74915161174368 16.7 35.66916845166087 139.74915755362179 15.1 35.66916845166087 139.74915755362179 6.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68b22705-cd82-43fc-bd2a-3be84687ab23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68b22705-cd82-43fc-bd2a-3be84687ab23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68b22705-cd82-43fc-bd2a-3be84687ab23">
											<gml:posList>35.66908738867628 139.74911533222848 16.7 35.66908738867628 139.74911533222848 6.19 35.66906157055607 139.74918870530837 6.19 35.66906157055607 139.74918870530837 15.1 35.669066716194855 139.74917408594544 16.7 35.66908738867628 139.74911533222848 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7aab5ad-7788-4d39-a1e7-dfa41ab20a8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7aab5ad-7788-4d39-a1e7-dfa41ab20a8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7aab5ad-7788-4d39-a1e7-dfa41ab20a8f">
											<gml:posList>35.66907053664852 139.7491721267793 16.7 35.66907053664852 139.7491721267793 16.227 35.66908889719786 139.74911994790645 16.227 35.66908889719786 139.74911994790645 16.7 35.66907053664852 139.7491721267793 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4cf6e2a-1231-4bc5-9b31-1e483e76fe59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4cf6e2a-1231-4bc5-9b31-1e483e76fe59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4cf6e2a-1231-4bc5-9b31-1e483e76fe59">
											<gml:posList>35.66906157055607 139.74918870530837 6.19 35.66913037029503 139.74922442243331 6.19 35.66913037029503 139.74922442243331 15.1 35.66906157055607 139.74918870530837 15.1 35.66906157055607 139.74918870530837 6.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04caeaf2-6e2b-49d4-ac4b-92f55d3e7acb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04caeaf2-6e2b-49d4-ac4b-92f55d3e7acb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04caeaf2-6e2b-49d4-ac4b-92f55d3e7acb">
											<gml:posList>35.669135917180114 139.7492035395068 16.7 35.669135917180114 139.7492035395068 16.227 35.66907053664852 139.7491721267793 16.227 35.66907053664852 139.7491721267793 16.7 35.669135917180114 139.7492035395068 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a0ce645-c109-45b1-9514-15dce6cb0ca9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a0ce645-c109-45b1-9514-15dce6cb0ca9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a0ce645-c109-45b1-9514-15dce6cb0ca9">
											<gml:posList>35.66908889719786 139.74911994790645 16.7 35.66908889719786 139.74911994790645 16.227 35.6691532786941 139.74915347145082 16.227 35.6691532786941 139.74915347145082 16.7 35.66908889719786 139.74911994790645 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99c55bc7-ed01-4511-ad8f-b948175cc6f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99c55bc7-ed01-4511-ad8f-b948175cc6f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99c55bc7-ed01-4511-ad8f-b948175cc6f0">
											<gml:posList>35.66913037029503 139.74922442243331 6.19 35.66914875243334 139.74921600812186 6.19 35.66914875243334 139.74921600812186 15.1 35.66913037029503 139.74922442243331 15.1 35.66913037029503 139.74922442243331 6.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfa5c766-0016-43f0-b4a7-507d9daf291a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfa5c766-0016-43f0-b4a7-507d9daf291a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfa5c766-0016-43f0-b4a7-507d9daf291a">
											<gml:posList>35.6691532786941 139.74915347145082 16.7 35.6691532786941 139.74915347145082 16.227 35.669135917180114 139.7492035395068 16.227 35.669135917180114 139.7492035395068 16.7 35.6691532786941 139.74915347145082 16.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2928a847-203f-40be-b2c8-42dabc72e20b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2928a847-203f-40be-b2c8-42dabc72e20b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2928a847-203f-40be-b2c8-42dabc72e20b">
											<gml:posList>35.66914875243334 139.74921600812186 6.19 35.66916845166087 139.74915755362179 6.19 35.66916845166087 139.74915755362179 15.1 35.66914875243334 139.74921600812186 15.1 35.66914875243334 139.74921600812186 6.19</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10776</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">69.8398</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1131</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>