<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3c5eb58b-0c1a-4ea4-abc3-c9e59c9302e6">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67117649783229 139.74425052586358 0 35.671188725712156 139.74429420067534 0 35.671206747569705 139.7442866249414 0 35.67119451968707 139.744242950121 0 35.67117649783229 139.74425052586358 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117649783229 139.74425052586358 6.763 35.67119451968707 139.744242950121 6.763 35.671206747569705 139.7442866249414 6.763 35.671188725712156 139.74429420067534 6.763 35.67117649783229 139.74425052586358 6.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117649783229 139.74425052586358 6.763 35.671188725712156 139.74429420067534 6.763 35.671188725712156 139.74429420067534 9.763 35.67117649783229 139.74425052586358 9.763 35.67117649783229 139.74425052586358 6.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671188725712156 139.74429420067534 6.763 35.671206747569705 139.7442866249414 6.763 35.671206747569705 139.7442866249414 9.763 35.671188725712156 139.74429420067534 9.763 35.671188725712156 139.74429420067534 6.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671206747569705 139.7442866249414 6.763 35.67119451968707 139.744242950121 6.763 35.67119451968707 139.744242950121 9.763 35.671206747569705 139.7442866249414 9.763 35.671206747569705 139.7442866249414 6.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67119451968707 139.744242950121 6.763 35.67117649783229 139.74425052586358 6.763 35.67117649783229 139.74425052586358 9.763 35.67119451968707 139.744242950121 9.763 35.67119451968707 139.744242950121 6.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117649783229 139.74425052586358 9.763 35.671188725712156 139.74429420067534 9.763 35.671206747569705 139.7442866249414 9.763 35.67119451968707 139.744242950121 9.763 35.67117649783229 139.74425052586358 9.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-77aa4572-0063-4ba9-a763-46b986831dc6"/>
							<gml:surfaceMember xlink:href="#poly-7bb1ba46-ba28-47f1-bf47-6f856b695e08"/>
							<gml:surfaceMember xlink:href="#poly-4ad5b1da-9d3f-468c-a36c-bbe6779a1a51"/>
							<gml:surfaceMember xlink:href="#poly-87e3388f-9d17-4b93-a63c-7045cfdcc749"/>
							<gml:surfaceMember xlink:href="#poly-a913dc67-f43c-4bf7-ac5b-6a0990be65fc"/>
							<gml:surfaceMember xlink:href="#poly-6466eb0a-ce83-456f-b664-21fc9f52f992"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-77aa4572-0063-4ba9-a763-46b986831dc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77aa4572-0063-4ba9-a763-46b986831dc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77aa4572-0063-4ba9-a763-46b986831dc6">
											<gml:posList>35.67117649783225 139.74425052586358 6.763 35.671194519687056 139.744242950121 6.763 35.671206747569684 139.74428662494137 6.763 35.67118872571216 139.7442942006753 6.763 35.67117649783225 139.74425052586358 6.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7bb1ba46-ba28-47f1-bf47-6f856b695e08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7bb1ba46-ba28-47f1-bf47-6f856b695e08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7bb1ba46-ba28-47f1-bf47-6f856b695e08">
											<gml:posList>35.671194519687056 139.744242950121 9.831 35.67117649783225 139.74425052586358 9.831 35.67118872571216 139.7442942006753 9.831 35.671206747569684 139.74428662494137 9.831 35.671194519687056 139.744242950121 9.831</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ad5b1da-9d3f-468c-a36c-bbe6779a1a51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ad5b1da-9d3f-468c-a36c-bbe6779a1a51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ad5b1da-9d3f-468c-a36c-bbe6779a1a51">
											<gml:posList>35.671194519687056 139.744242950121 6.763 35.67117649783225 139.74425052586358 6.763 35.67117649783225 139.74425052586358 9.831 35.671194519687056 139.744242950121 9.831 35.671194519687056 139.744242950121 6.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87e3388f-9d17-4b93-a63c-7045cfdcc749">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87e3388f-9d17-4b93-a63c-7045cfdcc749">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87e3388f-9d17-4b93-a63c-7045cfdcc749">
											<gml:posList>35.671206747569684 139.74428662494137 6.763 35.671194519687056 139.744242950121 6.763 35.671194519687056 139.744242950121 9.831 35.671206747569684 139.74428662494137 9.831 35.671206747569684 139.74428662494137 6.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a913dc67-f43c-4bf7-ac5b-6a0990be65fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a913dc67-f43c-4bf7-ac5b-6a0990be65fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a913dc67-f43c-4bf7-ac5b-6a0990be65fc">
											<gml:posList>35.67117649783225 139.74425052586358 6.763 35.67118872571216 139.7442942006753 6.763 35.67118872571216 139.7442942006753 9.831 35.67117649783225 139.74425052586358 9.831 35.67117649783225 139.74425052586358 6.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6466eb0a-ce83-456f-b664-21fc9f52f992">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6466eb0a-ce83-456f-b664-21fc9f52f992">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6466eb0a-ce83-456f-b664-21fc9f52f992">
											<gml:posList>35.67118872571216 139.7442942006753 6.763 35.671206747569684 139.74428662494137 6.763 35.671206747569684 139.74428662494137 9.831 35.67118872571216 139.7442942006753 9.831 35.67118872571216 139.7442942006753 6.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-2983</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">224</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>