<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3e5fee21-eb14-44a1-a131-85b7c81b7aa9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">12.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66815080189318 139.73906173752937 0 35.668036614756765 139.73896820223658 0 35.66801279396819 139.73905195844338 0 35.66810299822218 139.73913745845886 0 35.66815080189318 139.73906173752937 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66815080189318 139.73906173752937 12.316 35.66810299822218 139.73913745845886 12.316 35.66801279396819 139.73905195844338 12.316 35.668036614756765 139.73896820223658 12.316 35.66815080189318 139.73906173752937 12.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66815080189318 139.73906173752937 12.316 35.668036614756765 139.73896820223658 12.316 35.668036614756765 139.73896820223658 24.95 35.66815080189318 139.73906173752937 24.95 35.66815080189318 139.73906173752937 12.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668036614756765 139.73896820223658 12.316 35.66801279396819 139.73905195844338 12.316 35.66801279396819 139.73905195844338 24.95 35.668036614756765 139.73896820223658 24.95 35.668036614756765 139.73896820223658 12.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66801279396819 139.73905195844338 12.316 35.66810299822218 139.73913745845886 12.316 35.66810299822218 139.73913745845886 24.95 35.66801279396819 139.73905195844338 24.95 35.66801279396819 139.73905195844338 12.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66810299822218 139.73913745845886 12.316 35.66815080189318 139.73906173752937 12.316 35.66815080189318 139.73906173752937 24.95 35.66810299822218 139.73913745845886 24.95 35.66810299822218 139.73913745845886 12.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66815080189318 139.73906173752937 24.95 35.668036614756765 139.73896820223658 24.95 35.66801279396819 139.73905195844338 24.95 35.66810299822218 139.73913745845886 24.95 35.66815080189318 139.73906173752937 24.95</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-12d72755-0efb-46df-adc4-d27ea3eac467"/>
							<gml:surfaceMember xlink:href="#poly-4bb6636b-38e3-4fbe-8997-6c52717b1ea4"/>
							<gml:surfaceMember xlink:href="#poly-f0d9eca8-d53e-4024-b64e-4377fd9e1f96"/>
							<gml:surfaceMember xlink:href="#poly-8a1fa932-004a-4a1f-856b-2c377d2b0ead"/>
							<gml:surfaceMember xlink:href="#poly-e3b8cc39-3355-4da6-a530-4ffa60a8ce87"/>
							<gml:surfaceMember xlink:href="#poly-d17732a5-8525-4a76-b0ba-649b5278306f"/>
							<gml:surfaceMember xlink:href="#poly-6552c858-3f9a-4205-b8b4-c9ab8348e238"/>
							<gml:surfaceMember xlink:href="#poly-76ea3a05-34dd-4d43-96a4-4c6c2dcace95"/>
							<gml:surfaceMember xlink:href="#poly-efd7310b-bd5b-464d-b786-d09e43a92821"/>
							<gml:surfaceMember xlink:href="#poly-47516ff0-f812-4769-a61f-17569ce7557d"/>
							<gml:surfaceMember xlink:href="#poly-46d1d19d-9348-4ac8-a414-43e265ec6551"/>
							<gml:surfaceMember xlink:href="#poly-345ce413-4027-49ff-8dee-acc2be0946c3"/>
							<gml:surfaceMember xlink:href="#poly-a0fed598-c234-4c35-8f69-7ac49658d8f2"/>
							<gml:surfaceMember xlink:href="#poly-471f74e4-762c-4620-84d2-a6e54b50e6a6"/>
							<gml:surfaceMember xlink:href="#poly-e0efa7c4-2921-4307-a179-815509d35861"/>
							<gml:surfaceMember xlink:href="#poly-01d0af82-7466-42ba-b7e0-381b678140e6"/>
							<gml:surfaceMember xlink:href="#poly-f9d45b95-6955-4c2a-b458-ca0cd3edf0a4"/>
							<gml:surfaceMember xlink:href="#poly-9eae9924-ebb7-4fe2-932f-961f8a3d3f08"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-12d72755-0efb-46df-adc4-d27ea3eac467">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12d72755-0efb-46df-adc4-d27ea3eac467">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12d72755-0efb-46df-adc4-d27ea3eac467">
											<gml:posList>35.66815080189317 139.73906173752937 12.316 35.66810299822218 139.73913745845883 12.316 35.668012793968174 139.73905195844335 12.316 35.668036614756744 139.73896820223658 12.316 35.66815080189317 139.73906173752937 12.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4bb6636b-38e3-4fbe-8997-6c52717b1ea4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4bb6636b-38e3-4fbe-8997-6c52717b1ea4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4bb6636b-38e3-4fbe-8997-6c52717b1ea4">
											<gml:posList>35.66802716735553 139.73900142848169 28.704 35.66802896060239 139.73900080779967 28.704 35.66803741024117 139.73897110638174 28.704 35.668036614756744 139.73896820223658 28.704 35.66802716735553 139.73900142848169 28.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f0d9eca8-d53e-4024-b64e-4377fd9e1f96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f0d9eca8-d53e-4024-b64e-4377fd9e1f96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f0d9eca8-d53e-4024-b64e-4377fd9e1f96">
											<gml:posList>35.6680971053444 139.73907103506957 28.704 35.66802716735553 139.73900142848169 28.704 35.668012793968174 139.73905195844335 22.662 35.6680971053444 139.73907103506957 28.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8a1fa932-004a-4a1f-856b-2c377d2b0ead">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a1fa932-004a-4a1f-856b-2c377d2b0ead">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a1fa932-004a-4a1f-856b-2c377d2b0ead">
											<gml:posList>35.668012793968174 139.73905195844335 22.662 35.66810299822218 139.73913745845883 22.662 35.6680971053444 139.73907103506957 28.704 35.668012793968174 139.73905195844335 22.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e3b8cc39-3355-4da6-a530-4ffa60a8ce87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e3b8cc39-3355-4da6-a530-4ffa60a8ce87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e3b8cc39-3355-4da6-a530-4ffa60a8ce87">
											<gml:posList>35.6680971053444 139.73907103506957 28.704 35.668096895979396 139.73906841742678 28.704 35.66802896060239 139.73900080779967 28.704 35.66802716735553 139.73900142848169 28.704 35.6680971053444 139.73907103506957 28.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d17732a5-8525-4a76-b0ba-649b5278306f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d17732a5-8525-4a76-b0ba-649b5278306f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d17732a5-8525-4a76-b0ba-649b5278306f">
											<gml:posList>35.66811823416399 139.7390372979988 27.946 35.66803741024117 139.73897110638174 27.946 35.66802896060239 139.73900080779967 27.946 35.668096895979396 139.73906841742678 27.946 35.66811823416399 139.7390372979988 27.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6552c858-3f9a-4205-b8b4-c9ab8348e238">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6552c858-3f9a-4205-b8b4-c9ab8348e238">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6552c858-3f9a-4205-b8b4-c9ab8348e238">
											<gml:posList>35.668036614756744 139.73896820223658 28.704 35.66803741024117 139.73897110638174 28.704 35.66811823416399 139.7390372979988 28.704 35.66812050532877 139.73903691976568 28.704 35.668036614756744 139.73896820223658 28.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76ea3a05-34dd-4d43-96a4-4c6c2dcace95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76ea3a05-34dd-4d43-96a4-4c6c2dcace95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76ea3a05-34dd-4d43-96a4-4c6c2dcace95">
											<gml:posList>35.6680971053444 139.73907103506957 28.704 35.66812050532877 139.73903691976568 28.704 35.66811823416399 139.7390372979988 28.704 35.668096895979396 139.73906841742678 28.704 35.6680971053444 139.73907103506957 28.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-efd7310b-bd5b-464d-b786-d09e43a92821">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efd7310b-bd5b-464d-b786-d09e43a92821">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efd7310b-bd5b-464d-b786-d09e43a92821">
											<gml:posList>35.66815080189317 139.73906173752937 22.662 35.66812050532877 139.73903691976568 28.704 35.6680971053444 139.73907103506957 28.704 35.66815080189317 139.73906173752937 22.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-47516ff0-f812-4769-a61f-17569ce7557d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47516ff0-f812-4769-a61f-17569ce7557d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47516ff0-f812-4769-a61f-17569ce7557d">
											<gml:posList>35.6680971053444 139.73907103506957 28.704 35.66810299822218 139.73913745845883 22.662 35.66815080189317 139.73906173752937 22.662 35.6680971053444 139.73907103506957 28.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46d1d19d-9348-4ac8-a414-43e265ec6551">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46d1d19d-9348-4ac8-a414-43e265ec6551">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46d1d19d-9348-4ac8-a414-43e265ec6551">
											<gml:posList>35.668096895979396 139.73906841742678 28.704 35.668096895979396 139.73906841742678 27.946 35.66802896060239 139.73900080779967 27.946 35.66802896060239 139.73900080779967 28.704 35.668096895979396 139.73906841742678 28.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-345ce413-4027-49ff-8dee-acc2be0946c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-345ce413-4027-49ff-8dee-acc2be0946c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-345ce413-4027-49ff-8dee-acc2be0946c3">
											<gml:posList>35.668012793968174 139.73905195844335 22.662 35.66802716735553 139.73900142848169 28.704 35.668036614756744 139.73896820223658 28.704 35.668036614756744 139.73896820223658 12.316 35.668012793968174 139.73905195844335 12.316 35.668012793968174 139.73905195844335 22.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0fed598-c234-4c35-8f69-7ac49658d8f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0fed598-c234-4c35-8f69-7ac49658d8f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0fed598-c234-4c35-8f69-7ac49658d8f2">
											<gml:posList>35.66802896060239 139.73900080779967 28.704 35.66802896060239 139.73900080779967 27.946 35.66803741024117 139.73897110638174 27.946 35.66803741024117 139.73897110638174 28.704 35.66802896060239 139.73900080779967 28.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-471f74e4-762c-4620-84d2-a6e54b50e6a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-471f74e4-762c-4620-84d2-a6e54b50e6a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-471f74e4-762c-4620-84d2-a6e54b50e6a6">
											<gml:posList>35.668012793968174 139.73905195844335 12.316 35.66810299822218 139.73913745845883 12.316 35.66810299822218 139.73913745845883 22.662 35.668012793968174 139.73905195844335 22.662 35.668012793968174 139.73905195844335 12.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0efa7c4-2921-4307-a179-815509d35861">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0efa7c4-2921-4307-a179-815509d35861">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0efa7c4-2921-4307-a179-815509d35861">
											<gml:posList>35.66803741024117 139.73897110638174 28.704 35.66803741024117 139.73897110638174 27.946 35.66811823416399 139.7390372979988 27.946 35.66811823416399 139.7390372979988 28.704 35.66803741024117 139.73897110638174 28.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01d0af82-7466-42ba-b7e0-381b678140e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01d0af82-7466-42ba-b7e0-381b678140e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01d0af82-7466-42ba-b7e0-381b678140e6">
											<gml:posList>35.668036614756744 139.73896820223658 28.704 35.66812050532877 139.73903691976568 28.704 35.66815080189317 139.73906173752937 22.662 35.66815080189317 139.73906173752937 12.316 35.668036614756744 139.73896820223658 12.316 35.668036614756744 139.73896820223658 28.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9d45b95-6955-4c2a-b458-ca0cd3edf0a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9d45b95-6955-4c2a-b458-ca0cd3edf0a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9d45b95-6955-4c2a-b458-ca0cd3edf0a4">
											<gml:posList>35.66811823416399 139.7390372979988 28.704 35.66811823416399 139.7390372979988 27.946 35.668096895979396 139.73906841742678 27.946 35.668096895979396 139.73906841742678 28.704 35.66811823416399 139.7390372979988 28.704</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9eae9924-ebb7-4fe2-932f-961f8a3d3f08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9eae9924-ebb7-4fe2-932f-961f8a3d3f08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9eae9924-ebb7-4fe2-932f-961f8a3d3f08">
											<gml:posList>35.66810299822218 139.73913745845883 12.316 35.66815080189317 139.73906173752937 12.316 35.66815080189317 139.73906173752937 22.662 35.66810299822218 139.73913745845883 22.662 35.66810299822218 139.73913745845883 12.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6796</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">114.04365</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>