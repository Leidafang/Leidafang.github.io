<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3e6d5b39-6f4d-46b0-bf9e-2c86f9254c34">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">26.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67397036304005 139.73852199914148 0 35.674082734681136 139.73848452816145 0 35.67402950575143 139.7383093894928 0 35.6739219231977 139.7383617681276 0 35.67397036304005 139.73852199914148 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67397036304005 139.73852199914148 7.83 35.6739219231977 139.7383617681276 7.83 35.67402950575143 139.7383093894928 7.83 35.674082734681136 139.73848452816145 7.83 35.67397036304005 139.73852199914148 7.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67397036304005 139.73852199914148 7.83 35.674082734681136 139.73848452816145 7.83 35.674082734681136 139.73848452816145 34.36 35.67397036304005 139.73852199914148 34.36 35.67397036304005 139.73852199914148 7.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674082734681136 139.73848452816145 7.83 35.67402950575143 139.7383093894928 7.83 35.67402950575143 139.7383093894928 34.36 35.674082734681136 139.73848452816145 34.36 35.674082734681136 139.73848452816145 7.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402950575143 139.7383093894928 7.83 35.6739219231977 139.7383617681276 7.83 35.6739219231977 139.7383617681276 34.36 35.67402950575143 139.7383093894928 34.36 35.67402950575143 139.7383093894928 7.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6739219231977 139.7383617681276 7.83 35.67397036304005 139.73852199914148 7.83 35.67397036304005 139.73852199914148 34.36 35.6739219231977 139.7383617681276 34.36 35.6739219231977 139.7383617681276 7.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67397036304005 139.73852199914148 34.36 35.674082734681136 139.73848452816145 34.36 35.67402950575143 139.7383093894928 34.36 35.6739219231977 139.7383617681276 34.36 35.67397036304005 139.73852199914148 34.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-34bec188-7a7e-4fc1-8bab-81c0933bc74c"/>
							<gml:surfaceMember xlink:href="#poly-43968bfb-c7e9-4936-8cd0-d1110fb673b8"/>
							<gml:surfaceMember xlink:href="#poly-55a5544a-d42b-40cc-ab71-8888ea3ace49"/>
							<gml:surfaceMember xlink:href="#poly-2021aafe-5c52-4f63-bb0c-004a05631d86"/>
							<gml:surfaceMember xlink:href="#poly-b0c3748e-5f93-4d72-8c38-146e29a4fa1e"/>
							<gml:surfaceMember xlink:href="#poly-ed53f25d-4ca1-40b7-aa58-66d476d913e9"/>
							<gml:surfaceMember xlink:href="#poly-f28c503c-f829-4867-98ea-4d455781feea"/>
							<gml:surfaceMember xlink:href="#poly-f2bafc24-0296-4fe1-9296-a9486bbee544"/>
							<gml:surfaceMember xlink:href="#poly-d030f9c1-12fb-447d-805b-e1b95f232f1f"/>
							<gml:surfaceMember xlink:href="#poly-3210316d-edf8-4800-859f-9da96f8e4742"/>
							<gml:surfaceMember xlink:href="#poly-797bfb07-e2d6-46c8-84c4-db52daaf6d90"/>
							<gml:surfaceMember xlink:href="#poly-b26862e1-3c9d-4522-8de8-7c02fd67d7e1"/>
							<gml:surfaceMember xlink:href="#poly-da20153a-98b6-4fe6-a86d-290b800c89fb"/>
							<gml:surfaceMember xlink:href="#poly-505fe057-eae5-4c99-90af-d78ffcda9204"/>
							<gml:surfaceMember xlink:href="#poly-06fb1cf0-17b6-46c3-9b40-31f6485b334d"/>
							<gml:surfaceMember xlink:href="#poly-15d5e258-3e84-4eac-8b4e-6781a6816811"/>
							<gml:surfaceMember xlink:href="#poly-67577345-4443-4083-8b27-a05177c156ee"/>
							<gml:surfaceMember xlink:href="#poly-36a17244-af8f-49df-ad12-d313342da47e"/>
							<gml:surfaceMember xlink:href="#poly-e482e0ea-0a63-4427-bc3c-8fb85aa64d8a"/>
							<gml:surfaceMember xlink:href="#poly-a35792cc-d8c7-4f19-ba8c-72e578cfaa81"/>
							<gml:surfaceMember xlink:href="#poly-d134b3cb-6f64-4b49-8120-f1a76cb71900"/>
							<gml:surfaceMember xlink:href="#poly-20376d9e-6899-42e7-bb7d-c973647e1faa"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3e6d5b39-6f4d-46b0-bf9e-2c86f9254c34_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4893b7c3-6a9a-4b1e-8b2b-17ae7c692bf1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674000241867034 139.73841690913565 32.897 35.67400978510476 139.7384483037734 32.897 35.674003793133274 139.7384510394148 32.897 35.67399424088254 139.73841964478976 32.897 35.674000241867034 139.73841690913565 32.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b0fb75d-6d27-4f6c-ad99-26bfd1d68754">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b0fb75d-6d27-4f6c-ad99-26bfd1d68754_0">
											<gml:posList>35.674000241867034 139.73841690913565 33.468 35.674000241867034 139.73841690913565 32.897 35.67399424088254 139.73841964478976 32.897 35.67399424088254 139.73841964478976 33.468 35.674000241867034 139.73841690913565 33.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76f3d09a-059e-42ad-891c-54814836fa60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76f3d09a-059e-42ad-891c-54814836fa60_0">
											<gml:posList>35.67399424088254 139.73841964478976 33.468 35.67399424088254 139.73841964478976 32.897 35.674003793133274 139.7384510394148 32.897 35.674003793133274 139.7384510394148 33.468 35.67399424088254 139.73841964478976 33.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-618d67a3-aa64-407c-8221-01fd6f98e8ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-618d67a3-aa64-407c-8221-01fd6f98e8ce_0">
											<gml:posList>35.674003793133274 139.7384510394148 33.468 35.67400978510476 139.7384483037734 33.468 35.674000241867034 139.73841690913565 33.468 35.67399424088254 139.73841964478976 33.468 35.674003793133274 139.7384510394148 33.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-328b8cd3-a288-4c03-b86f-0b5655aea321">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-328b8cd3-a288-4c03-b86f-0b5655aea321_0">
											<gml:posList>35.67400978510476 139.7384483037734 33.468 35.67400978510476 139.7384483037734 32.897 35.674000241867034 139.73841690913565 32.897 35.674000241867034 139.73841690913565 33.468 35.67400978510476 139.7384483037734 33.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-035d6d9c-3b60-42e3-81aa-3a65c719f07e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-035d6d9c-3b60-42e3-81aa-3a65c719f07e_0">
											<gml:posList>35.674003793133274 139.7384510394148 33.468 35.674003793133274 139.7384510394148 32.897 35.67400978510476 139.7384483037734 32.897 35.67400978510476 139.7384483037734 33.468 35.674003793133274 139.7384510394148 33.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3e6d5b39-6f4d-46b0-bf9e-2c86f9254c34_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-908afdae-107d-4eba-806f-c49c03281d9b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673979543486546 139.73850478848618 32.897 35.67395942682197 139.73843864223502 32.897 35.673984043459086 139.7384274006388 32.897 35.673992773309614 139.73845606768512 32.897 35.67400978510476 139.7384483037734 32.897 35.674021180923624 139.73848576089836 32.897 35.673979543486546 139.73850478848618 32.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4d258b7-1d9f-4059-84fd-77328fd51406">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67403955278847 139.73844240270907 36.144 35.67404683325979 139.73843908006205 36.144 35.674057171770066 139.7384731029099 36.144 35.67403804251582 139.7384818414415 36.144 35.6740291138213 139.73845247866555 36.144 35.6740409716157 139.7384470627639 36.144 35.67403955278847 139.73844240270907 36.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c422a479-d587-4b10-a774-21eaf4c4b6b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c422a479-d587-4b10-a774-21eaf4c4b6b0_0">
											<gml:posList>35.673979543486546 139.73850478848618 36.047 35.67395942682197 139.73843864223502 36.047 35.67395942682197 139.73843864223502 32.897 35.673979543486546 139.73850478848618 32.897 35.673979543486546 139.73850478848618 36.047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e423964e-d585-40c8-98d4-d630400cdb27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e423964e-d585-40c8-98d4-d630400cdb27_0">
											<gml:posList>35.673984043459086 139.7384274006388 36.047 35.673984043459086 139.7384274006388 32.897 35.67395942682197 139.73843864223502 32.897 35.67395942682197 139.73843864223502 36.047 35.673984043459086 139.7384274006388 36.047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6214bc6d-8730-47ae-9b1e-6da13cde34e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6214bc6d-8730-47ae-9b1e-6da13cde34e3_0">
											<gml:posList>35.673984043459086 139.7384274006388 36.047 35.673992773309614 139.73845606768512 36.047 35.673992773309614 139.73845606768512 32.897 35.673984043459086 139.7384274006388 32.897 35.673984043459086 139.7384274006388 36.047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35ee39cd-8c54-4949-a5dd-d10ed4597f46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35ee39cd-8c54-4949-a5dd-d10ed4597f46_0">
											<gml:posList>35.673984043459086 139.7384274006388 36.047 35.67395942682197 139.73843864223502 36.047 35.673979543486546 139.73850478848618 36.047 35.674021180923624 139.73848576089836 36.047 35.67400978510476 139.7384483037734 36.047 35.673992773309614 139.73845606768512 36.047 35.673984043459086 139.7384274006388 36.047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9444091a-b6c3-47c8-b4f4-a718392012ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9444091a-b6c3-47c8-b4f4-a718392012ba_0">
											<gml:posList>35.674021180923624 139.73848576089836 36.047 35.673979543486546 139.73850478848618 36.047 35.673979543486546 139.73850478848618 32.897 35.674021180923624 139.73848576089836 32.897 35.674021180923624 139.73848576089836 36.047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-405ffbb1-17ad-42a6-8c4c-9f0da585f35b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-405ffbb1-17ad-42a6-8c4c-9f0da585f35b_0">
											<gml:posList>35.673992773309614 139.73845606768512 36.047 35.67400978510476 139.7384483037734 36.047 35.67400978510476 139.7384483037734 32.897 35.673992773309614 139.73845606768512 32.897 35.673992773309614 139.73845606768512 36.047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e24a3f46-4c6e-4790-adab-adef54647e69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e24a3f46-4c6e-4790-adab-adef54647e69_0">
											<gml:posList>35.67400978510476 139.7384483037734 36.047 35.674021180923624 139.73848576089836 36.047 35.674021180923624 139.73848576089836 32.897 35.67400978510476 139.7384483037734 32.897 35.67400978510476 139.7384483037734 36.047</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02e2d8bb-3a6e-46c0-80de-32f96d10a9ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02e2d8bb-3a6e-46c0-80de-32f96d10a9ea_0">
											<gml:posList>35.67403804251582 139.7384818414415 38.918 35.6740291138213 139.73845247866555 38.918 35.6740291138213 139.73845247866555 36.144 35.67403804251582 139.7384818414415 36.144 35.67403804251582 139.7384818414415 38.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60337e5d-0605-4170-849d-1aebfef12d86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60337e5d-0605-4170-849d-1aebfef12d86_0">
											<gml:posList>35.6740291138213 139.73845247866555 38.918 35.6740409716157 139.7384470627639 38.918 35.6740409716157 139.7384470627639 36.144 35.6740291138213 139.73845247866555 36.144 35.6740291138213 139.73845247866555 38.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2257f9ae-9b05-4fb8-b75c-b36fc9890f1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2257f9ae-9b05-4fb8-b75c-b36fc9890f1b_0">
											<gml:posList>35.6740409716157 139.7384470627639 38.918 35.67403955278847 139.73844240270907 38.918 35.67403955278847 139.73844240270907 36.144 35.6740409716157 139.7384470627639 36.144 35.6740409716157 139.7384470627639 38.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19adc1bc-5f55-4b1d-bd89-bcec2b597366">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19adc1bc-5f55-4b1d-bd89-bcec2b597366_0">
											<gml:posList>35.674057171770066 139.7384731029099 38.918 35.67404683325979 139.73843908006205 38.918 35.67403955278847 139.73844240270907 38.918 35.6740409716157 139.7384470627639 38.918 35.6740291138213 139.73845247866555 38.918 35.67403804251582 139.7384818414415 38.918 35.674057171770066 139.7384731029099 38.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5d748a1-82fc-4a52-84af-9c80baf9639d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5d748a1-82fc-4a52-84af-9c80baf9639d_0">
											<gml:posList>35.67404683325979 139.73843908006205 38.918 35.67404683325979 139.73843908006205 36.144 35.67403955278847 139.73844240270907 36.144 35.67403955278847 139.73844240270907 38.918 35.67404683325979 139.73843908006205 38.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62a3aa49-8593-498a-8c78-ffaeea45d16a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62a3aa49-8593-498a-8c78-ffaeea45d16a_0">
											<gml:posList>35.674057171770066 139.7384731029099 38.918 35.67403804251582 139.7384818414415 38.918 35.67403804251582 139.7384818414415 36.144 35.674057171770066 139.7384731029099 36.144 35.674057171770066 139.7384731029099 38.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cad040c7-f2c9-427c-943a-1664ffc783b8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cad040c7-f2c9-427c-943a-1664ffc783b8_0">
											<gml:posList>35.67404683325979 139.73843908006205 38.918 35.674057171770066 139.7384731029099 38.918 35.674057171770066 139.7384731029099 36.144 35.67404683325979 139.73843908006205 36.144 35.67404683325979 139.73843908006205 38.918</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_3e6d5b39-6f4d-46b0-bf9e-2c86f9254c34_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-565e98aa-fe90-479f-977e-4f0bf361535a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67394658660373 139.7383755473478 32.897 35.673951900789746 139.73839344783713 32.897 35.67394559340033 139.73839626118144 32.897 35.673940270201015 139.73837836070405 32.897 35.67394658660373 139.7383755473478 32.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9be5ed8-a9b1-49a4-bd3f-48fc049eea3d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67393708081019 139.73835736461132 33.684 35.673954453156504 139.73834961130362 33.684 35.67395625166137 139.73835566279277 33.684 35.673939032983505 139.73836396825476 33.684 35.67393708081019 139.73835736461132 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b954116e-c4b1-4938-a8e0-803f913628b4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673956631256964 139.73835695481304 32.897 35.673939258910195 139.73836470811935 32.897 35.673939032983505 139.73836396825476 32.897 35.67395625166137 139.73835566279277 32.897 35.673956631256964 139.73835695481304 32.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1ad9f0e-8768-48c5-bcc9-5073b3f64e8e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67395482796329 139.73843628367388 32.897 35.67394922495286 139.73841788641926 32.897 35.67396887680672 139.73840890423475 32.897 35.673974470813505 139.73842731255067 32.897 35.67395482796329 139.73843628367388 32.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25f4ad3a-a00a-4bab-9440-c574468b06a8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674006911175944 139.73837010716838 36.144 35.67399973883624 139.7383733855049 36.144 35.67399345800985 139.73835273550898 36.144 35.674000630349 139.7383494571709 36.144 35.674006911175944 139.73837010716838 36.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69e870cf-ad7c-4763-a70e-c8471bc07b2b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674017471453254 139.73836527827146 36.144 35.67401074062899 139.73836835724416 36.144 35.67400445980174 139.7383477072458 36.144 35.67401119062549 139.73834462827162 36.144 35.674017471453254 139.73836527827146 36.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6036bdb6-39a7-4d1d-9a37-42c34ef1757c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67401119062549 139.73834462827162 37.994 35.674017471453254 139.73836527827146 37.994 35.674017471453254 139.73836527827146 36.144 35.67401119062549 139.73834462827162 36.144 35.67401119062549 139.73834462827162 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02333f41-0908-47d6-9067-2e914223b356">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674025290166654 139.73839297428694 36.144 35.67401239617175 139.73839886643327 36.144 35.674007055215476 139.73838130841136 36.144 35.67401994920953 139.73837541626258 36.144 35.674025290166654 139.73839297428694 36.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a231b4b2-b59d-4462-900a-d8a62c740f3c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402115673902 139.7383635947981 37.994 35.67401487591098 139.73834294479744 37.994 35.67401487591098 139.73834294479744 36.144 35.67402115673902 139.7383635947981 36.144 35.67402115673902 139.7383635947981 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be768932-80d9-42c6-8873-2515631b9f48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67401487591098 139.73834294479744 36.144 35.67402215637957 139.73833962214243 36.144 35.674028437208186 139.73836027214472 36.144 35.67402115673902 139.7383635947981 36.144 35.67401487591098 139.73834294479744 36.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b70225d-4b41-4706-8d2f-5e863a9a7903">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67401551673809 139.73841260490747 36.144 35.674022788194904 139.73840928226943 36.144 35.67402901479868 139.73842976664008 36.144 35.67402174334131 139.73843308927653 36.144 35.67401551673809 139.73841260490747 36.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85bfb718-72f4-41bd-b33c-1031b4eb80e2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402379895169 139.73836510507428 37.728 35.67402379895169 139.73836510507428 36.144 35.674023267830705 139.7383659783976 36.144 35.674023267830705 139.7383659783976 37.728 35.67402379895169 139.73836510507428 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d163a156-b23c-455f-ae3f-380745f07334">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402379895169 139.73836510507428 37.728 35.6740244744141 139.73836438623462 37.728 35.6740244744141 139.73836438623462 36.144 35.67402379895169 139.73836510507428 36.144 35.67402379895169 139.73836510507428 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4330de9-89d2-4e2e-b43d-eec4f4a68047">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674026997505464 139.73836343322418 37.728 35.674026997505464 139.73836343322418 36.144 35.67402610522593 139.73836353370206 36.144 35.67402610522593 139.73836353370206 37.728 35.674026997505464 139.73836343322418 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-323c3d66-9b8c-41d6-8ef6-c3a0c894f6fb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402949513271 139.7383644797077 36.144 35.67403014470406 139.73836521907128 36.144 35.67403065919165 139.73836611324953 36.144 35.67403101151945 139.73836711808752 36.144 35.67403118362518 139.73836818941962 36.144 35.674031175474 139.73836928305872 36.144 35.674030978017335 139.73837035482856 36.144 35.67403060022534 139.73837134948468 36.144 35.67403006910432 139.738372222808 36.144 35.67402939364186 139.73837294164767 36.144 35.67402860986668 139.73837347282065 36.144 35.674027762838676 139.73837380522684 36.144 35.67402687055913 139.73837390570463 36.144 35.674025987110355 139.73837377418994 36.144 35.674025139542195 139.73837342169756 36.144 35.67402437293196 139.7383728592208 36.144 35.67402371433822 139.73837210882115 36.144 35.67402319985069 139.73837121464294 36.144 35.67402284752291 139.73837020980503 36.144 35.67402267541719 139.73836913847308 36.144 35.6740226925821 139.7383680448234 36.144 35.67402289003875 139.73836697305364 36.144 35.674023267830705 139.7383659783976 36.144 35.67402379895169 139.73836510507428 36.144 35.6740244744141 139.73836438623462 36.144 35.674025249175514 139.73836385507227 36.144 35.67402610522593 139.73836353370206 36.144 35.674026997505464 139.73836343322418 36.144 35.67402788095425 139.73836356473873 36.144 35.67402872852243 139.73836391723103 36.144 35.67402949513271 139.7383644797077 36.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27b1003b-deae-4b13-bbe7-6dd4f9690274">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402788095425 139.73836356473873 37.728 35.67402788095425 139.73836356473873 36.144 35.674026997505464 139.73836343322418 36.144 35.674026997505464 139.73836343322418 37.728 35.67402788095425 139.73836356473873 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9049176-01b6-42c4-aeff-b58bff0edb0e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67403280821512 139.7384280388544 36.144 35.67402658161105 139.73840755448288 36.144 35.67403369989548 139.73840430935263 36.144 35.67403991747767 139.73842478268963 36.144 35.67403280821512 139.7384280388544 36.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd5ec41d-309d-4a6f-86c2-0f6c5d1e0703">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67404788305974 139.73838724739994 36.144 35.67404129639343 139.73839024887388 36.144 35.67402009516104 139.73832048054848 36.144 35.674026627603844 139.73831730238572 36.144 35.67404788305974 139.73838724739994 36.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4de562d4-b132-4da8-a74c-90fb60892343">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674026627603844 139.73831730238572 36.573 35.67402009516104 139.73832048054848 36.573 35.674019082992224 139.7383171456264 36.573 35.67402823763319 139.73831295910003 36.573 35.674050460059355 139.73838607339079 36.573 35.67404788305974 139.73838724739994 36.573 35.674026627603844 139.73831730238572 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dddd30c-55d3-479e-9598-3ce6c41e5dcd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67403369989548 139.73840430935263 37.959 35.67403991747767 139.73842478268963 37.959 35.67403991747767 139.73842478268963 36.144 35.67403369989548 139.73840430935263 36.144 35.67403369989548 139.73840430935263 37.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e66fd2d8-5ace-41e1-ba25-e015d47273bc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.674042512505096 139.73842360866044 37.959 35.67403636722405 139.73840337826604 37.959 35.67403636722405 139.73840337826604 36.144 35.674042512505096 139.73842360866044 36.144 35.674042512505096 139.73842360866044 37.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c636801b-0e21-4993-8192-bbf3a33c0c14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67404425139557 139.7383997787316 36.144 35.67405040568222 139.7384199980703 36.144 35.674042512505096 139.73842360866044 36.144 35.67403636722405 139.73840337826604 36.144 35.67404425139557 139.7383997787316 36.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fbe8235-aad4-47b0-bbc5-118e9d72762f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fbe8235-aad4-47b0-bbc5-118e9d72762f_0">
											<gml:posList>35.6740244744141 139.73836438623462 37.728 35.674025249175514 139.73836385507227 37.728 35.674025249175514 139.73836385507227 36.144 35.6740244744141 139.73836438623462 36.144 35.6740244744141 139.73836438623462 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e51285d-e85d-4124-9d09-f4b40ff2a2eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e51285d-e85d-4124-9d09-f4b40ff2a2eb_0">
											<gml:posList>35.674028437208186 139.73836027214472 37.994 35.674028437208186 139.73836027214472 36.144 35.67402215637957 139.73833962214243 36.144 35.67402215637957 139.73833962214243 37.994 35.674028437208186 139.73836027214472 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1e0d3e6-435c-40be-ac13-dd08b6dc1a60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1e0d3e6-435c-40be-ac13-dd08b6dc1a60_0">
											<gml:posList>35.674025249175514 139.73836385507227 37.728 35.67402610522593 139.73836353370206 37.728 35.67402610522593 139.73836353370206 36.144 35.674025249175514 139.73836385507227 36.144 35.674025249175514 139.73836385507227 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55ac4c32-09a0-4052-9133-e557cd88a9a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55ac4c32-09a0-4052-9133-e557cd88a9a2_0">
											<gml:posList>35.67402788095425 139.73836356473873 37.728 35.67402872852243 139.73836391723103 37.728 35.67402872852243 139.73836391723103 36.144 35.67402788095425 139.73836356473873 36.144 35.67402788095425 139.73836356473873 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9258674f-0eae-470a-8c93-d752a00058d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9258674f-0eae-470a-8c93-d752a00058d3_0">
											<gml:posList>35.67402872852243 139.73836391723103 37.728 35.67402949513271 139.7383644797077 37.728 35.67402949513271 139.7383644797077 36.144 35.67402872852243 139.73836391723103 36.144 35.67402872852243 139.73836391723103 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5faa9213-de97-4373-b49b-6d38da40483b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5faa9213-de97-4373-b49b-6d38da40483b_0">
											<gml:posList>35.67403280821512 139.7384280388544 37.959 35.67402658161105 139.73840755448288 37.959 35.67402658161105 139.73840755448288 36.144 35.67403280821512 139.7384280388544 36.144 35.67403280821512 139.7384280388544 37.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8f530ca-72b8-46c9-abe7-1194b5832458">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8f530ca-72b8-46c9-abe7-1194b5832458_0">
											<gml:posList>35.67402949513271 139.7383644797077 37.728 35.67403014470406 139.73836521907128 37.728 35.67403014470406 139.73836521907128 36.144 35.67402949513271 139.7383644797077 36.144 35.67402949513271 139.7383644797077 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44c4472e-e8c8-43d9-8d62-0a65522e7a12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44c4472e-e8c8-43d9-8d62-0a65522e7a12_0">
											<gml:posList>35.67403014470406 139.73836521907128 37.728 35.67403065919165 139.73836611324953 37.728 35.67403065919165 139.73836611324953 36.144 35.67403014470406 139.73836521907128 36.144 35.67403014470406 139.73836521907128 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de749001-1463-4c96-a60e-9036f270f748">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de749001-1463-4c96-a60e-9036f270f748_0">
											<gml:posList>35.674030978017335 139.73837035482856 37.728 35.67403060022534 139.73837134948468 37.728 35.67403060022534 139.73837134948468 36.144 35.674030978017335 139.73837035482856 36.144 35.674030978017335 139.73837035482856 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-800e31d2-3c2a-4756-b092-efcff4943024">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-800e31d2-3c2a-4756-b092-efcff4943024_0">
											<gml:posList>35.67403065919165 139.73836611324953 37.728 35.67403101151945 139.73836711808752 37.728 35.67403101151945 139.73836711808752 36.144 35.67403065919165 139.73836611324953 36.144 35.67403065919165 139.73836611324953 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66d2b8af-c099-4df0-aebe-f792d5a273a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66d2b8af-c099-4df0-aebe-f792d5a273a0_0">
											<gml:posList>35.674031175474 139.73836928305872 37.728 35.674030978017335 139.73837035482856 37.728 35.674030978017335 139.73837035482856 36.144 35.674031175474 139.73836928305872 36.144 35.674031175474 139.73836928305872 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1479d8ba-0fc1-4fa0-b04d-923df11c9e99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1479d8ba-0fc1-4fa0-b04d-923df11c9e99_0">
											<gml:posList>35.67403101151945 139.73836711808752 37.728 35.67403118362518 139.73836818941962 37.728 35.67403118362518 139.73836818941962 36.144 35.67403101151945 139.73836711808752 36.144 35.67403101151945 139.73836711808752 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53342f29-b2ce-4ff4-8481-023310b41a86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53342f29-b2ce-4ff4-8481-023310b41a86_0">
											<gml:posList>35.67403118362518 139.73836818941962 37.728 35.674031175474 139.73836928305872 37.728 35.674031175474 139.73836928305872 36.144 35.67403118362518 139.73836818941962 36.144 35.67403118362518 139.73836818941962 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8ac7c7c-60a4-4bea-bd32-0bc721ae27c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8ac7c7c-60a4-4bea-bd32-0bc721ae27c3_0">
											<gml:posList>35.673939032983505 139.73836396825476 33.684 35.673939032983505 139.73836396825476 32.897 35.673939258910195 139.73836470811935 32.897 35.673939258910195 139.73836470811935 34.226 35.67393708081019 139.73835736461132 34.226 35.67393708081019 139.73835736461132 33.684 35.673939032983505 139.73836396825476 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bab7ec6d-046d-47c5-8c3d-6788bd381c31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bab7ec6d-046d-47c5-8c3d-6788bd381c31_0">
											<gml:posList>35.67394559340033 139.73839626118144 34.368 35.673940270201015 139.73837836070405 34.368 35.673940270201015 139.73837836070405 32.897 35.67394559340033 139.73839626118144 32.897 35.67394559340033 139.73839626118144 34.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-778ae4a7-8611-4df0-81d2-f41db8966fe6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-778ae4a7-8611-4df0-81d2-f41db8966fe6_0">
											<gml:posList>35.673940270201015 139.73837836070405 34.368 35.67394658660373 139.7383755473478 34.368 35.67394658660373 139.7383755473478 32.897 35.673940270201015 139.73837836070405 32.897 35.673940270201015 139.73837836070405 34.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7d7813b-bd05-4252-a153-ca97fbc39887">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7d7813b-bd05-4252-a153-ca97fbc39887_0">
											<gml:posList>35.67393708081019 139.73835736461132 34.226 35.673954453156504 139.73834961130362 34.226 35.673954453156504 139.73834961130362 33.684 35.67393708081019 139.73835736461132 33.684 35.67393708081019 139.73835736461132 34.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ace1c6d-2dbe-4c40-9edd-bfc7b2f16d21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ace1c6d-2dbe-4c40-9edd-bfc7b2f16d21_0">
											<gml:posList>35.67394658660373 139.7383755473478 34.368 35.673940270201015 139.73837836070405 34.368 35.67394559340033 139.73839626118144 34.368 35.673951900789746 139.73839344783713 34.368 35.67394658660373 139.7383755473478 34.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4826ed8-9871-4842-bf5d-617cf96a581d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4826ed8-9871-4842-bf5d-617cf96a581d_0">
											<gml:posList>35.67393708081019 139.73835736461132 34.226 35.673939258910195 139.73836470811935 34.226 35.673956631256964 139.73835695481304 34.226 35.673954453156504 139.73834961130362 34.226 35.67393708081019 139.73835736461132 34.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-594b5c6b-ff8b-4881-a794-599d143d06d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-594b5c6b-ff8b-4881-a794-599d143d06d1_0">
											<gml:posList>35.67395625166137 139.73835566279277 32.897 35.673939032983505 139.73836396825476 32.897 35.673939032983505 139.73836396825476 33.684 35.67395625166137 139.73835566279277 33.684 35.67395625166137 139.73835566279277 32.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6be29239-cb46-4cbd-8277-7ceb2541b61e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6be29239-cb46-4cbd-8277-7ceb2541b61e_0">
											<gml:posList>35.673956631256964 139.73835695481304 34.226 35.673939258910195 139.73836470811935 34.226 35.673939258910195 139.73836470811935 32.897 35.673956631256964 139.73835695481304 32.897 35.673956631256964 139.73835695481304 34.226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c450065e-65da-4827-83ea-3056d7d6a518">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c450065e-65da-4827-83ea-3056d7d6a518_0">
											<gml:posList>35.673951900789746 139.73839344783713 34.368 35.67394559340033 139.73839626118144 34.368 35.67394559340033 139.73839626118144 32.897 35.673951900789746 139.73839344783713 32.897 35.673951900789746 139.73839344783713 34.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d1989db-bb0e-40ad-b261-038f901ba462">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d1989db-bb0e-40ad-b261-038f901ba462_0">
											<gml:posList>35.67394658660373 139.7383755473478 34.368 35.673951900789746 139.73839344783713 34.368 35.673951900789746 139.73839344783713 32.897 35.67394658660373 139.7383755473478 32.897 35.67394658660373 139.7383755473478 34.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b06a8d45-2eb9-4646-8c4e-a4d36deb4d2d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b06a8d45-2eb9-4646-8c4e-a4d36deb4d2d_0">
											<gml:posList>35.67395482796329 139.73843628367388 34.694 35.67394922495286 139.73841788641926 34.694 35.67394922495286 139.73841788641926 32.897 35.67395482796329 139.73843628367388 32.897 35.67395482796329 139.73843628367388 34.694</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e569763d-6da1-46b6-a60c-8ca5ec437052">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e569763d-6da1-46b6-a60c-8ca5ec437052_0">
											<gml:posList>35.67395625166137 139.73835566279277 33.684 35.673954453156504 139.73834961130362 33.684 35.673954453156504 139.73834961130362 34.226 35.673956631256964 139.73835695481304 34.226 35.673956631256964 139.73835695481304 32.897 35.67395625166137 139.73835566279277 32.897 35.67395625166137 139.73835566279277 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e684c138-8b3a-4ce6-ad94-409a6a32259d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e684c138-8b3a-4ce6-ad94-409a6a32259d_0">
											<gml:posList>35.67394922495286 139.73841788641926 34.694 35.67396887680672 139.73840890423475 34.694 35.67396887680672 139.73840890423475 32.897 35.67394922495286 139.73841788641926 32.897 35.67394922495286 139.73841788641926 34.694</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db786935-1896-475e-8e55-4f491ff25552">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db786935-1896-475e-8e55-4f491ff25552_0">
											<gml:posList>35.67395482796329 139.73843628367388 34.694 35.673974470813505 139.73842731255067 34.694 35.67396887680672 139.73840890423475 34.694 35.67394922495286 139.73841788641926 34.694 35.67395482796329 139.73843628367388 34.694</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9935199b-9ca9-417d-8a6b-3c98ab8743ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9935199b-9ca9-417d-8a6b-3c98ab8743ca_0">
											<gml:posList>35.673974470813505 139.73842731255067 34.694 35.67395482796329 139.73843628367388 34.694 35.67395482796329 139.73843628367388 32.897 35.673974470813505 139.73842731255067 32.897 35.673974470813505 139.73842731255067 34.694</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7552ca64-5c2b-4c99-8e30-3a1519226b4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7552ca64-5c2b-4c99-8e30-3a1519226b4a_0">
											<gml:posList>35.67396887680672 139.73840890423475 34.694 35.673974470813505 139.73842731255067 34.694 35.673974470813505 139.73842731255067 32.897 35.67396887680672 139.73840890423475 32.897 35.67396887680672 139.73840890423475 34.694</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ac2a056-453c-427b-9328-d77ae48b2bd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ac2a056-453c-427b-9328-d77ae48b2bd1_0">
											<gml:posList>35.67399973883624 139.7383733855049 37.994 35.67399345800985 139.73835273550898 37.994 35.67399345800985 139.73835273550898 36.144 35.67399973883624 139.7383733855049 36.144 35.67399973883624 139.7383733855049 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b2ed80d-d593-4312-9903-2f9f92c14116">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b2ed80d-d593-4312-9903-2f9f92c14116_0">
											<gml:posList>35.67399345800985 139.73835273550898 37.994 35.674000630349 139.7383494571709 37.994 35.674000630349 139.7383494571709 36.144 35.67399345800985 139.73835273550898 36.144 35.67399345800985 139.73835273550898 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-912b7254-7e77-42e0-9f7e-d031e8a5e731">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-912b7254-7e77-42e0-9f7e-d031e8a5e731_0">
											<gml:posList>35.67399345800985 139.73835273550898 37.994 35.67399973883624 139.7383733855049 37.994 35.674006911175944 139.73837010716838 37.994 35.674000630349 139.7383494571709 37.994 35.67399345800985 139.73835273550898 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-058f06ac-f74b-4847-93c0-7d3f5f53f5e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-058f06ac-f74b-4847-93c0-7d3f5f53f5e2_0">
											<gml:posList>35.674006911175944 139.73837010716838 37.994 35.67399973883624 139.7383733855049 37.994 35.67399973883624 139.7383733855049 36.144 35.674006911175944 139.73837010716838 36.144 35.674006911175944 139.73837010716838 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2b2c953-a236-449f-aa34-76faaa59e908">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2b2c953-a236-449f-aa34-76faaa59e908_0">
											<gml:posList>35.674000630349 139.7383494571709 37.994 35.674006911175944 139.73837010716838 37.994 35.674006911175944 139.73837010716838 36.144 35.674000630349 139.7383494571709 36.144 35.674000630349 139.7383494571709 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b7cf1d4-a238-43d9-ba30-a1b78d9eeeb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b7cf1d4-a238-43d9-ba30-a1b78d9eeeb5_0">
											<gml:posList>35.67401074062899 139.73836835724416 37.994 35.67400445980174 139.7383477072458 37.994 35.67400445980174 139.7383477072458 36.144 35.67401074062899 139.73836835724416 36.144 35.67401074062899 139.73836835724416 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-959671f4-3d80-45f7-a3c0-dca58276e4ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-959671f4-3d80-45f7-a3c0-dca58276e4ca_0">
											<gml:posList>35.67400445980174 139.7383477072458 37.994 35.67401119062549 139.73834462827162 37.994 35.67401119062549 139.73834462827162 36.144 35.67400445980174 139.7383477072458 36.144 35.67400445980174 139.7383477072458 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1867ab0-1513-498f-8728-6d655b615ff1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1867ab0-1513-498f-8728-6d655b615ff1_0">
											<gml:posList>35.67401239617175 139.73839886643327 39.819 35.674007055215476 139.73838130841136 39.819 35.674007055215476 139.73838130841136 36.144 35.67401239617175 139.73839886643327 36.144 35.67401239617175 139.73839886643327 39.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6459e7e-45b7-4e58-83ff-aeb2a33d194d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6459e7e-45b7-4e58-83ff-aeb2a33d194d_0">
											<gml:posList>35.67400445980174 139.7383477072458 37.994 35.67401074062899 139.73836835724416 37.994 35.674017471453254 139.73836527827146 37.994 35.67401119062549 139.73834462827162 37.994 35.67400445980174 139.7383477072458 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be25c096-8aba-4af6-863e-c0f1ac1644e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be25c096-8aba-4af6-863e-c0f1ac1644e0_0">
											<gml:posList>35.674007055215476 139.73838130841136 39.819 35.67401994920953 139.73837541626258 39.819 35.67401994920953 139.73837541626258 36.144 35.674007055215476 139.73838130841136 36.144 35.674007055215476 139.73838130841136 39.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbf3056b-dec7-406a-9426-f3a7ff9ef2e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbf3056b-dec7-406a-9426-f3a7ff9ef2e0_0">
											<gml:posList>35.674017471453254 139.73836527827146 37.994 35.67401074062899 139.73836835724416 37.994 35.67401074062899 139.73836835724416 36.144 35.674017471453254 139.73836527827146 36.144 35.674017471453254 139.73836527827146 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63d88ad2-9bb0-4382-8455-151bb0adccd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63d88ad2-9bb0-4382-8455-151bb0adccd7_0">
											<gml:posList>35.674007055215476 139.73838130841136 39.819 35.67401239617175 139.73839886643327 39.819 35.674025290166654 139.73839297428694 39.819 35.67401994920953 139.73837541626258 39.819 35.674007055215476 139.73838130841136 39.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca3118bd-e174-47e9-aeeb-ed5fa4660dbd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca3118bd-e174-47e9-aeeb-ed5fa4660dbd_0">
											<gml:posList>35.67401487591098 139.73834294479744 37.994 35.67402215637957 139.73833962214243 37.994 35.67402215637957 139.73833962214243 36.144 35.67401487591098 139.73834294479744 36.144 35.67401487591098 139.73834294479744 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a43a737d-d51c-4aea-98fa-78bd8b6a1f41">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a43a737d-d51c-4aea-98fa-78bd8b6a1f41_0">
											<gml:posList>35.67402174334131 139.73843308927653 38.095 35.67401551673809 139.73841260490747 38.095 35.67401551673809 139.73841260490747 36.144 35.67402174334131 139.73843308927653 36.144 35.67402174334131 139.73843308927653 38.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4f00d00-5db1-4f0e-8fb1-8ccb45c7b5dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4f00d00-5db1-4f0e-8fb1-8ccb45c7b5dc_0">
											<gml:posList>35.674025290166654 139.73839297428694 39.819 35.67401239617175 139.73839886643327 39.819 35.67401239617175 139.73839886643327 36.144 35.674025290166654 139.73839297428694 36.144 35.674025290166654 139.73839297428694 39.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05c20d6b-2828-477f-9f55-4dac179358b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05c20d6b-2828-477f-9f55-4dac179358b6_0">
											<gml:posList>35.67401551673809 139.73841260490747 38.095 35.674022788194904 139.73840928226943 38.095 35.674022788194904 139.73840928226943 36.144 35.67401551673809 139.73841260490747 36.144 35.67401551673809 139.73841260490747 38.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb456f32-0484-4148-a1e3-853aab3d300c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb456f32-0484-4148-a1e3-853aab3d300c_0">
											<gml:posList>35.67401487591098 139.73834294479744 37.994 35.67402115673902 139.7383635947981 37.994 35.674028437208186 139.73836027214472 37.994 35.67402215637957 139.73833962214243 37.994 35.67401487591098 139.73834294479744 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a454c5ef-6e81-4a94-a756-3dac39cabb24">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a454c5ef-6e81-4a94-a756-3dac39cabb24_0">
											<gml:posList>35.67401551673809 139.73841260490747 38.095 35.67402174334131 139.73843308927653 38.095 35.67402901479868 139.73842976664008 38.095 35.674022788194904 139.73840928226943 38.095 35.67401551673809 139.73841260490747 38.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58ede4db-c720-4087-b50a-d2c6de3bbeb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58ede4db-c720-4087-b50a-d2c6de3bbeb1_0">
											<gml:posList>35.67401994920953 139.73837541626258 39.819 35.674025290166654 139.73839297428694 39.819 35.674025290166654 139.73839297428694 36.144 35.67401994920953 139.73837541626258 36.144 35.67401994920953 139.73837541626258 39.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcbdda06-9973-480a-bdca-c544e6fe9bbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcbdda06-9973-480a-bdca-c544e6fe9bbf_0">
											<gml:posList>35.67402267541719 139.73836913847308 37.728 35.6740226925821 139.7383680448234 37.728 35.6740226925821 139.7383680448234 36.144 35.67402267541719 139.73836913847308 36.144 35.67402267541719 139.73836913847308 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2098916-b203-4a24-a2a1-5f5d82771fe3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2098916-b203-4a24-a2a1-5f5d82771fe3_0">
											<gml:posList>35.67402284752291 139.73837020980503 37.728 35.67402267541719 139.73836913847308 37.728 35.67402267541719 139.73836913847308 36.144 35.67402284752291 139.73837020980503 36.144 35.67402284752291 139.73837020980503 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0ff66b55-48cf-4dd1-97a9-0ca24ebf4b39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0ff66b55-48cf-4dd1-97a9-0ca24ebf4b39_0">
											<gml:posList>35.6740226925821 139.7383680448234 37.728 35.67402289003875 139.73836697305364 37.728 35.67402289003875 139.73836697305364 36.144 35.6740226925821 139.7383680448234 36.144 35.6740226925821 139.7383680448234 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3c2eff0-a2de-4039-89f2-7c898280f565">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3c2eff0-a2de-4039-89f2-7c898280f565_0">
											<gml:posList>35.67402319985069 139.73837121464294 37.728 35.67402284752291 139.73837020980503 37.728 35.67402284752291 139.73837020980503 36.144 35.67402319985069 139.73837121464294 36.144 35.67402319985069 139.73837121464294 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44b2e98d-6b7d-4235-bf46-8e8a69b06317">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44b2e98d-6b7d-4235-bf46-8e8a69b06317_0">
											<gml:posList>35.674023267830705 139.7383659783976 37.728 35.674023267830705 139.7383659783976 36.144 35.67402289003875 139.73836697305364 36.144 35.67402289003875 139.73836697305364 37.728 35.674023267830705 139.7383659783976 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13516d3a-88dc-49df-8884-a24afd5eeea5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13516d3a-88dc-49df-8884-a24afd5eeea5_0">
											<gml:posList>35.674026627603844 139.73831730238572 36.573 35.674026627603844 139.73831730238572 36.144 35.67402009516104 139.73832048054848 36.144 35.67402009516104 139.73832048054848 36.573 35.674026627603844 139.73831730238572 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b503a8c-24af-4f18-bcd1-b6ef050cb851">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b503a8c-24af-4f18-bcd1-b6ef050cb851_0">
											<gml:posList>35.67402371433822 139.73837210882115 37.728 35.67402319985069 139.73837121464294 37.728 35.67402319985069 139.73837121464294 36.144 35.67402371433822 139.73837210882115 36.144 35.67402371433822 139.73837210882115 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af756517-2192-4474-af55-39d9e9e32609">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af756517-2192-4474-af55-39d9e9e32609_0">
											<gml:posList>35.67402823763319 139.73831295910003 36.573 35.674019082992224 139.7383171456264 36.573 35.674019082992224 139.7383171456264 38.202 35.67402823763319 139.73831295910003 38.202 35.67402823763319 139.73831295910003 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8439722e-6a10-4356-817f-d66af43b575a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8439722e-6a10-4356-817f-d66af43b575a_0">
											<gml:posList>35.67402437293196 139.7383728592208 37.728 35.67402371433822 139.73837210882115 37.728 35.67402371433822 139.73837210882115 36.144 35.67402437293196 139.7383728592208 36.144 35.67402437293196 139.7383728592208 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04b4cc7f-c649-4e8d-bef4-1633e8ce7c0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04b4cc7f-c649-4e8d-bef4-1633e8ce7c0c_0">
											<gml:posList>35.674025139542195 139.73837342169756 37.728 35.67402437293196 139.7383728592208 37.728 35.67402437293196 139.7383728592208 36.144 35.674025139542195 139.73837342169756 36.144 35.674025139542195 139.73837342169756 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dfec4aa5-dfbc-4c33-9fe6-605ebfcd297e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dfec4aa5-dfbc-4c33-9fe6-605ebfcd297e_0">
											<gml:posList>35.674028437208186 139.73836027214472 37.994 35.67402115673902 139.7383635947981 37.994 35.67402115673902 139.7383635947981 36.144 35.674028437208186 139.73836027214472 36.144 35.674028437208186 139.73836027214472 37.994</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df10a9af-66e0-4161-aac9-2a35920885e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df10a9af-66e0-4161-aac9-2a35920885e5_0">
											<gml:posList>35.67402901479868 139.73842976664008 38.095 35.67402174334131 139.73843308927653 38.095 35.67402174334131 139.73843308927653 36.144 35.67402901479868 139.73842976664008 36.144 35.67402901479868 139.73842976664008 38.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4722390b-5707-4344-802b-52552d9744d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4722390b-5707-4344-802b-52552d9744d1_0">
											<gml:posList>35.674025987110355 139.73837377418994 37.728 35.674025139542195 139.73837342169756 37.728 35.674025139542195 139.73837342169756 36.144 35.674025987110355 139.73837377418994 36.144 35.674025987110355 139.73837377418994 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b626bcf-3f45-47cf-9b75-d3c67689105a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b626bcf-3f45-47cf-9b75-d3c67689105a_0">
											<gml:posList>35.67402901479868 139.73842976664008 38.095 35.67402901479868 139.73842976664008 36.144 35.674022788194904 139.73840928226943 36.144 35.674022788194904 139.73840928226943 38.095 35.67402901479868 139.73842976664008 38.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7961688b-18b7-4842-afd4-dfc3417dde91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7961688b-18b7-4842-afd4-dfc3417dde91_0">
											<gml:posList>35.67402687055913 139.73837390570463 37.728 35.674025987110355 139.73837377418994 37.728 35.674025987110355 139.73837377418994 36.144 35.67402687055913 139.73837390570463 36.144 35.67402687055913 139.73837390570463 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4f310b7b-6a7e-45d1-b473-f6468cf34303">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4f310b7b-6a7e-45d1-b473-f6468cf34303_0">
											<gml:posList>35.67403065919165 139.73836611324953 37.728 35.67403014470406 139.73836521907128 37.728 35.67402949513271 139.7383644797077 37.728 35.67402872852243 139.73836391723103 37.728 35.67402788095425 139.73836356473873 37.728 35.674026997505464 139.73836343322418 37.728 35.67402610522593 139.73836353370206 37.728 35.674025249175514 139.73836385507227 37.728 35.6740244744141 139.73836438623462 37.728 35.67402379895169 139.73836510507428 37.728 35.674023267830705 139.7383659783976 37.728 35.67402289003875 139.73836697305364 37.728 35.6740226925821 139.7383680448234 37.728 35.67402267541719 139.73836913847308 37.728 35.67402284752291 139.73837020980503 37.728 35.67402319985069 139.73837121464294 37.728 35.67402371433822 139.73837210882115 37.728 35.67402437293196 139.7383728592208 37.728 35.674025139542195 139.73837342169756 37.728 35.674025987110355 139.73837377418994 37.728 35.67402687055913 139.73837390570463 37.728 35.674027762838676 139.73837380522684 37.728 35.67402860986668 139.73837347282065 37.728 35.67402939364186 139.73837294164767 37.728 35.67403006910432 139.738372222808 37.728 35.67403060022534 139.73837134948468 37.728 35.674030978017335 139.73837035482856 37.728 35.674031175474 139.73836928305872 37.728 35.67403118362518 139.73836818941962 37.728 35.67403101151945 139.73836711808752 37.728 35.67403065919165 139.73836611324953 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cceed3d8-2f4e-4c40-baec-97f6a9c755a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cceed3d8-2f4e-4c40-baec-97f6a9c755a6_0">
											<gml:posList>35.674027762838676 139.73837380522684 37.728 35.67402687055913 139.73837390570463 37.728 35.67402687055913 139.73837390570463 36.144 35.674027762838676 139.73837380522684 36.144 35.674027762838676 139.73837380522684 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ee976bb-0322-4939-9dec-494ad57a525e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ee976bb-0322-4939-9dec-494ad57a525e_0">
											<gml:posList>35.67402860986668 139.73837347282065 37.728 35.674027762838676 139.73837380522684 37.728 35.674027762838676 139.73837380522684 36.144 35.67402860986668 139.73837347282065 36.144 35.67402860986668 139.73837347282065 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c742396-3b59-4b0d-a324-68cb5e120f0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c742396-3b59-4b0d-a324-68cb5e120f0a_0">
											<gml:posList>35.67402939364186 139.73837294164767 37.728 35.67402860986668 139.73837347282065 37.728 35.67402860986668 139.73837347282065 36.144 35.67402939364186 139.73837294164767 36.144 35.67402939364186 139.73837294164767 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7dfb9a0b-4cd7-4835-9f6e-bc995d2bd146">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7dfb9a0b-4cd7-4835-9f6e-bc995d2bd146_0">
											<gml:posList>35.67403006910432 139.738372222808 37.728 35.67402939364186 139.73837294164767 37.728 35.67402939364186 139.73837294164767 36.144 35.67403006910432 139.738372222808 36.144 35.67403006910432 139.738372222808 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2efaf8b3-4701-48a1-a7d7-c05081afc9fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2efaf8b3-4701-48a1-a7d7-c05081afc9fe_0">
											<gml:posList>35.67403369989548 139.73840430935263 37.959 35.67403369989548 139.73840430935263 36.144 35.67402658161105 139.73840755448288 36.144 35.67402658161105 139.73840755448288 37.959 35.67403369989548 139.73840430935263 37.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9997398d-794a-4cc1-950b-d377f83fc95b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9997398d-794a-4cc1-950b-d377f83fc95b_0">
											<gml:posList>35.67402009516104 139.73832048054848 36.573 35.67402009516104 139.73832048054848 36.144 35.67404129639343 139.73839024887388 36.144 35.67404129639343 139.73839024887388 38.202 35.674019082992224 139.7383171456264 38.202 35.674019082992224 139.7383171456264 36.573 35.67402009516104 139.73832048054848 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18b01264-55ad-4937-8dfd-7410fae7de76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18b01264-55ad-4937-8dfd-7410fae7de76_0">
											<gml:posList>35.67403060022534 139.73837134948468 37.728 35.67403006910432 139.738372222808 37.728 35.67403006910432 139.738372222808 36.144 35.67403060022534 139.73837134948468 36.144 35.67403060022534 139.73837134948468 37.728</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb2ade6b-12d4-4596-b71c-1f94d2902dda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb2ade6b-12d4-4596-b71c-1f94d2902dda_0">
											<gml:posList>35.67403369989548 139.73840430935263 37.959 35.67402658161105 139.73840755448288 37.959 35.67403280821512 139.7384280388544 37.959 35.67403991747767 139.73842478268963 37.959 35.67403369989548 139.73840430935263 37.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77ee9067-e523-452a-8faf-f8536227466c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77ee9067-e523-452a-8faf-f8536227466c_0">
											<gml:posList>35.67404129639343 139.73839024887388 38.202 35.674050460059355 139.73838607339079 38.202 35.67402823763319 139.73831295910003 38.202 35.674019082992224 139.7383171456264 38.202 35.67404129639343 139.73839024887388 38.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db3489dd-a97e-4579-86b8-7eba431586a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db3489dd-a97e-4579-86b8-7eba431586a5_0">
											<gml:posList>35.67403991747767 139.73842478268963 37.959 35.67403280821512 139.7384280388544 37.959 35.67403280821512 139.7384280388544 36.144 35.67403991747767 139.73842478268963 36.144 35.67403991747767 139.73842478268963 37.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b8e334f-bf41-4595-aaf6-20aad50f30e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b8e334f-bf41-4595-aaf6-20aad50f30e8_0">
											<gml:posList>35.67404788305974 139.73838724739994 36.144 35.674026627603844 139.73831730238572 36.144 35.674026627603844 139.73831730238572 36.573 35.67404788305974 139.73838724739994 36.573 35.67404788305974 139.73838724739994 36.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1515cdf0-de05-4f24-9faa-51c60ce2d897">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1515cdf0-de05-4f24-9faa-51c60ce2d897_0">
											<gml:posList>35.67402823763319 139.73831295910003 38.202 35.674050460059355 139.73838607339079 38.202 35.674050460059355 139.73838607339079 36.573 35.67402823763319 139.73831295910003 36.573 35.67402823763319 139.73831295910003 38.202</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72bf2fe1-0943-4b92-8e93-f1c68a22eb9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72bf2fe1-0943-4b92-8e93-f1c68a22eb9e_0">
											<gml:posList>35.67403636722405 139.73840337826604 37.959 35.67404425139557 139.7383997787316 37.959 35.67404425139557 139.7383997787316 36.144 35.67403636722405 139.73840337826604 36.144 35.67403636722405 139.73840337826604 37.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41ab24bd-0ab0-4aab-8fd4-a0fe931dd63f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41ab24bd-0ab0-4aab-8fd4-a0fe931dd63f_0">
											<gml:posList>35.674042512505096 139.73842360866044 37.959 35.67405040568222 139.7384199980703 37.959 35.67404425139557 139.7383997787316 37.959 35.67403636722405 139.73840337826604 37.959 35.674042512505096 139.73842360866044 37.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a07ee089-41c4-401f-afa5-b73c3aefc018">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a07ee089-41c4-401f-afa5-b73c3aefc018_0">
											<gml:posList>35.67404788305974 139.73838724739994 36.573 35.674050460059355 139.73838607339079 36.573 35.674050460059355 139.73838607339079 38.202 35.67404129639343 139.73839024887388 38.202 35.67404129639343 139.73839024887388 36.144 35.67404788305974 139.73838724739994 36.144 35.67404788305974 139.73838724739994 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97c9b9e7-7cb7-45e5-a6ab-a6437bccdbbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97c9b9e7-7cb7-45e5-a6ab-a6437bccdbbc_0">
											<gml:posList>35.67405040568222 139.7384199980703 37.959 35.674042512505096 139.73842360866044 37.959 35.674042512505096 139.73842360866044 36.144 35.67405040568222 139.7384199980703 36.144 35.67405040568222 139.7384199980703 37.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a19a30f0-c54b-4ffb-8917-73fd44620aea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a19a30f0-c54b-4ffb-8917-73fd44620aea_0">
											<gml:posList>35.67404425139557 139.7383997787316 37.959 35.67405040568222 139.7384199980703 37.959 35.67405040568222 139.7384199980703 36.144 35.67404425139557 139.7383997787316 36.144 35.67404425139557 139.7383997787316 37.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-34bec188-7a7e-4fc1-8bab-81c0933bc74c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34bec188-7a7e-4fc1-8bab-81c0933bc74c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34bec188-7a7e-4fc1-8bab-81c0933bc74c">
											<gml:posList>35.67397036304003 139.73852199914148 7.83 35.67392192319766 139.7383617681276 7.83 35.674029505751406 139.7383093894928 7.83 35.67408273468113 139.73848452816145 7.83 35.67397036304003 139.73852199914148 7.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43968bfb-c7e9-4936-8cd0-d1110fb673b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43968bfb-c7e9-4936-8cd0-d1110fb673b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43968bfb-c7e9-4936-8cd0-d1110fb673b8">
											<gml:posList>35.67397036304003 139.73852199914148 33.684 35.673975302332295 139.73851026164652 33.684 35.67393207703408 139.73836732365993 33.684 35.67392192319766 139.7383617681276 33.684 35.67397036304003 139.73852199914148 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55a5544a-d42b-40cc-ab71-8888ea3ace49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55a5544a-d42b-40cc-ab71-8888ea3ace49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55a5544a-d42b-40cc-ab71-8888ea3ace49">
											<gml:posList>35.67393207703408 139.73836732365993 33.684 35.673978362930605 139.7383449985714 33.684 35.67397552525932 139.73833566742607 33.684 35.67392192319766 139.7383617681276 33.684 35.67393207703408 139.73836732365993 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2021aafe-5c52-4f63-bb0c-004a05631d86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2021aafe-5c52-4f63-bb0c-004a05631d86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2021aafe-5c52-4f63-bb0c-004a05631d86">
											<gml:posList>35.673975302332295 139.73851026164652 32.897 35.674023467310896 139.7384932699909 32.897 35.673978362930605 139.7383449985714 32.897 35.67393207703408 139.73836732365993 32.897 35.673975302332295 139.73851026164652 32.897</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b0c3748e-5f93-4d72-8c38-146e29a4fa1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0c3748e-5f93-4d72-8c38-146e29a4fa1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0c3748e-5f93-4d72-8c38-146e29a4fa1e">
											<gml:posList>35.673975302332295 139.73851026164652 33.684 35.67397036304003 139.73852199914148 33.684 35.674026512816155 139.73850327475404 33.684 35.674023467310896 139.7384932699909 33.684 35.673975302332295 139.73851026164652 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed53f25d-4ca1-40b7-aa58-66d476d913e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed53f25d-4ca1-40b7-aa58-66d476d913e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed53f25d-4ca1-40b7-aa58-66d476d913e9">
											<gml:posList>35.674026512816155 139.73850327475404 36.573 35.67402956271513 139.73849596923654 36.573 35.67398183758895 139.73833911758044 36.573 35.67397552525932 139.73833566742607 36.573 35.674026512816155 139.73850327475404 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f28c503c-f829-4867-98ea-4d455781feea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f28c503c-f829-4867-98ea-4d455781feea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f28c503c-f829-4867-98ea-4d455781feea">
											<gml:posList>35.67397552525932 139.73833566742607 36.573 35.67398183758895 139.73833911758044 36.573 35.674026627603844 139.73831730238572 36.573 35.674029505751406 139.7383093894928 36.573 35.67397552525932 139.73833566742607 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2bafc24-0296-4fe1-9296-a9486bbee544">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2bafc24-0296-4fe1-9296-a9486bbee544">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2bafc24-0296-4fe1-9296-a9486bbee544">
											<gml:posList>35.67402956271513 139.73849596923654 36.144 35.674076205513124 139.73848042648854 36.144 35.674026627603844 139.73831730238572 36.144 35.67398183758895 139.73833911758044 36.144 35.67402956271513 139.73849596923654 36.144</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d030f9c1-12fb-447d-805b-e1b95f232f1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d030f9c1-12fb-447d-805b-e1b95f232f1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d030f9c1-12fb-447d-805b-e1b95f232f1f">
											<gml:posList>35.674026512816155 139.73850327475404 36.573 35.67408273468113 139.73848452816145 36.573 35.674076205513124 139.73848042648854 36.573 35.67402956271513 139.73849596923654 36.573 35.674026512816155 139.73850327475404 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3210316d-edf8-4800-859f-9da96f8e4742">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3210316d-edf8-4800-859f-9da96f8e4742">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3210316d-edf8-4800-859f-9da96f8e4742">
											<gml:posList>35.674029505751406 139.7383093894928 36.573 35.674026627603844 139.73831730238572 36.573 35.674076205513124 139.73848042648854 36.573 35.67408273468113 139.73848452816145 36.573 35.674029505751406 139.7383093894928 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-797bfb07-e2d6-46c8-84c4-db52daaf6d90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-797bfb07-e2d6-46c8-84c4-db52daaf6d90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-797bfb07-e2d6-46c8-84c4-db52daaf6d90">
											<gml:posList>35.67402956271513 139.73849596923654 36.573 35.67402956271513 139.73849596923654 36.144 35.67398183758895 139.73833911758044 36.144 35.67398183758895 139.73833911758044 36.573 35.67402956271513 139.73849596923654 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b26862e1-3c9d-4522-8de8-7c02fd67d7e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b26862e1-3c9d-4522-8de8-7c02fd67d7e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b26862e1-3c9d-4522-8de8-7c02fd67d7e1">
											<gml:posList>35.674026627603844 139.73831730238572 36.573 35.674026627603844 139.73831730238572 36.144 35.674076205513124 139.73848042648854 36.144 35.674076205513124 139.73848042648854 36.573 35.674026627603844 139.73831730238572 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da20153a-98b6-4fe6-a86d-290b800c89fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da20153a-98b6-4fe6-a86d-290b800c89fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da20153a-98b6-4fe6-a86d-290b800c89fb">
											<gml:posList>35.67398183758895 139.73833911758044 36.573 35.67398183758895 139.73833911758044 36.144 35.674026627603844 139.73831730238572 36.144 35.674026627603844 139.73831730238572 36.573 35.67398183758895 139.73833911758044 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-505fe057-eae5-4c99-90af-d78ffcda9204">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-505fe057-eae5-4c99-90af-d78ffcda9204">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-505fe057-eae5-4c99-90af-d78ffcda9204">
											<gml:posList>35.67392192319766 139.7383617681276 7.83 35.67392192319766 139.7383617681276 33.684 35.67397552525932 139.73833566742607 33.684 35.67397552525932 139.73833566742607 36.573 35.674029505751406 139.7383093894928 36.573 35.674029505751406 139.7383093894928 7.83 35.67392192319766 139.7383617681276 7.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-06fb1cf0-17b6-46c3-9b40-31f6485b334d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06fb1cf0-17b6-46c3-9b40-31f6485b334d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06fb1cf0-17b6-46c3-9b40-31f6485b334d">
											<gml:posList>35.67393207703408 139.73836732365993 33.684 35.67393207703408 139.73836732365993 32.897 35.673978362930605 139.7383449985714 32.897 35.673978362930605 139.7383449985714 33.684 35.67393207703408 139.73836732365993 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15d5e258-3e84-4eac-8b4e-6781a6816811">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15d5e258-3e84-4eac-8b4e-6781a6816811">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15d5e258-3e84-4eac-8b4e-6781a6816811">
											<gml:posList>35.67408273468113 139.73848452816145 7.83 35.674029505751406 139.7383093894928 7.83 35.674029505751406 139.7383093894928 36.573 35.67408273468113 139.73848452816145 36.573 35.67408273468113 139.73848452816145 7.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-67577345-4443-4083-8b27-a05177c156ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67577345-4443-4083-8b27-a05177c156ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67577345-4443-4083-8b27-a05177c156ee">
											<gml:posList>35.673978362930605 139.7383449985714 33.684 35.673978362930605 139.7383449985714 32.897 35.674023467310896 139.7384932699909 32.897 35.674023467310896 139.7384932699909 33.684 35.674026512816155 139.73850327475404 33.684 35.674026512816155 139.73850327475404 36.573 35.67397552525932 139.73833566742607 36.573 35.67397552525932 139.73833566742607 33.684 35.673978362930605 139.7383449985714 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36a17244-af8f-49df-ad12-d313342da47e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36a17244-af8f-49df-ad12-d313342da47e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36a17244-af8f-49df-ad12-d313342da47e">
											<gml:posList>35.673975302332295 139.73851026164652 33.684 35.673975302332295 139.73851026164652 32.897 35.67393207703408 139.73836732365993 32.897 35.67393207703408 139.73836732365993 33.684 35.673975302332295 139.73851026164652 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e482e0ea-0a63-4427-bc3c-8fb85aa64d8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e482e0ea-0a63-4427-bc3c-8fb85aa64d8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e482e0ea-0a63-4427-bc3c-8fb85aa64d8a">
											<gml:posList>35.67392192319766 139.7383617681276 7.83 35.67397036304003 139.73852199914148 7.83 35.67397036304003 139.73852199914148 33.684 35.67392192319766 139.7383617681276 33.684 35.67392192319766 139.7383617681276 7.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a35792cc-d8c7-4f19-ba8c-72e578cfaa81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a35792cc-d8c7-4f19-ba8c-72e578cfaa81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a35792cc-d8c7-4f19-ba8c-72e578cfaa81">
											<gml:posList>35.674076205513124 139.73848042648854 36.573 35.674076205513124 139.73848042648854 36.144 35.67402956271513 139.73849596923654 36.144 35.67402956271513 139.73849596923654 36.573 35.674076205513124 139.73848042648854 36.573</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d134b3cb-6f64-4b49-8120-f1a76cb71900">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d134b3cb-6f64-4b49-8120-f1a76cb71900">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d134b3cb-6f64-4b49-8120-f1a76cb71900">
											<gml:posList>35.674023467310896 139.7384932699909 33.684 35.674023467310896 139.7384932699909 32.897 35.673975302332295 139.73851026164652 32.897 35.673975302332295 139.73851026164652 33.684 35.674023467310896 139.7384932699909 33.684</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-20376d9e-6899-42e7-bb7d-c973647e1faa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20376d9e-6899-42e7-bb7d-c973647e1faa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20376d9e-6899-42e7-bb7d-c973647e1faa">
											<gml:posList>35.67408273468113 139.73848452816145 7.83 35.67408273468113 139.73848452816145 36.573 35.674026512816155 139.73850327475404 36.573 35.674026512816155 139.73850327475404 33.684 35.67397036304003 139.73852199914148 33.684 35.67397036304003 139.73852199914148 7.83 35.67408273468113 139.73848452816145 7.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2420</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">208.1423</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.37</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>