<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_3eded0bd-be1b-47eb-bd60-c3e844952c55">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">8.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668466403780535 139.73818442488607 0 35.66847190555668 139.738188726296 0 35.66845732461501 139.7382156958237 0 35.66848744964973 139.73823996128436 0 35.66851850110314 139.7381818224844 0 35.668524814638275 139.7381867856939 0 35.66854524567614 139.7381486527279 0 35.66853974381125 139.73814424085685 0 35.66855486468669 139.7381161660465 0 35.66851923531406 139.73808439586816 0 35.668466403780535 139.73818442488607 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668466403780535 139.73818442488607 23.59 35.66851923531406 139.73808439586816 23.59 35.66855486468669 139.7381161660465 23.59 35.66853974381125 139.73814424085685 23.59 35.66854524567614 139.7381486527279 23.59 35.668524814638275 139.7381867856939 23.59 35.66851850110314 139.7381818224844 23.59 35.66848744964973 139.73823996128436 23.59 35.66845732461501 139.7382156958237 23.59 35.66847190555668 139.738188726296 23.59 35.668466403780535 139.73818442488607 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668466403780535 139.73818442488607 23.59 35.66847190555668 139.738188726296 23.59 35.66847190555668 139.738188726296 32.26 35.668466403780535 139.73818442488607 32.26 35.668466403780535 139.73818442488607 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66847190555668 139.738188726296 23.59 35.66845732461501 139.7382156958237 23.59 35.66845732461501 139.7382156958237 32.26 35.66847190555668 139.738188726296 32.26 35.66847190555668 139.738188726296 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845732461501 139.7382156958237 23.59 35.66848744964973 139.73823996128436 23.59 35.66848744964973 139.73823996128436 32.26 35.66845732461501 139.7382156958237 32.26 35.66845732461501 139.7382156958237 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66848744964973 139.73823996128436 23.59 35.66851850110314 139.7381818224844 23.59 35.66851850110314 139.7381818224844 32.26 35.66848744964973 139.73823996128436 32.26 35.66848744964973 139.73823996128436 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851850110314 139.7381818224844 23.59 35.668524814638275 139.7381867856939 23.59 35.668524814638275 139.7381867856939 32.26 35.66851850110314 139.7381818224844 32.26 35.66851850110314 139.7381818224844 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668524814638275 139.7381867856939 23.59 35.66854524567614 139.7381486527279 23.59 35.66854524567614 139.7381486527279 32.26 35.668524814638275 139.7381867856939 32.26 35.668524814638275 139.7381867856939 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66854524567614 139.7381486527279 23.59 35.66853974381125 139.73814424085685 23.59 35.66853974381125 139.73814424085685 32.26 35.66854524567614 139.7381486527279 32.26 35.66854524567614 139.7381486527279 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853974381125 139.73814424085685 23.59 35.66855486468669 139.7381161660465 23.59 35.66855486468669 139.7381161660465 32.26 35.66853974381125 139.73814424085685 32.26 35.66853974381125 139.73814424085685 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66855486468669 139.7381161660465 23.59 35.66851923531406 139.73808439586816 23.59 35.66851923531406 139.73808439586816 32.26 35.66855486468669 139.7381161660465 32.26 35.66855486468669 139.7381161660465 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66851923531406 139.73808439586816 23.59 35.668466403780535 139.73818442488607 23.59 35.668466403780535 139.73818442488607 32.26 35.66851923531406 139.73808439586816 32.26 35.66851923531406 139.73808439586816 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668466403780535 139.73818442488607 32.26 35.66847190555668 139.738188726296 32.26 35.66845732461501 139.7382156958237 32.26 35.66848744964973 139.73823996128436 32.26 35.66851850110314 139.7381818224844 32.26 35.668524814638275 139.7381867856939 32.26 35.66854524567614 139.7381486527279 32.26 35.66853974381125 139.73814424085685 32.26 35.66855486468669 139.7381161660465 32.26 35.66851923531406 139.73808439586816 32.26 35.668466403780535 139.73818442488607 32.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ad68bd75-23d1-4fbc-8949-307ec33c14b7"/>
							<gml:surfaceMember xlink:href="#poly-a23a5cef-5a3a-4b33-8cd7-4b09d9b68d49"/>
							<gml:surfaceMember xlink:href="#poly-d0b9b25b-98da-4325-8e56-58a425f3edc6"/>
							<gml:surfaceMember xlink:href="#poly-4135ad16-4a5f-4c89-8400-aaff97c0b187"/>
							<gml:surfaceMember xlink:href="#poly-591383a2-4f7a-463e-8d36-e48220f4ee44"/>
							<gml:surfaceMember xlink:href="#poly-1c8d5ca0-c44a-4166-b4a3-9a0376343238"/>
							<gml:surfaceMember xlink:href="#poly-615c3979-d0b5-4508-96a8-6387fd748dd3"/>
							<gml:surfaceMember xlink:href="#poly-f47e20e8-8ae8-4ef1-9413-7d35cb26fac0"/>
							<gml:surfaceMember xlink:href="#poly-25c68512-394e-4592-bcac-a39807e97198"/>
							<gml:surfaceMember xlink:href="#poly-0fb135ca-3433-4dc4-9472-635b84ac16da"/>
							<gml:surfaceMember xlink:href="#poly-45413e42-bdc7-4243-aaf5-f34f1563ccee"/>
							<gml:surfaceMember xlink:href="#poly-5f8d25e2-ff9a-48fc-bc27-e39b99317353"/>
							<gml:surfaceMember xlink:href="#poly-f4e0852a-b7f8-4ffc-98b3-530238ac5883"/>
							<gml:surfaceMember xlink:href="#poly-ec1e7943-c3a8-44c1-880e-03bdf54db1a5"/>
							<gml:surfaceMember xlink:href="#poly-ac5efd81-27b7-4c8d-86cb-2b2289ea3518"/>
							<gml:surfaceMember xlink:href="#poly-1772c8a9-f575-46e3-ae50-cd6b93e6e660"/>
							<gml:surfaceMember xlink:href="#poly-0c4cfcb5-095e-4871-a986-5bc26008cf09"/>
							<gml:surfaceMember xlink:href="#poly-d969ca0b-00cd-4f71-8113-977d2b1a95fb"/>
							<gml:surfaceMember xlink:href="#poly-a3bd97c6-bfaf-432b-8d22-62318e56b7b2"/>
							<gml:surfaceMember xlink:href="#poly-74472f25-0465-46fd-86df-96c2e3b9c354"/>
							<gml:surfaceMember xlink:href="#poly-3892805a-c2b7-495d-bfb0-a7ebcd628e59"/>
							<gml:surfaceMember xlink:href="#poly-52407f56-94bf-45e3-a927-ab4e7132ff9d"/>
							<gml:surfaceMember xlink:href="#poly-57b95d8a-e99a-4ec5-bcbb-c94cac82a604"/>
							<gml:surfaceMember xlink:href="#poly-b99526c3-1ff2-4d66-a7fd-850c322816a2"/>
							<gml:surfaceMember xlink:href="#poly-663181ca-d477-4c1e-955c-6f10e1050754"/>
							<gml:surfaceMember xlink:href="#poly-3b78cffd-740d-44c0-9cd5-5ab869bf3a10"/>
							<gml:surfaceMember xlink:href="#poly-21319fd5-a719-49d2-b5c7-20c65e9b2389"/>
							<gml:surfaceMember xlink:href="#poly-0bc11ff0-5903-4cc9-899f-00b2d1e3f4bf"/>
							<gml:surfaceMember xlink:href="#poly-061be6bf-6f10-4617-8c84-467980f9cc19"/>
							<gml:surfaceMember xlink:href="#poly-59b2c9ea-c1d7-44b9-ab60-38f950e51eb2"/>
							<gml:surfaceMember xlink:href="#poly-f87e9296-16f6-4f04-b7b5-53298870ad11"/>
							<gml:surfaceMember xlink:href="#poly-400cec35-2cec-4841-bd6f-bdaf6301dd30"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ad68bd75-23d1-4fbc-8949-307ec33c14b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad68bd75-23d1-4fbc-8949-307ec33c14b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad68bd75-23d1-4fbc-8949-307ec33c14b7">
											<gml:posList>35.66851923531406 139.73808439586816 23.59 35.6685548646867 139.73811616604647 23.59 35.66853974381126 139.73814424085685 23.59 35.66854524567611 139.7381486527279 23.59 35.66852481463827 139.73818678569387 23.59 35.66851850110314 139.7381818224844 23.59 35.668487449649724 139.73823996128436 23.59 35.66845732461501 139.7382156958237 23.59 35.668471905556665 139.73818872629596 23.59 35.66846640378052 139.73818442488604 23.59 35.66851923531406 139.73808439586816 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a23a5cef-5a3a-4b33-8cd7-4b09d9b68d49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a23a5cef-5a3a-4b33-8cd7-4b09d9b68d49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a23a5cef-5a3a-4b33-8cd7-4b09d9b68d49">
											<gml:posList>35.668471905556665 139.73818872629596 32.442 35.66845732461501 139.7382156958237 32.442 35.668460037205264 139.7382150077542 32.442 35.66847353807949 139.7381900388324 32.442 35.668471905556665 139.73818872629596 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0b9b25b-98da-4325-8e56-58a425f3edc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0b9b25b-98da-4325-8e56-58a425f3edc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0b9b25b-98da-4325-8e56-58a425f3edc6">
											<gml:posList>35.668487449649724 139.73823996128436 32.442 35.66848688817308 139.7382366371047 32.442 35.668460037205264 139.7382150077542 32.442 35.66845732461501 139.7382156958237 32.442 35.668487449649724 139.73823996128436 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4135ad16-4a5f-4c89-8400-aaff97c0b187">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4135ad16-4a5f-4c89-8400-aaff97c0b187">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4135ad16-4a5f-4c89-8400-aaff97c0b187">
											<gml:posList>35.66846640378052 139.73818442488604 30.661 35.668471905556665 139.73818872629596 32.442 35.668528796616116 139.73809292307155 32.442 35.66846640378052 139.73818442488604 30.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-591383a2-4f7a-463e-8d36-e48220f4ee44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-591383a2-4f7a-463e-8d36-e48220f4ee44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-591383a2-4f7a-463e-8d36-e48220f4ee44">
											<gml:posList>35.668528796616116 139.73809292307155 32.442 35.66851923531406 139.73808439586816 30.661 35.66846640378052 139.73818442488604 30.661 35.668528796616116 139.73809292307155 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1c8d5ca0-c44a-4166-b4a3-9a0376343238">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c8d5ca0-c44a-4166-b4a3-9a0376343238">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c8d5ca0-c44a-4166-b4a3-9a0376343238">
											<gml:posList>35.668471905556665 139.73818872629596 32.442 35.66847353807949 139.7381900388324 32.442 35.6685292138946 139.73809626951518 32.442 35.668528796616116 139.73809292307155 32.442 35.668471905556665 139.73818872629596 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-615c3979-d0b5-4508-96a8-6387fd748dd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-615c3979-d0b5-4508-96a8-6387fd748dd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-615c3979-d0b5-4508-96a8-6387fd748dd3">
											<gml:posList>35.66851850110314 139.7381818224844 32.442 35.66851791259244 139.73817850938195 32.442 35.66848688817308 139.7382366371047 32.442 35.668487449649724 139.73823996128436 32.442 35.66851850110314 139.7381818224844 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f47e20e8-8ae8-4ef1-9413-7d35cb26fac0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f47e20e8-8ae8-4ef1-9413-7d35cb26fac0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f47e20e8-8ae8-4ef1-9413-7d35cb26fac0">
											<gml:posList>35.66847353807949 139.7381900388324 32.083 35.668460037205264 139.7382150077542 32.083 35.66848688817308 139.7382366371047 32.083 35.66851791259244 139.73817850938195 32.083 35.66852423515016 139.73818348362644 32.083 35.668542533086274 139.73814934080036 32.083 35.66853702220773 139.73814492894013 32.083 35.668552197087074 139.73811675465265 32.083 35.6685292138946 139.73809626951518 32.083 35.66847353807949 139.7381900388324 32.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-25c68512-394e-4592-bcac-a39807e97198">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25c68512-394e-4592-bcac-a39807e97198">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25c68512-394e-4592-bcac-a39807e97198">
											<gml:posList>35.66851850110314 139.7381818224844 32.442 35.66852481463827 139.73818678569387 32.442 35.66852423515016 139.73818348362644 32.442 35.66851791259244 139.73817850938195 32.442 35.66851850110314 139.7381818224844 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fb135ca-3433-4dc4-9472-635b84ac16da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fb135ca-3433-4dc4-9472-635b84ac16da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fb135ca-3433-4dc4-9472-635b84ac16da">
											<gml:posList>35.66854524567611 139.7381486527279 32.442 35.668542533086274 139.73814934080036 32.442 35.66852423515016 139.73818348362644 32.442 35.66852481463827 139.73818678569387 32.442 35.66854524567611 139.7381486527279 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45413e42-bdc7-4243-aaf5-f34f1563ccee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45413e42-bdc7-4243-aaf5-f34f1563ccee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45413e42-bdc7-4243-aaf5-f34f1563ccee">
											<gml:posList>35.66853974381126 139.73814424085685 32.442 35.66853702220773 139.73814492894013 32.442 35.668542533086274 139.73814934080036 32.442 35.66854524567611 139.7381486527279 32.442 35.66853974381126 139.73814424085685 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f8d25e2-ff9a-48fc-bc27-e39b99317353">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f8d25e2-ff9a-48fc-bc27-e39b99317353">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f8d25e2-ff9a-48fc-bc27-e39b99317353">
											<gml:posList>35.668528796616116 139.73809292307155 32.442 35.6685292138946 139.73809626951518 32.442 35.668552197087074 139.73811675465265 32.442 35.6685548646867 139.73811616604647 32.442 35.668528796616116 139.73809292307155 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4e0852a-b7f8-4ffc-98b3-530238ac5883">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4e0852a-b7f8-4ffc-98b3-530238ac5883">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4e0852a-b7f8-4ffc-98b3-530238ac5883">
											<gml:posList>35.66853974381126 139.73814424085685 32.442 35.6685548646867 139.73811616604647 32.442 35.668552197087074 139.73811675465265 32.442 35.66853702220773 139.73814492894013 32.442 35.66853974381126 139.73814424085685 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec1e7943-c3a8-44c1-880e-03bdf54db1a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec1e7943-c3a8-44c1-880e-03bdf54db1a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec1e7943-c3a8-44c1-880e-03bdf54db1a5">
											<gml:posList>35.66851923531406 139.73808439586816 30.661 35.668528796616116 139.73809292307155 32.442 35.6685548646867 139.73811616604647 32.442 35.6685548646867 139.73811616604647 23.59 35.66851923531406 139.73808439586816 23.59 35.66851923531406 139.73808439586816 30.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac5efd81-27b7-4c8d-86cb-2b2289ea3518">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac5efd81-27b7-4c8d-86cb-2b2289ea3518">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac5efd81-27b7-4c8d-86cb-2b2289ea3518">
											<gml:posList>35.6685292138946 139.73809626951518 32.442 35.6685292138946 139.73809626951518 32.083 35.668552197087074 139.73811675465265 32.083 35.668552197087074 139.73811675465265 32.442 35.6685292138946 139.73809626951518 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1772c8a9-f575-46e3-ae50-cd6b93e6e660">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1772c8a9-f575-46e3-ae50-cd6b93e6e660">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1772c8a9-f575-46e3-ae50-cd6b93e6e660">
											<gml:posList>35.66853974381126 139.73814424085685 23.59 35.6685548646867 139.73811616604647 23.59 35.6685548646867 139.73811616604647 32.442 35.66853974381126 139.73814424085685 32.442 35.66853974381126 139.73814424085685 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c4cfcb5-095e-4871-a986-5bc26008cf09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c4cfcb5-095e-4871-a986-5bc26008cf09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c4cfcb5-095e-4871-a986-5bc26008cf09">
											<gml:posList>35.668552197087074 139.73811675465265 32.442 35.668552197087074 139.73811675465265 32.083 35.66853702220773 139.73814492894013 32.083 35.66853702220773 139.73814492894013 32.442 35.668552197087074 139.73811675465265 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d969ca0b-00cd-4f71-8113-977d2b1a95fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d969ca0b-00cd-4f71-8113-977d2b1a95fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d969ca0b-00cd-4f71-8113-977d2b1a95fb">
											<gml:posList>35.66851923531406 139.73808439586816 23.59 35.66846640378052 139.73818442488604 23.59 35.66846640378052 139.73818442488604 30.661 35.66851923531406 139.73808439586816 30.661 35.66851923531406 139.73808439586816 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3bd97c6-bfaf-432b-8d22-62318e56b7b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3bd97c6-bfaf-432b-8d22-62318e56b7b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3bd97c6-bfaf-432b-8d22-62318e56b7b2">
											<gml:posList>35.66847353807949 139.7381900388324 32.442 35.66847353807949 139.7381900388324 32.083 35.6685292138946 139.73809626951518 32.083 35.6685292138946 139.73809626951518 32.442 35.66847353807949 139.7381900388324 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74472f25-0465-46fd-86df-96c2e3b9c354">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74472f25-0465-46fd-86df-96c2e3b9c354">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74472f25-0465-46fd-86df-96c2e3b9c354">
											<gml:posList>35.66854524567611 139.7381486527279 23.59 35.66853974381126 139.73814424085685 23.59 35.66853974381126 139.73814424085685 32.442 35.66854524567611 139.7381486527279 32.442 35.66854524567611 139.7381486527279 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3892805a-c2b7-495d-bfb0-a7ebcd628e59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3892805a-c2b7-495d-bfb0-a7ebcd628e59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3892805a-c2b7-495d-bfb0-a7ebcd628e59">
											<gml:posList>35.66853702220773 139.73814492894013 32.442 35.66853702220773 139.73814492894013 32.083 35.668542533086274 139.73814934080036 32.083 35.668542533086274 139.73814934080036 32.442 35.66853702220773 139.73814492894013 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52407f56-94bf-45e3-a927-ab4e7132ff9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52407f56-94bf-45e3-a927-ab4e7132ff9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52407f56-94bf-45e3-a927-ab4e7132ff9d">
											<gml:posList>35.668542533086274 139.73814934080036 32.442 35.668542533086274 139.73814934080036 32.083 35.66852423515016 139.73818348362644 32.083 35.66852423515016 139.73818348362644 32.442 35.668542533086274 139.73814934080036 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-57b95d8a-e99a-4ec5-bcbb-c94cac82a604">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-57b95d8a-e99a-4ec5-bcbb-c94cac82a604">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-57b95d8a-e99a-4ec5-bcbb-c94cac82a604">
											<gml:posList>35.66852481463827 139.73818678569387 23.59 35.66854524567611 139.7381486527279 23.59 35.66854524567611 139.7381486527279 32.442 35.66852481463827 139.73818678569387 32.442 35.66852481463827 139.73818678569387 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b99526c3-1ff2-4d66-a7fd-850c322816a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b99526c3-1ff2-4d66-a7fd-850c322816a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b99526c3-1ff2-4d66-a7fd-850c322816a2">
											<gml:posList>35.66852423515016 139.73818348362644 32.442 35.66852423515016 139.73818348362644 32.083 35.66851791259244 139.73817850938195 32.083 35.66851791259244 139.73817850938195 32.442 35.66852423515016 139.73818348362644 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-663181ca-d477-4c1e-955c-6f10e1050754">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-663181ca-d477-4c1e-955c-6f10e1050754">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-663181ca-d477-4c1e-955c-6f10e1050754">
											<gml:posList>35.66851850110314 139.7381818224844 23.59 35.66852481463827 139.73818678569387 23.59 35.66852481463827 139.73818678569387 32.442 35.66851850110314 139.7381818224844 32.442 35.66851850110314 139.7381818224844 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b78cffd-740d-44c0-9cd5-5ab869bf3a10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b78cffd-740d-44c0-9cd5-5ab869bf3a10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b78cffd-740d-44c0-9cd5-5ab869bf3a10">
											<gml:posList>35.66846640378052 139.73818442488604 30.661 35.66846640378052 139.73818442488604 23.59 35.668471905556665 139.73818872629596 23.59 35.668471905556665 139.73818872629596 32.442 35.66846640378052 139.73818442488604 30.661</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21319fd5-a719-49d2-b5c7-20c65e9b2389">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21319fd5-a719-49d2-b5c7-20c65e9b2389">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21319fd5-a719-49d2-b5c7-20c65e9b2389">
											<gml:posList>35.668471905556665 139.73818872629596 32.442 35.668471905556665 139.73818872629596 23.59 35.66845732461501 139.7382156958237 23.59 35.66845732461501 139.7382156958237 32.442 35.668471905556665 139.73818872629596 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0bc11ff0-5903-4cc9-899f-00b2d1e3f4bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bc11ff0-5903-4cc9-899f-00b2d1e3f4bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bc11ff0-5903-4cc9-899f-00b2d1e3f4bf">
											<gml:posList>35.668460037205264 139.7382150077542 32.442 35.668460037205264 139.7382150077542 32.083 35.66847353807949 139.7381900388324 32.083 35.66847353807949 139.7381900388324 32.442 35.668460037205264 139.7382150077542 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-061be6bf-6f10-4617-8c84-467980f9cc19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-061be6bf-6f10-4617-8c84-467980f9cc19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-061be6bf-6f10-4617-8c84-467980f9cc19">
											<gml:posList>35.66851791259244 139.73817850938195 32.442 35.66851791259244 139.73817850938195 32.083 35.66848688817308 139.7382366371047 32.083 35.66848688817308 139.7382366371047 32.442 35.66851791259244 139.73817850938195 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59b2c9ea-c1d7-44b9-ab60-38f950e51eb2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59b2c9ea-c1d7-44b9-ab60-38f950e51eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59b2c9ea-c1d7-44b9-ab60-38f950e51eb2">
											<gml:posList>35.668487449649724 139.73823996128436 23.59 35.66851850110314 139.7381818224844 23.59 35.66851850110314 139.7381818224844 32.442 35.668487449649724 139.73823996128436 32.442 35.668487449649724 139.73823996128436 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f87e9296-16f6-4f04-b7b5-53298870ad11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f87e9296-16f6-4f04-b7b5-53298870ad11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f87e9296-16f6-4f04-b7b5-53298870ad11">
											<gml:posList>35.66848688817308 139.7382366371047 32.442 35.66848688817308 139.7382366371047 32.083 35.668460037205264 139.7382150077542 32.083 35.668460037205264 139.7382150077542 32.442 35.66848688817308 139.7382366371047 32.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-400cec35-2cec-4841-bd6f-bdaf6301dd30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-400cec35-2cec-4841-bd6f-bdaf6301dd30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-400cec35-2cec-4841-bd6f-bdaf6301dd30">
											<gml:posList>35.66845732461501 139.7382156958237 23.59 35.668487449649724 139.73823996128436 23.59 35.668487449649724 139.73823996128436 32.442 35.66845732461501 139.7382156958237 32.442 35.66845732461501 139.7382156958237 23.59</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8610</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">65.97865</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>