<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_407d25d9-fa8f-48b4-826e-b47efb08f7ec">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">25</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66927686962989 139.7476633100675 0 35.669290163547934 139.74762343045262 0 35.6693143921645 139.7476356767851 0 35.669326624970395 139.7475993330384 0 35.66923789820264 139.74755491211607 0 35.669212443392055 139.74763082604977 0 35.66927686962989 139.7476633100675 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927686962989 139.7476633100675 6.04 35.669212443392055 139.74763082604977 6.04 35.66923789820264 139.74755491211607 6.04 35.669326624970395 139.7475993330384 6.04 35.6693143921645 139.7476356767851 6.04 35.669290163547934 139.74762343045262 6.04 35.66927686962989 139.7476633100675 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927686962989 139.7476633100675 6.04 35.669290163547934 139.74762343045262 6.04 35.669290163547934 139.74762343045262 31.01 35.66927686962989 139.7476633100675 31.01 35.66927686962989 139.7476633100675 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669290163547934 139.74762343045262 6.04 35.6693143921645 139.7476356767851 6.04 35.6693143921645 139.7476356767851 31.01 35.669290163547934 139.74762343045262 31.01 35.669290163547934 139.74762343045262 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6693143921645 139.7476356767851 6.04 35.669326624970395 139.7475993330384 6.04 35.669326624970395 139.7475993330384 31.01 35.6693143921645 139.7476356767851 31.01 35.6693143921645 139.7476356767851 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669326624970395 139.7475993330384 6.04 35.66923789820264 139.74755491211607 6.04 35.66923789820264 139.74755491211607 31.01 35.669326624970395 139.7475993330384 31.01 35.669326624970395 139.7475993330384 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923789820264 139.74755491211607 6.04 35.669212443392055 139.74763082604977 6.04 35.669212443392055 139.74763082604977 31.01 35.66923789820264 139.74755491211607 31.01 35.66923789820264 139.74755491211607 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669212443392055 139.74763082604977 6.04 35.66927686962989 139.7476633100675 6.04 35.66927686962989 139.7476633100675 31.01 35.669212443392055 139.74763082604977 31.01 35.669212443392055 139.74763082604977 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66927686962989 139.7476633100675 31.01 35.669290163547934 139.74762343045262 31.01 35.6693143921645 139.7476356767851 31.01 35.669326624970395 139.7475993330384 31.01 35.66923789820264 139.74755491211607 31.01 35.669212443392055 139.74763082604977 31.01 35.66927686962989 139.7476633100675 31.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9c3e978b-3348-4fa0-9cb7-362f0af151d2"/>
							<gml:surfaceMember xlink:href="#poly-11a58080-5df9-406a-993b-d9bada73e438"/>
							<gml:surfaceMember xlink:href="#poly-708d5b15-97b8-41e0-9305-746e036ae2a4"/>
							<gml:surfaceMember xlink:href="#poly-5b9afc96-7664-435f-997f-649736617e9a"/>
							<gml:surfaceMember xlink:href="#poly-ed48e154-4d7d-47ec-b91d-02845d4cda08"/>
							<gml:surfaceMember xlink:href="#poly-a4a9386a-deb0-4a6b-855a-005da4197eb8"/>
							<gml:surfaceMember xlink:href="#poly-7acc5c98-44c5-4ba3-88b3-d27bdad69c39"/>
							<gml:surfaceMember xlink:href="#poly-1bd463af-beec-42a1-a8be-672576876f2d"/>
							<gml:surfaceMember xlink:href="#poly-0a597ac3-e0fe-418f-83aa-8efa9b2b6e49"/>
							<gml:surfaceMember xlink:href="#poly-cd220ab0-1340-47b7-8b37-be440de6b6d5"/>
							<gml:surfaceMember xlink:href="#poly-3e53b151-d9d5-4045-8957-a17b698ba02b"/>
							<gml:surfaceMember xlink:href="#poly-2432bd0e-3855-4e80-9c68-d004060154bb"/>
							<gml:surfaceMember xlink:href="#poly-a73ba591-d710-46df-9253-4b858e744b5f"/>
							<gml:surfaceMember xlink:href="#poly-cdf2a5d2-cf53-49d3-834d-ff2df577f16a"/>
							<gml:surfaceMember xlink:href="#poly-9e18acfb-3c4a-4ce0-adab-e67f099e72e3"/>
							<gml:surfaceMember xlink:href="#poly-1fd37fbf-6421-4bf2-8fa9-7fad631b4977"/>
							<gml:surfaceMember xlink:href="#poly-d5974c99-a4ef-457e-bc6f-c97698258889"/>
							<gml:surfaceMember xlink:href="#poly-cbb68a87-5933-40bd-9cbe-d619677d676b"/>
							<gml:surfaceMember xlink:href="#poly-2b39e734-f32d-45d4-89aa-ee59b8d26714"/>
							<gml:surfaceMember xlink:href="#poly-afa867bb-09e6-446b-9db3-39dccd8a26e8"/>
							<gml:surfaceMember xlink:href="#poly-47d050aa-de16-4672-a5bb-e5e8b0a5f2ab"/>
							<gml:surfaceMember xlink:href="#poly-eb895125-b897-491d-884c-82b5c13687a1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_407d25d9-fa8f-48b4-826e-b47efb08f7ec_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-857a51a5-89fc-4f3b-a141-495d6a2afe13">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669281542137206 139.7476300783799 35.236 35.669277044872764 139.747643570485 35.236 35.669266026161125 139.74763804816135 35.236 35.66927052342497 139.74762455605781 35.236 35.669281542137206 139.7476300783799 35.236</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-401d8705-c1b9-43eb-bb79-3b4e864f45b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-401d8705-c1b9-43eb-bb79-3b4e864f45b6_0">
											<gml:posList>35.669294291270916 139.74760997187764 33.55 35.669294291270916 139.74760997187764 31.927 35.669284778392665 139.7476052101289 33.55 35.669294291270916 139.74760997187764 33.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd971dd8-b202-45fd-866d-4bf74df54563">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd971dd8-b202-45fd-866d-4bf74df54563_0">
											<gml:posList>35.66928014266191 139.7476141182489 33.55 35.66928450853923 139.74760599469118 33.55 35.669284778392665 139.7476052101289 33.55 35.669294291270916 139.74760997187764 31.927 35.66929108021963 139.74761959647253 31.659 35.66928014266191 139.7476141182489 33.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68420461-fe0e-4fdc-a149-b82651fc2ddc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68420461-fe0e-4fdc-a149-b82651fc2ddc_0">
											<gml:posList>35.66929108021963 139.74761959647253 33.55 35.669294291270916 139.74760997187764 33.55 35.669284778392665 139.7476052101289 33.55 35.66928450853923 139.74760599469118 33.55 35.66928014266191 139.7476141182489 33.55 35.66929108021963 139.74761959647253 33.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15c4cf78-763b-487e-89c5-f2ae7114a777">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15c4cf78-763b-487e-89c5-f2ae7114a777_0">
											<gml:posList>35.669294291270916 139.74760997187764 31.927 35.669294291270916 139.74760997187764 33.55 35.66929108021963 139.74761959647253 33.55 35.66929108021963 139.74761959647253 31.659 35.669294291270916 139.74760997187764 31.927</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4fcd595e-92ac-4133-b780-776c0d195398">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4fcd595e-92ac-4133-b780-776c0d195398_0">
											<gml:posList>35.66929108021963 139.74761959647253 33.55 35.66928014266191 139.7476141182489 33.55 35.66929108021963 139.74761959647253 31.659 35.66929108021963 139.74761959647253 33.55</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-715ad896-457c-4c94-8ccb-3378f036ce14">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-715ad896-457c-4c94-8ccb-3378f036ce14_0">
											<gml:posList>35.669281542137206 139.7476300783799 35.236 35.66927052342497 139.74762455605781 35.236 35.66927052342497 139.74762455605781 36.826 35.669281542137206 139.7476300783799 36.826 35.669281542137206 139.7476300783799 35.236</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6a3cbc7-50d4-4b88-9fd1-8c36534e42a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6a3cbc7-50d4-4b88-9fd1-8c36534e42a9_0">
											<gml:posList>35.66927052342497 139.74762455605781 35.236 35.669266026161125 139.74763804816135 35.236 35.669266026161125 139.74763804816135 36.826 35.66927052342497 139.74762455605781 36.826 35.66927052342497 139.74762455605781 35.236</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-200792e0-11ff-4ac8-98ea-cce9ca6d154f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-200792e0-11ff-4ac8-98ea-cce9ca6d154f_0">
											<gml:posList>35.669266026161125 139.74763804816135 36.826 35.669277044872764 139.747643570485 36.826 35.669281542137206 139.7476300783799 36.826 35.66927052342497 139.74762455605781 36.826 35.669266026161125 139.74763804816135 36.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df29d3b2-ac1a-49a6-96b2-3a41cd32b0b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df29d3b2-ac1a-49a6-96b2-3a41cd32b0b4_0">
											<gml:posList>35.669281542137206 139.7476300783799 35.236 35.669281542137206 139.7476300783799 36.826 35.669277044872764 139.747643570485 36.826 35.669277044872764 139.747643570485 35.236 35.669281542137206 139.7476300783799 35.236</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e991f4a-d7e6-4ed7-8c37-1b6aac8bd739">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e991f4a-d7e6-4ed7-8c37-1b6aac8bd739_0">
											<gml:posList>35.669277044872764 139.747643570485 36.826 35.669266026161125 139.74763804816135 36.826 35.669266026161125 139.74763804816135 35.236 35.669277044872764 139.747643570485 35.236 35.669277044872764 139.747643570485 36.826</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_407d25d9-fa8f-48b4-826e-b47efb08f7ec_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69d34d11-0ad7-465f-83fa-f5f2ba050fb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69d34d11-0ad7-465f-83fa-f5f2ba050fb1_0">
											<gml:posList>35.669285937626945 139.74766356548534 28.713 35.66929662324094 139.74763166394615 27.225 35.66929662324094 139.74763166394615 30.303 35.669285937626945 139.74766356548534 28.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f67216b-cba4-41de-9abf-dd59f6d22333">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f67216b-cba4-41de-9abf-dd59f6d22333_0">
											<gml:posList>35.66929016354792 139.74762343045262 30.303 35.669298044382806 139.7476274096744 30.303 35.66929016354792 139.74762343045262 6.04 35.66929016354792 139.74762343045262 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aa1d630-6b79-43bb-b20c-1ece0fe13c19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6aa1d630-6b79-43bb-b20c-1ece0fe13c19_0">
											<gml:posList>35.669298044382806 139.7476274096744 30.303 35.669305934239155 139.74763139993348 30.303 35.669305934239155 139.74763139993348 6.04 35.669298044382806 139.7476274096744 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d057c24-3a06-4d1b-8a0b-395949042987">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d057c24-3a06-4d1b-8a0b-395949042987_0">
											<gml:posList>35.66929016354792 139.74762343045262 6.04 35.669298044382806 139.7476274096744 30.303 35.669305934239155 139.74763139993348 6.04 35.66929016354792 139.74762343045262 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fdbc224-7dd0-488d-a905-d93d1bd8529e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fdbc224-7dd0-488d-a905-d93d1bd8529e_0">
											<gml:posList>35.669298044382806 139.7476274096744 30.303 35.66928873340817 139.74762770682585 30.303 35.66929662324094 139.74763166394615 30.303 35.669298044382806 139.7476274096744 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b2122fe-ce8e-4922-b096-4faad42e69f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b2122fe-ce8e-4922-b096-4faad42e69f1_0">
											<gml:posList>35.669298044382806 139.7476274096744 30.303 35.66929016354792 139.74762343045262 30.303 35.66928873340817 139.74762770682585 30.303 35.669298044382806 139.7476274096744 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44044d83-c353-4ff2-90e8-f97d1a538fc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-44044d83-c353-4ff2-90e8-f97d1a538fc8_0">
											<gml:posList>35.66930451306569 139.74763561002118 30.303 35.669305934239155 139.74763139993348 30.303 35.669298044382806 139.7476274096744 30.303 35.66930451306569 139.74763561002118 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3015300a-7092-47ba-8c4c-ad1a9fe92cf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3015300a-7092-47ba-8c4c-ad1a9fe92cf4_0">
											<gml:posList>35.66929662324094 139.74763166394615 30.303 35.66930451306569 139.74763561002118 30.303 35.669298044382806 139.7476274096744 30.303 35.66929662324094 139.74763166394615 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c648e212-6d48-493f-9c05-a5b4263d5a7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c648e212-6d48-493f-9c05-a5b4263d5a7f_0">
											<gml:posList>35.66928873340817 139.74762770682585 30.303 35.66927809288743 139.74765964145257 28.713 35.669285937626945 139.74766356548534 28.713 35.66928873340817 139.74762770682585 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37fddc50-6658-423b-8aca-28e048ae811d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37fddc50-6658-423b-8aca-28e048ae811d_0">
											<gml:posList>35.66929662324094 139.74763166394615 30.303 35.66928873340817 139.74762770682585 30.303 35.669285937626945 139.74766356548534 28.713 35.66929662324094 139.74763166394615 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-365740e4-284a-4462-b018-81cb8c2a7aad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-365740e4-284a-4462-b018-81cb8c2a7aad_0">
											<gml:posList>35.66929377336047 139.74766750057464 28.713 35.66930451306569 139.74763561002118 27.225 35.66929662324094 139.74763166394615 27.225 35.66929377336047 139.74766750057464 28.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29805781-89a6-4be9-89a1-2dedd11d1a3b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29805781-89a6-4be9-89a1-2dedd11d1a3b_0">
											<gml:posList>35.669285937626945 139.74766356548534 28.713 35.66929377336047 139.74766750057464 28.713 35.66929662324094 139.74763166394615 27.225 35.669285937626945 139.74766356548534 28.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e6827d0-9d73-407d-abbf-8c4c63c8e10b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e6827d0-9d73-407d-abbf-8c4c63c8e10b_0">
											<gml:posList>35.66929377336047 139.74766750057464 28.713 35.669285937626945 139.74766356548534 28.713 35.669292532090935 139.74767119130166 28.713 35.66929377336047 139.74766750057464 28.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61e4a4d1-2b36-4262-a6a8-37df18cd5d77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61e4a4d1-2b36-4262-a6a8-37df18cd5d77_0">
											<gml:posList>35.669285937626945 139.74766356548534 28.713 35.66927809288743 139.74765964145257 28.713 35.66927686962986 139.7476633100675 28.713 35.669285937626945 139.74766356548534 28.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ac8b316-3738-4238-abcd-51a72689becc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ac8b316-3738-4238-abcd-51a72689becc_0">
											<gml:posList>35.669285937626945 139.74766356548534 28.713 35.66927686962986 139.7476633100675 28.713 35.669292532090935 139.74767119130166 28.713 35.669285937626945 139.74766356548534 28.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55b4968c-ad50-458e-83af-c2943fa6d1fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55b4968c-ad50-458e-83af-c2943fa6d1fa_0">
											<gml:posList>35.66927686962986 139.7476633100675 28.713 35.669292532090935 139.74767119130166 6.04 35.669292532090935 139.74767119130166 28.713 35.66927686962986 139.7476633100675 28.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcbf2025-56b0-4885-b439-54c521687a51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcbf2025-56b0-4885-b439-54c521687a51_0">
											<gml:posList>35.66927686962986 139.7476633100675 28.713 35.66927686962986 139.7476633100675 6.04 35.669292532090935 139.74767119130166 6.04 35.66927686962986 139.7476633100675 28.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19faf7f8-9660-4389-b78e-ab6bb4a32070">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19faf7f8-9660-4389-b78e-ab6bb4a32070_0">
											<gml:posList>35.66930451306569 139.74763561002118 30.303 35.66929662324094 139.74763166394615 27.225 35.66930451306569 139.74763561002118 27.225 35.66930451306569 139.74763561002118 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f47bf43a-6e8b-4247-b911-0a6fbf01e593">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f47bf43a-6e8b-4247-b911-0a6fbf01e593_0">
											<gml:posList>35.66930451306569 139.74763561002118 30.303 35.66929662324094 139.74763166394615 30.303 35.66929662324094 139.74763166394615 27.225 35.66930451306569 139.74763561002118 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd78fbcc-d101-4c85-8af6-6d59a306f08a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd78fbcc-d101-4c85-8af6-6d59a306f08a_0">
											<gml:posList>35.66927686962986 139.7476633100675 6.04 35.66927809288743 139.74765964145257 28.713 35.66929016354792 139.74762343045262 6.04 35.66927686962986 139.7476633100675 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c8419eb2-0e25-4a8a-b9c3-401b53216edc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c8419eb2-0e25-4a8a-b9c3-401b53216edc_0">
											<gml:posList>35.66929016354792 139.74762343045262 6.04 35.66927809288743 139.74765964145257 28.713 35.66929016354792 139.74762343045262 30.303 35.66929016354792 139.74762343045262 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a0246be-981b-47bb-9620-697da18a0ee3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a0246be-981b-47bb-9620-697da18a0ee3_0">
											<gml:posList>35.66927686962986 139.7476633100675 6.04 35.66927686962986 139.7476633100675 28.713 35.66927809288743 139.74765964145257 28.713 35.66927686962986 139.7476633100675 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3f44c72-20a0-445b-a9a4-e274e2642f88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3f44c72-20a0-445b-a9a4-e274e2642f88_0">
											<gml:posList>35.66929016354792 139.74762343045262 30.303 35.66927809288743 139.74765964145257 28.713 35.66928873340817 139.74762770682585 30.303 35.66929016354792 139.74762343045262 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7fd63da7-fabf-456c-9dd8-39b16308ed7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7fd63da7-fabf-456c-9dd8-39b16308ed7a_0">
											<gml:posList>35.66929377336047 139.74766750057464 28.713 35.669292532090935 139.74767119130166 28.713 35.66930451306569 139.74763561002118 27.225 35.66929377336047 139.74766750057464 28.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbd62ec7-05af-4a00-860e-a00f741f6f90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbd62ec7-05af-4a00-860e-a00f741f6f90_0">
											<gml:posList>35.66930451306569 139.74763561002118 30.303 35.66930451306569 139.74763561002118 27.225 35.669305934239155 139.74763139993348 30.303 35.66930451306569 139.74763561002118 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f31f795-ea60-4fa4-93e3-a6693ca79187">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f31f795-ea60-4fa4-93e3-a6693ca79187_0">
											<gml:posList>35.669292532090935 139.74767119130166 28.713 35.669292532090935 139.74767119130166 6.04 35.66930451306569 139.74763561002118 27.225 35.669292532090935 139.74767119130166 28.713</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88fd3046-6757-4526-9f56-30274b3c74f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88fd3046-6757-4526-9f56-30274b3c74f2_0">
											<gml:posList>35.669305934239155 139.74763139993348 30.303 35.66930451306569 139.74763561002118 27.225 35.669305934239155 139.74763139993348 6.04 35.669305934239155 139.74763139993348 30.303</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbc90662-3fee-472b-ba54-2252149f5426">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbc90662-3fee-472b-ba54-2252149f5426_0">
											<gml:posList>35.66930451306569 139.74763561002118 27.225 35.669292532090935 139.74767119130166 6.04 35.669305934239155 139.74763139993348 6.04 35.66930451306569 139.74763561002118 27.225</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab28f90f-eb92-4f58-acaf-74d42c85f891">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929016354792 139.74762343045262 6.04 35.669305934239155 139.74763139993348 6.04 35.669292532090935 139.74767119130166 6.04 35.66927686962986 139.7476633100675 6.04 35.66929016354792 139.74762343045262 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9c3e978b-3348-4fa0-9cb7-362f0af151d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c3e978b-3348-4fa0-9cb7-362f0af151d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c3e978b-3348-4fa0-9cb7-362f0af151d2">
											<gml:posList>35.66932662497036 139.7475993330384 6.04 35.66931439216449 139.7476356767851 6.04 35.66929016354792 139.74762343045262 6.04 35.66927686962986 139.7476633100675 6.04 35.66921244339205 139.74763082604977 6.04 35.66923789820263 139.74755491211607 6.04 35.66932662497036 139.7475993330384 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11a58080-5df9-406a-993b-d9bada73e438">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11a58080-5df9-406a-993b-d9bada73e438">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11a58080-5df9-406a-993b-d9bada73e438">
											<gml:posList>35.66923789820263 139.74755491211607 28.3 35.66921244339205 139.74763082604977 28.3 35.66925437229588 139.74765196766293 35.5 35.6692688714781 139.7476084746918 35.5 35.66927974586228 139.74757586599927 35.5 35.66923789820263 139.74755491211607 28.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-708d5b15-97b8-41e0-9305-746e036ae2a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-708d5b15-97b8-41e0-9305-746e036ae2a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-708d5b15-97b8-41e0-9305-746e036ae2a4">
											<gml:posList>35.66925437229588 139.74765196766293 35.5 35.669257309701656 139.7476504622537 35.5 35.66927010893001 139.74761208544584 35.5 35.6692688714781 139.7476084746918 35.5 35.66925437229588 139.74765196766293 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5b9afc96-7664-435f-997f-649736617e9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b9afc96-7664-435f-997f-649736617e9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b9afc96-7664-435f-997f-649736617e9a">
											<gml:posList>35.66927686962986 139.7476633100675 35.5 35.669275632187365 139.74765971035848 35.5 35.669257309701656 139.7476504622537 35.5 35.66925437229588 139.74765196766293 35.5 35.66927686962986 139.7476633100675 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed48e154-4d7d-47ec-b91d-02845d4cda08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed48e154-4d7d-47ec-b91d-02845d4cda08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed48e154-4d7d-47ec-b91d-02845d4cda08">
											<gml:posList>35.669288440377294 139.747621256211 35.236 35.66927010893001 139.74761208544584 35.236 35.669257309701656 139.7476504622537 35.236 35.669275632187365 139.74765971035848 35.236 35.669288440377294 139.747621256211 35.236</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4a9386a-deb0-4a6b-855a-005da4197eb8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4a9386a-deb0-4a6b-855a-005da4197eb8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4a9386a-deb0-4a6b-855a-005da4197eb8">
											<gml:posList>35.6692688714781 139.7476084746918 35.5 35.66927010893001 139.74761208544584 35.5 35.669288440377294 139.747621256211 35.5 35.6692913867964 139.74761975079034 35.5 35.6692688714781 139.7476084746918 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7acc5c98-44c5-4ba3-88b3-d27bdad69c39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7acc5c98-44c5-4ba3-88b3-d27bdad69c39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7acc5c98-44c5-4ba3-88b3-d27bdad69c39">
											<gml:posList>35.6692913867964 139.74761975079034 35.5 35.669288440377294 139.747621256211 35.5 35.669275632187365 139.74765971035848 35.5 35.66927686962986 139.7476633100675 35.5 35.6692913867964 139.74761975079034 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1bd463af-beec-42a1-a8be-672576876f2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bd463af-beec-42a1-a8be-672576876f2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bd463af-beec-42a1-a8be-672576876f2d">
											<gml:posList>35.66932662497036 139.7475993330384 28.3 35.66927974586228 139.74757586599927 35.5 35.6692688714781 139.7476084746918 35.5 35.66932662497036 139.7475993330384 28.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0a597ac3-e0fe-418f-83aa-8efa9b2b6e49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a597ac3-e0fe-418f-83aa-8efa9b2b6e49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a597ac3-e0fe-418f-83aa-8efa9b2b6e49">
											<gml:posList>35.6692913867964 139.74761975079034 31.606 35.66932662497036 139.7475993330384 28.3 35.6692688714781 139.7476084746918 35.5 35.6692913867964 139.74761975079034 31.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cd220ab0-1340-47b7-8b37-be440de6b6d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cd220ab0-1340-47b7-8b37-be440de6b6d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cd220ab0-1340-47b7-8b37-be440de6b6d5">
											<gml:posList>35.6692913867964 139.74761975079034 31.606 35.66929016354792 139.74762343045262 31.606 35.66931439216449 139.7476356767851 28.3 35.6692913867964 139.74761975079034 31.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e53b151-d9d5-4045-8957-a17b698ba02b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e53b151-d9d5-4045-8957-a17b698ba02b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e53b151-d9d5-4045-8957-a17b698ba02b">
											<gml:posList>35.6692913867964 139.74761975079034 31.606 35.66931439216449 139.7476356767851 28.3 35.66932662497036 139.7475993330384 28.3 35.6692913867964 139.74761975079034 31.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2432bd0e-3855-4e80-9c68-d004060154bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2432bd0e-3855-4e80-9c68-d004060154bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2432bd0e-3855-4e80-9c68-d004060154bb">
											<gml:posList>35.66923789820263 139.74755491211607 28.3 35.66927974586228 139.74757586599927 35.5 35.66932662497036 139.7475993330384 28.3 35.66932662497036 139.7475993330384 6.04 35.66923789820263 139.74755491211607 6.04 35.66923789820263 139.74755491211607 28.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a73ba591-d710-46df-9253-4b858e744b5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a73ba591-d710-46df-9253-4b858e744b5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a73ba591-d710-46df-9253-4b858e744b5f">
											<gml:posList>35.66923789820263 139.74755491211607 6.04 35.66921244339205 139.74763082604977 6.04 35.66921244339205 139.74763082604977 28.3 35.66923789820263 139.74755491211607 28.3 35.66923789820263 139.74755491211607 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdf2a5d2-cf53-49d3-834d-ff2df577f16a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdf2a5d2-cf53-49d3-834d-ff2df577f16a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdf2a5d2-cf53-49d3-834d-ff2df577f16a">
											<gml:posList>35.6692688714781 139.7476084746918 35.5 35.6692913867964 139.74761975079034 35.5 35.6692913867964 139.74761975079034 31.606 35.6692688714781 139.7476084746918 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e18acfb-3c4a-4ce0-adab-e67f099e72e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e18acfb-3c4a-4ce0-adab-e67f099e72e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e18acfb-3c4a-4ce0-adab-e67f099e72e3">
											<gml:posList>35.66927010893001 139.74761208544584 35.5 35.66927010893001 139.74761208544584 35.236 35.669288440377294 139.747621256211 35.236 35.669288440377294 139.747621256211 35.5 35.66927010893001 139.74761208544584 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1fd37fbf-6421-4bf2-8fa9-7fad631b4977">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fd37fbf-6421-4bf2-8fa9-7fad631b4977">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fd37fbf-6421-4bf2-8fa9-7fad631b4977">
											<gml:posList>35.66931439216449 139.7476356767851 6.04 35.66932662497036 139.7475993330384 6.04 35.66932662497036 139.7475993330384 28.3 35.66931439216449 139.7476356767851 28.3 35.66931439216449 139.7476356767851 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5974c99-a4ef-457e-bc6f-c97698258889">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5974c99-a4ef-457e-bc6f-c97698258889">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5974c99-a4ef-457e-bc6f-c97698258889">
											<gml:posList>35.66929016354792 139.74762343045262 6.04 35.66931439216449 139.7476356767851 6.04 35.66931439216449 139.7476356767851 28.3 35.66929016354792 139.74762343045262 31.606 35.66929016354792 139.74762343045262 6.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbb68a87-5933-40bd-9cbe-d619677d676b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbb68a87-5933-40bd-9cbe-d619677d676b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbb68a87-5933-40bd-9cbe-d619677d676b">
											<gml:posList>35.669257309701656 139.7476504622537 35.5 35.669257309701656 139.7476504622537 35.236 35.66927010893001 139.74761208544584 35.236 35.66927010893001 139.74761208544584 35.5 35.669257309701656 139.7476504622537 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b39e734-f32d-45d4-89aa-ee59b8d26714">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b39e734-f32d-45d4-89aa-ee59b8d26714">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b39e734-f32d-45d4-89aa-ee59b8d26714">
											<gml:posList>35.669288440377294 139.747621256211 35.5 35.669288440377294 139.747621256211 35.236 35.669275632187365 139.74765971035848 35.236 35.669275632187365 139.74765971035848 35.5 35.669288440377294 139.747621256211 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afa867bb-09e6-446b-9db3-39dccd8a26e8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afa867bb-09e6-446b-9db3-39dccd8a26e8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afa867bb-09e6-446b-9db3-39dccd8a26e8">
											<gml:posList>35.66927686962986 139.7476633100675 35.5 35.66927686962986 139.7476633100675 6.04 35.66929016354792 139.74762343045262 6.04 35.66929016354792 139.74762343045262 31.606 35.6692913867964 139.74761975079034 31.606 35.6692913867964 139.74761975079034 35.5 35.66927686962986 139.7476633100675 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47d050aa-de16-4672-a5bb-e5e8b0a5f2ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47d050aa-de16-4672-a5bb-e5e8b0a5f2ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47d050aa-de16-4672-a5bb-e5e8b0a5f2ab">
											<gml:posList>35.66921244339205 139.74763082604977 28.3 35.66921244339205 139.74763082604977 6.04 35.66927686962986 139.7476633100675 6.04 35.66927686962986 139.7476633100675 35.5 35.66925437229588 139.74765196766293 35.5 35.66921244339205 139.74763082604977 28.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb895125-b897-491d-884c-82b5c13687a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb895125-b897-491d-884c-82b5c13687a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb895125-b897-491d-884c-82b5c13687a1">
											<gml:posList>35.669275632187365 139.74765971035848 35.5 35.669275632187365 139.74765971035848 35.236 35.669257309701656 139.7476504622537 35.236 35.669257309701656 139.7476504622537 35.5 35.669275632187365 139.74765971035848 35.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6676</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">79.104</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>