<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_408080ff-4936-45ac-9ae4-2d9cfd2a6f8e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">421</bldg:usage>
			<bldg:measuredHeight uom="m">14.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66785707033679 139.7430959394341 0 35.66787041710913 139.743104540227 0 35.667890519044846 139.7431062849538 0 35.66790367304421 139.7430982066319 0 35.66791231620587 139.74308483134254 0 35.66791852441775 139.74306980190318 0 35.66791678746223 139.7430373288527 0 35.66790379187304 139.74301624578257 0 35.66791638772357 139.74298508209995 0 35.66784055301693 139.74294617548483 0 35.66780819684264 139.74283034041053 0 35.667598988982775 139.7427117229056 0 35.66756889543477 139.7427281048068 0 35.6675530596928 139.74276589957628 0 35.667558948267896 139.74280532668485 0 35.66770467326831 139.7428892213953 0 35.667739192515135 139.7430048329894 0 35.66768952956098 139.74312871335047 0 35.667592935078666 139.74317245322322 0 35.667789062835006 139.74327805244457 0 35.66785707033679 139.7430959394341 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66785707033679 139.7430959394341 27.72 35.667789062835006 139.74327805244457 27.72 35.667592935078666 139.74317245322322 27.72 35.66768952956098 139.74312871335047 27.72 35.667739192515135 139.7430048329894 27.72 35.66770467326831 139.7428892213953 27.72 35.667558948267896 139.74280532668485 27.72 35.6675530596928 139.74276589957628 27.72 35.66756889543477 139.7427281048068 27.72 35.667598988982775 139.7427117229056 27.72 35.66780819684264 139.74283034041053 27.72 35.66784055301693 139.74294617548483 27.72 35.66791638772357 139.74298508209995 27.72 35.66790379187304 139.74301624578257 27.72 35.66791678746223 139.7430373288527 27.72 35.66791852441775 139.74306980190318 27.72 35.66791231620587 139.74308483134254 27.72 35.66790367304421 139.7430982066319 27.72 35.667890519044846 139.7431062849538 27.72 35.66787041710913 139.743104540227 27.72 35.66785707033679 139.7430959394341 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66785707033679 139.7430959394341 27.72 35.66787041710913 139.743104540227 27.72 35.66787041710913 139.743104540227 42.06 35.66785707033679 139.7430959394341 42.06 35.66785707033679 139.7430959394341 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66787041710913 139.743104540227 27.72 35.667890519044846 139.7431062849538 27.72 35.667890519044846 139.7431062849538 42.06 35.66787041710913 139.743104540227 42.06 35.66787041710913 139.743104540227 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667890519044846 139.7431062849538 27.72 35.66790367304421 139.7430982066319 27.72 35.66790367304421 139.7430982066319 42.06 35.667890519044846 139.7431062849538 42.06 35.667890519044846 139.7431062849538 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66790367304421 139.7430982066319 27.72 35.66791231620587 139.74308483134254 27.72 35.66791231620587 139.74308483134254 42.06 35.66790367304421 139.7430982066319 42.06 35.66790367304421 139.7430982066319 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66791231620587 139.74308483134254 27.72 35.66791852441775 139.74306980190318 27.72 35.66791852441775 139.74306980190318 42.06 35.66791231620587 139.74308483134254 42.06 35.66791231620587 139.74308483134254 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66791852441775 139.74306980190318 27.72 35.66791678746223 139.7430373288527 27.72 35.66791678746223 139.7430373288527 42.06 35.66791852441775 139.74306980190318 42.06 35.66791852441775 139.74306980190318 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66791678746223 139.7430373288527 27.72 35.66790379187304 139.74301624578257 27.72 35.66790379187304 139.74301624578257 42.06 35.66791678746223 139.7430373288527 42.06 35.66791678746223 139.7430373288527 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66790379187304 139.74301624578257 27.72 35.66791638772357 139.74298508209995 27.72 35.66791638772357 139.74298508209995 42.06 35.66790379187304 139.74301624578257 42.06 35.66790379187304 139.74301624578257 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66791638772357 139.74298508209995 27.72 35.66784055301693 139.74294617548483 27.72 35.66784055301693 139.74294617548483 42.06 35.66791638772357 139.74298508209995 42.06 35.66791638772357 139.74298508209995 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66784055301693 139.74294617548483 27.72 35.66780819684264 139.74283034041053 27.72 35.66780819684264 139.74283034041053 42.06 35.66784055301693 139.74294617548483 42.06 35.66784055301693 139.74294617548483 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66780819684264 139.74283034041053 27.72 35.667598988982775 139.7427117229056 27.72 35.667598988982775 139.7427117229056 42.06 35.66780819684264 139.74283034041053 42.06 35.66780819684264 139.74283034041053 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667598988982775 139.7427117229056 27.72 35.66756889543477 139.7427281048068 27.72 35.66756889543477 139.7427281048068 42.06 35.667598988982775 139.7427117229056 42.06 35.667598988982775 139.7427117229056 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66756889543477 139.7427281048068 27.72 35.6675530596928 139.74276589957628 27.72 35.6675530596928 139.74276589957628 42.06 35.66756889543477 139.7427281048068 42.06 35.66756889543477 139.7427281048068 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6675530596928 139.74276589957628 27.72 35.667558948267896 139.74280532668485 27.72 35.667558948267896 139.74280532668485 42.06 35.6675530596928 139.74276589957628 42.06 35.6675530596928 139.74276589957628 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667558948267896 139.74280532668485 27.72 35.66770467326831 139.7428892213953 27.72 35.66770467326831 139.7428892213953 42.06 35.667558948267896 139.74280532668485 42.06 35.667558948267896 139.74280532668485 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66770467326831 139.7428892213953 27.72 35.667739192515135 139.7430048329894 27.72 35.667739192515135 139.7430048329894 42.06 35.66770467326831 139.7428892213953 42.06 35.66770467326831 139.7428892213953 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667739192515135 139.7430048329894 27.72 35.66768952956098 139.74312871335047 27.72 35.66768952956098 139.74312871335047 42.06 35.667739192515135 139.7430048329894 42.06 35.667739192515135 139.7430048329894 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66768952956098 139.74312871335047 27.72 35.667592935078666 139.74317245322322 27.72 35.667592935078666 139.74317245322322 42.06 35.66768952956098 139.74312871335047 42.06 35.66768952956098 139.74312871335047 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667592935078666 139.74317245322322 27.72 35.667789062835006 139.74327805244457 27.72 35.667789062835006 139.74327805244457 42.06 35.667592935078666 139.74317245322322 42.06 35.667592935078666 139.74317245322322 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667789062835006 139.74327805244457 27.72 35.66785707033679 139.7430959394341 27.72 35.66785707033679 139.7430959394341 42.06 35.667789062835006 139.74327805244457 42.06 35.667789062835006 139.74327805244457 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66785707033679 139.7430959394341 42.06 35.66787041710913 139.743104540227 42.06 35.667890519044846 139.7431062849538 42.06 35.66790367304421 139.7430982066319 42.06 35.66791231620587 139.74308483134254 42.06 35.66791852441775 139.74306980190318 42.06 35.66791678746223 139.7430373288527 42.06 35.66790379187304 139.74301624578257 42.06 35.66791638772357 139.74298508209995 42.06 35.66784055301693 139.74294617548483 42.06 35.66780819684264 139.74283034041053 42.06 35.667598988982775 139.7427117229056 42.06 35.66756889543477 139.7427281048068 42.06 35.6675530596928 139.74276589957628 42.06 35.667558948267896 139.74280532668485 42.06 35.66770467326831 139.7428892213953 42.06 35.667739192515135 139.7430048329894 42.06 35.66768952956098 139.74312871335047 42.06 35.667592935078666 139.74317245322322 42.06 35.667789062835006 139.74327805244457 42.06 35.66785707033679 139.7430959394341 42.06</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-fecf62c3-8ce8-4665-8005-30598c70ea96"/>
							<gml:surfaceMember xlink:href="#poly-846ef56d-20bc-4360-8330-df5b0adc49b9"/>
							<gml:surfaceMember xlink:href="#poly-4c202dd2-e930-4b97-a09c-14eeec4dba28"/>
							<gml:surfaceMember xlink:href="#poly-dff162cb-f142-4932-a7e7-a6d47565debd"/>
							<gml:surfaceMember xlink:href="#poly-438ce352-1d1c-451e-991d-bb4f681989a6"/>
							<gml:surfaceMember xlink:href="#poly-014a8b44-babd-425f-8439-e810a9649f32"/>
							<gml:surfaceMember xlink:href="#poly-eabe7855-c3fe-4cf4-b61e-dccf78273d6f"/>
							<gml:surfaceMember xlink:href="#poly-4db194a0-79ba-4f40-814f-35d471c3fd07"/>
							<gml:surfaceMember xlink:href="#poly-a0d43816-9196-4bea-b2be-b98e82ab7e26"/>
							<gml:surfaceMember xlink:href="#poly-d305d3be-d495-40ce-ac72-8187dbcff811"/>
							<gml:surfaceMember xlink:href="#poly-122c2e37-9cbb-4d50-9cbb-e9019ab65f06"/>
							<gml:surfaceMember xlink:href="#poly-23604e68-4fe5-49ea-9376-ca10adff9439"/>
							<gml:surfaceMember xlink:href="#poly-3264b77a-b0be-4783-b244-06db1d66e447"/>
							<gml:surfaceMember xlink:href="#poly-2930fd73-7f77-49eb-b6c2-e242c3fbdd30"/>
							<gml:surfaceMember xlink:href="#poly-3e83654c-7f61-493a-b0dd-ab72b06ecddd"/>
							<gml:surfaceMember xlink:href="#poly-94bf4f3f-e5d3-49d9-9fed-de10d27e12d5"/>
							<gml:surfaceMember xlink:href="#poly-ab889b44-2fbe-4cb9-bcdd-2de13fbe89c2"/>
							<gml:surfaceMember xlink:href="#poly-45be2874-9757-41f6-9bfe-741e0939c381"/>
							<gml:surfaceMember xlink:href="#poly-9b101d56-5c41-4706-9bef-71876297370c"/>
							<gml:surfaceMember xlink:href="#poly-26a8061f-ee70-4c19-852f-166e6f7e72fe"/>
							<gml:surfaceMember xlink:href="#poly-5f810c2f-563e-4ba5-84fc-21a6661e75ee"/>
							<gml:surfaceMember xlink:href="#poly-90d60fc8-baf1-420c-94f3-9925dcebe848"/>
							<gml:surfaceMember xlink:href="#poly-a49a2bcd-f3a9-4e1b-8fce-8d7716782a9c"/>
							<gml:surfaceMember xlink:href="#poly-7c15ffee-62e9-443f-9ecb-69dfb1ac6195"/>
							<gml:surfaceMember xlink:href="#poly-68318d1d-1131-4a81-ba66-6f756793b0ba"/>
							<gml:surfaceMember xlink:href="#poly-e8395aca-e521-48af-b8eb-58693a7660e6"/>
							<gml:surfaceMember xlink:href="#poly-33747eb8-a8c7-4c8b-a073-8ad1bafecfcf"/>
							<gml:surfaceMember xlink:href="#poly-8e058425-2816-4dd4-abfd-7b980e29e6d6"/>
							<gml:surfaceMember xlink:href="#poly-e9492f58-ddfa-423f-9a30-0f9cbb06d128"/>
							<gml:surfaceMember xlink:href="#poly-d88ac592-83fc-4319-b6d5-5b2742259a50"/>
							<gml:surfaceMember xlink:href="#poly-21c1baf3-10fd-4d43-8afd-4cb644c3cf9c"/>
							<gml:surfaceMember xlink:href="#poly-d3add9e8-2953-4dad-b86b-864f198dfaa4"/>
							<gml:surfaceMember xlink:href="#poly-ba0cad62-6cbc-45a9-b099-2b26f33d186a"/>
							<gml:surfaceMember xlink:href="#poly-1f4585a3-97ed-4b4a-9ec8-cf845d8c26c5"/>
							<gml:surfaceMember xlink:href="#poly-bd56afcb-2344-4a80-8cac-c531321e95d2"/>
							<gml:surfaceMember xlink:href="#poly-882a9311-3ac7-4173-9a2a-4f3d81b29d40"/>
							<gml:surfaceMember xlink:href="#poly-1425c12f-aa4f-4667-82a5-b7111ac865db"/>
							<gml:surfaceMember xlink:href="#poly-3dc5e771-d948-48a8-9f45-ee283d729916"/>
							<gml:surfaceMember xlink:href="#poly-143250dd-b839-4e45-84f9-835aa66073f0"/>
							<gml:surfaceMember xlink:href="#poly-5b23c1fe-d975-40d4-9ac8-795df70f3524"/>
							<gml:surfaceMember xlink:href="#poly-46e06239-be21-4fc3-bf0d-a224a659fad8"/>
							<gml:surfaceMember xlink:href="#poly-dcd53e96-ba9b-4966-8a5a-35d81e70744f"/>
							<gml:surfaceMember xlink:href="#poly-149d01dc-cbe5-4970-81f6-eb71af2d88af"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_408080ff-4936-45ac-9ae4-2d9cfd2a6f8e_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93670f49-07eb-4f8b-8e11-5e7af50b8c1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93670f49-07eb-4f8b-8e11-5e7af50b8c1d_0">
											<gml:posList>35.66761808251277 139.74277487271 43.167 35.66762684733634 139.74277949103524 45.357 35.66762684733634 139.74277949103524 43.15 35.66761808251277 139.74277487271 43.167</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2ccb895-ec91-41d0-9cd0-dcdaa0abb485">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2ccb895-ec91-41d0-9cd0-dcdaa0abb485_0">
											<gml:posList>35.66761808251277 139.74277487271 43.167 35.66761808251277 139.74277487271 45.357 35.66762684733634 139.74277949103524 45.357 35.66761808251277 139.74277487271 43.167</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-254bc7df-6039-4561-afd0-2336a8b9776f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-254bc7df-6039-4561-afd0-2336a8b9776f_0">
											<gml:posList>35.66761808251277 139.74277487271 43.167 35.667616679394946 139.74277889499456 43.358 35.66761808251277 139.74277487271 45.357 35.66761808251277 139.74277487271 43.167</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0362111-10b9-480f-91c5-9a1b88942516">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0362111-10b9-480f-91c5-9a1b88942516_0">
											<gml:posList>35.66761808251277 139.74277487271 45.357 35.667616679394946 139.74277889499456 43.358 35.66761141766038 139.74279392333108 45.357 35.66761808251277 139.74277487271 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57e5e855-6ff7-429b-8696-7963e2eb564f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57e5e855-6ff7-429b-8696-7963e2eb564f_0">
											<gml:posList>35.667616679394946 139.74277889499456 43.358 35.66761141766038 139.74279392333108 42.674 35.66761141766038 139.74279392333108 45.357 35.667616679394946 139.74277889499456 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63222202-bed4-4866-af9a-171466fb8d67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63222202-bed4-4866-af9a-171466fb8d67_0">
											<gml:posList>35.66762684733634 139.74277949103524 45.357 35.66761141766038 139.74279392333108 45.357 35.66762018247494 139.74279853061213 45.357 35.66762684733634 139.74277949103524 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8359ee3e-75e3-483d-b145-a64a836e24ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8359ee3e-75e3-483d-b145-a64a836e24ee_0">
											<gml:posList>35.66762684733634 139.74277949103524 45.357 35.66761808251277 139.74277487271 45.357 35.66761141766038 139.74279392333108 45.357 35.66762684733634 139.74277949103524 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d2cf69d-5f66-42f7-b8c7-58c2b0ce96f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d2cf69d-5f66-42f7-b8c7-58c2b0ce96f0_0">
											<gml:posList>35.66762684733634 139.74277949103524 43.15 35.66762684733634 139.74277949103524 45.357 35.667625318283676 139.74278385588465 43.358 35.66762684733634 139.74277949103524 43.15</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20d844e9-2fbb-46dc-b8ac-c9bc50ea9a61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20d844e9-2fbb-46dc-b8ac-c9bc50ea9a61_0">
											<gml:posList>35.667625318283676 139.74278385588465 43.358 35.66762018247494 139.74279853061213 45.357 35.66762018247494 139.74279853061213 42.689 35.667625318283676 139.74278385588465 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82b43228-570b-47a0-a35b-51dec0893a7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82b43228-570b-47a0-a35b-51dec0893a7b_0">
											<gml:posList>35.667625318283676 139.74278385588465 43.358 35.66762684733634 139.74277949103524 45.357 35.66762018247494 139.74279853061213 45.357 35.667625318283676 139.74278385588465 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12422d9c-7c52-4db0-9475-49ed1ff3d326">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12422d9c-7c52-4db0-9475-49ed1ff3d326_0">
											<gml:posList>35.66762018247494 139.74279853061213 42.689 35.66761141766038 139.74279392333108 45.357 35.66761141766038 139.74279392333108 42.674 35.66762018247494 139.74279853061213 42.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-092b17fb-8809-4599-9de5-de4064866215">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-092b17fb-8809-4599-9de5-de4064866215_0">
											<gml:posList>35.66762018247494 139.74279853061213 42.689 35.66762018247494 139.74279853061213 45.357 35.66761141766038 139.74279392333108 45.357 35.66762018247494 139.74279853061213 42.689</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-397fcec3-d90b-4e83-a40a-3660d429c8eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-397fcec3-d90b-4e83-a40a-3660d429c8eb_0">
											<gml:posList>35.66779799840692 139.7428251493005 41.123 35.66777212697229 139.74281047640915 42.806 35.66779799840692 139.7428251493005 42.806 35.66779799840692 139.7428251493005 41.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6fa915b-9a7a-49dd-b431-5f3767b76005">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6fa915b-9a7a-49dd-b431-5f3767b76005_0">
											<gml:posList>35.66779799840692 139.7428251493005 41.123 35.66777212697229 139.74281047640915 41.123 35.66777212697229 139.74281047640915 42.806 35.66779799840692 139.7428251493005 41.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-678e1028-c799-4363-818a-7dbfd5679fbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-678e1028-c799-4363-818a-7dbfd5679fbb_0">
											<gml:posList>35.66776072907091 139.74284041261637 42.538 35.66777212697229 139.74281047640915 42.806 35.66777212697229 139.74281047640915 41.123 35.66776072907091 139.74284041261637 42.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6230a7cb-2ff4-4140-be81-bfeae6cc7ced">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6230a7cb-2ff4-4140-be81-bfeae6cc7ced_0">
											<gml:posList>35.66776072907091 139.74284041261637 42.538 35.66776072907091 139.74284041261637 42.806 35.66777212697229 139.74281047640915 42.806 35.66776072907091 139.74284041261637 42.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4d334a7-83d3-4a42-a2fa-d8db842aff48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4d334a7-83d3-4a42-a2fa-d8db842aff48_0">
											<gml:posList>35.667786600501955 139.7428550855153 42.806 35.66777212697229 139.74281047640915 42.806 35.66776072907091 139.74284041261637 42.806 35.667786600501955 139.7428550855153 42.806</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7677010e-2450-407b-8fee-f7e54785cd2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7677010e-2450-407b-8fee-f7e54785cd2e_0">
											<gml:posList>35.667786600501955 139.7428550855153 42.806 35.66779799840692 139.7428251493005 42.806 35.66777212697229 139.74281047640915 42.806 35.667786600501955 139.7428550855153 42.806</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-017cdc40-0267-4201-8525-2630170b62a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-017cdc40-0267-4201-8525-2630170b62a2_0">
											<gml:posList>35.667722512027936 139.7428300063308 42.98 35.667735334628695 139.74283675194616 45.357 35.667735334628695 139.74283675194616 42.956 35.667722512027936 139.7428300063308 42.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b919684c-c5c6-44a3-a38e-06744a367da8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b919684c-c5c6-44a3-a38e-06744a367da8_0">
											<gml:posList>35.667722512027936 139.7428300063308 42.98 35.667722512027936 139.7428300063308 45.357 35.667735334628695 139.74283675194616 45.357 35.667722512027936 139.7428300063308 42.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7cffa5cc-89ff-4f93-a3c6-a86a74b2aef6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7cffa5cc-89ff-4f93-a3c6-a86a74b2aef6_0">
											<gml:posList>35.66779799840692 139.7428251493005 41.123 35.66779799840692 139.7428251493005 42.806 35.667789866035825 139.74284649916407 42.132 35.66779799840692 139.7428251493005 41.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1a208c3-9ff3-4c89-b1c0-b584073300a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1a208c3-9ff3-4c89-b1c0-b584073300a9_0">
											<gml:posList>35.667789866035825 139.74284649916407 42.132 35.667786600501955 139.7428550855153 42.806 35.667786600501955 139.7428550855153 42.388 35.667789866035825 139.74284649916407 42.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9534a20-94fa-41cd-95c9-d76de7d62f60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9534a20-94fa-41cd-95c9-d76de7d62f60_0">
											<gml:posList>35.667789866035825 139.74284649916407 42.132 35.66779799840692 139.7428251493005 42.806 35.667786600501955 139.7428550855153 42.806 35.667789866035825 139.74284649916407 42.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-201e375e-4ea0-4793-841c-e760311e6f99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-201e375e-4ea0-4793-841c-e760311e6f99_0">
											<gml:posList>35.66771380536684 139.74285480314023 42.594 35.66771380536684 139.74285480314023 45.357 35.66771971473585 139.7428379625311 43.358 35.66771380536684 139.74285480314023 42.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18de6b6a-45ae-4fbe-8f83-fbc1bf5bbaf9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18de6b6a-45ae-4fbe-8f83-fbc1bf5bbaf9_0">
											<gml:posList>35.66771971473585 139.7428379625311 43.358 35.667722512027936 139.7428300063308 45.357 35.667722512027936 139.7428300063308 42.98 35.66771971473585 139.7428379625311 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68874e8e-4e8c-4883-8eda-91ba2ca6df42">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68874e8e-4e8c-4883-8eda-91ba2ca6df42_0">
											<gml:posList>35.66771971473585 139.7428379625311 43.358 35.66771380536684 139.74285480314023 45.357 35.667722512027936 139.7428300063308 45.357 35.66771971473585 139.7428379625311 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48011f02-9844-46ad-a72e-fd7482110e62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48011f02-9844-46ad-a72e-fd7482110e62_0">
											<gml:posList>35.667722512027936 139.7428300063308 45.357 35.66772662797452 139.7428615598047 45.357 35.667735334628695 139.74283675194616 45.357 35.667722512027936 139.7428300063308 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d32ab7e9-47ad-4f03-9c23-13afbbeec95b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d32ab7e9-47ad-4f03-9c23-13afbbeec95b_0">
											<gml:posList>35.667722512027936 139.7428300063308 45.357 35.66771380536684 139.74285480314023 45.357 35.66772662797452 139.7428615598047 45.357 35.667722512027936 139.7428300063308 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f547a501-6e21-45dd-a6b7-c9d0a7eb7081">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f547a501-6e21-45dd-a6b7-c9d0a7eb7081_0">
											<gml:posList>35.66778265982663 139.74285285868962 42.538 35.66776072907091 139.74284041261637 42.806 35.66776072907091 139.74284041261637 42.538 35.66778265982663 139.74285285868962 42.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d041cab-66a8-4899-b8f2-5f649ceeae1b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d041cab-66a8-4899-b8f2-5f649ceeae1b_0">
											<gml:posList>35.667786600501955 139.7428550855153 42.388 35.667786600501955 139.7428550855153 42.806 35.66778265982663 139.74285285868962 42.538 35.667786600501955 139.7428550855153 42.388</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58df435e-49c0-4e99-b318-6af272f05667">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58df435e-49c0-4e99-b318-6af272f05667_0">
											<gml:posList>35.66778265982663 139.74285285868962 42.538 35.667786600501955 139.7428550855153 42.806 35.66776072907091 139.74284041261637 42.806 35.66778265982663 139.74285285868962 42.538</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d59437ba-b4fd-4ff1-8db4-04d924a176b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d59437ba-b4fd-4ff1-8db4-04d924a176b0_0">
											<gml:posList>35.667735334628695 139.74283675194616 42.956 35.667735334628695 139.74283675194616 45.357 35.66773236644888 139.74284520540562 43.358 35.667735334628695 139.74283675194616 42.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-302d6af1-03f1-4e3b-bfad-d59dce3ec3ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-302d6af1-03f1-4e3b-bfad-d59dce3ec3ab_0">
											<gml:posList>35.66773236644888 139.74284520540562 43.358 35.66772662797452 139.7428615598047 45.357 35.66772662797452 139.7428615598047 42.713 35.66773236644888 139.74284520540562 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-146ffd4f-1d2c-491f-b937-66fe893635d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-146ffd4f-1d2c-491f-b937-66fe893635d8_0">
											<gml:posList>35.66773236644888 139.74284520540562 43.358 35.667735334628695 139.74283675194616 45.357 35.66772662797452 139.7428615598047 45.357 35.66773236644888 139.74284520540562 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2f8cd7e-0f58-436c-b75f-2533b2f11b46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2f8cd7e-0f58-436c-b75f-2533b2f11b46_0">
											<gml:posList>35.66771380536684 139.74285480314023 42.594 35.667724490866355 139.7428604244889 42.614 35.66771380536684 139.74285480314023 45.357 35.66771380536684 139.74285480314023 42.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2741cfc-49de-4b7a-8ce8-2424d6bb8269">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2741cfc-49de-4b7a-8ce8-2424d6bb8269_0">
											<gml:posList>35.66771380536684 139.74285480314023 45.357 35.667724490866355 139.7428604244889 42.614 35.66772662797452 139.7428615598047 45.357 35.66771380536684 139.74285480314023 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-353bf8fb-1e73-4ce9-9e85-980e3ba7cc36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-353bf8fb-1e73-4ce9-9e85-980e3ba7cc36_0">
											<gml:posList>35.667724490866355 139.7428604244889 42.614 35.66772662797452 139.7428615598047 42.713 35.66772662797452 139.7428615598047 45.357 35.667724490866355 139.7428604244889 42.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11c167b1-30c5-473e-be52-3b0305f2e694">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11c167b1-30c5-473e-be52-3b0305f2e694_0">
											<gml:posList>35.667808978104794 139.74294644304106 42.547 35.667812665015916 139.74295884343752 45.357 35.667812665015916 139.74295884343752 42.541 35.667808978104794 139.74294644304106 42.547</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48fa035f-be02-4c16-af5a-f15b7894e1ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48fa035f-be02-4c16-af5a-f15b7894e1ec_0">
											<gml:posList>35.667808978104794 139.74294644304106 42.547 35.667808978104794 139.74294644304106 45.357 35.667812665015916 139.74295884343752 45.357 35.667808978104794 139.74294644304106 42.547</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84c09eee-48ab-40f2-89bd-b95b1ef7f3f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84c09eee-48ab-40f2-89bd-b95b1ef7f3f7_0">
											<gml:posList>35.667793209355224 139.74295348601052 45.357 35.667796896265614 139.74296588640485 45.357 35.667812665015916 139.74295884343752 45.357 35.667793209355224 139.74295348601052 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bd388b6-67c8-4769-a5a5-5b08787e3802">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bd388b6-67c8-4769-a5a5-5b08787e3802_0">
											<gml:posList>35.667808978104794 139.74294644304106 45.357 35.667793209355224 139.74295348601052 45.357 35.667812665015916 139.74295884343752 45.357 35.667808978104794 139.74294644304106 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ca39e57-eebe-4a9d-a60d-b4333cbbf859">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ca39e57-eebe-4a9d-a60d-b4333cbbf859_0">
											<gml:posList>35.667796896265614 139.74296588640485 43.354 35.667796896265614 139.74296588640485 45.357 35.667794646169035 139.74295832249678 43.358 35.667796896265614 139.74296588640485 43.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f8c7929-360e-4c8c-82b1-e27993ef5e59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f8c7929-360e-4c8c-82b1-e27993ef5e59_0">
											<gml:posList>35.667794646169035 139.74295832249678 43.358 35.667793209355224 139.74295348601052 45.357 35.667793209355224 139.74295348601052 43.358 35.667794646169035 139.74295832249678 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0d557c8-06c9-4a47-8b81-9f6432f672c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0d557c8-06c9-4a47-8b81-9f6432f672c1_0">
											<gml:posList>35.667794646169035 139.74295832249678 43.358 35.667796896265614 139.74296588640485 45.357 35.667793209355224 139.74295348601052 45.357 35.667794646169035 139.74295832249678 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73da0a84-a123-4d7b-851c-ace72b122ab5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73da0a84-a123-4d7b-851c-ace72b122ab5_0">
											<gml:posList>35.667796896265614 139.74296588640485 43.354 35.667812665015916 139.74295884343752 45.357 35.667796896265614 139.74296588640485 45.357 35.667796896265614 139.74296588640485 43.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbdc5ec9-4648-4a58-8075-6b3d9871deca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbdc5ec9-4648-4a58-8075-6b3d9871deca_0">
											<gml:posList>35.667796896265614 139.74296588640485 43.354 35.667812665015916 139.74295884343752 42.541 35.667812665015916 139.74295884343752 45.357 35.667796896265614 139.74296588640485 43.354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c9c2c81-5fe8-4dcc-a283-18a885165763">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c9c2c81-5fe8-4dcc-a283-18a885165763_0">
											<gml:posList>35.66777102808925 139.74301560001717 42.909 35.66777102808925 139.74301560001717 45.357 35.66777844051294 139.74301977806468 43.358 35.66777102808925 139.74301560001717 42.909</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16a6ba35-8007-4f4b-b54f-eba24f5b800f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16a6ba35-8007-4f4b-b54f-eba24f5b800f_0">
											<gml:posList>35.66777844051294 139.74301977806468 43.358 35.66779127247294 139.74302699867835 45.357 35.66779127247294 139.74302699867835 43.358 35.66777844051294 139.74301977806468 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f22b5e6b-b209-4f7b-b9bc-fd078d702cb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f22b5e6b-b209-4f7b-b9bc-fd078d702cb9_0">
											<gml:posList>35.66777844051294 139.74301977806468 43.358 35.66777102808925 139.74301560001717 45.357 35.66779127247294 139.74302699867835 45.357 35.66777844051294 139.74301977806468 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-beeb7b28-7dcb-404d-ae08-3f19bb38fa36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-beeb7b28-7dcb-404d-ae08-3f19bb38fa36_0">
											<gml:posList>35.667766161405126 139.74302859547672 42.926 35.66777102808925 139.74301560001717 45.357 35.66777102808925 139.74301560001717 42.909 35.667766161405126 139.74302859547672 42.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56787584-f4f0-4712-9b29-c32e1d672246">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56787584-f4f0-4712-9b29-c32e1d672246_0">
											<gml:posList>35.667766161405126 139.74302859547672 42.926 35.667766161405126 139.74302859547672 45.357 35.66777102808925 139.74301560001717 45.357 35.667766161405126 139.74302859547672 42.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb318501-e8e4-4eb6-89c7-49ea1d4329ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb318501-e8e4-4eb6-89c7-49ea1d4329ae_0">
											<gml:posList>35.66779127247294 139.74302699867835 45.357 35.667766161405126 139.74302859547672 45.357 35.66778640577932 139.74303998309463 45.357 35.66779127247294 139.74302699867835 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79cea166-fb82-495e-8a71-4a5a55d8149d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79cea166-fb82-495e-8a71-4a5a55d8149d_0">
											<gml:posList>35.66779127247294 139.74302699867835 45.357 35.66777102808925 139.74301560001717 45.357 35.667766161405126 139.74302859547672 45.357 35.66779127247294 139.74302699867835 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-237af266-d2b0-4c24-b5bc-209c8e83ba18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-237af266-d2b0-4c24-b5bc-209c8e83ba18_0">
											<gml:posList>35.66778640577932 139.74303998309463 43.358 35.66779127247294 139.74302699867835 45.357 35.66778640577932 139.74303998309463 45.357 35.66778640577932 139.74303998309463 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0532af1f-88f4-48dc-9505-dbff2b30e5e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0532af1f-88f4-48dc-9505-dbff2b30e5e2_0">
											<gml:posList>35.66778640577932 139.74303998309463 43.358 35.66779127247294 139.74302699867835 43.358 35.66779127247294 139.74302699867835 45.357 35.66778640577932 139.74303998309463 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0da2f74e-d152-44eb-a044-be0b34a5ff37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0da2f74e-d152-44eb-a044-be0b34a5ff37_0">
											<gml:posList>35.667766161405126 139.74302859547672 42.926 35.66777350168543 139.74303272942282 43.358 35.667766161405126 139.74302859547672 45.357 35.667766161405126 139.74302859547672 42.926</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afe8b3eb-52ec-45bc-87e1-4e0aca413730">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afe8b3eb-52ec-45bc-87e1-4e0aca413730_0">
											<gml:posList>35.667766161405126 139.74302859547672 45.357 35.66777350168543 139.74303272942282 43.358 35.66778640577932 139.74303998309463 45.357 35.667766161405126 139.74302859547672 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f40490ad-f6c7-41e4-85b1-0f9fbad30086">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f40490ad-f6c7-41e4-85b1-0f9fbad30086_0">
											<gml:posList>35.66777350168543 139.74303272942282 43.358 35.66778640577932 139.74303998309463 43.358 35.66778640577932 139.74303998309463 45.357 35.66777350168543 139.74303272942282 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f16bf28-2582-45d0-abf9-2e12c8bc1633">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f16bf28-2582-45d0-abf9-2e12c8bc1633_0">
											<gml:posList>35.667719398009524 139.74314868386244 42.889 35.667719398009524 139.74314868386244 45.357 35.6677274957615 139.74315324775512 43.358 35.667719398009524 139.74314868386244 42.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bd96e8b-fcda-4a93-9b30-20138a516959">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bd96e8b-fcda-4a93-9b30-20138a516959_0">
											<gml:posList>35.6677274957615 139.74315324775512 43.358 35.66773440319668 139.7431571391877 45.357 35.66773440319668 139.7431571391877 43.358 35.6677274957615 139.74315324775512 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e17b8d24-c963-4474-9bf6-1052b64c1f40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e17b8d24-c963-4474-9bf6-1052b64c1f40_0">
											<gml:posList>35.6677274957615 139.74315324775512 43.358 35.667719398009524 139.74314868386244 45.357 35.66773440319668 139.7431571391877 45.357 35.6677274957615 139.74315324775512 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3500e338-d664-46b3-b5a0-25c751fbd4f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3500e338-d664-46b3-b5a0-25c751fbd4f0_0">
											<gml:posList>35.66771545787206 139.74315920398368 42.892 35.667719398009524 139.74314868386244 45.357 35.667719398009524 139.74314868386244 42.889 35.66771545787206 139.74315920398368 42.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03ad4451-c8a7-4c20-b954-e1ec40571e20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03ad4451-c8a7-4c20-b954-e1ec40571e20_0">
											<gml:posList>35.66771545787206 139.74315920398368 42.892 35.66771545787206 139.74315920398368 45.357 35.667719398009524 139.74314868386244 45.357 35.66771545787206 139.74315920398368 42.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3373605b-ae11-471c-a512-f52af5f9fd62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3373605b-ae11-471c-a512-f52af5f9fd62_0">
											<gml:posList>35.66773440319668 139.7431571391877 45.357 35.66771545787206 139.74315920398368 45.357 35.66773046305022 139.74316764826463 45.357 35.66773440319668 139.7431571391877 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3fb5363-fd96-4950-a49a-aca552386d3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3fb5363-fd96-4950-a49a-aca552386d3d_0">
											<gml:posList>35.66773440319668 139.7431571391877 45.357 35.667719398009524 139.74314868386244 45.357 35.66771545787206 139.74315920398368 45.357 35.66773440319668 139.7431571391877 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eaaf6cbb-055e-4364-986d-417f74488faf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eaaf6cbb-055e-4364-986d-417f74488faf_0">
											<gml:posList>35.66773046305022 139.74316764826463 43.358 35.66773440319668 139.7431571391877 45.357 35.66773046305022 139.74316764826463 45.357 35.66773046305022 139.74316764826463 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-338ffcde-29ea-4485-85f9-54e9f05a63e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-338ffcde-29ea-4485-85f9-54e9f05a63e0_0">
											<gml:posList>35.66773046305022 139.74316764826463 43.358 35.66773440319668 139.7431571391877 43.358 35.66773440319668 139.7431571391877 45.357 35.66773046305022 139.74316764826463 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1af66154-6800-4a89-b1d2-ce4277302e85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1af66154-6800-4a89-b1d2-ce4277302e85_0">
											<gml:posList>35.66779894925928 139.7431674497492 42.57 35.66778446710078 139.7431593031123 43.358 35.66779894925928 139.7431674497492 45.357 35.66779894925928 139.7431674497492 42.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f95fd4e4-5c41-4d82-9d73-46f6d6186df4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f95fd4e4-5c41-4d82-9d73-46f6d6186df4_0">
											<gml:posList>35.66779894925928 139.7431674497492 45.357 35.66778446710078 139.7431593031123 43.358 35.66778348418265 139.74315874087662 45.357 35.66779894925928 139.7431674497492 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70223ff4-ef96-41c0-a84c-f58c3dbc871e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70223ff4-ef96-41c0-a84c-f58c3dbc871e_0">
											<gml:posList>35.66778446710078 139.7431593031123 43.358 35.66778348418265 139.74315874087662 43.358 35.66778348418265 139.74315874087662 45.357 35.66778446710078 139.7431593031123 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9740a38-c3b7-47fe-a7e9-b0cdf8af5295">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9740a38-c3b7-47fe-a7e9-b0cdf8af5295_0">
											<gml:posList>35.66771545787206 139.74315920398368 42.892 35.66772349250273 139.74316373481048 43.358 35.66771545787206 139.74315920398368 45.357 35.66771545787206 139.74315920398368 42.892</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68462c36-8bfe-4df4-b7a3-e7c698257a50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68462c36-8bfe-4df4-b7a3-e7c698257a50_0">
											<gml:posList>35.66771545787206 139.74315920398368 45.357 35.66772349250273 139.74316373481048 43.358 35.66773046305022 139.74316764826463 45.357 35.66771545787206 139.74315920398368 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-296359d0-9ade-4ae2-a254-9888fb5d86f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-296359d0-9ade-4ae2-a254-9888fb5d86f3_0">
											<gml:posList>35.66772349250273 139.74316373481048 43.358 35.66773046305022 139.74316764826463 43.358 35.66773046305022 139.74316764826463 45.357 35.66772349250273 139.74316373481048 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4b7dced-af3c-43d7-b31c-2f9272c06e28">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4b7dced-af3c-43d7-b31c-2f9272c06e28_0">
											<gml:posList>35.66778348418265 139.74315874087662 43.358 35.66777895030453 139.74317081914552 45.357 35.66778348418265 139.74315874087662 45.357 35.66778348418265 139.74315874087662 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbd0d1a4-babb-44c3-a3b4-a6183e744a6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbd0d1a4-babb-44c3-a3b4-a6183e744a6b_0">
											<gml:posList>35.66778348418265 139.74315874087662 43.358 35.66777895030453 139.74317081914552 43.358 35.66777895030453 139.74317081914552 45.357 35.66778348418265 139.74315874087662 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5eef8b5-3641-42a8-87a5-91756f3e19bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5eef8b5-3641-42a8-87a5-91756f3e19bf_0">
											<gml:posList>35.66778348418265 139.74315874087662 45.357 35.66777895030453 139.74317081914552 45.357 35.66779442439402 139.74317952800976 45.357 35.66778348418265 139.74315874087662 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18caf51e-ecaa-4fb7-b490-358527fbbbd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18caf51e-ecaa-4fb7-b490-358527fbbbd5_0">
											<gml:posList>35.66779894925928 139.7431674497492 45.357 35.66778348418265 139.74315874087662 45.357 35.66779442439402 139.74317952800976 45.357 35.66779894925928 139.7431674497492 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0ceb2a0-5f45-41ac-8d71-22a07cafa5bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0ceb2a0-5f45-41ac-8d71-22a07cafa5bc_0">
											<gml:posList>35.66779894925928 139.7431674497492 45.357 35.66779442439402 139.74317952800976 42.571 35.66779894925928 139.7431674497492 42.57 35.66779894925928 139.7431674497492 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4982144-2029-4fcd-b991-1242caee3913">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4982144-2029-4fcd-b991-1242caee3913_0">
											<gml:posList>35.66779894925928 139.7431674497492 45.357 35.66779442439402 139.74317952800976 45.357 35.66779442439402 139.74317952800976 42.571 35.66779894925928 139.7431674497492 45.357</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36cc0541-ab2c-4027-8b73-05a971c14644">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36cc0541-ab2c-4027-8b73-05a971c14644_0">
											<gml:posList>35.66779442439402 139.74317952800976 42.571 35.66779442439402 139.74317952800976 45.357 35.667780104549585 139.74317146955585 43.358 35.66779442439402 139.74317952800976 42.571</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-572ba038-849b-455f-9734-27d37d22031f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-572ba038-849b-455f-9734-27d37d22031f_0">
											<gml:posList>35.667780104549585 139.74317146955585 43.358 35.66777895030453 139.74317081914552 45.357 35.66777895030453 139.74317081914552 43.358 35.667780104549585 139.74317146955585 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80af9970-1782-4938-9b72-3dba7d5660eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80af9970-1782-4938-9b72-3dba7d5660eb_0">
											<gml:posList>35.667780104549585 139.74317146955585 43.358 35.66779442439402 139.74317952800976 45.357 35.66777895030453 139.74317081914552 45.357 35.667780104549585 139.74317146955585 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d7c6c2f-92f6-4b56-8cde-832c0020688c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d7c6c2f-92f6-4b56-8cde-832c0020688c_0">
											<gml:posList>35.66779325440728 139.74295346386796 43.358 35.667808978104794 139.74294644304106 45.357 35.667808978104794 139.74294644304106 42.547 35.66779325440728 139.74295346386796 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddbdf816-4eeb-45d8-b8e5-aec8c95e7eb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddbdf816-4eeb-45d8-b8e5-aec8c95e7eb8_0">
											<gml:posList>35.66779325440728 139.74295346386796 43.358 35.667793209355224 139.74295348601052 45.357 35.667808978104794 139.74294644304106 45.357 35.66779325440728 139.74295346386796 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eebdd17b-3463-4e23-afe1-cea584d05454">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667789866035825 139.74284649916407 42.132 35.667786600501955 139.7428550855153 42.388 35.66778265982663 139.74285285868962 42.538 35.667789866035825 139.74284649916407 42.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e0f8c8a-b92b-4376-8fdf-25a48b530a8f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66761141766038 139.74279392333108 42.674 35.667625318283676 139.74278385588465 43.358 35.66762018247494 139.74279853061213 42.689 35.66761141766038 139.74279392333108 42.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76032064-3d0f-48a5-82c4-f6ed024821e6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66761141766038 139.74279392333108 42.674 35.667616679394946 139.74277889499456 43.358 35.667625318283676 139.74278385588465 43.358 35.66761141766038 139.74279392333108 42.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98bb4cda-a549-4b42-946c-2373c4e5deb3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667616679394946 139.74277889499456 43.358 35.66762684733634 139.74277949103524 43.15 35.667625318283676 139.74278385588465 43.358 35.667616679394946 139.74277889499456 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19499e4f-dd17-4d1d-9df9-7eccac11ab04">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667616679394946 139.74277889499456 43.358 35.66761808251277 139.74277487271 43.167 35.66762684733634 139.74277949103524 43.15 35.667616679394946 139.74277889499456 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d1c433c-67c9-4d3b-abbd-c700d72fdfeb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667719398009524 139.74314868386244 42.889 35.66772349250273 139.74316373481048 43.358 35.66771545787206 139.74315920398368 42.892 35.667719398009524 139.74314868386244 42.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d29ea785-6da5-44da-b4b8-ca51d67883b5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667719398009524 139.74314868386244 42.889 35.6677274957615 139.74315324775512 43.358 35.66772349250273 139.74316373481048 43.358 35.667719398009524 139.74314868386244 42.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39b664a4-4693-4d6d-a647-d2eb9b8b52fe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66771971473585 139.7428379625311 43.358 35.66773236644888 139.74284520540562 43.358 35.667724490866355 139.7428604244889 42.614 35.66771971473585 139.7428379625311 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-458403f5-fee3-4a46-9d35-192b85736501">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66771971473585 139.7428379625311 43.358 35.667724490866355 139.7428604244889 42.614 35.66771380536684 139.74285480314023 42.594 35.66771971473585 139.7428379625311 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8fb8db0-d5d4-4953-8e50-2daaa66dd1d6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66773236644888 139.74284520540562 43.358 35.66772662797452 139.7428615598047 42.713 35.667724490866355 139.7428604244889 42.614 35.66773236644888 139.74284520540562 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14f8d821-88bd-41f9-a036-c7426569d9ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667735334628695 139.74283675194616 42.956 35.66771971473585 139.7428379625311 43.358 35.667722512027936 139.7428300063308 42.98 35.667735334628695 139.74283675194616 42.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e66c745e-76d1-4e2a-8cb3-df1ee0f0cb48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667735334628695 139.74283675194616 42.956 35.66773236644888 139.74284520540562 43.358 35.66771971473585 139.7428379625311 43.358 35.667735334628695 139.74283675194616 42.956</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-030d49c7-3441-40b6-9163-3ed549ce4f7f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66773046305022 139.74316764826463 43.358 35.6677274957615 139.74315324775512 43.358 35.66773440319668 139.7431571391877 43.358 35.66773046305022 139.74316764826463 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2121773-255e-4e15-b1fa-893998fcefcd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66773046305022 139.74316764826463 43.358 35.66772349250273 139.74316373481048 43.358 35.6677274957615 139.74315324775512 43.358 35.66773046305022 139.74316764826463 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4014586-004d-4bdc-991d-5b19479783d1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66777844051294 139.74301977806468 43.358 35.667766161405126 139.74302859547672 42.926 35.66777102808925 139.74301560001717 42.909 35.66777844051294 139.74301977806468 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00b8be4c-8ce0-4893-be5e-18f29106ef6c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66777844051294 139.74301977806468 43.358 35.66777350168543 139.74303272942282 43.358 35.667766161405126 139.74302859547672 42.926 35.66777844051294 139.74301977806468 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-626a3321-4511-409a-9588-07a5812f2ff2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66779799840692 139.7428251493005 41.123 35.667789866035825 139.74284649916407 42.132 35.66777212697229 139.74281047640915 41.123 35.66779799840692 139.7428251493005 41.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-407812aa-9258-4aa4-be9b-fd971f8d6c5d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66777212697229 139.74281047640915 41.123 35.667789866035825 139.74284649916407 42.132 35.66776072907091 139.74284041261637 42.538 35.66777212697229 139.74281047640915 41.123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17db8051-3bfe-4904-a0df-b26f7712f2dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667789866035825 139.74284649916407 42.132 35.66778265982663 139.74285285868962 42.538 35.66776072907091 139.74284041261637 42.538 35.667789866035825 139.74284649916407 42.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-337cef30-7c3e-4d87-a774-16d333ae6e3b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66777895030453 139.74317081914552 43.358 35.66778446710078 139.7431593031123 43.358 35.667780104549585 139.74317146955585 43.358 35.66777895030453 139.74317081914552 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7f12944-7216-48ba-b5ee-37838f9716e8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66777895030453 139.74317081914552 43.358 35.66778348418265 139.74315874087662 43.358 35.66778446710078 139.7431593031123 43.358 35.66777895030453 139.74317081914552 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-386d28c2-e2f3-4b8e-b410-b25a9334103f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66777844051294 139.74301977806468 43.358 35.66778640577932 139.74303998309463 43.358 35.66777350168543 139.74303272942282 43.358 35.66777844051294 139.74301977806468 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a6b685a9-03be-4e8c-ba0c-e831d5ce196b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66777844051294 139.74301977806468 43.358 35.66779127247294 139.74302699867835 43.358 35.66778640577932 139.74303998309463 43.358 35.66777844051294 139.74301977806468 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0d3966c-9d08-4d58-a9df-4997f648ae9c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66779894925928 139.7431674497492 42.57 35.667780104549585 139.74317146955585 43.358 35.66778446710078 139.7431593031123 43.358 35.66779894925928 139.7431674497492 42.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b1021ff-965a-489f-816e-7e0e2c7b5f9b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66779894925928 139.7431674497492 42.57 35.66779442439402 139.74317952800976 42.571 35.667780104549585 139.74317146955585 43.358 35.66779894925928 139.7431674497492 42.57</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-539c932b-e582-4f17-8733-d3af8d7c4550">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667808978104794 139.74294644304106 42.547 35.667812665015916 139.74295884343752 42.541 35.667794646169035 139.74295832249678 43.358 35.667808978104794 139.74294644304106 42.547</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7558b716-ce33-4b55-8cb9-a062e132282d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667808978104794 139.74294644304106 42.547 35.667794646169035 139.74295832249678 43.358 35.66779325440728 139.74295346386796 43.358 35.667808978104794 139.74294644304106 42.547</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a836dd37-fda6-4662-bb97-2a71b0f18ead">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667812665015916 139.74295884343752 42.541 35.667796896265614 139.74296588640485 43.354 35.667794646169035 139.74295832249678 43.358 35.667812665015916 139.74295884343752 42.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_408080ff-4936-45ac-9ae4-2d9cfd2a6f8e_BuildingInstallation_1030">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6731edda-0e3a-4639-bded-f37bcaa86141">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66788493513863 139.74300422697368 41.251 35.66788790175686 139.74300569273862 41.1 35.66788334180577 139.74301904134154 41.1 35.667880528479046 139.74301765272494 41.243 35.66788493513863 139.74300422697368 41.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2d47f90-a36a-408b-97de-78a2e01744d4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66789750761495 139.74302601745214 41.1 35.66788334180577 139.74301904134154 41.1 35.66788790175686 139.74300569273862 41.1 35.667901914275454 139.74301259169846 41.1 35.66789750761495 139.74302601745214 41.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dabfba66-451a-4283-b51e-9b49fd224dae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dabfba66-451a-4283-b51e-9b49fd224dae_0">
											<gml:posList>35.66789750761495 139.74302601745214 44.693 35.667901914275454 139.74301259169846 44.693 35.66788493513863 139.74300422697368 44.693 35.667880528479046 139.74301765272494 44.693 35.66789750761495 139.74302601745214 44.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1abbb8ff-ff33-45c9-ab15-d78bc289f28b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1abbb8ff-ff33-45c9-ab15-d78bc289f28b_0">
											<gml:posList>35.667901914275454 139.74301259169846 41.1 35.667901914275454 139.74301259169846 44.693 35.66789750761495 139.74302601745214 44.693 35.66789750761495 139.74302601745214 41.1 35.667901914275454 139.74301259169846 41.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaf13426-f187-48d3-a5e7-0dfdbbbc78f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aaf13426-f187-48d3-a5e7-0dfdbbbc78f7_0">
											<gml:posList>35.66789750761495 139.74302601745214 44.693 35.667880528479046 139.74301765272494 44.693 35.667880528479046 139.74301765272494 41.243 35.66788334180577 139.74301904134154 41.1 35.66789750761495 139.74302601745214 41.1 35.66789750761495 139.74302601745214 44.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93867170-4c5f-46d8-9d4c-9c9ac337b33f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-93867170-4c5f-46d8-9d4c-9c9ac337b33f_0">
											<gml:posList>35.667880528479046 139.74301765272494 44.693 35.66788493513863 139.74300422697368 44.693 35.66788493513863 139.74300422697368 41.251 35.667880528479046 139.74301765272494 41.243 35.667880528479046 139.74301765272494 44.693</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72be42ef-66a8-4748-b32f-b5e7b40e63f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72be42ef-66a8-4748-b32f-b5e7b40e63f8_0">
											<gml:posList>35.66788790175686 139.74300569273862 41.1 35.66788493513863 139.74300422697368 41.251 35.66788493513863 139.74300422697368 44.693 35.667901914275454 139.74301259169846 44.693 35.667901914275454 139.74301259169846 41.1 35.66788790175686 139.74300569273862 41.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-fecf62c3-8ce8-4665-8005-30598c70ea96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fecf62c3-8ce8-4665-8005-30598c70ea96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fecf62c3-8ce8-4665-8005-30598c70ea96">
											<gml:posList>35.667789062834984 139.74327805244457 27.72 35.667592935078645 139.74317245322322 27.72 35.667689529560974 139.74312871335047 27.72 35.667739192515135 139.7430048329894 27.72 35.6677046732683 139.74288922139533 27.72 35.667558948267896 139.74280532668482 27.72 35.6675530596928 139.74276589957628 27.72 35.667568895434776 139.74272810480676 27.72 35.66759898898278 139.7427117229056 27.72 35.667808196842635 139.74283034041053 27.72 35.66784055301691 139.74294617548483 27.72 35.667916387723565 139.74298508209992 27.72 35.66790379187303 139.74301624578254 27.72 35.667916787462204 139.74303732885267 27.72 35.66791852441775 139.74306980190318 27.72 35.66791231620587 139.74308483134254 27.72 35.6679036730442 139.74309820663188 27.72 35.66789051904484 139.7431062849538 27.72 35.667870417109114 139.74310454022697 27.72 35.66785707033678 139.7430959394341 27.72 35.667789062834984 139.74327805244457 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-846ef56d-20bc-4360-8330-df5b0adc49b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-846ef56d-20bc-4360-8330-df5b0adc49b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-846ef56d-20bc-4360-8330-df5b0adc49b9">
											<gml:posList>35.667568895434776 139.74272810480676 41.1 35.6675530596928 139.74276589957628 41.1 35.667601800323396 139.74277037333476 43.358 35.667568895434776 139.74272810480676 41.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4c202dd2-e930-4b97-a09c-14eeec4dba28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c202dd2-e930-4b97-a09c-14eeec4dba28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c202dd2-e930-4b97-a09c-14eeec4dba28">
											<gml:posList>35.667601800323396 139.74277037333476 43.358 35.6675530596928 139.74276589957628 41.1 35.667558948267896 139.74280532668482 41.1 35.667601800323396 139.74277037333476 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dff162cb-f142-4932-a7e7-a6d47565debd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dff162cb-f142-4932-a7e7-a6d47565debd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dff162cb-f142-4932-a7e7-a6d47565debd">
											<gml:posList>35.667601800323396 139.74277037333476 43.358 35.66759898898278 139.7427117229056 41.1 35.667568895434776 139.74272810480676 41.1 35.667601800323396 139.74277037333476 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-438ce352-1d1c-451e-991d-bb4f681989a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-438ce352-1d1c-451e-991d-bb4f681989a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-438ce352-1d1c-451e-991d-bb4f681989a6">
											<gml:posList>35.6676607547178 139.74320897198396 36.9 35.667689529560974 139.74312871335047 36.9 35.667592935078645 139.74317245322322 36.9 35.6676607547178 139.74320897198396 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-014a8b44-babd-425f-8439-e810a9649f32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-014a8b44-babd-425f-8439-e810a9649f32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-014a8b44-babd-425f-8439-e810a9649f32">
											<gml:posList>35.66773422408184 139.74284627476115 43.358 35.667601800323396 139.74277037333476 43.358 35.667558948267896 139.74280532668482 41.1 35.66773422408184 139.74284627476115 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eabe7855-c3fe-4cf4-b61e-dccf78273d6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eabe7855-c3fe-4cf4-b61e-dccf78273d6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eabe7855-c3fe-4cf4-b61e-dccf78273d6f">
											<gml:posList>35.66773422408184 139.74284627476115 43.358 35.667558948267896 139.74280532668482 41.1 35.6677046732683 139.74288922139533 41.1 35.66773422408184 139.74284627476115 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4db194a0-79ba-4f40-814f-35d471c3fd07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4db194a0-79ba-4f40-814f-35d471c3fd07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4db194a0-79ba-4f40-814f-35d471c3fd07">
											<gml:posList>35.667689529560974 139.74312871335047 41.1 35.6676607547178 139.74320897198396 41.1 35.66771891349752 139.74317573579955 43.358 35.667689529560974 139.74312871335047 41.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0d43816-9196-4bea-b2be-b98e82ab7e26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0d43816-9196-4bea-b2be-b98e82ab7e26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0d43816-9196-4bea-b2be-b98e82ab7e26">
											<gml:posList>35.66759898898278 139.7427117229056 41.1 35.667601800323396 139.74277037333476 43.358 35.66773422408184 139.74284627476115 43.358 35.66776810327057 139.74286568835893 43.358 35.667808196842635 139.74283034041053 41.1 35.66759898898278 139.7427117229056 41.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d305d3be-d495-40ce-ac72-8187dbcff811">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d305d3be-d495-40ce-ac72-8187dbcff811">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d305d3be-d495-40ce-ac72-8187dbcff811">
											<gml:posList>35.667767745487595 139.74320594666005 43.358 35.66771891349752 139.74317573579955 43.358 35.6676607547178 139.74320897198396 41.1 35.667767745487595 139.74320594666005 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-122c2e37-9cbb-4d50-9cbb-e9019ab65f06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-122c2e37-9cbb-4d50-9cbb-e9019ab65f06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-122c2e37-9cbb-4d50-9cbb-e9019ab65f06">
											<gml:posList>35.6676607547178 139.74320897198396 41.1 35.667789062834984 139.74327805244457 41.1 35.667767745487595 139.74320594666005 43.358 35.6676607547178 139.74320897198396 41.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-23604e68-4fe5-49ea-9376-ca10adff9439">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23604e68-4fe5-49ea-9376-ca10adff9439">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23604e68-4fe5-49ea-9376-ca10adff9439">
											<gml:posList>35.667689529560974 139.74312871335047 41.1 35.66771891349752 139.74317573579955 43.358 35.66778088744157 139.74301336868575 43.358 35.667689529560974 139.74312871335047 41.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3264b77a-b0be-4783-b244-06db1d66e447">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3264b77a-b0be-4783-b244-06db1d66e447">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3264b77a-b0be-4783-b244-06db1d66e447">
											<gml:posList>35.667689529560974 139.74312871335047 41.1 35.66778088744157 139.74301336868575 43.358 35.667739192515135 139.7430048329894 41.1 35.667689529560974 139.74312871335047 41.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2930fd73-7f77-49eb-b6c2-e242c3fbdd30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2930fd73-7f77-49eb-b6c2-e242c3fbdd30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2930fd73-7f77-49eb-b6c2-e242c3fbdd30">
											<gml:posList>35.66773422408184 139.74284627476115 43.358 35.6677046732683 139.74288922139533 41.1 35.66778088744157 139.74301336868575 43.358 35.66773422408184 139.74284627476115 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3e83654c-7f61-493a-b0dd-ab72b06ecddd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e83654c-7f61-493a-b0dd-ab72b06ecddd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e83654c-7f61-493a-b0dd-ab72b06ecddd">
											<gml:posList>35.6677046732683 139.74288922139533 41.1 35.667739192515135 139.7430048329894 41.1 35.66778088744157 139.74301336868575 43.358 35.6677046732683 139.74288922139533 41.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94bf4f3f-e5d3-49d9-9fed-de10d27e12d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94bf4f3f-e5d3-49d9-9fed-de10d27e12d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94bf4f3f-e5d3-49d9-9fed-de10d27e12d5">
											<gml:posList>35.66780127961872 139.74298146723598 43.358 35.66776810327057 139.74286568835893 43.358 35.66773422408184 139.74284627476115 43.358 35.66778088744157 139.74301336868575 43.358 35.66771891349752 139.74317573579955 43.358 35.667767745487595 139.74320594666005 43.358 35.66784063145183 139.7430026531334 43.358 35.66780127961872 139.74298146723598 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab889b44-2fbe-4cb9-bcdd-2de13fbe89c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab889b44-2fbe-4cb9-bcdd-2de13fbe89c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab889b44-2fbe-4cb9-bcdd-2de13fbe89c2">
											<gml:posList>35.66776810327057 139.74286568835893 43.358 35.66780127961872 139.74298146723598 43.358 35.66784055301691 139.74294617548483 41.1 35.667808196842635 139.74283034041053 41.1 35.66776810327057 139.74286568835893 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45be2874-9757-41f6-9bfe-741e0939c381">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45be2874-9757-41f6-9bfe-741e0939c381">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45be2874-9757-41f6-9bfe-741e0939c381">
											<gml:posList>35.667767745487595 139.74320594666005 43.358 35.667789062834984 139.74327805244457 41.1 35.66785707033678 139.7430959394341 41.1 35.667767745487595 139.74320594666005 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b101d56-5c41-4706-9bef-71876297370c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b101d56-5c41-4706-9bef-71876297370c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b101d56-5c41-4706-9bef-71876297370c">
											<gml:posList>35.667767745487595 139.74320594666005 43.358 35.66785707033678 139.7430959394341 41.1 35.6678981369034 139.74297572467987 41.1 35.667767745487595 139.74320594666005 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26a8061f-ee70-4c19-852f-166e6f7e72fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26a8061f-ee70-4c19-852f-166e6f7e72fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26a8061f-ee70-4c19-852f-166e6f7e72fe">
											<gml:posList>35.667767745487595 139.74320594666005 43.358 35.6678981369034 139.74297572467987 41.1 35.66784063145183 139.7430026531334 43.358 35.667767745487595 139.74320594666005 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f810c2f-563e-4ba5-84fc-21a6661e75ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f810c2f-563e-4ba5-84fc-21a6661e75ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f810c2f-563e-4ba5-84fc-21a6661e75ee">
											<gml:posList>35.66784063145183 139.7430026531334 43.358 35.6678981369034 139.74297572467987 41.1 35.66784055301691 139.74294617548483 41.1 35.66780127961872 139.74298146723598 43.358 35.66784063145183 139.7430026531334 43.358</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-90d60fc8-baf1-420c-94f3-9925dcebe848">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90d60fc8-baf1-420c-94f3-9925dcebe848">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90d60fc8-baf1-420c-94f3-9925dcebe848">
											<gml:posList>35.66791231620587 139.74308483134254 41.1 35.66791852441775 139.74306980190318 41.1 35.667916787462204 139.74303732885267 41.1 35.66790379187303 139.74301624578254 41.1 35.667916387723565 139.74298508209992 41.1 35.6678981369034 139.74297572467987 41.1 35.66785707033678 139.7430959394341 41.1 35.667870417109114 139.74310454022697 41.1 35.66789051904484 139.7431062849538 41.1 35.6679036730442 139.74309820663188 41.1 35.66791231620587 139.74308483134254 41.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a49a2bcd-f3a9-4e1b-8fce-8d7716782a9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a49a2bcd-f3a9-4e1b-8fce-8d7716782a9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a49a2bcd-f3a9-4e1b-8fce-8d7716782a9c">
											<gml:posList>35.66759898898278 139.7427117229056 27.72 35.667568895434776 139.74272810480676 27.72 35.667568895434776 139.74272810480676 41.1 35.66759898898278 139.7427117229056 41.1 35.66759898898278 139.7427117229056 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c15ffee-62e9-443f-9ecb-69dfb1ac6195">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c15ffee-62e9-443f-9ecb-69dfb1ac6195">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c15ffee-62e9-443f-9ecb-69dfb1ac6195">
											<gml:posList>35.667568895434776 139.74272810480676 27.72 35.6675530596928 139.74276589957628 27.72 35.6675530596928 139.74276589957628 41.1 35.667568895434776 139.74272810480676 41.1 35.667568895434776 139.74272810480676 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68318d1d-1131-4a81-ba66-6f756793b0ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68318d1d-1131-4a81-ba66-6f756793b0ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68318d1d-1131-4a81-ba66-6f756793b0ba">
											<gml:posList>35.667808196842635 139.74283034041053 27.72 35.66759898898278 139.7427117229056 27.72 35.66759898898278 139.7427117229056 41.1 35.667808196842635 139.74283034041053 41.1 35.667808196842635 139.74283034041053 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8395aca-e521-48af-b8eb-58693a7660e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8395aca-e521-48af-b8eb-58693a7660e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8395aca-e521-48af-b8eb-58693a7660e6">
											<gml:posList>35.6675530596928 139.74276589957628 27.72 35.667558948267896 139.74280532668482 27.72 35.667558948267896 139.74280532668482 41.1 35.6675530596928 139.74276589957628 41.1 35.6675530596928 139.74276589957628 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33747eb8-a8c7-4c8b-a073-8ad1bafecfcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33747eb8-a8c7-4c8b-a073-8ad1bafecfcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33747eb8-a8c7-4c8b-a073-8ad1bafecfcf">
											<gml:posList>35.667558948267896 139.74280532668482 27.72 35.6677046732683 139.74288922139533 27.72 35.6677046732683 139.74288922139533 41.1 35.667558948267896 139.74280532668482 41.1 35.667558948267896 139.74280532668482 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e058425-2816-4dd4-abfd-7b980e29e6d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e058425-2816-4dd4-abfd-7b980e29e6d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e058425-2816-4dd4-abfd-7b980e29e6d6">
											<gml:posList>35.6677046732683 139.74288922139533 27.72 35.667739192515135 139.7430048329894 27.72 35.667739192515135 139.7430048329894 41.1 35.6677046732683 139.74288922139533 41.1 35.6677046732683 139.74288922139533 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9492f58-ddfa-423f-9a30-0f9cbb06d128">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9492f58-ddfa-423f-9a30-0f9cbb06d128">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9492f58-ddfa-423f-9a30-0f9cbb06d128">
											<gml:posList>35.667689529560974 139.74312871335047 27.72 35.667592935078645 139.74317245322322 27.72 35.667592935078645 139.74317245322322 36.9 35.667689529560974 139.74312871335047 36.9 35.667689529560974 139.74312871335047 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d88ac592-83fc-4319-b6d5-5b2742259a50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d88ac592-83fc-4319-b6d5-5b2742259a50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d88ac592-83fc-4319-b6d5-5b2742259a50">
											<gml:posList>35.6676607547178 139.74320897198396 36.9 35.6676607547178 139.74320897198396 41.1 35.667689529560974 139.74312871335047 41.1 35.667689529560974 139.74312871335047 36.9 35.6676607547178 139.74320897198396 36.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21c1baf3-10fd-4d43-8afd-4cb644c3cf9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21c1baf3-10fd-4d43-8afd-4cb644c3cf9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21c1baf3-10fd-4d43-8afd-4cb644c3cf9c">
											<gml:posList>35.667789062834984 139.74327805244457 27.72 35.667789062834984 139.74327805244457 41.1 35.6676607547178 139.74320897198396 41.1 35.6676607547178 139.74320897198396 36.9 35.667592935078645 139.74317245322322 36.9 35.667592935078645 139.74317245322322 27.72 35.667789062834984 139.74327805244457 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3add9e8-2953-4dad-b86b-864f198dfaa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3add9e8-2953-4dad-b86b-864f198dfaa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3add9e8-2953-4dad-b86b-864f198dfaa4">
											<gml:posList>35.667739192515135 139.7430048329894 41.1 35.667739192515135 139.7430048329894 27.72 35.667689529560974 139.74312871335047 27.72 35.667689529560974 139.74312871335047 36.9 35.667689529560974 139.74312871335047 41.1 35.667739192515135 139.7430048329894 41.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba0cad62-6cbc-45a9-b099-2b26f33d186a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba0cad62-6cbc-45a9-b099-2b26f33d186a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba0cad62-6cbc-45a9-b099-2b26f33d186a">
											<gml:posList>35.66784055301691 139.74294617548483 27.72 35.667808196842635 139.74283034041053 27.72 35.667808196842635 139.74283034041053 41.1 35.66784055301691 139.74294617548483 41.1 35.66784055301691 139.74294617548483 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f4585a3-97ed-4b4a-9ec8-cf845d8c26c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f4585a3-97ed-4b4a-9ec8-cf845d8c26c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f4585a3-97ed-4b4a-9ec8-cf845d8c26c5">
											<gml:posList>35.667916387723565 139.74298508209992 27.72 35.66784055301691 139.74294617548483 27.72 35.66784055301691 139.74294617548483 41.1 35.6678981369034 139.74297572467987 41.1 35.667916387723565 139.74298508209992 41.1 35.667916387723565 139.74298508209992 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd56afcb-2344-4a80-8cac-c531321e95d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd56afcb-2344-4a80-8cac-c531321e95d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd56afcb-2344-4a80-8cac-c531321e95d2">
											<gml:posList>35.66790379187303 139.74301624578254 27.72 35.667916387723565 139.74298508209992 27.72 35.667916387723565 139.74298508209992 41.1 35.66790379187303 139.74301624578254 41.1 35.66790379187303 139.74301624578254 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-882a9311-3ac7-4173-9a2a-4f3d81b29d40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-882a9311-3ac7-4173-9a2a-4f3d81b29d40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-882a9311-3ac7-4173-9a2a-4f3d81b29d40">
											<gml:posList>35.667916787462204 139.74303732885267 27.72 35.66790379187303 139.74301624578254 27.72 35.66790379187303 139.74301624578254 41.1 35.667916787462204 139.74303732885267 41.1 35.667916787462204 139.74303732885267 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1425c12f-aa4f-4667-82a5-b7111ac865db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1425c12f-aa4f-4667-82a5-b7111ac865db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1425c12f-aa4f-4667-82a5-b7111ac865db">
											<gml:posList>35.66791852441775 139.74306980190318 27.72 35.667916787462204 139.74303732885267 27.72 35.667916787462204 139.74303732885267 41.1 35.66791852441775 139.74306980190318 41.1 35.66791852441775 139.74306980190318 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3dc5e771-d948-48a8-9f45-ee283d729916">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3dc5e771-d948-48a8-9f45-ee283d729916">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3dc5e771-d948-48a8-9f45-ee283d729916">
											<gml:posList>35.66791231620587 139.74308483134254 27.72 35.66791852441775 139.74306980190318 27.72 35.66791852441775 139.74306980190318 41.1 35.66791231620587 139.74308483134254 41.1 35.66791231620587 139.74308483134254 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-143250dd-b839-4e45-84f9-835aa66073f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-143250dd-b839-4e45-84f9-835aa66073f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-143250dd-b839-4e45-84f9-835aa66073f0">
											<gml:posList>35.6679036730442 139.74309820663188 27.72 35.66791231620587 139.74308483134254 27.72 35.66791231620587 139.74308483134254 41.1 35.6679036730442 139.74309820663188 41.1 35.6679036730442 139.74309820663188 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b23c1fe-d975-40d4-9ac8-795df70f3524">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b23c1fe-d975-40d4-9ac8-795df70f3524">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b23c1fe-d975-40d4-9ac8-795df70f3524">
											<gml:posList>35.66785707033678 139.7430959394341 27.72 35.667870417109114 139.74310454022697 27.72 35.667870417109114 139.74310454022697 41.1 35.66785707033678 139.7430959394341 41.1 35.66785707033678 139.7430959394341 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46e06239-be21-4fc3-bf0d-a224a659fad8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46e06239-be21-4fc3-bf0d-a224a659fad8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46e06239-be21-4fc3-bf0d-a224a659fad8">
											<gml:posList>35.66789051904484 139.7431062849538 27.72 35.6679036730442 139.74309820663188 27.72 35.6679036730442 139.74309820663188 41.1 35.66789051904484 139.7431062849538 41.1 35.66789051904484 139.7431062849538 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dcd53e96-ba9b-4966-8a5a-35d81e70744f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dcd53e96-ba9b-4966-8a5a-35d81e70744f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dcd53e96-ba9b-4966-8a5a-35d81e70744f">
											<gml:posList>35.667870417109114 139.74310454022697 27.72 35.66789051904484 139.7431062849538 27.72 35.66789051904484 139.7431062849538 41.1 35.667870417109114 139.74310454022697 41.1 35.667870417109114 139.74310454022697 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-149d01dc-cbe5-4970-81f6-eb71af2d88af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-149d01dc-cbe5-4970-81f6-eb71af2d88af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-149d01dc-cbe5-4970-81f6-eb71af2d88af">
											<gml:posList>35.667789062834984 139.74327805244457 27.72 35.66785707033678 139.7430959394341 27.72 35.66785707033678 139.7430959394341 41.1 35.667789062834984 139.74327805244457 41.1 35.667789062834984 139.74327805244457 27.72</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2117</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">862.6156</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1110</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">22</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>