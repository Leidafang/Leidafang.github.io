<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_408a20ad-7407-4588-bbd3-815c64986b87">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">36.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67002875146554 139.74143059873438 0 35.66999035512192 139.74155159869917 0 35.670050344190535 139.74161427252483 0 35.67008284846906 139.7415679516861 0 35.670089867123885 139.74143395301002 0 35.67002875146554 139.74143059873438 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002875146554 139.74143059873438 8.482 35.670089867123885 139.74143395301002 8.482 35.67008284846906 139.7415679516861 8.482 35.670050344190535 139.74161427252483 8.482 35.66999035512192 139.74155159869917 8.482 35.67002875146554 139.74143059873438 8.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002875146554 139.74143059873438 8.482 35.66999035512192 139.74155159869917 8.482 35.66999035512192 139.74155159869917 44.83 35.67002875146554 139.74143059873438 44.83 35.67002875146554 139.74143059873438 8.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66999035512192 139.74155159869917 8.482 35.670050344190535 139.74161427252483 8.482 35.670050344190535 139.74161427252483 44.83 35.66999035512192 139.74155159869917 44.83 35.66999035512192 139.74155159869917 8.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670050344190535 139.74161427252483 8.482 35.67008284846906 139.7415679516861 8.482 35.67008284846906 139.7415679516861 44.83 35.670050344190535 139.74161427252483 44.83 35.670050344190535 139.74161427252483 8.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67008284846906 139.7415679516861 8.482 35.670089867123885 139.74143395301002 8.482 35.670089867123885 139.74143395301002 44.83 35.67008284846906 139.7415679516861 44.83 35.67008284846906 139.7415679516861 8.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670089867123885 139.74143395301002 8.482 35.67002875146554 139.74143059873438 8.482 35.67002875146554 139.74143059873438 44.83 35.670089867123885 139.74143395301002 44.83 35.670089867123885 139.74143395301002 8.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002875146554 139.74143059873438 44.83 35.66999035512192 139.74155159869917 44.83 35.670050344190535 139.74161427252483 44.83 35.67008284846906 139.7415679516861 44.83 35.670089867123885 139.74143395301002 44.83 35.67002875146554 139.74143059873438 44.83</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2e4e92ed-7b7b-4f52-aefd-88a0ff5089bf"/>
							<gml:surfaceMember xlink:href="#poly-de0371af-f36e-4ef2-928d-ae7a76783ae6"/>
							<gml:surfaceMember xlink:href="#poly-6d058893-ad1e-456b-aaa9-b8fae988bde1"/>
							<gml:surfaceMember xlink:href="#poly-077886f9-5242-46f2-8e83-1ceefdd0b804"/>
							<gml:surfaceMember xlink:href="#poly-54c3ec3c-2860-42ac-baff-19da22b2eaa3"/>
							<gml:surfaceMember xlink:href="#poly-f8eccf6f-57f4-4a95-b1ba-b44328953aac"/>
							<gml:surfaceMember xlink:href="#poly-cf9ab6aa-726e-47c6-a0cb-33c4f7e9039a"/>
							<gml:surfaceMember xlink:href="#poly-7abd7e11-a881-4dcb-859e-e8b0ab729df4"/>
							<gml:surfaceMember xlink:href="#poly-a745559f-9dc9-4fef-8153-aa114be548b1"/>
							<gml:surfaceMember xlink:href="#poly-f508ea3a-3ad6-44d5-842b-8be44682bb79"/>
							<gml:surfaceMember xlink:href="#poly-69090595-6aae-4666-9181-20409cf9c307"/>
							<gml:surfaceMember xlink:href="#poly-a3c2a15e-731d-452c-bd30-82004b83c0e3"/>
							<gml:surfaceMember xlink:href="#poly-2994c994-bb5d-4706-946c-66931ee6070b"/>
							<gml:surfaceMember xlink:href="#poly-35634399-f96e-416c-9d71-5819b801118d"/>
							<gml:surfaceMember xlink:href="#poly-1797b50b-006f-4c3b-815a-ea8a752ee9e1"/>
							<gml:surfaceMember xlink:href="#poly-6c5a5950-ae26-47bd-aa7e-791bb6865266"/>
							<gml:surfaceMember xlink:href="#poly-478629ac-70af-40b3-87fc-f7b77129f9d2"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_408a20ad-7407-4588-bbd3-815c64986b87_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91746cf9-36c6-4229-9a65-51fd62ae75f7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006332948086 139.7414441680381 49.157 35.670062947420284 139.74145141479357 49.157 35.67003811310343 139.74144946598085 49.157 35.67003848615017 139.74144221923797 49.157 35.67006332948086 139.7414441680381 49.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b7fa741-045c-4234-827a-fbe46cc6510a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006191579808 139.7414579111506 49.157 35.670075130405436 139.74145853668878 49.157 35.670074391337224 139.74148224271823 49.157 35.67006117672998 139.74148161717613 49.157 35.67006191579808 139.7414579111506 49.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe0d9bbf-836f-4b59-a6ef-1a7b094fce32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe0d9bbf-836f-4b59-a6ef-1a7b094fce32_0">
											<gml:posList>35.67006332948086 139.7414441680381 49.157 35.67003848615017 139.74144221923797 49.157 35.67003848615017 139.74144221923797 50.199 35.67006332948086 139.7414441680381 50.199 35.67006332948086 139.7414441680381 49.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d71d9f43-7ffe-4fb5-8700-d45e87d7a905">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d71d9f43-7ffe-4fb5-8700-d45e87d7a905_0">
											<gml:posList>35.67003848615017 139.74144221923797 49.157 35.67003811310343 139.74144946598085 49.157 35.67003811310343 139.74144946598085 50.199 35.67003848615017 139.74144221923797 50.199 35.67003848615017 139.74144221923797 49.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a98ef74f-1915-49f0-a763-f280820bfcd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a98ef74f-1915-49f0-a763-f280820bfcd1_0">
											<gml:posList>35.67006332948086 139.7414441680381 50.199 35.67003848615017 139.74144221923797 50.199 35.67003811310343 139.74144946598085 50.199 35.670062947420284 139.74145141479357 50.199 35.67006332948086 139.7414441680381 50.199</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3a396e8-db95-4dc0-a944-2703da5529cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3a396e8-db95-4dc0-a944-2703da5529cb_0">
											<gml:posList>35.670062947420284 139.74145141479357 49.157 35.67006332948086 139.7414441680381 49.157 35.67006332948086 139.7414441680381 50.199 35.670062947420284 139.74145141479357 50.199 35.670062947420284 139.74145141479357 49.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3823da9-bf5c-407b-bb41-c7f76ec02697">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3823da9-bf5c-407b-bb41-c7f76ec02697_0">
											<gml:posList>35.67003811310343 139.74144946598085 49.157 35.670062947420284 139.74145141479357 49.157 35.670062947420284 139.74145141479357 50.199 35.67003811310343 139.74144946598085 50.199 35.67003811310343 139.74144946598085 49.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06221178-0b4a-4683-b539-c185cd548e66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06221178-0b4a-4683-b539-c185cd548e66_0">
											<gml:posList>35.670075130405436 139.74145853668878 49.157 35.67006191579808 139.7414579111506 49.157 35.67006191579808 139.7414579111506 49.715 35.670075130405436 139.74145853668878 49.715 35.670075130405436 139.74145853668878 49.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c1b2cf7-ac98-40b7-8d8e-a48284aa5af0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c1b2cf7-ac98-40b7-8d8e-a48284aa5af0_0">
											<gml:posList>35.67006191579808 139.7414579111506 49.157 35.67006117672998 139.74148161717613 49.157 35.67006117672998 139.74148161717613 49.715 35.67006191579808 139.7414579111506 49.715 35.67006191579808 139.7414579111506 49.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e2b7274-c490-4319-bb60-e972500c7a06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e2b7274-c490-4319-bb60-e972500c7a06_0">
											<gml:posList>35.67006191579808 139.7414579111506 49.715 35.67006117672998 139.74148161717613 49.715 35.670074391337224 139.74148224271823 49.715 35.670075130405436 139.74145853668878 49.715 35.67006191579808 139.7414579111506 49.715</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f44f13b-a2f1-4459-a672-1bde4caa91f6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5f44f13b-a2f1-4459-a672-1bde4caa91f6_0">
											<gml:posList>35.670074391337224 139.74148224271823 49.157 35.670075130405436 139.74145853668878 49.157 35.670075130405436 139.74145853668878 49.715 35.670074391337224 139.74148224271823 49.715 35.670074391337224 139.74148224271823 49.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c37dc726-d8ba-4d7f-a6a5-aff7c7084c07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c37dc726-d8ba-4d7f-a6a5-aff7c7084c07_0">
											<gml:posList>35.67006117672998 139.74148161717613 49.157 35.670074391337224 139.74148224271823 49.157 35.670074391337224 139.74148224271823 49.715 35.67006117672998 139.74148161717613 49.715 35.67006117672998 139.74148161717613 49.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2e4e92ed-7b7b-4f52-aefd-88a0ff5089bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2e4e92ed-7b7b-4f52-aefd-88a0ff5089bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2e4e92ed-7b7b-4f52-aefd-88a0ff5089bf">
											<gml:posList>35.670028751465544 139.74143059873438 8.482 35.67008986712385 139.74143395301002 8.482 35.670082848469065 139.7415679516861 8.482 35.670050344190535 139.74161427252483 8.482 35.669990355121904 139.74155159869915 8.482 35.670028751465544 139.74143059873438 8.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de0371af-f36e-4ef2-928d-ae7a76783ae6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de0371af-f36e-4ef2-928d-ae7a76783ae6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de0371af-f36e-4ef2-928d-ae7a76783ae6">
											<gml:posList>35.670028751465544 139.74143059873438 51.966 35.67003286763314 139.74143833741073 51.966 35.67008335565612 139.7414411073768 51.966 35.67008986712385 139.74143395301002 51.966 35.670028751465544 139.74143059873438 51.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d058893-ad1e-456b-aaa9-b8fae988bde1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d058893-ad1e-456b-aaa9-b8fae988bde1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d058893-ad1e-456b-aaa9-b8fae988bde1">
											<gml:posList>35.669990355121904 139.74155159869915 51.966 35.66999764550663 139.74154933692753 51.966 35.67003286763314 139.74143833741073 51.966 35.670028751465544 139.74143059873438 51.966 35.669990355121904 139.74155159869915 51.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-077886f9-5242-46f2-8e83-1ceefdd0b804">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-077886f9-5242-46f2-8e83-1ceefdd0b804">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-077886f9-5242-46f2-8e83-1ceefdd0b804">
											<gml:posList>35.670082848469065 139.7415679516861 51.966 35.67008986712385 139.74143395301002 51.966 35.67008335565612 139.7414411073768 51.966 35.67007686107536 139.74156496501374 51.966 35.670082848469065 139.7415679516861 51.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54c3ec3c-2860-42ac-baff-19da22b2eaa3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54c3ec3c-2860-42ac-baff-19da22b2eaa3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54c3ec3c-2860-42ac-baff-19da22b2eaa3">
											<gml:posList>35.67007686107536 139.74156496501374 49.157 35.67008335565612 139.7414411073768 49.157 35.67003286763314 139.74143833741073 49.157 35.66999764550663 139.74154933692753 49.157 35.67004967814457 139.74160371310614 49.157 35.67007686107536 139.74156496501374 49.157</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f8eccf6f-57f4-4a95-b1ba-b44328953aac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8eccf6f-57f4-4a95-b1ba-b44328953aac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8eccf6f-57f4-4a95-b1ba-b44328953aac">
											<gml:posList>35.669990355121904 139.74155159869915 51.966 35.670050344190535 139.74161427252483 51.966 35.67004967814457 139.74160371310614 51.966 35.66999764550663 139.74154933692753 51.966 35.669990355121904 139.74155159869915 51.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cf9ab6aa-726e-47c6-a0cb-33c4f7e9039a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf9ab6aa-726e-47c6-a0cb-33c4f7e9039a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf9ab6aa-726e-47c6-a0cb-33c4f7e9039a">
											<gml:posList>35.670082848469065 139.7415679516861 51.966 35.67007686107536 139.74156496501374 51.966 35.67004967814457 139.74160371310614 51.966 35.670050344190535 139.74161427252483 51.966 35.670082848469065 139.7415679516861 51.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7abd7e11-a881-4dcb-859e-e8b0ab729df4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7abd7e11-a881-4dcb-859e-e8b0ab729df4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7abd7e11-a881-4dcb-859e-e8b0ab729df4">
											<gml:posList>35.670028751465544 139.74143059873438 8.482 35.669990355121904 139.74155159869915 8.482 35.669990355121904 139.74155159869915 51.966 35.670028751465544 139.74143059873438 51.966 35.670028751465544 139.74143059873438 8.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a745559f-9dc9-4fef-8153-aa114be548b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a745559f-9dc9-4fef-8153-aa114be548b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a745559f-9dc9-4fef-8153-aa114be548b1">
											<gml:posList>35.66999764550663 139.74154933692753 51.966 35.66999764550663 139.74154933692753 49.157 35.67003286763314 139.74143833741073 49.157 35.67003286763314 139.74143833741073 51.966 35.66999764550663 139.74154933692753 51.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f508ea3a-3ad6-44d5-842b-8be44682bb79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f508ea3a-3ad6-44d5-842b-8be44682bb79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f508ea3a-3ad6-44d5-842b-8be44682bb79">
											<gml:posList>35.669990355121904 139.74155159869915 8.482 35.670050344190535 139.74161427252483 8.482 35.670050344190535 139.74161427252483 51.966 35.669990355121904 139.74155159869915 51.966 35.669990355121904 139.74155159869915 8.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69090595-6aae-4666-9181-20409cf9c307">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69090595-6aae-4666-9181-20409cf9c307">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69090595-6aae-4666-9181-20409cf9c307">
											<gml:posList>35.67004967814457 139.74160371310614 51.966 35.67004967814457 139.74160371310614 49.157 35.66999764550663 139.74154933692753 49.157 35.66999764550663 139.74154933692753 51.966 35.67004967814457 139.74160371310614 51.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a3c2a15e-731d-452c-bd30-82004b83c0e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3c2a15e-731d-452c-bd30-82004b83c0e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3c2a15e-731d-452c-bd30-82004b83c0e3">
											<gml:posList>35.67003286763314 139.74143833741073 51.966 35.67003286763314 139.74143833741073 49.157 35.67008335565612 139.7414411073768 49.157 35.67008335565612 139.7414411073768 51.966 35.67003286763314 139.74143833741073 51.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2994c994-bb5d-4706-946c-66931ee6070b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2994c994-bb5d-4706-946c-66931ee6070b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2994c994-bb5d-4706-946c-66931ee6070b">
											<gml:posList>35.67008986712385 139.74143395301002 8.482 35.670028751465544 139.74143059873438 8.482 35.670028751465544 139.74143059873438 51.966 35.67008986712385 139.74143395301002 51.966 35.67008986712385 139.74143395301002 8.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35634399-f96e-416c-9d71-5819b801118d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35634399-f96e-416c-9d71-5819b801118d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35634399-f96e-416c-9d71-5819b801118d">
											<gml:posList>35.67007686107536 139.74156496501374 51.966 35.67007686107536 139.74156496501374 49.157 35.67004967814457 139.74160371310614 49.157 35.67004967814457 139.74160371310614 51.966 35.67007686107536 139.74156496501374 51.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1797b50b-006f-4c3b-815a-ea8a752ee9e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1797b50b-006f-4c3b-815a-ea8a752ee9e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1797b50b-006f-4c3b-815a-ea8a752ee9e1">
											<gml:posList>35.670050344190535 139.74161427252483 8.482 35.670082848469065 139.7415679516861 8.482 35.670082848469065 139.7415679516861 51.966 35.670050344190535 139.74161427252483 51.966 35.670050344190535 139.74161427252483 8.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c5a5950-ae26-47bd-aa7e-791bb6865266">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c5a5950-ae26-47bd-aa7e-791bb6865266">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c5a5950-ae26-47bd-aa7e-791bb6865266">
											<gml:posList>35.67008335565612 139.7414411073768 51.966 35.67008335565612 139.7414411073768 49.157 35.67007686107536 139.74156496501374 49.157 35.67007686107536 139.74156496501374 51.966 35.67008335565612 139.7414411073768 51.966</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-478629ac-70af-40b3-87fc-f7b77129f9d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-478629ac-70af-40b3-87fc-f7b77129f9d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-478629ac-70af-40b3-87fc-f7b77129f9d2">
											<gml:posList>35.670082848469065 139.7415679516861 8.482 35.67008986712385 139.74143395301002 8.482 35.67008986712385 139.74143395301002 51.966 35.670082848469065 139.7415679516861 51.966 35.670082848469065 139.7415679516861 8.482</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2854</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">90.1696</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>