<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_424be4b8-7a45-41c6-a6cf-8b1b048e1263">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66716129869243 139.74107191385627 0 35.667161658310626 139.74107069840278 0 35.667162197103075 139.74106804678692 0 35.66716237636203 139.74106672108275 0 35.667162463452364 139.7410627444887 0 35.66716210087187 139.74106009391 0 35.66716182952902 139.74105887918248 0 35.66716110648396 139.7410563394768 0 35.66716065486649 139.7410551249568 0 35.667160113111734 139.74105391054047 0 35.66715884949687 139.7410517028315 0 35.66715740586139 139.74104982670423 0 35.66715569189871 139.7410480613463 0 35.667153888052674 139.74104662746637 0 35.66715190418605 139.7410455251681 0 35.66714974029883 139.7410447544515 0 35.667147666802826 139.74104431500538 0 35.6671443317236 139.7410443188438 0 35.667142168767555 139.74104476316572 0 35.66714009620278 139.74104553875796 0 35.66713811402921 139.74104664562054 0 35.667135411603965 139.74104885789325 0 35.66713388070932 139.74105073744317 0 35.667132440036596 139.74105272734735 0 35.66713136016683 139.7410550482106 0 35.667130820274274 139.74105626387117 0 35.667130460656246 139.74105747932433 0 35.66712983164207 139.74106002058485 0 35.66712947312433 139.74106267199224 0 35.667129475240266 139.7410654334427 0 35.667129747683354 139.74106808412404 0 35.667130290453564 139.74107062403618 0 35.667131013498285 139.74107316374102 0 35.66713209692281 139.741075482115 0 35.66713272873002 139.7410765859693 0 35.6671341724497 139.7410785725545 0 35.66713579627466 139.74108033801633 0 35.66713669823981 139.74108111018552 0 35.667138502085436 139.74108254406596 0 35.66714057600437 139.7410835358032 0 35.66714156785291 139.74108397649468 0 35.667143731570654 139.74108452629616 0 35.66714598508723 139.7410846341618 0 35.667148148297244 139.74108452121507 0 35.66714922977531 139.74108429905462 0 35.66715130234037 139.7410835234633 0 35.66715238364919 139.74108308038672 0 35.66715526660351 139.74108119928147 0 35.66715697794244 139.74107954044032 0 35.66715778850094 139.74107865584253 0 35.667159138952194 139.74107655558387 0 35.66716039918151 139.74107434497074 0 35.66716129869243 139.74107191385627 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716129869243 139.74107191385627 24.269 35.66716039918151 139.74107434497074 24.269 35.667159138952194 139.74107655558387 24.269 35.66715778850094 139.74107865584253 24.269 35.66715697794244 139.74107954044032 24.269 35.66715526660351 139.74108119928147 24.269 35.66715238364919 139.74108308038672 24.269 35.66715130234037 139.7410835234633 24.269 35.66714922977531 139.74108429905462 24.269 35.667148148297244 139.74108452121507 24.269 35.66714598508723 139.7410846341618 24.269 35.667143731570654 139.74108452629616 24.269 35.66714156785291 139.74108397649468 24.269 35.66714057600437 139.7410835358032 24.269 35.667138502085436 139.74108254406596 24.269 35.66713669823981 139.74108111018552 24.269 35.66713579627466 139.74108033801633 24.269 35.6671341724497 139.7410785725545 24.269 35.66713272873002 139.7410765859693 24.269 35.66713209692281 139.741075482115 24.269 35.667131013498285 139.74107316374102 24.269 35.667130290453564 139.74107062403618 24.269 35.667129747683354 139.74106808412404 24.269 35.667129475240266 139.7410654334427 24.269 35.66712947312433 139.74106267199224 24.269 35.66712983164207 139.74106002058485 24.269 35.667130460656246 139.74105747932433 24.269 35.667130820274274 139.74105626387117 24.269 35.66713136016683 139.7410550482106 24.269 35.667132440036596 139.74105272734735 24.269 35.66713388070932 139.74105073744317 24.269 35.667135411603965 139.74104885789325 24.269 35.66713811402921 139.74104664562054 24.269 35.66714009620278 139.74104553875796 24.269 35.667142168767555 139.74104476316572 24.269 35.6671443317236 139.7410443188438 24.269 35.667147666802826 139.74104431500538 24.269 35.66714974029883 139.7410447544515 24.269 35.66715190418605 139.7410455251681 24.269 35.667153888052674 139.74104662746637 24.269 35.66715569189871 139.7410480613463 24.269 35.66715740586139 139.74104982670423 24.269 35.66715884949687 139.7410517028315 24.269 35.667160113111734 139.74105391054047 24.269 35.66716065486649 139.7410551249568 24.269 35.66716110648396 139.7410563394768 24.269 35.66716182952902 139.74105887918248 24.269 35.66716210087187 139.74106009391 24.269 35.667162463452364 139.7410627444887 24.269 35.66716237636203 139.74106672108275 24.269 35.667162197103075 139.74106804678692 24.269 35.667161658310626 139.74107069840278 24.269 35.66716129869243 139.74107191385627 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716129869243 139.74107191385627 24.269 35.667161658310626 139.74107069840278 24.269 35.667161658310626 139.74107069840278 27.269 35.66716129869243 139.74107191385627 27.269 35.66716129869243 139.74107191385627 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667161658310626 139.74107069840278 24.269 35.667162197103075 139.74106804678692 24.269 35.667162197103075 139.74106804678692 27.269 35.667161658310626 139.74107069840278 27.269 35.667161658310626 139.74107069840278 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667162197103075 139.74106804678692 24.269 35.66716237636203 139.74106672108275 24.269 35.66716237636203 139.74106672108275 27.269 35.667162197103075 139.74106804678692 27.269 35.667162197103075 139.74106804678692 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716237636203 139.74106672108275 24.269 35.667162463452364 139.7410627444887 24.269 35.667162463452364 139.7410627444887 27.269 35.66716237636203 139.74106672108275 27.269 35.66716237636203 139.74106672108275 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667162463452364 139.7410627444887 24.269 35.66716210087187 139.74106009391 24.269 35.66716210087187 139.74106009391 27.269 35.667162463452364 139.7410627444887 27.269 35.667162463452364 139.7410627444887 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716210087187 139.74106009391 24.269 35.66716182952902 139.74105887918248 24.269 35.66716182952902 139.74105887918248 27.269 35.66716210087187 139.74106009391 27.269 35.66716210087187 139.74106009391 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716182952902 139.74105887918248 24.269 35.66716110648396 139.7410563394768 24.269 35.66716110648396 139.7410563394768 27.269 35.66716182952902 139.74105887918248 27.269 35.66716182952902 139.74105887918248 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716110648396 139.7410563394768 24.269 35.66716065486649 139.7410551249568 24.269 35.66716065486649 139.7410551249568 27.269 35.66716110648396 139.7410563394768 27.269 35.66716110648396 139.7410563394768 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716065486649 139.7410551249568 24.269 35.667160113111734 139.74105391054047 24.269 35.667160113111734 139.74105391054047 27.269 35.66716065486649 139.7410551249568 27.269 35.66716065486649 139.7410551249568 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667160113111734 139.74105391054047 24.269 35.66715884949687 139.7410517028315 24.269 35.66715884949687 139.7410517028315 27.269 35.667160113111734 139.74105391054047 27.269 35.667160113111734 139.74105391054047 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715884949687 139.7410517028315 24.269 35.66715740586139 139.74104982670423 24.269 35.66715740586139 139.74104982670423 27.269 35.66715884949687 139.7410517028315 27.269 35.66715884949687 139.7410517028315 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715740586139 139.74104982670423 24.269 35.66715569189871 139.7410480613463 24.269 35.66715569189871 139.7410480613463 27.269 35.66715740586139 139.74104982670423 27.269 35.66715740586139 139.74104982670423 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715569189871 139.7410480613463 24.269 35.667153888052674 139.74104662746637 24.269 35.667153888052674 139.74104662746637 27.269 35.66715569189871 139.7410480613463 27.269 35.66715569189871 139.7410480613463 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667153888052674 139.74104662746637 24.269 35.66715190418605 139.7410455251681 24.269 35.66715190418605 139.7410455251681 27.269 35.667153888052674 139.74104662746637 27.269 35.667153888052674 139.74104662746637 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715190418605 139.7410455251681 24.269 35.66714974029883 139.7410447544515 24.269 35.66714974029883 139.7410447544515 27.269 35.66715190418605 139.7410455251681 27.269 35.66715190418605 139.7410455251681 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714974029883 139.7410447544515 24.269 35.667147666802826 139.74104431500538 24.269 35.667147666802826 139.74104431500538 27.269 35.66714974029883 139.7410447544515 27.269 35.66714974029883 139.7410447544515 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667147666802826 139.74104431500538 24.269 35.6671443317236 139.7410443188438 24.269 35.6671443317236 139.7410443188438 27.269 35.667147666802826 139.74104431500538 27.269 35.667147666802826 139.74104431500538 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671443317236 139.7410443188438 24.269 35.667142168767555 139.74104476316572 24.269 35.667142168767555 139.74104476316572 27.269 35.6671443317236 139.7410443188438 27.269 35.6671443317236 139.7410443188438 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667142168767555 139.74104476316572 24.269 35.66714009620278 139.74104553875796 24.269 35.66714009620278 139.74104553875796 27.269 35.667142168767555 139.74104476316572 27.269 35.667142168767555 139.74104476316572 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714009620278 139.74104553875796 24.269 35.66713811402921 139.74104664562054 24.269 35.66713811402921 139.74104664562054 27.269 35.66714009620278 139.74104553875796 27.269 35.66714009620278 139.74104553875796 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713811402921 139.74104664562054 24.269 35.667135411603965 139.74104885789325 24.269 35.667135411603965 139.74104885789325 27.269 35.66713811402921 139.74104664562054 27.269 35.66713811402921 139.74104664562054 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667135411603965 139.74104885789325 24.269 35.66713388070932 139.74105073744317 24.269 35.66713388070932 139.74105073744317 27.269 35.667135411603965 139.74104885789325 27.269 35.667135411603965 139.74104885789325 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713388070932 139.74105073744317 24.269 35.667132440036596 139.74105272734735 24.269 35.667132440036596 139.74105272734735 27.269 35.66713388070932 139.74105073744317 27.269 35.66713388070932 139.74105073744317 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667132440036596 139.74105272734735 24.269 35.66713136016683 139.7410550482106 24.269 35.66713136016683 139.7410550482106 27.269 35.667132440036596 139.74105272734735 27.269 35.667132440036596 139.74105272734735 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713136016683 139.7410550482106 24.269 35.667130820274274 139.74105626387117 24.269 35.667130820274274 139.74105626387117 27.269 35.66713136016683 139.7410550482106 27.269 35.66713136016683 139.7410550482106 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667130820274274 139.74105626387117 24.269 35.667130460656246 139.74105747932433 24.269 35.667130460656246 139.74105747932433 27.269 35.667130820274274 139.74105626387117 27.269 35.667130820274274 139.74105626387117 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667130460656246 139.74105747932433 24.269 35.66712983164207 139.74106002058485 24.269 35.66712983164207 139.74106002058485 27.269 35.667130460656246 139.74105747932433 27.269 35.667130460656246 139.74105747932433 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66712983164207 139.74106002058485 24.269 35.66712947312433 139.74106267199224 24.269 35.66712947312433 139.74106267199224 27.269 35.66712983164207 139.74106002058485 27.269 35.66712983164207 139.74106002058485 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66712947312433 139.74106267199224 24.269 35.667129475240266 139.7410654334427 24.269 35.667129475240266 139.7410654334427 27.269 35.66712947312433 139.74106267199224 27.269 35.66712947312433 139.74106267199224 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667129475240266 139.7410654334427 24.269 35.667129747683354 139.74106808412404 24.269 35.667129747683354 139.74106808412404 27.269 35.667129475240266 139.7410654334427 27.269 35.667129475240266 139.7410654334427 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667129747683354 139.74106808412404 24.269 35.667130290453564 139.74107062403618 24.269 35.667130290453564 139.74107062403618 27.269 35.667129747683354 139.74106808412404 27.269 35.667129747683354 139.74106808412404 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667130290453564 139.74107062403618 24.269 35.667131013498285 139.74107316374102 24.269 35.667131013498285 139.74107316374102 27.269 35.667130290453564 139.74107062403618 27.269 35.667130290453564 139.74107062403618 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667131013498285 139.74107316374102 24.269 35.66713209692281 139.741075482115 24.269 35.66713209692281 139.741075482115 27.269 35.667131013498285 139.74107316374102 27.269 35.667131013498285 139.74107316374102 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713209692281 139.741075482115 24.269 35.66713272873002 139.7410765859693 24.269 35.66713272873002 139.7410765859693 27.269 35.66713209692281 139.741075482115 27.269 35.66713209692281 139.741075482115 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713272873002 139.7410765859693 24.269 35.6671341724497 139.7410785725545 24.269 35.6671341724497 139.7410785725545 27.269 35.66713272873002 139.7410765859693 27.269 35.66713272873002 139.7410765859693 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671341724497 139.7410785725545 24.269 35.66713579627466 139.74108033801633 24.269 35.66713579627466 139.74108033801633 27.269 35.6671341724497 139.7410785725545 27.269 35.6671341724497 139.7410785725545 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713579627466 139.74108033801633 24.269 35.66713669823981 139.74108111018552 24.269 35.66713669823981 139.74108111018552 27.269 35.66713579627466 139.74108033801633 27.269 35.66713579627466 139.74108033801633 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713669823981 139.74108111018552 24.269 35.667138502085436 139.74108254406596 24.269 35.667138502085436 139.74108254406596 27.269 35.66713669823981 139.74108111018552 27.269 35.66713669823981 139.74108111018552 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667138502085436 139.74108254406596 24.269 35.66714057600437 139.7410835358032 24.269 35.66714057600437 139.7410835358032 27.269 35.667138502085436 139.74108254406596 27.269 35.667138502085436 139.74108254406596 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714057600437 139.7410835358032 24.269 35.66714156785291 139.74108397649468 24.269 35.66714156785291 139.74108397649468 27.269 35.66714057600437 139.7410835358032 27.269 35.66714057600437 139.7410835358032 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714156785291 139.74108397649468 24.269 35.667143731570654 139.74108452629616 24.269 35.667143731570654 139.74108452629616 27.269 35.66714156785291 139.74108397649468 27.269 35.66714156785291 139.74108397649468 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667143731570654 139.74108452629616 24.269 35.66714598508723 139.7410846341618 24.269 35.66714598508723 139.7410846341618 27.269 35.667143731570654 139.74108452629616 27.269 35.667143731570654 139.74108452629616 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714598508723 139.7410846341618 24.269 35.667148148297244 139.74108452121507 24.269 35.667148148297244 139.74108452121507 27.269 35.66714598508723 139.7410846341618 27.269 35.66714598508723 139.7410846341618 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667148148297244 139.74108452121507 24.269 35.66714922977531 139.74108429905462 24.269 35.66714922977531 139.74108429905462 27.269 35.667148148297244 139.74108452121507 27.269 35.667148148297244 139.74108452121507 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714922977531 139.74108429905462 24.269 35.66715130234037 139.7410835234633 24.269 35.66715130234037 139.7410835234633 27.269 35.66714922977531 139.74108429905462 27.269 35.66714922977531 139.74108429905462 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715130234037 139.7410835234633 24.269 35.66715238364919 139.74108308038672 24.269 35.66715238364919 139.74108308038672 27.269 35.66715130234037 139.7410835234633 27.269 35.66715130234037 139.7410835234633 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715238364919 139.74108308038672 24.269 35.66715526660351 139.74108119928147 24.269 35.66715526660351 139.74108119928147 27.269 35.66715238364919 139.74108308038672 27.269 35.66715238364919 139.74108308038672 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715526660351 139.74108119928147 24.269 35.66715697794244 139.74107954044032 24.269 35.66715697794244 139.74107954044032 27.269 35.66715526660351 139.74108119928147 27.269 35.66715526660351 139.74108119928147 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715697794244 139.74107954044032 24.269 35.66715778850094 139.74107865584253 24.269 35.66715778850094 139.74107865584253 27.269 35.66715697794244 139.74107954044032 27.269 35.66715697794244 139.74107954044032 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715778850094 139.74107865584253 24.269 35.667159138952194 139.74107655558387 24.269 35.667159138952194 139.74107655558387 27.269 35.66715778850094 139.74107865584253 27.269 35.66715778850094 139.74107865584253 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667159138952194 139.74107655558387 24.269 35.66716039918151 139.74107434497074 24.269 35.66716039918151 139.74107434497074 27.269 35.667159138952194 139.74107655558387 27.269 35.667159138952194 139.74107655558387 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716039918151 139.74107434497074 24.269 35.66716129869243 139.74107191385627 24.269 35.66716129869243 139.74107191385627 27.269 35.66716039918151 139.74107434497074 27.269 35.66716039918151 139.74107434497074 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716129869243 139.74107191385627 27.269 35.667161658310626 139.74107069840278 27.269 35.667162197103075 139.74106804678692 27.269 35.66716237636203 139.74106672108275 27.269 35.667162463452364 139.7410627444887 27.269 35.66716210087187 139.74106009391 27.269 35.66716182952902 139.74105887918248 27.269 35.66716110648396 139.7410563394768 27.269 35.66716065486649 139.7410551249568 27.269 35.667160113111734 139.74105391054047 27.269 35.66715884949687 139.7410517028315 27.269 35.66715740586139 139.74104982670423 27.269 35.66715569189871 139.7410480613463 27.269 35.667153888052674 139.74104662746637 27.269 35.66715190418605 139.7410455251681 27.269 35.66714974029883 139.7410447544515 27.269 35.667147666802826 139.74104431500538 27.269 35.6671443317236 139.7410443188438 27.269 35.667142168767555 139.74104476316572 27.269 35.66714009620278 139.74104553875796 27.269 35.66713811402921 139.74104664562054 27.269 35.667135411603965 139.74104885789325 27.269 35.66713388070932 139.74105073744317 27.269 35.667132440036596 139.74105272734735 27.269 35.66713136016683 139.7410550482106 27.269 35.667130820274274 139.74105626387117 27.269 35.667130460656246 139.74105747932433 27.269 35.66712983164207 139.74106002058485 27.269 35.66712947312433 139.74106267199224 27.269 35.667129475240266 139.7410654334427 27.269 35.667129747683354 139.74106808412404 27.269 35.667130290453564 139.74107062403618 27.269 35.667131013498285 139.74107316374102 27.269 35.66713209692281 139.741075482115 27.269 35.66713272873002 139.7410765859693 27.269 35.6671341724497 139.7410785725545 27.269 35.66713579627466 139.74108033801633 27.269 35.66713669823981 139.74108111018552 27.269 35.667138502085436 139.74108254406596 27.269 35.66714057600437 139.7410835358032 27.269 35.66714156785291 139.74108397649468 27.269 35.667143731570654 139.74108452629616 27.269 35.66714598508723 139.7410846341618 27.269 35.667148148297244 139.74108452121507 27.269 35.66714922977531 139.74108429905462 27.269 35.66715130234037 139.7410835234633 27.269 35.66715238364919 139.74108308038672 27.269 35.66715526660351 139.74108119928147 27.269 35.66715697794244 139.74107954044032 27.269 35.66715778850094 139.74107865584253 27.269 35.667159138952194 139.74107655558387 27.269 35.66716039918151 139.74107434497074 27.269 35.66716129869243 139.74107191385627 27.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-22d9e5a3-ba20-4480-a205-d0a26836f1fb"/>
							<gml:surfaceMember xlink:href="#poly-89cf3457-4201-46f9-89ea-53d8d72e8b17"/>
							<gml:surfaceMember xlink:href="#poly-75269497-b99d-452c-97c0-3a6c1aa2e86e"/>
							<gml:surfaceMember xlink:href="#poly-0b54dce3-1ecb-463c-b7d6-4b7ed64dde0c"/>
							<gml:surfaceMember xlink:href="#poly-dec23e1c-c2e9-45b9-913e-9c163f50a767"/>
							<gml:surfaceMember xlink:href="#poly-8d86625f-fe08-4e96-96e1-4ed618aec683"/>
							<gml:surfaceMember xlink:href="#poly-e23f5909-f24d-4db3-8859-61b85d6173df"/>
							<gml:surfaceMember xlink:href="#poly-e5b81bf8-e9b8-4502-a153-dcbc547a20da"/>
							<gml:surfaceMember xlink:href="#poly-48882086-6765-4436-b489-ea04bfb77c9b"/>
							<gml:surfaceMember xlink:href="#poly-04fddea2-72b3-4a8d-8c19-df0022b89bf9"/>
							<gml:surfaceMember xlink:href="#poly-343022af-c774-401d-b010-b5f072672169"/>
							<gml:surfaceMember xlink:href="#poly-dc199452-5080-4a98-9d56-97ccc3d1b9ce"/>
							<gml:surfaceMember xlink:href="#poly-482f9261-05b8-4d3c-8cd5-4dd39ea6b927"/>
							<gml:surfaceMember xlink:href="#poly-c9f2bb85-4af7-4094-beb3-aa561221e0d1"/>
							<gml:surfaceMember xlink:href="#poly-55a89b10-cc40-4b9f-88e7-d4822f06bbc8"/>
							<gml:surfaceMember xlink:href="#poly-4e081422-483e-4396-9abf-f17b744e7fe0"/>
							<gml:surfaceMember xlink:href="#poly-b00bc628-d061-4a8d-bbdd-362f621cc3fa"/>
							<gml:surfaceMember xlink:href="#poly-f878aad7-afb3-4f42-8043-f7dc9688520c"/>
							<gml:surfaceMember xlink:href="#poly-c2ce2b50-3b28-4492-b536-101f5328e7d1"/>
							<gml:surfaceMember xlink:href="#poly-cad658ff-c961-4eab-aaa6-90a3a7d8ac41"/>
							<gml:surfaceMember xlink:href="#poly-6e9e8cfa-1ad6-4e42-a08d-11465479a88f"/>
							<gml:surfaceMember xlink:href="#poly-378fa422-5fc7-41d7-8851-6e2af6aa810d"/>
							<gml:surfaceMember xlink:href="#poly-8a30aa90-59c9-4093-8d02-1f350ecfa44e"/>
							<gml:surfaceMember xlink:href="#poly-9c5f93ef-de1b-4926-bece-326d09664d94"/>
							<gml:surfaceMember xlink:href="#poly-021ec0e2-ba21-4709-ac94-f9e7984218ba"/>
							<gml:surfaceMember xlink:href="#poly-03e9e73d-a70a-4160-a4cf-dd50ff059eb9"/>
							<gml:surfaceMember xlink:href="#poly-bd37b959-ff8c-4ef0-b18d-4e9b394b2a80"/>
							<gml:surfaceMember xlink:href="#poly-d9e791c6-86ea-48b6-bcca-83936d908666"/>
							<gml:surfaceMember xlink:href="#poly-7dc3ae6d-7b20-488c-9858-2f9d25484e00"/>
							<gml:surfaceMember xlink:href="#poly-658e0b94-166c-4495-b423-c166b103b2f3"/>
							<gml:surfaceMember xlink:href="#poly-c9eeed4b-8348-4c7d-91ca-e7082425d80e"/>
							<gml:surfaceMember xlink:href="#poly-88ba7af6-b0b8-4896-923b-d55b7f72ee50"/>
							<gml:surfaceMember xlink:href="#poly-6be0700d-40ab-4d1f-be44-27ebbdee8b1c"/>
							<gml:surfaceMember xlink:href="#poly-c7701e2f-f645-4ec5-af2c-6b02ceb9531e"/>
							<gml:surfaceMember xlink:href="#poly-4faed0da-287b-4c91-85a0-965ba4a79080"/>
							<gml:surfaceMember xlink:href="#poly-d4e70500-526f-4f80-90dc-29e859fb48de"/>
							<gml:surfaceMember xlink:href="#poly-81595dff-5b12-436b-9b82-64b6be3ee693"/>
							<gml:surfaceMember xlink:href="#poly-3b816472-9941-4d06-9446-6edd09c4500f"/>
							<gml:surfaceMember xlink:href="#poly-4e8b6f8f-70f3-49c9-9198-4f8b147a8716"/>
							<gml:surfaceMember xlink:href="#poly-2903cf71-9867-499c-ab11-e8c5b7bc9aed"/>
							<gml:surfaceMember xlink:href="#poly-23483b9c-15f0-4a28-bc02-878ab9b137be"/>
							<gml:surfaceMember xlink:href="#poly-cbea8886-8a76-4c66-9b34-f111f8333457"/>
							<gml:surfaceMember xlink:href="#poly-92c3aa67-8e83-46e3-b94d-3d4efbae3980"/>
							<gml:surfaceMember xlink:href="#poly-3736b3c8-9cc6-467a-be55-4aca8bb24a68"/>
							<gml:surfaceMember xlink:href="#poly-e9fe24b3-d99f-4a2f-99b3-13697f14fab4"/>
							<gml:surfaceMember xlink:href="#poly-6bcd4436-990a-4bf2-896e-553a2e537014"/>
							<gml:surfaceMember xlink:href="#poly-d4fda5a9-fe78-4fda-82bf-7b080ef8f224"/>
							<gml:surfaceMember xlink:href="#poly-15d8c154-a2ba-462c-a419-fffdd6fe6ce0"/>
							<gml:surfaceMember xlink:href="#poly-302f18ea-0003-43e0-91c7-769e7b3667bd"/>
							<gml:surfaceMember xlink:href="#poly-4ba7ad95-76a8-4b79-9d4a-1f8e5a0730a7"/>
							<gml:surfaceMember xlink:href="#poly-36f8b0a6-82ff-4dcf-9e0d-34b9033d2bdb"/>
							<gml:surfaceMember xlink:href="#poly-3f5bb552-0204-4dab-beb4-53fe3fa85594"/>
							<gml:surfaceMember xlink:href="#poly-dd38bcee-a24c-465b-acc4-a0f6863351d3"/>
							<gml:surfaceMember xlink:href="#poly-d4401693-f022-4c89-a397-7fcf79591045"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-22d9e5a3-ba20-4480-a205-d0a26836f1fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22d9e5a3-ba20-4480-a205-d0a26836f1fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22d9e5a3-ba20-4480-a205-d0a26836f1fb">
											<gml:posList>35.667161298692434 139.74107191385627 24.269 35.66716039918151 139.74107434497074 24.269 35.66715913895219 139.74107655558387 24.269 35.66715778850091 139.74107865584253 24.269 35.66715697794241 139.74107954044032 24.269 35.667155266603494 139.74108119928147 24.269 35.667152383649196 139.74108308038672 24.269 35.66715130234035 139.7410835234633 24.269 35.66714922977532 139.74108429905462 24.269 35.66714814829722 139.74108452121507 24.269 35.6671459850872 139.7410846341618 24.269 35.667143731570654 139.74108452629616 24.269 35.66714156785291 139.74108397649468 24.269 35.66714057600438 139.7410835358032 24.269 35.66713850208542 139.74108254406593 24.269 35.667136698239794 139.74108111018552 24.269 35.667135796274664 139.7410803380163 24.269 35.6671341724497 139.7410785725545 24.269 35.667132728730024 139.7410765859693 24.269 35.6671320969228 139.741075482115 24.269 35.667131013498285 139.74107316374102 24.269 35.667130290453564 139.7410706240362 24.269 35.66712974768334 139.74106808412404 24.269 35.66712947524026 139.7410654334427 24.269 35.66712947312432 139.7410626719922 24.269 35.667129831642065 139.74106002058485 24.269 35.66713046065623 139.74105747932433 24.269 35.66713082027425 139.7410562638712 24.269 35.66713136016682 139.74105504821057 24.269 35.66713244003655 139.74105272734732 24.269 35.66713388070931 139.74105073744317 24.269 35.66713541160395 139.74104885789325 24.269 35.66713811402921 139.74104664562054 24.269 35.66714009620277 139.74104553875796 24.269 35.66714216876755 139.7410447631657 24.269 35.66714433172358 139.7410443188438 24.269 35.667147666802826 139.74104431500535 24.269 35.66714974029882 139.7410447544515 24.269 35.66715190418605 139.7410455251681 24.269 35.66715388805268 139.74104662746635 24.269 35.66715569189871 139.74104806134628 24.269 35.667157405861396 139.74104982670423 24.269 35.66715884949687 139.7410517028315 24.269 35.66716011311171 139.74105391054047 24.269 35.667160654866485 139.74105512495677 24.269 35.66716110648396 139.7410563394768 24.269 35.66716182952898 139.74105887918248 24.269 35.66716210087188 139.74106009391 24.269 35.66716246345235 139.7410627444887 24.269 35.66716237636201 139.74106672108272 24.269 35.66716219710307 139.74106804678692 24.269 35.6671616583106 139.74107069840275 24.269 35.667161298692434 139.74107191385627 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89cf3457-4201-46f9-89ea-53d8d72e8b17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89cf3457-4201-46f9-89ea-53d8d72e8b17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89cf3457-4201-46f9-89ea-53d8d72e8b17">
											<gml:posList>35.66716237636201 139.74106672108272 30.9 35.66716246345235 139.7410627444887 30.9 35.66716210087188 139.74106009391 30.9 35.66716182952898 139.74105887918248 30.9 35.66716110648396 139.7410563394768 30.9 35.667160654866485 139.74105512495677 30.9 35.66716011311171 139.74105391054047 30.9 35.66715884949687 139.7410517028315 30.9 35.667157405861396 139.74104982670423 30.9 35.66715569189871 139.74104806134628 30.9 35.66715388805268 139.74104662746635 30.9 35.66715190418605 139.7410455251681 30.9 35.66714974029882 139.7410447544515 30.9 35.667147666802826 139.74104431500535 30.9 35.66714433172358 139.7410443188438 30.9 35.66714216876755 139.7410447631657 30.9 35.66714009620277 139.74104553875796 30.9 35.66713811402921 139.74104664562054 30.9 35.66713541160395 139.74104885789325 30.9 35.66713388070931 139.74105073744317 30.9 35.66713244003655 139.74105272734732 30.9 35.66713136016682 139.74105504821057 30.9 35.66713082027425 139.7410562638712 30.9 35.66713046065623 139.74105747932433 30.9 35.667129831642065 139.74106002058485 30.9 35.66712947312432 139.7410626719922 30.9 35.66712947524026 139.7410654334427 30.9 35.66712974768334 139.74106808412404 30.9 35.667130290453564 139.7410706240362 30.9 35.667131013498285 139.74107316374102 30.9 35.6671320969228 139.741075482115 30.9 35.667132728730024 139.7410765859693 30.9 35.6671341724497 139.7410785725545 30.9 35.667135796274664 139.7410803380163 30.9 35.667136698239794 139.74108111018552 30.9 35.66713850208542 139.74108254406593 30.9 35.66714057600438 139.7410835358032 30.9 35.66714156785291 139.74108397649468 30.9 35.667143731570654 139.74108452629616 30.9 35.6671459850872 139.7410846341618 30.9 35.66714814829722 139.74108452121507 30.9 35.66714922977532 139.74108429905462 30.9 35.66715130234035 139.7410835234633 30.9 35.667152383649196 139.74108308038672 30.9 35.667155266603494 139.74108119928147 30.9 35.66715697794241 139.74107954044032 30.9 35.66715778850091 139.74107865584253 30.9 35.66715913895219 139.74107655558387 30.9 35.66716039918151 139.74107434497074 30.9 35.667161298692434 139.74107191385627 30.9 35.6671616583106 139.74107069840275 30.9 35.66716219710307 139.74106804678692 30.9 35.66716237636201 139.74106672108272 30.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75269497-b99d-452c-97c0-3a6c1aa2e86e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75269497-b99d-452c-97c0-3a6c1aa2e86e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75269497-b99d-452c-97c0-3a6c1aa2e86e">
											<gml:posList>35.66715388805268 139.74104662746635 24.269 35.66715190418605 139.7410455251681 24.269 35.66715190418605 139.7410455251681 30.9 35.66715388805268 139.74104662746635 30.9 35.66715388805268 139.74104662746635 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b54dce3-1ecb-463c-b7d6-4b7ed64dde0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b54dce3-1ecb-463c-b7d6-4b7ed64dde0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b54dce3-1ecb-463c-b7d6-4b7ed64dde0c">
											<gml:posList>35.667160654866485 139.74105512495677 24.269 35.66716011311171 139.74105391054047 24.269 35.66716011311171 139.74105391054047 30.9 35.667160654866485 139.74105512495677 30.9 35.667160654866485 139.74105512495677 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dec23e1c-c2e9-45b9-913e-9c163f50a767">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dec23e1c-c2e9-45b9-913e-9c163f50a767">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dec23e1c-c2e9-45b9-913e-9c163f50a767">
											<gml:posList>35.667147666802826 139.74104431500535 24.269 35.66714433172358 139.7410443188438 24.269 35.66714433172358 139.7410443188438 30.9 35.667147666802826 139.74104431500535 30.9 35.667147666802826 139.74104431500535 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d86625f-fe08-4e96-96e1-4ed618aec683">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d86625f-fe08-4e96-96e1-4ed618aec683">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d86625f-fe08-4e96-96e1-4ed618aec683">
											<gml:posList>35.66714433172358 139.7410443188438 24.269 35.66714216876755 139.7410447631657 24.269 35.66714216876755 139.7410447631657 30.9 35.66714433172358 139.7410443188438 30.9 35.66714433172358 139.7410443188438 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e23f5909-f24d-4db3-8859-61b85d6173df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e23f5909-f24d-4db3-8859-61b85d6173df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e23f5909-f24d-4db3-8859-61b85d6173df">
											<gml:posList>35.66714974029882 139.7410447544515 24.269 35.667147666802826 139.74104431500535 24.269 35.667147666802826 139.74104431500535 30.9 35.66714974029882 139.7410447544515 30.9 35.66714974029882 139.7410447544515 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5b81bf8-e9b8-4502-a153-dcbc547a20da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5b81bf8-e9b8-4502-a153-dcbc547a20da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5b81bf8-e9b8-4502-a153-dcbc547a20da">
											<gml:posList>35.66715190418605 139.7410455251681 24.269 35.66714974029882 139.7410447544515 24.269 35.66714974029882 139.7410447544515 30.9 35.66715190418605 139.7410455251681 30.9 35.66715190418605 139.7410455251681 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48882086-6765-4436-b489-ea04bfb77c9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48882086-6765-4436-b489-ea04bfb77c9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48882086-6765-4436-b489-ea04bfb77c9b">
											<gml:posList>35.66714216876755 139.7410447631657 24.269 35.66714009620277 139.74104553875796 24.269 35.66714009620277 139.74104553875796 30.9 35.66714216876755 139.7410447631657 30.9 35.66714216876755 139.7410447631657 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04fddea2-72b3-4a8d-8c19-df0022b89bf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04fddea2-72b3-4a8d-8c19-df0022b89bf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04fddea2-72b3-4a8d-8c19-df0022b89bf9">
											<gml:posList>35.66714009620277 139.74104553875796 24.269 35.66713811402921 139.74104664562054 24.269 35.66713811402921 139.74104664562054 30.9 35.66714009620277 139.74104553875796 30.9 35.66714009620277 139.74104553875796 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-343022af-c774-401d-b010-b5f072672169">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-343022af-c774-401d-b010-b5f072672169">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-343022af-c774-401d-b010-b5f072672169">
											<gml:posList>35.66713811402921 139.74104664562054 24.269 35.66713541160395 139.74104885789325 24.269 35.66713541160395 139.74104885789325 30.9 35.66713811402921 139.74104664562054 30.9 35.66713811402921 139.74104664562054 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc199452-5080-4a98-9d56-97ccc3d1b9ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc199452-5080-4a98-9d56-97ccc3d1b9ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc199452-5080-4a98-9d56-97ccc3d1b9ce">
											<gml:posList>35.66713541160395 139.74104885789325 24.269 35.66713388070931 139.74105073744317 24.269 35.66713388070931 139.74105073744317 30.9 35.66713541160395 139.74104885789325 30.9 35.66713541160395 139.74104885789325 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-482f9261-05b8-4d3c-8cd5-4dd39ea6b927">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-482f9261-05b8-4d3c-8cd5-4dd39ea6b927">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-482f9261-05b8-4d3c-8cd5-4dd39ea6b927">
											<gml:posList>35.66713388070931 139.74105073744317 24.269 35.66713244003655 139.74105272734732 24.269 35.66713244003655 139.74105272734732 30.9 35.66713388070931 139.74105073744317 30.9 35.66713388070931 139.74105073744317 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9f2bb85-4af7-4094-beb3-aa561221e0d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9f2bb85-4af7-4094-beb3-aa561221e0d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9f2bb85-4af7-4094-beb3-aa561221e0d1">
											<gml:posList>35.66713244003655 139.74105272734732 24.269 35.66713136016682 139.74105504821057 24.269 35.66713136016682 139.74105504821057 30.9 35.66713244003655 139.74105272734732 30.9 35.66713244003655 139.74105272734732 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55a89b10-cc40-4b9f-88e7-d4822f06bbc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55a89b10-cc40-4b9f-88e7-d4822f06bbc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55a89b10-cc40-4b9f-88e7-d4822f06bbc8">
											<gml:posList>35.66713136016682 139.74105504821057 24.269 35.66713082027425 139.7410562638712 24.269 35.66713082027425 139.7410562638712 30.9 35.66713136016682 139.74105504821057 30.9 35.66713136016682 139.74105504821057 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e081422-483e-4396-9abf-f17b744e7fe0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e081422-483e-4396-9abf-f17b744e7fe0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e081422-483e-4396-9abf-f17b744e7fe0">
											<gml:posList>35.66716110648396 139.7410563394768 24.269 35.667160654866485 139.74105512495677 24.269 35.667160654866485 139.74105512495677 30.9 35.66716110648396 139.7410563394768 30.9 35.66716110648396 139.7410563394768 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b00bc628-d061-4a8d-bbdd-362f621cc3fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b00bc628-d061-4a8d-bbdd-362f621cc3fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b00bc628-d061-4a8d-bbdd-362f621cc3fa">
											<gml:posList>35.66713082027425 139.7410562638712 24.269 35.66713046065623 139.74105747932433 24.269 35.66713046065623 139.74105747932433 30.9 35.66713082027425 139.7410562638712 30.9 35.66713082027425 139.7410562638712 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f878aad7-afb3-4f42-8043-f7dc9688520c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f878aad7-afb3-4f42-8043-f7dc9688520c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f878aad7-afb3-4f42-8043-f7dc9688520c">
											<gml:posList>35.66716182952898 139.74105887918248 24.269 35.66716110648396 139.7410563394768 24.269 35.66716110648396 139.7410563394768 30.9 35.66716182952898 139.74105887918248 30.9 35.66716182952898 139.74105887918248 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2ce2b50-3b28-4492-b536-101f5328e7d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2ce2b50-3b28-4492-b536-101f5328e7d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2ce2b50-3b28-4492-b536-101f5328e7d1">
											<gml:posList>35.66713046065623 139.74105747932433 24.269 35.667129831642065 139.74106002058485 24.269 35.667129831642065 139.74106002058485 30.9 35.66713046065623 139.74105747932433 30.9 35.66713046065623 139.74105747932433 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cad658ff-c961-4eab-aaa6-90a3a7d8ac41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cad658ff-c961-4eab-aaa6-90a3a7d8ac41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cad658ff-c961-4eab-aaa6-90a3a7d8ac41">
											<gml:posList>35.66716210087188 139.74106009391 24.269 35.66716182952898 139.74105887918248 24.269 35.66716182952898 139.74105887918248 30.9 35.66716210087188 139.74106009391 30.9 35.66716210087188 139.74106009391 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e9e8cfa-1ad6-4e42-a08d-11465479a88f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e9e8cfa-1ad6-4e42-a08d-11465479a88f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e9e8cfa-1ad6-4e42-a08d-11465479a88f">
											<gml:posList>35.667129831642065 139.74106002058485 24.269 35.66712947312432 139.7410626719922 24.269 35.66712947312432 139.7410626719922 30.9 35.667129831642065 139.74106002058485 30.9 35.667129831642065 139.74106002058485 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-378fa422-5fc7-41d7-8851-6e2af6aa810d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-378fa422-5fc7-41d7-8851-6e2af6aa810d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-378fa422-5fc7-41d7-8851-6e2af6aa810d">
											<gml:posList>35.66716246345235 139.7410627444887 24.269 35.66716210087188 139.74106009391 24.269 35.66716210087188 139.74106009391 30.9 35.66716246345235 139.7410627444887 30.9 35.66716246345235 139.7410627444887 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a30aa90-59c9-4093-8d02-1f350ecfa44e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a30aa90-59c9-4093-8d02-1f350ecfa44e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a30aa90-59c9-4093-8d02-1f350ecfa44e">
											<gml:posList>35.66712947312432 139.7410626719922 24.269 35.66712947524026 139.7410654334427 24.269 35.66712947524026 139.7410654334427 30.9 35.66712947312432 139.7410626719922 30.9 35.66712947312432 139.7410626719922 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c5f93ef-de1b-4926-bece-326d09664d94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c5f93ef-de1b-4926-bece-326d09664d94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c5f93ef-de1b-4926-bece-326d09664d94">
											<gml:posList>35.66716237636201 139.74106672108272 24.269 35.66716246345235 139.7410627444887 24.269 35.66716246345235 139.7410627444887 30.9 35.66716237636201 139.74106672108272 30.9 35.66716237636201 139.74106672108272 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-021ec0e2-ba21-4709-ac94-f9e7984218ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-021ec0e2-ba21-4709-ac94-f9e7984218ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-021ec0e2-ba21-4709-ac94-f9e7984218ba">
											<gml:posList>35.66712947524026 139.7410654334427 24.269 35.66712974768334 139.74106808412404 24.269 35.66712974768334 139.74106808412404 30.9 35.66712947524026 139.7410654334427 30.9 35.66712947524026 139.7410654334427 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03e9e73d-a70a-4160-a4cf-dd50ff059eb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03e9e73d-a70a-4160-a4cf-dd50ff059eb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03e9e73d-a70a-4160-a4cf-dd50ff059eb9">
											<gml:posList>35.66716219710307 139.74106804678692 24.269 35.66716237636201 139.74106672108272 24.269 35.66716237636201 139.74106672108272 30.9 35.66716219710307 139.74106804678692 30.9 35.66716219710307 139.74106804678692 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd37b959-ff8c-4ef0-b18d-4e9b394b2a80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd37b959-ff8c-4ef0-b18d-4e9b394b2a80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd37b959-ff8c-4ef0-b18d-4e9b394b2a80">
											<gml:posList>35.66712974768334 139.74106808412404 24.269 35.667130290453564 139.7410706240362 24.269 35.667130290453564 139.7410706240362 30.9 35.66712974768334 139.74106808412404 30.9 35.66712974768334 139.74106808412404 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9e791c6-86ea-48b6-bcca-83936d908666">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9e791c6-86ea-48b6-bcca-83936d908666">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9e791c6-86ea-48b6-bcca-83936d908666">
											<gml:posList>35.6671616583106 139.74107069840275 24.269 35.66716219710307 139.74106804678692 24.269 35.66716219710307 139.74106804678692 30.9 35.6671616583106 139.74107069840275 30.9 35.6671616583106 139.74107069840275 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7dc3ae6d-7b20-488c-9858-2f9d25484e00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dc3ae6d-7b20-488c-9858-2f9d25484e00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dc3ae6d-7b20-488c-9858-2f9d25484e00">
											<gml:posList>35.667161298692434 139.74107191385627 24.269 35.6671616583106 139.74107069840275 24.269 35.6671616583106 139.74107069840275 30.9 35.667161298692434 139.74107191385627 30.9 35.667161298692434 139.74107191385627 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-658e0b94-166c-4495-b423-c166b103b2f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-658e0b94-166c-4495-b423-c166b103b2f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-658e0b94-166c-4495-b423-c166b103b2f3">
											<gml:posList>35.667130290453564 139.7410706240362 24.269 35.667131013498285 139.74107316374102 24.269 35.667131013498285 139.74107316374102 30.9 35.667130290453564 139.7410706240362 30.9 35.667130290453564 139.7410706240362 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9eeed4b-8348-4c7d-91ca-e7082425d80e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9eeed4b-8348-4c7d-91ca-e7082425d80e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9eeed4b-8348-4c7d-91ca-e7082425d80e">
											<gml:posList>35.66716039918151 139.74107434497074 24.269 35.667161298692434 139.74107191385627 24.269 35.667161298692434 139.74107191385627 30.9 35.66716039918151 139.74107434497074 30.9 35.66716039918151 139.74107434497074 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88ba7af6-b0b8-4896-923b-d55b7f72ee50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88ba7af6-b0b8-4896-923b-d55b7f72ee50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88ba7af6-b0b8-4896-923b-d55b7f72ee50">
											<gml:posList>35.667131013498285 139.74107316374102 24.269 35.6671320969228 139.741075482115 24.269 35.6671320969228 139.741075482115 30.9 35.667131013498285 139.74107316374102 30.9 35.667131013498285 139.74107316374102 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6be0700d-40ab-4d1f-be44-27ebbdee8b1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6be0700d-40ab-4d1f-be44-27ebbdee8b1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6be0700d-40ab-4d1f-be44-27ebbdee8b1c">
											<gml:posList>35.66715913895219 139.74107655558387 24.269 35.66716039918151 139.74107434497074 24.269 35.66716039918151 139.74107434497074 30.9 35.66715913895219 139.74107655558387 30.9 35.66715913895219 139.74107655558387 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7701e2f-f645-4ec5-af2c-6b02ceb9531e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7701e2f-f645-4ec5-af2c-6b02ceb9531e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7701e2f-f645-4ec5-af2c-6b02ceb9531e">
											<gml:posList>35.6671320969228 139.741075482115 24.269 35.667132728730024 139.7410765859693 24.269 35.667132728730024 139.7410765859693 30.9 35.6671320969228 139.741075482115 30.9 35.6671320969228 139.741075482115 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4faed0da-287b-4c91-85a0-965ba4a79080">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4faed0da-287b-4c91-85a0-965ba4a79080">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4faed0da-287b-4c91-85a0-965ba4a79080">
											<gml:posList>35.667132728730024 139.7410765859693 24.269 35.6671341724497 139.7410785725545 24.269 35.6671341724497 139.7410785725545 30.9 35.667132728730024 139.7410765859693 30.9 35.667132728730024 139.7410765859693 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4e70500-526f-4f80-90dc-29e859fb48de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4e70500-526f-4f80-90dc-29e859fb48de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4e70500-526f-4f80-90dc-29e859fb48de">
											<gml:posList>35.66715778850091 139.74107865584253 24.269 35.66715913895219 139.74107655558387 24.269 35.66715913895219 139.74107655558387 30.9 35.66715778850091 139.74107865584253 30.9 35.66715778850091 139.74107865584253 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81595dff-5b12-436b-9b82-64b6be3ee693">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81595dff-5b12-436b-9b82-64b6be3ee693">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81595dff-5b12-436b-9b82-64b6be3ee693">
											<gml:posList>35.66715697794241 139.74107954044032 24.269 35.66715778850091 139.74107865584253 24.269 35.66715778850091 139.74107865584253 30.9 35.66715697794241 139.74107954044032 30.9 35.66715697794241 139.74107954044032 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b816472-9941-4d06-9446-6edd09c4500f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b816472-9941-4d06-9446-6edd09c4500f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b816472-9941-4d06-9446-6edd09c4500f">
											<gml:posList>35.6671341724497 139.7410785725545 24.269 35.667135796274664 139.7410803380163 24.269 35.667135796274664 139.7410803380163 30.9 35.6671341724497 139.7410785725545 30.9 35.6671341724497 139.7410785725545 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e8b6f8f-70f3-49c9-9198-4f8b147a8716">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e8b6f8f-70f3-49c9-9198-4f8b147a8716">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e8b6f8f-70f3-49c9-9198-4f8b147a8716">
											<gml:posList>35.667155266603494 139.74108119928147 24.269 35.66715697794241 139.74107954044032 24.269 35.66715697794241 139.74107954044032 30.9 35.667155266603494 139.74108119928147 30.9 35.667155266603494 139.74108119928147 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2903cf71-9867-499c-ab11-e8c5b7bc9aed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2903cf71-9867-499c-ab11-e8c5b7bc9aed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2903cf71-9867-499c-ab11-e8c5b7bc9aed">
											<gml:posList>35.667135796274664 139.7410803380163 24.269 35.667136698239794 139.74108111018552 24.269 35.667136698239794 139.74108111018552 30.9 35.667135796274664 139.7410803380163 30.9 35.667135796274664 139.7410803380163 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23483b9c-15f0-4a28-bc02-878ab9b137be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23483b9c-15f0-4a28-bc02-878ab9b137be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23483b9c-15f0-4a28-bc02-878ab9b137be">
											<gml:posList>35.667136698239794 139.74108111018552 24.269 35.66713850208542 139.74108254406593 24.269 35.66713850208542 139.74108254406593 30.9 35.667136698239794 139.74108111018552 30.9 35.667136698239794 139.74108111018552 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbea8886-8a76-4c66-9b34-f111f8333457">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbea8886-8a76-4c66-9b34-f111f8333457">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbea8886-8a76-4c66-9b34-f111f8333457">
											<gml:posList>35.667152383649196 139.74108308038672 24.269 35.667155266603494 139.74108119928147 24.269 35.667155266603494 139.74108119928147 30.9 35.667152383649196 139.74108308038672 30.9 35.667152383649196 139.74108308038672 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-92c3aa67-8e83-46e3-b94d-3d4efbae3980">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92c3aa67-8e83-46e3-b94d-3d4efbae3980">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92c3aa67-8e83-46e3-b94d-3d4efbae3980">
											<gml:posList>35.66713850208542 139.74108254406593 24.269 35.66714057600438 139.7410835358032 24.269 35.66714057600438 139.7410835358032 30.9 35.66713850208542 139.74108254406593 30.9 35.66713850208542 139.74108254406593 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3736b3c8-9cc6-467a-be55-4aca8bb24a68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3736b3c8-9cc6-467a-be55-4aca8bb24a68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3736b3c8-9cc6-467a-be55-4aca8bb24a68">
											<gml:posList>35.66715130234035 139.7410835234633 24.269 35.667152383649196 139.74108308038672 24.269 35.667152383649196 139.74108308038672 30.9 35.66715130234035 139.7410835234633 30.9 35.66715130234035 139.7410835234633 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9fe24b3-d99f-4a2f-99b3-13697f14fab4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9fe24b3-d99f-4a2f-99b3-13697f14fab4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9fe24b3-d99f-4a2f-99b3-13697f14fab4">
											<gml:posList>35.66714057600438 139.7410835358032 24.269 35.66714156785291 139.74108397649468 24.269 35.66714156785291 139.74108397649468 30.9 35.66714057600438 139.7410835358032 30.9 35.66714057600438 139.7410835358032 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6bcd4436-990a-4bf2-896e-553a2e537014">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6bcd4436-990a-4bf2-896e-553a2e537014">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6bcd4436-990a-4bf2-896e-553a2e537014">
											<gml:posList>35.66714922977532 139.74108429905462 24.269 35.66715130234035 139.7410835234633 24.269 35.66715130234035 139.7410835234633 30.9 35.66714922977532 139.74108429905462 30.9 35.66714922977532 139.74108429905462 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4fda5a9-fe78-4fda-82bf-7b080ef8f224">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4fda5a9-fe78-4fda-82bf-7b080ef8f224">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4fda5a9-fe78-4fda-82bf-7b080ef8f224">
											<gml:posList>35.66714156785291 139.74108397649468 24.269 35.667143731570654 139.74108452629616 24.269 35.667143731570654 139.74108452629616 30.9 35.66714156785291 139.74108397649468 30.9 35.66714156785291 139.74108397649468 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15d8c154-a2ba-462c-a419-fffdd6fe6ce0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15d8c154-a2ba-462c-a419-fffdd6fe6ce0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15d8c154-a2ba-462c-a419-fffdd6fe6ce0">
											<gml:posList>35.66714814829722 139.74108452121507 24.269 35.66714922977532 139.74108429905462 24.269 35.66714922977532 139.74108429905462 30.9 35.66714814829722 139.74108452121507 30.9 35.66714814829722 139.74108452121507 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-302f18ea-0003-43e0-91c7-769e7b3667bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-302f18ea-0003-43e0-91c7-769e7b3667bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-302f18ea-0003-43e0-91c7-769e7b3667bd">
											<gml:posList>35.667143731570654 139.74108452629616 24.269 35.6671459850872 139.7410846341618 24.269 35.6671459850872 139.7410846341618 30.9 35.667143731570654 139.74108452629616 30.9 35.667143731570654 139.74108452629616 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ba7ad95-76a8-4b79-9d4a-1f8e5a0730a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ba7ad95-76a8-4b79-9d4a-1f8e5a0730a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ba7ad95-76a8-4b79-9d4a-1f8e5a0730a7">
											<gml:posList>35.6671459850872 139.7410846341618 24.269 35.66714814829722 139.74108452121507 24.269 35.66714814829722 139.74108452121507 30.9 35.6671459850872 139.7410846341618 30.9 35.6671459850872 139.7410846341618 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36f8b0a6-82ff-4dcf-9e0d-34b9033d2bdb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36f8b0a6-82ff-4dcf-9e0d-34b9033d2bdb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36f8b0a6-82ff-4dcf-9e0d-34b9033d2bdb">
											<gml:posList>35.66715569189871 139.74104806134628 24.269 35.66715388805268 139.74104662746635 24.269 35.66715388805268 139.74104662746635 30.9 35.66715569189871 139.74104806134628 30.9 35.66715569189871 139.74104806134628 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3f5bb552-0204-4dab-beb4-53fe3fa85594">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f5bb552-0204-4dab-beb4-53fe3fa85594">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f5bb552-0204-4dab-beb4-53fe3fa85594">
											<gml:posList>35.667157405861396 139.74104982670423 24.269 35.66715569189871 139.74104806134628 24.269 35.66715569189871 139.74104806134628 30.9 35.667157405861396 139.74104982670423 30.9 35.667157405861396 139.74104982670423 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd38bcee-a24c-465b-acc4-a0f6863351d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd38bcee-a24c-465b-acc4-a0f6863351d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd38bcee-a24c-465b-acc4-a0f6863351d3">
											<gml:posList>35.66715884949687 139.7410517028315 24.269 35.667157405861396 139.74104982670423 24.269 35.667157405861396 139.74104982670423 30.9 35.66715884949687 139.7410517028315 30.9 35.66715884949687 139.7410517028315 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4401693-f022-4c89-a397-7fcf79591045">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4401693-f022-4c89-a397-7fcf79591045">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4401693-f022-4c89-a397-7fcf79591045">
											<gml:posList>35.66716011311171 139.74105391054047 24.269 35.66715884949687 139.7410517028315 24.269 35.66715884949687 139.7410517028315 30.9 35.66716011311171 139.74105391054047 30.9 35.66716011311171 139.74105391054047 24.269</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8981</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.23</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>