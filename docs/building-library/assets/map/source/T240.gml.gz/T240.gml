<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_42738063-1373-4c75-8113-7a54dba0e394">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667937850791375 139.74019479146855 0 35.66792639179724 139.74021481998827 0 35.66799067538072 139.74027005230838 0 35.668002134392424 139.74025003482635 0 35.667937850791375 139.74019479146855 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667937850791375 139.74019479146855 11.24 35.668002134392424 139.74025003482635 11.24 35.66799067538072 139.74027005230838 11.24 35.66792639179724 139.74021481998827 11.24 35.667937850791375 139.74019479146855 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667937850791375 139.74019479146855 11.24 35.66792639179724 139.74021481998827 11.24 35.66792639179724 139.74021481998827 14.24 35.667937850791375 139.74019479146855 14.24 35.667937850791375 139.74019479146855 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66792639179724 139.74021481998827 11.24 35.66799067538072 139.74027005230838 11.24 35.66799067538072 139.74027005230838 14.24 35.66792639179724 139.74021481998827 14.24 35.66792639179724 139.74021481998827 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66799067538072 139.74027005230838 11.24 35.668002134392424 139.74025003482635 11.24 35.668002134392424 139.74025003482635 14.24 35.66799067538072 139.74027005230838 14.24 35.66799067538072 139.74027005230838 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668002134392424 139.74025003482635 11.24 35.667937850791375 139.74019479146855 11.24 35.667937850791375 139.74019479146855 14.24 35.668002134392424 139.74025003482635 14.24 35.668002134392424 139.74025003482635 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667937850791375 139.74019479146855 14.24 35.66792639179724 139.74021481998827 14.24 35.66799067538072 139.74027005230838 14.24 35.668002134392424 139.74025003482635 14.24 35.667937850791375 139.74019479146855 14.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5e9735aa-5335-4300-9f34-bf25e7dde398"/>
							<gml:surfaceMember xlink:href="#poly-38a100c5-8964-466b-aa84-2464adf4aed3"/>
							<gml:surfaceMember xlink:href="#poly-36205799-beaa-4b0a-bd42-0f1f2809e1e2"/>
							<gml:surfaceMember xlink:href="#poly-ab6fe85b-56cf-46d9-bb66-4fecfc512e1a"/>
							<gml:surfaceMember xlink:href="#poly-52ed05e5-5e2c-47cf-bcbb-78ebe188e2de"/>
							<gml:surfaceMember xlink:href="#poly-aeea82aa-d8cc-4081-8c31-d2abb4843e56"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5e9735aa-5335-4300-9f34-bf25e7dde398">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e9735aa-5335-4300-9f34-bf25e7dde398">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e9735aa-5335-4300-9f34-bf25e7dde398">
											<gml:posList>35.66793785079136 139.74019479146855 11.24 35.6680021343924 139.74025003482637 11.24 35.6679906753807 139.74027005230835 11.24 35.667926391797245 139.74021481998827 11.24 35.66793785079136 139.74019479146855 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38a100c5-8964-466b-aa84-2464adf4aed3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38a100c5-8964-466b-aa84-2464adf4aed3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38a100c5-8964-466b-aa84-2464adf4aed3">
											<gml:posList>35.6680021343924 139.74025003482637 13.869 35.66793785079136 139.74019479146855 13.869 35.667926391797245 139.74021481998827 13.869 35.6679906753807 139.74027005230835 13.869 35.6680021343924 139.74025003482637 13.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36205799-beaa-4b0a-bd42-0f1f2809e1e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36205799-beaa-4b0a-bd42-0f1f2809e1e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36205799-beaa-4b0a-bd42-0f1f2809e1e2">
											<gml:posList>35.66793785079136 139.74019479146855 11.24 35.667926391797245 139.74021481998827 11.24 35.667926391797245 139.74021481998827 13.869 35.66793785079136 139.74019479146855 13.869 35.66793785079136 139.74019479146855 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab6fe85b-56cf-46d9-bb66-4fecfc512e1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab6fe85b-56cf-46d9-bb66-4fecfc512e1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab6fe85b-56cf-46d9-bb66-4fecfc512e1a">
											<gml:posList>35.667926391797245 139.74021481998827 11.24 35.6679906753807 139.74027005230835 11.24 35.6679906753807 139.74027005230835 13.869 35.667926391797245 139.74021481998827 13.869 35.667926391797245 139.74021481998827 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52ed05e5-5e2c-47cf-bcbb-78ebe188e2de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52ed05e5-5e2c-47cf-bcbb-78ebe188e2de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52ed05e5-5e2c-47cf-bcbb-78ebe188e2de">
											<gml:posList>35.6680021343924 139.74025003482637 11.24 35.66793785079136 139.74019479146855 11.24 35.66793785079136 139.74019479146855 13.869 35.6680021343924 139.74025003482637 13.869 35.6680021343924 139.74025003482637 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aeea82aa-d8cc-4081-8c31-d2abb4843e56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aeea82aa-d8cc-4081-8c31-d2abb4843e56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aeea82aa-d8cc-4081-8c31-d2abb4843e56">
											<gml:posList>35.6679906753807 139.74027005230835 11.24 35.6680021343924 139.74025003482637 11.24 35.6680021343924 139.74025003482637 13.869 35.6679906753807 139.74027005230835 13.869 35.6679906753807 139.74027005230835 11.24</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1343</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>