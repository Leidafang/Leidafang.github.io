<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_428fbc7a-3141-4f5d-9cff-75a746e06438">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="地区計画">
				<gen:value>虎ノ門二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">7.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66838784707848 139.745662362829 0 35.66840612736953 139.7456382073579 0 35.6683970159592 139.74562785618733 0 35.668414692911085 139.74560450772296 0 35.66838771950759 139.74557385148702 0 35.66834321647415 139.74563265375886 0 35.668368575070716 139.74566147813002 0 35.66837712988357 139.74565016873464 0 35.66838784707848 139.745662362829 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838784707848 139.745662362829 7.405 35.66837712988357 139.74565016873464 7.405 35.668368575070716 139.74566147813002 7.405 35.66834321647415 139.74563265375886 7.405 35.66838771950759 139.74557385148702 7.405 35.668414692911085 139.74560450772296 7.405 35.6683970159592 139.74562785618733 7.405 35.66840612736953 139.7456382073579 7.405 35.66838784707848 139.745662362829 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838784707848 139.745662362829 7.405 35.66840612736953 139.7456382073579 7.405 35.66840612736953 139.7456382073579 14.84 35.66838784707848 139.745662362829 14.84 35.66838784707848 139.745662362829 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840612736953 139.7456382073579 7.405 35.6683970159592 139.74562785618733 7.405 35.6683970159592 139.74562785618733 14.84 35.66840612736953 139.7456382073579 14.84 35.66840612736953 139.7456382073579 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683970159592 139.74562785618733 7.405 35.668414692911085 139.74560450772296 7.405 35.668414692911085 139.74560450772296 14.84 35.6683970159592 139.74562785618733 14.84 35.6683970159592 139.74562785618733 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668414692911085 139.74560450772296 7.405 35.66838771950759 139.74557385148702 7.405 35.66838771950759 139.74557385148702 14.84 35.668414692911085 139.74560450772296 14.84 35.668414692911085 139.74560450772296 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838771950759 139.74557385148702 7.405 35.66834321647415 139.74563265375886 7.405 35.66834321647415 139.74563265375886 14.84 35.66838771950759 139.74557385148702 14.84 35.66838771950759 139.74557385148702 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66834321647415 139.74563265375886 7.405 35.668368575070716 139.74566147813002 7.405 35.668368575070716 139.74566147813002 14.84 35.66834321647415 139.74563265375886 14.84 35.66834321647415 139.74563265375886 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668368575070716 139.74566147813002 7.405 35.66837712988357 139.74565016873464 7.405 35.66837712988357 139.74565016873464 14.84 35.668368575070716 139.74566147813002 14.84 35.668368575070716 139.74566147813002 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66837712988357 139.74565016873464 7.405 35.66838784707848 139.745662362829 7.405 35.66838784707848 139.745662362829 14.84 35.66837712988357 139.74565016873464 14.84 35.66837712988357 139.74565016873464 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838784707848 139.745662362829 14.84 35.66840612736953 139.7456382073579 14.84 35.6683970159592 139.74562785618733 14.84 35.668414692911085 139.74560450772296 14.84 35.66838771950759 139.74557385148702 14.84 35.66834321647415 139.74563265375886 14.84 35.668368575070716 139.74566147813002 14.84 35.66837712988357 139.74565016873464 14.84 35.66838784707848 139.745662362829 14.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-687c906b-b474-4653-ba01-a3b5da6d1d42"/>
							<gml:surfaceMember xlink:href="#poly-d58c86b9-757c-41cc-8e1e-3df02ae12f20"/>
							<gml:surfaceMember xlink:href="#poly-e6d141d8-e2c8-4be3-95ea-1720a62206e2"/>
							<gml:surfaceMember xlink:href="#poly-1c897054-2294-4311-82f7-12cd845df1af"/>
							<gml:surfaceMember xlink:href="#poly-c2f2c0a6-c4f1-4ffd-b501-6e4662d234fe"/>
							<gml:surfaceMember xlink:href="#poly-e11aecce-7eaa-49c8-8fc1-ff1e1bc33230"/>
							<gml:surfaceMember xlink:href="#poly-19f6ef7f-4c55-4b34-99d6-84e15020acaf"/>
							<gml:surfaceMember xlink:href="#poly-646c3b9b-6b18-433d-b8f2-8e1e040e93a7"/>
							<gml:surfaceMember xlink:href="#poly-011f07b5-282f-4a78-9aad-927a4362689f"/>
							<gml:surfaceMember xlink:href="#poly-1ad7ad00-f638-46e6-ab7a-c544af7586ee"/>
							<gml:surfaceMember xlink:href="#poly-69368690-803f-45b8-ab77-9724bffe1bc5"/>
							<gml:surfaceMember xlink:href="#poly-26f4eeb4-845b-4913-b524-8f7c13c1e6f8"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-687c906b-b474-4653-ba01-a3b5da6d1d42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-687c906b-b474-4653-ba01-a3b5da6d1d42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-687c906b-b474-4653-ba01-a3b5da6d1d42">
											<gml:posList>35.66834321647413 139.74563265375883 7.405 35.66838771950757 139.74557385148702 7.405 35.66841469291106 139.74560450772296 7.405 35.66839701595919 139.74562785618733 7.405 35.66840612736953 139.7456382073579 7.405 35.66838784707848 139.745662362829 7.405 35.66837712988356 139.74565016873464 7.405 35.6683685750707 139.74566147813002 7.405 35.66834321647413 139.74563265375883 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d58c86b9-757c-41cc-8e1e-3df02ae12f20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d58c86b9-757c-41cc-8e1e-3df02ae12f20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d58c86b9-757c-41cc-8e1e-3df02ae12f20">
											<gml:posList>35.66838771950757 139.74557385148702 14.7 35.66834321647413 139.74563265375883 14.7 35.6683685750707 139.74566147813002 14.7 35.66837712988356 139.74565016873464 14.7 35.66839701595919 139.74562785618733 14.7 35.66841469291106 139.74560450772296 14.7 35.66838771950757 139.74557385148702 14.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6d141d8-e2c8-4be3-95ea-1720a62206e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6d141d8-e2c8-4be3-95ea-1720a62206e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6d141d8-e2c8-4be3-95ea-1720a62206e2">
											<gml:posList>35.66839701595919 139.74562785618733 13.1 35.66837712988356 139.74565016873464 13.1 35.66838784707848 139.745662362829 13.1 35.66840612736953 139.7456382073579 13.1 35.66839701595919 139.74562785618733 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c897054-2294-4311-82f7-12cd845df1af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c897054-2294-4311-82f7-12cd845df1af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c897054-2294-4311-82f7-12cd845df1af">
											<gml:posList>35.66841469291106 139.74560450772296 7.405 35.66838771950757 139.74557385148702 7.405 35.66838771950757 139.74557385148702 14.7 35.66841469291106 139.74560450772296 14.7 35.66841469291106 139.74560450772296 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2f2c0a6-c4f1-4ffd-b501-6e4662d234fe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2f2c0a6-c4f1-4ffd-b501-6e4662d234fe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2f2c0a6-c4f1-4ffd-b501-6e4662d234fe">
											<gml:posList>35.66838771950757 139.74557385148702 7.405 35.66834321647413 139.74563265375883 7.405 35.66834321647413 139.74563265375883 14.7 35.66838771950757 139.74557385148702 14.7 35.66838771950757 139.74557385148702 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e11aecce-7eaa-49c8-8fc1-ff1e1bc33230">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e11aecce-7eaa-49c8-8fc1-ff1e1bc33230">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e11aecce-7eaa-49c8-8fc1-ff1e1bc33230">
											<gml:posList>35.66841469291106 139.74560450772296 14.7 35.66839701595919 139.74562785618733 14.7 35.66839701595919 139.74562785618733 13.1 35.66839701595919 139.74562785618733 7.405 35.66841469291106 139.74560450772296 7.405 35.66841469291106 139.74560450772296 14.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19f6ef7f-4c55-4b34-99d6-84e15020acaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19f6ef7f-4c55-4b34-99d6-84e15020acaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19f6ef7f-4c55-4b34-99d6-84e15020acaf">
											<gml:posList>35.66840612736953 139.7456382073579 7.405 35.66839701595919 139.74562785618733 7.405 35.66839701595919 139.74562785618733 13.1 35.66840612736953 139.7456382073579 13.1 35.66840612736953 139.7456382073579 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-646c3b9b-6b18-433d-b8f2-8e1e040e93a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-646c3b9b-6b18-433d-b8f2-8e1e040e93a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-646c3b9b-6b18-433d-b8f2-8e1e040e93a7">
											<gml:posList>35.66839701595919 139.74562785618733 14.7 35.66837712988356 139.74565016873464 14.7 35.66837712988356 139.74565016873464 13.1 35.66839701595919 139.74562785618733 13.1 35.66839701595919 139.74562785618733 14.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-011f07b5-282f-4a78-9aad-927a4362689f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-011f07b5-282f-4a78-9aad-927a4362689f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-011f07b5-282f-4a78-9aad-927a4362689f">
											<gml:posList>35.66834321647413 139.74563265375883 7.405 35.6683685750707 139.74566147813002 7.405 35.6683685750707 139.74566147813002 14.7 35.66834321647413 139.74563265375883 14.7 35.66834321647413 139.74563265375883 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ad7ad00-f638-46e6-ab7a-c544af7586ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ad7ad00-f638-46e6-ab7a-c544af7586ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ad7ad00-f638-46e6-ab7a-c544af7586ee">
											<gml:posList>35.66838784707848 139.745662362829 7.405 35.66840612736953 139.7456382073579 7.405 35.66840612736953 139.7456382073579 13.1 35.66838784707848 139.745662362829 13.1 35.66838784707848 139.745662362829 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69368690-803f-45b8-ab77-9724bffe1bc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69368690-803f-45b8-ab77-9724bffe1bc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69368690-803f-45b8-ab77-9724bffe1bc5">
											<gml:posList>35.6683685750707 139.74566147813002 14.7 35.6683685750707 139.74566147813002 7.405 35.66837712988356 139.74565016873464 7.405 35.66837712988356 139.74565016873464 13.1 35.66837712988356 139.74565016873464 14.7 35.6683685750707 139.74566147813002 14.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26f4eeb4-845b-4913-b524-8f7c13c1e6f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26f4eeb4-845b-4913-b524-8f7c13c1e6f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26f4eeb4-845b-4913-b524-8f7c13c1e6f8">
											<gml:posList>35.66837712988356 139.74565016873464 7.405 35.66838784707848 139.745662362829 7.405 35.66838784707848 139.745662362829 13.1 35.66837712988356 139.74565016873464 13.1 35.66837712988356 139.74565016873464 7.405</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4406</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>