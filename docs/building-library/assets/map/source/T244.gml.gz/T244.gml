<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_449b0737-a59b-42eb-b423-79f4278acd5c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">17.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670037441381425 139.7443842244789 0 35.66998016497219 139.7446120828545 0 35.67006526009229 139.74464401167435 0 35.670122752906494 139.744416174932 0 35.670037441381425 139.7443842244789 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670037441381425 139.7443842244789 8.64 35.670122752906494 139.744416174932 8.64 35.67006526009229 139.74464401167435 8.64 35.66998016497219 139.7446120828545 8.64 35.670037441381425 139.7443842244789 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670037441381425 139.7443842244789 8.64 35.66998016497219 139.7446120828545 8.64 35.66998016497219 139.7446120828545 25.74 35.670037441381425 139.7443842244789 25.74 35.670037441381425 139.7443842244789 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66998016497219 139.7446120828545 8.64 35.67006526009229 139.74464401167435 8.64 35.67006526009229 139.74464401167435 25.74 35.66998016497219 139.7446120828545 25.74 35.66998016497219 139.7446120828545 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006526009229 139.74464401167435 8.64 35.670122752906494 139.744416174932 8.64 35.670122752906494 139.744416174932 25.74 35.67006526009229 139.74464401167435 25.74 35.67006526009229 139.74464401167435 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670122752906494 139.744416174932 8.64 35.670037441381425 139.7443842244789 8.64 35.670037441381425 139.7443842244789 25.74 35.670122752906494 139.744416174932 25.74 35.670122752906494 139.744416174932 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670037441381425 139.7443842244789 25.74 35.66998016497219 139.7446120828545 25.74 35.67006526009229 139.74464401167435 25.74 35.670122752906494 139.744416174932 25.74 35.670037441381425 139.7443842244789 25.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9d689275-eed7-42a1-9f6e-96b697fee7ff"/>
							<gml:surfaceMember xlink:href="#poly-4d87b861-de8c-4125-bc2a-faf85d854144"/>
							<gml:surfaceMember xlink:href="#poly-da8f7faf-2911-42fd-a835-9200bcb82a29"/>
							<gml:surfaceMember xlink:href="#poly-28fdf59d-7e43-4a0c-8b81-00bd2e9d5e09"/>
							<gml:surfaceMember xlink:href="#poly-faf8c179-cc89-4b4d-bafe-d03ffdf5d952"/>
							<gml:surfaceMember xlink:href="#poly-3ffebde7-56b1-489e-8261-0ef823c07215"/>
							<gml:surfaceMember xlink:href="#poly-8181078b-3fc8-48ff-900b-aa1fa35b058a"/>
							<gml:surfaceMember xlink:href="#poly-64a0f4e9-f4a9-44bd-9031-66d176129342"/>
							<gml:surfaceMember xlink:href="#poly-cc975143-71bf-4d03-b488-6deb32c231f5"/>
							<gml:surfaceMember xlink:href="#poly-89df0065-1df9-4d9b-88bf-24bd729af187"/>
							<gml:surfaceMember xlink:href="#poly-f09205df-c2b1-4a98-8ca0-6f690bcd1370"/>
							<gml:surfaceMember xlink:href="#poly-60dfec2f-75d6-4b7f-a6db-1634f963dee4"/>
							<gml:surfaceMember xlink:href="#poly-ae075039-f47c-4842-8971-c5fa6ed91bbb"/>
							<gml:surfaceMember xlink:href="#poly-5686612e-3421-43d1-a899-166296650452"/>
							<gml:surfaceMember xlink:href="#poly-3b07bd90-eea8-4463-a678-1155492a2d73"/>
							<gml:surfaceMember xlink:href="#poly-5e95ad73-a14e-4df5-8de2-1270d09f0b80"/>
							<gml:surfaceMember xlink:href="#poly-d0486ecf-059d-48c1-b381-55ff66127e95"/>
							<gml:surfaceMember xlink:href="#poly-960fb668-6f10-4726-8dde-cf3a73c8f4ad"/>
							<gml:surfaceMember xlink:href="#poly-08d7f95d-eed3-47bb-96a8-36e48c9e2ccf"/>
							<gml:surfaceMember xlink:href="#poly-a62944c7-0af7-477e-afbe-0b7720ded93e"/>
							<gml:surfaceMember xlink:href="#poly-de6a4d1f-2004-419f-b236-b4c36367e4f2"/>
							<gml:surfaceMember xlink:href="#poly-8fcdacc6-db10-43d8-8f65-ea6c4f25a0af"/>
							<gml:surfaceMember xlink:href="#poly-d35613ff-0b48-4b8e-bd9f-c25b61a03492"/>
							<gml:surfaceMember xlink:href="#poly-619aea90-55d1-48f6-ab45-7360254b0420"/>
							<gml:surfaceMember xlink:href="#poly-13b201f3-0e0a-40ec-bd4d-b0afb7c49449"/>
							<gml:surfaceMember xlink:href="#poly-167d47e4-80e4-4735-9995-ba990c9c7954"/>
							<gml:surfaceMember xlink:href="#poly-308a371a-4777-45b6-b002-e41d9a001629"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_449b0737-a59b-42eb-b423-79f4278acd5c_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77489d30-080a-48db-93e0-d4e4c893b97c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67003621718965 139.7443986963753 26.1 35.66998497127676 139.74460254466084 26.1 35.669983366378 139.74460192784943 26.1 35.67003535161921 139.7443983549028 26.1 35.67003621718965 139.7443986963753 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-939220b6-6bc1-453d-8d0a-126307b912a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67010921457735 139.74442878263957 24.871 35.67003661545782 139.74440094936088 24.871 35.66998583459188 139.74459982633888 24.871 35.67005784761147 139.74462743950428 24.871 35.67007807913282 139.74454821573633 24.871 35.670080495486914 139.74454912989674 24.871 35.67005955393134 139.74463113809875 24.871 35.66998497127676 139.74460254466084 24.871 35.67003621718965 139.7443986963753 24.871 35.67011139496882 139.74442752095248 24.871 35.670099009859484 139.74447603864255 24.871 35.67009731480656 139.74447539984027 24.871 35.67010921457735 139.74442878263957 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-68cea30e-d9bb-4206-bc1d-71b2906538d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-68cea30e-d9bb-4206-bc1d-71b2906538d1_0">
											<gml:posList>35.67003621718965 139.7443986963753 26.1 35.67003535161921 139.7443983549028 26.1 35.67003535161921 139.7443983549028 26.727 35.67011139496882 139.74442752095248 26.727 35.67011139496882 139.74442752095248 24.871 35.67003621718965 139.7443986963753 24.871 35.67003621718965 139.7443986963753 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79548d3f-d276-4fe8-a5bb-2cd97183760b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79548d3f-d276-4fe8-a5bb-2cd97183760b_0">
											<gml:posList>35.67010921457735 139.74442878263957 26.727 35.67003661545782 139.74440094936088 26.727 35.67003661545782 139.74440094936088 24.871 35.67010921457735 139.74442878263957 24.871 35.67010921457735 139.74442878263957 26.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-797bdca7-1767-400f-bca7-f5f5ae5ed13d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-797bdca7-1767-400f-bca7-f5f5ae5ed13d_0">
											<gml:posList>35.67011139496882 139.74442752095248 24.871 35.67011139496882 139.74442752095248 26.727 35.670099009859484 139.74447603864255 26.727 35.670099009859484 139.74447603864255 24.871 35.67011139496882 139.74442752095248 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16f0898f-885f-43db-ab2a-896238f2c4ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16f0898f-885f-43db-ab2a-896238f2c4ed_0">
											<gml:posList>35.67009731480656 139.74447539984027 24.871 35.67009731480656 139.74447539984027 26.727 35.67010921457735 139.74442878263957 26.727 35.67010921457735 139.74442878263957 24.871 35.67009731480656 139.74447539984027 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd4b3692-978a-4a30-bc71-9539b8b75bfb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd4b3692-978a-4a30-bc71-9539b8b75bfb_0">
											<gml:posList>35.670099009859484 139.74447603864255 26.727 35.67009731480656 139.74447539984027 26.727 35.67009731480656 139.74447539984027 24.871 35.670099009859484 139.74447603864255 24.871 35.670099009859484 139.74447603864255 26.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e05f01c-c8e5-431d-8d85-ef1aa1659949">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e05f01c-c8e5-431d-8d85-ef1aa1659949_0">
											<gml:posList>35.669983366378 139.74460192784943 26.1 35.669983366378 139.74460192784943 26.727 35.67003535161921 139.7443983549028 26.727 35.67003535161921 139.7443983549028 26.1 35.669983366378 139.74460192784943 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1bdf5d0-302d-45f5-8065-b1e606d728d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1bdf5d0-302d-45f5-8065-b1e606d728d6_0">
											<gml:posList>35.67003661545782 139.74440094936088 24.871 35.67003661545782 139.74440094936088 26.727 35.66998583459188 139.74459982633888 26.727 35.66998583459188 139.74459982633888 24.871 35.67003661545782 139.74440094936088 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-846491af-0853-4cd9-9c2f-52e96a9d885e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-846491af-0853-4cd9-9c2f-52e96a9d885e_0">
											<gml:posList>35.66998497127676 139.74460254466084 24.871 35.66998497127676 139.74460254466084 26.1 35.67003621718965 139.7443986963753 26.1 35.67003621718965 139.7443986963753 24.871 35.66998497127676 139.74460254466084 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c618bd04-d61c-418c-be5d-737110601eae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c618bd04-d61c-418c-be5d-737110601eae_0">
											<gml:posList>35.670099009859484 139.74447603864255 26.727 35.67011139496882 139.74442752095248 26.727 35.67003535161921 139.7443983549028 26.727 35.669983366378 139.74460192784943 26.727 35.67005955393134 139.74463113809875 26.727 35.670080495486914 139.74454912989674 26.727 35.67007807913282 139.74454821573633 26.727 35.67005784761147 139.74462743950428 26.727 35.66998583459188 139.74459982633888 26.727 35.67003661545782 139.74440094936088 26.727 35.67010921457735 139.74442878263957 26.727 35.67009731480656 139.74447539984027 26.727 35.670099009859484 139.74447603864255 26.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f82e456-f581-4fa3-9c54-bf33f5a1e983">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f82e456-f581-4fa3-9c54-bf33f5a1e983_0">
											<gml:posList>35.670080495486914 139.74454912989674 24.871 35.67007807913282 139.74454821573633 24.871 35.67007807913282 139.74454821573633 26.727 35.670080495486914 139.74454912989674 26.727 35.670080495486914 139.74454912989674 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d92759ed-3c5c-449d-9af2-714128b5180d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d92759ed-3c5c-449d-9af2-714128b5180d_0">
											<gml:posList>35.67007807913282 139.74454821573633 24.871 35.67005784761147 139.74462743950428 24.871 35.67005784761147 139.74462743950428 26.727 35.67007807913282 139.74454821573633 26.727 35.67007807913282 139.74454821573633 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd907f53-b453-4f21-a975-832e43fdac19">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd907f53-b453-4f21-a975-832e43fdac19_0">
											<gml:posList>35.67005955393134 139.74463113809875 26.727 35.67005955393134 139.74463113809875 24.871 35.670080495486914 139.74454912989674 24.871 35.670080495486914 139.74454912989674 26.727 35.67005955393134 139.74463113809875 26.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e92914f-766f-4c5e-aa4f-e3b64816511b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e92914f-766f-4c5e-aa4f-e3b64816511b_0">
											<gml:posList>35.66998583459188 139.74459982633888 24.871 35.66998583459188 139.74459982633888 26.727 35.67005784761147 139.74462743950428 26.727 35.67005784761147 139.74462743950428 24.871 35.66998583459188 139.74459982633888 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15ca0554-54d6-4075-ba9f-5583f2ff3314">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15ca0554-54d6-4075-ba9f-5583f2ff3314_0">
											<gml:posList>35.67005955393134 139.74463113809875 24.871 35.67005955393134 139.74463113809875 26.727 35.669983366378 139.74460192784943 26.727 35.669983366378 139.74460192784943 26.1 35.66998497127676 139.74460254466084 26.1 35.66998497127676 139.74460254466084 24.871 35.67005955393134 139.74463113809875 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_449b0737-a59b-42eb-b423-79f4278acd5c_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa1d61c0-0321-4368-b336-693bd502885b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670084332318424 139.74445950767267 24.871 35.67009312148305 139.744423929101 24.871 35.67010294914196 139.7444275745025 24.871 35.67009415998443 139.74446316412437 24.871 35.670084332318424 139.74445950767267 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-686ee78e-1379-45bf-99e7-80bb653ab198">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670045163741996 139.7445641808251 24.871 35.670035823137674 139.74456095462625 24.871 35.67004425991729 139.74452418348648 24.871 35.670053600514436 139.74452739863514 24.871 35.670045163741996 139.7445641808251 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e10044f8-e8c2-45e8-bb50-2c79869f074c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e10044f8-e8c2-45e8-bb50-2c79869f074c_0">
											<gml:posList>35.67004425991729 139.74452418348648 24.871 35.670035823137674 139.74456095462625 24.871 35.670035823137674 139.74456095462625 28.811 35.67004425991729 139.74452418348648 28.811 35.67004425991729 139.74452418348648 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-594aaf8c-1e3c-44af-940c-510e9ccb3c66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-594aaf8c-1e3c-44af-940c-510e9ccb3c66_0">
											<gml:posList>35.670035823137674 139.74456095462625 24.871 35.670045163741996 139.7445641808251 24.871 35.670045163741996 139.7445641808251 28.811 35.670035823137674 139.74456095462625 28.811 35.670035823137674 139.74456095462625 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a65faa8-db49-443f-9bce-64c1ec8ae416">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a65faa8-db49-443f-9bce-64c1ec8ae416_0">
											<gml:posList>35.67004425991729 139.74452418348648 28.811 35.670035823137674 139.74456095462625 28.811 35.670045163741996 139.7445641808251 28.811 35.670053600514436 139.74452739863514 28.811 35.67004425991729 139.74452418348648 28.811</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5b18a1b-1cfb-4da4-9e51-9493cabd2d7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a5b18a1b-1cfb-4da4-9e51-9493cabd2d7a_0">
											<gml:posList>35.670053600514436 139.74452739863514 24.871 35.67004425991729 139.74452418348648 24.871 35.67004425991729 139.74452418348648 28.811 35.670053600514436 139.74452739863514 28.811 35.670053600514436 139.74452739863514 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6ef8698-f5cc-472d-8132-a8acc363bfee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6ef8698-f5cc-472d-8132-a8acc363bfee_0">
											<gml:posList>35.670053600514436 139.74452739863514 24.871 35.670053600514436 139.74452739863514 28.811 35.670045163741996 139.7445641808251 28.811 35.670045163741996 139.7445641808251 24.871 35.670053600514436 139.74452739863514 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29e0a620-4ae6-4b84-8de5-6656b2774ae7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29e0a620-4ae6-4b84-8de5-6656b2774ae7_0">
											<gml:posList>35.67009312148305 139.744423929101 24.871 35.670084332318424 139.74445950767267 24.871 35.670084332318424 139.74445950767267 28.811 35.67009312148305 139.744423929101 28.811 35.67009312148305 139.744423929101 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd300f99-f659-4a91-abff-2c75d796ede1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd300f99-f659-4a91-abff-2c75d796ede1_0">
											<gml:posList>35.670084332318424 139.74445950767267 24.871 35.67009415998443 139.74446316412437 24.871 35.67009415998443 139.74446316412437 28.811 35.670084332318424 139.74445950767267 28.811 35.670084332318424 139.74445950767267 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5816a533-2461-44ac-9d11-448e2fb92bd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5816a533-2461-44ac-9d11-448e2fb92bd4_0">
											<gml:posList>35.67010294914196 139.7444275745025 28.811 35.67009312148305 139.744423929101 28.811 35.670084332318424 139.74445950767267 28.811 35.67009415998443 139.74446316412437 28.811 35.67010294914196 139.7444275745025 28.811</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3fd12c5-51b4-4c18-84d6-126d0324cfbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3fd12c5-51b4-4c18-84d6-126d0324cfbc_0">
											<gml:posList>35.67010294914196 139.7444275745025 24.871 35.67009312148305 139.744423929101 24.871 35.67009312148305 139.744423929101 28.811 35.67010294914196 139.7444275745025 28.811 35.67010294914196 139.7444275745025 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7bfbb3d-fe15-4527-9ccc-c5f2616077de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e7bfbb3d-fe15-4527-9ccc-c5f2616077de_0">
											<gml:posList>35.67010294914196 139.7444275745025 24.871 35.67010294914196 139.7444275745025 28.811 35.67009415998443 139.74446316412437 28.811 35.67009415998443 139.74446316412437 24.871 35.67010294914196 139.7444275745025 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_449b0737-a59b-42eb-b423-79f4278acd5c_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-383f6561-df9b-49f6-b4b4-286895e8fe1d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67007021197051 139.7444651568951 24.871 35.67008025607172 139.74446895670783 24.871 35.67007171805571 139.74450287805803 24.871 35.67006167395555 139.7444990782415 24.871 35.67007021197051 139.7444651568951 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cf065bb-cfd7-4343-a825-148bfeccd68d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cf065bb-cfd7-4343-a825-148bfeccd68d_0">
											<gml:posList>35.67007021197051 139.7444651568951 29.135 35.67008025607172 139.74446895670783 29.135 35.67008025607172 139.74446895670783 24.871 35.67007021197051 139.7444651568951 24.871 35.67007021197051 139.7444651568951 29.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33731098-a48c-44ea-bcf2-fefeefb90179">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33731098-a48c-44ea-bcf2-fefeefb90179_0">
											<gml:posList>35.67006167395555 139.7444990782415 24.871 35.67006167395555 139.7444990782415 29.135 35.67007021197051 139.7444651568951 29.135 35.67007021197051 139.7444651568951 24.871 35.67006167395555 139.7444990782415 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-721d1955-bde2-4363-bfb1-05394383c1b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-721d1955-bde2-4363-bfb1-05394383c1b2_0">
											<gml:posList>35.67007171805571 139.74450287805803 29.135 35.67008025607172 139.74446895670783 29.135 35.67007021197051 139.7444651568951 29.135 35.67006167395555 139.7444990782415 29.135 35.67007171805571 139.74450287805803 29.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd2c48c1-3aa5-480a-978f-820f8c8dd95c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd2c48c1-3aa5-480a-978f-820f8c8dd95c_0">
											<gml:posList>35.67008025607172 139.74446895670783 24.871 35.67008025607172 139.74446895670783 29.135 35.67007171805571 139.74450287805803 29.135 35.67007171805571 139.74450287805803 24.871 35.67008025607172 139.74446895670783 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a516ea93-b07f-4639-8656-4aabfbec2e3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a516ea93-b07f-4639-8656-4aabfbec2e3f_0">
											<gml:posList>35.67007171805571 139.74450287805803 29.135 35.67006167395555 139.7444990782415 29.135 35.67006167395555 139.7444990782415 24.871 35.67007171805571 139.74450287805803 24.871 35.67007171805571 139.74450287805803 29.135</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9d689275-eed7-42a1-9f6e-96b697fee7ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d689275-eed7-42a1-9f6e-96b697fee7ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d689275-eed7-42a1-9f6e-96b697fee7ff">
											<gml:posList>35.67003744138141 139.7443842244789 8.64 35.67012275290647 139.744416174932 8.64 35.67006526009226 139.74464401167435 8.64 35.66998016497219 139.7446120828545 8.64 35.67003744138141 139.7443842244789 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4d87b861-de8c-4125-bc2a-faf85d854144">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d87b861-de8c-4125-bc2a-faf85d854144">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d87b861-de8c-4125-bc2a-faf85d854144">
											<gml:posList>35.66998016497219 139.7446120828545 26.1 35.66998303897477 139.7446102128656 26.1 35.67003896731188 139.74438775757415 26.1 35.67003744138141 139.7443842244789 26.1 35.66998016497219 139.7446120828545 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-da8f7faf-2911-42fd-a835-9200bcb82a29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da8f7faf-2911-42fd-a835-9200bcb82a29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da8f7faf-2911-42fd-a835-9200bcb82a29">
											<gml:posList>35.67006526009226 139.74464401167435 26.1 35.67006373417745 139.7446404896193 26.1 35.66998303897477 139.7446102128656 26.1 35.66998016497219 139.7446120828545 26.1 35.67006526009226 139.74464401167435 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-28fdf59d-7e43-4a0c-8b81-00bd2e9d5e09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28fdf59d-7e43-4a0c-8b81-00bd2e9d5e09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28fdf59d-7e43-4a0c-8b81-00bd2e9d5e09">
											<gml:posList>35.670085573813466 139.74455400670223 24.871 35.6700860513128 139.7445536968794 24.871 35.67008661751598 139.74455144282368 24.871 35.67006185890624 139.7445420809554 24.871 35.67008025607172 139.74446895670783 24.871 35.67010469009518 139.7444781863607 24.871 35.670105364151866 139.74447551242798 24.871 35.670119860887695 139.7444180559973 24.871 35.67003896731188 139.74438775757415 24.871 35.66998303897477 139.7446102128656 24.871 35.67006373417745 139.7446404896193 24.871 35.670085573813466 139.74455400670223 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-faf8c179-cc89-4b4d-bafe-d03ffdf5d952">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faf8c179-cc89-4b4d-bafe-d03ffdf5d952">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faf8c179-cc89-4b4d-bafe-d03ffdf5d952">
											<gml:posList>35.67006526009226 139.74464401167435 26.1 35.670088465842525 139.74455213668887 26.1 35.6700860513128 139.7445536968794 26.1 35.670085573813466 139.74455400670223 26.1 35.67006373417745 139.7446404896193 26.1 35.67006526009226 139.74464401167435 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ffebde7-56b1-489e-8261-0ef823c07215">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ffebde7-56b1-489e-8261-0ef823c07215">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ffebde7-56b1-489e-8261-0ef823c07215">
											<gml:posList>35.67003744138141 139.7443842244789 26.1 35.67003896731188 139.74438775757415 26.1 35.670119860887695 139.7444180559973 26.1 35.67012275290647 139.744416174932 26.1 35.67003744138141 139.7443842244789 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8181078b-3fc8-48ff-900b-aa1fa35b058a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8181078b-3fc8-48ff-900b-aa1fa35b058a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8181078b-3fc8-48ff-900b-aa1fa35b058a">
											<gml:posList>35.67007227528496 139.7445006792434 31.308 35.67006185890624 139.7445420809554 31.308 35.670088465842525 139.74455213668887 31.308 35.67009890927397 139.74451074598068 31.308 35.67007227528496 139.7445006792434 31.308</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-64a0f4e9-f4a9-44bd-9031-66d176129342">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-64a0f4e9-f4a9-44bd-9031-66d176129342">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-64a0f4e9-f4a9-44bd-9031-66d176129342">
											<gml:posList>35.6700860513128 139.7445536968794 26.1 35.670088465842525 139.74455213668887 26.1 35.67008661751598 139.74455144282368 26.1 35.6700860513128 139.7445536968794 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc975143-71bf-4d03-b488-6deb32c231f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc975143-71bf-4d03-b488-6deb32c231f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc975143-71bf-4d03-b488-6deb32c231f5">
											<gml:posList>35.67010689907707 139.74447902342555 28.968 35.67008025607172 139.74446895670783 28.968 35.67007227528496 139.7445006792434 28.968 35.67009890927397 139.74451074598068 28.968 35.67010689907707 139.74447902342555 28.968</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89df0065-1df9-4d9b-88bf-24bd729af187">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89df0065-1df9-4d9b-88bf-24bd729af187">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89df0065-1df9-4d9b-88bf-24bd729af187">
											<gml:posList>35.67010469009518 139.7444781863607 26.1 35.67010689907707 139.74447902342555 26.1 35.670105364151866 139.74447551242798 26.1 35.67010469009518 139.7444781863607 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f09205df-c2b1-4a98-8ca0-6f690bcd1370">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f09205df-c2b1-4a98-8ca0-6f690bcd1370">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f09205df-c2b1-4a98-8ca0-6f690bcd1370">
											<gml:posList>35.67012275290647 139.744416174932 26.1 35.670119860887695 139.7444180559973 26.1 35.670105364151866 139.74447551242798 26.1 35.67010689907707 139.74447902342555 26.1 35.67012275290647 139.744416174932 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60dfec2f-75d6-4b7f-a6db-1634f963dee4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60dfec2f-75d6-4b7f-a6db-1634f963dee4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60dfec2f-75d6-4b7f-a6db-1634f963dee4">
											<gml:posList>35.6700860513128 139.7445536968794 26.1 35.6700860513128 139.7445536968794 24.871 35.670085573813466 139.74455400670223 24.871 35.670085573813466 139.74455400670223 26.1 35.6700860513128 139.7445536968794 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae075039-f47c-4842-8971-c5fa6ed91bbb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae075039-f47c-4842-8971-c5fa6ed91bbb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae075039-f47c-4842-8971-c5fa6ed91bbb">
											<gml:posList>35.67012275290647 139.744416174932 8.64 35.67003744138141 139.7443842244789 8.64 35.67003744138141 139.7443842244789 26.1 35.67012275290647 139.744416174932 26.1 35.67012275290647 139.744416174932 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5686612e-3421-43d1-a899-166296650452">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5686612e-3421-43d1-a899-166296650452">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5686612e-3421-43d1-a899-166296650452">
											<gml:posList>35.67003896731188 139.74438775757415 26.1 35.67003896731188 139.74438775757415 24.871 35.670119860887695 139.7444180559973 24.871 35.670119860887695 139.7444180559973 26.1 35.67003896731188 139.74438775757415 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b07bd90-eea8-4463-a678-1155492a2d73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b07bd90-eea8-4463-a678-1155492a2d73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b07bd90-eea8-4463-a678-1155492a2d73">
											<gml:posList>35.670119860887695 139.7444180559973 26.1 35.670119860887695 139.7444180559973 24.871 35.670105364151866 139.74447551242798 24.871 35.670105364151866 139.74447551242798 26.1 35.670119860887695 139.7444180559973 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e95ad73-a14e-4df5-8de2-1270d09f0b80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e95ad73-a14e-4df5-8de2-1270d09f0b80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e95ad73-a14e-4df5-8de2-1270d09f0b80">
											<gml:posList>35.67010469009518 139.7444781863607 26.1 35.67010469009518 139.7444781863607 24.871 35.67008025607172 139.74446895670783 24.871 35.67008025607172 139.74446895670783 28.968 35.67010689907707 139.74447902342555 28.968 35.67010689907707 139.74447902342555 26.1 35.67010469009518 139.7444781863607 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0486ecf-059d-48c1-b381-55ff66127e95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0486ecf-059d-48c1-b381-55ff66127e95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0486ecf-059d-48c1-b381-55ff66127e95">
											<gml:posList>35.670105364151866 139.74447551242798 26.1 35.670105364151866 139.74447551242798 24.871 35.67010469009518 139.7444781863607 24.871 35.67010469009518 139.7444781863607 26.1 35.670105364151866 139.74447551242798 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-960fb668-6f10-4726-8dde-cf3a73c8f4ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-960fb668-6f10-4726-8dde-cf3a73c8f4ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-960fb668-6f10-4726-8dde-cf3a73c8f4ad">
											<gml:posList>35.67003744138141 139.7443842244789 8.64 35.66998016497219 139.7446120828545 8.64 35.66998016497219 139.7446120828545 26.1 35.67003744138141 139.7443842244789 26.1 35.67003744138141 139.7443842244789 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08d7f95d-eed3-47bb-96a8-36e48c9e2ccf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08d7f95d-eed3-47bb-96a8-36e48c9e2ccf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08d7f95d-eed3-47bb-96a8-36e48c9e2ccf">
											<gml:posList>35.66998303897477 139.7446102128656 26.1 35.66998303897477 139.7446102128656 24.871 35.67003896731188 139.74438775757415 24.871 35.67003896731188 139.74438775757415 26.1 35.66998303897477 139.7446102128656 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a62944c7-0af7-477e-afbe-0b7720ded93e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a62944c7-0af7-477e-afbe-0b7720ded93e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a62944c7-0af7-477e-afbe-0b7720ded93e">
											<gml:posList>35.67006185890624 139.7445420809554 24.871 35.67006185890624 139.7445420809554 31.308 35.67007227528496 139.7445006792434 31.308 35.67007227528496 139.7445006792434 28.968 35.67008025607172 139.74446895670783 28.968 35.67008025607172 139.74446895670783 24.871 35.67006185890624 139.7445420809554 24.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de6a4d1f-2004-419f-b236-b4c36367e4f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de6a4d1f-2004-419f-b236-b4c36367e4f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de6a4d1f-2004-419f-b236-b4c36367e4f2">
											<gml:posList>35.67007227528496 139.7445006792434 28.968 35.67007227528496 139.7445006792434 31.308 35.67009890927397 139.74451074598068 31.308 35.67009890927397 139.74451074598068 28.968 35.67007227528496 139.7445006792434 28.968</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fcdacc6-db10-43d8-8f65-ea6c4f25a0af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fcdacc6-db10-43d8-8f65-ea6c4f25a0af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fcdacc6-db10-43d8-8f65-ea6c4f25a0af">
											<gml:posList>35.67006526009226 139.74464401167435 8.64 35.67012275290647 139.744416174932 8.64 35.67012275290647 139.744416174932 26.1 35.67010689907707 139.74447902342555 26.1 35.67010689907707 139.74447902342555 28.968 35.67009890927397 139.74451074598068 28.968 35.67009890927397 139.74451074598068 31.308 35.670088465842525 139.74455213668887 31.308 35.670088465842525 139.74455213668887 26.1 35.67006526009226 139.74464401167435 26.1 35.67006526009226 139.74464401167435 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d35613ff-0b48-4b8e-bd9f-c25b61a03492">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d35613ff-0b48-4b8e-bd9f-c25b61a03492">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d35613ff-0b48-4b8e-bd9f-c25b61a03492">
											<gml:posList>35.67008661751598 139.74455144282368 26.1 35.670088465842525 139.74455213668887 26.1 35.670088465842525 139.74455213668887 31.308 35.67006185890624 139.7445420809554 31.308 35.67006185890624 139.7445420809554 24.871 35.67008661751598 139.74455144282368 24.871 35.67008661751598 139.74455144282368 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-619aea90-55d1-48f6-ab45-7360254b0420">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-619aea90-55d1-48f6-ab45-7360254b0420">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-619aea90-55d1-48f6-ab45-7360254b0420">
											<gml:posList>35.67008661751598 139.74455144282368 26.1 35.67008661751598 139.74455144282368 24.871 35.6700860513128 139.7445536968794 24.871 35.6700860513128 139.7445536968794 26.1 35.67008661751598 139.74455144282368 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13b201f3-0e0a-40ec-bd4d-b0afb7c49449">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13b201f3-0e0a-40ec-bd4d-b0afb7c49449">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13b201f3-0e0a-40ec-bd4d-b0afb7c49449">
											<gml:posList>35.670085573813466 139.74455400670223 26.1 35.670085573813466 139.74455400670223 24.871 35.67006373417745 139.7446404896193 24.871 35.67006373417745 139.7446404896193 26.1 35.670085573813466 139.74455400670223 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-167d47e4-80e4-4735-9995-ba990c9c7954">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-167d47e4-80e4-4735-9995-ba990c9c7954">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-167d47e4-80e4-4735-9995-ba990c9c7954">
											<gml:posList>35.67006373417745 139.7446404896193 26.1 35.67006373417745 139.7446404896193 24.871 35.66998303897477 139.7446102128656 24.871 35.66998303897477 139.7446102128656 26.1 35.67006373417745 139.7446404896193 26.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-308a371a-4777-45b6-b002-e41d9a001629">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-308a371a-4777-45b6-b002-e41d9a001629">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-308a371a-4777-45b6-b002-e41d9a001629">
											<gml:posList>35.66998016497219 139.7446120828545 8.64 35.67006526009226 139.74464401167435 8.64 35.67006526009226 139.74464401167435 26.1 35.66998016497219 139.7446120828545 26.1 35.66998016497219 139.7446120828545 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7395</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">197.76745</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>