<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_44e2d6f0-8521-4abd-869b-a93924cfe351">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">18.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67088568418709 139.74083852740222 0 35.67081965408563 139.74077398260533 0 35.67077670828671 139.74083865312156 0 35.67078491713752 139.74084692838792 0 35.67065013723286 139.74104978340523 0 35.670707508346645 139.74110693722872 0 35.67088568418709 139.74083852740222 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67088568418709 139.74083852740222 9.779 35.670707508346645 139.74110693722872 9.779 35.67065013723286 139.74104978340523 9.779 35.67078491713752 139.74084692838792 9.779 35.67077670828671 139.74083865312156 9.779 35.67081965408563 139.74077398260533 9.779 35.67088568418709 139.74083852740222 9.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67088568418709 139.74083852740222 9.779 35.67081965408563 139.74077398260533 9.779 35.67081965408563 139.74077398260533 27.87 35.67088568418709 139.74083852740222 27.87 35.67088568418709 139.74083852740222 9.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67081965408563 139.74077398260533 9.779 35.67077670828671 139.74083865312156 9.779 35.67077670828671 139.74083865312156 27.87 35.67081965408563 139.74077398260533 27.87 35.67081965408563 139.74077398260533 9.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67077670828671 139.74083865312156 9.779 35.67078491713752 139.74084692838792 9.779 35.67078491713752 139.74084692838792 27.87 35.67077670828671 139.74083865312156 27.87 35.67077670828671 139.74083865312156 9.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078491713752 139.74084692838792 9.779 35.67065013723286 139.74104978340523 9.779 35.67065013723286 139.74104978340523 27.87 35.67078491713752 139.74084692838792 27.87 35.67078491713752 139.74084692838792 9.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67065013723286 139.74104978340523 9.779 35.670707508346645 139.74110693722872 9.779 35.670707508346645 139.74110693722872 27.87 35.67065013723286 139.74104978340523 27.87 35.67065013723286 139.74104978340523 9.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670707508346645 139.74110693722872 9.779 35.67088568418709 139.74083852740222 9.779 35.67088568418709 139.74083852740222 27.87 35.670707508346645 139.74110693722872 27.87 35.670707508346645 139.74110693722872 9.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67088568418709 139.74083852740222 27.87 35.67081965408563 139.74077398260533 27.87 35.67077670828671 139.74083865312156 27.87 35.67078491713752 139.74084692838792 27.87 35.67065013723286 139.74104978340523 27.87 35.670707508346645 139.74110693722872 27.87 35.67088568418709 139.74083852740222 27.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-09e2ce78-2cc2-43dd-8d06-05a5fab18dad"/>
							<gml:surfaceMember xlink:href="#poly-d647a14e-b081-43ec-b836-79f2af3745d6"/>
							<gml:surfaceMember xlink:href="#poly-62ab4213-4729-4815-88da-01507955176e"/>
							<gml:surfaceMember xlink:href="#poly-a09a16ec-344a-40b8-a82d-bddccc69d3a5"/>
							<gml:surfaceMember xlink:href="#poly-ffe009af-6965-4ae7-996d-2d48ce1fed34"/>
							<gml:surfaceMember xlink:href="#poly-59060661-71dc-465c-a87e-55ed60ece47e"/>
							<gml:surfaceMember xlink:href="#poly-305d5d0c-0e23-4507-af60-daa72488e550"/>
							<gml:surfaceMember xlink:href="#poly-a4013661-62f0-4286-846e-8d803fb82b9f"/>
							<gml:surfaceMember xlink:href="#poly-7f98c42f-9c2d-484f-b9d7-0b0e48172d1c"/>
							<gml:surfaceMember xlink:href="#poly-cb593272-1604-4770-b324-652f5f12f21c"/>
							<gml:surfaceMember xlink:href="#poly-0049abe3-5e99-44ff-8a95-5dc5646491bb"/>
							<gml:surfaceMember xlink:href="#poly-38a116e2-159a-4441-a693-0a7132314837"/>
							<gml:surfaceMember xlink:href="#poly-5d87decf-e001-41f6-a470-19249268b291"/>
							<gml:surfaceMember xlink:href="#poly-c2e92d20-fc28-44c4-81ec-86a52f5dd610"/>
							<gml:surfaceMember xlink:href="#poly-4425a7dc-c526-4d1f-83cc-ae7770a828f8"/>
							<gml:surfaceMember xlink:href="#poly-1876b7a0-ae54-422c-9656-c36f7c98bedc"/>
							<gml:surfaceMember xlink:href="#poly-75b5a106-63bf-47dd-94f9-ca2d52995e27"/>
							<gml:surfaceMember xlink:href="#poly-e824aabe-499d-4e78-bdd5-d7a51452248c"/>
							<gml:surfaceMember xlink:href="#poly-9d002eaa-aa57-4401-82ad-3dd9fc36d602"/>
							<gml:surfaceMember xlink:href="#poly-9c689203-7cc8-46e1-a4c7-f4366a858cbd"/>
							<gml:surfaceMember xlink:href="#poly-387a8e8c-d854-44a0-8f0b-dbfd6f33dc19"/>
							<gml:surfaceMember xlink:href="#poly-83ca0505-427b-4bcb-a35c-525db72d60cc"/>
							<gml:surfaceMember xlink:href="#poly-234a4d8e-974c-4664-8a69-993fd911da2c"/>
							<gml:surfaceMember xlink:href="#poly-e448f54f-15dd-48f7-9c23-31655aee493a"/>
							<gml:surfaceMember xlink:href="#poly-a007d578-0184-474d-9dd6-0a514b141c5b"/>
							<gml:surfaceMember xlink:href="#poly-4ad45225-176b-43ae-b2cc-60dbb5860af0"/>
							<gml:surfaceMember xlink:href="#poly-9ed0cb7c-71a3-47f5-b78e-f048bb1a1082"/>
							<gml:surfaceMember xlink:href="#poly-f3854200-5ff7-4c48-ad37-a3711a7d849d"/>
							<gml:surfaceMember xlink:href="#poly-608c0065-0259-45a1-b73a-f3d8d7001794"/>
							<gml:surfaceMember xlink:href="#poly-96f74bc9-4933-42d6-9199-7290668bec40"/>
							<gml:surfaceMember xlink:href="#poly-2efdb165-6c7a-419e-a337-939e4632c6bf"/>
							<gml:surfaceMember xlink:href="#poly-2b536b6d-6206-4e9d-8dde-6066ec8b824e"/>
							<gml:surfaceMember xlink:href="#poly-65020d7c-9bd8-477f-9992-be12266ccca0"/>
							<gml:surfaceMember xlink:href="#poly-b6c56544-3878-4565-a35b-f06e938908fb"/>
							<gml:surfaceMember xlink:href="#poly-8034659b-1de8-45cb-bcb4-c4371eaa2ff8"/>
							<gml:surfaceMember xlink:href="#poly-1c616b54-ec22-4bf9-b5de-97c4d6b5664a"/>
							<gml:surfaceMember xlink:href="#poly-7c2ae640-a6e9-4d47-ad1e-25f86495649f"/>
							<gml:surfaceMember xlink:href="#poly-ac624b5b-6372-4f3f-b484-3ccefa22dd98"/>
							<gml:surfaceMember xlink:href="#poly-54ba1e55-0085-4d91-bb3b-97d2db0cb274"/>
							<gml:surfaceMember xlink:href="#poly-2ac6042f-bbd0-4853-8191-c3e15fc2c99f"/>
							<gml:surfaceMember xlink:href="#poly-033480ed-9680-4f3c-86d7-613406c00aa5"/>
							<gml:surfaceMember xlink:href="#poly-5c59ef5f-6dfc-4bdd-97eb-69f0650e5948"/>
							<gml:surfaceMember xlink:href="#poly-e563d0eb-3f6e-441b-a223-9c8226be6fdd"/>
							<gml:surfaceMember xlink:href="#poly-825d88b5-6ec7-4d19-90b2-da992851d33d"/>
							<gml:surfaceMember xlink:href="#poly-f4d37158-8c44-488c-a151-5a80910962d6"/>
							<gml:surfaceMember xlink:href="#poly-120edb5c-61e8-4923-879f-66e42f47e1be"/>
							<gml:surfaceMember xlink:href="#poly-58323be9-7264-4f29-b532-afbe66b6acbd"/>
							<gml:surfaceMember xlink:href="#poly-1d6ad3f7-ba27-45de-b562-1d3d6d571dda"/>
							<gml:surfaceMember xlink:href="#poly-e5b16ab0-f59e-4c4e-8987-e2e9b3c4f796"/>
							<gml:surfaceMember xlink:href="#poly-07cee00a-5424-463c-bfbc-405306c1ab7e"/>
							<gml:surfaceMember xlink:href="#poly-1ecf11f3-17ba-4619-9e91-1ad695c980ac"/>
							<gml:surfaceMember xlink:href="#poly-7c75343e-d5f4-4227-a4d0-852155f28025"/>
							<gml:surfaceMember xlink:href="#poly-9cf3e922-b2af-4304-835b-b26873155fa5"/>
							<gml:surfaceMember xlink:href="#poly-6308f272-19f6-49ed-a1d1-de37063eeaf1"/>
							<gml:surfaceMember xlink:href="#poly-17a4f1b3-b07e-4136-adc5-de2f0a7aaf3c"/>
							<gml:surfaceMember xlink:href="#poly-894daba6-ad93-4f41-8e88-e98bc339d4d6"/>
							<gml:surfaceMember xlink:href="#poly-0e32a43d-68ff-43ab-b1e8-c4ac50e69c53"/>
							<gml:surfaceMember xlink:href="#poly-94d09146-7ce3-4dbe-9d92-36c8ba50fe7e"/>
							<gml:surfaceMember xlink:href="#poly-24efe0ef-c6ca-4cbc-b1c8-afc24d0a07b1"/>
							<gml:surfaceMember xlink:href="#poly-65aa55b2-8242-45d4-bd54-116192c0327d"/>
							<gml:surfaceMember xlink:href="#poly-e5117754-7b97-449a-9c72-0fcb6b54d6e0"/>
							<gml:surfaceMember xlink:href="#poly-a0ace30a-1d88-4a32-8232-917a278dc427"/>
							<gml:surfaceMember xlink:href="#poly-6cd68c81-eee3-4835-85eb-19169516a7f7"/>
							<gml:surfaceMember xlink:href="#poly-6135ed5e-b5cf-4fe1-801e-2ce358c78d8c"/>
							<gml:surfaceMember xlink:href="#poly-49e0d949-e462-46ab-b194-508233890dc9"/>
							<gml:surfaceMember xlink:href="#poly-f40ad4be-e59a-4fa1-963f-c9233abd8f0b"/>
							<gml:surfaceMember xlink:href="#poly-1d316d17-3b05-4d36-ae85-80a39671ccd2"/>
							<gml:surfaceMember xlink:href="#poly-23bdf4dc-1ccc-44be-b38e-bf03e0732466"/>
							<gml:surfaceMember xlink:href="#poly-6dd37635-ec30-4b59-86bf-481525e1ad47"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_44e2d6f0-8521-4abd-869b-a93924cfe351_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-93f78a91-4c2e-4aad-9fda-befbb98292ca">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67076659614768 139.74095772194588 28.815 35.670740495486434 139.74099702164682 28.815 35.670720226124004 139.74097679711076 28.815 35.67074632678722 139.74093750845947 28.815 35.67076659614768 139.74095772194588 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76a8c962-af8d-498f-958b-e3a9177486c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-76a8c962-af8d-498f-958b-e3a9177486c1_0">
											<gml:posList>35.67074632678722 139.74093750845947 28.815 35.67074632678722 139.74093750845947 30.611 35.67076659614768 139.74095772194588 30.611 35.67076659614768 139.74095772194588 28.815 35.67074632678722 139.74093750845947 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09a514eb-3077-4d36-90bc-040561893927">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09a514eb-3077-4d36-90bc-040561893927_0">
											<gml:posList>35.670720226124004 139.74097679711076 28.815 35.670720226124004 139.74097679711076 30.611 35.67074632678722 139.74093750845947 30.611 35.67074632678722 139.74093750845947 28.815 35.670720226124004 139.74097679711076 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6cf0540-1dde-4755-89c7-39b00fbded58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6cf0540-1dde-4755-89c7-39b00fbded58_0">
											<gml:posList>35.67076659614768 139.74095772194588 30.611 35.67074632678722 139.74093750845947 30.611 35.670720226124004 139.74097679711076 30.611 35.670740495486434 139.74099702164682 30.611 35.67076659614768 139.74095772194588 30.611</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea7f4818-7bcc-4cd7-8dea-c5089d8cb446">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea7f4818-7bcc-4cd7-8dea-c5089d8cb446_0">
											<gml:posList>35.67076659614768 139.74095772194588 28.815 35.67076659614768 139.74095772194588 30.611 35.670740495486434 139.74099702164682 30.611 35.670740495486434 139.74099702164682 28.815 35.67076659614768 139.74095772194588 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaaa1610-492e-4b09-8a91-22f7e76dba64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aaaa1610-492e-4b09-8a91-22f7e76dba64_0">
											<gml:posList>35.670740495486434 139.74099702164682 28.815 35.670740495486434 139.74099702164682 30.611 35.670720226124004 139.74097679711076 30.611 35.670720226124004 139.74097679711076 28.815 35.670740495486434 139.74099702164682 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_44e2d6f0-8521-4abd-869b-a93924cfe351_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71feb283-39e4-4695-ab52-168e82f246ae">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670719219820214 139.74101627776832 28.263 35.67071163771823 139.7410260072471 28.263 35.67070346394365 139.74101643951195 28.263 35.67071104604487 139.74100671003328 28.263 35.670719219820214 139.74101627776832 28.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f0fae79-0aec-4f53-9c9c-9d647650d979">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67073260968226 139.74103387016598 26.537 35.67074513928452 139.74104630493295 26.537 35.670730796762626 139.74106764081597 26.537 35.670718411492146 139.74105534948373 26.537 35.67073260968226 139.74103387016598 26.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a77035d-0193-4919-b812-6b3fc62c7f5d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67074513928452 139.74104630493295 26.875 35.670746618669426 139.74104778343565 26.875 35.67073242046841 139.7410692517084 26.875 35.670730796762626 139.74106764081597 26.875 35.67074513928452 139.74104630493295 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71e81162-f4db-4e4e-b37b-0c2c776226fc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67078529634626 139.74094168324314 28.815 35.670779425713526 139.74094991951247 28.815 35.67075780203858 139.74092676926685 28.815 35.67076367266976 139.74091853299802 28.815 35.67078529634626 139.74094168324314 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9245854-b94a-484f-9b4d-0d32ca3747bd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67082101350901 139.74081875177177 33.231 35.67080340333989 139.7408456809221 33.231 35.67079713407694 139.7408395353555 33.231 35.67081475324994 139.74081259514924 33.231 35.67082101350901 139.74081875177177 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c8e969a-31c4-4cc0-9568-50f5bcca7821">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c8e969a-31c4-4cc0-9568-50f5bcca7821_0">
											<gml:posList>35.67081475324994 139.74081259514924 33.231 35.67081475324994 139.74081259514924 34.051 35.67082101350901 139.74081875177177 34.051 35.67082101350901 139.74081875177177 33.231 35.67081475324994 139.74081259514924 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02c5fd26-1714-411b-9326-c893dd460bf6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02c5fd26-1714-411b-9326-c893dd460bf6_0">
											<gml:posList>35.67081475324994 139.74081259514924 33.231 35.67079713407694 139.7408395353555 33.231 35.67079713407694 139.7408395353555 34.051 35.67081475324994 139.74081259514924 34.051 35.67081475324994 139.74081259514924 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca13f5be-bf94-469b-b1a7-926331905db1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca13f5be-bf94-469b-b1a7-926331905db1_0">
											<gml:posList>35.67082101350901 139.74081875177177 34.051 35.67081475324994 139.74081259514924 34.051 35.67079713407694 139.7408395353555 34.051 35.67080340333989 139.7408456809221 34.051 35.67082101350901 139.74081875177177 34.051</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6de013a-37eb-4ad6-a6a9-faede16596ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6de013a-37eb-4ad6-a6a9-faede16596ef_0">
											<gml:posList>35.67080340333989 139.7408456809221 33.231 35.67082101350901 139.74081875177177 33.231 35.67082101350901 139.74081875177177 34.051 35.67080340333989 139.7408456809221 34.051 35.67080340333989 139.7408456809221 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8ea322f-3be6-4039-9b6e-774b4c4a0167">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8ea322f-3be6-4039-9b6e-774b4c4a0167_0">
											<gml:posList>35.67079713407694 139.7408395353555 33.231 35.67080340333989 139.7408456809221 33.231 35.67080340333989 139.7408456809221 34.051 35.67079713407694 139.7408395353555 34.051 35.67079713407694 139.7408395353555 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5e6144b-f261-4fcb-b2a2-12906327d112">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5e6144b-f261-4fcb-b2a2-12906327d112_0">
											<gml:posList>35.67076367266976 139.74091853299802 28.815 35.67075780203858 139.74092676926685 28.815 35.67075780203858 139.74092676926685 29.643 35.67076367266976 139.74091853299802 29.643 35.67076367266976 139.74091853299802 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e63b044-a2b8-4729-ba00-67a3e4ccf88e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e63b044-a2b8-4729-ba00-67a3e4ccf88e_0">
											<gml:posList>35.67076367266976 139.74091853299802 28.815 35.67076367266976 139.74091853299802 29.643 35.67078529634626 139.74094168324314 29.643 35.67078529634626 139.74094168324314 28.815 35.67076367266976 139.74091853299802 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e976a1a-7176-4e84-be73-81b75629658e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e976a1a-7176-4e84-be73-81b75629658e_0">
											<gml:posList>35.67078529634626 139.74094168324314 29.643 35.67076367266976 139.74091853299802 29.643 35.67075780203858 139.74092676926685 29.643 35.670779425713526 139.74094991951247 29.643 35.67078529634626 139.74094168324314 29.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29812c17-c77f-496e-ae39-7fe1ff02a244">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29812c17-c77f-496e-ae39-7fe1ff02a244_0">
											<gml:posList>35.67075780203858 139.74092676926685 28.815 35.670779425713526 139.74094991951247 28.815 35.670779425713526 139.74094991951247 29.643 35.67075780203858 139.74092676926685 29.643 35.67075780203858 139.74092676926685 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cdbda3b3-db32-4d3a-b384-941c55b42572">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cdbda3b3-db32-4d3a-b384-941c55b42572_0">
											<gml:posList>35.670779425713526 139.74094991951247 28.815 35.67078529634626 139.74094168324314 28.815 35.67078529634626 139.74094168324314 29.643 35.670779425713526 139.74094991951247 29.643 35.670779425713526 139.74094991951247 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2f28570-d150-4fc5-8902-69456aee9d6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2f28570-d150-4fc5-8902-69456aee9d6d_0">
											<gml:posList>35.670719219820214 139.74101627776832 28.263 35.67071104604487 139.74100671003328 28.263 35.67071104604487 139.74100671003328 29.524 35.670719219820214 139.74101627776832 29.524 35.670719219820214 139.74101627776832 28.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b515cf7-daed-4f21-bc7e-b2545bd036fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b515cf7-daed-4f21-bc7e-b2545bd036fe_0">
											<gml:posList>35.67070346394365 139.74101643951195 28.263 35.67070346394365 139.74101643951195 29.524 35.67071104604487 139.74100671003328 29.524 35.67071104604487 139.74100671003328 28.263 35.67070346394365 139.74101643951195 28.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a43a2833-52b9-4743-a7bb-735cd32f9952">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a43a2833-52b9-4743-a7bb-735cd32f9952_0">
											<gml:posList>35.67070346394365 139.74101643951195 29.524 35.67071163771823 139.7410260072471 29.524 35.670719219820214 139.74101627776832 29.524 35.67071104604487 139.74100671003328 29.524 35.67070346394365 139.74101643951195 29.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-445010b3-87bb-4dc1-bd04-9929ff2811d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-445010b3-87bb-4dc1-bd04-9929ff2811d8_0">
											<gml:posList>35.67071163771823 139.7410260072471 28.263 35.670719219820214 139.74101627776832 28.263 35.670719219820214 139.74101627776832 29.524 35.67071163771823 139.7410260072471 29.524 35.67071163771823 139.7410260072471 28.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62a9611f-5c9d-4659-9936-195d7c2c0bce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62a9611f-5c9d-4659-9936-195d7c2c0bce_0">
											<gml:posList>35.67071163771823 139.7410260072471 28.263 35.67071163771823 139.7410260072471 29.524 35.67070346394365 139.74101643951195 29.524 35.67070346394365 139.74101643951195 28.263 35.67071163771823 139.7410260072471 28.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3fd6ff75-1771-4214-9038-8df6bff1c57f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3fd6ff75-1771-4214-9038-8df6bff1c57f_0">
											<gml:posList>35.67074513928452 139.74104630493295 26.875 35.67074513928452 139.74104630493295 26.537 35.67073260968226 139.74103387016598 26.537 35.67073260968226 139.74103387016598 27.822 35.670746618669426 139.74104778343565 27.822 35.670746618669426 139.74104778343565 26.875 35.67074513928452 139.74104630493295 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-869caff6-349f-45a9-9e1b-f9ad82bc379f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-869caff6-349f-45a9-9e1b-f9ad82bc379f_0">
											<gml:posList>35.67073260968226 139.74103387016598 26.537 35.670718411492146 139.74105534948373 26.537 35.670718411492146 139.74105534948373 27.822 35.67073260968226 139.74103387016598 27.822 35.67073260968226 139.74103387016598 26.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbca7d89-5c23-44b0-b851-f34776b026e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbca7d89-5c23-44b0-b851-f34776b026e6_0">
											<gml:posList>35.67073260968226 139.74103387016598 27.822 35.670718411492146 139.74105534948373 27.822 35.67073242046841 139.7410692517084 27.822 35.670746618669426 139.74104778343565 27.822 35.67073260968226 139.74103387016598 27.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6234971d-67aa-4d32-8c49-375d1c5b302e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6234971d-67aa-4d32-8c49-375d1c5b302e_0">
											<gml:posList>35.67074513928452 139.74104630493295 26.875 35.670730796762626 139.74106764081597 26.875 35.670730796762626 139.74106764081597 26.537 35.67074513928452 139.74104630493295 26.537 35.67074513928452 139.74104630493295 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87a42494-fe23-4828-bc12-ab5700e8b25d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87a42494-fe23-4828-bc12-ab5700e8b25d_0">
											<gml:posList>35.67073242046841 139.7410692517084 26.875 35.670746618669426 139.74104778343565 26.875 35.670746618669426 139.74104778343565 27.822 35.67073242046841 139.7410692517084 27.822 35.67073242046841 139.7410692517084 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cca5f4d-7e81-4070-a8a0-2606afc3bfc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cca5f4d-7e81-4070-a8a0-2606afc3bfc3_0">
											<gml:posList>35.67073242046841 139.7410692517084 27.822 35.670718411492146 139.74105534948373 27.822 35.670718411492146 139.74105534948373 26.537 35.670730796762626 139.74106764081597 26.537 35.670730796762626 139.74106764081597 26.875 35.67073242046841 139.7410692517084 26.875 35.67073242046841 139.7410692517084 27.822</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-09e2ce78-2cc2-43dd-8d06-05a5fab18dad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09e2ce78-2cc2-43dd-8d06-05a5fab18dad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09e2ce78-2cc2-43dd-8d06-05a5fab18dad">
											<gml:posList>35.670784917137496 139.7408469283879 9.779 35.67077670828668 139.74083865312153 9.779 35.67081965408562 139.74077398260533 9.779 35.67088568418707 139.7408385274022 9.779 35.67070750834666 139.74110693722875 9.779 35.67065013723286 139.74104978340523 9.779 35.670784917137496 139.7408469283879 9.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d647a14e-b081-43ec-b836-79f2af3745d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d647a14e-b081-43ec-b836-79f2af3745d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d647a14e-b081-43ec-b836-79f2af3745d6">
											<gml:posList>35.670758016842115 139.7410305491163 27.764 35.67088568418707 139.7408385274022 27.764 35.67087384026846 139.74082695346834 30.036 35.670758016842115 139.7410305491163 27.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-62ab4213-4729-4815-88da-01507955176e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-62ab4213-4729-4815-88da-01507955176e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-62ab4213-4729-4815-88da-01507955176e">
											<gml:posList>35.67082359605402 139.74077784426672 34.112 35.67082398691294 139.74078209664896 34.112 35.67084644796635 139.74080404185892 34.112 35.670849917884354 139.74080356286245 34.112 35.67082359605402 139.74077784426672 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a09a16ec-344a-40b8-a82d-bddccc69d3a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a09a16ec-344a-40b8-a82d-bddccc69d3a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a09a16ec-344a-40b8-a82d-bddccc69d3a5">
											<gml:posList>35.67081965408562 139.74077398260533 30.036 35.67077670828668 139.74083865312153 30.036 35.6707811374607 139.74084312176933 30.036 35.67082359605402 139.74077784426672 30.036 35.67081965408562 139.74077398260533 30.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ffe009af-6965-4ae7-996d-2d48ce1fed34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffe009af-6965-4ae7-996d-2d48ce1fed34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffe009af-6965-4ae7-996d-2d48ce1fed34">
											<gml:posList>35.6707811374607 139.74084312176933 34.112 35.670784589368424 139.74084266488833 34.112 35.67082398691294 139.74078209664896 34.112 35.67082359605402 139.74077784426672 34.112 35.6707811374607 139.74084312176933 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-59060661-71dc-465c-a87e-55ed60ece47e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59060661-71dc-465c-a87e-55ed60ece47e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59060661-71dc-465c-a87e-55ed60ece47e">
											<gml:posList>35.670849917884354 139.74080356286245 30.036 35.67084814427772 139.74080629335134 30.036 35.67086978448391 139.74082746627892 30.036 35.67087384026846 139.74082695346834 30.036 35.670849917884354 139.74080356286245 30.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-305d5d0c-0e23-4507-af60-daa72488e550">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-305d5d0c-0e23-4507-af60-daa72488e550">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-305d5d0c-0e23-4507-af60-daa72488e550">
											<gml:posList>35.670788387089644 139.74084649357889 33.231 35.67078769383905 139.74084754377856 33.231 35.67080628510134 139.74086572666533 33.231 35.67084644796635 139.74080404185892 33.231 35.67082398691294 139.74078209664896 33.231 35.670784589368424 139.74084266488833 33.231 35.670788387089644 139.74084649357889 33.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a4013661-62f0-4286-846e-8d803fb82b9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4013661-62f0-4286-846e-8d803fb82b9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4013661-62f0-4286-846e-8d803fb82b9f">
											<gml:posList>35.670849917884354 139.74080356286245 34.112 35.67084644796635 139.74080404185892 34.112 35.67080628510134 139.74086572666533 34.112 35.67080667596564 139.74086999009342 34.112 35.670849917884354 139.74080356286245 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f98c42f-9c2d-484f-b9d7-0b0e48172d1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f98c42f-9c2d-484f-b9d7-0b0e48172d1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f98c42f-9c2d-484f-b9d7-0b0e48172d1c">
											<gml:posList>35.670784917137496 139.7408469283879 34.112 35.670788387089644 139.74084649357889 34.112 35.670784589368424 139.74084266488833 34.112 35.6707811374607 139.74084312176933 34.112 35.670784917137496 139.7408469283879 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb593272-1604-4770-b324-652f5f12f21c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb593272-1604-4770-b324-652f5f12f21c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb593272-1604-4770-b324-652f5f12f21c">
											<gml:posList>35.670784917137496 139.7408469283879 34.112 35.67078419687119 139.74084801175766 34.112 35.67078769383905 139.74084754377856 34.112 35.670788387089644 139.74084649357889 34.112 35.670784917137496 139.7408469283879 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0049abe3-5e99-44ff-8a95-5dc5646491bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0049abe3-5e99-44ff-8a95-5dc5646491bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0049abe3-5e99-44ff-8a95-5dc5646491bb">
											<gml:posList>35.67080667596564 139.74086999009342 34.112 35.67080628510134 139.74086572666533 34.112 35.67078769383905 139.74084754377856 34.112 35.67078419687119 139.74084801175766 34.112 35.67080667596564 139.74086999009342 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38a116e2-159a-4441-a693-0a7132314837">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38a116e2-159a-4441-a693-0a7132314837">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38a116e2-159a-4441-a693-0a7132314837">
											<gml:posList>35.67074423918631 139.74101269204874 28.815 35.67086978448391 139.74082746627892 28.815 35.67084814427772 139.74080629335134 28.815 35.67080667596564 139.74086999009342 28.815 35.67078640689603 139.74085017428615 28.815 35.67070423349298 139.7409738330308 28.815 35.67074423918631 139.74101269204874 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d87decf-e001-41f6-a470-19249268b291">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d87decf-e001-41f6-a470-19249268b291">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d87decf-e001-41f6-a470-19249268b291">
											<gml:posList>35.67078419687119 139.74084801175766 30.036 35.670700195769 139.7409743899972 30.036 35.67070423349298 139.7409738330308 30.036 35.67078640689603 139.74085017428615 30.036 35.67078419687119 139.74084801175766 30.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2e92d20-fc28-44c4-81ec-86a52f5dd610">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2e92d20-fc28-44c4-81ec-86a52f5dd610">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2e92d20-fc28-44c4-81ec-86a52f5dd610">
											<gml:posList>35.67087384026846 139.74082695346834 30.036 35.67086978448391 139.74082746627892 30.036 35.67074423918631 139.74101269204874 30.036 35.67074464853864 139.74101756299996 30.036 35.67087384026846 139.74082695346834 30.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4425a7dc-c526-4d1f-83cc-ae7770a828f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4425a7dc-c526-4d1f-83cc-ae7770a828f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4425a7dc-c526-4d1f-83cc-ae7770a828f8">
											<gml:posList>35.67087384026846 139.74082695346834 30.036 35.67074464853864 139.74101756299996 30.036 35.670758016842115 139.7410305491163 27.764 35.67087384026846 139.74082695346834 30.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1876b7a0-ae54-422c-9656-c36f7c98bedc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1876b7a0-ae54-422c-9656-c36f7c98bedc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1876b7a0-ae54-422c-9656-c36f7c98bedc">
											<gml:posList>35.67074464853864 139.74101756299996 30.036 35.67074423918631 139.74101269204874 30.036 35.67070423349298 139.7409738330308 30.036 35.670700195769 139.7409743899972 30.036 35.67074464853864 139.74101756299996 30.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-75b5a106-63bf-47dd-94f9-ca2d52995e27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75b5a106-63bf-47dd-94f9-ca2d52995e27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75b5a106-63bf-47dd-94f9-ca2d52995e27">
											<gml:posList>35.67071001001897 139.74098392269923 24.847 35.670700195769 139.7409743899972 24.847 35.670677543385516 139.74100850497473 24.847 35.67068727663635 139.741018203466 24.847 35.67071001001897 139.74098392269923 24.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e824aabe-499d-4e78-bdd5-d7a51452248c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e824aabe-499d-4e78-bdd5-d7a51452248c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e824aabe-499d-4e78-bdd5-d7a51452248c">
											<gml:posList>35.67069527318264 139.74100823049358 28.678 35.670697878097585 139.74100816121614 28.678 35.67070741425304 139.74099592197587 28.678 35.67070734871737 139.74099274071563 28.678 35.67069527318264 139.74100823049358 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d002eaa-aa57-4401-82ad-3dd9fc36d602">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d002eaa-aa57-4401-82ad-3dd9fc36d602">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d002eaa-aa57-4401-82ad-3dd9fc36d602">
											<gml:posList>35.67070734871737 139.74099274071563 28.678 35.67070741425304 139.74099592197587 28.678 35.67073283774758 139.7410256624965 28.678 35.670735433657256 139.74102560427627 28.678 35.67070734871737 139.74099274071563 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c689203-7cc8-46e1-a4c7-f4366a858cbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c689203-7cc8-46e1-a4c7-f4366a858cbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c689203-7cc8-46e1-a4c7-f4366a858cbd">
											<gml:posList>35.670700848659955 139.74101474139246 28.678 35.6707034535749 139.74101467211523 28.678 35.670697878097585 139.74100816121614 28.678 35.67069527318264 139.74100823049358 28.678 35.670700848659955 139.74101474139246 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-387a8e8c-d854-44a0-8f0b-dbfd6f33dc19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-387a8e8c-d854-44a0-8f0b-dbfd6f33dc19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-387a8e8c-d854-44a0-8f0b-dbfd6f33dc19">
											<gml:posList>35.67075495306563 139.74103171250613 26.537 35.670710941211084 139.74098754481471 26.537 35.67070734871737 139.74099274071563 26.537 35.670735433657256 139.74102560427627 26.537 35.670720521589736 139.74104474260102 26.537 35.67075495306563 139.74103171250613 26.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83ca0505-427b-4bcb-a35c-525db72d60cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83ca0505-427b-4bcb-a35c-525db72d60cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83ca0505-427b-4bcb-a35c-525db72d60cc">
											<gml:posList>35.670700848659955 139.74101474139246 28.678 35.67069800311841 139.74101838994903 28.678 35.670700608024895 139.74101830962562 28.678 35.6707034535749 139.74101467211523 28.678 35.670700848659955 139.74101474139246 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-234a4d8e-974c-4664-8a69-993fd911da2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-234a4d8e-974c-4664-8a69-993fd911da2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-234a4d8e-974c-4664-8a69-993fd911da2c">
											<gml:posList>35.6707034535749 139.74101467211523 28.263 35.670700608024895 139.74101830962562 28.263 35.67072046506061 139.7410415502835 28.263 35.67073283774758 139.7410256624965 28.263 35.67070741425304 139.74099592197587 28.263 35.670697878097585 139.74100816121614 28.263 35.6707034535749 139.74101467211523 28.263</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e448f54f-15dd-48f7-9c23-31655aee493a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e448f54f-15dd-48f7-9c23-31655aee493a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e448f54f-15dd-48f7-9c23-31655aee493a">
											<gml:posList>35.670710941211084 139.74098754481471 26.875 35.67075495306563 139.74103171250613 26.875 35.670758016842115 139.7410305491163 26.875 35.67071001001897 139.74098392269923 26.875 35.67065988851633 139.74105949292377 26.875 35.670663268340576 139.74105906927466 26.875 35.670696373847704 139.7410095216436 26.875 35.67069527318264 139.74100823049358 26.875 35.67070734871737 139.74099274071563 26.875 35.670710941211084 139.74098754481471 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a007d578-0184-474d-9dd6-0a514b141c5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a007d578-0184-474d-9dd6-0a514b141c5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a007d578-0184-474d-9dd6-0a514b141c5b">
											<gml:posList>35.670720521589736 139.74104474260102 28.678 35.67072046506061 139.7410415502835 28.678 35.670700608024895 139.74101830962562 28.678 35.67069800311841 139.74101838994903 28.678 35.670720521589736 139.74104474260102 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ad45225-176b-43ae-b2cc-60dbb5860af0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ad45225-176b-43ae-b2cc-60dbb5860af0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ad45225-176b-43ae-b2cc-60dbb5860af0">
											<gml:posList>35.67068727663635 139.741018203466 19.691 35.670677543385516 139.74100850497473 19.691 35.67065013723286 139.74104978340523 19.691 35.67065988851633 139.74105949292377 19.691 35.67068727663635 139.741018203466 19.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ed0cb7c-71a3-47f5-b78e-f048bb1a1082">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ed0cb7c-71a3-47f5-b78e-f048bb1a1082">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ed0cb7c-71a3-47f5-b78e-f048bb1a1082">
											<gml:posList>35.670735433657256 139.74102560427627 28.678 35.67073283774758 139.7410256624965 28.678 35.67072046506061 139.7410415502835 28.678 35.670720521589736 139.74104474260102 28.678 35.670735433657256 139.74102560427627 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3854200-5ff7-4c48-ad37-a3711a7d849d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3854200-5ff7-4c48-ad37-a3711a7d849d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3854200-5ff7-4c48-ad37-a3711a7d849d">
											<gml:posList>35.67070716265242 139.74110279526218 26.537 35.67075495306563 139.74103171250613 26.537 35.670720521589736 139.74104474260102 26.537 35.67069800311841 139.74101838994903 26.537 35.670700848659955 139.74101474139246 26.537 35.670696373847704 139.7410095216436 26.537 35.670663268340576 139.74105906927466 26.537 35.67070716265242 139.74110279526218 26.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-608c0065-0259-45a1-b73a-f3d8d7001794">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-608c0065-0259-45a1-b73a-f3d8d7001794">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-608c0065-0259-45a1-b73a-f3d8d7001794">
											<gml:posList>35.670758016842115 139.7410305491163 26.875 35.67075495306563 139.74103171250613 26.875 35.67070716265242 139.74110279526218 26.875 35.67070750834666 139.74110693722875 26.875 35.670758016842115 139.7410305491163 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96f74bc9-4933-42d6-9199-7290668bec40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96f74bc9-4933-42d6-9199-7290668bec40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96f74bc9-4933-42d6-9199-7290668bec40">
											<gml:posList>35.67070750834666 139.74110693722875 26.875 35.67070716265242 139.74110279526218 26.875 35.670663268340576 139.74105906927466 26.875 35.67065988851633 139.74105949292377 26.875 35.67070750834666 139.74110693722875 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2efdb165-6c7a-419e-a337-939e4632c6bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2efdb165-6c7a-419e-a337-939e4632c6bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2efdb165-6c7a-419e-a337-939e4632c6bf">
											<gml:posList>35.670784589368424 139.74084266488833 34.112 35.670784589368424 139.74084266488833 33.231 35.67082398691294 139.74078209664896 33.231 35.67082398691294 139.74078209664896 34.112 35.670784589368424 139.74084266488833 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2b536b6d-6206-4e9d-8dde-6066ec8b824e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2b536b6d-6206-4e9d-8dde-6066ec8b824e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2b536b6d-6206-4e9d-8dde-6066ec8b824e">
											<gml:posList>35.67084644796635 139.74080404185892 34.112 35.67084644796635 139.74080404185892 33.231 35.67080628510134 139.74086572666533 33.231 35.67080628510134 139.74086572666533 34.112 35.67084644796635 139.74080404185892 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65020d7c-9bd8-477f-9992-be12266ccca0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65020d7c-9bd8-477f-9992-be12266ccca0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65020d7c-9bd8-477f-9992-be12266ccca0">
											<gml:posList>35.67074423918631 139.74101269204874 30.036 35.67086978448391 139.74082746627892 30.036 35.67086978448391 139.74082746627892 28.815 35.67074423918631 139.74101269204874 28.815 35.67074423918631 139.74101269204874 30.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6c56544-3878-4565-a35b-f06e938908fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6c56544-3878-4565-a35b-f06e938908fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6c56544-3878-4565-a35b-f06e938908fb">
											<gml:posList>35.67070734871737 139.74099274071563 26.875 35.67070734871737 139.74099274071563 26.537 35.670710941211084 139.74098754481471 26.537 35.670710941211084 139.74098754481471 26.875 35.67070734871737 139.74099274071563 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8034659b-1de8-45cb-bcb4-c4371eaa2ff8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8034659b-1de8-45cb-bcb4-c4371eaa2ff8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8034659b-1de8-45cb-bcb4-c4371eaa2ff8">
											<gml:posList>35.67072046506061 139.7410415502835 28.678 35.67072046506061 139.7410415502835 28.263 35.670700608024895 139.74101830962562 28.263 35.670700608024895 139.74101830962562 28.678 35.67072046506061 139.7410415502835 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c616b54-ec22-4bf9-b5de-97c4d6b5664a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c616b54-ec22-4bf9-b5de-97c4d6b5664a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c616b54-ec22-4bf9-b5de-97c4d6b5664a">
											<gml:posList>35.67075495306563 139.74103171250613 26.875 35.67075495306563 139.74103171250613 26.537 35.67070716265242 139.74110279526218 26.537 35.67070716265242 139.74110279526218 26.875 35.67075495306563 139.74103171250613 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c2ae640-a6e9-4d47-ad1e-25f86495649f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c2ae640-a6e9-4d47-ad1e-25f86495649f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c2ae640-a6e9-4d47-ad1e-25f86495649f">
											<gml:posList>35.67070750834666 139.74110693722875 9.779 35.67070750834666 139.74110693722875 26.875 35.67065988851633 139.74105949292377 26.875 35.67065988851633 139.74105949292377 19.691 35.67065013723286 139.74104978340523 19.691 35.67065013723286 139.74104978340523 9.779 35.67070750834666 139.74110693722875 9.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac624b5b-6372-4f3f-b484-3ccefa22dd98">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac624b5b-6372-4f3f-b484-3ccefa22dd98">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac624b5b-6372-4f3f-b484-3ccefa22dd98">
											<gml:posList>35.670663268340576 139.74105906927466 26.875 35.670663268340576 139.74105906927466 26.537 35.670696373847704 139.7410095216436 26.537 35.670696373847704 139.7410095216436 26.875 35.670663268340576 139.74105906927466 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-54ba1e55-0085-4d91-bb3b-97d2db0cb274">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54ba1e55-0085-4d91-bb3b-97d2db0cb274">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54ba1e55-0085-4d91-bb3b-97d2db0cb274">
											<gml:posList>35.67068727663635 139.741018203466 19.691 35.67068727663635 139.741018203466 24.847 35.670677543385516 139.74100850497473 24.847 35.670677543385516 139.74100850497473 19.691 35.67068727663635 139.741018203466 19.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ac6042f-bbd0-4853-8191-c3e15fc2c99f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ac6042f-bbd0-4853-8191-c3e15fc2c99f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ac6042f-bbd0-4853-8191-c3e15fc2c99f">
											<gml:posList>35.67068727663635 139.741018203466 24.847 35.67068727663635 139.741018203466 19.691 35.67065988851633 139.74105949292377 19.691 35.67065988851633 139.74105949292377 26.875 35.67071001001897 139.74098392269923 26.875 35.67071001001897 139.74098392269923 24.847 35.67068727663635 139.741018203466 24.847</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-033480ed-9680-4f3c-86d7-613406c00aa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-033480ed-9680-4f3c-86d7-613406c00aa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-033480ed-9680-4f3c-86d7-613406c00aa5">
											<gml:posList>35.67070716265242 139.74110279526218 26.875 35.67070716265242 139.74110279526218 26.537 35.670663268340576 139.74105906927466 26.537 35.670663268340576 139.74105906927466 26.875 35.67070716265242 139.74110279526218 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c59ef5f-6dfc-4bdd-97eb-69f0650e5948">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c59ef5f-6dfc-4bdd-97eb-69f0650e5948">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c59ef5f-6dfc-4bdd-97eb-69f0650e5948">
											<gml:posList>35.67069527318264 139.74100823049358 28.678 35.67069527318264 139.74100823049358 26.875 35.670696373847704 139.7410095216436 26.875 35.670696373847704 139.7410095216436 26.537 35.670700848659955 139.74101474139246 26.537 35.670700848659955 139.74101474139246 28.678 35.67069527318264 139.74100823049358 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e563d0eb-3f6e-441b-a223-9c8226be6fdd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e563d0eb-3f6e-441b-a223-9c8226be6fdd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e563d0eb-3f6e-441b-a223-9c8226be6fdd">
											<gml:posList>35.67069800311841 139.74101838994903 28.678 35.670700848659955 139.74101474139246 28.678 35.670700848659955 139.74101474139246 26.537 35.67069800311841 139.74101838994903 26.537 35.67069800311841 139.74101838994903 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-825d88b5-6ec7-4d19-90b2-da992851d33d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-825d88b5-6ec7-4d19-90b2-da992851d33d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-825d88b5-6ec7-4d19-90b2-da992851d33d">
											<gml:posList>35.6707034535749 139.74101467211523 28.678 35.6707034535749 139.74101467211523 28.263 35.670697878097585 139.74100816121614 28.263 35.670697878097585 139.74100816121614 28.678 35.6707034535749 139.74101467211523 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4d37158-8c44-488c-a151-5a80910962d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4d37158-8c44-488c-a151-5a80910962d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4d37158-8c44-488c-a151-5a80910962d6">
											<gml:posList>35.67069527318264 139.74100823049358 26.875 35.67069527318264 139.74100823049358 28.678 35.67070734871737 139.74099274071563 28.678 35.67070734871737 139.74099274071563 26.875 35.67069527318264 139.74100823049358 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-120edb5c-61e8-4923-879f-66e42f47e1be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-120edb5c-61e8-4923-879f-66e42f47e1be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-120edb5c-61e8-4923-879f-66e42f47e1be">
											<gml:posList>35.670700608024895 139.74101830962562 28.678 35.670700608024895 139.74101830962562 28.263 35.6707034535749 139.74101467211523 28.263 35.6707034535749 139.74101467211523 28.678 35.670700608024895 139.74101830962562 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-58323be9-7264-4f29-b532-afbe66b6acbd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-58323be9-7264-4f29-b532-afbe66b6acbd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-58323be9-7264-4f29-b532-afbe66b6acbd">
											<gml:posList>35.670697878097585 139.74100816121614 28.678 35.670697878097585 139.74100816121614 28.263 35.67070741425304 139.74099592197587 28.263 35.67070741425304 139.74099592197587 28.678 35.670697878097585 139.74100816121614 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d6ad3f7-ba27-45de-b562-1d3d6d571dda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d6ad3f7-ba27-45de-b562-1d3d6d571dda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d6ad3f7-ba27-45de-b562-1d3d6d571dda">
											<gml:posList>35.67069800311841 139.74101838994903 26.537 35.670720521589736 139.74104474260102 26.537 35.670720521589736 139.74104474260102 28.678 35.67069800311841 139.74101838994903 28.678 35.67069800311841 139.74101838994903 26.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5b16ab0-f59e-4c4e-8987-e2e9b3c4f796">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5b16ab0-f59e-4c4e-8987-e2e9b3c4f796">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5b16ab0-f59e-4c4e-8987-e2e9b3c4f796">
											<gml:posList>35.67078419687119 139.74084801175766 30.036 35.67078419687119 139.74084801175766 34.112 35.670784917137496 139.7408469283879 34.112 35.670784917137496 139.7408469283879 9.779 35.67065013723286 139.74104978340523 9.779 35.67065013723286 139.74104978340523 19.691 35.670677543385516 139.74100850497473 19.691 35.670677543385516 139.74100850497473 24.847 35.670700195769 139.7409743899972 24.847 35.670700195769 139.7409743899972 30.036 35.67078419687119 139.74084801175766 30.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07cee00a-5424-463c-bfbc-405306c1ab7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07cee00a-5424-463c-bfbc-405306c1ab7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07cee00a-5424-463c-bfbc-405306c1ab7e">
											<gml:posList>35.67070741425304 139.74099592197587 28.678 35.67070741425304 139.74099592197587 28.263 35.67073283774758 139.7410256624965 28.263 35.67073283774758 139.7410256624965 28.678 35.67070741425304 139.74099592197587 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ecf11f3-17ba-4619-9e91-1ad695c980ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ecf11f3-17ba-4619-9e91-1ad695c980ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ecf11f3-17ba-4619-9e91-1ad695c980ac">
											<gml:posList>35.670735433657256 139.74102560427627 28.678 35.670735433657256 139.74102560427627 26.537 35.67070734871737 139.74099274071563 26.537 35.67070734871737 139.74099274071563 26.875 35.67070734871737 139.74099274071563 28.678 35.670735433657256 139.74102560427627 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c75343e-d5f4-4227-a4d0-852155f28025">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c75343e-d5f4-4227-a4d0-852155f28025">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c75343e-d5f4-4227-a4d0-852155f28025">
											<gml:posList>35.67070423349298 139.7409738330308 30.036 35.67074423918631 139.74101269204874 30.036 35.67074423918631 139.74101269204874 28.815 35.67070423349298 139.7409738330308 28.815 35.67070423349298 139.7409738330308 30.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cf3e922-b2af-4304-835b-b26873155fa5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cf3e922-b2af-4304-835b-b26873155fa5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cf3e922-b2af-4304-835b-b26873155fa5">
											<gml:posList>35.67073283774758 139.7410256624965 28.678 35.67073283774758 139.7410256624965 28.263 35.67072046506061 139.7410415502835 28.263 35.67072046506061 139.7410415502835 28.678 35.67073283774758 139.7410256624965 28.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6308f272-19f6-49ed-a1d1-de37063eeaf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6308f272-19f6-49ed-a1d1-de37063eeaf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6308f272-19f6-49ed-a1d1-de37063eeaf1">
											<gml:posList>35.670720521589736 139.74104474260102 26.537 35.670735433657256 139.74102560427627 26.537 35.670735433657256 139.74102560427627 28.678 35.670720521589736 139.74104474260102 28.678 35.670720521589736 139.74104474260102 26.537</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-17a4f1b3-b07e-4136-adc5-de2f0a7aaf3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17a4f1b3-b07e-4136-adc5-de2f0a7aaf3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17a4f1b3-b07e-4136-adc5-de2f0a7aaf3c">
											<gml:posList>35.670700195769 139.7409743899972 30.036 35.670700195769 139.7409743899972 24.847 35.67071001001897 139.74098392269923 24.847 35.67071001001897 139.74098392269923 26.875 35.670758016842115 139.7410305491163 26.875 35.670758016842115 139.7410305491163 27.764 35.67074464853864 139.74101756299996 30.036 35.670700195769 139.7409743899972 30.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-894daba6-ad93-4f41-8e88-e98bc339d4d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-894daba6-ad93-4f41-8e88-e98bc339d4d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-894daba6-ad93-4f41-8e88-e98bc339d4d6">
											<gml:posList>35.670710941211084 139.74098754481471 26.875 35.670710941211084 139.74098754481471 26.537 35.67075495306563 139.74103171250613 26.537 35.67075495306563 139.74103171250613 26.875 35.670710941211084 139.74098754481471 26.875</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e32a43d-68ff-43ab-b1e8-c4ac50e69c53">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e32a43d-68ff-43ab-b1e8-c4ac50e69c53">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e32a43d-68ff-43ab-b1e8-c4ac50e69c53">
											<gml:posList>35.67070423349298 139.7409738330308 28.815 35.67078640689603 139.74085017428615 28.815 35.67078640689603 139.74085017428615 30.036 35.67070423349298 139.7409738330308 30.036 35.67070423349298 139.7409738330308 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94d09146-7ce3-4dbe-9d92-36c8ba50fe7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94d09146-7ce3-4dbe-9d92-36c8ba50fe7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94d09146-7ce3-4dbe-9d92-36c8ba50fe7e">
											<gml:posList>35.670784917137496 139.7408469283879 9.779 35.670784917137496 139.7408469283879 34.112 35.6707811374607 139.74084312176933 34.112 35.6707811374607 139.74084312176933 30.036 35.67077670828668 139.74083865312153 30.036 35.67077670828668 139.74083865312153 9.779 35.670784917137496 139.7408469283879 9.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24efe0ef-c6ca-4cbc-b1c8-afc24d0a07b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24efe0ef-c6ca-4cbc-b1c8-afc24d0a07b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24efe0ef-c6ca-4cbc-b1c8-afc24d0a07b1">
											<gml:posList>35.670788387089644 139.74084649357889 34.112 35.670788387089644 139.74084649357889 33.231 35.670784589368424 139.74084266488833 33.231 35.670784589368424 139.74084266488833 34.112 35.670788387089644 139.74084649357889 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65aa55b2-8242-45d4-bd54-116192c0327d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65aa55b2-8242-45d4-bd54-116192c0327d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65aa55b2-8242-45d4-bd54-116192c0327d">
											<gml:posList>35.67078769383905 139.74084754377856 34.112 35.67078769383905 139.74084754377856 33.231 35.670788387089644 139.74084649357889 33.231 35.670788387089644 139.74084649357889 34.112 35.67078769383905 139.74084754377856 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5117754-7b97-449a-9c72-0fcb6b54d6e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5117754-7b97-449a-9c72-0fcb6b54d6e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5117754-7b97-449a-9c72-0fcb6b54d6e0">
											<gml:posList>35.67078419687119 139.74084801175766 34.112 35.67078419687119 139.74084801175766 30.036 35.67078640689603 139.74085017428615 30.036 35.67078640689603 139.74085017428615 28.815 35.67080667596564 139.74086999009342 28.815 35.67080667596564 139.74086999009342 34.112 35.67078419687119 139.74084801175766 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a0ace30a-1d88-4a32-8232-917a278dc427">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0ace30a-1d88-4a32-8232-917a278dc427">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0ace30a-1d88-4a32-8232-917a278dc427">
											<gml:posList>35.67088568418707 139.7408385274022 9.779 35.67088568418707 139.7408385274022 27.764 35.670758016842115 139.7410305491163 27.764 35.670758016842115 139.7410305491163 26.875 35.67070750834666 139.74110693722875 26.875 35.67070750834666 139.74110693722875 9.779 35.67088568418707 139.7408385274022 9.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6cd68c81-eee3-4835-85eb-19169516a7f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cd68c81-eee3-4835-85eb-19169516a7f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cd68c81-eee3-4835-85eb-19169516a7f7">
											<gml:posList>35.67080628510134 139.74086572666533 34.112 35.67080628510134 139.74086572666533 33.231 35.67078769383905 139.74084754377856 33.231 35.67078769383905 139.74084754377856 34.112 35.67080628510134 139.74086572666533 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6135ed5e-b5cf-4fe1-801e-2ce358c78d8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6135ed5e-b5cf-4fe1-801e-2ce358c78d8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6135ed5e-b5cf-4fe1-801e-2ce358c78d8c">
											<gml:posList>35.67081965408562 139.74077398260533 9.779 35.67077670828668 139.74083865312153 9.779 35.67077670828668 139.74083865312153 30.036 35.67081965408562 139.74077398260533 30.036 35.67081965408562 139.74077398260533 9.779</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49e0d949-e462-46ab-b194-508233890dc9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49e0d949-e462-46ab-b194-508233890dc9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49e0d949-e462-46ab-b194-508233890dc9">
											<gml:posList>35.6707811374607 139.74084312176933 30.036 35.6707811374607 139.74084312176933 34.112 35.67082359605402 139.74077784426672 34.112 35.67082359605402 139.74077784426672 30.036 35.6707811374607 139.74084312176933 30.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f40ad4be-e59a-4fa1-963f-c9233abd8f0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f40ad4be-e59a-4fa1-963f-c9233abd8f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f40ad4be-e59a-4fa1-963f-c9233abd8f0b">
											<gml:posList>35.670849917884354 139.74080356286245 34.112 35.67080667596564 139.74086999009342 34.112 35.67080667596564 139.74086999009342 28.815 35.67084814427772 139.74080629335134 28.815 35.67084814427772 139.74080629335134 30.036 35.670849917884354 139.74080356286245 30.036 35.670849917884354 139.74080356286245 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d316d17-3b05-4d36-ae85-80a39671ccd2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d316d17-3b05-4d36-ae85-80a39671ccd2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d316d17-3b05-4d36-ae85-80a39671ccd2">
											<gml:posList>35.67082398691294 139.74078209664896 34.112 35.67082398691294 139.74078209664896 33.231 35.67084644796635 139.74080404185892 33.231 35.67084644796635 139.74080404185892 34.112 35.67082398691294 139.74078209664896 34.112</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-23bdf4dc-1ccc-44be-b38e-bf03e0732466">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-23bdf4dc-1ccc-44be-b38e-bf03e0732466">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-23bdf4dc-1ccc-44be-b38e-bf03e0732466">
											<gml:posList>35.67088568418707 139.7408385274022 27.764 35.67088568418707 139.7408385274022 9.779 35.67081965408562 139.74077398260533 9.779 35.67081965408562 139.74077398260533 30.036 35.67082359605402 139.74077784426672 30.036 35.67082359605402 139.74077784426672 34.112 35.670849917884354 139.74080356286245 34.112 35.670849917884354 139.74080356286245 30.036 35.67087384026846 139.74082695346834 30.036 35.67088568418707 139.7408385274022 27.764</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6dd37635-ec30-4b59-86bf-481525e1ad47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dd37635-ec30-4b59-86bf-481525e1ad47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dd37635-ec30-4b59-86bf-481525e1ad47">
											<gml:posList>35.67084814427772 139.74080629335134 28.815 35.67086978448391 139.74082746627892 28.815 35.67086978448391 139.74082746627892 30.036 35.67084814427772 139.74080629335134 30.036 35.67084814427772 139.74080629335134 28.815</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-958</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">213.3844</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>