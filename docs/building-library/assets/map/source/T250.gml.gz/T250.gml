<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_458a911f-ac45-4d6f-b7b6-46498cb27a31">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">31.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670544033192776 139.74277865973556 0 35.670524903745964 139.74276360316932 0 35.67050471985007 139.74279669852228 0 35.67059474023069 139.7428809905202 0 35.67056164969322 139.74274758873267 0 35.670544033192776 139.74277865973556 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670544033192776 139.74277865973556 7.21 35.67056164969322 139.74274758873267 7.21 35.67059474023069 139.7428809905202 7.21 35.67050471985007 139.74279669852228 7.21 35.670524903745964 139.74276360316932 7.21 35.670544033192776 139.74277865973556 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670544033192776 139.74277865973556 7.21 35.670524903745964 139.74276360316932 7.21 35.670524903745964 139.74276360316932 38.67 35.670544033192776 139.74277865973556 38.67 35.670544033192776 139.74277865973556 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670524903745964 139.74276360316932 7.21 35.67050471985007 139.74279669852228 7.21 35.67050471985007 139.74279669852228 38.67 35.670524903745964 139.74276360316932 38.67 35.670524903745964 139.74276360316932 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67050471985007 139.74279669852228 7.21 35.67059474023069 139.7428809905202 7.21 35.67059474023069 139.7428809905202 38.67 35.67050471985007 139.74279669852228 38.67 35.67050471985007 139.74279669852228 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67059474023069 139.7428809905202 7.21 35.67056164969322 139.74274758873267 7.21 35.67056164969322 139.74274758873267 38.67 35.67059474023069 139.7428809905202 38.67 35.67059474023069 139.7428809905202 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056164969322 139.74274758873267 7.21 35.670544033192776 139.74277865973556 7.21 35.670544033192776 139.74277865973556 38.67 35.67056164969322 139.74274758873267 38.67 35.67056164969322 139.74274758873267 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670544033192776 139.74277865973556 38.67 35.670524903745964 139.74276360316932 38.67 35.67050471985007 139.74279669852228 38.67 35.67059474023069 139.7428809905202 38.67 35.67056164969322 139.74274758873267 38.67 35.670544033192776 139.74277865973556 38.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7d8f27e1-4f1f-411e-bedf-add1d47b204d"/>
							<gml:surfaceMember xlink:href="#poly-7d29df1a-818a-4b89-a86b-9a8a541d062d"/>
							<gml:surfaceMember xlink:href="#poly-067a45ed-d3c9-4e11-9742-11d16628f16a"/>
							<gml:surfaceMember xlink:href="#poly-c7327653-a7b5-4f75-902a-3a9d39998927"/>
							<gml:surfaceMember xlink:href="#poly-98e1b7e0-98e4-4272-8ffe-8814112e10dc"/>
							<gml:surfaceMember xlink:href="#poly-c11161c5-42e2-4527-8f48-23ff30e19d3c"/>
							<gml:surfaceMember xlink:href="#poly-e08a87d8-a81a-4ed7-8cc6-26f7fcac1b4c"/>
							<gml:surfaceMember xlink:href="#poly-c491cfed-0c5c-43bf-add0-237e5b2e7f56"/>
							<gml:surfaceMember xlink:href="#poly-3c6554b3-f5c3-4176-a1a8-c44ae83f4b6c"/>
							<gml:surfaceMember xlink:href="#poly-81b674f9-9f75-425d-a937-c01b4316a1fa"/>
							<gml:surfaceMember xlink:href="#poly-1f8dba91-cbe3-4b47-bf64-8b4b182c5631"/>
							<gml:surfaceMember xlink:href="#poly-75a1b35e-ded4-4c8f-b16d-0f9e6602d14d"/>
							<gml:surfaceMember xlink:href="#poly-750833f8-d4e3-4d53-8b19-dc76b8e453f3"/>
							<gml:surfaceMember xlink:href="#poly-2f06f4aa-e2aa-435c-ae5c-d82424c31110"/>
							<gml:surfaceMember xlink:href="#poly-041157c5-607c-4905-91c8-fe340cfade58"/>
							<gml:surfaceMember xlink:href="#poly-b2d5c854-49e9-4706-8f8c-5a8073e80d74"/>
							<gml:surfaceMember xlink:href="#poly-4468ca40-fecc-431a-b867-bbf905a9779d"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_458a911f-ac45-4d6f-b7b6-46498cb27a31_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bc3f7fb-781d-4607-9515-380914cc838e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67053830106441 139.74281542823434 37.71 35.67054937322783 139.74279584172066 37.71 35.67057073138528 139.74281398874297 37.71 35.670559650205234 139.74283357526951 37.71 35.67053830106441 139.74281542823434 37.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4057b689-d505-4f12-9d6d-5c5a06e51dd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4057b689-d505-4f12-9d6d-5c5a06e51dd8_0">
											<gml:posList>35.67053830106441 139.74281542823434 37.71 35.67053830106441 139.74281542823434 40.946 35.67054937322783 139.74279584172066 40.946 35.67054937322783 139.74279584172066 37.71 35.67053830106441 139.74281542823434 37.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b25e4d7-45bb-4db9-8379-1acc75786bd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b25e4d7-45bb-4db9-8379-1acc75786bd8_0">
											<gml:posList>35.670559650205234 139.74283357526951 37.71 35.670559650205234 139.74283357526951 40.946 35.67053830106441 139.74281542823434 40.946 35.67053830106441 139.74281542823434 37.71 35.670559650205234 139.74283357526951 37.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7396c904-4661-448b-8941-c7716bce671b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7396c904-4661-448b-8941-c7716bce671b_0">
											<gml:posList>35.67053830106441 139.74281542823434 40.946 35.670559650205234 139.74283357526951 40.946 35.67057073138528 139.74281398874297 40.946 35.67054937322783 139.74279584172066 40.946 35.67053830106441 139.74281542823434 40.946</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71e44d40-f951-4843-99e0-b235a494fccf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71e44d40-f951-4843-99e0-b235a494fccf_0">
											<gml:posList>35.67054937322783 139.74279584172066 37.71 35.67054937322783 139.74279584172066 40.946 35.67057073138528 139.74281398874297 40.946 35.67057073138528 139.74281398874297 37.71 35.67054937322783 139.74279584172066 37.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4457271-a125-42b8-b587-3bf2d6d876e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4457271-a125-42b8-b587-3bf2d6d876e4_0">
											<gml:posList>35.67057073138528 139.74281398874297 37.71 35.67057073138528 139.74281398874297 40.946 35.670559650205234 139.74283357526951 40.946 35.670559650205234 139.74283357526951 37.71 35.67057073138528 139.74281398874297 37.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_458a911f-ac45-4d6f-b7b6-46498cb27a31_BuildingInstallation_1051">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc00855b-bc8e-48ca-8dc7-b36ddafbead7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67056070460041 139.74276136451726 37.71 35.67058210260246 139.74284449679726 37.71 35.67057984081378 139.74284537200666 37.71 35.67055844281232 139.74276223972876 37.71 35.67056070460041 139.74276136451726 37.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06818f45-2bc7-4c71-8456-d4f8b89f7a9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06818f45-2bc7-4c71-8456-d4f8b89f7a9b_0">
											<gml:posList>35.67055844281232 139.74276223972876 37.71 35.67055844281232 139.74276223972876 46.036 35.67056070460041 139.74276136451726 46.036 35.67056070460041 139.74276136451726 37.71 35.67055844281232 139.74276223972876 37.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b88c1cf-b88c-4bea-90c7-cc812d433547">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b88c1cf-b88c-4bea-90c7-cc812d433547_0">
											<gml:posList>35.67057984081378 139.74284537200666 46.036 35.67055844281232 139.74276223972876 46.036 35.67055844281232 139.74276223972876 37.71 35.67057984081378 139.74284537200666 37.71 35.67057984081378 139.74284537200666 46.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c42907a-c416-44ac-b717-1edb6bdd1e45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c42907a-c416-44ac-b717-1edb6bdd1e45_0">
											<gml:posList>35.67057984081378 139.74284537200666 46.036 35.67058210260246 139.74284449679726 46.036 35.67056070460041 139.74276136451726 46.036 35.67055844281232 139.74276223972876 46.036 35.67057984081378 139.74284537200666 46.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cf69c40-207b-4127-b5d2-601da0f9bcbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cf69c40-207b-4127-b5d2-601da0f9bcbf_0">
											<gml:posList>35.67056070460041 139.74276136451726 37.71 35.67056070460041 139.74276136451726 46.036 35.67058210260246 139.74284449679726 46.036 35.67058210260246 139.74284449679726 37.71 35.67056070460041 139.74276136451726 37.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90aa149a-261a-4fce-a0ed-99557c714497">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90aa149a-261a-4fce-a0ed-99557c714497_0">
											<gml:posList>35.67058210260246 139.74284449679726 46.036 35.67057984081378 139.74284537200666 46.036 35.67057984081378 139.74284537200666 37.71 35.67058210260246 139.74284449679726 37.71 35.67058210260246 139.74284449679726 46.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_458a911f-ac45-4d6f-b7b6-46498cb27a31_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6371e1ab-717f-476d-9274-b70f636d9d4a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67054262093114 139.74273457561895 7.29 35.67056164969323 139.74274758873267 7.29 35.67054403319277 139.74277865973556 7.29 35.670524903754256 139.7427636142156 7.29 35.67054262093114 139.74273457561895 7.29</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb181a3e-1774-4395-b504-d5a21caea8ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb181a3e-1774-4395-b504-d5a21caea8ab_0">
											<gml:posList>35.67054262093114 139.74273457561895 38.4 35.67054262093114 139.74273457561895 7.29 35.670524903754256 139.7427636142156 7.29 35.670524903754256 139.7427636142156 38.4 35.67054262093114 139.74273457561895 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee4547d1-c8e4-4e04-aa16-eb36cb1a740c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee4547d1-c8e4-4e04-aa16-eb36cb1a740c_0">
											<gml:posList>35.670524903754256 139.7427636142156 38.4 35.670524903754256 139.7427636142156 7.29 35.67054403319277 139.74277865973556 7.29 35.67054403319277 139.74277865973556 38.4 35.670524903754256 139.7427636142156 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09673950-b128-4d09-aead-3c754c327f23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09673950-b128-4d09-aead-3c754c327f23_0">
											<gml:posList>35.670524903754256 139.7427636142156 38.4 35.67054403319277 139.74277865973556 38.4 35.67056164969323 139.74274758873267 38.4 35.67054262093114 139.74273457561895 38.4 35.670524903754256 139.7427636142156 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25af8088-4451-4adb-85ac-9fbb2819a4dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25af8088-4451-4adb-85ac-9fbb2819a4dc_0">
											<gml:posList>35.67056164969323 139.74274758873267 38.4 35.67056164969323 139.74274758873267 7.29 35.67054262093114 139.74273457561895 7.29 35.67054262093114 139.74273457561895 38.4 35.67056164969323 139.74274758873267 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2aa8a994-ff74-4b9e-a516-e9cdda3aa97b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2aa8a994-ff74-4b9e-a516-e9cdda3aa97b_0">
											<gml:posList>35.67054403319277 139.74277865973556 38.4 35.67054403319277 139.74277865973556 7.29 35.67056164969323 139.74274758873267 7.29 35.67056164969323 139.74274758873267 38.4 35.67054403319277 139.74277865973556 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7d8f27e1-4f1f-411e-bedf-add1d47b204d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d8f27e1-4f1f-411e-bedf-add1d47b204d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d8f27e1-4f1f-411e-bedf-add1d47b204d">
											<gml:posList>35.67059474023068 139.7428809905202 7.21 35.670504719850065 139.74279669852228 7.21 35.67052490374595 139.74276360316932 7.21 35.67054403319277 139.74277865973556 7.21 35.67056164969323 139.74274758873267 7.21 35.67059474023068 139.7428809905202 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d29df1a-818a-4b89-a86b-9a8a541d062d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d29df1a-818a-4b89-a86b-9a8a541d062d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d29df1a-818a-4b89-a86b-9a8a541d062d">
											<gml:posList>35.670504719850065 139.74279669852228 38.4 35.67050624296163 139.74279642064545 38.4 35.670525166498194 139.7427654034161 38.4 35.67052490374595 139.74276360316932 38.4 35.670504719850065 139.74279669852228 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-067a45ed-d3c9-4e11-9742-11d16628f16a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-067a45ed-d3c9-4e11-9742-11d16628f16a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-067a45ed-d3c9-4e11-9742-11d16628f16a">
											<gml:posList>35.67054403319277 139.74277865973556 38.4 35.67052490374595 139.74276360316932 38.4 35.670525166498194 139.7427654034161 38.4 35.67054434103002 139.74278048202444 38.4 35.67054403319277 139.74277865973556 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c7327653-a7b5-4f75-902a-3a9d39998927">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7327653-a7b5-4f75-902a-3a9d39998927">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7327653-a7b5-4f75-902a-3a9d39998927">
											<gml:posList>35.670592700424145 139.7428773917312 37.71 35.67056125536634 139.74275061586016 37.71 35.67054434103002 139.74278048202444 37.71 35.670525166498194 139.7427654034161 37.71 35.67050624296163 139.74279642064545 37.71 35.670592700424145 139.7428773917312 37.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98e1b7e0-98e4-4272-8ffe-8814112e10dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98e1b7e0-98e4-4272-8ffe-8814112e10dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98e1b7e0-98e4-4272-8ffe-8814112e10dc">
											<gml:posList>35.670504719850065 139.74279669852228 38.4 35.67059474023068 139.7428809905202 38.4 35.670592700424145 139.7428773917312 38.4 35.67050624296163 139.74279642064545 38.4 35.670504719850065 139.74279669852228 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c11161c5-42e2-4527-8f48-23ff30e19d3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c11161c5-42e2-4527-8f48-23ff30e19d3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c11161c5-42e2-4527-8f48-23ff30e19d3c">
											<gml:posList>35.67054403319277 139.74277865973556 38.4 35.67054434103002 139.74278048202444 38.4 35.67056125536634 139.74275061586016 38.4 35.67056164969323 139.74274758873267 38.4 35.67054403319277 139.74277865973556 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e08a87d8-a81a-4ed7-8cc6-26f7fcac1b4c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e08a87d8-a81a-4ed7-8cc6-26f7fcac1b4c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e08a87d8-a81a-4ed7-8cc6-26f7fcac1b4c">
											<gml:posList>35.67056164969323 139.74274758873267 38.4 35.67056125536634 139.74275061586016 38.4 35.670592700424145 139.7428773917312 38.4 35.67059474023068 139.7428809905202 38.4 35.67056164969323 139.74274758873267 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c491cfed-0c5c-43bf-add0-237e5b2e7f56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c491cfed-0c5c-43bf-add0-237e5b2e7f56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c491cfed-0c5c-43bf-add0-237e5b2e7f56">
											<gml:posList>35.67054434103002 139.74278048202444 38.4 35.67054434103002 139.74278048202444 37.71 35.67056125536634 139.74275061586016 37.71 35.67056125536634 139.74275061586016 38.4 35.67054434103002 139.74278048202444 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3c6554b3-f5c3-4176-a1a8-c44ae83f4b6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3c6554b3-f5c3-4176-a1a8-c44ae83f4b6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3c6554b3-f5c3-4176-a1a8-c44ae83f4b6c">
											<gml:posList>35.67056164969323 139.74274758873267 7.21 35.67054403319277 139.74277865973556 7.21 35.67054403319277 139.74277865973556 38.4 35.67056164969323 139.74274758873267 38.4 35.67056164969323 139.74274758873267 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81b674f9-9f75-425d-a937-c01b4316a1fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81b674f9-9f75-425d-a937-c01b4316a1fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81b674f9-9f75-425d-a937-c01b4316a1fa">
											<gml:posList>35.67054403319277 139.74277865973556 7.21 35.67052490374595 139.74276360316932 7.21 35.67052490374595 139.74276360316932 38.4 35.67054403319277 139.74277865973556 38.4 35.67054403319277 139.74277865973556 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f8dba91-cbe3-4b47-bf64-8b4b182c5631">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f8dba91-cbe3-4b47-bf64-8b4b182c5631">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f8dba91-cbe3-4b47-bf64-8b4b182c5631">
											<gml:posList>35.670525166498194 139.7427654034161 38.4 35.670525166498194 139.7427654034161 37.71 35.67054434103002 139.74278048202444 37.71 35.67054434103002 139.74278048202444 38.4 35.670525166498194 139.7427654034161 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75a1b35e-ded4-4c8f-b16d-0f9e6602d14d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75a1b35e-ded4-4c8f-b16d-0f9e6602d14d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75a1b35e-ded4-4c8f-b16d-0f9e6602d14d">
											<gml:posList>35.67052490374595 139.74276360316932 7.21 35.670504719850065 139.74279669852228 7.21 35.670504719850065 139.74279669852228 38.4 35.67052490374595 139.74276360316932 38.4 35.67052490374595 139.74276360316932 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-750833f8-d4e3-4d53-8b19-dc76b8e453f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-750833f8-d4e3-4d53-8b19-dc76b8e453f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-750833f8-d4e3-4d53-8b19-dc76b8e453f3">
											<gml:posList>35.67050624296163 139.74279642064545 38.4 35.67050624296163 139.74279642064545 37.71 35.670525166498194 139.7427654034161 37.71 35.670525166498194 139.7427654034161 38.4 35.67050624296163 139.74279642064545 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f06f4aa-e2aa-435c-ae5c-d82424c31110">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f06f4aa-e2aa-435c-ae5c-d82424c31110">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f06f4aa-e2aa-435c-ae5c-d82424c31110">
											<gml:posList>35.67056125536634 139.74275061586016 38.4 35.67056125536634 139.74275061586016 37.71 35.670592700424145 139.7428773917312 37.71 35.670592700424145 139.7428773917312 38.4 35.67056125536634 139.74275061586016 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-041157c5-607c-4905-91c8-fe340cfade58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-041157c5-607c-4905-91c8-fe340cfade58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-041157c5-607c-4905-91c8-fe340cfade58">
											<gml:posList>35.67059474023068 139.7428809905202 7.21 35.67056164969323 139.74274758873267 7.21 35.67056164969323 139.74274758873267 38.4 35.67059474023068 139.7428809905202 38.4 35.67059474023068 139.7428809905202 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2d5c854-49e9-4706-8f8c-5a8073e80d74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2d5c854-49e9-4706-8f8c-5a8073e80d74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2d5c854-49e9-4706-8f8c-5a8073e80d74">
											<gml:posList>35.670592700424145 139.7428773917312 38.4 35.670592700424145 139.7428773917312 37.71 35.67050624296163 139.74279642064545 37.71 35.67050624296163 139.74279642064545 38.4 35.670592700424145 139.7428773917312 38.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4468ca40-fecc-431a-b867-bbf905a9779d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4468ca40-fecc-431a-b867-bbf905a9779d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4468ca40-fecc-431a-b867-bbf905a9779d">
											<gml:posList>35.670504719850065 139.74279669852228 7.21 35.67059474023068 139.7428809905202 7.21 35.67059474023068 139.7428809905202 38.4 35.670504719850065 139.74279669852228 38.4 35.670504719850065 139.74279669852228 7.21</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1352</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">49.3696</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.43</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>