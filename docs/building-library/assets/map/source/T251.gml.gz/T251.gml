<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4594d991-a470-4956-9dc1-8879af37ad0f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">3.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6714703036263 139.74057807453227 0 35.67149934283756 139.74060925810116 0 35.67151685568083 139.74058477003538 0 35.67148781645486 139.74055357542218 0 35.6714703036263 139.74057807453227 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714703036263 139.74057807453227 8.809 35.67148781645486 139.74055357542218 8.809 35.67151685568083 139.74058477003538 8.809 35.67149934283756 139.74060925810116 8.809 35.6714703036263 139.74057807453227 8.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714703036263 139.74057807453227 8.809 35.67149934283756 139.74060925810116 8.809 35.67149934283756 139.74060925810116 12.3 35.6714703036263 139.74057807453227 12.3 35.6714703036263 139.74057807453227 8.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149934283756 139.74060925810116 8.809 35.67151685568083 139.74058477003538 8.809 35.67151685568083 139.74058477003538 12.3 35.67149934283756 139.74060925810116 12.3 35.67149934283756 139.74060925810116 8.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67151685568083 139.74058477003538 8.809 35.67148781645486 139.74055357542218 8.809 35.67148781645486 139.74055357542218 12.3 35.67151685568083 139.74058477003538 12.3 35.67151685568083 139.74058477003538 8.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148781645486 139.74055357542218 8.809 35.6714703036263 139.74057807453227 8.809 35.6714703036263 139.74057807453227 12.3 35.67148781645486 139.74055357542218 12.3 35.67148781645486 139.74055357542218 8.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714703036263 139.74057807453227 12.3 35.67149934283756 139.74060925810116 12.3 35.67151685568083 139.74058477003538 12.3 35.67148781645486 139.74055357542218 12.3 35.6714703036263 139.74057807453227 12.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-08e005cd-0ced-4f3a-85df-c046577e7dd3"/>
							<gml:surfaceMember xlink:href="#poly-468c41ff-bc80-4e6f-8b55-26430d0fe411"/>
							<gml:surfaceMember xlink:href="#poly-90db2865-2c60-4d19-a748-525ceefaa60e"/>
							<gml:surfaceMember xlink:href="#poly-7c1e9f40-aab4-478a-b32f-b2ec2097765a"/>
							<gml:surfaceMember xlink:href="#poly-994a2098-421f-48d7-ad34-cd7240846781"/>
							<gml:surfaceMember xlink:href="#poly-5918091f-c665-43be-b276-7fef81a2ed0c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4594d991-a470-4956-9dc1-8879af37ad0f_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b49ab7f-b21b-403f-a4f6-2fd6f8c5f1ef">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67149508119848 139.74056485644937 12.891 35.67151183354917 139.7405828427225 12.891 35.67150083963055 139.7405982210026 12.891 35.67148408728214 139.74058023472872 12.891 35.67149508119848 139.74056485644937 12.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0dea6127-a53f-45e3-83ac-1c59052462dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0dea6127-a53f-45e3-83ac-1c59052462dc_0">
											<gml:posList>35.67148408728214 139.74058023472872 14.719 35.67149508119848 139.74056485644937 14.719 35.67149508119848 139.74056485644937 12.891 35.67148408728214 139.74058023472872 12.891 35.67148408728214 139.74058023472872 14.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d65d9c6-f9cb-4b7a-8e9c-65475f791c23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d65d9c6-f9cb-4b7a-8e9c-65475f791c23_0">
											<gml:posList>35.67150083963055 139.7405982210026 12.891 35.67150083963055 139.7405982210026 14.719 35.67148408728214 139.74058023472872 14.719 35.67148408728214 139.74058023472872 12.891 35.67150083963055 139.7405982210026 12.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55d335a8-176e-4231-a817-16a7f9b6dacd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55d335a8-176e-4231-a817-16a7f9b6dacd_0">
											<gml:posList>35.67150083963055 139.7405982210026 14.719 35.67151183354917 139.7405828427225 14.719 35.67149508119848 139.74056485644937 14.719 35.67148408728214 139.74058023472872 14.719 35.67150083963055 139.7405982210026 14.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-876ef91a-10e6-4345-831f-b42fc6c3adc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-876ef91a-10e6-4345-831f-b42fc6c3adc8_0">
											<gml:posList>35.67149508119848 139.74056485644937 12.891 35.67149508119848 139.74056485644937 14.719 35.67151183354917 139.7405828427225 14.719 35.67151183354917 139.7405828427225 12.891 35.67149508119848 139.74056485644937 12.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce4f4cc0-348c-4872-a712-bb75e05054eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce4f4cc0-348c-4872-a712-bb75e05054eb_0">
											<gml:posList>35.67151183354917 139.7405828427225 12.891 35.67151183354917 139.7405828427225 14.719 35.67150083963055 139.7405982210026 14.719 35.67150083963055 139.7405982210026 12.891 35.67151183354917 139.7405828427225 12.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-08e005cd-0ced-4f3a-85df-c046577e7dd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08e005cd-0ced-4f3a-85df-c046577e7dd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08e005cd-0ced-4f3a-85df-c046577e7dd3">
											<gml:posList>35.67147030362631 139.74057807453224 8.809 35.67148781645483 139.74055357542218 8.809 35.6715168556808 139.74058477003538 8.809 35.67149934283753 139.74060925810116 8.809 35.67147030362631 139.74057807453224 8.809</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-468c41ff-bc80-4e6f-8b55-26430d0fe411">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-468c41ff-bc80-4e6f-8b55-26430d0fe411">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-468c41ff-bc80-4e6f-8b55-26430d0fe411">
											<gml:posList>35.67149934283753 139.74060925810116 12.891 35.6715168556808 139.74058477003538 12.891 35.67148781645483 139.74055357542218 12.891 35.67147030362631 139.74057807453224 12.891 35.67149934283753 139.74060925810116 12.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-90db2865-2c60-4d19-a748-525ceefaa60e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-90db2865-2c60-4d19-a748-525ceefaa60e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-90db2865-2c60-4d19-a748-525ceefaa60e">
											<gml:posList>35.67147030362631 139.74057807453224 12.891 35.67147030362631 139.74057807453224 8.809 35.67149934283753 139.74060925810116 8.809 35.67149934283753 139.74060925810116 12.891 35.67147030362631 139.74057807453224 12.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c1e9f40-aab4-478a-b32f-b2ec2097765a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c1e9f40-aab4-478a-b32f-b2ec2097765a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c1e9f40-aab4-478a-b32f-b2ec2097765a">
											<gml:posList>35.67148781645483 139.74055357542218 12.891 35.67148781645483 139.74055357542218 8.809 35.67147030362631 139.74057807453224 8.809 35.67147030362631 139.74057807453224 12.891 35.67148781645483 139.74055357542218 12.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-994a2098-421f-48d7-ad34-cd7240846781">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-994a2098-421f-48d7-ad34-cd7240846781">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-994a2098-421f-48d7-ad34-cd7240846781">
											<gml:posList>35.6715168556808 139.74058477003538 12.891 35.6715168556808 139.74058477003538 8.809 35.67148781645483 139.74055357542218 8.809 35.67148781645483 139.74055357542218 12.891 35.6715168556808 139.74058477003538 12.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5918091f-c665-43be-b276-7fef81a2ed0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5918091f-c665-43be-b276-7fef81a2ed0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5918091f-c665-43be-b276-7fef81a2ed0c">
											<gml:posList>35.67149934283753 139.74060925810116 12.891 35.67149934283753 139.74060925810116 8.809 35.6715168556808 139.74058477003538 8.809 35.6715168556808 139.74058477003538 12.891 35.67149934283753 139.74060925810116 12.891</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3736</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">93.00955</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>