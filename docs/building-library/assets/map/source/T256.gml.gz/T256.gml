<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_476f3998-300c-41e0-9afe-2fef2ff8f0b6">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668812111447885 139.7393717956805 0 35.66884758431125 139.7393189540012 0 35.66878950396992 139.73926656445616 0 35.66880610589506 139.73924173556802 0 35.668731007617836 139.73916632406412 0 35.66868230001083 139.7392388431934 0 35.668812111447885 139.7393717956805 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668812111447885 139.7393717956805 11.945 35.66868230001083 139.7392388431934 11.945 35.668731007617836 139.73916632406412 11.945 35.66880610589506 139.73924173556802 11.945 35.66878950396992 139.73926656445616 11.945 35.66884758431125 139.7393189540012 11.945 35.668812111447885 139.7393717956805 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668812111447885 139.7393717956805 11.945 35.66884758431125 139.7393189540012 11.945 35.66884758431125 139.7393189540012 25.92 35.668812111447885 139.7393717956805 25.92 35.668812111447885 139.7393717956805 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884758431125 139.7393189540012 11.945 35.66878950396992 139.73926656445616 11.945 35.66878950396992 139.73926656445616 25.92 35.66884758431125 139.7393189540012 25.92 35.66884758431125 139.7393189540012 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66878950396992 139.73926656445616 11.945 35.66880610589506 139.73924173556802 11.945 35.66880610589506 139.73924173556802 25.92 35.66878950396992 139.73926656445616 25.92 35.66878950396992 139.73926656445616 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880610589506 139.73924173556802 11.945 35.668731007617836 139.73916632406412 11.945 35.668731007617836 139.73916632406412 25.92 35.66880610589506 139.73924173556802 25.92 35.66880610589506 139.73924173556802 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668731007617836 139.73916632406412 11.945 35.66868230001083 139.7392388431934 11.945 35.66868230001083 139.7392388431934 25.92 35.668731007617836 139.73916632406412 25.92 35.668731007617836 139.73916632406412 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868230001083 139.7392388431934 11.945 35.668812111447885 139.7393717956805 11.945 35.668812111447885 139.7393717956805 25.92 35.66868230001083 139.7392388431934 25.92 35.66868230001083 139.7392388431934 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668812111447885 139.7393717956805 25.92 35.66884758431125 139.7393189540012 25.92 35.66878950396992 139.73926656445616 25.92 35.66880610589506 139.73924173556802 25.92 35.668731007617836 139.73916632406412 25.92 35.66868230001083 139.7392388431934 25.92 35.668812111447885 139.7393717956805 25.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-a8fee04c-c470-473e-ae48-01e16c550840"/>
							<gml:surfaceMember xlink:href="#poly-359425f7-c140-4ae0-bcfb-0d504bccf393"/>
							<gml:surfaceMember xlink:href="#poly-7cf3efd1-f26e-4368-826c-22b53f573244"/>
							<gml:surfaceMember xlink:href="#poly-ebd7b01f-9cb3-4382-856c-e42c6f3eb90e"/>
							<gml:surfaceMember xlink:href="#poly-bc564a74-1ca4-4099-b5d1-933444a64f0b"/>
							<gml:surfaceMember xlink:href="#poly-9f4e2869-e429-416d-9623-67d1f9343304"/>
							<gml:surfaceMember xlink:href="#poly-3ce05815-88fd-4a60-b7d5-01e7195112ed"/>
							<gml:surfaceMember xlink:href="#poly-116093a0-4f53-4648-b2a7-c6e3d448ed7f"/>
							<gml:surfaceMember xlink:href="#poly-4edbe7b1-dfd6-43f5-9c14-b57beb7ca3c3"/>
							<gml:surfaceMember xlink:href="#poly-cbea986e-a1ea-4b19-aecc-138f8806413b"/>
							<gml:surfaceMember xlink:href="#poly-8c8a5e96-fa74-4248-8101-3b10eae84bf9"/>
							<gml:surfaceMember xlink:href="#poly-fb1b44bf-bbc4-4be0-b9f6-41988550faab"/>
							<gml:surfaceMember xlink:href="#poly-9fd6402e-9d6c-4a21-8b9c-3f3e996276db"/>
							<gml:surfaceMember xlink:href="#poly-ac7bd3f9-50b5-4542-88c4-ea9570c1f86d"/>
							<gml:surfaceMember xlink:href="#poly-bafc0d7f-c4d9-4be5-95be-91ca05060cf1"/>
							<gml:surfaceMember xlink:href="#poly-1a64b31e-6ba4-437f-83d2-73f485234dae"/>
							<gml:surfaceMember xlink:href="#poly-cc1b997e-5296-4930-8ef6-4aa30e5b9975"/>
							<gml:surfaceMember xlink:href="#poly-0fe9d08f-3f9e-478f-b907-db9c1b80128c"/>
							<gml:surfaceMember xlink:href="#poly-47395855-5537-4a95-92d4-7da47b92b8c1"/>
							<gml:surfaceMember xlink:href="#poly-e7fd7746-d8e2-4f31-9739-701e4618c7bb"/>
							<gml:surfaceMember xlink:href="#poly-acbc6033-2fcf-49c9-8d6d-87a9149acbdf"/>
							<gml:surfaceMember xlink:href="#poly-5c4f36cd-83e6-4d00-9f67-e62379578b2c"/>
							<gml:surfaceMember xlink:href="#poly-6ea7efad-e9a4-4a0a-ad61-0babe98aeccc"/>
							<gml:surfaceMember xlink:href="#poly-7ca11107-e7d1-4968-b7c7-55af9ee12d26"/>
							<gml:surfaceMember xlink:href="#poly-7f65cc73-3fc5-4d8d-8dd4-d3cc0acc7222"/>
							<gml:surfaceMember xlink:href="#poly-de0256dd-f652-49ff-89af-23d9de75aa36"/>
							<gml:surfaceMember xlink:href="#poly-33c57f7b-506c-46b8-9425-b1437f387821"/>
							<gml:surfaceMember xlink:href="#poly-85a4cedb-d46f-49d9-9464-3f1109389ed8"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_476f3998-300c-41e0-9afe-2fef2ff8f0b6_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ade2d665-0ab2-4783-87a9-ea34e64ff102">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6687685209697 139.7392331969019 34.316 35.66877502128239 139.73922346875966 34.316 35.668790149185455 139.7392386614015 34.316 35.66878364886292 139.73924837849827 34.316 35.6687685209697 139.7392331969019 34.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b11319d2-4722-4ce6-8ad9-19c54c80c4f2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876711552172 139.73925715740572 30.184 35.66875532531435 139.73924530779684 30.184 35.66876055618612 139.7392374921112 30.184 35.668772346385644 139.7392493306737 30.184 35.66876711552172 139.73925715740572 30.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef8184cb-1f39-461d-9786-93035468da46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668767920801685 139.73927260986696 30.184 35.66876241982647 139.73928082352515 30.184 35.668750304885705 139.73926866500545 30.184 35.668755805851475 139.73926044030162 30.184 35.668767920801685 139.73927260986696 30.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c10646c8-f356-4aae-9dbe-375b4f4d412e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c10646c8-f356-4aae-9dbe-375b4f4d412e_0">
											<gml:posList>35.668755805851475 139.73926044030162 30.184 35.668750304885705 139.73926866500545 30.184 35.668750304885705 139.73926866500545 32.675 35.668755805851475 139.73926044030162 32.675 35.668755805851475 139.73926044030162 30.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66792753-6827-4df0-8b9a-192f7c8f0d61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66792753-6827-4df0-8b9a-192f7c8f0d61_0">
											<gml:posList>35.66876241982647 139.73928082352515 30.184 35.66876241982647 139.73928082352515 32.675 35.668750304885705 139.73926866500545 32.675 35.668750304885705 139.73926866500545 30.184 35.66876241982647 139.73928082352515 30.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40c117ad-0e90-495f-9f14-276b5c070e73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40c117ad-0e90-495f-9f14-276b5c070e73_0">
											<gml:posList>35.66876055618612 139.7392374921112 30.184 35.66875532531435 139.73924530779684 30.184 35.66875532531435 139.73924530779684 32.347 35.66876055618612 139.7392374921112 32.347 35.66876055618612 139.7392374921112 30.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3b3fe4e-7bdc-45be-8eba-399030e75336">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3b3fe4e-7bdc-45be-8eba-399030e75336_0">
											<gml:posList>35.668750304885705 139.73926866500545 32.675 35.66876241982647 139.73928082352515 32.675 35.668767920801685 139.73927260986696 32.675 35.668755805851475 139.73926044030162 32.675 35.668750304885705 139.73926866500545 32.675</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf4a0f9f-a60a-485d-adbd-8d2bace5ca67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf4a0f9f-a60a-485d-adbd-8d2bace5ca67_0">
											<gml:posList>35.66875532531435 139.73924530779684 30.184 35.66876711552172 139.73925715740572 30.184 35.66876711552172 139.73925715740572 32.347 35.66875532531435 139.73924530779684 32.347 35.66875532531435 139.73924530779684 30.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a6f01d2-8c7d-48b4-9fbf-cf92c9ccf89e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a6f01d2-8c7d-48b4-9fbf-cf92c9ccf89e_0">
											<gml:posList>35.668755805851475 139.73926044030162 30.184 35.668755805851475 139.73926044030162 32.675 35.668767920801685 139.73927260986696 32.675 35.668767920801685 139.73927260986696 30.184 35.668755805851475 139.73926044030162 30.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9e5004a-fe8b-48cd-95a9-e17ca7a5f101">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9e5004a-fe8b-48cd-95a9-e17ca7a5f101_0">
											<gml:posList>35.66876711552172 139.73925715740572 32.347 35.668772346385644 139.7392493306737 32.347 35.66876055618612 139.7392374921112 32.347 35.66875532531435 139.73924530779684 32.347 35.66876711552172 139.73925715740572 32.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa0b86e9-96e2-4c7d-9d7c-b884b11d055d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa0b86e9-96e2-4c7d-9d7c-b884b11d055d_0">
											<gml:posList>35.66876241982647 139.73928082352515 30.184 35.668767920801685 139.73927260986696 30.184 35.668767920801685 139.73927260986696 32.675 35.66876241982647 139.73928082352515 32.675 35.66876241982647 139.73928082352515 30.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-040fdf55-6194-49c7-9295-1d649635a719">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-040fdf55-6194-49c7-9295-1d649635a719_0">
											<gml:posList>35.668772346385644 139.7392493306737 30.184 35.66876055618612 139.7392374921112 30.184 35.66876055618612 139.7392374921112 32.347 35.668772346385644 139.7392493306737 32.347 35.668772346385644 139.7392493306737 30.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-126dbdce-053b-4bd2-b8f0-03f83e6334eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-126dbdce-053b-4bd2-b8f0-03f83e6334eb_0">
											<gml:posList>35.66876711552172 139.73925715740572 30.184 35.668772346385644 139.7392493306737 30.184 35.668772346385644 139.7392493306737 32.347 35.66876711552172 139.73925715740572 32.347 35.66876711552172 139.73925715740572 30.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d83f7ea4-93a7-40d1-b542-aa0d92219001">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d83f7ea4-93a7-40d1-b542-aa0d92219001_0">
											<gml:posList>35.66877502128239 139.73922346875966 34.316 35.6687685209697 139.7392331969019 34.316 35.6687685209697 139.7392331969019 35.49 35.66877502128239 139.73922346875966 35.49 35.66877502128239 139.73922346875966 34.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b57c3c1-5595-4a20-8849-324e7277ca5a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b57c3c1-5595-4a20-8849-324e7277ca5a_0">
											<gml:posList>35.6687685209697 139.7392331969019 34.316 35.66878364886292 139.73924837849827 34.316 35.66878364886292 139.73924837849827 35.49 35.6687685209697 139.7392331969019 35.49 35.6687685209697 139.7392331969019 34.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-447e772f-1b6b-45ee-90a4-16c7f8d1feb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-447e772f-1b6b-45ee-90a4-16c7f8d1feb3_0">
											<gml:posList>35.668790149185455 139.7392386614015 35.49 35.66877502128239 139.73922346875966 35.49 35.6687685209697 139.7392331969019 35.49 35.66878364886292 139.73924837849827 35.49 35.668790149185455 139.7392386614015 35.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b08c8a2-72db-4c7e-951e-6ec36dc0468d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b08c8a2-72db-4c7e-951e-6ec36dc0468d_0">
											<gml:posList>35.66877502128239 139.73922346875966 35.49 35.668790149185455 139.7392386614015 35.49 35.668790149185455 139.7392386614015 34.316 35.66877502128239 139.73922346875966 34.316 35.66877502128239 139.73922346875966 35.49</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8453bb96-f479-44cf-bcf5-af5404a796ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8453bb96-f479-44cf-bcf5-af5404a796ee_0">
											<gml:posList>35.66878364886292 139.73924837849827 34.316 35.668790149185455 139.7392386614015 34.316 35.668790149185455 139.7392386614015 35.49 35.66878364886292 139.73924837849827 35.49 35.66878364886292 139.73924837849827 34.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_476f3998-300c-41e0-9afe-2fef2ff8f0b6_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f065110-4c07-412b-ac14-381ae91fbf4a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66880610589507 139.73924173556802 11.945 35.668839888830576 139.7392756625195 11.945 35.66882476338104 139.73929822524036 11.945 35.668789503969904 139.73926656445616 11.945 35.66880610589507 139.73924173556802 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3632f2f9-c8ff-45ed-b01b-e16e77cf4f23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3632f2f9-c8ff-45ed-b01b-e16e77cf4f23_0">
											<gml:posList>35.66880610589507 139.73924173556802 23.316 35.66880610589507 139.73924173556802 11.945 35.668789503969904 139.73926656445616 11.945 35.668789503969904 139.73926656445616 23.316 35.66880610589507 139.73924173556802 23.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7383c9a2-b758-4890-aa11-7f5383b29dad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7383c9a2-b758-4890-aa11-7f5383b29dad_0">
											<gml:posList>35.66880610589507 139.73924173556802 11.945 35.66880610589507 139.73924173556802 23.316 35.668839888830576 139.7392756625195 23.316 35.668839888830576 139.7392756625195 11.945 35.66880610589507 139.73924173556802 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b16e3114-9986-433e-8f75-69964acce875">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b16e3114-9986-433e-8f75-69964acce875_0">
											<gml:posList>35.66882476338104 139.73929822524036 23.316 35.668839888830576 139.7392756625195 23.316 35.66880610589507 139.73924173556802 23.316 35.668789503969904 139.73926656445616 23.316 35.66882476338104 139.73929822524036 23.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-763d3194-4fab-4fa0-919c-e9a1662412c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-763d3194-4fab-4fa0-919c-e9a1662412c1_0">
											<gml:posList>35.66882476338104 139.73929822524036 23.316 35.668789503969904 139.73926656445616 23.316 35.668789503969904 139.73926656445616 11.945 35.66882476338104 139.73929822524036 11.945 35.66882476338104 139.73929822524036 23.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-035fc2dc-b182-4157-8f14-c92cf80b0f0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-035fc2dc-b182-4157-8f14-c92cf80b0f0d_0">
											<gml:posList>35.66882476338104 139.73929822524036 11.945 35.668839888830576 139.7392756625195 11.945 35.668839888830576 139.7392756625195 23.316 35.66882476338104 139.73929822524036 23.316 35.66882476338104 139.73929822524036 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-a8fee04c-c470-473e-ae48-01e16c550840">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a8fee04c-c470-473e-ae48-01e16c550840">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a8fee04c-c470-473e-ae48-01e16c550840">
											<gml:posList>35.66868230001082 139.7392388431934 11.945 35.66873100761781 139.73916632406412 11.945 35.66880610589507 139.73924173556802 11.945 35.668789503969904 139.73926656445616 11.945 35.66884758431123 139.7393189540012 11.945 35.66881211144787 139.73937179568048 11.945 35.66868230001082 139.7392388431934 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-359425f7-c140-4ae0-bcfb-0d504bccf393">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-359425f7-c140-4ae0-bcfb-0d504bccf393">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-359425f7-c140-4ae0-bcfb-0d504bccf393">
											<gml:posList>35.6687582829407 139.73923520824948 30.596 35.668774884859495 139.73921037936458 30.596 35.66873100761781 139.73916632406412 19.33 35.66868230001082 139.7392388431934 19.33 35.66872589837028 139.73928362787203 30.596 35.6687582829407 139.73923520824948 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7cf3efd1-f26e-4368-826c-22b53f573244">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cf3efd1-f26e-4368-826c-22b53f573244">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cf3efd1-f26e-4368-826c-22b53f573244">
											<gml:posList>35.668757056377224 139.73931509461917 30.596 35.66875686520883 139.73931268680755 30.596 35.66872785415878 139.73928338256528 30.596 35.66872589837028 139.73928362787203 30.596 35.668757056377224 139.73931509461917 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ebd7b01f-9cb3-4382-856c-e42c6f3eb90e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebd7b01f-9cb3-4382-856c-e42c6f3eb90e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebd7b01f-9cb3-4382-856c-e42c6f3eb90e">
											<gml:posList>35.66872785415878 139.73928338256528 30.596 35.668759356419876 139.73923628950124 30.596 35.6687582829407 139.73923520824948 30.596 35.66872589837028 139.73928362787203 30.596 35.66872785415878 139.73928338256528 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc564a74-1ca4-4099-b5d1-933444a64f0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc564a74-1ca4-4099-b5d1-933444a64f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc564a74-1ca4-4099-b5d1-933444a64f0b">
											<gml:posList>35.66872785415878 139.73928338256528 30.184 35.66875686520883 139.73931268680755 30.184 35.66878753915911 139.739266798728 30.184 35.66878266793363 139.7392619220934 30.184 35.668783559256845 139.73926059552295 30.184 35.668759356419876 139.73923628950124 30.184 35.66872785415878 139.73928338256528 30.184</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f4e2869-e429-416d-9623-67d1f9343304">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f4e2869-e429-416d-9623-67d1f9343304">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f4e2869-e429-416d-9623-67d1f9343304">
											<gml:posList>35.668789503969904 139.73926656445616 30.596 35.66878753915911 139.739266798728 30.596 35.66875686520883 139.73931268680755 30.596 35.668757056377224 139.73931509461917 30.596 35.668789503969904 139.73926656445616 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3ce05815-88fd-4a60-b7d5-01e7195112ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ce05815-88fd-4a60-b7d5-01e7195112ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ce05815-88fd-4a60-b7d5-01e7195112ed">
											<gml:posList>35.6687582829407 139.73923520824948 34.316 35.66878418169574 139.73926122441696 34.316 35.668800783619815 139.73923639552933 34.316 35.668774884859495 139.73921037936458 34.316 35.6687582829407 139.73923520824948 34.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-116093a0-4f53-4648-b2a7-c6e3d448ed7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-116093a0-4f53-4648-b2a7-c6e3d448ed7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-116093a0-4f53-4648-b2a7-c6e3d448ed7f">
											<gml:posList>35.66878266793363 139.7392619220934 30.596 35.66878753915911 139.739266798728 30.596 35.668789503969904 139.73926656445616 30.596 35.66878418169574 139.73926122441696 30.596 35.668783559256845 139.73926059552295 30.596 35.66878266793363 139.7392619220934 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4edbe7b1-dfd6-43f5-9c14-b57beb7ca3c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4edbe7b1-dfd6-43f5-9c14-b57beb7ca3c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4edbe7b1-dfd6-43f5-9c14-b57beb7ca3c3">
											<gml:posList>35.668789503969904 139.73926656445616 19.33 35.66880610589507 139.73924173556802 19.33 35.668800783619815 139.73923639552933 19.33 35.66878418169574 139.73926122441696 19.33 35.668789503969904 139.73926656445616 19.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbea986e-a1ea-4b19-aecc-138f8806413b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbea986e-a1ea-4b19-aecc-138f8806413b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbea986e-a1ea-4b19-aecc-138f8806413b">
											<gml:posList>35.66881211144787 139.73937179568048 19.33 35.66884758431123 139.7393189540012 19.33 35.668789503969904 139.73926656445616 30.596 35.668757056377224 139.73931509461917 30.596 35.66881211144787 139.73937179568048 19.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c8a5e96-fa74-4248-8101-3b10eae84bf9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c8a5e96-fa74-4248-8101-3b10eae84bf9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c8a5e96-fa74-4248-8101-3b10eae84bf9">
											<gml:posList>35.66878266793363 139.7392619220934 30.596 35.66878266793363 139.7392619220934 30.184 35.66878753915911 139.739266798728 30.184 35.66878753915911 139.739266798728 30.596 35.66878266793363 139.7392619220934 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb1b44bf-bbc4-4be0-b9f6-41988550faab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb1b44bf-bbc4-4be0-b9f6-41988550faab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb1b44bf-bbc4-4be0-b9f6-41988550faab">
											<gml:posList>35.66873100761781 139.73916632406412 11.945 35.66868230001082 139.7392388431934 11.945 35.66868230001082 139.7392388431934 19.33 35.66873100761781 139.73916632406412 19.33 35.66873100761781 139.73916632406412 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9fd6402e-9d6c-4a21-8b9c-3f3e996276db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fd6402e-9d6c-4a21-8b9c-3f3e996276db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fd6402e-9d6c-4a21-8b9c-3f3e996276db">
											<gml:posList>35.668774884859495 139.73921037936458 30.596 35.668774884859495 139.73921037936458 34.316 35.668800783619815 139.73923639552933 34.316 35.668800783619815 139.73923639552933 19.33 35.66880610589507 139.73924173556802 19.33 35.66880610589507 139.73924173556802 11.945 35.66873100761781 139.73916632406412 11.945 35.66873100761781 139.73916632406412 19.33 35.668774884859495 139.73921037936458 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac7bd3f9-50b5-4542-88c4-ea9570c1f86d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac7bd3f9-50b5-4542-88c4-ea9570c1f86d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac7bd3f9-50b5-4542-88c4-ea9570c1f86d">
											<gml:posList>35.6687582829407 139.73923520824948 34.316 35.668774884859495 139.73921037936458 34.316 35.668774884859495 139.73921037936458 30.596 35.6687582829407 139.73923520824948 30.596 35.6687582829407 139.73923520824948 34.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bafc0d7f-c4d9-4be5-95be-91ca05060cf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bafc0d7f-c4d9-4be5-95be-91ca05060cf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bafc0d7f-c4d9-4be5-95be-91ca05060cf1">
											<gml:posList>35.668759356419876 139.73923628950124 30.596 35.668759356419876 139.73923628950124 30.184 35.668783559256845 139.73926059552295 30.184 35.668783559256845 139.73926059552295 30.596 35.66878418169574 139.73926122441696 30.596 35.66878418169574 139.73926122441696 34.316 35.6687582829407 139.73923520824948 34.316 35.6687582829407 139.73923520824948 30.596 35.668759356419876 139.73923628950124 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a64b31e-6ba4-437f-83d2-73f485234dae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a64b31e-6ba4-437f-83d2-73f485234dae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a64b31e-6ba4-437f-83d2-73f485234dae">
											<gml:posList>35.668800783619815 139.73923639552933 34.316 35.66878418169574 139.73926122441696 34.316 35.66878418169574 139.73926122441696 30.596 35.66878418169574 139.73926122441696 19.33 35.668800783619815 139.73923639552933 19.33 35.668800783619815 139.73923639552933 34.316</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc1b997e-5296-4930-8ef6-4aa30e5b9975">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc1b997e-5296-4930-8ef6-4aa30e5b9975">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc1b997e-5296-4930-8ef6-4aa30e5b9975">
											<gml:posList>35.668789503969904 139.73926656445616 11.945 35.66880610589507 139.73924173556802 11.945 35.66880610589507 139.73924173556802 19.33 35.668789503969904 139.73926656445616 19.33 35.668789503969904 139.73926656445616 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0fe9d08f-3f9e-478f-b907-db9c1b80128c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fe9d08f-3f9e-478f-b907-db9c1b80128c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fe9d08f-3f9e-478f-b907-db9c1b80128c">
											<gml:posList>35.66872785415878 139.73928338256528 30.596 35.66872785415878 139.73928338256528 30.184 35.668759356419876 139.73923628950124 30.184 35.668759356419876 139.73923628950124 30.596 35.66872785415878 139.73928338256528 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47395855-5537-4a95-92d4-7da47b92b8c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47395855-5537-4a95-92d4-7da47b92b8c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47395855-5537-4a95-92d4-7da47b92b8c1">
											<gml:posList>35.668783559256845 139.73926059552295 30.596 35.668783559256845 139.73926059552295 30.184 35.66878266793363 139.7392619220934 30.184 35.66878266793363 139.7392619220934 30.596 35.668783559256845 139.73926059552295 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e7fd7746-d8e2-4f31-9739-701e4618c7bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7fd7746-d8e2-4f31-9739-701e4618c7bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7fd7746-d8e2-4f31-9739-701e4618c7bb">
											<gml:posList>35.668789503969904 139.73926656445616 19.33 35.66878418169574 139.73926122441696 19.33 35.66878418169574 139.73926122441696 30.596 35.668789503969904 139.73926656445616 19.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-acbc6033-2fcf-49c9-8d6d-87a9149acbdf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acbc6033-2fcf-49c9-8d6d-87a9149acbdf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acbc6033-2fcf-49c9-8d6d-87a9149acbdf">
											<gml:posList>35.66878753915911 139.739266798728 30.596 35.66878753915911 139.739266798728 30.184 35.66875686520883 139.73931268680755 30.184 35.66875686520883 139.73931268680755 30.596 35.66878753915911 139.739266798728 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c4f36cd-83e6-4d00-9f67-e62379578b2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c4f36cd-83e6-4d00-9f67-e62379578b2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c4f36cd-83e6-4d00-9f67-e62379578b2c">
											<gml:posList>35.66878418169574 139.73926122441696 30.596 35.668789503969904 139.73926656445616 30.596 35.66884758431123 139.7393189540012 11.945 35.66878418169574 139.73926122441696 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ea7efad-e9a4-4a0a-ad61-0babe98aeccc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ea7efad-e9a4-4a0a-ad61-0babe98aeccc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ea7efad-e9a4-4a0a-ad61-0babe98aeccc">
											<gml:posList>35.668789503969904 139.73926656445616 19.33 35.66878418169574 139.73926122441696 30.596 35.66884758431123 139.7393189540012 11.945 35.668789503969904 139.73926656445616 19.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ca11107-e7d1-4968-b7c7-55af9ee12d26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ca11107-e7d1-4968-b7c7-55af9ee12d26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ca11107-e7d1-4968-b7c7-55af9ee12d26">
											<gml:posList>35.668789503969904 139.73926656445616 30.596 35.66884758431123 139.7393189540012 19.33 35.66884758431123 139.7393189540012 11.945 35.668789503969904 139.73926656445616 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f65cc73-3fc5-4d8d-8dd4-d3cc0acc7222">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f65cc73-3fc5-4d8d-8dd4-d3cc0acc7222">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f65cc73-3fc5-4d8d-8dd4-d3cc0acc7222">
											<gml:posList>35.668789503969904 139.73926656445616 19.33 35.66884758431123 139.7393189540012 11.945 35.668789503969904 139.73926656445616 11.945 35.668789503969904 139.73926656445616 19.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de0256dd-f652-49ff-89af-23d9de75aa36">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de0256dd-f652-49ff-89af-23d9de75aa36">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de0256dd-f652-49ff-89af-23d9de75aa36">
											<gml:posList>35.66875686520883 139.73931268680755 30.596 35.66875686520883 139.73931268680755 30.184 35.66872785415878 139.73928338256528 30.184 35.66872785415878 139.73928338256528 30.596 35.66875686520883 139.73931268680755 30.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-33c57f7b-506c-46b8-9425-b1437f387821">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33c57f7b-506c-46b8-9425-b1437f387821">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33c57f7b-506c-46b8-9425-b1437f387821">
											<gml:posList>35.66868230001082 139.7392388431934 19.33 35.66868230001082 139.7392388431934 11.945 35.66881211144787 139.73937179568048 11.945 35.66881211144787 139.73937179568048 19.33 35.668757056377224 139.73931509461917 30.596 35.66872589837028 139.73928362787203 30.596 35.66868230001082 139.7392388431934 19.33</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-85a4cedb-d46f-49d9-9464-3f1109389ed8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-85a4cedb-d46f-49d9-9464-3f1109389ed8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-85a4cedb-d46f-49d9-9464-3f1109389ed8">
											<gml:posList>35.66881211144787 139.73937179568048 11.945 35.66884758431123 139.7393189540012 11.945 35.66884758431123 139.7393189540012 19.33 35.66881211144787 139.73937179568048 19.33 35.66881211144787 139.73937179568048 11.945</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9891</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">153.451</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>