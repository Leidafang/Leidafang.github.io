<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_47d36ea5-99ab-43b6-ac60-2c281f2a0f7b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">25.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66913199097034 139.7497396102938 0 35.66920358020674 139.74950933497067 0 35.669108364255706 139.74946491878953 0 35.66903695545408 139.74969530415112 0 35.66913199097034 139.7497396102938 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913199097034 139.7497396102938 6.217 35.66903695545408 139.74969530415112 6.217 35.669108364255706 139.74946491878953 6.217 35.66920358020674 139.74950933497067 6.217 35.66913199097034 139.7497396102938 6.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913199097034 139.7497396102938 6.217 35.66920358020674 139.74950933497067 6.217 35.66920358020674 139.74950933497067 30.39 35.66913199097034 139.7497396102938 30.39 35.66913199097034 139.7497396102938 6.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66920358020674 139.74950933497067 6.217 35.669108364255706 139.74946491878953 6.217 35.669108364255706 139.74946491878953 30.39 35.66920358020674 139.74950933497067 30.39 35.66920358020674 139.74950933497067 6.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669108364255706 139.74946491878953 6.217 35.66903695545408 139.74969530415112 6.217 35.66903695545408 139.74969530415112 30.39 35.669108364255706 139.74946491878953 30.39 35.669108364255706 139.74946491878953 6.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66903695545408 139.74969530415112 6.217 35.66913199097034 139.7497396102938 6.217 35.66913199097034 139.7497396102938 30.39 35.66903695545408 139.74969530415112 30.39 35.66903695545408 139.74969530415112 6.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913199097034 139.7497396102938 30.39 35.66920358020674 139.74950933497067 30.39 35.669108364255706 139.74946491878953 30.39 35.66903695545408 139.74969530415112 30.39 35.66913199097034 139.7497396102938 30.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e8b32a10-6643-471c-8488-527c3e654396"/>
							<gml:surfaceMember xlink:href="#poly-87bba432-c97f-41db-8dbd-86b31c530048"/>
							<gml:surfaceMember xlink:href="#poly-53759404-b7d2-42b7-9442-ef71f3aac241"/>
							<gml:surfaceMember xlink:href="#poly-5c6fa87b-dbb5-469c-92a4-63620eb8b232"/>
							<gml:surfaceMember xlink:href="#poly-fabff443-81be-4aed-8240-e869491d3ace"/>
							<gml:surfaceMember xlink:href="#poly-56a8947a-c494-4e2e-9a1c-beb24d1e5cb1"/>
							<gml:surfaceMember xlink:href="#poly-ad9e4dfd-8a34-454d-b95e-c7c8ca8c3b56"/>
							<gml:surfaceMember xlink:href="#poly-7f061aff-8c77-425b-9d91-0f6feeed8678"/>
							<gml:surfaceMember xlink:href="#poly-3f609e91-93e8-4c62-a916-7c0b08e8830f"/>
							<gml:surfaceMember xlink:href="#poly-f7d4a185-4364-417c-8831-878726480807"/>
							<gml:surfaceMember xlink:href="#poly-6101f2c8-b317-47f9-82c3-cc141c1d3d82"/>
							<gml:surfaceMember xlink:href="#poly-f3795ee6-1bb7-4213-9068-d0d83b3b9fac"/>
							<gml:surfaceMember xlink:href="#poly-6c91e02e-57ff-43c8-9e9a-e24e38aa47b4"/>
							<gml:surfaceMember xlink:href="#poly-d7a85258-e82f-4c36-b824-6b8a83ea408e"/>
							<gml:surfaceMember xlink:href="#poly-ae11c540-7f80-46cf-b852-6b79143397da"/>
							<gml:surfaceMember xlink:href="#poly-027c4db7-be94-4a46-ac64-056b12a37018"/>
							<gml:surfaceMember xlink:href="#poly-3805e93c-977b-4182-bc6d-1bf60ee0f49a"/>
							<gml:surfaceMember xlink:href="#poly-32ecf8da-2682-4efb-b162-a68b81601ebb"/>
							<gml:surfaceMember xlink:href="#poly-d726a96f-b8f9-47da-9f42-65d4f48bc209"/>
							<gml:surfaceMember xlink:href="#poly-af3374ea-c1ee-410e-aa3c-d5757088d97d"/>
							<gml:surfaceMember xlink:href="#poly-8dd39b1c-edf1-4506-8e93-5824ba6ece89"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_47d36ea5-99ab-43b6-ac60-2c281f2a0f7b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1dfcde35-3755-4aeb-9fc2-5efe86e0cf98">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908171449054 139.749599962918 30.241 35.66908761409021 139.74958068134353 30.241 35.66909537739824 139.74958425216545 30.241 35.669089477790315 139.74960352269545 30.241 35.66908171449054 139.749599962918 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3266446a-d5fe-4aa2-a999-c2292864923a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911929539656 139.74969456654236 22.803 35.669116426270435 139.74970357209548 22.803 35.66907980027436 139.74968599179718 22.803 35.66908267842061 139.74967699728424 22.803 35.66911929539656 139.74969456654236 22.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a543d1f-335b-4bd7-8a4e-fff848397edf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911113520332 139.74949616526698 35.99 35.66911669311088 139.74947809910464 35.99 35.66914026259219 139.74948898799158 35.99 35.6691346956693 139.7495070541679 35.99 35.66911113520332 139.74949616526698 35.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1aad2c28-ec92-4ca2-93b2-76ce654a15ac">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913221929704 139.74965306395316 30.241 35.66912360807129 139.74964858822875 30.241 35.66913416898735 139.7496180789556 30.241 35.66914278021422 139.7496225546773 30.241 35.66913221929704 139.74965306395316 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1ba69b8-6f94-4c76-90c6-f2cae047d7cc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914758878782 139.74960274401676 30.241 35.66914431558687 139.74961395921628 30.241 35.66913501057152 139.74960987083296 30.241 35.66913829278583 139.74959865562516 30.241 35.66914758878782 139.74960274401676 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e800a1d8-f125-4d80-bd0f-68d7b1bd3dcb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691371036996 139.74954786694946 30.241 35.66914710456264 139.74951566819152 30.241 35.669153362126515 139.74951858886433 30.241 35.66914336126271 139.74955078762443 30.241 35.6691371036996 139.74954786694946 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1e137a7-8009-4d19-b1b7-f61380d14518">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1e137a7-8009-4d19-b1b7-f61380d14518_0">
											<gml:posList>35.66914026259219 139.74948898799158 35.99 35.66911669311088 139.74947809910464 35.99 35.66911669311088 139.74947809910464 38.057 35.66914026259219 139.74948898799158 38.057 35.66914026259219 139.74948898799158 35.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b310a96f-19dc-4460-a8c8-306587a7cde0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b310a96f-19dc-4460-a8c8-306587a7cde0_0">
											<gml:posList>35.66911113520332 139.74949616526698 35.99 35.66911113520332 139.74949616526698 38.057 35.66911669311088 139.74947809910464 38.057 35.66911669311088 139.74947809910464 35.99 35.66911113520332 139.74949616526698 35.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15f352c3-be99-4b8c-bd29-3907c34df01c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15f352c3-be99-4b8c-bd29-3907c34df01c_0">
											<gml:posList>35.66911113520332 139.74949616526698 38.057 35.6691346956693 139.7495070541679 38.057 35.66914026259219 139.74948898799158 38.057 35.66911669311088 139.74947809910464 38.057 35.66911113520332 139.74949616526698 38.057</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f120888-58be-45fc-963e-1a03979c6a2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f120888-58be-45fc-963e-1a03979c6a2e_0">
											<gml:posList>35.6691346956693 139.7495070541679 35.99 35.66914026259219 139.74948898799158 35.99 35.66914026259219 139.74948898799158 38.057 35.6691346956693 139.7495070541679 38.057 35.6691346956693 139.7495070541679 35.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92074456-ad1d-4fd7-9938-0cf168ac8271">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92074456-ad1d-4fd7-9938-0cf168ac8271_0">
											<gml:posList>35.66911113520332 139.74949616526698 35.99 35.6691346956693 139.7495070541679 35.99 35.6691346956693 139.7495070541679 38.057 35.66911113520332 139.74949616526698 38.057 35.66911113520332 139.74949616526698 35.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dd60c3e-236b-46d4-878d-b37f109aa029">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dd60c3e-236b-46d4-878d-b37f109aa029_0">
											<gml:posList>35.669153362126515 139.74951858886433 30.241 35.66914710456264 139.74951566819152 30.241 35.66914710456264 139.74951566819152 31.763 35.669153362126515 139.74951858886433 31.763 35.669153362126515 139.74951858886433 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ce57e22-f845-48bd-b773-b9f7a2e147e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ce57e22-f845-48bd-b773-b9f7a2e147e6_0">
											<gml:posList>35.6691371036996 139.74954786694946 30.241 35.6691371036996 139.74954786694946 31.763 35.66914710456264 139.74951566819152 31.763 35.66914710456264 139.74951566819152 30.241 35.6691371036996 139.74954786694946 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a349e29-97a5-40e1-bd87-d0f0c6f8aa43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a349e29-97a5-40e1-bd87-d0f0c6f8aa43_0">
											<gml:posList>35.6691371036996 139.74954786694946 31.763 35.66914336126271 139.74955078762443 31.763 35.669153362126515 139.74951858886433 31.763 35.66914710456264 139.74951566819152 31.763 35.6691371036996 139.74954786694946 31.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-340fa302-aef7-43b0-ae97-63bac393766c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-340fa302-aef7-43b0-ae97-63bac393766c_0">
											<gml:posList>35.66914336126271 139.74955078762443 30.241 35.669153362126515 139.74951858886433 30.241 35.669153362126515 139.74951858886433 31.763 35.66914336126271 139.74955078762443 31.763 35.66914336126271 139.74955078762443 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b42c41a-33ac-4273-bbb4-b2a965ccf81e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b42c41a-33ac-4273-bbb4-b2a965ccf81e_0">
											<gml:posList>35.6691371036996 139.74954786694946 30.241 35.66914336126271 139.74955078762443 30.241 35.66914336126271 139.74955078762443 31.763 35.6691371036996 139.74954786694946 31.763 35.6691371036996 139.74954786694946 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-594a4e28-15f9-4159-9452-391f8673b1e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-594a4e28-15f9-4159-9452-391f8673b1e0_0">
											<gml:posList>35.66909537739824 139.74958425216545 30.241 35.66908761409021 139.74958068134353 30.241 35.66908761409021 139.74958068134353 31.763 35.66909537739824 139.74958425216545 31.763 35.66909537739824 139.74958425216545 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb5ee4d7-ff8d-4b9d-a159-2fb7ff78c7c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb5ee4d7-ff8d-4b9d-a159-2fb7ff78c7c6_0">
											<gml:posList>35.66908761409021 139.74958068134353 30.241 35.66908171449054 139.749599962918 30.241 35.66908171449054 139.749599962918 31.763 35.66908761409021 139.74958068134353 31.763 35.66908761409021 139.74958068134353 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34fc0813-e72e-4fc8-b82f-ec53909026b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34fc0813-e72e-4fc8-b82f-ec53909026b3_0">
											<gml:posList>35.66909537739824 139.74958425216545 31.763 35.66908761409021 139.74958068134353 31.763 35.66908171449054 139.749599962918 31.763 35.669089477790315 139.74960352269545 31.763 35.66909537739824 139.74958425216545 31.763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-739d2a99-26ff-47fd-9a11-7b4050b21e6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-739d2a99-26ff-47fd-9a11-7b4050b21e6b_0">
											<gml:posList>35.669089477790315 139.74960352269545 30.241 35.66909537739824 139.74958425216545 30.241 35.66909537739824 139.74958425216545 31.763 35.669089477790315 139.74960352269545 31.763 35.669089477790315 139.74960352269545 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02f12d9c-05fd-4a66-9921-c3e9169a629e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-02f12d9c-05fd-4a66-9921-c3e9169a629e_0">
											<gml:posList>35.66913829278583 139.74959865562516 30.241 35.66913829278583 139.74959865562516 32.553 35.66914758878782 139.74960274401676 32.553 35.66914758878782 139.74960274401676 30.241 35.66913829278583 139.74959865562516 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad7ee04c-dc29-4498-b4f6-2c865d782e00">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad7ee04c-dc29-4498-b4f6-2c865d782e00_0">
											<gml:posList>35.669089477790315 139.74960352269545 30.241 35.669089477790315 139.74960352269545 31.763 35.66908171449054 139.749599962918 31.763 35.66908171449054 139.749599962918 30.241 35.669089477790315 139.74960352269545 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1d252ad-86f4-4575-a0fd-a0f70592589d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1d252ad-86f4-4575-a0fd-a0f70592589d_0">
											<gml:posList>35.66913829278583 139.74959865562516 30.241 35.66913501057152 139.74960987083296 30.241 35.66913501057152 139.74960987083296 32.553 35.66913829278583 139.74959865562516 32.553 35.66913829278583 139.74959865562516 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-169b437f-bbae-4e3a-b6a4-c6cc8c1acc09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-169b437f-bbae-4e3a-b6a4-c6cc8c1acc09_0">
											<gml:posList>35.66913501057152 139.74960987083296 32.553 35.66914431558687 139.74961395921628 32.553 35.66914758878782 139.74960274401676 32.553 35.66913829278583 139.74959865562516 32.553 35.66913501057152 139.74960987083296 32.553</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbba5807-c67f-4b27-a391-098e30684aa7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbba5807-c67f-4b27-a391-098e30684aa7_0">
											<gml:posList>35.66914431558687 139.74961395921628 30.241 35.66914758878782 139.74960274401676 30.241 35.66914758878782 139.74960274401676 32.553 35.66914431558687 139.74961395921628 32.553 35.66914431558687 139.74961395921628 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7227b85c-cb1e-4950-a7c1-dfa6d16745ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7227b85c-cb1e-4950-a7c1-dfa6d16745ec_0">
											<gml:posList>35.66913501057152 139.74960987083296 30.241 35.66914431558687 139.74961395921628 30.241 35.66914431558687 139.74961395921628 32.553 35.66913501057152 139.74960987083296 32.553 35.66913501057152 139.74960987083296 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c391320f-cd3e-4f6e-aa16-2b56a7ed0274">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c391320f-cd3e-4f6e-aa16-2b56a7ed0274_0">
											<gml:posList>35.66914278021422 139.7496225546773 30.241 35.66913416898735 139.7496180789556 30.241 35.66913416898735 139.7496180789556 32.3 35.66914278021422 139.7496225546773 32.3 35.66914278021422 139.7496225546773 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77726cd9-855f-4997-9be4-65eac3452548">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77726cd9-855f-4997-9be4-65eac3452548_0">
											<gml:posList>35.66913416898735 139.7496180789556 30.241 35.66912360807129 139.74964858822875 30.241 35.66912360807129 139.74964858822875 32.3 35.66913416898735 139.7496180789556 32.3 35.66913416898735 139.7496180789556 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b530e318-2f0c-4346-9588-0fca7b7a86aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b530e318-2f0c-4346-9588-0fca7b7a86aa_0">
											<gml:posList>35.66913416898735 139.7496180789556 32.3 35.66912360807129 139.74964858822875 32.3 35.66913221929704 139.74965306395316 32.3 35.66914278021422 139.7496225546773 32.3 35.66913416898735 139.7496180789556 32.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d78b1c5e-666f-4eb0-b035-0b926bb5b58c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d78b1c5e-666f-4eb0-b035-0b926bb5b58c_0">
											<gml:posList>35.66913221929704 139.74965306395316 30.241 35.66914278021422 139.7496225546773 30.241 35.66914278021422 139.7496225546773 32.3 35.66913221929704 139.74965306395316 32.3 35.66913221929704 139.74965306395316 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-105851a7-d17f-4fe3-8b98-b957f6816f2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-105851a7-d17f-4fe3-8b98-b957f6816f2a_0">
											<gml:posList>35.66912360807129 139.74964858822875 30.241 35.66913221929704 139.74965306395316 30.241 35.66913221929704 139.74965306395316 32.3 35.66912360807129 139.74964858822875 32.3 35.66912360807129 139.74964858822875 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b05684e0-002a-4ba1-8302-b04dc05f1bc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b05684e0-002a-4ba1-8302-b04dc05f1bc8_0">
											<gml:posList>35.66908267842061 139.74967699728424 22.803 35.66907980027436 139.74968599179718 22.803 35.66907980027436 139.74968599179718 25.452 35.66908267842061 139.74967699728424 25.452 35.66908267842061 139.74967699728424 22.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7dfdc37-0660-4399-a44d-f455d5f12f1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7dfdc37-0660-4399-a44d-f455d5f12f1a_0">
											<gml:posList>35.66908267842061 139.74967699728424 22.803 35.66908267842061 139.74967699728424 25.452 35.66911929539656 139.74969456654236 25.452 35.66911929539656 139.74969456654236 22.803 35.66908267842061 139.74967699728424 22.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06430b4d-f23f-455d-8e48-396dff0244cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06430b4d-f23f-455d-8e48-396dff0244cf_0">
											<gml:posList>35.66907980027436 139.74968599179718 25.452 35.669116426270435 139.74970357209548 25.452 35.66911929539656 139.74969456654236 25.452 35.66908267842061 139.74967699728424 25.452 35.66907980027436 139.74968599179718 25.452</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf20ea2c-aaa8-4457-bbe9-4c6928d1bbf2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf20ea2c-aaa8-4457-bbe9-4c6928d1bbf2_0">
											<gml:posList>35.66907980027436 139.74968599179718 22.803 35.669116426270435 139.74970357209548 22.803 35.669116426270435 139.74970357209548 25.452 35.66907980027436 139.74968599179718 25.452 35.66907980027436 139.74968599179718 22.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e01a6069-ecee-458a-87d2-d7c893cdedf5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e01a6069-ecee-458a-87d2-d7c893cdedf5_0">
											<gml:posList>35.669116426270435 139.74970357209548 22.803 35.66911929539656 139.74969456654236 22.803 35.66911929539656 139.74969456654236 25.452 35.669116426270435 139.74970357209548 25.452 35.669116426270435 139.74970357209548 22.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_47d36ea5-99ab-43b6-ac60-2c281f2a0f7b_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c9508be-a4f3-4a16-a66c-96e42bc83d2e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914465087727 139.7494869730144 30.8 35.66911064003075 139.74947111326298 30.8 35.66910201523443 139.74949893632382 30.8 35.66910067175848 139.7494983191478 30.8 35.66910995191026 139.7494666955486 30.8 35.669145802088345 139.74948331555473 30.8 35.66914465087727 139.7494869730144 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f42891e2-205e-4194-8c09-cbac09bca574">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913597180275 139.74951451998984 30.241 35.66910201523443 139.74949893632382 30.241 35.66911064003075 139.74947111326298 30.241 35.66914465087727 139.7494869730144 30.241 35.66913597180275 139.74951451998984 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48b048b4-b525-406a-99aa-7a405119fbab">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669191051781624 139.74953619008275 30.8 35.66919853444982 139.74951211281615 30.8 35.66915448806042 139.74949156894772 30.8 35.66915561221507 139.7494878894237 30.8 35.669202607316336 139.7495101865373 30.8 35.66919412646942 139.7495376339081 30.8 35.669191051781624 139.74953619008275 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0734886-d382-47fa-a5bf-7b30abb4c401">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66914710456264 139.74951566819152 30.241 35.66915448806042 139.74949156894772 30.241 35.66919853444982 139.74951211281615 30.241 35.669191051781624 139.74953619008275 30.241 35.66914710456264 139.74951566819152 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b8de44b8-7c4f-45b5-a177-ce6fcebb86f2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669103604909225 139.7495424672805 30.241 35.66912844588899 139.74955417226653 30.241 35.66912080117263 139.74957854792177 30.241 35.6690959601952 139.7495668429293 30.241 35.669103604909225 139.7495424672805 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ddf3bcf-5ed1-4359-bcfc-c5d5103dfc91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905599027918 139.7496402748278 23.2 35.6690573247407 139.7496408920153 23.2 35.669051820630024 139.7496585825302 23.2 35.6690504320632 139.74965793226073 23.2 35.66905599027918 139.7496402748278 23.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2d85f16-a13c-4aef-b710-41f1567f94be">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690573247407 139.7496408920153 22.803 35.66907738680847 139.74965026024347 22.803 35.66907182859104 139.74966791768037 22.803 35.669051820630024 139.7496585825302 22.803 35.6690573247407 139.7496408920153 22.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17649402-0690-4242-94bc-be6d86a8a0ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17649402-0690-4242-94bc-be6d86a8a0ce_0">
											<gml:posList>35.66905599027918 139.7496402748278 23.2 35.6690504320632 139.74965793226073 23.2 35.6690504320632 139.74965793226073 27.476 35.66905599027918 139.7496402748278 27.476 35.66905599027918 139.7496402748278 23.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e060ed1-6bd7-4ec1-b0ac-3ce619074958">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e060ed1-6bd7-4ec1-b0ac-3ce619074958_0">
											<gml:posList>35.6690573247407 139.7496408920153 23.2 35.6690573247407 139.7496408920153 22.803 35.669051820630024 139.7496585825302 22.803 35.669051820630024 139.7496585825302 23.2 35.6690573247407 139.7496408920153 23.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb4270a5-6d1b-4050-aa9f-8eb8bc9cd331">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb4270a5-6d1b-4050-aa9f-8eb8bc9cd331_0">
											<gml:posList>35.66907182859104 139.74966791768037 22.803 35.66907182859104 139.74966791768037 27.476 35.6690504320632 139.74965793226073 27.476 35.6690504320632 139.74965793226073 23.2 35.669051820630024 139.7496585825302 23.2 35.669051820630024 139.7496585825302 22.803 35.66907182859104 139.74966791768037 22.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-733a5bc2-3527-4f5a-841b-b07eef06ebf3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-733a5bc2-3527-4f5a-841b-b07eef06ebf3_0">
											<gml:posList>35.66907182859104 139.74966791768037 27.476 35.66907738680847 139.74965026024347 27.476 35.66905599027918 139.7496402748278 27.476 35.6690504320632 139.74965793226073 27.476 35.66907182859104 139.74966791768037 27.476</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-023d9676-e1b8-4076-8b33-215e81964bc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-023d9676-e1b8-4076-8b33-215e81964bc4_0">
											<gml:posList>35.6690573247407 139.7496408920153 23.2 35.66905599027918 139.7496402748278 23.2 35.66905599027918 139.7496402748278 27.476 35.66907738680847 139.74965026024347 27.476 35.66907738680847 139.74965026024347 22.803 35.6690573247407 139.7496408920153 22.803 35.6690573247407 139.7496408920153 23.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d306eec5-3c54-4fcb-b290-1e635651ea2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d306eec5-3c54-4fcb-b290-1e635651ea2f_0">
											<gml:posList>35.66907182859104 139.74966791768037 22.803 35.66907738680847 139.74965026024347 22.803 35.66907738680847 139.74965026024347 27.476 35.66907182859104 139.74966791768037 27.476 35.66907182859104 139.74966791768037 22.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e3248ff-56e8-4c8e-970b-9d732f2055fe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e3248ff-56e8-4c8e-970b-9d732f2055fe_0">
											<gml:posList>35.669103604909225 139.7495424672805 30.241 35.6690959601952 139.7495668429293 30.241 35.6690959601952 139.7495668429293 32.952 35.669103604909225 139.7495424672805 32.952 35.669103604909225 139.7495424672805 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad56f881-c17f-48a5-85a0-a96fa50629e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad56f881-c17f-48a5-85a0-a96fa50629e0_0">
											<gml:posList>35.66910067175848 139.7494983191478 30.8 35.66910067175848 139.7494983191478 35.99 35.66910995191026 139.7494666955486 35.99 35.66910995191026 139.7494666955486 30.8 35.66910067175848 139.7494983191478 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f175518d-ba08-4209-88a3-02901a0d407e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f175518d-ba08-4209-88a3-02901a0d407e_0">
											<gml:posList>35.66911064003075 139.74947111326298 30.241 35.66910201523443 139.74949893632382 30.241 35.66910201523443 139.74949893632382 30.8 35.66911064003075 139.74947111326298 30.8 35.66911064003075 139.74947111326298 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-611e3797-fda9-417a-95ff-9810b4b6d36b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-611e3797-fda9-417a-95ff-9810b4b6d36b_0">
											<gml:posList>35.6690959601952 139.7495668429293 30.241 35.66912080117263 139.74957854792177 30.241 35.66912080117263 139.74957854792177 32.952 35.6690959601952 139.7495668429293 32.952 35.6690959601952 139.7495668429293 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc745568-1d29-46a4-a73b-fae77da86ab3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc745568-1d29-46a4-a73b-fae77da86ab3_0">
											<gml:posList>35.66912080117263 139.74957854792177 32.952 35.66912844588899 139.74955417226653 32.952 35.669103604909225 139.7495424672805 32.952 35.6690959601952 139.7495668429293 32.952 35.66912080117263 139.74957854792177 32.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d393ebb6-637c-4df8-848f-19db54ed27e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d393ebb6-637c-4df8-848f-19db54ed27e3_0">
											<gml:posList>35.66912844588899 139.74955417226653 30.241 35.669103604909225 139.7495424672805 30.241 35.669103604909225 139.7495424672805 32.952 35.66912844588899 139.74955417226653 32.952 35.66912844588899 139.74955417226653 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc5f9c5b-24f1-4b91-b0f3-d3a7b95ea71e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc5f9c5b-24f1-4b91-b0f3-d3a7b95ea71e_0">
											<gml:posList>35.66913597180275 139.74951451998984 30.241 35.66913597180275 139.74951451998984 35.99 35.66910067175848 139.7494983191478 35.99 35.66910067175848 139.7494983191478 30.8 35.66910201523443 139.74949893632382 30.8 35.66910201523443 139.74949893632382 30.241 35.66913597180275 139.74951451998984 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-479e07a3-8022-406c-8644-83e6d43ed5cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-479e07a3-8022-406c-8644-83e6d43ed5cf_0">
											<gml:posList>35.66910995191026 139.7494666955486 35.99 35.66910067175848 139.7494983191478 35.99 35.66913597180275 139.74951451998984 35.99 35.669145802088345 139.74948331555473 35.99 35.66910995191026 139.7494666955486 35.99</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ead5dd6d-3cff-40e4-8350-d567e6953167">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ead5dd6d-3cff-40e4-8350-d567e6953167_0">
											<gml:posList>35.66912844588899 139.74955417226653 30.241 35.66912844588899 139.74955417226653 32.952 35.66912080117263 139.74957854792177 32.952 35.66912080117263 139.74957854792177 30.241 35.66912844588899 139.74955417226653 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d88ce71-f625-47ae-945c-966337bd7af3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5d88ce71-f625-47ae-945c-966337bd7af3_0">
											<gml:posList>35.66911064003075 139.74947111326298 30.8 35.66914465087727 139.7494869730144 30.8 35.66914465087727 139.7494869730144 30.241 35.66911064003075 139.74947111326298 30.241 35.66911064003075 139.74947111326298 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-38353fa3-74d7-4af5-9bbe-d710279e72ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-38353fa3-74d7-4af5-9bbe-d710279e72ee_0">
											<gml:posList>35.66910995191026 139.7494666955486 30.8 35.66910995191026 139.7494666955486 35.99 35.669145802088345 139.74948331555473 35.99 35.669145802088345 139.74948331555473 30.8 35.66910995191026 139.7494666955486 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dad2f25-cb0f-4852-9d2c-74c28623f93e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dad2f25-cb0f-4852-9d2c-74c28623f93e_0">
											<gml:posList>35.66914465087727 139.7494869730144 30.8 35.669145802088345 139.74948331555473 30.8 35.669145802088345 139.74948331555473 35.99 35.66913597180275 139.74951451998984 35.99 35.66913597180275 139.74951451998984 30.241 35.66914465087727 139.7494869730144 30.241 35.66914465087727 139.7494869730144 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99ae3251-7503-443a-9776-d3ba85d6fb07">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99ae3251-7503-443a-9776-d3ba85d6fb07_0">
											<gml:posList>35.66914710456264 139.74951566819152 30.241 35.66914710456264 139.74951566819152 32.101 35.66915561221507 139.7494878894237 32.101 35.66915561221507 139.7494878894237 30.8 35.66915448806042 139.74949156894772 30.8 35.66915448806042 139.74949156894772 30.241 35.66914710456264 139.74951566819152 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32dee42c-9d97-4edf-ba65-e5e16c6a851d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32dee42c-9d97-4edf-ba65-e5e16c6a851d_0">
											<gml:posList>35.66919412646942 139.7495376339081 32.101 35.66914710456264 139.74951566819152 32.101 35.66914710456264 139.74951566819152 30.241 35.669191051781624 139.74953619008275 30.241 35.669191051781624 139.74953619008275 30.8 35.66919412646942 139.7495376339081 30.8 35.66919412646942 139.7495376339081 32.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc186fad-fc92-4170-ac6c-a0f82ecf1fe6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc186fad-fc92-4170-ac6c-a0f82ecf1fe6_0">
											<gml:posList>35.669202607316336 139.7495101865373 32.101 35.66915561221507 139.7494878894237 32.101 35.66914710456264 139.74951566819152 32.101 35.66919412646942 139.7495376339081 32.101 35.669202607316336 139.7495101865373 32.101</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d1f86e4-3df3-4966-a95a-3c0416dea6e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d1f86e4-3df3-4966-a95a-3c0416dea6e4_0">
											<gml:posList>35.66919853444982 139.74951211281615 30.241 35.66915448806042 139.74949156894772 30.241 35.66915448806042 139.74949156894772 30.8 35.66919853444982 139.74951211281615 30.8 35.66919853444982 139.74951211281615 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c15e364d-3fb9-440b-a9ac-902b01fa0a4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c15e364d-3fb9-440b-a9ac-902b01fa0a4d_0">
											<gml:posList>35.66915561221507 139.7494878894237 30.8 35.66915561221507 139.7494878894237 32.101 35.669202607316336 139.7495101865373 32.101 35.669202607316336 139.7495101865373 30.8 35.66915561221507 139.7494878894237 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b259ad0-459d-4289-a771-4e5b1f54d7e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b259ad0-459d-4289-a771-4e5b1f54d7e1_0">
											<gml:posList>35.66919853444982 139.74951211281615 30.8 35.669191051781624 139.74953619008275 30.8 35.669191051781624 139.74953619008275 30.241 35.66919853444982 139.74951211281615 30.241 35.66919853444982 139.74951211281615 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e70bd76-142f-4ce8-bd0a-4697c51d77b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e70bd76-142f-4ce8-bd0a-4697c51d77b2_0">
											<gml:posList>35.66919412646942 139.7495376339081 30.8 35.669202607316336 139.7495101865373 30.8 35.669202607316336 139.7495101865373 32.101 35.66919412646942 139.7495376339081 32.101 35.66919412646942 139.7495376339081 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e8b32a10-6643-471c-8488-527c3e654396">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8b32a10-6643-471c-8488-527c3e654396">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8b32a10-6643-471c-8488-527c3e654396">
											<gml:posList>35.66913199097034 139.7497396102938 6.217 35.66903695545407 139.74969530415115 6.217 35.66910836425569 139.74946491878953 6.217 35.66920358020672 139.74950933497064 6.217 35.66913199097034 139.7497396102938 6.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87bba432-c97f-41db-8dbd-86b31c530048">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87bba432-c97f-41db-8dbd-86b31c530048">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87bba432-c97f-41db-8dbd-86b31c530048">
											<gml:posList>35.66905436701756 139.7496391387762 30.8 35.66905942179894 139.74963637198036 30.8 35.66911064003075 139.74947111326298 30.8 35.66910836425569 139.74946491878953 30.8 35.66905436701756 139.7496391387762 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53759404-b7d2-42b7-9442-ef71f3aac241">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53759404-b7d2-42b7-9442-ef71f3aac241">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53759404-b7d2-42b7-9442-ef71f3aac241">
											<gml:posList>35.66903695545407 139.74969530415115 22.07 35.66913199097034 139.7497396102938 22.07 35.66913485993812 139.74973037277252 23.2 35.669039842399904 139.749686000344 23.2 35.66903695545407 139.74969530415115 22.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5c6fa87b-dbb5-469c-92a4-63620eb8b232">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c6fa87b-dbb5-469c-92a4-63620eb8b232">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c6fa87b-dbb5-469c-92a4-63620eb8b232">
											<gml:posList>35.66913485993812 139.74973037277252 23.2 35.66914942964905 139.74968352215618 23.2 35.669147635334234 139.74968268452523 23.2 35.66913406393083 139.74972634178013 23.2 35.669043852280666 139.74968422878862 23.2 35.66905742366906 139.74964057157575 23.2 35.66905436701756 139.7496391387762 23.2 35.669039842399904 139.749686000344 23.2 35.66913485993812 139.74973037277252 23.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fabff443-81be-4aed-8240-e869491d3ace">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fabff443-81be-4aed-8240-e869491d3ace">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fabff443-81be-4aed-8240-e869491d3ace">
											<gml:posList>35.669043852280666 139.74968422878862 22.803 35.66913406393083 139.74972634178013 22.803 35.669147635334234 139.74968268452523 22.803 35.66905742366906 139.74964057157575 22.803 35.669043852280666 139.74968422878862 22.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-56a8947a-c494-4e2e-9a1c-beb24d1e5cb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56a8947a-c494-4e2e-9a1c-beb24d1e5cb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56a8947a-c494-4e2e-9a1c-beb24d1e5cb1">
											<gml:posList>35.66914942964905 139.74968352215618 30.8 35.66914717192004 139.7496773387009 30.8 35.66905942179894 139.74963637198036 30.8 35.66905436701756 139.7496391387762 30.8 35.66914942964905 139.74968352215618 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad9e4dfd-8a34-454d-b95e-c7c8ca8c3b56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad9e4dfd-8a34-454d-b95e-c7c8ca8c3b56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad9e4dfd-8a34-454d-b95e-c7c8ca8c3b56">
											<gml:posList>35.66919853444982 139.74951211281615 30.241 35.66911064003075 139.74947111326298 30.241 35.66905942179894 139.74963637198036 30.241 35.66914717192004 139.7496773387009 30.241 35.66919853444982 139.74951211281615 30.241</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f061aff-8c77-425b-9d91-0f6feeed8678">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f061aff-8c77-425b-9d91-0f6feeed8678">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f061aff-8c77-425b-9d91-0f6feeed8678">
											<gml:posList>35.66910836425569 139.74946491878953 30.8 35.66911064003075 139.74947111326298 30.8 35.66919853444982 139.74951211281615 30.8 35.66920358020672 139.74950933497064 30.8 35.66910836425569 139.74946491878953 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f609e91-93e8-4c62-a916-7c0b08e8830f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f609e91-93e8-4c62-a916-7c0b08e8830f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f609e91-93e8-4c62-a916-7c0b08e8830f">
											<gml:posList>35.66920358020672 139.74950933497064 30.8 35.66919853444982 139.74951211281615 30.8 35.66914717192004 139.7496773387009 30.8 35.66914942964905 139.74968352215618 30.8 35.66920358020672 139.74950933497064 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7d4a185-4364-417c-8831-878726480807">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7d4a185-4364-417c-8831-878726480807">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7d4a185-4364-417c-8831-878726480807">
											<gml:posList>35.669043852280666 139.74968422878862 23.2 35.669043852280666 139.74968422878862 22.803 35.66905742366906 139.74964057157575 22.803 35.66905742366906 139.74964057157575 23.2 35.669043852280666 139.74968422878862 23.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6101f2c8-b317-47f9-82c3-cc141c1d3d82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6101f2c8-b317-47f9-82c3-cc141c1d3d82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6101f2c8-b317-47f9-82c3-cc141c1d3d82">
											<gml:posList>35.66910836425569 139.74946491878953 30.8 35.66910836425569 139.74946491878953 6.217 35.66903695545407 139.74969530415115 6.217 35.66903695545407 139.74969530415115 22.07 35.669039842399904 139.749686000344 23.2 35.66905436701756 139.7496391387762 23.2 35.66905436701756 139.7496391387762 30.8 35.66910836425569 139.74946491878953 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3795ee6-1bb7-4213-9068-d0d83b3b9fac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3795ee6-1bb7-4213-9068-d0d83b3b9fac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3795ee6-1bb7-4213-9068-d0d83b3b9fac">
											<gml:posList>35.66903695545407 139.74969530415115 6.217 35.66913199097034 139.7497396102938 6.217 35.66913199097034 139.7497396102938 22.07 35.66903695545407 139.74969530415115 22.07 35.66903695545407 139.74969530415115 6.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6c91e02e-57ff-43c8-9e9a-e24e38aa47b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c91e02e-57ff-43c8-9e9a-e24e38aa47b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c91e02e-57ff-43c8-9e9a-e24e38aa47b4">
											<gml:posList>35.66905942179894 139.74963637198036 30.8 35.66905942179894 139.74963637198036 30.241 35.66911064003075 139.74947111326298 30.241 35.66911064003075 139.74947111326298 30.8 35.66905942179894 139.74963637198036 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7a85258-e82f-4c36-b824-6b8a83ea408e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7a85258-e82f-4c36-b824-6b8a83ea408e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7a85258-e82f-4c36-b824-6b8a83ea408e">
											<gml:posList>35.66913406393083 139.74972634178013 23.2 35.66913406393083 139.74972634178013 22.803 35.669043852280666 139.74968422878862 22.803 35.669043852280666 139.74968422878862 23.2 35.66913406393083 139.74972634178013 23.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae11c540-7f80-46cf-b852-6b79143397da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae11c540-7f80-46cf-b852-6b79143397da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae11c540-7f80-46cf-b852-6b79143397da">
											<gml:posList>35.66905742366906 139.74964057157575 23.2 35.66905742366906 139.74964057157575 22.803 35.669147635334234 139.74968268452523 22.803 35.669147635334234 139.74968268452523 23.2 35.66914942964905 139.74968352215618 23.2 35.66914942964905 139.74968352215618 30.8 35.66905436701756 139.7496391387762 30.8 35.66905436701756 139.7496391387762 23.2 35.66905742366906 139.74964057157575 23.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-027c4db7-be94-4a46-ac64-056b12a37018">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-027c4db7-be94-4a46-ac64-056b12a37018">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-027c4db7-be94-4a46-ac64-056b12a37018">
											<gml:posList>35.66914717192004 139.7496773387009 30.8 35.66914717192004 139.7496773387009 30.241 35.66905942179894 139.74963637198036 30.241 35.66905942179894 139.74963637198036 30.8 35.66914717192004 139.7496773387009 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3805e93c-977b-4182-bc6d-1bf60ee0f49a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3805e93c-977b-4182-bc6d-1bf60ee0f49a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3805e93c-977b-4182-bc6d-1bf60ee0f49a">
											<gml:posList>35.669147635334234 139.74968268452523 23.2 35.669147635334234 139.74968268452523 22.803 35.66913406393083 139.74972634178013 22.803 35.66913406393083 139.74972634178013 23.2 35.669147635334234 139.74968268452523 23.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-32ecf8da-2682-4efb-b162-a68b81601ebb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-32ecf8da-2682-4efb-b162-a68b81601ebb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-32ecf8da-2682-4efb-b162-a68b81601ebb">
											<gml:posList>35.66911064003075 139.74947111326298 30.8 35.66911064003075 139.74947111326298 30.241 35.66919853444982 139.74951211281615 30.241 35.66919853444982 139.74951211281615 30.8 35.66911064003075 139.74947111326298 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d726a96f-b8f9-47da-9f42-65d4f48bc209">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d726a96f-b8f9-47da-9f42-65d4f48bc209">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d726a96f-b8f9-47da-9f42-65d4f48bc209">
											<gml:posList>35.66920358020672 139.74950933497064 6.217 35.66910836425569 139.74946491878953 6.217 35.66910836425569 139.74946491878953 30.8 35.66920358020672 139.74950933497064 30.8 35.66920358020672 139.74950933497064 6.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af3374ea-c1ee-410e-aa3c-d5757088d97d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af3374ea-c1ee-410e-aa3c-d5757088d97d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af3374ea-c1ee-410e-aa3c-d5757088d97d">
											<gml:posList>35.66914942964905 139.74968352215618 23.2 35.66913485993812 139.74973037277252 23.2 35.66913199097034 139.7497396102938 22.07 35.66913199097034 139.7497396102938 6.217 35.66920358020672 139.74950933497064 6.217 35.66920358020672 139.74950933497064 30.8 35.66914942964905 139.74968352215618 30.8 35.66914942964905 139.74968352215618 23.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8dd39b1c-edf1-4506-8e93-5824ba6ece89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dd39b1c-edf1-4506-8e93-5824ba6ece89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dd39b1c-edf1-4506-8e93-5824ba6ece89">
											<gml:posList>35.66919853444982 139.74951211281615 30.8 35.66919853444982 139.74951211281615 30.241 35.66914717192004 139.7496773387009 30.241 35.66914717192004 139.7496773387009 30.8 35.66919853444982 139.74951211281615 30.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7637</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">251.9135</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>