<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_480bffb3-189a-4ca0-b953-edb6f5c1b22e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">11.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67021807818511 139.7389170313994 0 35.67025844883448 139.73890317605637 0 35.67026107190918 139.73891477152205 0 35.67045454471294 139.738848486993 0 35.6704183653385 139.73869001573246 0 35.67018452207555 139.7387702664869 0 35.67021807818511 139.7389170313994 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021807818511 139.7389170313994 20.28 35.67018452207555 139.7387702664869 20.28 35.6704183653385 139.73869001573246 20.28 35.67045454471294 139.738848486993 20.28 35.67026107190918 139.73891477152205 20.28 35.67025844883448 139.73890317605637 20.28 35.67021807818511 139.7389170313994 20.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021807818511 139.7389170313994 20.28 35.67025844883448 139.73890317605637 20.28 35.67025844883448 139.73890317605637 31.97 35.67021807818511 139.7389170313994 31.97 35.67021807818511 139.7389170313994 20.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67025844883448 139.73890317605637 20.28 35.67026107190918 139.73891477152205 20.28 35.67026107190918 139.73891477152205 31.97 35.67025844883448 139.73890317605637 31.97 35.67025844883448 139.73890317605637 20.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67026107190918 139.73891477152205 20.28 35.67045454471294 139.738848486993 20.28 35.67045454471294 139.738848486993 31.97 35.67026107190918 139.73891477152205 31.97 35.67026107190918 139.73891477152205 20.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67045454471294 139.738848486993 20.28 35.6704183653385 139.73869001573246 20.28 35.6704183653385 139.73869001573246 31.97 35.67045454471294 139.738848486993 31.97 35.67045454471294 139.738848486993 20.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6704183653385 139.73869001573246 20.28 35.67018452207555 139.7387702664869 20.28 35.67018452207555 139.7387702664869 31.97 35.6704183653385 139.73869001573246 31.97 35.6704183653385 139.73869001573246 20.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018452207555 139.7387702664869 20.28 35.67021807818511 139.7389170313994 20.28 35.67021807818511 139.7389170313994 31.97 35.67018452207555 139.7387702664869 31.97 35.67018452207555 139.7387702664869 20.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021807818511 139.7389170313994 31.97 35.67025844883448 139.73890317605637 31.97 35.67026107190918 139.73891477152205 31.97 35.67045454471294 139.738848486993 31.97 35.6704183653385 139.73869001573246 31.97 35.67018452207555 139.7387702664869 31.97 35.67021807818511 139.7389170313994 31.97</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0bbf944e-673e-452d-882d-a139596cfec6"/>
							<gml:surfaceMember xlink:href="#poly-629536c6-3f61-4c65-b209-10da90c6c6a1"/>
							<gml:surfaceMember xlink:href="#poly-b7f1dcf6-de17-4404-9708-c2d4d2b530f8"/>
							<gml:surfaceMember xlink:href="#poly-66adefcc-29d1-464e-a6ff-b2f2d3b3a28f"/>
							<gml:surfaceMember xlink:href="#poly-1b8a7e26-5688-4ccf-954e-ece2b1d2eabd"/>
							<gml:surfaceMember xlink:href="#poly-5e4228e5-7b36-4c7b-8955-31e52fec368a"/>
							<gml:surfaceMember xlink:href="#poly-c41a7029-6bbc-4ecd-9622-a88d21353fe0"/>
							<gml:surfaceMember xlink:href="#poly-e7f68527-574c-4fc6-90f1-edaea2032c81"/>
							<gml:surfaceMember xlink:href="#poly-72f52068-85ed-488f-9afe-48e84eea9b38"/>
							<gml:surfaceMember xlink:href="#poly-ce7f8175-6e1b-4c81-b75a-66049da1f75d"/>
							<gml:surfaceMember xlink:href="#poly-1047818b-dcdb-456e-933c-6fdae28a4a5b"/>
							<gml:surfaceMember xlink:href="#poly-c17de59a-d865-4826-8800-22004f1600b7"/>
							<gml:surfaceMember xlink:href="#poly-874611c2-6e45-4640-98f7-eade3f4dec11"/>
							<gml:surfaceMember xlink:href="#poly-639fdbfb-643f-4fbc-ab2f-0be82d0311d8"/>
							<gml:surfaceMember xlink:href="#poly-e78896ed-667d-46d2-bcfe-6b3770f0e0aa"/>
							<gml:surfaceMember xlink:href="#poly-677387c6-4b8c-4658-8339-fe8d3ba63882"/>
							<gml:surfaceMember xlink:href="#poly-d6b3e34e-21ba-4f0d-bc00-7868addea4f0"/>
							<gml:surfaceMember xlink:href="#poly-558910d9-f235-4d2c-bfeb-800980611440"/>
							<gml:surfaceMember xlink:href="#poly-754e1039-9688-4d90-9672-de53a32ae52b"/>
							<gml:surfaceMember xlink:href="#poly-6e5c7345-be4f-40fb-9efb-dd529aad36fc"/>
							<gml:surfaceMember xlink:href="#poly-38ca336f-021e-46be-9ed6-62d35353e17b"/>
							<gml:surfaceMember xlink:href="#poly-a251b6dd-ccaa-4a71-bb5f-c1a399cdeb21"/>
							<gml:surfaceMember xlink:href="#poly-ddda2264-1564-4882-9b3f-e0c9582c23d1"/>
							<gml:surfaceMember xlink:href="#poly-055463cb-5eb0-4f9b-b227-4883c8d25986"/>
							<gml:surfaceMember xlink:href="#poly-2da3deea-2444-410c-b92b-c028bfa94c87"/>
							<gml:surfaceMember xlink:href="#poly-431e66fd-6301-4892-baff-8c8a7ebb6468"/>
							<gml:surfaceMember xlink:href="#poly-51c8ccda-71de-4060-b1db-b610dfe73c40"/>
							<gml:surfaceMember xlink:href="#poly-cbb27479-efcb-48b8-a204-8695baaf0ee1"/>
							<gml:surfaceMember xlink:href="#poly-e43b2f96-5100-40e1-8483-379057e3ca37"/>
							<gml:surfaceMember xlink:href="#poly-14b91996-5479-4976-9746-27c463cfb475"/>
							<gml:surfaceMember xlink:href="#poly-ded8c383-3e19-4739-890a-4f04f1aaa4ac"/>
							<gml:surfaceMember xlink:href="#poly-ff43ed46-727d-457c-96bf-11aa5199b5d0"/>
							<gml:surfaceMember xlink:href="#poly-f9d4ee2b-9355-4910-9dbf-73da90ff2ac7"/>
							<gml:surfaceMember xlink:href="#poly-192bf723-1687-4aa6-aa78-62ef9e9f9e5c"/>
							<gml:surfaceMember xlink:href="#poly-ccdb6b06-9bc8-48ad-8ec6-1be1cfbbc508"/>
							<gml:surfaceMember xlink:href="#poly-023ef069-943d-4ddf-a810-c06332664792"/>
							<gml:surfaceMember xlink:href="#poly-94d6a95d-ff97-4930-9b10-95e5585a130c"/>
							<gml:surfaceMember xlink:href="#poly-44c4aa4a-bd6c-4701-bb51-60177192cb3d"/>
							<gml:surfaceMember xlink:href="#poly-78e6beed-ee7d-4f77-86e7-b286f3a65054"/>
							<gml:surfaceMember xlink:href="#poly-2f6628df-fee2-4724-ac11-902e4b6689f6"/>
							<gml:surfaceMember xlink:href="#poly-e418604b-7fb9-4116-886d-bdce42695e62"/>
							<gml:surfaceMember xlink:href="#poly-1b1c0b2c-45ca-417e-936b-a46b47812fff"/>
							<gml:surfaceMember xlink:href="#poly-44108680-f1f5-4a4c-93ab-3fb76729b8b8"/>
							<gml:surfaceMember xlink:href="#poly-e04a1f64-d4ad-4879-ac56-ac7ac475b3c8"/>
							<gml:surfaceMember xlink:href="#poly-f9b3312a-b213-43df-838b-698f0344206f"/>
							<gml:surfaceMember xlink:href="#poly-2c7c873f-08d4-4264-80f1-43733b203cba"/>
							<gml:surfaceMember xlink:href="#poly-37c20214-3471-4a76-aa67-d0cd3e67a5b6"/>
							<gml:surfaceMember xlink:href="#poly-7241e59d-17ec-457a-9546-edf94fc46b71"/>
							<gml:surfaceMember xlink:href="#poly-1f11c6b7-643c-4365-8709-bdc62656bff8"/>
							<gml:surfaceMember xlink:href="#poly-511c5228-99fb-4f67-aa5a-49c51b7f6a2d"/>
							<gml:surfaceMember xlink:href="#poly-9b18ee41-026e-449b-b797-6ca1f1a61e61"/>
							<gml:surfaceMember xlink:href="#poly-38071368-9763-473a-ae56-d9351c49206a"/>
							<gml:surfaceMember xlink:href="#poly-cbd24e3c-b8d1-4150-856a-c18a75cc41b7"/>
							<gml:surfaceMember xlink:href="#poly-8db6cd70-19cf-48cc-a2ff-c9634a193778"/>
							<gml:surfaceMember xlink:href="#poly-a1f1febb-1e60-41fd-a716-ae11526c0f79"/>
							<gml:surfaceMember xlink:href="#poly-77e5bdfa-5069-4b73-9d7a-60b7316dc0f6"/>
							<gml:surfaceMember xlink:href="#poly-522ced6d-305a-4885-a30c-91e3785c4f46"/>
							<gml:surfaceMember xlink:href="#poly-0a86254f-33ba-4fd7-b5a3-d0a76dcac42a"/>
							<gml:surfaceMember xlink:href="#poly-d0e8ef3c-1126-4d8d-93ab-0d4daa1d4261"/>
							<gml:surfaceMember xlink:href="#poly-e8c1995a-5c30-4911-96f4-92ffbbc904a7"/>
							<gml:surfaceMember xlink:href="#poly-a9c8a724-3ba4-4af6-9036-702f5ad74ccc"/>
							<gml:surfaceMember xlink:href="#poly-1fb0565a-82b2-40d0-9496-75b39ab54307"/>
							<gml:surfaceMember xlink:href="#poly-dae144fc-221f-49fb-9153-53259c8a94fd"/>
							<gml:surfaceMember xlink:href="#poly-e760a751-ad80-474f-945f-2137b6943b63"/>
							<gml:surfaceMember xlink:href="#poly-1f480096-2ebb-4111-bdd9-41c6adf4d52a"/>
							<gml:surfaceMember xlink:href="#poly-70776fbb-a696-4cb4-a0fd-a862a96cccf1"/>
							<gml:surfaceMember xlink:href="#poly-5d75c39d-f01c-4cd4-9aae-09edc06c92e9"/>
							<gml:surfaceMember xlink:href="#poly-47a169c1-b7b7-405b-88e7-b52e88d5e3bc"/>
							<gml:surfaceMember xlink:href="#poly-dd5108f7-1c18-4933-b9e3-0d39cdc5089f"/>
							<gml:surfaceMember xlink:href="#poly-04e02cb7-f6a5-4c4d-b1d1-26884b15d14b"/>
							<gml:surfaceMember xlink:href="#poly-c52ddd25-88b7-4994-a100-1c73844044b1"/>
							<gml:surfaceMember xlink:href="#poly-127c4774-6d45-4afa-8b96-5eef4b09693e"/>
							<gml:surfaceMember xlink:href="#poly-49f45848-0d42-4e33-af6b-653404bab56b"/>
							<gml:surfaceMember xlink:href="#poly-bca991c1-c3b0-46cb-8807-fd917e46947a"/>
							<gml:surfaceMember xlink:href="#poly-1206d405-ffa2-4ebe-8069-6d45c11adea7"/>
							<gml:surfaceMember xlink:href="#poly-b34137c7-b724-45e9-b440-bbd88e37410c"/>
							<gml:surfaceMember xlink:href="#poly-ace37413-ca46-4f3f-b098-1682019f15b8"/>
							<gml:surfaceMember xlink:href="#poly-38960678-9c22-4e9a-9362-75f8e0586ef6"/>
							<gml:surfaceMember xlink:href="#poly-87eda565-5ebd-4a00-b242-20dd70c13f6c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_480bffb3-189a-4ca0-b953-edb6f5c1b22e_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b59afa6-a844-444d-85e6-2fb04b99a740">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67038071002424 139.7387066406169 29.695 35.670380836667746 139.7387072148729 29.695 35.67037188844606 139.73871028524718 29.695 35.67037175278884 139.73870971100186 29.695 35.67038071002424 139.7387066406169 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19c592c6-d6bc-4be2-bd20-661745f746c9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670376239018566 139.73872933490907 29.398 35.67037188844606 139.73871028524718 29.398 35.670380836667746 139.7387072148729 29.398 35.670385196245796 139.73872625347988 29.398 35.670376239018566 139.73872933490907 29.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-44f95b8d-91d4-48ad-bc02-7731b3fccbce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670311325596124 139.73875669573928 40.85 35.67029779963404 139.73876134007222 40.85 35.67029410933306 139.7387451727188 40.85 35.67030763529453 139.73874052838337 40.85 35.670311325596124 139.73875669573928 40.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a352450-369d-473c-a3c3-fb50a8fe2ba9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670408567436766 139.7387588786565 29.398 35.67040653226071 139.73874985626034 29.398 35.67042183349151 139.73874465751155 29.398 35.67042387768167 139.73875367989868 29.398 35.670408567436766 139.7387588786565 29.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43e98314-a8f9-464b-88f4-d3a110132c32">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67038123177492 139.73875120061157 31.217 35.67038858500266 139.7387486844362 31.217 35.67039221196418 139.73876454258817 31.217 35.67038485874479 139.7387670698085 31.217 35.67038123177492 139.73875120061157 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-493a3fe8-a72b-4dae-8cc4-ae5abc2de4f7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67021401249465 139.73876707248192 31.848 35.67021349694271 139.73876481965777 31.848 35.67022344542031 139.7387614056825 31.848 35.670223960972294 139.7387636585069 31.848 35.67021401249465 139.73876707248192 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb7c7305-a9b2-4c02-8876-2e9f0e96f482">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670410702075394 139.73876829860131 29.398 35.67042628265428 139.73876300010988 29.398 35.67043022636059 139.73878047065128 29.398 35.670414654794655 139.73878576912898 29.398 35.670410702075394 139.73876829860131 29.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e62e5ad-eac6-40fc-959f-f19f0a163197">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67026566496737 139.738771905046 39.333 35.6702728559834 139.7387694332524 39.333 35.67027521667555 139.73877975870707 39.333 35.67026802565932 139.7387822304998 39.333 35.67026566496737 139.738771905046 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f68bd045-fdfe-4136-84f8-938b5871cddf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670223960972294 139.7387636585069 31.217 35.67022889040959 139.7387852480888 31.217 35.670218941931324 139.73878866206132 31.217 35.67021401249465 139.73876707248192 31.217 35.670223960972294 139.7387636585069 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f2174f2-094b-4781-b2d9-04e95ee4945b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67039638093526 139.73878191344025 31.217 35.67040103901231 139.738802299347 31.217 35.670393505561044 139.73880488200794 31.217 35.67038884748443 139.73878449610297 31.217 35.67039638093526 139.73878191344025 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41aa05b9-02e6-4b43-b385-73583a095731">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670231531479764 139.73879678829388 31.217 35.67023656039154 139.73881879751968 31.217 35.67022675608854 139.73882215608722 31.217 35.67022172717738 139.73880014686395 31.217 35.670231531479764 139.73879678829388 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24155e48-2e5c-46d9-a35c-0bd1f5d6bdd4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67036519568332 139.73881923133433 31.217 35.67038292991991 139.73881313498623 31.217 35.67038548056405 139.73882431079443 31.217 35.67036774631823 139.73883039609402 31.217 35.67036519568332 139.73881923133433 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39c32240-6c27-42bf-925a-325d434b72ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67034302041418 139.73884030058892 31.217 35.67032634048688 139.7388460201129 31.217 35.67032349136897 139.73883354120636 31.217 35.670340171287 139.73882781063372 31.217 35.67034302041418 139.73884030058892 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a186b9e-125a-4b66-9423-11e5f1090440">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670315930884435 139.73883613494 31.217 35.67031887951706 139.73884907767072 31.217 35.67030058656633 139.7388553514043 31.217 35.67029763793436 139.7388424086763 31.217 35.670315930884435 139.73883613494 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47b2306a-9e16-430b-8771-e22121011393">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6702347271271 139.7388603114478 31.217 35.67023012332417 139.73884015748698 31.217 35.670240612479866 139.73883655509704 31.217 35.67024521628339 139.73885670906031 31.217 35.6702347271271 139.7388603114478 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1bc1da4d-a740-4a4e-a04c-88e075b9cc98">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6702742806327 139.73885042263817 31.217 35.670277048365385 139.73886257024623 31.217 35.67025889959871 139.7388687996186 31.217 35.67025612285292 139.7388566520237 31.217 35.6702742806327 139.73885042263817 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3d6cf29-46ba-4ad4-a8ba-c4fb481184fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3d6cf29-46ba-4ad4-a8ba-c4fb481184fc_0">
											<gml:posList>35.67022344542031 139.7387614056825 31.848 35.67021349694271 139.73876481965777 31.848 35.67021349694271 139.73876481965777 34.906 35.67022344542031 139.7387614056825 34.906 35.67022344542031 139.7387614056825 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27e05b13-ee3c-4fdc-9205-86afe2e95ea4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27e05b13-ee3c-4fdc-9205-86afe2e95ea4_0">
											<gml:posList>35.67021401249465 139.73876707248192 31.217 35.67021401249465 139.73876707248192 31.848 35.670223960972294 139.7387636585069 31.848 35.670223960972294 139.7387636585069 31.217 35.67021401249465 139.73876707248192 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cdccdb8-d1b6-4f48-a190-3fa3b75587d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cdccdb8-d1b6-4f48-a190-3fa3b75587d4_0">
											<gml:posList>35.670223960972294 139.7387636585069 31.848 35.67022344542031 139.7387614056825 31.848 35.67022344542031 139.7387614056825 34.906 35.67022889040959 139.7387852480888 34.906 35.67022889040959 139.7387852480888 31.217 35.670223960972294 139.7387636585069 31.217 35.670223960972294 139.7387636585069 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a0e8b65-1f14-4553-9c7e-20a71f2169aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a0e8b65-1f14-4553-9c7e-20a71f2169aa_0">
											<gml:posList>35.670218941931324 139.73878866206132 34.906 35.67022889040959 139.7387852480888 34.906 35.67022344542031 139.7387614056825 34.906 35.67021349694271 139.73876481965777 34.906 35.670218941931324 139.73878866206132 34.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e6d5864-83db-49fd-a029-bb4bb523dbc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e6d5864-83db-49fd-a029-bb4bb523dbc3_0">
											<gml:posList>35.670218941931324 139.73878866206132 31.217 35.670218941931324 139.73878866206132 34.906 35.67021349694271 139.73876481965777 34.906 35.67021349694271 139.73876481965777 31.848 35.67021401249465 139.73876707248192 31.848 35.67021401249465 139.73876707248192 31.217 35.670218941931324 139.73878866206132 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86795f0c-53ff-4040-94f6-126e727b52b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86795f0c-53ff-4040-94f6-126e727b52b9_0">
											<gml:posList>35.670218941931324 139.73878866206132 31.217 35.67022889040959 139.7387852480888 31.217 35.67022889040959 139.7387852480888 34.906 35.670218941931324 139.73878866206132 34.906 35.670218941931324 139.73878866206132 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-153bb7d2-5616-444d-b6e9-8a85fce6bd80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-153bb7d2-5616-444d-b6e9-8a85fce6bd80_0">
											<gml:posList>35.67022172717738 139.73880014686395 31.217 35.67022172717738 139.73880014686395 34.906 35.670231531479764 139.73879678829388 34.906 35.670231531479764 139.73879678829388 31.631 35.670231531479764 139.73879678829388 31.217 35.67022172717738 139.73880014686395 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb38dd2c-e973-4f5d-8ed7-199276a3cbb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb38dd2c-e973-4f5d-8ed7-199276a3cbb0_0">
											<gml:posList>35.67023656039154 139.73881879751968 31.487 35.67023656039154 139.73881879751968 31.217 35.670231531479764 139.73879678829388 31.217 35.670231531479764 139.73879678829388 31.631 35.67023656039154 139.73881879751968 31.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a32c2e8-feae-49aa-9b7d-e66a5b7d47bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a32c2e8-feae-49aa-9b7d-e66a5b7d47bd_0">
											<gml:posList>35.670231531479764 139.73879678829388 31.631 35.670231531479764 139.73879678829388 34.906 35.67023233649352 139.73880034423365 34.906 35.67023656039154 139.73881879751968 33.767 35.67023656039154 139.73881879751968 31.487 35.670231531479764 139.73879678829388 31.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7369efb1-3b39-400f-bf2b-4de66caef545">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7369efb1-3b39-400f-bf2b-4de66caef545_0">
											<gml:posList>35.67023233649352 139.73880034423365 34.906 35.670231531479764 139.73879678829388 34.906 35.67022172717738 139.73880014686395 34.906 35.67022675608854 139.73882215608722 34.906 35.67023656039154 139.73881879751968 34.906 35.67023233649352 139.73880034423365 34.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7927cdd-a2d6-46aa-8000-287028f91def">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7927cdd-a2d6-46aa-8000-287028f91def_0">
											<gml:posList>35.67023656039154 139.73881879751968 33.767 35.67023233649352 139.73880034423365 34.906 35.67023656039154 139.73881879751968 34.906 35.67023656039154 139.73881879751968 33.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05b7aba2-c313-4f72-b8ad-bf9ce6c6566c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05b7aba2-c313-4f72-b8ad-bf9ce6c6566c_0">
											<gml:posList>35.67022172717738 139.73880014686395 31.217 35.67022675608854 139.73882215608722 31.217 35.67022675608854 139.73882215608722 34.906 35.67022172717738 139.73880014686395 34.906 35.67022172717738 139.73880014686395 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efbe7c62-b558-4e45-b6a0-7e9eb9ff1140">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efbe7c62-b558-4e45-b6a0-7e9eb9ff1140_0">
											<gml:posList>35.67023656039154 139.73881879751968 31.487 35.67023656039154 139.73881879751968 33.767 35.67023656039154 139.73881879751968 34.906 35.67022675608854 139.73882215608722 34.906 35.67022675608854 139.73882215608722 31.217 35.67023656039154 139.73881879751968 31.217 35.67023656039154 139.73881879751968 31.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d796971e-a5d0-4be5-8163-5275505bc833">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d796971e-a5d0-4be5-8163-5275505bc833_0">
											<gml:posList>35.670240612479866 139.73883655509704 31.217 35.67023012332417 139.73884015748698 31.217 35.67023012332417 139.73884015748698 34.906 35.670240612479866 139.73883655509704 34.906 35.670240612479866 139.73883655509704 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9388fe9-8b51-4575-8d00-5574ccedef59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9388fe9-8b51-4575-8d00-5574ccedef59_0">
											<gml:posList>35.67024521628339 139.73885670906031 31.217 35.670240612479866 139.73883655509704 31.217 35.670240612479866 139.73883655509704 34.906 35.67024521628339 139.73885670906031 34.906 35.67024521628339 139.73885670906031 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b513f97-d758-4ee7-b47b-c63d2eab8d73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b513f97-d758-4ee7-b47b-c63d2eab8d73_0">
											<gml:posList>35.6702347271271 139.7388603114478 34.906 35.67024521628339 139.73885670906031 34.906 35.670240612479866 139.73883655509704 34.906 35.67023012332417 139.73884015748698 34.906 35.6702347271271 139.7388603114478 34.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb9f4ead-7244-43e7-8686-4f15b699ce75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb9f4ead-7244-43e7-8686-4f15b699ce75_0">
											<gml:posList>35.67023012332417 139.73884015748698 31.217 35.6702347271271 139.7388603114478 31.217 35.6702347271271 139.7388603114478 34.906 35.67023012332417 139.73884015748698 34.906 35.67023012332417 139.73884015748698 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-186b8043-c386-4f75-a291-1abfbef3517a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-186b8043-c386-4f75-a291-1abfbef3517a_0">
											<gml:posList>35.67025612285292 139.7388566520237 34.906 35.6702742806327 139.73885042263817 34.906 35.6702742806327 139.73885042263817 31.217 35.67025612285292 139.7388566520237 31.217 35.67025612285292 139.7388566520237 34.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-398e709b-636c-44cb-880e-b144d3302add">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-398e709b-636c-44cb-880e-b144d3302add_0">
											<gml:posList>35.6702347271271 139.7388603114478 31.217 35.67024521628339 139.73885670906031 31.217 35.67024521628339 139.73885670906031 34.906 35.6702347271271 139.7388603114478 34.906 35.6702347271271 139.7388603114478 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37a56496-75f3-40f1-b503-55bd4f527d78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37a56496-75f3-40f1-b503-55bd4f527d78_0">
											<gml:posList>35.67025612285292 139.7388566520237 31.217 35.67025889959871 139.7388687996186 31.217 35.67025889959871 139.7388687996186 34.906 35.67025612285292 139.7388566520237 34.906 35.67025612285292 139.7388566520237 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e394f35c-846a-45b6-9347-83e3176089c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e394f35c-846a-45b6-9347-83e3176089c7_0">
											<gml:posList>35.67038071002424 139.7387066406169 29.695 35.67037175278884 139.73870971100186 29.695 35.67037175278884 139.73870971100186 34.258 35.67038071002424 139.7387066406169 34.258 35.67038071002424 139.7387066406169 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-584952d6-1c43-4501-aac3-17665c0de1a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-584952d6-1c43-4501-aac3-17665c0de1a7_0">
											<gml:posList>35.67037188844606 139.73871028524718 29.695 35.670380836667746 139.7387072148729 29.695 35.670380836667746 139.7387072148729 29.398 35.67037188844606 139.73871028524718 29.398 35.67037188844606 139.73871028524718 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-048c35b9-4b8b-40b1-89c6-4d6f3062ab7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-048c35b9-4b8b-40b1-89c6-4d6f3062ab7e_0">
											<gml:posList>35.670380836667746 139.7387072148729 29.695 35.67038071002424 139.7387066406169 29.695 35.67038071002424 139.7387066406169 34.258 35.670385196245796 139.73872625347988 34.258 35.670385196245796 139.73872625347988 29.398 35.670380836667746 139.7387072148729 29.398 35.670380836667746 139.7387072148729 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-223c6fd7-93c4-4ead-ab21-1fa1e2fd95f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-223c6fd7-93c4-4ead-ab21-1fa1e2fd95f1_0">
											<gml:posList>35.670385196245796 139.73872625347988 34.258 35.67038071002424 139.7387066406169 34.258 35.67037175278884 139.73870971100186 34.258 35.67037443909105 139.7387214500043 34.258 35.670375289305824 139.73872517159018 34.258 35.670376239018566 139.73872933490907 34.258 35.670385196245796 139.73872625347988 34.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-474729b8-99af-4039-b413-27f1873042fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-474729b8-99af-4039-b413-27f1873042fa_0">
											<gml:posList>35.670376239018566 139.73872933490907 29.398 35.670376239018566 139.73872933490907 32.541 35.67037443909105 139.7387214500043 34.258 35.67037175278884 139.73870971100186 34.258 35.67037175278884 139.73870971100186 29.695 35.67037188844606 139.73871028524718 29.695 35.67037188844606 139.73871028524718 29.398 35.670376239018566 139.73872933490907 29.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7216de94-a952-43c8-afbf-9aa9758ba1b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7216de94-a952-43c8-afbf-9aa9758ba1b0_0">
											<gml:posList>35.67037443909105 139.7387214500043 34.258 35.670376239018566 139.73872933490907 32.541 35.670376239018566 139.73872933490907 33.53 35.670375289305824 139.73872517159018 34.258 35.67037443909105 139.7387214500043 34.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d9ad9e1-085b-49cf-bdf0-8a77db4d80da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d9ad9e1-085b-49cf-bdf0-8a77db4d80da_0">
											<gml:posList>35.670375289305824 139.73872517159018 34.258 35.670376239018566 139.73872933490907 33.53 35.670376239018566 139.73872933490907 34.258 35.670375289305824 139.73872517159018 34.258</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c9d8534-ca76-43d1-bf0a-7e1f1143a476">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c9d8534-ca76-43d1-bf0a-7e1f1143a476_0">
											<gml:posList>35.670376239018566 139.73872933490907 33.53 35.670376239018566 139.73872933490907 32.541 35.670376239018566 139.73872933490907 29.398 35.670385196245796 139.73872625347988 29.398 35.670385196245796 139.73872625347988 34.258 35.670376239018566 139.73872933490907 34.258 35.670376239018566 139.73872933490907 33.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7af23965-6a88-46c5-8213-37dd5e1cd01f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7af23965-6a88-46c5-8213-37dd5e1cd01f_0">
											<gml:posList>35.67030763529453 139.73874052838337 40.85 35.67029410933306 139.7387451727188 40.85 35.67029410933306 139.7387451727188 44.445 35.67030763529453 139.73874052838337 44.445 35.67030763529453 139.73874052838337 40.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-357ffec1-fe5d-43d8-a9e0-789649748b22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-357ffec1-fe5d-43d8-a9e0-789649748b22_0">
											<gml:posList>35.67040653226071 139.73874985626034 29.398 35.67040653226071 139.73874985626034 31.138 35.67042183349151 139.73874465751155 31.138 35.67042183349151 139.73874465751155 29.398 35.67040653226071 139.73874985626034 29.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ad56b44-0202-481f-9d91-f7fb8d499258">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ad56b44-0202-481f-9d91-f7fb8d499258_0">
											<gml:posList>35.670311325596124 139.73875669573928 40.85 35.67030763529453 139.73874052838337 40.85 35.67030763529453 139.73874052838337 44.445 35.670311325596124 139.73875669573928 44.445 35.670311325596124 139.73875669573928 40.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0416c74-9aa1-43c7-9430-5b34f4086e68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0416c74-9aa1-43c7-9430-5b34f4086e68_0">
											<gml:posList>35.67042387768167 139.73875367989868 29.398 35.67042183349151 139.73874465751155 29.398 35.67042183349151 139.73874465751155 31.138 35.67042387768167 139.73875367989868 31.138 35.67042387768167 139.73875367989868 29.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36d3fe0b-e52d-4400-8597-363f429a266f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36d3fe0b-e52d-4400-8597-363f429a266f_0">
											<gml:posList>35.67038123177492 139.73875120061157 31.217 35.67038123177492 139.73875120061157 34.483 35.67038858500266 139.7387486844362 34.483 35.67038858500266 139.7387486844362 31.217 35.67038123177492 139.73875120061157 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4c918f4-98bf-47e3-8d53-b12610585253">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4c918f4-98bf-47e3-8d53-b12610585253_0">
											<gml:posList>35.67029410933306 139.7387451727188 44.445 35.67029779963404 139.73876134007222 44.445 35.670311325596124 139.73875669573928 44.445 35.67030763529453 139.73874052838337 44.445 35.67029410933306 139.7387451727188 44.445</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7e0c76c-2e95-4086-8498-bc7975e844d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7e0c76c-2e95-4086-8498-bc7975e844d8_0">
											<gml:posList>35.67042183349151 139.73874465751155 31.138 35.67040653226071 139.73874985626034 31.138 35.670408567436766 139.7387588786565 31.138 35.67042387768167 139.73875367989868 31.138 35.67042183349151 139.73874465751155 31.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e40dabf-6ef4-4486-b2a3-dd33daef35f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e40dabf-6ef4-4486-b2a3-dd33daef35f7_0">
											<gml:posList>35.67029410933306 139.7387451727188 40.85 35.67029779963404 139.73876134007222 40.85 35.67029779963404 139.73876134007222 44.445 35.67029410933306 139.7387451727188 44.445 35.67029410933306 139.7387451727188 40.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13918151-e831-4998-9b3d-d763bee8db10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13918151-e831-4998-9b3d-d763bee8db10_0">
											<gml:posList>35.670408567436766 139.7387588786565 31.138 35.67040653226071 139.73874985626034 31.138 35.67040653226071 139.73874985626034 29.398 35.670408567436766 139.7387588786565 29.398 35.670408567436766 139.7387588786565 31.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-546204d6-4848-4243-af22-21884a68198e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-546204d6-4848-4243-af22-21884a68198e_0">
											<gml:posList>35.670408567436766 139.7387588786565 29.398 35.67042387768167 139.73875367989868 29.398 35.67042387768167 139.73875367989868 31.138 35.670408567436766 139.7387588786565 31.138 35.670408567436766 139.7387588786565 29.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c21bd38-efe1-421d-82d9-8bff70bb097b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c21bd38-efe1-421d-82d9-8bff70bb097b_0">
											<gml:posList>35.67039221196418 139.73876454258817 31.217 35.67038858500266 139.7387486844362 31.217 35.67038858500266 139.7387486844362 34.483 35.67039221196418 139.73876454258817 34.483 35.67039221196418 139.73876454258817 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea2207ab-b145-43cf-8546-2b11e6db6919">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea2207ab-b145-43cf-8546-2b11e6db6919_0">
											<gml:posList>35.67039221196418 139.73876454258817 34.483 35.67038858500266 139.7387486844362 34.483 35.67038123177492 139.73875120061157 34.483 35.67038485874479 139.7387670698085 34.483 35.67039221196418 139.73876454258817 34.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d368656-9f3e-45c1-b4c0-858e561bce2c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d368656-9f3e-45c1-b4c0-858e561bce2c_0">
											<gml:posList>35.67029779963404 139.73876134007222 40.85 35.670311325596124 139.73875669573928 40.85 35.670311325596124 139.73875669573928 44.445 35.67029779963404 139.73876134007222 44.445 35.67029779963404 139.73876134007222 40.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6ef20e8-46cb-4c9f-a5b2-fc09046e9efd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6ef20e8-46cb-4c9f-a5b2-fc09046e9efd_0">
											<gml:posList>35.67038485874479 139.7387670698085 34.483 35.67038123177492 139.73875120061157 34.483 35.67038123177492 139.73875120061157 31.217 35.67038485874479 139.7387670698085 31.217 35.67038485874479 139.7387670698085 34.483</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5437386d-150e-42a5-b629-c31ff875bb10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5437386d-150e-42a5-b629-c31ff875bb10_0">
											<gml:posList>35.670410702075394 139.73876829860131 29.398 35.670410702075394 139.73876829860131 31.342 35.67042628265428 139.73876300010988 31.342 35.67042628265428 139.73876300010988 29.398 35.670410702075394 139.73876829860131 29.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1336806-76b6-4b16-8d51-73756e3d4fc6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1336806-76b6-4b16-8d51-73756e3d4fc6_0">
											<gml:posList>35.67038485874479 139.7387670698085 31.217 35.67039221196418 139.73876454258817 31.217 35.67039221196418 139.73876454258817 34.483 35.67038485874479 139.7387670698085 34.483 35.67038485874479 139.7387670698085 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74a48afb-f2d1-4ab4-bf41-7d16c09c0098">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74a48afb-f2d1-4ab4-bf41-7d16c09c0098_0">
											<gml:posList>35.6702728559834 139.7387694332524 39.333 35.67026566496737 139.738771905046 39.333 35.67026566496737 139.738771905046 44.129 35.6702728559834 139.7387694332524 44.129 35.6702728559834 139.7387694332524 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b766c305-9fd4-4df8-90bc-6026f930c798">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b766c305-9fd4-4df8-90bc-6026f930c798_0">
											<gml:posList>35.67043022636059 139.73878047065128 29.398 35.67042628265428 139.73876300010988 29.398 35.67042628265428 139.73876300010988 31.342 35.67043022636059 139.73878047065128 31.342 35.67043022636059 139.73878047065128 29.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e07569a6-12bd-44b3-b94e-fef1a0a34dbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e07569a6-12bd-44b3-b94e-fef1a0a34dbb_0">
											<gml:posList>35.67043022636059 139.73878047065128 31.342 35.67042628265428 139.73876300010988 31.342 35.670410702075394 139.73876829860131 31.342 35.670414654794655 139.73878576912898 31.342 35.67043022636059 139.73878047065128 31.342</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f456865-2153-4717-ac8a-a38c9b3a4e95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f456865-2153-4717-ac8a-a38c9b3a4e95_0">
											<gml:posList>35.67027521667555 139.73877975870707 39.333 35.6702728559834 139.7387694332524 39.333 35.6702728559834 139.7387694332524 44.129 35.67027521667555 139.73877975870707 44.129 35.67027521667555 139.73877975870707 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c2e9a38-b96c-4188-b70f-3873a1c6cb23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c2e9a38-b96c-4188-b70f-3873a1c6cb23_0">
											<gml:posList>35.67026566496737 139.738771905046 44.129 35.67026802565932 139.7387822304998 44.129 35.67027521667555 139.73877975870707 44.129 35.6702728559834 139.7387694332524 44.129 35.67026566496737 139.738771905046 44.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca4a0abf-aa97-4b38-9473-78a207be4ce4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca4a0abf-aa97-4b38-9473-78a207be4ce4_0">
											<gml:posList>35.67026566496737 139.738771905046 39.333 35.67026802565932 139.7387822304998 39.333 35.67026802565932 139.7387822304998 44.129 35.67026566496737 139.738771905046 44.129 35.67026566496737 139.738771905046 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30444899-f742-4478-9d93-d8d5fab2495c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30444899-f742-4478-9d93-d8d5fab2495c_0">
											<gml:posList>35.670410702075394 139.73876829860131 29.398 35.670414654794655 139.73878576912898 29.398 35.670414654794655 139.73878576912898 31.342 35.670410702075394 139.73876829860131 31.342 35.670410702075394 139.73876829860131 29.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2c86fc9-0529-49d3-8674-af84f093ecf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2c86fc9-0529-49d3-8674-af84f093ecf4_0">
											<gml:posList>35.67026802565932 139.7387822304998 39.333 35.67027521667555 139.73877975870707 39.333 35.67027521667555 139.73877975870707 44.129 35.67026802565932 139.7387822304998 44.129 35.67026802565932 139.7387822304998 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-071edee8-66b5-484e-b5e3-b07a5fc00247">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-071edee8-66b5-484e-b5e3-b07a5fc00247_0">
											<gml:posList>35.670414654794655 139.73878576912898 29.398 35.67043022636059 139.73878047065128 29.398 35.67043022636059 139.73878047065128 31.342 35.670414654794655 139.73878576912898 31.342 35.670414654794655 139.73878576912898 29.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87dbfde1-87fa-4b30-881e-e6147d6657d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87dbfde1-87fa-4b30-881e-e6147d6657d5_0">
											<gml:posList>35.67039638093526 139.73878191344025 31.217 35.67038884748443 139.73878449610297 31.217 35.67038884748443 139.73878449610297 34.906 35.67039638093526 139.73878191344025 34.906 35.67039638093526 139.73878191344025 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-030fab3b-f221-48ff-af7b-1230e1c25feb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-030fab3b-f221-48ff-af7b-1230e1c25feb_0">
											<gml:posList>35.67040103901231 139.738802299347 31.217 35.67039638093526 139.73878191344025 31.217 35.67039638093526 139.73878191344025 34.906 35.67040103901231 139.738802299347 34.906 35.67040103901231 139.738802299347 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abaac73b-c16e-48ab-a932-90dbc1ab5b89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abaac73b-c16e-48ab-a932-90dbc1ab5b89_0">
											<gml:posList>35.67039638093526 139.73878191344025 34.906 35.67038884748443 139.73878449610297 34.906 35.670393505561044 139.73880488200794 34.906 35.67040103901231 139.738802299347 34.906 35.67039638093526 139.73878191344025 34.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d14220d7-db59-4f6c-b300-8165ad69a832">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d14220d7-db59-4f6c-b300-8165ad69a832_0">
											<gml:posList>35.670393505561044 139.73880488200794 34.906 35.67038884748443 139.73878449610297 34.906 35.67038884748443 139.73878449610297 31.217 35.670393505561044 139.73880488200794 31.217 35.670393505561044 139.73880488200794 34.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-47ab704c-3caa-49dd-9bc7-74d513ba6c0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-47ab704c-3caa-49dd-9bc7-74d513ba6c0d_0">
											<gml:posList>35.670393505561044 139.73880488200794 31.217 35.67040103901231 139.738802299347 31.217 35.67040103901231 139.738802299347 34.906 35.670393505561044 139.73880488200794 34.906 35.670393505561044 139.73880488200794 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d25b65bd-b8d7-4fef-a9d5-d1665aef8761">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d25b65bd-b8d7-4fef-a9d5-d1665aef8761_0">
											<gml:posList>35.67038292991991 139.73881313498623 31.217 35.67036519568332 139.73881923133433 31.217 35.67036519568332 139.73881923133433 34.906 35.67038292991991 139.73881313498623 34.906 35.67038292991991 139.73881313498623 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2e16e44-63b7-45b0-98e0-6a698445554e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2e16e44-63b7-45b0-98e0-6a698445554e_0">
											<gml:posList>35.67038292991991 139.73881313498623 31.217 35.67038292991991 139.73881313498623 34.906 35.67038548056405 139.73882431079443 34.906 35.67038548056405 139.73882431079443 31.217 35.67038292991991 139.73881313498623 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40baf334-329e-43d0-8178-4c1bf73052c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40baf334-329e-43d0-8178-4c1bf73052c9_0">
											<gml:posList>35.67038548056405 139.73882431079443 34.906 35.67038292991991 139.73881313498623 34.906 35.67036519568332 139.73881923133433 34.906 35.67036774631823 139.73883039609402 34.906 35.67038548056405 139.73882431079443 34.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dff25900-06c9-435d-830b-f0e1bafe18ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dff25900-06c9-435d-830b-f0e1bafe18ee_0">
											<gml:posList>35.67036519568332 139.73881923133433 31.217 35.67036774631823 139.73883039609402 31.217 35.67036774631823 139.73883039609402 34.906 35.67036519568332 139.73881923133433 34.906 35.67036519568332 139.73881923133433 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fca68ef8-0db8-4243-9ae5-02c89d4a58d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fca68ef8-0db8-4243-9ae5-02c89d4a58d4_0">
											<gml:posList>35.67036774631823 139.73883039609402 31.217 35.67038548056405 139.73882431079443 31.217 35.67038548056405 139.73882431079443 34.906 35.67036774631823 139.73883039609402 34.906 35.67036774631823 139.73883039609402 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f13dd333-4d42-45c8-8f44-856e99567f84">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f13dd333-4d42-45c8-8f44-856e99567f84_0">
											<gml:posList>35.67032349136897 139.73883354120636 34.906 35.670340171287 139.73882781063372 34.906 35.670340171287 139.73882781063372 31.217 35.67032349136897 139.73883354120636 31.217 35.67032349136897 139.73883354120636 34.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-453f5586-baf3-4798-aafa-bd8e5a14791d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-453f5586-baf3-4798-aafa-bd8e5a14791d_0">
											<gml:posList>35.670340171287 139.73882781063372 31.217 35.670340171287 139.73882781063372 34.906 35.67034302041418 139.73884030058892 34.906 35.67034302041418 139.73884030058892 31.217 35.670340171287 139.73882781063372 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce50e6d6-dc7c-48fa-9e6d-4c7e30d7c62f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce50e6d6-dc7c-48fa-9e6d-4c7e30d7c62f_0">
											<gml:posList>35.67034302041418 139.73884030058892 34.906 35.670340171287 139.73882781063372 34.906 35.67032349136897 139.73883354120636 34.906 35.67032634048688 139.7388460201129 34.906 35.67034302041418 139.73884030058892 34.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f17ecf8-3040-4eb6-a676-1845a53b45d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f17ecf8-3040-4eb6-a676-1845a53b45d1_0">
											<gml:posList>35.67029763793436 139.7388424086763 34.906 35.670315930884435 139.73883613494 34.906 35.670315930884435 139.73883613494 31.217 35.67029763793436 139.7388424086763 31.217 35.67029763793436 139.7388424086763 34.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f64c3f3-d4cb-4f15-89f7-791757945b15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f64c3f3-d4cb-4f15-89f7-791757945b15_0">
											<gml:posList>35.67032349136897 139.73883354120636 31.217 35.67032634048688 139.7388460201129 31.217 35.67032634048688 139.7388460201129 34.906 35.67032349136897 139.73883354120636 34.906 35.67032349136897 139.73883354120636 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41bbe5c7-7cee-47dd-9bdc-07938de6e8a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41bbe5c7-7cee-47dd-9bdc-07938de6e8a8_0">
											<gml:posList>35.67031887951706 139.73884907767072 31.217 35.670315930884435 139.73883613494 31.217 35.670315930884435 139.73883613494 34.906 35.67031887951706 139.73884907767072 34.906 35.67031887951706 139.73884907767072 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4d4865a-ce32-49d0-abf9-898fa435cbf7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4d4865a-ce32-49d0-abf9-898fa435cbf7_0">
											<gml:posList>35.67032634048688 139.7388460201129 31.217 35.67034302041418 139.73884030058892 31.217 35.67034302041418 139.73884030058892 34.906 35.67032634048688 139.7388460201129 34.906 35.67032634048688 139.7388460201129 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b3cb76e-28a1-41bb-a41f-387bd9be333b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b3cb76e-28a1-41bb-a41f-387bd9be333b_0">
											<gml:posList>35.67030058656633 139.7388553514043 34.906 35.67031887951706 139.73884907767072 34.906 35.670315930884435 139.73883613494 34.906 35.67029763793436 139.7388424086763 34.906 35.67030058656633 139.7388553514043 34.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d1bada6-c7cf-47ff-9c87-0f0c81ef05ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d1bada6-c7cf-47ff-9c87-0f0c81ef05ec_0">
											<gml:posList>35.67029763793436 139.7388424086763 31.217 35.67030058656633 139.7388553514043 31.217 35.67030058656633 139.7388553514043 34.906 35.67029763793436 139.7388424086763 34.906 35.67029763793436 139.7388424086763 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a3a83a4-c731-47bb-98d2-cf93bb0d0973">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a3a83a4-c731-47bb-98d2-cf93bb0d0973_0">
											<gml:posList>35.67030058656633 139.7388553514043 31.217 35.67031887951706 139.73884907767072 31.217 35.67031887951706 139.73884907767072 34.906 35.67030058656633 139.7388553514043 34.906 35.67030058656633 139.7388553514043 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e32485de-a0c9-426a-a622-6235a1f2865a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e32485de-a0c9-426a-a622-6235a1f2865a_0">
											<gml:posList>35.670277048365385 139.73886257024623 31.217 35.6702742806327 139.73885042263817 31.217 35.6702742806327 139.73885042263817 34.906 35.670277048365385 139.73886257024623 34.906 35.670277048365385 139.73886257024623 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-341299fc-1ebc-408a-b887-4760a2452412">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-341299fc-1ebc-408a-b887-4760a2452412_0">
											<gml:posList>35.67025889959871 139.7388687996186 34.906 35.670277048365385 139.73886257024623 34.906 35.6702742806327 139.73885042263817 34.906 35.67025612285292 139.7388566520237 34.906 35.67025889959871 139.7388687996186 34.906</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e999cfba-d952-4118-a907-d077a5e82564">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e999cfba-d952-4118-a907-d077a5e82564_0">
											<gml:posList>35.67025889959871 139.7388687996186 31.217 35.670277048365385 139.73886257024623 31.217 35.670277048365385 139.73886257024623 34.906 35.67025889959871 139.7388687996186 34.906 35.67025889959871 139.7388687996186 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0bbf944e-673e-452d-882d-a139596cfec6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0bbf944e-673e-452d-882d-a139596cfec6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0bbf944e-673e-452d-882d-a139596cfec6">
											<gml:posList>35.67045454471292 139.738848486993 20.28 35.67026107190919 139.73891477152205 20.28 35.67025844883446 139.73890317605637 20.28 35.670218078185115 139.73891703139938 20.28 35.67018452207556 139.7387702664869 20.28 35.6704183653385 139.73869001573243 20.28 35.67045454471292 139.738848486993 20.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-629536c6-3f61-4c65-b209-10da90c6c6a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-629536c6-3f61-4c65-b209-10da90c6c6a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-629536c6-3f61-4c65-b209-10da90c6c6a1">
											<gml:posList>35.67037097490906 139.73870627653363 29.695 35.67037188844606 139.73871028524718 29.695 35.67041599876668 139.73869515503887 29.695 35.6704183653385 139.73869001573243 29.695 35.67037097490906 139.73870627653363 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7f1dcf6-de17-4404-9708-c2d4d2b530f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7f1dcf6-de17-4404-9708-c2d4d2b530f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7f1dcf6-de17-4404-9708-c2d4d2b530f8">
											<gml:posList>35.670324125161514 139.73872235993753 37.565 35.67032515626691 139.7387268655915 37.565 35.670368320400875 139.7387120568593 37.565 35.67037097490906 139.73870627653363 37.565 35.670324125161514 139.73872235993753 37.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-66adefcc-29d1-464e-a6ff-b2f2d3b3a28f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66adefcc-29d1-464e-a6ff-b2f2d3b3a28f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66adefcc-29d1-464e-a6ff-b2f2d3b3a28f">
											<gml:posList>35.67030964399791 139.73872732574532 39.541 35.67031037662622 139.73873052829327 39.541 35.670322244513486 139.73872646031595 39.541 35.670324125161514 139.73872235993753 39.541 35.67030964399791 139.73872732574532 39.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b8a7e26-5688-4ccf-954e-ece2b1d2eabd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b8a7e26-5688-4ccf-954e-ece2b1d2eabd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b8a7e26-5688-4ccf-954e-ece2b1d2eabd">
											<gml:posList>35.67037696261575 139.7387325153778 31.848 35.67037842788937 139.7387389425717 31.848 35.67039700021575 139.73873261324445 31.848 35.67040077954817 139.73872442350506 31.848 35.67037696261575 139.7387325153778 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e4228e5-7b36-4c7b-8955-31e52fec368a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e4228e5-7b36-4c7b-8955-31e52fec368a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e4228e5-7b36-4c7b-8955-31e52fec368a">
											<gml:posList>35.67026661503274 139.73874209011396 41.536 35.67026957313031 139.738744119133 41.536 35.670307979297185 139.73873093983312 41.536 35.67030964399791 139.73872732574532 41.536 35.67026661503274 139.73874209011396 41.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c41a7029-6bbc-4ecd-9622-a88d21353fe0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c41a7029-6bbc-4ecd-9622-a88d21353fe0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c41a7029-6bbc-4ecd-9622-a88d21353fe0">
											<gml:posList>35.67026661503274 139.73874209011396 39.541 35.67023886923486 139.73875161156752 39.541 35.670242224152986 139.7387539162741 39.541 35.67026734766933 139.73874530370654 39.541 35.67026661503274 139.73874209011396 39.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7f68527-574c-4fc6-90f1-edaea2032c81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7f68527-574c-4fc6-90f1-edaea2032c81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7f68527-574c-4fc6-90f1-edaea2032c81">
											<gml:posList>35.67030964399791 139.73872732574532 41.536 35.670307979297185 139.73873093983312 41.536 35.67031868837535 139.73877781853201 41.536 35.670321646480986 139.73877985859994 41.536 35.67030964399791 139.73872732574532 41.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-72f52068-85ed-488f-9afe-48e84eea9b38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72f52068-85ed-488f-9afe-48e84eea9b38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72f52068-85ed-488f-9afe-48e84eea9b38">
											<gml:posList>35.67023886923486 139.73875161156752 37.565 35.67022248669493 139.7387572423818 37.565 35.67022719441746 139.73876049546894 37.565 35.67023990034784 139.7387561282633 37.565 35.67023886923486 139.73875161156752 37.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce7f8175-6e1b-4c81-b75a-66049da1f75d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce7f8175-6e1b-4c81-b75a-66049da1f75d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce7f8175-6e1b-4c81-b75a-66049da1f75d">
											<gml:posList>35.670324125161514 139.73872235993753 39.541 35.670322244513486 139.73872646031595 39.541 35.67033654434933 139.73878900942108 39.541 35.67033989026166 139.7387913251889 39.541 35.670324125161514 139.73872235993753 39.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1047818b-dcdb-456e-933c-6fdae28a4a5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1047818b-dcdb-456e-933c-6fdae28a4a5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1047818b-dcdb-456e-933c-6fdae28a4a5b">
											<gml:posList>35.67037097490906 139.73870627653363 37.565 35.670368320400875 139.7387120568593 37.565 35.67038976569012 139.73880593581197 37.565 35.670394482416256 139.73880917785186 37.565 35.67037097490906 139.73870627653363 37.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c17de59a-d865-4826-8800-22004f1600b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c17de59a-d865-4826-8800-22004f1600b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c17de59a-d865-4826-8800-22004f1600b7">
											<gml:posList>35.67031868837535 139.73877781853201 40.85 35.670307979297185 139.73873093983312 40.85 35.67026957313031 139.738744119133 40.85 35.67028028220339 139.7387909978112 40.85 35.67031868837535 139.73877781853201 40.85</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-874611c2-6e45-4640-98f7-eade3f4dec11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-874611c2-6e45-4640-98f7-eade3f4dec11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-874611c2-6e45-4640-98f7-eade3f4dec11">
											<gml:posList>35.67022248669493 139.7387572423818 31.848 35.67018452207556 139.7387702664869 31.848 35.67019122290608 139.73877488695558 31.848 35.670223951958576 139.73876365851754 31.848 35.67022248669493 139.7387572423818 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-639fdbfb-643f-4fbc-ab2f-0be82d0311d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-639fdbfb-643f-4fbc-ab2f-0be82d0311d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-639fdbfb-643f-4fbc-ab2f-0be82d0311d8">
											<gml:posList>35.67027861750942 139.7387946229426 41.536 35.67028028220339 139.7387909978112 41.536 35.67026957313031 139.738744119133 41.536 35.67026661503274 139.73874209011396 41.536 35.67027861750942 139.7387946229426 41.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e78896ed-667d-46d2-bcfe-6b3770f0e0aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e78896ed-667d-46d2-bcfe-6b3770f0e0aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e78896ed-667d-46d2-bcfe-6b3770f0e0aa">
											<gml:posList>35.6704183653385 139.73869001573243 29.695 35.67041599876668 139.73869515503887 29.695 35.67045034203007 139.73884557573064 29.695 35.67045454471292 139.738848486993 29.695 35.6704183653385 139.73869001573243 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-677387c6-4b8c-4658-8339-fe8d3ba63882">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-677387c6-4b8c-4658-8339-fe8d3ba63882">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-677387c6-4b8c-4658-8339-fe8d3ba63882">
											<gml:posList>35.67033654434933 139.73878900942108 39.333 35.670322244513486 139.73872646031595 39.333 35.67031037662622 139.73873052829327 39.333 35.670321646480986 139.73877985859994 39.333 35.67027861750942 139.7387946229426 39.333 35.67026734766933 139.73874530370654 39.333 35.670242224152986 139.7387539162741 39.333 35.67025651496963 139.73881647637862 39.333 35.67033654434933 139.73878900942108 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d6b3e34e-21ba-4f0d-bc00-7868addea4f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6b3e34e-21ba-4f0d-bc00-7868addea4f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6b3e34e-21ba-4f0d-bc00-7868addea4f0">
											<gml:posList>35.67040077954817 139.73872442350506 31.848 35.67039700021575 139.73873261324445 31.848 35.67041916075468 139.73883054537228 31.848 35.67042583455015 139.7388351769376 31.848 35.67040077954817 139.73872442350506 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-558910d9-f235-4d2c-bfeb-800980611440">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-558910d9-f235-4d2c-bfeb-800980611440">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-558910d9-f235-4d2c-bfeb-800980611440">
											<gml:posList>35.67038976569012 139.73880593581197 37.078 35.670368320400875 139.7387120568593 37.078 35.67032515626691 139.7387268655915 37.078 35.67033989026166 139.7387913251889 37.078 35.67025462531331 139.73882058780825 37.078 35.67023990034784 139.7387561282633 37.078 35.67022719441746 139.73876049546894 37.078 35.67024864867425 139.73885436321265 37.078 35.67038976569012 139.73880593581197 37.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-754e1039-9688-4d90-9672-de53a32ae52b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-754e1039-9688-4d90-9672-de53a32ae52b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-754e1039-9688-4d90-9672-de53a32ae52b">
											<gml:posList>35.67025462531331 139.73882058780825 39.541 35.67025651496963 139.73881647637862 39.541 35.670242224152986 139.7387539162741 39.541 35.67023886923486 139.73875161156752 39.541 35.67025462531331 139.73882058780825 39.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e5c7345-be4f-40fb-9efb-dd529aad36fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e5c7345-be4f-40fb-9efb-dd529aad36fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e5c7345-be4f-40fb-9efb-dd529aad36fc">
											<gml:posList>35.670321646480986 139.73877985859994 41.536 35.67031868837535 139.73877781853201 41.536 35.67028028220339 139.7387909978112 41.536 35.67027861750942 139.7387946229426 41.536 35.670321646480986 139.73877985859994 41.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38ca336f-021e-46be-9ed6-62d35353e17b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38ca336f-021e-46be-9ed6-62d35353e17b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38ca336f-021e-46be-9ed6-62d35353e17b">
											<gml:posList>35.67041599876668 139.73869515503887 29.398 35.67037188844606 139.73871028524718 29.398 35.67037696261575 139.7387325153778 29.398 35.67040077954817 139.73872442350506 29.398 35.67042583455015 139.7388351769376 29.398 35.6702614318608 139.73889102167587 29.398 35.67026467906652 139.73890540005982 29.398 35.67026264249365 139.7389060762792 29.398 35.670263447495515 139.7389096211752 29.398 35.67045034203007 139.73884557573064 29.398 35.67041599876668 139.73869515503887 29.398</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a251b6dd-ccaa-4a71-bb5f-c1a399cdeb21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a251b6dd-ccaa-4a71-bb5f-c1a399cdeb21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a251b6dd-ccaa-4a71-bb5f-c1a399cdeb21">
											<gml:posList>35.67033989026166 139.7387913251889 39.541 35.67033654434933 139.73878900942108 39.541 35.67025651496963 139.73881647637862 39.541 35.67025462531331 139.73882058780825 39.541 35.67033989026166 139.7387913251889 39.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ddda2264-1564-4882-9b3f-e0c9582c23d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddda2264-1564-4882-9b3f-e0c9582c23d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddda2264-1564-4882-9b3f-e0c9582c23d1">
											<gml:posList>35.67024600316394 139.73886013246775 37.565 35.67024864867425 139.73885436321265 37.565 35.67022719441746 139.73876049546894 37.565 35.67022248669493 139.7387572423818 37.565 35.67024600316394 139.73886013246775 37.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-055463cb-5eb0-4f9b-b227-4883c8d25986">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-055463cb-5eb0-4f9b-b227-4883c8d25986">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-055463cb-5eb0-4f9b-b227-4883c8d25986">
											<gml:posList>35.67041916075468 139.73883054537228 31.217 35.67039700021575 139.73873261324445 31.217 35.67037842788937 139.7387389425717 31.217 35.670394482416256 139.73880917785186 31.217 35.67024600316394 139.73886013246775 31.217 35.670223951958576 139.73876365851754 31.217 35.67019122290608 139.73877488695558 31.217 35.67022184850785 139.7389088306513 31.217 35.670253820627984 139.73889786826493 31.217 35.67025148696112 139.73888750963903 31.217 35.67041916075468 139.73883054537228 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2da3deea-2444-410c-b92b-c028bfa94c87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2da3deea-2444-410c-b92b-c028bfa94c87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2da3deea-2444-410c-b92b-c028bfa94c87">
											<gml:posList>35.670394482416256 139.73880917785186 37.565 35.67038976569012 139.73880593581197 37.565 35.67024864867425 139.73885436321265 37.565 35.67024600316394 139.73886013246775 37.565 35.670394482416256 139.73880917785186 37.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-431e66fd-6301-4892-baff-8c8a7ebb6468">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-431e66fd-6301-4892-baff-8c8a7ebb6468">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-431e66fd-6301-4892-baff-8c8a7ebb6468">
											<gml:posList>35.670218078185115 139.73891703139938 31.848 35.67022184850785 139.7389088306513 31.848 35.67019122290608 139.73877488695558 31.848 35.67018452207556 139.7387702664869 31.848 35.670218078185115 139.73891703139938 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-51c8ccda-71de-4060-b1db-b610dfe73c40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-51c8ccda-71de-4060-b1db-b610dfe73c40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-51c8ccda-71de-4060-b1db-b610dfe73c40">
											<gml:posList>35.67025815174086 139.73889214121004 31.848 35.67042583455015 139.7388351769376 31.848 35.67041916075468 139.73883054537228 31.848 35.67025148696112 139.73888750963903 31.848 35.67025815174086 139.73889214121004 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cbb27479-efcb-48b8-a204-8695baaf0ee1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbb27479-efcb-48b8-a204-8695baaf0ee1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbb27479-efcb-48b8-a204-8695baaf0ee1">
											<gml:posList>35.67045454471292 139.738848486993 29.695 35.67045034203007 139.73884557573064 29.695 35.670263447495515 139.7389096211752 29.695 35.67026107190919 139.73891477152205 29.695 35.67045454471292 139.738848486993 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e43b2f96-5100-40e1-8483-379057e3ca37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e43b2f96-5100-40e1-8483-379057e3ca37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e43b2f96-5100-40e1-8483-379057e3ca37">
											<gml:posList>35.67025815174086 139.73889214121004 31.848 35.67025148696112 139.73888750963903 31.848 35.670253820627984 139.73889786826493 31.848 35.67026048539865 139.73890248879073 31.848 35.67025815174086 139.73889214121004 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14b91996-5479-4976-9746-27c463cfb475">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14b91996-5479-4976-9746-27c463cfb475">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14b91996-5479-4976-9746-27c463cfb475">
											<gml:posList>35.67026048539865 139.73890248879073 29.695 35.67026467906652 139.73890540005982 29.695 35.6702614318608 139.73889102167587 29.695 35.67025815174086 139.73889214121004 29.695 35.67026048539865 139.73890248879073 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ded8c383-3e19-4739-890a-4f04f1aaa4ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ded8c383-3e19-4739-890a-4f04f1aaa4ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ded8c383-3e19-4739-890a-4f04f1aaa4ac">
											<gml:posList>35.67026048539865 139.73890248879073 29.695 35.67025844883446 139.73890317605637 29.695 35.67026264249365 139.7389060762792 29.695 35.67026467906652 139.73890540005982 29.695 35.67026048539865 139.73890248879073 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff43ed46-727d-457c-96bf-11aa5199b5d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff43ed46-727d-457c-96bf-11aa5199b5d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff43ed46-727d-457c-96bf-11aa5199b5d0">
											<gml:posList>35.67026048539865 139.73890248879073 31.848 35.670253820627984 139.73889786826493 31.848 35.67022184850785 139.7389088306513 31.848 35.670218078185115 139.73891703139938 31.848 35.67026048539865 139.73890248879073 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9d4ee2b-9355-4910-9dbf-73da90ff2ac7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9d4ee2b-9355-4910-9dbf-73da90ff2ac7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9d4ee2b-9355-4910-9dbf-73da90ff2ac7">
											<gml:posList>35.67026107190919 139.73891477152205 29.695 35.670263447495515 139.7389096211752 29.695 35.67026264249365 139.7389060762792 29.695 35.67025844883446 139.73890317605637 29.695 35.67026107190919 139.73891477152205 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-192bf723-1687-4aa6-aa78-62ef9e9f9e5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-192bf723-1687-4aa6-aa78-62ef9e9f9e5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-192bf723-1687-4aa6-aa78-62ef9e9f9e5c">
											<gml:posList>35.67026264249365 139.7389060762792 29.695 35.67026264249365 139.7389060762792 29.398 35.67026467906652 139.73890540005982 29.398 35.67026467906652 139.73890540005982 29.695 35.67026264249365 139.7389060762792 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccdb6b06-9bc8-48ad-8ec6-1be1cfbbc508">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccdb6b06-9bc8-48ad-8ec6-1be1cfbbc508">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccdb6b06-9bc8-48ad-8ec6-1be1cfbbc508">
											<gml:posList>35.67026957313031 139.738744119133 41.536 35.67026957313031 139.738744119133 40.85 35.670307979297185 139.73873093983312 40.85 35.670307979297185 139.73873093983312 41.536 35.67026957313031 139.738744119133 41.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-023ef069-943d-4ddf-a810-c06332664792">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-023ef069-943d-4ddf-a810-c06332664792">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-023ef069-943d-4ddf-a810-c06332664792">
											<gml:posList>35.67022248669493 139.7387572423818 31.848 35.67022248669493 139.7387572423818 37.565 35.67023886923486 139.73875161156752 37.565 35.67023886923486 139.73875161156752 39.541 35.67026661503274 139.73874209011396 39.541 35.67026661503274 139.73874209011396 41.536 35.67030964399791 139.73872732574532 41.536 35.67030964399791 139.73872732574532 39.541 35.670324125161514 139.73872235993753 39.541 35.670324125161514 139.73872235993753 37.565 35.67037097490906 139.73870627653363 37.565 35.67037097490906 139.73870627653363 29.695 35.6704183653385 139.73869001573243 29.695 35.6704183653385 139.73869001573243 20.28 35.67018452207556 139.7387702664869 20.28 35.67018452207556 139.7387702664869 31.848 35.67022248669493 139.7387572423818 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94d6a95d-ff97-4930-9b10-95e5585a130c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94d6a95d-ff97-4930-9b10-95e5585a130c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94d6a95d-ff97-4930-9b10-95e5585a130c">
											<gml:posList>35.67031037662622 139.73873052829327 39.541 35.67031037662622 139.73873052829327 39.333 35.670322244513486 139.73872646031595 39.333 35.670322244513486 139.73872646031595 39.541 35.67031037662622 139.73873052829327 39.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44c4aa4a-bd6c-4701-bb51-60177192cb3d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44c4aa4a-bd6c-4701-bb51-60177192cb3d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44c4aa4a-bd6c-4701-bb51-60177192cb3d">
											<gml:posList>35.67032515626691 139.7387268655915 37.565 35.67032515626691 139.7387268655915 37.078 35.670368320400875 139.7387120568593 37.078 35.670368320400875 139.7387120568593 37.565 35.67032515626691 139.7387268655915 37.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78e6beed-ee7d-4f77-86e7-b286f3a65054">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78e6beed-ee7d-4f77-86e7-b286f3a65054">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78e6beed-ee7d-4f77-86e7-b286f3a65054">
											<gml:posList>35.67037842788937 139.7387389425717 31.848 35.67037842788937 139.7387389425717 31.217 35.67039700021575 139.73873261324445 31.217 35.67039700021575 139.73873261324445 31.848 35.67037842788937 139.7387389425717 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2f6628df-fee2-4724-ac11-902e4b6689f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2f6628df-fee2-4724-ac11-902e4b6689f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2f6628df-fee2-4724-ac11-902e4b6689f6">
											<gml:posList>35.67037696261575 139.7387325153778 31.848 35.67040077954817 139.73872442350506 31.848 35.67040077954817 139.73872442350506 29.398 35.67037696261575 139.7387325153778 29.398 35.67037696261575 139.7387325153778 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e418604b-7fb9-4116-886d-bdce42695e62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e418604b-7fb9-4116-886d-bdce42695e62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e418604b-7fb9-4116-886d-bdce42695e62">
											<gml:posList>35.67037188844606 139.73871028524718 29.695 35.67037188844606 139.73871028524718 29.398 35.67041599876668 139.73869515503887 29.398 35.67041599876668 139.73869515503887 29.695 35.67037188844606 139.73871028524718 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b1c0b2c-45ca-417e-936b-a46b47812fff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b1c0b2c-45ca-417e-936b-a46b47812fff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b1c0b2c-45ca-417e-936b-a46b47812fff">
											<gml:posList>35.67018452207556 139.7387702664869 20.28 35.670218078185115 139.73891703139938 20.28 35.670218078185115 139.73891703139938 31.848 35.67018452207556 139.7387702664869 31.848 35.67018452207556 139.7387702664869 20.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44108680-f1f5-4a4c-93ab-3fb76729b8b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44108680-f1f5-4a4c-93ab-3fb76729b8b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44108680-f1f5-4a4c-93ab-3fb76729b8b8">
											<gml:posList>35.67022184850785 139.7389088306513 31.848 35.67022184850785 139.7389088306513 31.217 35.67019122290608 139.73877488695558 31.217 35.67019122290608 139.73877488695558 31.848 35.67022184850785 139.7389088306513 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e04a1f64-d4ad-4879-ac56-ac7ac475b3c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e04a1f64-d4ad-4879-ac56-ac7ac475b3c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e04a1f64-d4ad-4879-ac56-ac7ac475b3c8">
											<gml:posList>35.67019122290608 139.73877488695558 31.848 35.67019122290608 139.73877488695558 31.217 35.670223951958576 139.73876365851754 31.217 35.670223951958576 139.73876365851754 31.848 35.67019122290608 139.73877488695558 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9b3312a-b213-43df-838b-698f0344206f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9b3312a-b213-43df-838b-698f0344206f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9b3312a-b213-43df-838b-698f0344206f">
											<gml:posList>35.67022719441746 139.73876049546894 37.565 35.67022719441746 139.73876049546894 37.078 35.67023990034784 139.7387561282633 37.078 35.67023990034784 139.7387561282633 37.565 35.67022719441746 139.73876049546894 37.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c7c873f-08d4-4264-80f1-43733b203cba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c7c873f-08d4-4264-80f1-43733b203cba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c7c873f-08d4-4264-80f1-43733b203cba">
											<gml:posList>35.67022248669493 139.7387572423818 37.565 35.67022248669493 139.7387572423818 31.848 35.670223951958576 139.73876365851754 31.848 35.670223951958576 139.73876365851754 31.217 35.67024600316394 139.73886013246775 31.217 35.67024600316394 139.73886013246775 37.565 35.67022248669493 139.7387572423818 37.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37c20214-3471-4a76-aa67-d0cd3e67a5b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37c20214-3471-4a76-aa67-d0cd3e67a5b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37c20214-3471-4a76-aa67-d0cd3e67a5b6">
											<gml:posList>35.670253820627984 139.73889786826493 31.848 35.670253820627984 139.73889786826493 31.217 35.67022184850785 139.7389088306513 31.217 35.67022184850785 139.7389088306513 31.848 35.670253820627984 139.73889786826493 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7241e59d-17ec-457a-9546-edf94fc46b71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7241e59d-17ec-457a-9546-edf94fc46b71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7241e59d-17ec-457a-9546-edf94fc46b71">
											<gml:posList>35.67024864867425 139.73885436321265 37.565 35.67024864867425 139.73885436321265 37.078 35.67022719441746 139.73876049546894 37.078 35.67022719441746 139.73876049546894 37.565 35.67024864867425 139.73885436321265 37.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f11c6b7-643c-4365-8709-bdc62656bff8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f11c6b7-643c-4365-8709-bdc62656bff8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f11c6b7-643c-4365-8709-bdc62656bff8">
											<gml:posList>35.670218078185115 139.73891703139938 31.848 35.670218078185115 139.73891703139938 20.28 35.67025844883446 139.73890317605637 20.28 35.67025844883446 139.73890317605637 29.695 35.67026048539865 139.73890248879073 29.695 35.67026048539865 139.73890248879073 31.848 35.670218078185115 139.73891703139938 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-511c5228-99fb-4f67-aa5a-49c51b7f6a2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-511c5228-99fb-4f67-aa5a-49c51b7f6a2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-511c5228-99fb-4f67-aa5a-49c51b7f6a2d">
											<gml:posList>35.67023886923486 139.73875161156752 39.541 35.67023886923486 139.73875161156752 37.565 35.67023990034784 139.7387561282633 37.565 35.67023990034784 139.7387561282633 37.078 35.67025462531331 139.73882058780825 37.078 35.67025462531331 139.73882058780825 39.541 35.67023886923486 139.73875161156752 39.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b18ee41-026e-449b-b797-6ca1f1a61e61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b18ee41-026e-449b-b797-6ca1f1a61e61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b18ee41-026e-449b-b797-6ca1f1a61e61">
											<gml:posList>35.67025651496963 139.73881647637862 39.541 35.67025651496963 139.73881647637862 39.333 35.670242224152986 139.7387539162741 39.333 35.670242224152986 139.7387539162741 39.541 35.67025651496963 139.73881647637862 39.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38071368-9763-473a-ae56-d9351c49206a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38071368-9763-473a-ae56-d9351c49206a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38071368-9763-473a-ae56-d9351c49206a">
											<gml:posList>35.67025148696112 139.73888750963903 31.848 35.67025148696112 139.73888750963903 31.217 35.670253820627984 139.73889786826493 31.217 35.670253820627984 139.73889786826493 31.848 35.67025148696112 139.73888750963903 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbd24e3c-b8d1-4150-856a-c18a75cc41b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbd24e3c-b8d1-4150-856a-c18a75cc41b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbd24e3c-b8d1-4150-856a-c18a75cc41b7">
											<gml:posList>35.670242224152986 139.7387539162741 39.541 35.670242224152986 139.7387539162741 39.333 35.67026734766933 139.73874530370654 39.333 35.67026734766933 139.73874530370654 39.541 35.670242224152986 139.7387539162741 39.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8db6cd70-19cf-48cc-a2ff-c9634a193778">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8db6cd70-19cf-48cc-a2ff-c9634a193778">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8db6cd70-19cf-48cc-a2ff-c9634a193778">
											<gml:posList>35.67025815174086 139.73889214121004 29.695 35.67025815174086 139.73889214121004 31.848 35.67026048539865 139.73890248879073 31.848 35.67026048539865 139.73890248879073 29.695 35.67025815174086 139.73889214121004 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a1f1febb-1e60-41fd-a716-ae11526c0f79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1f1febb-1e60-41fd-a716-ae11526c0f79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1f1febb-1e60-41fd-a716-ae11526c0f79">
											<gml:posList>35.67025844883446 139.73890317605637 20.28 35.67026107190919 139.73891477152205 20.28 35.67026107190919 139.73891477152205 29.695 35.67025844883446 139.73890317605637 29.695 35.67025844883446 139.73890317605637 20.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77e5bdfa-5069-4b73-9d7a-60b7316dc0f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77e5bdfa-5069-4b73-9d7a-60b7316dc0f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77e5bdfa-5069-4b73-9d7a-60b7316dc0f6">
											<gml:posList>35.670263447495515 139.7389096211752 29.695 35.670263447495515 139.7389096211752 29.398 35.67026264249365 139.7389060762792 29.398 35.67026264249365 139.7389060762792 29.695 35.670263447495515 139.7389096211752 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-522ced6d-305a-4885-a30c-91e3785c4f46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-522ced6d-305a-4885-a30c-91e3785c4f46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-522ced6d-305a-4885-a30c-91e3785c4f46">
											<gml:posList>35.67026467906652 139.73890540005982 29.695 35.67026467906652 139.73890540005982 29.398 35.6702614318608 139.73889102167587 29.398 35.6702614318608 139.73889102167587 29.695 35.67026467906652 139.73890540005982 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a86254f-33ba-4fd7-b5a3-d0a76dcac42a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a86254f-33ba-4fd7-b5a3-d0a76dcac42a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a86254f-33ba-4fd7-b5a3-d0a76dcac42a">
											<gml:posList>35.67026661503274 139.73874209011396 41.536 35.67026661503274 139.73874209011396 39.541 35.67026734766933 139.73874530370654 39.541 35.67026734766933 139.73874530370654 39.333 35.67027861750942 139.7387946229426 39.333 35.67027861750942 139.7387946229426 41.536 35.67026661503274 139.73874209011396 41.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0e8ef3c-1126-4d8d-93ab-0d4daa1d4261">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0e8ef3c-1126-4d8d-93ab-0d4daa1d4261">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0e8ef3c-1126-4d8d-93ab-0d4daa1d4261">
											<gml:posList>35.67028028220339 139.7387909978112 41.536 35.67028028220339 139.7387909978112 40.85 35.67026957313031 139.738744119133 40.85 35.67026957313031 139.738744119133 41.536 35.67028028220339 139.7387909978112 41.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8c1995a-5c30-4911-96f4-92ffbbc904a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8c1995a-5c30-4911-96f4-92ffbbc904a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8c1995a-5c30-4911-96f4-92ffbbc904a7">
											<gml:posList>35.67033654434933 139.73878900942108 39.541 35.67033654434933 139.73878900942108 39.333 35.67025651496963 139.73881647637862 39.333 35.67025651496963 139.73881647637862 39.541 35.67033654434933 139.73878900942108 39.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9c8a724-3ba4-4af6-9036-702f5ad74ccc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9c8a724-3ba4-4af6-9036-702f5ad74ccc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9c8a724-3ba4-4af6-9036-702f5ad74ccc">
											<gml:posList>35.67025462531331 139.73882058780825 37.078 35.67033989026166 139.7387913251889 37.078 35.67033989026166 139.7387913251889 39.541 35.67025462531331 139.73882058780825 39.541 35.67025462531331 139.73882058780825 37.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1fb0565a-82b2-40d0-9496-75b39ab54307">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fb0565a-82b2-40d0-9496-75b39ab54307">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fb0565a-82b2-40d0-9496-75b39ab54307">
											<gml:posList>35.67031868837535 139.73877781853201 41.536 35.67031868837535 139.73877781853201 40.85 35.67028028220339 139.7387909978112 40.85 35.67028028220339 139.7387909978112 41.536 35.67031868837535 139.73877781853201 41.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dae144fc-221f-49fb-9153-53259c8a94fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dae144fc-221f-49fb-9153-53259c8a94fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dae144fc-221f-49fb-9153-53259c8a94fd">
											<gml:posList>35.67027861750942 139.7387946229426 39.333 35.670321646480986 139.73877985859994 39.333 35.670321646480986 139.73877985859994 41.536 35.67027861750942 139.7387946229426 41.536 35.67027861750942 139.7387946229426 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e760a751-ad80-474f-945f-2137b6943b63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e760a751-ad80-474f-945f-2137b6943b63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e760a751-ad80-474f-945f-2137b6943b63">
											<gml:posList>35.670307979297185 139.73873093983312 41.536 35.670307979297185 139.73873093983312 40.85 35.67031868837535 139.73877781853201 40.85 35.67031868837535 139.73877781853201 41.536 35.670307979297185 139.73873093983312 41.536</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f480096-2ebb-4111-bdd9-41c6adf4d52a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f480096-2ebb-4111-bdd9-41c6adf4d52a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f480096-2ebb-4111-bdd9-41c6adf4d52a">
											<gml:posList>35.67031037662622 139.73873052829327 39.541 35.67030964399791 139.73872732574532 39.541 35.67030964399791 139.73872732574532 41.536 35.670321646480986 139.73877985859994 41.536 35.670321646480986 139.73877985859994 39.333 35.67031037662622 139.73873052829327 39.333 35.67031037662622 139.73873052829327 39.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70776fbb-a696-4cb4-a0fd-a862a96cccf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70776fbb-a696-4cb4-a0fd-a862a96cccf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70776fbb-a696-4cb4-a0fd-a862a96cccf1">
											<gml:posList>35.67038976569012 139.73880593581197 37.565 35.67038976569012 139.73880593581197 37.078 35.67024864867425 139.73885436321265 37.078 35.67024864867425 139.73885436321265 37.565 35.67038976569012 139.73880593581197 37.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d75c39d-f01c-4cd4-9aae-09edc06c92e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d75c39d-f01c-4cd4-9aae-09edc06c92e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d75c39d-f01c-4cd4-9aae-09edc06c92e9">
											<gml:posList>35.67024600316394 139.73886013246775 31.217 35.670394482416256 139.73880917785186 31.217 35.670394482416256 139.73880917785186 37.565 35.67024600316394 139.73886013246775 37.565 35.67024600316394 139.73886013246775 31.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47a169c1-b7b7-405b-88e7-b52e88d5e3bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47a169c1-b7b7-405b-88e7-b52e88d5e3bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47a169c1-b7b7-405b-88e7-b52e88d5e3bc">
											<gml:posList>35.670322244513486 139.73872646031595 39.541 35.670322244513486 139.73872646031595 39.333 35.67033654434933 139.73878900942108 39.333 35.67033654434933 139.73878900942108 39.541 35.670322244513486 139.73872646031595 39.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd5108f7-1c18-4933-b9e3-0d39cdc5089f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd5108f7-1c18-4933-b9e3-0d39cdc5089f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd5108f7-1c18-4933-b9e3-0d39cdc5089f">
											<gml:posList>35.67032515626691 139.7387268655915 37.565 35.670324125161514 139.73872235993753 37.565 35.670324125161514 139.73872235993753 39.541 35.67033989026166 139.7387913251889 39.541 35.67033989026166 139.7387913251889 37.078 35.67032515626691 139.7387268655915 37.078 35.67032515626691 139.7387268655915 37.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04e02cb7-f6a5-4c4d-b1d1-26884b15d14b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04e02cb7-f6a5-4c4d-b1d1-26884b15d14b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04e02cb7-f6a5-4c4d-b1d1-26884b15d14b">
											<gml:posList>35.67041916075468 139.73883054537228 31.848 35.67041916075468 139.73883054537228 31.217 35.67025148696112 139.73888750963903 31.217 35.67025148696112 139.73888750963903 31.848 35.67041916075468 139.73883054537228 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c52ddd25-88b7-4994-a100-1c73844044b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c52ddd25-88b7-4994-a100-1c73844044b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c52ddd25-88b7-4994-a100-1c73844044b1">
											<gml:posList>35.67025815174086 139.73889214121004 31.848 35.67025815174086 139.73889214121004 29.695 35.6702614318608 139.73889102167587 29.695 35.6702614318608 139.73889102167587 29.398 35.67042583455015 139.7388351769376 29.398 35.67042583455015 139.7388351769376 31.848 35.67025815174086 139.73889214121004 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-127c4774-6d45-4afa-8b96-5eef4b09693e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-127c4774-6d45-4afa-8b96-5eef4b09693e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-127c4774-6d45-4afa-8b96-5eef4b09693e">
											<gml:posList>35.67045034203007 139.73884557573064 29.695 35.67045034203007 139.73884557573064 29.398 35.670263447495515 139.7389096211752 29.398 35.670263447495515 139.7389096211752 29.695 35.67045034203007 139.73884557573064 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-49f45848-0d42-4e33-af6b-653404bab56b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-49f45848-0d42-4e33-af6b-653404bab56b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-49f45848-0d42-4e33-af6b-653404bab56b">
											<gml:posList>35.67026107190919 139.73891477152205 20.28 35.67045454471292 139.738848486993 20.28 35.67045454471292 139.738848486993 29.695 35.67026107190919 139.73891477152205 29.695 35.67026107190919 139.73891477152205 20.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bca991c1-c3b0-46cb-8807-fd917e46947a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bca991c1-c3b0-46cb-8807-fd917e46947a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bca991c1-c3b0-46cb-8807-fd917e46947a">
											<gml:posList>35.670368320400875 139.7387120568593 37.565 35.670368320400875 139.7387120568593 37.078 35.67038976569012 139.73880593581197 37.078 35.67038976569012 139.73880593581197 37.565 35.670368320400875 139.7387120568593 37.565</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1206d405-ffa2-4ebe-8069-6d45c11adea7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1206d405-ffa2-4ebe-8069-6d45c11adea7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1206d405-ffa2-4ebe-8069-6d45c11adea7">
											<gml:posList>35.67037696261575 139.7387325153778 31.848 35.67037696261575 139.7387325153778 29.398 35.67037188844606 139.73871028524718 29.398 35.67037188844606 139.73871028524718 29.695 35.67037097490906 139.73870627653363 29.695 35.67037097490906 139.73870627653363 37.565 35.670394482416256 139.73880917785186 37.565 35.670394482416256 139.73880917785186 31.217 35.67037842788937 139.7387389425717 31.217 35.67037842788937 139.7387389425717 31.848 35.67037696261575 139.7387325153778 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b34137c7-b724-45e9-b440-bbd88e37410c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b34137c7-b724-45e9-b440-bbd88e37410c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b34137c7-b724-45e9-b440-bbd88e37410c">
											<gml:posList>35.67039700021575 139.73873261324445 31.848 35.67039700021575 139.73873261324445 31.217 35.67041916075468 139.73883054537228 31.217 35.67041916075468 139.73883054537228 31.848 35.67039700021575 139.73873261324445 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ace37413-ca46-4f3f-b098-1682019f15b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ace37413-ca46-4f3f-b098-1682019f15b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ace37413-ca46-4f3f-b098-1682019f15b8">
											<gml:posList>35.67040077954817 139.73872442350506 31.848 35.67042583455015 139.7388351769376 31.848 35.67042583455015 139.7388351769376 29.398 35.67040077954817 139.73872442350506 29.398 35.67040077954817 139.73872442350506 31.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38960678-9c22-4e9a-9362-75f8e0586ef6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38960678-9c22-4e9a-9362-75f8e0586ef6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38960678-9c22-4e9a-9362-75f8e0586ef6">
											<gml:posList>35.67041599876668 139.73869515503887 29.695 35.67041599876668 139.73869515503887 29.398 35.67045034203007 139.73884557573064 29.398 35.67045034203007 139.73884557573064 29.695 35.67041599876668 139.73869515503887 29.695</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87eda565-5ebd-4a00-b242-20dd70c13f6c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87eda565-5ebd-4a00-b242-20dd70c13f6c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87eda565-5ebd-4a00-b242-20dd70c13f6c">
											<gml:posList>35.67045454471292 139.738848486993 20.28 35.6704183653385 139.73869001573243 20.28 35.6704183653385 139.73869001573243 29.695 35.67045454471292 139.738848486993 29.695 35.67045454471292 139.738848486993 20.28</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2227</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">396.082</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>