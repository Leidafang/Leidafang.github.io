<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_481a9069-1f37-4039-9c72-0ec58b9ba99f">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">16.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66908205238322 139.7383120497732 0 35.66907131742162 139.73830112687688 0 35.66904491026106 139.73830502430135 0 35.66902699369418 139.73833133518872 0 35.66898477538217 139.73828819508853 0 35.66893534712218 139.73836060537351 0 35.66909519940531 139.73852422943207 0 35.669186852412516 139.73838869593556 0 35.66909438688861 139.73829391958122 0 35.66908205238322 139.7383120497732 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908205238322 139.7383120497732 16.644 35.66909438688861 139.73829391958122 16.644 35.669186852412516 139.73838869593556 16.644 35.66909519940531 139.73852422943207 16.644 35.66893534712218 139.73836060537351 16.644 35.66898477538217 139.73828819508853 16.644 35.66902699369418 139.73833133518872 16.644 35.66904491026106 139.73830502430135 16.644 35.66907131742162 139.73830112687688 16.644 35.66908205238322 139.7383120497732 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908205238322 139.7383120497732 16.644 35.66907131742162 139.73830112687688 16.644 35.66907131742162 139.73830112687688 33.32 35.66908205238322 139.7383120497732 33.32 35.66908205238322 139.7383120497732 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907131742162 139.73830112687688 16.644 35.66904491026106 139.73830502430135 16.644 35.66904491026106 139.73830502430135 33.32 35.66907131742162 139.73830112687688 33.32 35.66907131742162 139.73830112687688 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66904491026106 139.73830502430135 16.644 35.66902699369418 139.73833133518872 16.644 35.66902699369418 139.73833133518872 33.32 35.66904491026106 139.73830502430135 33.32 35.66904491026106 139.73830502430135 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902699369418 139.73833133518872 16.644 35.66898477538217 139.73828819508853 16.644 35.66898477538217 139.73828819508853 33.32 35.66902699369418 139.73833133518872 33.32 35.66902699369418 139.73833133518872 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66898477538217 139.73828819508853 16.644 35.66893534712218 139.73836060537351 16.644 35.66893534712218 139.73836060537351 33.32 35.66898477538217 139.73828819508853 33.32 35.66898477538217 139.73828819508853 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893534712218 139.73836060537351 16.644 35.66909519940531 139.73852422943207 16.644 35.66909519940531 139.73852422943207 33.32 35.66893534712218 139.73836060537351 33.32 35.66893534712218 139.73836060537351 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909519940531 139.73852422943207 16.644 35.669186852412516 139.73838869593556 16.644 35.669186852412516 139.73838869593556 33.32 35.66909519940531 139.73852422943207 33.32 35.66909519940531 139.73852422943207 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669186852412516 139.73838869593556 16.644 35.66909438688861 139.73829391958122 16.644 35.66909438688861 139.73829391958122 33.32 35.669186852412516 139.73838869593556 33.32 35.669186852412516 139.73838869593556 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66909438688861 139.73829391958122 16.644 35.66908205238322 139.7383120497732 16.644 35.66908205238322 139.7383120497732 33.32 35.66909438688861 139.73829391958122 33.32 35.66909438688861 139.73829391958122 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908205238322 139.7383120497732 33.32 35.66907131742162 139.73830112687688 33.32 35.66904491026106 139.73830502430135 33.32 35.66902699369418 139.73833133518872 33.32 35.66898477538217 139.73828819508853 33.32 35.66893534712218 139.73836060537351 33.32 35.66909519940531 139.73852422943207 33.32 35.669186852412516 139.73838869593556 33.32 35.66909438688861 139.73829391958122 33.32 35.66908205238322 139.7383120497732 33.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0dc929ef-b00d-48cc-9ea2-03c13f94b799"/>
							<gml:surfaceMember xlink:href="#poly-b11d707e-607d-43fb-a258-14a2e4f7d4b2"/>
							<gml:surfaceMember xlink:href="#poly-ad75af3e-ff63-429c-afe5-66ad76f8365e"/>
							<gml:surfaceMember xlink:href="#poly-450c8d86-b50a-4a8c-84fc-b818c939470a"/>
							<gml:surfaceMember xlink:href="#poly-b4da66fb-8b90-4abc-9ac8-328e38ededb6"/>
							<gml:surfaceMember xlink:href="#poly-26165c4c-a3ff-4346-9963-c16db7ef5a44"/>
							<gml:surfaceMember xlink:href="#poly-0e3cf8cf-b567-4198-a7ec-d8d1a1d92a3c"/>
							<gml:surfaceMember xlink:href="#poly-6a16738f-a636-4eda-8932-529e631fd226"/>
							<gml:surfaceMember xlink:href="#poly-ccedbf4b-aeb4-4eed-8e7f-6e7d3b82a376"/>
							<gml:surfaceMember xlink:href="#poly-1a1f9220-77ce-4276-9e8e-283ffe3310a9"/>
							<gml:surfaceMember xlink:href="#poly-63df3090-c036-40ee-8aa4-b4fd33b33d16"/>
							<gml:surfaceMember xlink:href="#poly-c99d7c29-1568-455d-a43b-ef748610189a"/>
							<gml:surfaceMember xlink:href="#poly-372d9049-3642-4636-97a7-12d4b6853380"/>
							<gml:surfaceMember xlink:href="#poly-74f6dca6-ddff-4161-90ad-70aeb24f6fd7"/>
							<gml:surfaceMember xlink:href="#poly-81cfb8ab-a93a-4ffb-a799-423cb965d1da"/>
							<gml:surfaceMember xlink:href="#poly-e96f6de6-0bd3-4bdf-bec9-2ec252737549"/>
							<gml:surfaceMember xlink:href="#poly-5f555f79-0f22-41b7-b5a2-ab13386d4d09"/>
							<gml:surfaceMember xlink:href="#poly-8829bcbd-192c-4a11-9670-3e07a90b304a"/>
							<gml:surfaceMember xlink:href="#poly-16446494-b86f-4160-8dd6-916d4e96e130"/>
							<gml:surfaceMember xlink:href="#poly-ec9cc1de-d371-4d5e-825a-d312f39a1447"/>
							<gml:surfaceMember xlink:href="#poly-768bf9c2-439b-40e7-a313-53d49797ac10"/>
							<gml:surfaceMember xlink:href="#poly-01e67beb-62ee-43cd-8ff6-4f6070d3311d"/>
							<gml:surfaceMember xlink:href="#poly-ac937a30-0aac-4a4e-9715-c06083b449ea"/>
							<gml:surfaceMember xlink:href="#poly-eb5de67f-2c0a-45f0-bb3f-0e5df16c946b"/>
							<gml:surfaceMember xlink:href="#poly-db0e6c7a-a491-4b9b-a939-250aa8626a65"/>
							<gml:surfaceMember xlink:href="#poly-939441f0-6daa-404d-b8a9-57b1020d04c2"/>
							<gml:surfaceMember xlink:href="#poly-e384c684-64fa-4cf1-8661-7a5de6352555"/>
							<gml:surfaceMember xlink:href="#poly-7acbcd3a-f824-4ce4-bfb5-d012cdc040f7"/>
							<gml:surfaceMember xlink:href="#poly-d62778d4-9508-4ccb-a2a2-52bae15ac658"/>
							<gml:surfaceMember xlink:href="#poly-379799de-93ef-4269-b0fd-8fd1ac712d23"/>
							<gml:surfaceMember xlink:href="#poly-799b2182-b702-490e-bdc9-9d628fb34c49"/>
							<gml:surfaceMember xlink:href="#poly-e4d71f9d-26c2-44e1-b18c-2319060f86b3"/>
							<gml:surfaceMember xlink:href="#poly-d1ec0808-e123-48a9-9f8e-74bbc8496d64"/>
							<gml:surfaceMember xlink:href="#poly-97efa421-3389-419b-b482-5c0b783efa34"/>
							<gml:surfaceMember xlink:href="#poly-0f81e10d-d47d-451c-a901-df420c621f96"/>
							<gml:surfaceMember xlink:href="#poly-aff30959-2ed0-4285-9185-513d3a8a68f3"/>
							<gml:surfaceMember xlink:href="#poly-141dda5d-04ec-48b7-87de-793d1f4ae5d4"/>
							<gml:surfaceMember xlink:href="#poly-f8d955e5-a756-49cc-b76e-19e3f4c3966e"/>
							<gml:surfaceMember xlink:href="#poly-512146f5-2ef5-4751-8453-6e5a1f8c80ed"/>
							<gml:surfaceMember xlink:href="#poly-9de40fa5-4387-4bad-b634-fc826924bb1d"/>
							<gml:surfaceMember xlink:href="#poly-e392f7b6-de64-4ee8-a916-2958089b4578"/>
							<gml:surfaceMember xlink:href="#poly-8a3df777-8ffd-4cef-8462-fad33fe2e2d7"/>
							<gml:surfaceMember xlink:href="#poly-4a768554-b818-4525-941b-2bf8c920e0f2"/>
							<gml:surfaceMember xlink:href="#poly-5ed4d352-6f9c-4d4c-b2eb-f511442159c0"/>
							<gml:surfaceMember xlink:href="#poly-e8696773-ce21-428d-aede-e84ae4635ca9"/>
							<gml:surfaceMember xlink:href="#poly-ec3a104a-9775-4394-a55d-a9be4b93b6be"/>
							<gml:surfaceMember xlink:href="#poly-f55e6551-35f0-408b-a34e-6c49b1fecece"/>
							<gml:surfaceMember xlink:href="#poly-f2779497-e902-4f9b-92cb-326b3476e135"/>
							<gml:surfaceMember xlink:href="#poly-688e12eb-8f89-4b6e-98a1-af30605faef1"/>
							<gml:surfaceMember xlink:href="#poly-18501106-f6f5-4f9a-b5a3-031cd87389fd"/>
							<gml:surfaceMember xlink:href="#poly-81ebea4b-43e4-4b66-9781-b4f1fda320a3"/>
							<gml:surfaceMember xlink:href="#poly-72feb813-414b-433d-9961-07f0bd19dddd"/>
							<gml:surfaceMember xlink:href="#poly-60728de5-8878-473d-ab8b-dc4408d26c90"/>
							<gml:surfaceMember xlink:href="#poly-ba9bf1c0-fb01-4389-95d6-f53bdb307e51"/>
							<gml:surfaceMember xlink:href="#poly-d9237c3a-8e06-40d0-82ec-a307278ced16"/>
							<gml:surfaceMember xlink:href="#poly-9c21da8e-54b9-4bc2-b3b4-a23aee894a65"/>
							<gml:surfaceMember xlink:href="#poly-08cd8613-35f4-496f-86c6-5e28738b31ea"/>
							<gml:surfaceMember xlink:href="#poly-3d08a240-5a1d-4468-874d-b51fa51e5f21"/>
							<gml:surfaceMember xlink:href="#poly-13958c26-de94-433f-ad6f-f3138edc54aa"/>
							<gml:surfaceMember xlink:href="#poly-6aa6a887-d8e8-4eb4-9a28-2957d09201ae"/>
							<gml:surfaceMember xlink:href="#poly-3ac7989b-e639-4b95-92b9-d9a180423351"/>
							<gml:surfaceMember xlink:href="#poly-477b7df1-6dca-4034-a961-573c2b55641e"/>
							<gml:surfaceMember xlink:href="#poly-ae213f30-27bd-4e20-bbdb-917be1372522"/>
							<gml:surfaceMember xlink:href="#poly-5dacf6a3-5a92-4603-8c18-7283858de3a4"/>
							<gml:surfaceMember xlink:href="#poly-b8659266-f6ec-45c3-9cb5-c2185c4e03c1"/>
							<gml:surfaceMember xlink:href="#poly-25089f8e-d34f-41bb-8a9e-a61c87c6c203"/>
							<gml:surfaceMember xlink:href="#poly-6499ec8b-5b1f-4e53-9834-b4cb11555d32"/>
							<gml:surfaceMember xlink:href="#poly-84cff96f-1fc3-4e03-9f24-143ef6327562"/>
							<gml:surfaceMember xlink:href="#poly-d22a3cc6-43c5-4e1d-add7-12b02cf4aaa7"/>
							<gml:surfaceMember xlink:href="#poly-7220a16a-0c1c-4fae-8ddf-4d546044fcc8"/>
							<gml:surfaceMember xlink:href="#poly-78180781-c546-4c19-9c9c-d873a80c90e7"/>
							<gml:surfaceMember xlink:href="#poly-75dede53-ffa5-4a76-acfc-8ba292c5385c"/>
							<gml:surfaceMember xlink:href="#poly-5d64c83e-4497-48aa-9fab-37913f41440c"/>
							<gml:surfaceMember xlink:href="#poly-585ce4ca-8680-4f5a-a818-37c2feb41fa2"/>
							<gml:surfaceMember xlink:href="#poly-c383551b-7b5c-466e-b931-37b3a87fbed6"/>
							<gml:surfaceMember xlink:href="#poly-127833ce-51f3-4c59-bf8e-ea627ab9263d"/>
							<gml:surfaceMember xlink:href="#poly-50909344-4afc-4d6f-9d79-863ea50d1141"/>
							<gml:surfaceMember xlink:href="#poly-a867a5c8-cd6f-42f3-8906-bc6629861f19"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_481a9069-1f37-4039-9c72-0ec58b9ba99f_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-553f7d63-dfa7-4ac6-9419-efe6cb19b66a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66910436833304 139.73830944958956 38.173 35.66908493015404 139.7383379273301 38.173 35.669073698969314 139.7383264085296 38.173 35.669080604512054 139.73831628213776 38.173 35.66908566530778 139.73832146779858 38.173 35.669098197942134 139.73830311645077 38.173 35.66910436833304 139.73830944958956 38.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e8edd52-6a1c-449f-8417-b32e086a8e4d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66911403987279 139.73833204946328 41.576 35.66910676518435 139.73834270650732 41.576 35.669097626883485 139.73833333920936 41.576 35.6691049015711 139.7383226821657 41.576 35.66911403987279 139.73833204946328 41.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dda3683-ad0f-4b9e-a414-fb8343501cb6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66905026476045 139.73840830981214 36.084 35.6690507505437 139.73840709416865 36.084 35.66905143475948 139.7384060439814 36.084 35.66905228137032 139.7384051813851 36.084 35.66905325436487 139.73840456165289 36.084 35.669054317696954 139.73840419587347 36.084 35.66905541731035 139.73840411724908 36.084 35.66905649911399 139.73840431479766 36.084 35.66905753605801 139.73840477750522 36.084 35.66905846504633 139.73840550544648 36.084 35.66905924998051 139.73840644343375 36.084 35.66905985478823 139.7384075694176 36.084 35.66906026139851 139.73840882818902 36.084 35.669060442717914 139.73841015350368 36.084 35.669060398711615 139.7384115011772 36.084 35.66906012031365 139.73841280494392 36.084 35.66905963452164 139.73841400954143 36.084 35.669058950305796 139.73841505972877 36.084 35.66905810369487 139.73841592232498 36.084 35.669057130708964 139.73841655310318 36.084 35.669056067368146 139.73841690783638 36.084 35.66905496776346 139.73841699750668 36.084 35.669053885959826 139.73841679995792 36.084 35.66905284900715 139.73841632620415 36.084 35.6690519200276 139.73841560930887 36.084 35.6690511440985 139.73841466026488 36.084 35.669050530277126 139.73841353429177 36.084 35.6690501236756 139.73841228656653 36.084 35.66904994234751 139.73841095020597 36.084 35.66904998636251 139.73840961357868 36.084 35.66905026476045 139.73840830981214 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-141762e6-355c-40bc-a418-cc4d3a55a344">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669089955087436 139.73841194116875 33.761 35.669080574758716 139.73842714063375 33.761 35.669069209151566 139.73841660508148 33.761 35.66907858947898 139.7384014056174 33.761 35.669089955087436 139.73841194116875 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e42ae9d-00b2-4c74-a7c9-a98cac4c2c7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e42ae9d-00b2-4c74-a7c9-a98cac4c2c7f_0">
											<gml:posList>35.66905541731035 139.73840411724908 36.084 35.669054317696954 139.73840419587347 36.084 35.669054317696954 139.73840419587347 40.539 35.66905541731035 139.73840411724908 40.539 35.66905541731035 139.73840411724908 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9378be2d-fec5-4ef0-b3e1-2244122d284e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9378be2d-fec5-4ef0-b3e1-2244122d284e_0">
											<gml:posList>35.66905649911399 139.73840431479766 36.084 35.66905541731035 139.73840411724908 36.084 35.66905541731035 139.73840411724908 40.539 35.66905649911399 139.73840431479766 40.539 35.66905649911399 139.73840431479766 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23a29690-7adf-4bc3-88e9-3db197ac9506">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23a29690-7adf-4bc3-88e9-3db197ac9506_0">
											<gml:posList>35.669054317696954 139.73840419587347 36.084 35.66905325436487 139.73840456165289 36.084 35.66905325436487 139.73840456165289 40.539 35.669054317696954 139.73840419587347 40.539 35.669054317696954 139.73840419587347 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36b43887-930d-42a1-a935-c3f91f1009ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36b43887-930d-42a1-a935-c3f91f1009ca_0">
											<gml:posList>35.66905753605801 139.73840477750522 36.084 35.66905649911399 139.73840431479766 36.084 35.66905649911399 139.73840431479766 40.539 35.66905753605801 139.73840477750522 40.539 35.66905753605801 139.73840477750522 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24b7a346-bb92-4022-b171-8b8626779776">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24b7a346-bb92-4022-b171-8b8626779776_0">
											<gml:posList>35.66905325436487 139.73840456165289 36.084 35.66905228137032 139.7384051813851 36.084 35.66905228137032 139.7384051813851 40.539 35.66905325436487 139.73840456165289 40.539 35.66905325436487 139.73840456165289 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-790ff0e2-c124-4651-b282-adaaae0070d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-790ff0e2-c124-4651-b282-adaaae0070d6_0">
											<gml:posList>35.66905753605801 139.73840477750522 36.084 35.66905753605801 139.73840477750522 40.539 35.66905846504633 139.73840550544648 40.539 35.66905846504633 139.73840550544648 36.084 35.66905753605801 139.73840477750522 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d958f87-05ac-44fa-997e-ee34d0ee61ea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d958f87-05ac-44fa-997e-ee34d0ee61ea_0">
											<gml:posList>35.66905143475948 139.7384060439814 36.084 35.66905143475948 139.7384060439814 40.539 35.66905228137032 139.7384051813851 40.539 35.66905228137032 139.7384051813851 36.084 35.66905143475948 139.7384060439814 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49a47bfb-a309-4875-a91f-4480187989c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49a47bfb-a309-4875-a91f-4480187989c4_0">
											<gml:posList>35.66905924998051 139.73840644343375 36.084 35.66905846504633 139.73840550544648 36.084 35.66905846504633 139.73840550544648 40.539 35.66905924998051 139.73840644343375 40.539 35.66905924998051 139.73840644343375 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9df2ef48-5761-499e-8332-2456050e6a2f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9df2ef48-5761-499e-8332-2456050e6a2f_0">
											<gml:posList>35.6690507505437 139.73840709416865 36.084 35.6690507505437 139.73840709416865 40.539 35.66905143475948 139.7384060439814 40.539 35.66905143475948 139.7384060439814 36.084 35.6690507505437 139.73840709416865 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-119fb063-2b73-4bd4-8b33-155d8d899c85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-119fb063-2b73-4bd4-8b33-155d8d899c85_0">
											<gml:posList>35.66907858947898 139.7384014056174 33.761 35.66907858947898 139.7384014056174 36.261 35.669089955087436 139.73841194116875 36.261 35.669089955087436 139.73841194116875 33.761 35.66907858947898 139.7384014056174 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4921331a-bd0a-4eb9-ac32-bb16bfd8405c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4921331a-bd0a-4eb9-ac32-bb16bfd8405c_0">
											<gml:posList>35.66905924998051 139.73840644343375 36.084 35.66905924998051 139.73840644343375 40.539 35.66905985478823 139.7384075694176 40.539 35.66905985478823 139.7384075694176 36.084 35.66905924998051 139.73840644343375 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a54d453d-b57d-4722-ae1d-7e4b27d523d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a54d453d-b57d-4722-ae1d-7e4b27d523d8_0">
											<gml:posList>35.6690507505437 139.73840709416865 36.084 35.66905026476045 139.73840830981214 36.084 35.66905026476045 139.73840830981214 40.539 35.6690507505437 139.73840709416865 40.539 35.6690507505437 139.73840709416865 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6999f5f-c4cb-4252-9052-ca33ebc3c915">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6999f5f-c4cb-4252-9052-ca33ebc3c915_0">
											<gml:posList>35.66906026139851 139.73840882818902 36.084 35.66905985478823 139.7384075694176 36.084 35.66905985478823 139.7384075694176 40.539 35.66906026139851 139.73840882818902 40.539 35.66906026139851 139.73840882818902 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72531fbe-3ac3-4ae8-8608-681721eac248">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72531fbe-3ac3-4ae8-8608-681721eac248_0">
											<gml:posList>35.66904998636251 139.73840961357868 36.084 35.66904998636251 139.73840961357868 40.539 35.66905026476045 139.73840830981214 40.539 35.66905026476045 139.73840830981214 36.084 35.66904998636251 139.73840961357868 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fba8ab1-8bd0-4958-8a47-202303cdfc76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fba8ab1-8bd0-4958-8a47-202303cdfc76_0">
											<gml:posList>35.66907858947898 139.7384014056174 33.761 35.669069209151566 139.73841660508148 33.761 35.669069209151566 139.73841660508148 36.261 35.66907858947898 139.7384014056174 36.261 35.66907858947898 139.7384014056174 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a82cbd7-7a6a-4d82-b1b5-2c1dc46468be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a82cbd7-7a6a-4d82-b1b5-2c1dc46468be_0">
											<gml:posList>35.66906026139851 139.73840882818902 36.084 35.66906026139851 139.73840882818902 40.539 35.669060442717914 139.73841015350368 40.539 35.669060442717914 139.73841015350368 36.084 35.66906026139851 139.73840882818902 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ab48b3e-07cd-4113-a738-128f4f6d9ba5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ab48b3e-07cd-4113-a738-128f4f6d9ba5_0">
											<gml:posList>35.66904998636251 139.73840961357868 36.084 35.66904994234751 139.73841095020597 36.084 35.66904994234751 139.73841095020597 40.539 35.66904998636251 139.73840961357868 40.539 35.66904998636251 139.73840961357868 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ecdd1a1-6193-4d0d-a877-36bb16959c85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ecdd1a1-6193-4d0d-a877-36bb16959c85_0">
											<gml:posList>35.66904994234751 139.73841095020597 40.539 35.6690501236756 139.73841228656653 40.539 35.669050530277126 139.73841353429177 40.539 35.6690511440985 139.73841466026488 40.539 35.6690519200276 139.73841560930887 40.539 35.66905284900715 139.73841632620415 40.539 35.669053885959826 139.73841679995792 40.539 35.66905496776346 139.73841699750668 40.539 35.669056067368146 139.73841690783638 40.539 35.669057130708964 139.73841655310318 40.539 35.66905810369487 139.73841592232498 40.539 35.669058950305796 139.73841505972877 40.539 35.66905963452164 139.73841400954143 40.539 35.66906012031365 139.73841280494392 40.539 35.669060398711615 139.7384115011772 40.539 35.669060442717914 139.73841015350368 40.539 35.66906026139851 139.73840882818902 40.539 35.66905985478823 139.7384075694176 40.539 35.66905924998051 139.73840644343375 40.539 35.66905846504633 139.73840550544648 40.539 35.66905753605801 139.73840477750522 40.539 35.66905649911399 139.73840431479766 40.539 35.66905541731035 139.73840411724908 40.539 35.669054317696954 139.73840419587347 40.539 35.66905325436487 139.73840456165289 40.539 35.66905228137032 139.7384051813851 40.539 35.66905143475948 139.7384060439814 40.539 35.6690507505437 139.73840709416865 40.539 35.66905026476045 139.73840830981214 40.539 35.66904998636251 139.73840961357868 40.539 35.66904994234751 139.73841095020597 40.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37ff2c37-5e78-4b45-8ab6-97b116456b65">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37ff2c37-5e78-4b45-8ab6-97b116456b65_0">
											<gml:posList>35.669060398711615 139.7384115011772 36.084 35.669060442717914 139.73841015350368 36.084 35.669060442717914 139.73841015350368 40.539 35.669060398711615 139.7384115011772 40.539 35.669060398711615 139.7384115011772 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-869afe4e-3520-4bfb-af73-7632354f8b85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-869afe4e-3520-4bfb-af73-7632354f8b85_0">
											<gml:posList>35.66904994234751 139.73841095020597 36.084 35.6690501236756 139.73841228656653 36.084 35.6690501236756 139.73841228656653 40.539 35.66904994234751 139.73841095020597 40.539 35.66904994234751 139.73841095020597 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dca7399e-10cf-4069-a73d-ca868e21c596">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dca7399e-10cf-4069-a73d-ca868e21c596_0">
											<gml:posList>35.66906012031365 139.73841280494392 36.084 35.669060398711615 139.7384115011772 36.084 35.669060398711615 139.7384115011772 40.539 35.66906012031365 139.73841280494392 40.539 35.66906012031365 139.73841280494392 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15da77f6-acdf-4e5a-9c7c-328b6d09ca72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15da77f6-acdf-4e5a-9c7c-328b6d09ca72_0">
											<gml:posList>35.6690501236756 139.73841228656653 36.084 35.669050530277126 139.73841353429177 36.084 35.669050530277126 139.73841353429177 40.539 35.6690501236756 139.73841228656653 40.539 35.6690501236756 139.73841228656653 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adf5dcec-7ca2-4210-9c60-7487eeee275c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-adf5dcec-7ca2-4210-9c60-7487eeee275c_0">
											<gml:posList>35.66905963452164 139.73841400954143 36.084 35.66906012031365 139.73841280494392 36.084 35.66906012031365 139.73841280494392 40.539 35.66905963452164 139.73841400954143 40.539 35.66905963452164 139.73841400954143 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-56dc6601-0c53-4a74-9b91-c1fe3d05f563">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-56dc6601-0c53-4a74-9b91-c1fe3d05f563_0">
											<gml:posList>35.6690511440985 139.73841466026488 36.084 35.6690511440985 139.73841466026488 40.539 35.669050530277126 139.73841353429177 40.539 35.669050530277126 139.73841353429177 36.084 35.6690511440985 139.73841466026488 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-121ee374-aaf8-4428-ac81-5ee687628663">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-121ee374-aaf8-4428-ac81-5ee687628663_0">
											<gml:posList>35.669069209151566 139.73841660508148 36.261 35.669080574758716 139.73842714063375 36.261 35.669089955087436 139.73841194116875 36.261 35.66907858947898 139.7384014056174 36.261 35.669069209151566 139.73841660508148 36.261</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ae3b3fa-b482-405f-9b73-38ff9842bf3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ae3b3fa-b482-405f-9b73-38ff9842bf3f_0">
											<gml:posList>35.66905963452164 139.73841400954143 36.084 35.66905963452164 139.73841400954143 40.539 35.669058950305796 139.73841505972877 40.539 35.669058950305796 139.73841505972877 36.084 35.66905963452164 139.73841400954143 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b8e4ef7-d17d-400f-86e1-b14a478e8649">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b8e4ef7-d17d-400f-86e1-b14a478e8649_0">
											<gml:posList>35.6690519200276 139.73841560930887 36.084 35.6690519200276 139.73841560930887 40.539 35.6690511440985 139.73841466026488 40.539 35.6690511440985 139.73841466026488 36.084 35.6690519200276 139.73841560930887 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-112ce20e-9c85-41df-b1ba-3ec20c41c161">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-112ce20e-9c85-41df-b1ba-3ec20c41c161_0">
											<gml:posList>35.669058950305796 139.73841505972877 36.084 35.669058950305796 139.73841505972877 40.539 35.66905810369487 139.73841592232498 40.539 35.66905810369487 139.73841592232498 36.084 35.669058950305796 139.73841505972877 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bef2f809-2685-4e8e-abdb-2aa05d3abed9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bef2f809-2685-4e8e-abdb-2aa05d3abed9_0">
											<gml:posList>35.66905284900715 139.73841632620415 36.084 35.66905284900715 139.73841632620415 40.539 35.6690519200276 139.73841560930887 40.539 35.6690519200276 139.73841560930887 36.084 35.66905284900715 139.73841632620415 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-599323a7-d8d7-486b-be6c-ae9a40bccee6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-599323a7-d8d7-486b-be6c-ae9a40bccee6_0">
											<gml:posList>35.669057130708964 139.73841655310318 36.084 35.66905810369487 139.73841592232498 36.084 35.66905810369487 139.73841592232498 40.539 35.669057130708964 139.73841655310318 40.539 35.669057130708964 139.73841655310318 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d15abe77-412c-435f-870a-0be730697dc3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d15abe77-412c-435f-870a-0be730697dc3_0">
											<gml:posList>35.669053885959826 139.73841679995792 36.084 35.669053885959826 139.73841679995792 40.539 35.66905284900715 139.73841632620415 40.539 35.66905284900715 139.73841632620415 36.084 35.669053885959826 139.73841679995792 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59232c3a-b4cf-4f2f-80a0-25e72a504724">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-59232c3a-b4cf-4f2f-80a0-25e72a504724_0">
											<gml:posList>35.669056067368146 139.73841690783638 36.084 35.669057130708964 139.73841655310318 36.084 35.669057130708964 139.73841655310318 40.539 35.669056067368146 139.73841690783638 40.539 35.669056067368146 139.73841690783638 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a39e730-6958-4092-bb6f-cd7e4f8d3095">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a39e730-6958-4092-bb6f-cd7e4f8d3095_0">
											<gml:posList>35.669053885959826 139.73841679995792 36.084 35.66905496776346 139.73841699750668 36.084 35.66905496776346 139.73841699750668 40.539 35.669053885959826 139.73841679995792 40.539 35.669053885959826 139.73841679995792 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e1b12cf-a7ac-4c7d-b93c-5bb33ca95c6f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e1b12cf-a7ac-4c7d-b93c-5bb33ca95c6f_0">
											<gml:posList>35.66905496776346 139.73841699750668 36.084 35.669056067368146 139.73841690783638 36.084 35.669056067368146 139.73841690783638 40.539 35.66905496776346 139.73841699750668 40.539 35.66905496776346 139.73841699750668 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-506640b2-5a13-41b5-8d0e-f5001fb0041e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-506640b2-5a13-41b5-8d0e-f5001fb0041e_0">
											<gml:posList>35.669080574758716 139.73842714063375 33.761 35.669089955087436 139.73841194116875 33.761 35.669089955087436 139.73841194116875 36.261 35.669080574758716 139.73842714063375 36.261 35.669080574758716 139.73842714063375 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07647e70-3f48-4232-b756-b0c5c3ede1ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07647e70-3f48-4232-b756-b0c5c3ede1ec_0">
											<gml:posList>35.669069209151566 139.73841660508148 33.761 35.669080574758716 139.73842714063375 33.761 35.669080574758716 139.73842714063375 36.261 35.669069209151566 139.73841660508148 36.261 35.669069209151566 139.73841660508148 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b87b97b-5a69-4568-8565-0044ddbf2def">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b87b97b-5a69-4568-8565-0044ddbf2def_0">
											<gml:posList>35.66910436833304 139.73830944958956 38.173 35.669098197942134 139.73830311645077 38.173 35.669098197942134 139.73830311645077 40.41 35.66910436833304 139.73830944958956 40.41 35.66910436833304 139.73830944958956 38.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f0c09047-353a-4e90-b525-7a814f62b419">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f0c09047-353a-4e90-b525-7a814f62b419_0">
											<gml:posList>35.66908566530778 139.73832146779858 38.173 35.66908566530778 139.73832146779858 40.41 35.669098197942134 139.73830311645077 40.41 35.669098197942134 139.73830311645077 38.173 35.66908566530778 139.73832146779858 38.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1565d316-2200-4ddb-b98a-ac622a729e60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1565d316-2200-4ddb-b98a-ac622a729e60_0">
											<gml:posList>35.669080604512054 139.73831628213776 38.173 35.669080604512054 139.73831628213776 40.41 35.66908566530778 139.73832146779858 40.41 35.66908566530778 139.73832146779858 38.173 35.669080604512054 139.73831628213776 38.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3bc4592f-23eb-4611-b4e4-7f25fcdd3b99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3bc4592f-23eb-4611-b4e4-7f25fcdd3b99_0">
											<gml:posList>35.66908566530778 139.73832146779858 40.41 35.669080604512054 139.73831628213776 40.41 35.669073698969314 139.7383264085296 40.41 35.66908493015404 139.7383379273301 40.41 35.66910436833304 139.73830944958956 40.41 35.669098197942134 139.73830311645077 40.41 35.66908566530778 139.73832146779858 40.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53ed9d96-0ba0-404d-b850-a83abd1bf68d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53ed9d96-0ba0-404d-b850-a83abd1bf68d_0">
											<gml:posList>35.669080604512054 139.73831628213776 38.173 35.669073698969314 139.7383264085296 38.173 35.669073698969314 139.7383264085296 40.41 35.669080604512054 139.73831628213776 40.41 35.669080604512054 139.73831628213776 38.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60c96f68-3446-4c04-8244-ca98fc6571dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60c96f68-3446-4c04-8244-ca98fc6571dc_0">
											<gml:posList>35.66910436833304 139.73830944958956 40.41 35.66908493015404 139.7383379273301 40.41 35.66908493015404 139.7383379273301 38.173 35.66910436833304 139.73830944958956 38.173 35.66910436833304 139.73830944958956 40.41</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-869f8dec-f187-495a-a2fa-050b3e65f240">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-869f8dec-f187-495a-a2fa-050b3e65f240_0">
											<gml:posList>35.66911403987279 139.73833204946328 41.576 35.6691049015711 139.7383226821657 41.576 35.6691049015711 139.7383226821657 44.12 35.66911403987279 139.73833204946328 44.12 35.66911403987279 139.73833204946328 41.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eff702a-bd7b-4aa0-879d-f9d67d68e67d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7eff702a-bd7b-4aa0-879d-f9d67d68e67d_0">
											<gml:posList>35.6691049015711 139.7383226821657 41.576 35.669097626883485 139.73833333920936 41.576 35.669097626883485 139.73833333920936 44.12 35.6691049015711 139.7383226821657 44.12 35.6691049015711 139.7383226821657 41.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96317531-05da-4bc9-9600-c92eb5f3e24e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96317531-05da-4bc9-9600-c92eb5f3e24e_0">
											<gml:posList>35.66908493015404 139.7383379273301 38.173 35.66908493015404 139.7383379273301 40.41 35.669073698969314 139.7383264085296 40.41 35.669073698969314 139.7383264085296 38.173 35.66908493015404 139.7383379273301 38.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbed5252-65dd-49f7-84f5-27f093d23df0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fbed5252-65dd-49f7-84f5-27f093d23df0_0">
											<gml:posList>35.669097626883485 139.73833333920936 44.12 35.66910676518435 139.73834270650732 44.12 35.66911403987279 139.73833204946328 44.12 35.6691049015711 139.7383226821657 44.12 35.669097626883485 139.73833333920936 44.12</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75da14a9-751b-432f-8d0b-695f7c501603">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75da14a9-751b-432f-8d0b-695f7c501603_0">
											<gml:posList>35.66910676518435 139.73834270650732 41.576 35.66911403987279 139.73833204946328 41.576 35.66911403987279 139.73833204946328 44.12 35.66910676518435 139.73834270650732 44.12 35.66910676518435 139.73834270650732 41.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7bb11e3-b55d-46c0-bfe6-74cc533117d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7bb11e3-b55d-46c0-bfe6-74cc533117d8_0">
											<gml:posList>35.66910676518435 139.73834270650732 41.576 35.66910676518435 139.73834270650732 44.12 35.669097626883485 139.73833333920936 44.12 35.669097626883485 139.73833333920936 41.576 35.66910676518435 139.73834270650732 41.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_481a9069-1f37-4039-9c72-0ec58b9ba99f_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18d0452d-728a-4d36-b84a-07664e5157c8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689884522939 139.73829873972448 33.77 35.66903620048512 139.73834753991687 33.77 35.669028754760944 139.73835848434965 33.77 35.66900688784893 139.73833614195914 33.77 35.6689954716739 139.73835292341667 33.77 35.66896958138028 139.7383264545757 33.77 35.6689884522939 139.73829873972448 33.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73abef3c-a977-4641-b6e9-2b7ac04b6ecb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73abef3c-a977-4641-b6e9-2b7ac04b6ecb_0">
											<gml:posList>35.66896958138028 139.7383264545757 33.77 35.66896958138028 139.7383264545757 36 35.6689884522939 139.73829873972448 36 35.6689884522939 139.73829873972448 33.77 35.66896958138028 139.7383264545757 33.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c4f387d-edd3-4380-b379-0b8f78d25e8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c4f387d-edd3-4380-b379-0b8f78d25e8d_0">
											<gml:posList>35.6689884522939 139.73829873972448 33.77 35.6689884522939 139.73829873972448 36 35.66903620048512 139.73834753991687 36 35.66903620048512 139.73834753991687 33.77 35.6689884522939 139.73829873972448 33.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-32bc7785-7645-4d87-85bf-6b000767a338">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-32bc7785-7645-4d87-85bf-6b000767a338_0">
											<gml:posList>35.6689954716739 139.73835292341667 36 35.66900688784893 139.73833614195914 36 35.669028754760944 139.73835848434965 36 35.66903620048512 139.73834753991687 36 35.6689884522939 139.73829873972448 36 35.66896958138028 139.7383264545757 36 35.6689954716739 139.73835292341667 36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-383d17fd-e16f-4f1a-a8c0-d30304b34187">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-383d17fd-e16f-4f1a-a8c0-d30304b34187_0">
											<gml:posList>35.6689954716739 139.73835292341667 36 35.66896958138028 139.7383264545757 36 35.66896958138028 139.7383264545757 33.77 35.6689954716739 139.73835292341667 33.77 35.6689954716739 139.73835292341667 36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d527db02-19c6-4eea-b3c6-2347057abc1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d527db02-19c6-4eea-b3c6-2347057abc1c_0">
											<gml:posList>35.66900688784893 139.73833614195914 36 35.6689954716739 139.73835292341667 36 35.6689954716739 139.73835292341667 33.77 35.66900688784893 139.73833614195914 33.77 35.66900688784893 139.73833614195914 36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15f4840c-a7b2-4966-96b0-050a049ff1d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15f4840c-a7b2-4966-96b0-050a049ff1d8_0">
											<gml:posList>35.669028754760944 139.73835848434965 33.77 35.669028754760944 139.73835848434965 36 35.66900688784893 139.73833614195914 36 35.66900688784893 139.73833614195914 33.77 35.669028754760944 139.73835848434965 33.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e7af0f5-c145-4eda-b831-1d4a37e22d66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e7af0f5-c145-4eda-b831-1d4a37e22d66_0">
											<gml:posList>35.66903620048512 139.73834753991687 33.77 35.66903620048512 139.73834753991687 36 35.669028754760944 139.73835848434965 36 35.669028754760944 139.73835848434965 33.77 35.66903620048512 139.73834753991687 33.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0dc929ef-b00d-48cc-9ea2-03c13f94b799">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0dc929ef-b00d-48cc-9ea2-03c13f94b799">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0dc929ef-b00d-48cc-9ea2-03c13f94b799">
											<gml:posList>35.669186852412494 139.73838869593556 16.644 35.669095199405305 139.73852422943207 16.644 35.66893534712218 139.73836060537351 16.644 35.66898477538217 139.73828819508853 16.644 35.66902699369417 139.7383313351887 16.644 35.66904491026105 139.73830502430135 16.644 35.66907131742162 139.73830112687688 16.644 35.66908205238324 139.73831204977319 16.644 35.66909438688861 139.7382939195812 16.644 35.669186852412494 139.73838869593556 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b11d707e-607d-43fb-a258-14a2e4f7d4b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b11d707e-607d-43fb-a258-14a2e4f7d4b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b11d707e-607d-43fb-a258-14a2e4f7d4b2">
											<gml:posList>35.66893534712218 139.73836060537351 33.889 35.66893699650304 139.73836043772897 33.889 35.668984939216 139.73829020527853 33.889 35.66898477538217 139.73828819508853 33.889 35.66893534712218 139.73836060537351 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad75af3e-ff63-429c-afe5-66ad76f8365e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad75af3e-ff63-429c-afe5-66ad76f8365e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad75af3e-ff63-429c-afe5-66ad76f8365e">
											<gml:posList>35.66899549021996 139.7384221711979 33.889 35.66899532637092 139.73842013891525 33.889 35.66893699650304 139.73836043772897 33.889 35.66893534712218 139.73836060537351 33.889 35.66899549021996 139.7384221711979 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-450c8d86-b50a-4a8c-84fc-b818c939470a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-450c8d86-b50a-4a8c-84fc-b818c939470a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-450c8d86-b50a-4a8c-84fc-b818c939470a">
											<gml:posList>35.668984939216 139.73829020527853 33.77 35.66893699650304 139.73836043772897 33.77 35.66899532637092 139.73842013891525 33.77 35.66900982053771 139.73839737789905 33.77 35.66901053174233 139.73839626140386 33.77 35.66899971611761 139.73838591299707 33.77 35.669015479653574 139.73836117322324 33.77 35.66902746795307 139.7383726469393 33.77 35.66904248428814 139.7383491010155 33.77 35.66902624641783 139.73833242963528 33.77 35.668984939216 139.73829020527853 33.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4da66fb-8b90-4abc-9ac8-328e38ededb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4da66fb-8b90-4abc-9ac8-328e38ededb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4da66fb-8b90-4abc-9ac8-328e38ededb6">
											<gml:posList>35.66899549021996 139.7384221711979 33.889 35.669011442816476 139.7383971329647 33.889 35.66901053174233 139.73839626140386 33.889 35.66900982053771 139.73839737789905 33.889 35.66899532637092 139.73842013891525 33.889 35.66899549021996 139.7384221711979 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26165c4c-a3ff-4346-9963-c16db7ef5a44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26165c4c-a3ff-4346-9963-c16db7ef5a44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26165c4c-a3ff-4346-9963-c16db7ef5a44">
											<gml:posList>35.66902699369417 139.7383313351887 33.889 35.66898477538217 139.73828819508853 33.889 35.668984939216 139.73829020527853 33.889 35.66902624641783 139.73833242963528 33.889 35.66902699369417 139.7383313351887 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e3cf8cf-b567-4198-a7ec-d8d1a1d92a3c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e3cf8cf-b567-4198-a7ec-d8d1a1d92a3c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e3cf8cf-b567-4198-a7ec-d8d1a1d92a3c">
											<gml:posList>35.66903258696495 139.73841737747472 21.605 35.669011442816476 139.7383971329647 21.605 35.66899549021996 139.7384221711979 21.605 35.6690163197283 139.73844348755176 21.605 35.66903258696495 139.73841737747472 21.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6a16738f-a636-4eda-8932-529e631fd226">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a16738f-a636-4eda-8932-529e631fd226">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a16738f-a636-4eda-8932-529e631fd226">
											<gml:posList>35.66901834759863 139.73844320900014 33.889 35.66903375061477 139.73841849175068 33.889 35.66903258696495 139.73841737747472 33.889 35.6690163197283 139.73844348755176 33.889 35.66901834759863 139.73844320900014 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ccedbf4b-aeb4-4eed-8e7f-6e7d3b82a376">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccedbf4b-aeb4-4eed-8e7f-6e7d3b82a376">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccedbf4b-aeb4-4eed-8e7f-6e7d3b82a376">
											<gml:posList>35.66905278264321 139.7384808132765 33.889 35.669052609389865 139.73847828393 33.889 35.66901834759863 139.73844320900014 33.889 35.6690163197283 139.73844348755176 33.889 35.66905278264321 139.7384808132765 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a1f9220-77ce-4276-9e8e-283ffe3310a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a1f9220-77ce-4276-9e8e-283ffe3310a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a1f9220-77ce-4276-9e8e-283ffe3310a9">
											<gml:posList>35.66902699369417 139.7383313351887 33.889 35.66902624641783 139.73833242963528 33.889 35.66904248428814 139.7383491010155 33.889 35.669044079543056 139.73834887820425 33.889 35.66902699369417 139.7383313351887 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63df3090-c036-40ee-8aa4-b4fd33b33d16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63df3090-c036-40ee-8aa4-b4fd33b33d16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63df3090-c036-40ee-8aa4-b4fd33b33d16">
											<gml:posList>35.66904248428814 139.7383491010155 33.889 35.66902746795307 139.7383726469393 33.889 35.669028379027374 139.73837351850005 33.889 35.669044079543056 139.73834887820425 33.889 35.66904248428814 139.7383491010155 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c99d7c29-1568-455d-a43b-ef748610189a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c99d7c29-1568-455d-a43b-ef748610189a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c99d7c29-1568-455d-a43b-ef748610189a">
											<gml:posList>35.66904491026105 139.73830502430135 38.337 35.66902699369417 139.7383313351887 38.337 35.669028922465564 139.73833112302802 38.337 35.66904562359181 139.73830660304472 38.337 35.66904491026105 139.73830502430135 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-372d9049-3642-4636-97a7-12d4b6853380">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-372d9049-3642-4636-97a7-12d4b6853380">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-372d9049-3642-4636-97a7-12d4b6853380">
											<gml:posList>35.669045084315904 139.7384114198923 36.084 35.6690572981191 139.73842310322866 36.084 35.66907854425355 139.73838977414883 36.084 35.669062505727474 139.73837441700002 36.084 35.66904992910218 139.73839414914013 36.084 35.669015479653574 139.73836117322324 36.084 35.66899971611761 139.73838591299707 36.084 35.66903799026919 139.73842255168734 36.084 35.669045084315904 139.7384114198923 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74f6dca6-ddff-4161-90ad-70aeb24f6fd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74f6dca6-ddff-4161-90ad-70aeb24f6fd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74f6dca6-ddff-4161-90ad-70aeb24f6fd7">
											<gml:posList>35.669044079543056 139.73834887820425 21.605 35.669028379027374 139.73837351850005 21.605 35.66904992910218 139.73839414914013 21.605 35.669062505727474 139.73837441700002 21.605 35.66906517072353 139.7383705256244 21.605 35.669044079543056 139.73834887820425 21.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81cfb8ab-a93a-4ffb-a799-423cb965d1da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81cfb8ab-a93a-4ffb-a799-423cb965d1da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81cfb8ab-a93a-4ffb-a799-423cb965d1da">
											<gml:posList>35.66908868856009 139.73839466659692 38.337 35.66908849738199 139.73839226982366 38.337 35.669028922465564 139.73833112302802 38.337 35.66902699369417 139.7383313351887 38.337 35.66908868856009 139.73839466659692 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e96f6de6-0bd3-4bdf-bec9-2ec252737549">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e96f6de6-0bd3-4bdf-bec9-2ec252737549">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e96f6de6-0bd3-4bdf-bec9-2ec252737549">
											<gml:posList>35.66904491026105 139.73830502430135 38.337 35.66904562359181 139.73830660304472 38.337 35.6690709041764 139.7383028836932 38.337 35.66907131742162 139.73830112687688 38.337 35.66904491026105 139.73830502430135 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f555f79-0f22-41b7-b5a2-ab13386d4d09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f555f79-0f22-41b7-b5a2-ab13386d4d09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f555f79-0f22-41b7-b5a2-ab13386d4d09">
											<gml:posList>35.669100047907094 139.73840869271822 33.761 35.66906534398784 139.73837306601715 33.761 35.66906370545871 139.7383755643713 33.761 35.66907854425355 139.73838977414883 33.761 35.6690572981191 139.73842310322866 33.761 35.669045084315904 139.7384114198923 33.761 35.66903799026919 139.73842255168734 33.761 35.66903375061477 139.73841849175068 33.761 35.66901834759863 139.73844320900014 33.761 35.669052609389865 139.73847828393 33.761 35.669100047907094 139.73840869271822 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8829bcbd-192c-4a11-9670-3e07a90b304a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8829bcbd-192c-4a11-9670-3e07a90b304a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8829bcbd-192c-4a11-9670-3e07a90b304a">
											<gml:posList>35.66908205238324 139.73831204977319 38.337 35.669082234514335 139.73831440237248 38.337 35.66909456000633 139.7382962721915 38.337 35.66909438688861 139.7382939195812 38.337 35.66908205238324 139.73831204977319 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16446494-b86f-4160-8dd6-916d4e96e130">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16446494-b86f-4160-8dd6-916d4e96e130">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16446494-b86f-4160-8dd6-916d4e96e130">
											<gml:posList>35.66908205238324 139.73831204977319 38.337 35.66907131742162 139.73830112687688 38.337 35.6690709041764 139.7383028836932 38.337 35.669082234514335 139.73831440237248 38.337 35.66908205238324 139.73831204977319 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec9cc1de-d371-4d5e-825a-d312f39a1447">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec9cc1de-d371-4d5e-825a-d312f39a1447">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec9cc1de-d371-4d5e-825a-d312f39a1447">
											<gml:posList>35.6691281092328 139.73833068517087 38.337 35.66913001092813 139.73833042885764 38.337 35.66909438688861 139.7382939195812 38.337 35.66909456000633 139.7382962721915 38.337 35.6691281092328 139.73833068517087 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-768bf9c2-439b-40e7-a313-53d49797ac10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-768bf9c2-439b-40e7-a313-53d49797ac10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-768bf9c2-439b-40e7-a313-53d49797ac10">
											<gml:posList>35.66909456000633 139.7382962721915 38.173 35.66910590059639 139.73830935940498 38.173 35.66912466433437 139.73832859049614 38.173 35.66909456000633 139.7382962721915 38.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01e67beb-62ee-43cd-8ff6-4f6070d3311d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01e67beb-62ee-43cd-8ff6-4f6070d3311d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01e67beb-62ee-43cd-8ff6-4f6070d3311d">
											<gml:posList>35.66909456000633 139.7382962721915 38.173 35.66912466433437 139.73832859049614 38.173 35.6691281092328 139.73833068517087 38.173 35.66909456000633 139.7382962721915 38.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ac937a30-0aac-4a4e-9715-c06083b449ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac937a30-0aac-4a4e-9715-c06083b449ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac937a30-0aac-4a4e-9715-c06083b449ea">
											<gml:posList>35.66912466433437 139.73832859049614 41.576 35.66910590059639 139.73830935940498 41.576 35.66908138455021 139.73834528822024 41.576 35.669100148282524 139.73836451931396 41.576 35.66912466433437 139.73832859049614 41.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eb5de67f-2c0a-45f0-bb3f-0e5df16c946b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb5de67f-2c0a-45f0-bb3f-0e5df16c946b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb5de67f-2c0a-45f0-bb3f-0e5df16c946b">
											<gml:posList>35.66908849738199 139.73839226982366 38.173 35.6691281092328 139.73833068517087 38.173 35.66912466433437 139.73832859049614 38.173 35.669100148282524 139.73836451931396 38.173 35.66908138455021 139.73834528822024 38.173 35.66910590059639 139.73830935940498 38.173 35.66909456000633 139.7382962721915 38.173 35.669082234514335 139.73831440237248 38.173 35.6690709041764 139.7383028836932 38.173 35.66904562359181 139.73830660304472 38.173 35.669028922465564 139.73833112302802 38.173 35.66908849738199 139.73839226982366 38.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db0e6c7a-a491-4b9b-a939-250aa8626a65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db0e6c7a-a491-4b9b-a939-250aa8626a65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db0e6c7a-a491-4b9b-a939-250aa8626a65">
											<gml:posList>35.669186852412494 139.73838869593556 26.447 35.66913001092813 139.73833042885764 38.337 35.66908868856009 139.73839466659692 38.337 35.669186852412494 139.73838869593556 26.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-939441f0-6daa-404d-b8a9-57b1020d04c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-939441f0-6daa-404d-b8a9-57b1020d04c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-939441f0-6daa-404d-b8a9-57b1020d04c2">
											<gml:posList>35.66908868856009 139.73839466659692 38.337 35.66913001092813 139.73833042885764 38.337 35.6691281092328 139.73833068517087 38.337 35.66908849738199 139.73839226982366 38.337 35.66908868856009 139.73839466659692 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e384c684-64fa-4cf1-8661-7a5de6352555">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e384c684-64fa-4cf1-8661-7a5de6352555">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e384c684-64fa-4cf1-8661-7a5de6352555">
											<gml:posList>35.66906534398784 139.73837306601715 33.889 35.66906517072353 139.7383705256244 33.889 35.669062505727474 139.73837441700002 33.889 35.66906370545871 139.7383755643713 33.889 35.66906534398784 139.73837306601715 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7acbcd3a-f824-4ce4-bfb5-d012cdc040f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7acbcd3a-f824-4ce4-bfb5-d012cdc040f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7acbcd3a-f824-4ce4-bfb5-d012cdc040f7">
											<gml:posList>35.669100047907094 139.73840869271822 33.889 35.66910211185834 139.73840844726095 33.889 35.66908868856009 139.73839466659692 33.889 35.66906517072353 139.7383705256244 33.889 35.66906534398784 139.73837306601715 33.889 35.669100047907094 139.73840869271822 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d62778d4-9508-4ccb-a2a2-52bae15ac658">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d62778d4-9508-4ccb-a2a2-52bae15ac658">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d62778d4-9508-4ccb-a2a2-52bae15ac658">
											<gml:posList>35.66914435735058 139.73845181942318 26.447 35.669186852412494 139.73838869593556 26.447 35.66908868856009 139.73839466659692 38.337 35.66914435735058 139.73845181942318 26.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-379799de-93ef-4269-b0fd-8fd1ac712d23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-379799de-93ef-4269-b0fd-8fd1ac712d23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-379799de-93ef-4269-b0fd-8fd1ac712d23">
											<gml:posList>35.66910211185834 139.73840844726095 33.889 35.669100047907094 139.73840869271822 33.889 35.669052609389865 139.73847828393 33.889 35.66905278264321 139.7384808132765 33.889 35.66910211185834 139.73840844726095 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-799b2182-b702-490e-bdc9-9d628fb34c49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-799b2182-b702-490e-bdc9-9d628fb34c49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-799b2182-b702-490e-bdc9-9d628fb34c49">
											<gml:posList>35.669095199405305 139.73852422943207 25.876 35.66914435735058 139.73845181942318 25.876 35.66910211185834 139.73840844726095 33.889 35.66905278264321 139.7384808132765 33.889 35.669095199405305 139.73852422943207 25.876</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4d71f9d-26c2-44e1-b18c-2319060f86b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4d71f9d-26c2-44e1-b18c-2319060f86b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4d71f9d-26c2-44e1-b18c-2319060f86b3">
											<gml:posList>35.66906370545871 139.7383755643713 33.889 35.669062505727474 139.73837441700002 33.889 35.669062505727474 139.73837441700002 36.084 35.66907854425355 139.73838977414883 36.084 35.66907854425355 139.73838977414883 33.761 35.66906370545871 139.7383755643713 33.761 35.66906370545871 139.7383755643713 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1ec0808-e123-48a9-9f8e-74bbc8496d64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1ec0808-e123-48a9-9f8e-74bbc8496d64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1ec0808-e123-48a9-9f8e-74bbc8496d64">
											<gml:posList>35.66906534398784 139.73837306601715 33.889 35.66906534398784 139.73837306601715 33.761 35.669100047907094 139.73840869271822 33.761 35.669100047907094 139.73840869271822 33.889 35.66906534398784 139.73837306601715 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97efa421-3389-419b-b482-5c0b783efa34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97efa421-3389-419b-b482-5c0b783efa34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97efa421-3389-419b-b482-5c0b783efa34">
											<gml:posList>35.66901053174233 139.73839626140386 33.889 35.66901053174233 139.73839626140386 33.77 35.66900982053771 139.73839737789905 33.77 35.66900982053771 139.73839737789905 33.889 35.66901053174233 139.73839626140386 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f81e10d-d47d-451c-a901-df420c621f96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f81e10d-d47d-451c-a901-df420c621f96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f81e10d-d47d-451c-a901-df420c621f96">
											<gml:posList>35.66909438688861 139.7382939195812 16.644 35.66908205238324 139.73831204977319 16.644 35.66908205238324 139.73831204977319 38.337 35.66909438688861 139.7382939195812 38.337 35.66909438688861 139.7382939195812 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aff30959-2ed0-4285-9185-513d3a8a68f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aff30959-2ed0-4285-9185-513d3a8a68f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aff30959-2ed0-4285-9185-513d3a8a68f3">
											<gml:posList>35.66907131742162 139.73830112687688 16.644 35.66904491026105 139.73830502430135 16.644 35.66904491026105 139.73830502430135 38.337 35.66907131742162 139.73830112687688 38.337 35.66907131742162 139.73830112687688 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-141dda5d-04ec-48b7-87de-793d1f4ae5d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-141dda5d-04ec-48b7-87de-793d1f4ae5d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-141dda5d-04ec-48b7-87de-793d1f4ae5d4">
											<gml:posList>35.66904562359181 139.73830660304472 38.337 35.66904562359181 139.73830660304472 38.173 35.6690709041764 139.7383028836932 38.173 35.6690709041764 139.7383028836932 38.337 35.66904562359181 139.73830660304472 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8d955e5-a756-49cc-b76e-19e3f4c3966e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8d955e5-a756-49cc-b76e-19e3f4c3966e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8d955e5-a756-49cc-b76e-19e3f4c3966e">
											<gml:posList>35.669082234514335 139.73831440237248 38.337 35.669082234514335 139.73831440237248 38.173 35.66909456000633 139.7382962721915 38.173 35.66909456000633 139.7382962721915 38.337 35.669082234514335 139.73831440237248 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-512146f5-2ef5-4751-8453-6e5a1f8c80ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-512146f5-2ef5-4751-8453-6e5a1f8c80ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-512146f5-2ef5-4751-8453-6e5a1f8c80ed">
											<gml:posList>35.66908205238324 139.73831204977319 16.644 35.66907131742162 139.73830112687688 16.644 35.66907131742162 139.73830112687688 38.337 35.66908205238324 139.73831204977319 38.337 35.66908205238324 139.73831204977319 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9de40fa5-4387-4bad-b634-fc826924bb1d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9de40fa5-4387-4bad-b634-fc826924bb1d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9de40fa5-4387-4bad-b634-fc826924bb1d">
											<gml:posList>35.6690709041764 139.7383028836932 38.337 35.6690709041764 139.7383028836932 38.173 35.669082234514335 139.73831440237248 38.173 35.669082234514335 139.73831440237248 38.337 35.6690709041764 139.7383028836932 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e392f7b6-de64-4ee8-a916-2958089b4578">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e392f7b6-de64-4ee8-a916-2958089b4578">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e392f7b6-de64-4ee8-a916-2958089b4578">
											<gml:posList>35.66902699369417 139.7383313351887 16.644 35.66898477538217 139.73828819508853 16.644 35.66898477538217 139.73828819508853 33.889 35.66902699369417 139.7383313351887 33.889 35.66902699369417 139.7383313351887 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a3df777-8ffd-4cef-8462-fad33fe2e2d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a3df777-8ffd-4cef-8462-fad33fe2e2d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a3df777-8ffd-4cef-8462-fad33fe2e2d7">
											<gml:posList>35.668984939216 139.73829020527853 33.889 35.668984939216 139.73829020527853 33.77 35.66902624641783 139.73833242963528 33.77 35.66902624641783 139.73833242963528 33.889 35.668984939216 139.73829020527853 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a768554-b818-4525-941b-2bf8c920e0f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a768554-b818-4525-941b-2bf8c920e0f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a768554-b818-4525-941b-2bf8c920e0f2">
											<gml:posList>35.6691281092328 139.73833068517087 38.337 35.66909456000633 139.7382962721915 38.173 35.6691281092328 139.73833068517087 38.173 35.6691281092328 139.73833068517087 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ed4d352-6f9c-4d4c-b2eb-f511442159c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ed4d352-6f9c-4d4c-b2eb-f511442159c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ed4d352-6f9c-4d4c-b2eb-f511442159c0">
											<gml:posList>35.6691281092328 139.73833068517087 38.337 35.66909456000633 139.7382962721915 38.337 35.66909456000633 139.7382962721915 38.173 35.6691281092328 139.73833068517087 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8696773-ce21-428d-aede-e84ae4635ca9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8696773-ce21-428d-aede-e84ae4635ca9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8696773-ce21-428d-aede-e84ae4635ca9">
											<gml:posList>35.66904491026105 139.73830502430135 38.337 35.66904491026105 139.73830502430135 16.644 35.66902699369417 139.7383313351887 16.644 35.66902699369417 139.7383313351887 33.889 35.66902699369417 139.7383313351887 38.337 35.66904491026105 139.73830502430135 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec3a104a-9775-4394-a55d-a9be4b93b6be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec3a104a-9775-4394-a55d-a9be4b93b6be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec3a104a-9775-4394-a55d-a9be4b93b6be">
											<gml:posList>35.669028922465564 139.73833112302802 38.337 35.669028922465564 139.73833112302802 38.173 35.66904562359181 139.73830660304472 38.173 35.66904562359181 139.73830660304472 38.337 35.669028922465564 139.73833112302802 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f55e6551-35f0-408b-a34e-6c49b1fecece">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f55e6551-35f0-408b-a34e-6c49b1fecece">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f55e6551-35f0-408b-a34e-6c49b1fecece">
											<gml:posList>35.66910590059639 139.73830935940498 41.576 35.66912466433437 139.73832859049614 41.576 35.66912466433437 139.73832859049614 38.173 35.66910590059639 139.73830935940498 38.173 35.66910590059639 139.73830935940498 41.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2779497-e902-4f9b-92cb-326b3476e135">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2779497-e902-4f9b-92cb-326b3476e135">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2779497-e902-4f9b-92cb-326b3476e135">
											<gml:posList>35.66898477538217 139.73828819508853 16.644 35.66893534712218 139.73836060537351 16.644 35.66893534712218 139.73836060537351 33.889 35.66898477538217 139.73828819508853 33.889 35.66898477538217 139.73828819508853 16.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-688e12eb-8f89-4b6e-98a1-af30605faef1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-688e12eb-8f89-4b6e-98a1-af30605faef1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-688e12eb-8f89-4b6e-98a1-af30605faef1">
											<gml:posList>35.66893699650304 139.73836043772897 33.889 35.66893699650304 139.73836043772897 33.77 35.668984939216 139.73829020527853 33.77 35.668984939216 139.73829020527853 33.889 35.66893699650304 139.73836043772897 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18501106-f6f5-4f9a-b5a3-031cd87389fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18501106-f6f5-4f9a-b5a3-031cd87389fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18501106-f6f5-4f9a-b5a3-031cd87389fd">
											<gml:posList>35.66908138455021 139.73834528822024 41.576 35.66910590059639 139.73830935940498 41.576 35.66910590059639 139.73830935940498 38.173 35.66908138455021 139.73834528822024 38.173 35.66908138455021 139.73834528822024 41.576</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81ebea4b-43e4-4b66-9781-b4f1fda320a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81ebea4b-43e4-4b66-9781-b4f1fda320a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81ebea4b-43e4-4b66-9781-b4f1fda320a3">
											<gml:posList>35.66902624641783 139.73833242963528 33.889 35.66902624641783 139.73833242963528 33.77 35.66904248428814 139.7383491010155 33.77 35.66904248428814 139.7383491010155 33.889 35.66902624641783 139.73833242963528 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72feb813-414b-433d-9961-07f0bd19dddd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72feb813-414b-433d-9961-07f0bd19dddd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72feb813-414b-433d-9961-07f0bd19dddd">
											<gml:posList>35.66909438688861 139.7382939195812 38.337 35.66913001092813 139.73833042885764 38.337 35.669186852412494 139.73838869593556 26.447 35.669186852412494 139.73838869593556 16.644 35.66909438688861 139.7382939195812 16.644 35.66909438688861 139.7382939195812 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60728de5-8878-473d-ab8b-dc4408d26c90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60728de5-8878-473d-ab8b-dc4408d26c90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60728de5-8878-473d-ab8b-dc4408d26c90">
											<gml:posList>35.669100148282524 139.73836451931396 38.173 35.66912466433437 139.73832859049614 38.173 35.66912466433437 139.73832859049614 41.576 35.669100148282524 139.73836451931396 41.576 35.669100148282524 139.73836451931396 38.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ba9bf1c0-fb01-4389-95d6-f53bdb307e51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba9bf1c0-fb01-4389-95d6-f53bdb307e51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba9bf1c0-fb01-4389-95d6-f53bdb307e51">
											<gml:posList>35.66908138455021 139.73834528822024 38.173 35.669100148282524 139.73836451931396 38.173 35.669100148282524 139.73836451931396 41.576 35.66908138455021 139.73834528822024 41.576 35.66908138455021 139.73834528822024 38.173</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d9237c3a-8e06-40d0-82ec-a307278ced16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9237c3a-8e06-40d0-82ec-a307278ced16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9237c3a-8e06-40d0-82ec-a307278ced16">
											<gml:posList>35.66904248428814 139.7383491010155 33.889 35.66904248428814 139.7383491010155 33.77 35.66902746795307 139.7383726469393 33.77 35.66902746795307 139.7383726469393 33.889 35.66904248428814 139.7383491010155 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9c21da8e-54b9-4bc2-b3b4-a23aee894a65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c21da8e-54b9-4bc2-b3b4-a23aee894a65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c21da8e-54b9-4bc2-b3b4-a23aee894a65">
											<gml:posList>35.669044079543056 139.73834887820425 21.605 35.669044079543056 139.73834887820425 33.889 35.669028379027374 139.73837351850005 33.889 35.669028379027374 139.73837351850005 21.605 35.669044079543056 139.73834887820425 21.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08cd8613-35f4-496f-86c6-5e28738b31ea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08cd8613-35f4-496f-86c6-5e28738b31ea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08cd8613-35f4-496f-86c6-5e28738b31ea">
											<gml:posList>35.6691281092328 139.73833068517087 38.337 35.6691281092328 139.73833068517087 38.173 35.66908849738199 139.73839226982366 38.173 35.66908849738199 139.73839226982366 38.337 35.6691281092328 139.73833068517087 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d08a240-5a1d-4468-874d-b51fa51e5f21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d08a240-5a1d-4468-874d-b51fa51e5f21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d08a240-5a1d-4468-874d-b51fa51e5f21">
											<gml:posList>35.66908849738199 139.73839226982366 38.337 35.66908849738199 139.73839226982366 38.173 35.669028922465564 139.73833112302802 38.173 35.669028922465564 139.73833112302802 38.337 35.66908849738199 139.73839226982366 38.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13958c26-de94-433f-ad6f-f3138edc54aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13958c26-de94-433f-ad6f-f3138edc54aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13958c26-de94-433f-ad6f-f3138edc54aa">
											<gml:posList>35.669044079543056 139.73834887820425 33.889 35.669044079543056 139.73834887820425 21.605 35.66906517072353 139.7383705256244 21.605 35.66906517072353 139.7383705256244 33.889 35.66908868856009 139.73839466659692 33.889 35.66908868856009 139.73839466659692 38.337 35.66902699369417 139.7383313351887 38.337 35.66902699369417 139.7383313351887 33.889 35.669044079543056 139.73834887820425 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6aa6a887-d8e8-4eb4-9a28-2957d09201ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6aa6a887-d8e8-4eb4-9a28-2957d09201ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6aa6a887-d8e8-4eb4-9a28-2957d09201ae">
											<gml:posList>35.669062505727474 139.73837441700002 21.605 35.669062505727474 139.73837441700002 33.889 35.66906517072353 139.7383705256244 33.889 35.66906517072353 139.7383705256244 21.605 35.669062505727474 139.73837441700002 21.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3ac7989b-e639-4b95-92b9-d9a180423351">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3ac7989b-e639-4b95-92b9-d9a180423351">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3ac7989b-e639-4b95-92b9-d9a180423351">
											<gml:posList>35.66899971611761 139.73838591299707 36.084 35.669015479653574 139.73836117322324 36.084 35.669015479653574 139.73836117322324 33.77 35.66899971611761 139.73838591299707 33.77 35.66899971611761 139.73838591299707 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-477b7df1-6dca-4034-a961-573c2b55641e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-477b7df1-6dca-4034-a961-573c2b55641e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-477b7df1-6dca-4034-a961-573c2b55641e">
											<gml:posList>35.66906370545871 139.7383755643713 33.889 35.66906370545871 139.7383755643713 33.761 35.66906534398784 139.73837306601715 33.761 35.66906534398784 139.73837306601715 33.889 35.66906370545871 139.7383755643713 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ae213f30-27bd-4e20-bbdb-917be1372522">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ae213f30-27bd-4e20-bbdb-917be1372522">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ae213f30-27bd-4e20-bbdb-917be1372522">
											<gml:posList>35.66904992910218 139.73839414914013 36.084 35.66904992910218 139.73839414914013 21.605 35.669028379027374 139.73837351850005 21.605 35.669028379027374 139.73837351850005 33.889 35.66902746795307 139.7383726469393 33.889 35.66902746795307 139.7383726469393 33.77 35.669015479653574 139.73836117322324 33.77 35.669015479653574 139.73836117322324 36.084 35.66904992910218 139.73839414914013 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5dacf6a3-5a92-4603-8c18-7283858de3a4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dacf6a3-5a92-4603-8c18-7283858de3a4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dacf6a3-5a92-4603-8c18-7283858de3a4">
											<gml:posList>35.66904992910218 139.73839414914013 36.084 35.669062505727474 139.73837441700002 36.084 35.669062505727474 139.73837441700002 33.889 35.669062505727474 139.73837441700002 21.605 35.66904992910218 139.73839414914013 21.605 35.66904992910218 139.73839414914013 36.084</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8659266-f6ec-45c3-9cb5-c2185c4e03c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8659266-f6ec-45c3-9cb5-c2185c4e03c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8659266-f6ec-45c3-9cb5-c2185c4e03c1">
											<gml:posList>35.66899532637092 139.73842013891525 33.889 35.66899532637092 139.73842013891525 33.77 35.66893699650304 139.73836043772897 33.77 35.66893699650304 139.73836043772897 33.889 35.66899532637092 139.73842013891525 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25089f8e-d34f-41bb-8a9e-a61c87c6c203">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25089f8e-d34f-41bb-8a9e-a61c87c6c203">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25089f8e-d34f-41bb-8a9e-a61c87c6c203">
											<gml:posList>35.669011442816476 139.7383971329647 33.889 35.669011442816476 139.7383971329647 21.605 35.66903258696495 139.73841737747472 21.605 35.66903258696495 139.73841737747472 33.889 35.66903375061477 139.73841849175068 33.889 35.66903375061477 139.73841849175068 33.761 35.66903799026919 139.73842255168734 33.761 35.66903799026919 139.73842255168734 36.084 35.66899971611761 139.73838591299707 36.084 35.66899971611761 139.73838591299707 33.77 35.66901053174233 139.73839626140386 33.77 35.66901053174233 139.73839626140386 33.889 35.669011442816476 139.7383971329647 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6499ec8b-5b1f-4e53-9834-b4cb11555d32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6499ec8b-5b1f-4e53-9834-b4cb11555d32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6499ec8b-5b1f-4e53-9834-b4cb11555d32">
											<gml:posList>35.6690572981191 139.73842310322866 33.761 35.66907854425355 139.73838977414883 33.761 35.66907854425355 139.73838977414883 36.084 35.6690572981191 139.73842310322866 36.084 35.6690572981191 139.73842310322866 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-84cff96f-1fc3-4e03-9f24-143ef6327562">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-84cff96f-1fc3-4e03-9f24-143ef6327562">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-84cff96f-1fc3-4e03-9f24-143ef6327562">
											<gml:posList>35.66900982053771 139.73839737789905 33.889 35.66900982053771 139.73839737789905 33.77 35.66899532637092 139.73842013891525 33.77 35.66899532637092 139.73842013891525 33.889 35.66900982053771 139.73839737789905 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d22a3cc6-43c5-4e1d-add7-12b02cf4aaa7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d22a3cc6-43c5-4e1d-add7-12b02cf4aaa7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d22a3cc6-43c5-4e1d-add7-12b02cf4aaa7">
											<gml:posList>35.669011442816476 139.7383971329647 21.605 35.669011442816476 139.7383971329647 33.889 35.66899549021996 139.7384221711979 33.889 35.66899549021996 139.7384221711979 21.605 35.669011442816476 139.7383971329647 21.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7220a16a-0c1c-4fae-8ddf-4d546044fcc8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7220a16a-0c1c-4fae-8ddf-4d546044fcc8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7220a16a-0c1c-4fae-8ddf-4d546044fcc8">
											<gml:posList>35.66903799026919 139.73842255168734 33.761 35.669045084315904 139.7384114198923 33.761 35.669045084315904 139.7384114198923 36.084 35.66903799026919 139.73842255168734 36.084 35.66903799026919 139.73842255168734 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78180781-c546-4c19-9c9c-d873a80c90e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78180781-c546-4c19-9c9c-d873a80c90e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78180781-c546-4c19-9c9c-d873a80c90e7">
											<gml:posList>35.669045084315904 139.7384114198923 33.761 35.6690572981191 139.73842310322866 33.761 35.6690572981191 139.73842310322866 36.084 35.669045084315904 139.7384114198923 36.084 35.669045084315904 139.7384114198923 33.761</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-75dede53-ffa5-4a76-acfc-8ba292c5385c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75dede53-ffa5-4a76-acfc-8ba292c5385c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75dede53-ffa5-4a76-acfc-8ba292c5385c">
											<gml:posList>35.66910211185834 139.73840844726095 33.889 35.66914435735058 139.73845181942318 25.876 35.66914435735058 139.73845181942318 26.447 35.66908868856009 139.73839466659692 38.337 35.66908868856009 139.73839466659692 33.889 35.66910211185834 139.73840844726095 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d64c83e-4497-48aa-9fab-37913f41440c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d64c83e-4497-48aa-9fab-37913f41440c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d64c83e-4497-48aa-9fab-37913f41440c">
											<gml:posList>35.6690163197283 139.73844348755176 21.605 35.6690163197283 139.73844348755176 33.889 35.66903258696495 139.73841737747472 33.889 35.66903258696495 139.73841737747472 21.605 35.6690163197283 139.73844348755176 21.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-585ce4ca-8680-4f5a-a818-37c2feb41fa2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-585ce4ca-8680-4f5a-a818-37c2feb41fa2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-585ce4ca-8680-4f5a-a818-37c2feb41fa2">
											<gml:posList>35.66901834759863 139.73844320900014 33.889 35.66901834759863 139.73844320900014 33.761 35.66903375061477 139.73841849175068 33.761 35.66903375061477 139.73841849175068 33.889 35.66901834759863 139.73844320900014 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c383551b-7b5c-466e-b931-37b3a87fbed6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c383551b-7b5c-466e-b931-37b3a87fbed6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c383551b-7b5c-466e-b931-37b3a87fbed6">
											<gml:posList>35.66899549021996 139.7384221711979 21.605 35.66899549021996 139.7384221711979 33.889 35.66893534712218 139.73836060537351 33.889 35.66893534712218 139.73836060537351 16.644 35.669095199405305 139.73852422943207 16.644 35.669095199405305 139.73852422943207 25.876 35.66905278264321 139.7384808132765 33.889 35.6690163197283 139.73844348755176 33.889 35.6690163197283 139.73844348755176 21.605 35.66899549021996 139.7384221711979 21.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-127833ce-51f3-4c59-bf8e-ea627ab9263d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-127833ce-51f3-4c59-bf8e-ea627ab9263d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-127833ce-51f3-4c59-bf8e-ea627ab9263d">
											<gml:posList>35.669100047907094 139.73840869271822 33.889 35.669100047907094 139.73840869271822 33.761 35.669052609389865 139.73847828393 33.761 35.669052609389865 139.73847828393 33.889 35.669100047907094 139.73840869271822 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50909344-4afc-4d6f-9d79-863ea50d1141">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50909344-4afc-4d6f-9d79-863ea50d1141">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50909344-4afc-4d6f-9d79-863ea50d1141">
											<gml:posList>35.669186852412494 139.73838869593556 26.447 35.66914435735058 139.73845181942318 26.447 35.66914435735058 139.73845181942318 25.876 35.669095199405305 139.73852422943207 25.876 35.669095199405305 139.73852422943207 16.644 35.669186852412494 139.73838869593556 16.644 35.669186852412494 139.73838869593556 26.447</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a867a5c8-cd6f-42f3-8906-bc6629861f19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a867a5c8-cd6f-42f3-8906-bc6629861f19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a867a5c8-cd6f-42f3-8906-bc6629861f19">
											<gml:posList>35.669052609389865 139.73847828393 33.889 35.669052609389865 139.73847828393 33.761 35.66901834759863 139.73844320900014 33.761 35.66901834759863 139.73844320900014 33.889 35.669052609389865 139.73847828393 33.889</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4012</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">197.04963</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>