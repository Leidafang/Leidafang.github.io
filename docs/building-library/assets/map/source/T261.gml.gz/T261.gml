<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_486b168a-b375-4ebd-8ada-138de79863f7">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66852265706125 139.7427525433565 0 35.66857251135792 139.742763643508 0 35.66857565004231 139.74274221070127 0 35.66852588588093 139.74273111046082 0 35.66852265706125 139.7427525433565 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852265706125 139.7427525433565 12.74 35.66852588588093 139.74273111046082 12.74 35.66857565004231 139.74274221070127 12.74 35.66857251135792 139.742763643508 12.74 35.66852265706125 139.7427525433565 12.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852265706125 139.7427525433565 12.74 35.66857251135792 139.742763643508 12.74 35.66857251135792 139.742763643508 15.74 35.66852265706125 139.7427525433565 15.74 35.66852265706125 139.7427525433565 12.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857251135792 139.742763643508 12.74 35.66857565004231 139.74274221070127 12.74 35.66857565004231 139.74274221070127 15.74 35.66857251135792 139.742763643508 15.74 35.66857251135792 139.742763643508 12.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857565004231 139.74274221070127 12.74 35.66852588588093 139.74273111046082 12.74 35.66852588588093 139.74273111046082 15.74 35.66857565004231 139.74274221070127 15.74 35.66857565004231 139.74274221070127 12.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852588588093 139.74273111046082 12.74 35.66852265706125 139.7427525433565 12.74 35.66852265706125 139.7427525433565 15.74 35.66852588588093 139.74273111046082 15.74 35.66852588588093 139.74273111046082 12.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852265706125 139.7427525433565 15.74 35.66857251135792 139.742763643508 15.74 35.66857565004231 139.74274221070127 15.74 35.66852588588093 139.74273111046082 15.74 35.66852265706125 139.7427525433565 15.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-abe3329c-2417-455b-95dc-f288e02011d9"/>
							<gml:surfaceMember xlink:href="#poly-a3e2bd1c-abe0-45a6-8acb-04799aefd6f3"/>
							<gml:surfaceMember xlink:href="#poly-0e65640c-c350-4e9c-8362-3629f05fa887"/>
							<gml:surfaceMember xlink:href="#poly-4a212554-055f-4a08-b016-08294dea0908"/>
							<gml:surfaceMember xlink:href="#poly-6ba53c85-aa22-4d77-b37d-bf02fcb08b49"/>
							<gml:surfaceMember xlink:href="#poly-2572bf4d-9a9e-4afd-97fe-48e9704c337c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-abe3329c-2417-455b-95dc-f288e02011d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abe3329c-2417-455b-95dc-f288e02011d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abe3329c-2417-455b-95dc-f288e02011d9">
											<gml:posList>35.66852265706125 139.7427525433565 12.74 35.66852588588094 139.74273111046082 12.74 35.668575650042285 139.74274221070127 12.74 35.66857251135792 139.742763643508 12.74 35.66852265706125 139.7427525433565 12.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a3e2bd1c-abe0-45a6-8acb-04799aefd6f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a3e2bd1c-abe0-45a6-8acb-04799aefd6f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a3e2bd1c-abe0-45a6-8acb-04799aefd6f3">
											<gml:posList>35.66852588588094 139.74273111046082 15.3 35.66852265706125 139.7427525433565 15.3 35.66857251135792 139.742763643508 15.3 35.668575650042285 139.74274221070127 15.3 35.66852588588094 139.74273111046082 15.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e65640c-c350-4e9c-8362-3629f05fa887">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e65640c-c350-4e9c-8362-3629f05fa887">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e65640c-c350-4e9c-8362-3629f05fa887">
											<gml:posList>35.668575650042285 139.74274221070127 12.74 35.66852588588094 139.74273111046082 12.74 35.66852588588094 139.74273111046082 15.3 35.668575650042285 139.74274221070127 15.3 35.668575650042285 139.74274221070127 12.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a212554-055f-4a08-b016-08294dea0908">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a212554-055f-4a08-b016-08294dea0908">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a212554-055f-4a08-b016-08294dea0908">
											<gml:posList>35.66852588588094 139.74273111046082 12.74 35.66852265706125 139.7427525433565 12.74 35.66852265706125 139.7427525433565 15.3 35.66852588588094 139.74273111046082 15.3 35.66852588588094 139.74273111046082 12.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ba53c85-aa22-4d77-b37d-bf02fcb08b49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ba53c85-aa22-4d77-b37d-bf02fcb08b49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ba53c85-aa22-4d77-b37d-bf02fcb08b49">
											<gml:posList>35.66857251135792 139.742763643508 12.74 35.668575650042285 139.74274221070127 12.74 35.668575650042285 139.74274221070127 15.3 35.66857251135792 139.742763643508 15.3 35.66857251135792 139.742763643508 12.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2572bf4d-9a9e-4afd-97fe-48e9704c337c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2572bf4d-9a9e-4afd-97fe-48e9704c337c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2572bf4d-9a9e-4afd-97fe-48e9704c337c">
											<gml:posList>35.66852265706125 139.7427525433565 12.74 35.66857251135792 139.742763643508 12.74 35.66857251135792 139.742763643508 15.3 35.66852265706125 139.7427525433565 15.3 35.66852265706125 139.7427525433565 12.74</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7484</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>