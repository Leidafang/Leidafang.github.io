<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_489f892f-4aba-4d21-87be-2281c44c1092">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">13.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66916621205277 139.747770387618 0 35.669154698888505 139.74780475324792 0 35.66924378650676 139.74784972632136 0 35.669255389820876 139.74781536056355 0 35.66916621205277 139.747770387618 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916621205277 139.747770387618 5.976 35.669255389820876 139.74781536056355 5.976 35.66924378650676 139.74784972632136 5.976 35.669154698888505 139.74780475324792 5.976 35.66916621205277 139.747770387618 5.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916621205277 139.747770387618 5.976 35.669154698888505 139.74780475324792 5.976 35.669154698888505 139.74780475324792 19.38 35.66916621205277 139.747770387618 19.38 35.66916621205277 139.747770387618 5.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669154698888505 139.74780475324792 5.976 35.66924378650676 139.74784972632136 5.976 35.66924378650676 139.74784972632136 19.38 35.669154698888505 139.74780475324792 19.38 35.669154698888505 139.74780475324792 5.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924378650676 139.74784972632136 5.976 35.669255389820876 139.74781536056355 5.976 35.669255389820876 139.74781536056355 19.38 35.66924378650676 139.74784972632136 19.38 35.66924378650676 139.74784972632136 5.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669255389820876 139.74781536056355 5.976 35.66916621205277 139.747770387618 5.976 35.66916621205277 139.747770387618 19.38 35.669255389820876 139.74781536056355 19.38 35.669255389820876 139.74781536056355 5.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916621205277 139.747770387618 19.38 35.669154698888505 139.74780475324792 19.38 35.66924378650676 139.74784972632136 19.38 35.669255389820876 139.74781536056355 19.38 35.66916621205277 139.747770387618 19.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2a6946be-7729-45a3-b03b-aec4a9f69524"/>
							<gml:surfaceMember xlink:href="#poly-f739b53f-b534-43a0-aa17-6d129ad61587"/>
							<gml:surfaceMember xlink:href="#poly-fa414c23-6cde-4ab1-a1f2-560fd62ebf48"/>
							<gml:surfaceMember xlink:href="#poly-f95a5732-8a2e-4b8f-a7af-44d5d97f69fd"/>
							<gml:surfaceMember xlink:href="#poly-d594a143-29a5-4c70-9911-8dc28548e9e1"/>
							<gml:surfaceMember xlink:href="#poly-6dce915d-13a3-46ca-b0f7-7fd35781860e"/>
							<gml:surfaceMember xlink:href="#poly-d20ad0ae-e6c8-4b34-baa7-01a328101e3f"/>
							<gml:surfaceMember xlink:href="#poly-04714ab1-bd15-4f6b-ba06-66a0ed86c350"/>
							<gml:surfaceMember xlink:href="#poly-48e4af4b-a904-4f5b-a75f-2842380ea4ec"/>
							<gml:surfaceMember xlink:href="#poly-52f85116-f49e-458e-8f9f-a2cf372564f1"/>
							<gml:surfaceMember xlink:href="#poly-4528d887-d7d0-4e69-9f2b-dc288838152d"/>
							<gml:surfaceMember xlink:href="#poly-748a453a-67cd-42cb-a01a-106c1509b22b"/>
							<gml:surfaceMember xlink:href="#poly-454a3435-ccf0-4f12-a0b4-e396d1bf6e8a"/>
							<gml:surfaceMember xlink:href="#poly-cfe8af7f-9eae-4ecc-9a88-d356a65548d0"/>
							<gml:surfaceMember xlink:href="#poly-82c9d673-3d0e-4c40-84fe-2b71360007ef"/>
							<gml:surfaceMember xlink:href="#poly-9d171983-34ca-4653-9f61-518b623d4158"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2a6946be-7729-45a3-b03b-aec4a9f69524">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a6946be-7729-45a3-b03b-aec4a9f69524">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a6946be-7729-45a3-b03b-aec4a9f69524">
											<gml:posList>35.66916621205273 139.74777038761798 5.976 35.66925538982087 139.74781536056352 5.976 35.66924378650675 139.7478497263214 5.976 35.6691546988885 139.74780475324792 5.976 35.66916621205273 139.74777038761798 5.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f739b53f-b534-43a0-aa17-6d129ad61587">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f739b53f-b534-43a0-aa17-6d129ad61587">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f739b53f-b534-43a0-aa17-6d129ad61587">
											<gml:posList>35.66919183826119 139.74778330629675 21.152 35.66916621205273 139.74777038761798 19.7 35.6691546988885 139.74780475324792 19.7 35.66918029805215 139.74781767196467 21.152 35.66919183826119 139.74778330629675 21.152</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa414c23-6cde-4ab1-a1f2-560fd62ebf48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa414c23-6cde-4ab1-a1f2-560fd62ebf48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa414c23-6cde-4ab1-a1f2-560fd62ebf48">
											<gml:posList>35.66918029805215 139.74781767196467 21.9 35.66918267681298 139.74781645435718 21.9 35.66919283183502 139.74778621036003 21.9 35.66919183826119 139.74778330629675 21.9 35.66918029805215 139.74781767196467 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f95a5732-8a2e-4b8f-a7af-44d5d97f69fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f95a5732-8a2e-4b8f-a7af-44d5d97f69fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f95a5732-8a2e-4b8f-a7af-44d5d97f69fd">
											<gml:posList>35.66924378650675 139.7478497263214 21.9 35.66924280194819 139.74784682224583 21.9 35.66918267681298 139.74781645435718 21.9 35.66918029805215 139.74781767196467 21.9 35.66924378650675 139.7478497263214 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d594a143-29a5-4c70-9911-8dc28548e9e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d594a143-29a5-4c70-9911-8dc28548e9e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d594a143-29a5-4c70-9911-8dc28548e9e1">
											<gml:posList>35.6692530200738 139.74781657816254 21.656 35.66919283183502 139.74778621036003 21.656 35.66918267681298 139.74781645435718 21.656 35.66924280194819 139.74784682224583 21.656 35.6692530200738 139.74781657816254 21.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6dce915d-13a3-46ca-b0f7-7fd35781860e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dce915d-13a3-46ca-b0f7-7fd35781860e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dce915d-13a3-46ca-b0f7-7fd35781860e">
											<gml:posList>35.66919183826119 139.74778330629675 21.9 35.66919283183502 139.74778621036003 21.9 35.6692530200738 139.74781657816254 21.9 35.66925538982087 139.74781536056352 21.9 35.66919183826119 139.74778330629675 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d20ad0ae-e6c8-4b34-baa7-01a328101e3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d20ad0ae-e6c8-4b34-baa7-01a328101e3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d20ad0ae-e6c8-4b34-baa7-01a328101e3f">
											<gml:posList>35.66925538982087 139.74781536056352 21.9 35.6692530200738 139.74781657816254 21.9 35.66924280194819 139.74784682224583 21.9 35.66924378650675 139.7478497263214 21.9 35.66925538982087 139.74781536056352 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-04714ab1-bd15-4f6b-ba06-66a0ed86c350">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-04714ab1-bd15-4f6b-ba06-66a0ed86c350">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-04714ab1-bd15-4f6b-ba06-66a0ed86c350">
											<gml:posList>35.66919283183502 139.74778621036003 21.9 35.66919283183502 139.74778621036003 21.656 35.6692530200738 139.74781657816254 21.656 35.6692530200738 139.74781657816254 21.9 35.66919283183502 139.74778621036003 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48e4af4b-a904-4f5b-a75f-2842380ea4ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48e4af4b-a904-4f5b-a75f-2842380ea4ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48e4af4b-a904-4f5b-a75f-2842380ea4ec">
											<gml:posList>35.66924280194819 139.74784682224583 21.9 35.66924280194819 139.74784682224583 21.656 35.66918267681298 139.74781645435718 21.656 35.66918267681298 139.74781645435718 21.9 35.66924280194819 139.74784682224583 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52f85116-f49e-458e-8f9f-a2cf372564f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52f85116-f49e-458e-8f9f-a2cf372564f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52f85116-f49e-458e-8f9f-a2cf372564f1">
											<gml:posList>35.66916621205273 139.74777038761798 5.976 35.6691546988885 139.74780475324792 5.976 35.6691546988885 139.74780475324792 19.7 35.66916621205273 139.74777038761798 19.7 35.66916621205273 139.74777038761798 5.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4528d887-d7d0-4e69-9f2b-dc288838152d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4528d887-d7d0-4e69-9f2b-dc288838152d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4528d887-d7d0-4e69-9f2b-dc288838152d">
											<gml:posList>35.66919183826119 139.74778330629675 21.152 35.66919183826119 139.74778330629675 21.9 35.66925538982087 139.74781536056352 21.9 35.66925538982087 139.74781536056352 5.976 35.66916621205273 139.74777038761798 5.976 35.66916621205273 139.74777038761798 19.7 35.66919183826119 139.74778330629675 21.152</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-748a453a-67cd-42cb-a01a-106c1509b22b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-748a453a-67cd-42cb-a01a-106c1509b22b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-748a453a-67cd-42cb-a01a-106c1509b22b">
											<gml:posList>35.66918029805215 139.74781767196467 21.152 35.66918029805215 139.74781767196467 21.9 35.66919183826119 139.74778330629675 21.9 35.66919183826119 139.74778330629675 21.152 35.66918029805215 139.74781767196467 21.152</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-454a3435-ccf0-4f12-a0b4-e396d1bf6e8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-454a3435-ccf0-4f12-a0b4-e396d1bf6e8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-454a3435-ccf0-4f12-a0b4-e396d1bf6e8a">
											<gml:posList>35.66918267681298 139.74781645435718 21.9 35.66918267681298 139.74781645435718 21.656 35.66919283183502 139.74778621036003 21.656 35.66919283183502 139.74778621036003 21.9 35.66918267681298 139.74781645435718 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfe8af7f-9eae-4ecc-9a88-d356a65548d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfe8af7f-9eae-4ecc-9a88-d356a65548d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfe8af7f-9eae-4ecc-9a88-d356a65548d0">
											<gml:posList>35.66924378650675 139.7478497263214 5.976 35.66924378650675 139.7478497263214 21.9 35.66918029805215 139.74781767196467 21.9 35.66918029805215 139.74781767196467 21.152 35.6691546988885 139.74780475324792 19.7 35.6691546988885 139.74780475324792 5.976 35.66924378650675 139.7478497263214 5.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82c9d673-3d0e-4c40-84fe-2b71360007ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82c9d673-3d0e-4c40-84fe-2b71360007ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82c9d673-3d0e-4c40-84fe-2b71360007ef">
											<gml:posList>35.6692530200738 139.74781657816254 21.9 35.6692530200738 139.74781657816254 21.656 35.66924280194819 139.74784682224583 21.656 35.66924280194819 139.74784682224583 21.9 35.6692530200738 139.74781657816254 21.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d171983-34ca-4653-9f61-518b623d4158">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d171983-34ca-4653-9f61-518b623d4158">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d171983-34ca-4653-9f61-518b623d4158">
											<gml:posList>35.66924378650675 139.7478497263214 5.976 35.66925538982087 139.74781536056352 5.976 35.66925538982087 139.74781536056352 21.9 35.66924378650675 139.7478497263214 21.9 35.66924378650675 139.7478497263214 5.976</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10323</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">35.98515</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>