<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4b1598c8-fe37-4ea2-a14a-481c02c87214">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>46</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101046002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">36.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672079570567895 139.74251997288954 0 35.67203029791828 139.7424435096864 0 35.672021815072576 139.74243034084563 0 35.671989038031036 139.74246202617846 0 35.67197479771663 139.7424757951858 0 35.67190440804198 139.7423664044421 0 35.67172533435966 139.7426439838575 0 35.671830737810836 139.74280757315884 0 35.67204510839223 139.74260009897125 0 35.67202651831554 139.74257117821546 0 35.672079570567895 139.74251997288954 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672079570567895 139.74251997288954 7.36 35.67202651831554 139.74257117821546 7.36 35.67204510839223 139.74260009897125 7.36 35.671830737810836 139.74280757315884 7.36 35.67172533435966 139.7426439838575 7.36 35.67190440804198 139.7423664044421 7.36 35.67197479771663 139.7424757951858 7.36 35.671989038031036 139.74246202617846 7.36 35.672021815072576 139.74243034084563 7.36 35.67203029791828 139.7424435096864 7.36 35.672079570567895 139.74251997288954 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672079570567895 139.74251997288954 7.36 35.67203029791828 139.7424435096864 7.36 35.67203029791828 139.7424435096864 40.87 35.672079570567895 139.74251997288954 40.87 35.672079570567895 139.74251997288954 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67203029791828 139.7424435096864 7.36 35.672021815072576 139.74243034084563 7.36 35.672021815072576 139.74243034084563 40.87 35.67203029791828 139.7424435096864 40.87 35.67203029791828 139.7424435096864 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672021815072576 139.74243034084563 7.36 35.671989038031036 139.74246202617846 7.36 35.671989038031036 139.74246202617846 40.87 35.672021815072576 139.74243034084563 40.87 35.672021815072576 139.74243034084563 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671989038031036 139.74246202617846 7.36 35.67197479771663 139.7424757951858 7.36 35.67197479771663 139.7424757951858 40.87 35.671989038031036 139.74246202617846 40.87 35.671989038031036 139.74246202617846 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67197479771663 139.7424757951858 7.36 35.67190440804198 139.7423664044421 7.36 35.67190440804198 139.7423664044421 40.87 35.67197479771663 139.7424757951858 40.87 35.67197479771663 139.7424757951858 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67190440804198 139.7423664044421 7.36 35.67172533435966 139.7426439838575 7.36 35.67172533435966 139.7426439838575 40.87 35.67190440804198 139.7423664044421 40.87 35.67190440804198 139.7423664044421 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67172533435966 139.7426439838575 7.36 35.671830737810836 139.74280757315884 7.36 35.671830737810836 139.74280757315884 40.87 35.67172533435966 139.7426439838575 40.87 35.67172533435966 139.7426439838575 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671830737810836 139.74280757315884 7.36 35.67204510839223 139.74260009897125 7.36 35.67204510839223 139.74260009897125 40.87 35.671830737810836 139.74280757315884 40.87 35.671830737810836 139.74280757315884 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67204510839223 139.74260009897125 7.36 35.67202651831554 139.74257117821546 7.36 35.67202651831554 139.74257117821546 40.87 35.67204510839223 139.74260009897125 40.87 35.67204510839223 139.74260009897125 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67202651831554 139.74257117821546 7.36 35.672079570567895 139.74251997288954 7.36 35.672079570567895 139.74251997288954 40.87 35.67202651831554 139.74257117821546 40.87 35.67202651831554 139.74257117821546 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672079570567895 139.74251997288954 40.87 35.67203029791828 139.7424435096864 40.87 35.672021815072576 139.74243034084563 40.87 35.671989038031036 139.74246202617846 40.87 35.67197479771663 139.7424757951858 40.87 35.67190440804198 139.7423664044421 40.87 35.67172533435966 139.7426439838575 40.87 35.671830737810836 139.74280757315884 40.87 35.67204510839223 139.74260009897125 40.87 35.67202651831554 139.74257117821546 40.87 35.672079570567895 139.74251997288954 40.87</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-99342788-6f74-40b2-b525-453a6377abbf"/>
							<gml:surfaceMember xlink:href="#poly-752de9bc-3804-4054-bf4e-50e7ca740a1a"/>
							<gml:surfaceMember xlink:href="#poly-7aa82db1-214b-4836-b435-a1d2caf2b2be"/>
							<gml:surfaceMember xlink:href="#poly-408dbff7-7105-4662-9459-e61689ff74a7"/>
							<gml:surfaceMember xlink:href="#poly-27b3fe23-30eb-47df-b666-ef05c0157c6f"/>
							<gml:surfaceMember xlink:href="#poly-21783353-7d75-46d4-8e07-4786398f17ca"/>
							<gml:surfaceMember xlink:href="#poly-d07ce1e0-b0a8-4cff-b5fd-7e0f1a8a5245"/>
							<gml:surfaceMember xlink:href="#poly-490a96a5-725d-4748-a110-a555f8c45083"/>
							<gml:surfaceMember xlink:href="#poly-fa02867f-4d30-47a4-9da4-1bb54a558613"/>
							<gml:surfaceMember xlink:href="#poly-b171be13-ae70-457b-8d72-73771307f31d"/>
							<gml:surfaceMember xlink:href="#poly-d0eb279b-8ca2-4747-bfa7-1769370b633c"/>
							<gml:surfaceMember xlink:href="#poly-fcf07ecf-87dd-44d7-aa79-b41fbf323262"/>
							<gml:surfaceMember xlink:href="#poly-441675ec-898b-4982-918e-de41b837cb05"/>
							<gml:surfaceMember xlink:href="#poly-0eb4b856-ecc6-4025-9d7d-7ff673d305b2"/>
							<gml:surfaceMember xlink:href="#poly-e011cfae-c82d-44a7-945f-bb5b39ec8e93"/>
							<gml:surfaceMember xlink:href="#poly-fbf8b1cf-3060-467c-8de4-41623fba1389"/>
							<gml:surfaceMember xlink:href="#poly-9133b698-678b-45b7-beae-cb765541a5e9"/>
							<gml:surfaceMember xlink:href="#poly-ec23b341-c2da-4d3c-aa2e-0c65fe478db2"/>
							<gml:surfaceMember xlink:href="#poly-4007249c-dc20-470e-89c1-529b184f65ba"/>
							<gml:surfaceMember xlink:href="#poly-7e81c7c8-74ed-453f-af83-de669c7886ec"/>
							<gml:surfaceMember xlink:href="#poly-ab3b896e-5c1a-41fb-a9a2-18bed1514350"/>
							<gml:surfaceMember xlink:href="#poly-0560bf77-0397-4ad8-adac-e76fa360f988"/>
							<gml:surfaceMember xlink:href="#poly-4cdc4b91-b6fe-4531-98b3-3d836945910b"/>
							<gml:surfaceMember xlink:href="#poly-1ea8f590-2c4e-4edd-8f91-b6b985555b1f"/>
							<gml:surfaceMember xlink:href="#poly-72b23135-485f-44f7-aa86-91c241b488b0"/>
							<gml:surfaceMember xlink:href="#poly-f338d425-21bd-42cc-b717-b64565c028c5"/>
							<gml:surfaceMember xlink:href="#poly-14318a35-e7dd-49ac-b3e7-3a17ef70f4e5"/>
							<gml:surfaceMember xlink:href="#poly-c1c19590-eb76-45b1-b88e-a336a2a4970b"/>
							<gml:surfaceMember xlink:href="#poly-2ce23645-4b16-4b6f-9c36-7c073460f2cc"/>
							<gml:surfaceMember xlink:href="#poly-7091c3df-f1a4-44cb-a2d2-781a8a1e95ff"/>
							<gml:surfaceMember xlink:href="#poly-165fddd3-9388-4a1e-aaa6-21fef0bc6872"/>
							<gml:surfaceMember xlink:href="#poly-eaf787f1-ce01-4874-97b6-f30112c4d4be"/>
							<gml:surfaceMember xlink:href="#poly-dba20f5e-260c-4644-971e-5315b6b4eb63"/>
							<gml:surfaceMember xlink:href="#poly-8e3348a8-2fea-42ac-84d3-bbe2c6e18073"/>
							<gml:surfaceMember xlink:href="#poly-e9beccf4-113b-42b2-ace4-a2d8a6ee8216"/>
							<gml:surfaceMember xlink:href="#poly-76e8694a-9d09-4867-9621-412bbf3fb49c"/>
							<gml:surfaceMember xlink:href="#poly-8231ce25-18c9-4d80-a7da-31a3c83693e2"/>
							<gml:surfaceMember xlink:href="#poly-734aa119-f488-4676-8292-a27c0495bed7"/>
							<gml:surfaceMember xlink:href="#poly-b5234e17-af96-49fc-8781-93b9d9fa98d3"/>
							<gml:surfaceMember xlink:href="#poly-09064e21-1334-4a0e-b669-726228ad22c9"/>
							<gml:surfaceMember xlink:href="#poly-c80a1b82-9001-42fe-aebe-9bdac95a04dd"/>
							<gml:surfaceMember xlink:href="#poly-fe11121e-3195-4320-b5c1-cba03cff0704"/>
							<gml:surfaceMember xlink:href="#poly-15b6cbc9-b3d3-4f28-a7c6-5f1e3062a4f7"/>
							<gml:surfaceMember xlink:href="#poly-5fa1c5be-abf7-445a-9928-de75d578f8b9"/>
							<gml:surfaceMember xlink:href="#poly-7fa8483e-ab08-4420-afce-6b24e8c54815"/>
							<gml:surfaceMember xlink:href="#poly-d8f14cf8-2694-4364-9d2a-3abc3062442f"/>
							<gml:surfaceMember xlink:href="#poly-6014da80-3c28-4cd2-8d88-98604ba03eb0"/>
							<gml:surfaceMember xlink:href="#poly-8c44c244-c861-47e3-8582-e26f1b344d48"/>
							<gml:surfaceMember xlink:href="#poly-4af8007c-ce35-43d1-bb49-59055091e9c8"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-99342788-6f74-40b2-b525-453a6377abbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99342788-6f74-40b2-b525-453a6377abbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99342788-6f74-40b2-b525-453a6377abbf">
											<gml:posList>35.671725334359635 139.74264398385748 7.36 35.671904408041975 139.7423664044421 7.36 35.671974797716594 139.7424757951858 7.36 35.67202181507257 139.74243034084563 7.36 35.67207957056787 139.74251997288954 7.36 35.672026518315505 139.74257117821546 7.36 35.672045108392226 139.74260009897122 7.36 35.671830737810836 139.7428075731588 7.36 35.671725334359635 139.74264398385748 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-752de9bc-3804-4054-bf4e-50e7ca740a1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-752de9bc-3804-4054-bf4e-50e7ca740a1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-752de9bc-3804-4054-bf4e-50e7ca740a1a">
											<gml:posList>35.671974797716594 139.7424757951858 40.8 35.671904408041975 139.7423664044421 40.8 35.671927700187375 139.74245085039195 40.8 35.67194427124474 139.74247980651162 40.8 35.671974797716594 139.7424757951858 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7aa82db1-214b-4836-b435-a1d2caf2b2be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7aa82db1-214b-4836-b435-a1d2caf2b2be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7aa82db1-214b-4836-b435-a1d2caf2b2be">
											<gml:posList>35.67202181507257 139.74243034084563 37.133 35.67198902901729 139.74246202618866 37.133 35.67199707955105 139.74247565946962 37.133 35.67203029791827 139.74244350968638 37.133 35.67202181507257 139.74243034084563 37.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-408dbff7-7105-4662-9459-e61689ff74a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-408dbff7-7105-4662-9459-e61689ff74a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-408dbff7-7105-4662-9459-e61689ff74a7">
											<gml:posList>35.67194427124474 139.74247980651162 43.6 35.671927700187375 139.74245085039195 43.6 35.6719116391358 139.74246466564028 43.6 35.67192821018989 139.742493621757 43.6 35.67194427124474 139.74247980651162 43.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-27b3fe23-30eb-47df-b666-ef05c0157c6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-27b3fe23-30eb-47df-b666-ef05c0157c6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-27b3fe23-30eb-47df-b666-ef05c0157c6f">
											<gml:posList>35.672041656100575 139.74254026404967 41.933 35.672012307655166 139.74249279740246 41.933 35.67198412342917 139.74251895426357 41.933 35.67201347187273 139.74256643195022 41.933 35.672041656100575 139.74254026404967 41.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-21783353-7d75-46d4-8e07-4786398f17ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21783353-7d75-46d4-8e07-4786398f17ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21783353-7d75-46d4-8e07-4786398f17ca">
											<gml:posList>35.672026518315505 139.74257117821546 40.8 35.67207957056787 139.74251997288954 40.8 35.672041656100575 139.74254026404967 40.8 35.67201347187273 139.74256643195022 40.8 35.672026518315505 139.74257117821546 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d07ce1e0-b0a8-4cff-b5fd-7e0f1a8a5245">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d07ce1e0-b0a8-4cff-b5fd-7e0f1a8a5245">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d07ce1e0-b0a8-4cff-b5fd-7e0f1a8a5245">
											<gml:posList>35.671871726206334 139.74269170469032 40.8 35.67186071903078 139.74270180255607 40.8 35.671830737810836 139.7428075731588 40.8 35.67197334366612 139.74266335500323 40.8 35.671962449580185 139.74264408017373 40.8 35.67197815047786 139.74263076245157 40.8 35.6719890445659 139.74265003728308 40.8 35.672045108392226 139.74260009897122 40.8 35.672026518315505 139.74257117821546 40.8 35.67201347187273 139.74256643195022 40.8 35.67198412342917 139.74251895426357 40.8 35.672012307655166 139.74249279740246 40.8 35.672041656100575 139.74254026404967 40.8 35.67207957056787 139.74251997288954 40.8 35.67203029791827 139.74244350968638 40.8 35.67199707955105 139.74247565946962 40.8 35.67198902901729 139.74246202618866 40.8 35.671974797716594 139.7424757951858 40.8 35.67194427124474 139.74247980651162 40.8 35.67192821018989 139.742493621757 40.8 35.6719116391358 139.74246466564028 40.8 35.671927700187375 139.74245085039195 40.8 35.671904408041975 139.7423664044421 40.8 35.671725334359635 139.74264398385748 40.8 35.671842687371246 139.7426722736563 40.8 35.67185369454434 139.74266217578878 40.8 35.67187769784676 139.74264986497226 40.8 35.67193293177922 139.742599088137 40.8 35.67194618023446 139.74262072423514 40.8 35.67193825277656 139.74266276503957 40.8 35.67195035551314 139.7426831210539 40.8 35.67193107008378 139.7427003422186 40.8 35.67191896735009 139.74267998620658 40.8 35.67189094629298 139.7426715010639 40.8 35.671871726206334 139.74269170469032 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-490a96a5-725d-4748-a110-a555f8c45083">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-490a96a5-725d-4748-a110-a555f8c45083">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-490a96a5-725d-4748-a110-a555f8c45083">
											<gml:posList>35.67193293177922 139.742599088137 44.3 35.67187769784676 139.74264986497226 44.3 35.67189094629298 139.7426715010639 44.3 35.67194618023446 139.74262072423514 44.3 35.67193293177922 139.742599088137 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa02867f-4d30-47a4-9da4-1bb54a558613">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa02867f-4d30-47a4-9da4-1bb54a558613">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa02867f-4d30-47a4-9da4-1bb54a558613">
											<gml:posList>35.671962449580185 139.74264408017373 41.933 35.671973334660706 139.74266336605993 41.933 35.6719890445659 139.74265003728308 41.933 35.67197815047786 139.74263076245157 41.933 35.671962449580185 139.74264408017373 41.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b171be13-ae70-457b-8d72-73771307f31d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b171be13-ae70-457b-8d72-73771307f31d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b171be13-ae70-457b-8d72-73771307f31d">
											<gml:posList>35.67189094629298 139.7426715010639 40.8 35.67191896735009 139.74267998620658 40.8 35.67193825277656 139.74266276503957 40.8 35.67194618023446 139.74262072423514 40.8 35.67189094629298 139.7426715010639 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0eb279b-8ca2-4747-bfa7-1769370b633c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0eb279b-8ca2-4747-bfa7-1769370b633c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0eb279b-8ca2-4747-bfa7-1769370b633c">
											<gml:posList>35.671871726206334 139.74269170469032 40.8 35.67189094629298 139.7426715010639 40.8 35.67187769784676 139.74264986497226 40.8 35.67185369454434 139.74266217578878 40.8 35.671871726206334 139.74269170469032 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcf07ecf-87dd-44d7-aa79-b41fbf323262">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcf07ecf-87dd-44d7-aa79-b41fbf323262">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcf07ecf-87dd-44d7-aa79-b41fbf323262">
											<gml:posList>35.67191896735009 139.74267998620658 41.933 35.67193107008378 139.7427003422186 41.933 35.67195035551314 139.7426831210539 41.933 35.67193825277656 139.74266276503957 41.933 35.67191896735009 139.74267998620658 41.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-441675ec-898b-4982-918e-de41b837cb05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-441675ec-898b-4982-918e-de41b837cb05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-441675ec-898b-4982-918e-de41b837cb05">
											<gml:posList>35.671871726206334 139.74269170469032 43.767 35.67185369454434 139.74266217578878 43.767 35.671842687371246 139.7426722736563 43.767 35.67186071903078 139.74270180255607 43.767 35.671871726206334 139.74269170469032 43.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0eb4b856-ecc6-4025-9d7d-7ff673d305b2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0eb4b856-ecc6-4025-9d7d-7ff673d305b2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0eb4b856-ecc6-4025-9d7d-7ff673d305b2">
											<gml:posList>35.6719890445659 139.74265003728308 40.8 35.67197334366612 139.74266335500323 40.8 35.671830737810836 139.7428075731588 40.8 35.672045108392226 139.74260009897122 40.8 35.6719890445659 139.74265003728308 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e011cfae-c82d-44a7-945f-bb5b39ec8e93">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e011cfae-c82d-44a7-945f-bb5b39ec8e93">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e011cfae-c82d-44a7-945f-bb5b39ec8e93">
											<gml:posList>35.671842687371246 139.7426722736563 40.8 35.671725334359635 139.74264398385748 40.8 35.671830737810836 139.7428075731588 40.8 35.67186071903078 139.74270180255607 40.8 35.671842687371246 139.7426722736563 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fbf8b1cf-3060-467c-8de4-41623fba1389">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fbf8b1cf-3060-467c-8de4-41623fba1389">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fbf8b1cf-3060-467c-8de4-41623fba1389">
											<gml:posList>35.671904408041975 139.7423664044421 7.36 35.671904408041975 139.7423664044421 40.8 35.671974797716594 139.7424757951858 40.8 35.671974797716594 139.7424757951858 7.36 35.671904408041975 139.7423664044421 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9133b698-678b-45b7-beae-cb765541a5e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9133b698-678b-45b7-beae-cb765541a5e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9133b698-678b-45b7-beae-cb765541a5e9">
											<gml:posList>35.671974797716594 139.7424757951858 7.36 35.671974797716594 139.7424757951858 40.8 35.67198902901729 139.74246202618866 40.8 35.67198902901729 139.74246202618866 37.133 35.67202181507257 139.74243034084563 37.133 35.67202181507257 139.74243034084563 7.36 35.671974797716594 139.7424757951858 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec23b341-c2da-4d3c-aa2e-0c65fe478db2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec23b341-c2da-4d3c-aa2e-0c65fe478db2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec23b341-c2da-4d3c-aa2e-0c65fe478db2">
											<gml:posList>35.671927700187375 139.74245085039195 40.8 35.6719116391358 139.74246466564028 40.8 35.6719116391358 139.74246466564028 43.6 35.671927700187375 139.74245085039195 43.6 35.671927700187375 139.74245085039195 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4007249c-dc20-470e-89c1-529b184f65ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4007249c-dc20-470e-89c1-529b184f65ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4007249c-dc20-470e-89c1-529b184f65ba">
											<gml:posList>35.67199707955105 139.74247565946962 40.8 35.67203029791827 139.74244350968638 40.8 35.67203029791827 139.74244350968638 37.133 35.67199707955105 139.74247565946962 37.133 35.67199707955105 139.74247565946962 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e81c7c8-74ed-453f-af83-de669c7886ec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e81c7c8-74ed-453f-af83-de669c7886ec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e81c7c8-74ed-453f-af83-de669c7886ec">
											<gml:posList>35.67194427124474 139.74247980651162 43.6 35.67194427124474 139.74247980651162 40.8 35.671927700187375 139.74245085039195 40.8 35.671927700187375 139.74245085039195 43.6 35.67194427124474 139.74247980651162 43.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab3b896e-5c1a-41fb-a9a2-18bed1514350">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab3b896e-5c1a-41fb-a9a2-18bed1514350">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab3b896e-5c1a-41fb-a9a2-18bed1514350">
											<gml:posList>35.67198902901729 139.74246202618866 40.8 35.67199707955105 139.74247565946962 40.8 35.67199707955105 139.74247565946962 37.133 35.67198902901729 139.74246202618866 37.133 35.67198902901729 139.74246202618866 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0560bf77-0397-4ad8-adac-e76fa360f988">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0560bf77-0397-4ad8-adac-e76fa360f988">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0560bf77-0397-4ad8-adac-e76fa360f988">
											<gml:posList>35.67203029791827 139.74244350968638 37.133 35.67203029791827 139.74244350968638 40.8 35.67207957056787 139.74251997288954 40.8 35.67207957056787 139.74251997288954 7.36 35.67202181507257 139.74243034084563 7.36 35.67202181507257 139.74243034084563 37.133 35.67203029791827 139.74244350968638 37.133</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cdc4b91-b6fe-4531-98b3-3d836945910b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cdc4b91-b6fe-4531-98b3-3d836945910b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cdc4b91-b6fe-4531-98b3-3d836945910b">
											<gml:posList>35.67192821018989 139.742493621757 40.8 35.67192821018989 139.742493621757 43.6 35.6719116391358 139.74246466564028 43.6 35.6719116391358 139.74246466564028 40.8 35.67192821018989 139.742493621757 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ea8f590-2c4e-4edd-8f91-b6b985555b1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ea8f590-2c4e-4edd-8f91-b6b985555b1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ea8f590-2c4e-4edd-8f91-b6b985555b1f">
											<gml:posList>35.67192821018989 139.742493621757 40.8 35.67194427124474 139.74247980651162 40.8 35.67194427124474 139.74247980651162 43.6 35.67192821018989 139.742493621757 43.6 35.67192821018989 139.742493621757 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-72b23135-485f-44f7-aa86-91c241b488b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-72b23135-485f-44f7-aa86-91c241b488b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-72b23135-485f-44f7-aa86-91c241b488b0">
											<gml:posList>35.671725334359635 139.74264398385748 40.8 35.671904408041975 139.7423664044421 40.8 35.671904408041975 139.7423664044421 7.36 35.671725334359635 139.74264398385748 7.36 35.671725334359635 139.74264398385748 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f338d425-21bd-42cc-b717-b64565c028c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f338d425-21bd-42cc-b717-b64565c028c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f338d425-21bd-42cc-b717-b64565c028c5">
											<gml:posList>35.672012307655166 139.74249279740246 40.8 35.67198412342917 139.74251895426357 40.8 35.67198412342917 139.74251895426357 41.933 35.672012307655166 139.74249279740246 41.933 35.672012307655166 139.74249279740246 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14318a35-e7dd-49ac-b3e7-3a17ef70f4e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14318a35-e7dd-49ac-b3e7-3a17ef70f4e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14318a35-e7dd-49ac-b3e7-3a17ef70f4e5">
											<gml:posList>35.672041656100575 139.74254026404967 41.933 35.672041656100575 139.74254026404967 40.8 35.672012307655166 139.74249279740246 40.8 35.672012307655166 139.74249279740246 41.933 35.672041656100575 139.74254026404967 41.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1c19590-eb76-45b1-b88e-a336a2a4970b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1c19590-eb76-45b1-b88e-a336a2a4970b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1c19590-eb76-45b1-b88e-a336a2a4970b">
											<gml:posList>35.67201347187273 139.74256643195022 40.8 35.67201347187273 139.74256643195022 41.933 35.67198412342917 139.74251895426357 41.933 35.67198412342917 139.74251895426357 40.8 35.67201347187273 139.74256643195022 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ce23645-4b16-4b6f-9c36-7c073460f2cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ce23645-4b16-4b6f-9c36-7c073460f2cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ce23645-4b16-4b6f-9c36-7c073460f2cc">
											<gml:posList>35.672026518315505 139.74257117821546 40.8 35.672026518315505 139.74257117821546 7.36 35.67207957056787 139.74251997288954 7.36 35.67207957056787 139.74251997288954 40.8 35.672026518315505 139.74257117821546 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7091c3df-f1a4-44cb-a2d2-781a8a1e95ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7091c3df-f1a4-44cb-a2d2-781a8a1e95ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7091c3df-f1a4-44cb-a2d2-781a8a1e95ff">
											<gml:posList>35.672041656100575 139.74254026404967 40.8 35.672041656100575 139.74254026404967 41.933 35.67201347187273 139.74256643195022 41.933 35.67201347187273 139.74256643195022 40.8 35.672041656100575 139.74254026404967 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-165fddd3-9388-4a1e-aaa6-21fef0bc6872">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-165fddd3-9388-4a1e-aaa6-21fef0bc6872">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-165fddd3-9388-4a1e-aaa6-21fef0bc6872">
											<gml:posList>35.672026518315505 139.74257117821546 40.8 35.672045108392226 139.74260009897122 40.8 35.672045108392226 139.74260009897122 7.36 35.672026518315505 139.74257117821546 7.36 35.672026518315505 139.74257117821546 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eaf787f1-ce01-4874-97b6-f30112c4d4be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eaf787f1-ce01-4874-97b6-f30112c4d4be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eaf787f1-ce01-4874-97b6-f30112c4d4be">
											<gml:posList>35.67193293177922 139.742599088137 40.8 35.67193293177922 139.742599088137 44.3 35.67194618023446 139.74262072423514 44.3 35.67194618023446 139.74262072423514 40.8 35.67193293177922 139.742599088137 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dba20f5e-260c-4644-971e-5315b6b4eb63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dba20f5e-260c-4644-971e-5315b6b4eb63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dba20f5e-260c-4644-971e-5315b6b4eb63">
											<gml:posList>35.67193293177922 139.742599088137 44.3 35.67193293177922 139.742599088137 40.8 35.67187769784676 139.74264986497226 40.8 35.67187769784676 139.74264986497226 44.3 35.67193293177922 139.742599088137 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8e3348a8-2fea-42ac-84d3-bbe2c6e18073">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8e3348a8-2fea-42ac-84d3-bbe2c6e18073">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8e3348a8-2fea-42ac-84d3-bbe2c6e18073">
											<gml:posList>35.671962449580185 139.74264408017373 40.8 35.671962449580185 139.74264408017373 41.933 35.67197815047786 139.74263076245157 41.933 35.67197815047786 139.74263076245157 40.8 35.671962449580185 139.74264408017373 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e9beccf4-113b-42b2-ace4-a2d8a6ee8216">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9beccf4-113b-42b2-ace4-a2d8a6ee8216">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9beccf4-113b-42b2-ace4-a2d8a6ee8216">
											<gml:posList>35.6719890445659 139.74265003728308 40.8 35.67197815047786 139.74263076245157 40.8 35.67197815047786 139.74263076245157 41.933 35.6719890445659 139.74265003728308 41.933 35.6719890445659 139.74265003728308 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76e8694a-9d09-4867-9621-412bbf3fb49c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76e8694a-9d09-4867-9621-412bbf3fb49c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76e8694a-9d09-4867-9621-412bbf3fb49c">
											<gml:posList>35.67189094629298 139.7426715010639 44.3 35.67189094629298 139.7426715010639 40.8 35.67194618023446 139.74262072423514 40.8 35.67194618023446 139.74262072423514 44.3 35.67189094629298 139.7426715010639 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8231ce25-18c9-4d80-a7da-31a3c83693e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8231ce25-18c9-4d80-a7da-31a3c83693e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8231ce25-18c9-4d80-a7da-31a3c83693e2">
											<gml:posList>35.671962449580185 139.74264408017373 40.8 35.67197334366612 139.74266335500323 40.8 35.671973334660706 139.74266336605993 41.933 35.671962449580185 139.74264408017373 41.933 35.671962449580185 139.74264408017373 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-734aa119-f488-4676-8292-a27c0495bed7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-734aa119-f488-4676-8292-a27c0495bed7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-734aa119-f488-4676-8292-a27c0495bed7">
											<gml:posList>35.671973334660706 139.74266336605993 41.933 35.67197334366612 139.74266335500323 40.8 35.6719890445659 139.74265003728308 40.8 35.6719890445659 139.74265003728308 41.933 35.671973334660706 139.74266336605993 41.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b5234e17-af96-49fc-8781-93b9d9fa98d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b5234e17-af96-49fc-8781-93b9d9fa98d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b5234e17-af96-49fc-8781-93b9d9fa98d3">
											<gml:posList>35.67187769784676 139.74264986497226 44.3 35.67187769784676 139.74264986497226 40.8 35.67189094629298 139.7426715010639 40.8 35.67189094629298 139.7426715010639 44.3 35.67187769784676 139.74264986497226 44.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-09064e21-1334-4a0e-b669-726228ad22c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09064e21-1334-4a0e-b669-726228ad22c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09064e21-1334-4a0e-b669-726228ad22c9">
											<gml:posList>35.67185369454434 139.74266217578878 40.8 35.671842687371246 139.7426722736563 40.8 35.671842687371246 139.7426722736563 43.767 35.67185369454434 139.74266217578878 43.767 35.67185369454434 139.74266217578878 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c80a1b82-9001-42fe-aebe-9bdac95a04dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c80a1b82-9001-42fe-aebe-9bdac95a04dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c80a1b82-9001-42fe-aebe-9bdac95a04dd">
											<gml:posList>35.67193825277656 139.74266276503957 41.933 35.67193825277656 139.74266276503957 40.8 35.67191896735009 139.74267998620658 40.8 35.67191896735009 139.74267998620658 41.933 35.67193825277656 139.74266276503957 41.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe11121e-3195-4320-b5c1-cba03cff0704">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe11121e-3195-4320-b5c1-cba03cff0704">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe11121e-3195-4320-b5c1-cba03cff0704">
											<gml:posList>35.67195035551314 139.7426831210539 41.933 35.67195035551314 139.7426831210539 40.8 35.67193825277656 139.74266276503957 40.8 35.67193825277656 139.74266276503957 41.933 35.67195035551314 139.7426831210539 41.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15b6cbc9-b3d3-4f28-a7c6-5f1e3062a4f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15b6cbc9-b3d3-4f28-a7c6-5f1e3062a4f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15b6cbc9-b3d3-4f28-a7c6-5f1e3062a4f7">
											<gml:posList>35.671871726206334 139.74269170469032 43.767 35.671871726206334 139.74269170469032 40.8 35.67185369454434 139.74266217578878 40.8 35.67185369454434 139.74266217578878 43.767 35.671871726206334 139.74269170469032 43.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5fa1c5be-abf7-445a-9928-de75d578f8b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fa1c5be-abf7-445a-9928-de75d578f8b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fa1c5be-abf7-445a-9928-de75d578f8b9">
											<gml:posList>35.671842687371246 139.7426722736563 43.767 35.671842687371246 139.7426722736563 40.8 35.67186071903078 139.74270180255607 40.8 35.67186071903078 139.74270180255607 43.767 35.671842687371246 139.7426722736563 43.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fa8483e-ab08-4420-afce-6b24e8c54815">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fa8483e-ab08-4420-afce-6b24e8c54815">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fa8483e-ab08-4420-afce-6b24e8c54815">
											<gml:posList>35.67193107008378 139.7427003422186 40.8 35.67193107008378 139.7427003422186 41.933 35.67191896735009 139.74267998620658 41.933 35.67191896735009 139.74267998620658 40.8 35.67193107008378 139.7427003422186 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8f14cf8-2694-4364-9d2a-3abc3062442f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8f14cf8-2694-4364-9d2a-3abc3062442f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8f14cf8-2694-4364-9d2a-3abc3062442f">
											<gml:posList>35.67193107008378 139.7427003422186 40.8 35.67195035551314 139.7426831210539 40.8 35.67195035551314 139.7426831210539 41.933 35.67193107008378 139.7427003422186 41.933 35.67193107008378 139.7427003422186 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6014da80-3c28-4cd2-8d88-98604ba03eb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6014da80-3c28-4cd2-8d88-98604ba03eb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6014da80-3c28-4cd2-8d88-98604ba03eb0">
											<gml:posList>35.67186071903078 139.74270180255607 40.8 35.671871726206334 139.74269170469032 40.8 35.671871726206334 139.74269170469032 43.767 35.67186071903078 139.74270180255607 43.767 35.67186071903078 139.74270180255607 40.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c44c244-c861-47e3-8582-e26f1b344d48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c44c244-c861-47e3-8582-e26f1b344d48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c44c244-c861-47e3-8582-e26f1b344d48">
											<gml:posList>35.672045108392226 139.74260009897122 7.36 35.672045108392226 139.74260009897122 40.8 35.671830737810836 139.7428075731588 40.8 35.671830737810836 139.7428075731588 7.36 35.672045108392226 139.74260009897122 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4af8007c-ce35-43d1-bb49-59055091e9c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4af8007c-ce35-43d1-bb49-59055091e9c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4af8007c-ce35-43d1-bb49-59055091e9c8">
											<gml:posList>35.671830737810836 139.7428075731588 7.36 35.671830737810836 139.7428075731588 40.8 35.671725334359635 139.74264398385748 40.8 35.671725334359635 139.74264398385748 7.36 35.671830737810836 139.7428075731588 7.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区永田町二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4487</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">769.1611</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.21</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>