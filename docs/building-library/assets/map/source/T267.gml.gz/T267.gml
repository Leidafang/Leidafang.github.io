<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4b1dcf3f-1abf-4dcb-b11c-cd23a2bec2a2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67011962884727 139.74445782266082 0 35.670202668151674 139.74448877053518 0 35.670228272181724 139.74438570284707 0 35.67014513369221 139.7443547441335 0 35.67011962884727 139.74445782266082 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011962884727 139.74445782266082 8.46 35.67014513369221 139.7443547441335 8.46 35.670228272181724 139.74438570284707 8.46 35.670202668151674 139.74448877053518 8.46 35.67011962884727 139.74445782266082 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011962884727 139.74445782266082 8.46 35.670202668151674 139.74448877053518 8.46 35.670202668151674 139.74448877053518 23.69 35.67011962884727 139.74445782266082 23.69 35.67011962884727 139.74445782266082 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670202668151674 139.74448877053518 8.46 35.670228272181724 139.74438570284707 8.46 35.670228272181724 139.74438570284707 23.69 35.670202668151674 139.74448877053518 23.69 35.670202668151674 139.74448877053518 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670228272181724 139.74438570284707 8.46 35.67014513369221 139.7443547441335 8.46 35.67014513369221 139.7443547441335 23.69 35.670228272181724 139.74438570284707 23.69 35.670228272181724 139.74438570284707 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014513369221 139.7443547441335 8.46 35.67011962884727 139.74445782266082 8.46 35.67011962884727 139.74445782266082 23.69 35.67014513369221 139.7443547441335 23.69 35.67014513369221 139.7443547441335 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011962884727 139.74445782266082 23.69 35.670202668151674 139.74448877053518 23.69 35.670228272181724 139.74438570284707 23.69 35.67014513369221 139.7443547441335 23.69 35.67011962884727 139.74445782266082 23.69</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ed304f6d-515f-4bf1-a3c3-7b44711a4bb4"/>
							<gml:surfaceMember xlink:href="#poly-504c6709-e96c-4deb-b38c-4c01b4884a26"/>
							<gml:surfaceMember xlink:href="#poly-6d9b6b2b-ca91-43f0-9bf4-2b53578d62f0"/>
							<gml:surfaceMember xlink:href="#poly-92a5db1f-2715-4bc7-a61f-0747572f0c25"/>
							<gml:surfaceMember xlink:href="#poly-43884b2f-5a6f-4fa3-8ba7-4201ba18ac31"/>
							<gml:surfaceMember xlink:href="#poly-1ba05af5-4dbd-47b3-b2c7-7c3a3f135e42"/>
							<gml:surfaceMember xlink:href="#poly-d07b9931-4f83-4bd3-b6cc-961531204eb4"/>
							<gml:surfaceMember xlink:href="#poly-b951f7c1-f219-40be-b446-55f43618f9d8"/>
							<gml:surfaceMember xlink:href="#poly-b8aaef9d-99c4-4b69-9a52-e66e99300f79"/>
							<gml:surfaceMember xlink:href="#poly-80ec0227-5f29-45a0-99bd-74e19797b4c9"/>
							<gml:surfaceMember xlink:href="#poly-00dbf2f0-5630-4fbc-bbaf-8e41bd9369dd"/>
							<gml:surfaceMember xlink:href="#poly-92d7fc4b-1a1f-4e50-9ae4-e819a485fc06"/>
							<gml:surfaceMember xlink:href="#poly-e99e4f7e-b452-425e-abdf-b49eaf821049"/>
							<gml:surfaceMember xlink:href="#poly-6fb6adb7-8142-43b1-ba6f-644de4c9e67a"/>
							<gml:surfaceMember xlink:href="#poly-02df4413-5d06-4421-8e08-574455ae03d6"/>
							<gml:surfaceMember xlink:href="#poly-6e22c18e-ea50-4f97-9797-9859e5f1e66b"/>
							<gml:surfaceMember xlink:href="#poly-36775f0c-90e0-4b8c-b37d-9f0275c22544"/>
							<gml:surfaceMember xlink:href="#poly-5e92d224-cad6-46a8-b325-66f4780a04aa"/>
							<gml:surfaceMember xlink:href="#poly-dc90a1e5-2bdf-4792-9e8d-8fea066da935"/>
							<gml:surfaceMember xlink:href="#poly-5c9821e5-f1af-48ae-afee-f4037d3012f5"/>
							<gml:surfaceMember xlink:href="#poly-8eb537ae-6891-4ae5-acf7-3c965072235b"/>
							<gml:surfaceMember xlink:href="#poly-668b4de2-f741-4072-a3e9-9af95b767afb"/>
							<gml:surfaceMember xlink:href="#poly-8822789f-34df-4794-a781-f460a87c74dd"/>
							<gml:surfaceMember xlink:href="#poly-79a70a04-da9e-4985-855d-96d48c8aec25"/>
							<gml:surfaceMember xlink:href="#poly-9715fb54-472a-4ec3-9828-8329b4ea69da"/>
							<gml:surfaceMember xlink:href="#poly-65eb946a-1582-4069-b84a-18407d6f08c4"/>
							<gml:surfaceMember xlink:href="#poly-822e988a-e447-4740-ae6d-982b6af7ce79"/>
							<gml:surfaceMember xlink:href="#poly-593b1420-8b07-4dbd-82ab-91306072a849"/>
							<gml:surfaceMember xlink:href="#poly-1e399df1-e9eb-4a1f-a171-09175350ceeb"/>
							<gml:surfaceMember xlink:href="#poly-74edac7b-d92e-46e5-b44a-dc0db88d264a"/>
							<gml:surfaceMember xlink:href="#poly-b431c059-5f1d-4a6b-98fe-a619027b6581"/>
							<gml:surfaceMember xlink:href="#poly-1fd0e0c0-0884-48af-ab35-e43998768584"/>
							<gml:surfaceMember xlink:href="#poly-dd5f6814-0748-4654-b185-5f202572da30"/>
							<gml:surfaceMember xlink:href="#poly-24e25268-3853-432c-ba53-3418cc39b5d1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4b1dcf3f-1abf-4dcb-b11c-cd23a2bec2a2_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9e16172-cf81-43ff-9f8b-01464679cd7c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670145133692166 139.7443547441335 8.64 35.6701564752022 139.7443089891128 8.64 35.67017742888668 139.7443167976257 8.64 35.67016608736557 139.744362541611 8.64 35.670145133692166 139.7443547441335 8.64</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-752d3718-9bf0-4ed4-bdf1-a6f4e7c409e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-752d3718-9bf0-4ed4-bdf1-a6f4e7c409e7_0">
											<gml:posList>35.6701564752022 139.7443089891128 20.233 35.6701564752022 139.7443089891128 8.64 35.670145133692166 139.7443547441335 8.64 35.670145133692166 139.7443547441335 21.527 35.670153967861644 139.74431912128847 20.233 35.6701564752022 139.7443089891128 20.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ffcab47-17f0-4d91-86a9-3eee8afbe93d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ffcab47-17f0-4d91-86a9-3eee8afbe93d_0">
											<gml:posList>35.67016390379447 139.7443229101607 20.233 35.670153967861644 139.74431912128847 20.233 35.670145133692166 139.7443547441335 21.527 35.67015543020549 139.74435857679447 21.527 35.67016390379447 139.7443229101607 20.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50dd1e35-6222-4589-ac3c-a7fe80cd11b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50dd1e35-6222-4589-ac3c-a7fe80cd11b3_0">
											<gml:posList>35.670145133692166 139.7443547441335 21.527 35.670145133692166 139.7443547441335 8.64 35.67016608736557 139.744362541611 8.64 35.67016608736557 139.744362541611 19.083 35.67015543020549 139.74435857679447 19.083 35.67015543020549 139.74435857679447 21.527 35.670145133692166 139.7443547441335 21.527</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e3a1713-ab13-417c-bdcb-203830727b03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e3a1713-ab13-417c-bdcb-203830727b03_0">
											<gml:posList>35.67016390379447 139.7443229101607 20.233 35.67015543020549 139.74435857679447 21.527 35.67015543020549 139.74435857679447 19.083 35.67016390379447 139.7443229101607 20.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-be5512b3-6c27-4ee0-8abc-427c00db0752">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-be5512b3-6c27-4ee0-8abc-427c00db0752_0">
											<gml:posList>35.670166338943865 139.74431266760172 20.233 35.6701564752022 139.7443089891128 20.233 35.670153967861644 139.74431912128847 20.233 35.67016390379447 139.7443229101607 20.233 35.670166338943865 139.74431266760172 20.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fc97c7b-0cb7-4816-8e8a-0ca22c6aac27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fc97c7b-0cb7-4816-8e8a-0ca22c6aac27_0">
											<gml:posList>35.67016608736557 139.744362541611 19.083 35.67017487660751 139.74432710659335 20.233 35.67016390379447 139.7443229101607 20.233 35.67015543020549 139.74435857679447 19.083 35.67016608736557 139.744362541611 19.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10f57b76-0278-4e62-a6cf-355493e22360">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10f57b76-0278-4e62-a6cf-355493e22360_0">
											<gml:posList>35.67017742888668 139.7443167976257 20.233 35.67017742888668 139.7443167976257 8.64 35.6701564752022 139.7443089891128 8.64 35.6701564752022 139.7443089891128 20.233 35.670166338943865 139.74431266760172 20.233 35.67017742888668 139.7443167976257 20.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00a0a2b9-155b-44e4-b5c7-4e3527f05048">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00a0a2b9-155b-44e4-b5c7-4e3527f05048_0">
											<gml:posList>35.67017487660751 139.74432710659335 20.233 35.67017742888668 139.7443167976257 20.233 35.670166338943865 139.74431266760172 20.233 35.67016390379447 139.7443229101607 20.233 35.67017487660751 139.74432710659335 20.233</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-614133bb-0287-4b78-aa1f-32c17f168086">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-614133bb-0287-4b78-aa1f-32c17f168086_0">
											<gml:posList>35.67016608736557 139.744362541611 19.083 35.67016608736557 139.744362541611 8.64 35.67017742888668 139.7443167976257 8.64 35.67017742888668 139.7443167976257 20.233 35.67017487660751 139.74432710659335 20.233 35.67016608736557 139.744362541611 19.083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4b1dcf3f-1abf-4dcb-b11c-cd23a2bec2a2_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55f447bb-73ba-475c-8232-fe37b62f247e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670162365244394 139.7443632858387 21.709 35.67018789926001 139.74437293400516 21.709 35.670184070666444 139.74438817100815 21.709 35.670182673155736 139.74438765338556 21.709 35.670158500678745 139.7443786333395 21.709 35.670162365244394 139.7443632858387 21.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15f25c8c-0666-473a-93b5-998639bfcdb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15f25c8c-0666-473a-93b5-998639bfcdb8_0">
											<gml:posList>35.670158500678745 139.7443786333395 21.709 35.670158500678745 139.7443786333395 24.078 35.670162365244394 139.7443632858387 24.078 35.670162365244394 139.7443632858387 21.709 35.670158500678745 139.7443786333395 21.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a13e282d-ea11-4d10-b55a-092831ec6eb1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a13e282d-ea11-4d10-b55a-092831ec6eb1_0">
											<gml:posList>35.670182646106404 139.74438764236933 24.078 35.670158500678745 139.7443786333395 24.078 35.670158500678745 139.7443786333395 21.709 35.670182673155736 139.74438765338556 21.709 35.670182646106404 139.74438764236933 24.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-576a4de8-3c15-4cd1-9048-01bb4a8b5b6e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-576a4de8-3c15-4cd1-9048-01bb4a8b5b6e_0">
											<gml:posList>35.670182646106404 139.74438764236933 24.078 35.670184070666444 139.74438817100815 24.078 35.67018789926001 139.74437293400516 24.078 35.670162365244394 139.7443632858387 24.078 35.670158500678745 139.7443786333395 24.078 35.670182646106404 139.74438764236933 24.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77494258-7027-446c-9187-9054f9a958d3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77494258-7027-446c-9187-9054f9a958d3_0">
											<gml:posList>35.670162365244394 139.7443632858387 21.709 35.670162365244394 139.7443632858387 24.078 35.67018789926001 139.74437293400516 24.078 35.67018789926001 139.74437293400516 21.709 35.670162365244394 139.7443632858387 21.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8ec3325-9654-4a58-b0c4-0d00feef7941">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8ec3325-9654-4a58-b0c4-0d00feef7941_0">
											<gml:posList>35.670184070666444 139.74438817100815 24.078 35.670182646106404 139.74438764236933 24.078 35.670182673155736 139.74438765338556 21.709 35.670184070666444 139.74438817100815 21.709 35.670184070666444 139.74438817100815 24.078</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84729974-3cbe-4dc5-a18f-dd45e67c5888">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84729974-3cbe-4dc5-a18f-dd45e67c5888_0">
											<gml:posList>35.67018789926001 139.74437293400516 21.709 35.67018789926001 139.74437293400516 24.078 35.670184070666444 139.74438817100815 24.078 35.670184070666444 139.74438817100815 21.709 35.67018789926001 139.74437293400516 21.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ed304f6d-515f-4bf1-a3c3-7b44711a4bb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed304f6d-515f-4bf1-a3c3-7b44711a4bb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed304f6d-515f-4bf1-a3c3-7b44711a4bb4">
											<gml:posList>35.67011962884725 139.7444578226608 8.46 35.670145133692166 139.7443547441335 8.46 35.67022827218171 139.74438570284707 8.46 35.67020266815167 139.74448877053518 8.46 35.67011962884725 139.7444578226608 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-504c6709-e96c-4deb-b38c-4c01b4884a26">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-504c6709-e96c-4deb-b38c-4c01b4884a26">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-504c6709-e96c-4deb-b38c-4c01b4884a26">
											<gml:posList>35.67011962884725 139.7444578226608 25.9 35.67012168298982 139.7444564837907 25.9 35.6701337614125 139.74440767922218 25.9 35.670132659878185 139.7444051619044 25.9 35.67011962884725 139.7444578226608 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d9b6b2b-ca91-43f0-9bf4-2b53578d62f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d9b6b2b-ca91-43f0-9bf4-2b53578d62f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d9b6b2b-ca91-43f0-9bf4-2b53578d62f0">
											<gml:posList>35.670132659878185 139.7444051619044 28.607 35.67013409236689 139.7444042213864 28.607 35.670141605393766 139.74437382488298 28.607 35.670140837937815 139.74437208043068 28.607 35.670132659878185 139.7444051619044 28.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92a5db1f-2715-4bc7-a61f-0747572f0c25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92a5db1f-2715-4bc7-a61f-0747572f0c25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92a5db1f-2715-4bc7-a61f-0747572f0c25">
											<gml:posList>35.67016114850059 139.74447329659003 25.9 35.670160055989534 139.74447079030674 25.9 35.67012168298982 139.7444564837907 25.9 35.67011962884725 139.7444578226608 25.9 35.67016114850059 139.74447329659003 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-43884b2f-5a6f-4fa3-8ba7-4201ba18ac31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43884b2f-5a6f-4fa3-8ba7-4201ba18ac31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43884b2f-5a6f-4fa3-8ba7-4201ba18ac31">
											<gml:posList>35.67017216142645 139.74442194150208 25.092 35.6701337614125 139.74440767922218 25.092 35.67012168298982 139.7444564837907 25.092 35.670160055989534 139.74447079030674 25.092 35.67017216142645 139.74442194150208 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ba05af5-4dbd-47b3-b2c7-7c3a3f135e42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ba05af5-4dbd-47b3-b2c7-7c3a3f135e42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ba05af5-4dbd-47b3-b2c7-7c3a3f135e42">
											<gml:posList>35.67017147463795 139.7444195783702 28.607 35.67017071618821 139.74441782286058 28.607 35.67013409236689 139.7444042213864 28.607 35.670132659878185 139.7444051619044 28.607 35.67017147463795 139.7444195783702 28.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d07b9931-4f83-4bd3-b6cc-961531204eb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d07b9931-4f83-4bd3-b6cc-961531204eb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d07b9931-4f83-4bd3-b6cc-961531204eb4">
											<gml:posList>35.67017147463795 139.7444195783702 25.9 35.670132659878185 139.7444051619044 25.9 35.6701337614125 139.74440767922218 25.9 35.67017216142645 139.74442194150208 25.9 35.67017147463795 139.7444195783702 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b951f7c1-f219-40be-b446-55f43618f9d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b951f7c1-f219-40be-b446-55f43618f9d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b951f7c1-f219-40be-b446-55f43618f9d8">
											<gml:posList>35.67017822924295 139.74438745948325 28.235 35.670141605393766 139.74437382488298 28.235 35.67013409236689 139.7444042213864 28.235 35.67017071618821 139.74441782286058 28.235 35.67017822924295 139.74438745948325 28.235</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8aaef9d-99c4-4b69-9a52-e66e99300f79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8aaef9d-99c4-4b69-9a52-e66e99300f79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8aaef9d-99c4-4b69-9a52-e66e99300f79">
											<gml:posList>35.670140837937815 139.74437208043068 28.607 35.670141605393766 139.74437382488298 28.607 35.67017822924295 139.74438745948325 28.607 35.67017965272593 139.7443865300206 28.607 35.670140837937815 139.74437208043068 28.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80ec0227-5f29-45a0-99bd-74e19797b4c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80ec0227-5f29-45a0-99bd-74e19797b4c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80ec0227-5f29-45a0-99bd-74e19797b4c9">
											<gml:posList>35.67016114850059 139.74447329659003 25.9 35.670182402670584 139.7443875542695 25.9 35.67017216142645 139.74442194150208 25.9 35.670160055989534 139.74447079030674 25.9 35.67016114850059 139.74447329659003 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-00dbf2f0-5630-4fbc-bbaf-8e41bd9369dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00dbf2f0-5630-4fbc-bbaf-8e41bd9369dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00dbf2f0-5630-4fbc-bbaf-8e41bd9369dd">
											<gml:posList>35.67017965272593 139.7443865300206 28.607 35.67017822924295 139.74438745948325 28.607 35.67017071618821 139.74441782286058 28.607 35.67017147463795 139.7444195783702 28.607 35.67017965272593 139.7443865300206 28.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92d7fc4b-1a1f-4e50-9ae4-e819a485fc06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92d7fc4b-1a1f-4e50-9ae4-e819a485fc06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92d7fc4b-1a1f-4e50-9ae4-e819a485fc06">
											<gml:posList>35.670182402670584 139.7443875542695 25.9 35.67017965272593 139.7443865300206 25.9 35.67017147463795 139.7444195783702 25.9 35.67017216142645 139.74442194150208 25.9 35.670182402670584 139.7443875542695 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e99e4f7e-b452-425e-abdf-b49eaf821049">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e99e4f7e-b452-425e-abdf-b49eaf821049">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e99e4f7e-b452-425e-abdf-b49eaf821049">
											<gml:posList>35.670209523434096 139.74439765358173 21.709 35.67021381919206 139.74438031727104 21.709 35.670145133692166 139.7443547441335 21.709 35.670140837937815 139.74437208043068 21.709 35.670182402670584 139.7443875542695 21.709 35.670205024345734 139.7443959795444 21.709 35.670209523434096 139.74439765358173 21.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6fb6adb7-8142-43b1-ba6f-644de4c9e67a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6fb6adb7-8142-43b1-ba6f-644de4c9e67a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6fb6adb7-8142-43b1-ba6f-644de4c9e67a">
											<gml:posList>35.67016114850059 139.74447329659003 25.9 35.67020266815167 139.74448877053518 18.2 35.67022396740926 139.7444030391706 18.2 35.670209523434096 139.74439765358173 20.876 35.670205024345734 139.7443959795444 21.709 35.670182402670584 139.7443875542695 25.9 35.67016114850059 139.74447329659003 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-02df4413-5d06-4421-8e08-574455ae03d6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02df4413-5d06-4421-8e08-574455ae03d6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02df4413-5d06-4421-8e08-574455ae03d6">
											<gml:posList>35.67022827218171 139.74438570284707 18.2 35.67021381919206 139.74438031727104 18.2 35.670209523442246 139.74439766462797 18.2 35.67022396740926 139.7444030391706 18.2 35.67022827218171 139.74438570284707 18.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e22c18e-ea50-4f97-9797-9859e5f1e66b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e22c18e-ea50-4f97-9797-9859e5f1e66b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e22c18e-ea50-4f97-9797-9859e5f1e66b">
											<gml:posList>35.67021381919206 139.74438031727104 18.2 35.67022827218171 139.74438570284707 18.2 35.67022827218171 139.74438570284707 8.46 35.670145133692166 139.7443547441335 8.46 35.670145133692166 139.7443547441335 21.709 35.67021381919206 139.74438031727104 21.709 35.67021381919206 139.74438031727104 18.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36775f0c-90e0-4b8c-b37d-9f0275c22544">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36775f0c-90e0-4b8c-b37d-9f0275c22544">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36775f0c-90e0-4b8c-b37d-9f0275c22544">
											<gml:posList>35.67017965272593 139.7443865300206 25.9 35.670182402670584 139.7443875542695 25.9 35.670182402670584 139.7443875542695 21.709 35.670140837937815 139.74437208043068 21.709 35.670140837937815 139.74437208043068 28.607 35.67017965272593 139.7443865300206 28.607 35.67017965272593 139.7443865300206 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e92d224-cad6-46a8-b325-66f4780a04aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e92d224-cad6-46a8-b325-66f4780a04aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e92d224-cad6-46a8-b325-66f4780a04aa">
											<gml:posList>35.670141605393766 139.74437382488298 28.607 35.670141605393766 139.74437382488298 28.235 35.67017822924295 139.74438745948325 28.235 35.67017822924295 139.74438745948325 28.607 35.670141605393766 139.74437382488298 28.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dc90a1e5-2bdf-4792-9e8d-8fea066da935">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc90a1e5-2bdf-4792-9e8d-8fea066da935">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc90a1e5-2bdf-4792-9e8d-8fea066da935">
											<gml:posList>35.67013409236689 139.7444042213864 28.607 35.67013409236689 139.7444042213864 28.235 35.670141605393766 139.74437382488298 28.235 35.670141605393766 139.74437382488298 28.607 35.67013409236689 139.7444042213864 28.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5c9821e5-f1af-48ae-afee-f4037d3012f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5c9821e5-f1af-48ae-afee-f4037d3012f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5c9821e5-f1af-48ae-afee-f4037d3012f5">
											<gml:posList>35.67021381919206 139.74438031727104 21.709 35.670209523434096 139.74439765358173 21.709 35.670209523434096 139.74439765358173 20.876 35.670209523442246 139.74439766462797 18.2 35.67021381919206 139.74438031727104 18.2 35.67021381919206 139.74438031727104 21.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8eb537ae-6891-4ae5-acf7-3c965072235b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8eb537ae-6891-4ae5-acf7-3c965072235b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8eb537ae-6891-4ae5-acf7-3c965072235b">
											<gml:posList>35.670182402670584 139.7443875542695 21.709 35.670182402670584 139.7443875542695 25.9 35.670205024345734 139.7443959795444 21.709 35.670182402670584 139.7443875542695 21.709</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-668b4de2-f741-4072-a3e9-9af95b767afb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-668b4de2-f741-4072-a3e9-9af95b767afb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-668b4de2-f741-4072-a3e9-9af95b767afb">
											<gml:posList>35.670209523434096 139.74439765358173 20.876 35.670209523434096 139.74439765358173 21.709 35.670205024345734 139.7443959795444 21.709 35.670209523434096 139.74439765358173 20.876</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8822789f-34df-4794-a781-f460a87c74dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8822789f-34df-4794-a781-f460a87c74dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8822789f-34df-4794-a781-f460a87c74dd">
											<gml:posList>35.670209523434096 139.74439765358173 20.876 35.67022396740926 139.7444030391706 18.2 35.670209523442246 139.74439766462797 18.2 35.670209523434096 139.74439765358173 20.876</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79a70a04-da9e-4985-855d-96d48c8aec25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79a70a04-da9e-4985-855d-96d48c8aec25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79a70a04-da9e-4985-855d-96d48c8aec25">
											<gml:posList>35.67017822924295 139.74438745948325 28.607 35.67017822924295 139.74438745948325 28.235 35.67017071618821 139.74441782286058 28.235 35.67017071618821 139.74441782286058 28.607 35.67017822924295 139.74438745948325 28.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9715fb54-472a-4ec3-9828-8329b4ea69da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9715fb54-472a-4ec3-9828-8329b4ea69da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9715fb54-472a-4ec3-9828-8329b4ea69da">
											<gml:posList>35.67017965272593 139.7443865300206 28.607 35.67017147463795 139.7444195783702 28.607 35.67017147463795 139.7444195783702 25.9 35.67017965272593 139.7443865300206 25.9 35.67017965272593 139.7443865300206 28.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-65eb946a-1582-4069-b84a-18407d6f08c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-65eb946a-1582-4069-b84a-18407d6f08c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-65eb946a-1582-4069-b84a-18407d6f08c4">
											<gml:posList>35.670132659878185 139.7444051619044 25.9 35.670132659878185 139.7444051619044 28.607 35.670140837937815 139.74437208043068 28.607 35.670140837937815 139.74437208043068 21.709 35.670145133692166 139.7443547441335 21.709 35.670145133692166 139.7443547441335 8.46 35.67011962884725 139.7444578226608 8.46 35.67011962884725 139.7444578226608 25.9 35.670132659878185 139.7444051619044 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-822e988a-e447-4740-ae6d-982b6af7ce79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-822e988a-e447-4740-ae6d-982b6af7ce79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-822e988a-e447-4740-ae6d-982b6af7ce79">
											<gml:posList>35.67017071618821 139.74441782286058 28.607 35.67017071618821 139.74441782286058 28.235 35.67013409236689 139.7444042213864 28.235 35.67013409236689 139.7444042213864 28.607 35.67017071618821 139.74441782286058 28.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-593b1420-8b07-4dbd-82ab-91306072a849">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-593b1420-8b07-4dbd-82ab-91306072a849">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-593b1420-8b07-4dbd-82ab-91306072a849">
											<gml:posList>35.67017147463795 139.7444195783702 28.607 35.670132659878185 139.7444051619044 28.607 35.670132659878185 139.7444051619044 25.9 35.67017147463795 139.7444195783702 25.9 35.67017147463795 139.7444195783702 28.607</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e399df1-e9eb-4a1f-a171-09175350ceeb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e399df1-e9eb-4a1f-a171-09175350ceeb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e399df1-e9eb-4a1f-a171-09175350ceeb">
											<gml:posList>35.6701337614125 139.74440767922218 25.9 35.6701337614125 139.74440767922218 25.092 35.67017216142645 139.74442194150208 25.092 35.67017216142645 139.74442194150208 25.9 35.6701337614125 139.74440767922218 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74edac7b-d92e-46e5-b44a-dc0db88d264a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74edac7b-d92e-46e5-b44a-dc0db88d264a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74edac7b-d92e-46e5-b44a-dc0db88d264a">
											<gml:posList>35.67012168298982 139.7444564837907 25.9 35.67012168298982 139.7444564837907 25.092 35.6701337614125 139.74440767922218 25.092 35.6701337614125 139.74440767922218 25.9 35.67012168298982 139.7444564837907 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b431c059-5f1d-4a6b-98fe-a619027b6581">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b431c059-5f1d-4a6b-98fe-a619027b6581">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b431c059-5f1d-4a6b-98fe-a619027b6581">
											<gml:posList>35.67020266815167 139.74448877053518 8.46 35.67022827218171 139.74438570284707 8.46 35.67022827218171 139.74438570284707 18.2 35.67022396740926 139.7444030391706 18.2 35.67020266815167 139.74448877053518 18.2 35.67020266815167 139.74448877053518 8.46</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1fd0e0c0-0884-48af-ab35-e43998768584">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1fd0e0c0-0884-48af-ab35-e43998768584">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1fd0e0c0-0884-48af-ab35-e43998768584">
											<gml:posList>35.67017216142645 139.74442194150208 25.9 35.67017216142645 139.74442194150208 25.092 35.670160055989534 139.74447079030674 25.092 35.670160055989534 139.74447079030674 25.9 35.67017216142645 139.74442194150208 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd5f6814-0748-4654-b185-5f202572da30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd5f6814-0748-4654-b185-5f202572da30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd5f6814-0748-4654-b185-5f202572da30">
											<gml:posList>35.670160055989534 139.74447079030674 25.9 35.670160055989534 139.74447079030674 25.092 35.67012168298982 139.7444564837907 25.092 35.67012168298982 139.7444564837907 25.9 35.670160055989534 139.74447079030674 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24e25268-3853-432c-ba53-3418cc39b5d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24e25268-3853-432c-ba53-3418cc39b5d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24e25268-3853-432c-ba53-3418cc39b5d1">
											<gml:posList>35.67011962884725 139.7444578226608 25.9 35.67011962884725 139.7444578226608 8.46 35.67020266815167 139.74448877053518 8.46 35.67020266815167 139.74448877053518 18.2 35.67016114850059 139.74447329659003 25.9 35.67011962884725 139.7444578226608 25.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5312</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">80.2555</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>