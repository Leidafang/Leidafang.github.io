<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4b8a7b10-359c-4487-8872-a70f80bee6d3">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">21.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668371284453706 139.73905869472148 0 35.66836893214814 139.7390590509586 0 35.668366389017635 139.7390344214091 0 35.668286266513284 139.73904666620396 0 35.66828808370093 139.7390651108389 0 35.66827032882354 139.7390678932046 0 35.6682795026083 139.7391572443163 0 35.66829997991819 139.73917787623458 0 35.66838406795672 139.73916496415245 0 35.66840135357472 139.73913843348393 0 35.6683973918983 139.73909793250672 0 35.66837550907137 139.73910115051356 0 35.668371284453706 139.73905869472148 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668371284453706 139.73905869472148 12.68 35.66837550907137 139.73910115051356 12.68 35.6683973918983 139.73909793250672 12.68 35.66840135357472 139.73913843348393 12.68 35.66838406795672 139.73916496415245 12.68 35.66829997991819 139.73917787623458 12.68 35.6682795026083 139.7391572443163 12.68 35.66827032882354 139.7390678932046 12.68 35.66828808370093 139.7390651108389 12.68 35.668286266513284 139.73904666620396 12.68 35.668366389017635 139.7390344214091 12.68 35.66836893214814 139.7390590509586 12.68 35.668371284453706 139.73905869472148 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668371284453706 139.73905869472148 12.68 35.66836893214814 139.7390590509586 12.68 35.66836893214814 139.7390590509586 34.04 35.668371284453706 139.73905869472148 34.04 35.668371284453706 139.73905869472148 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66836893214814 139.7390590509586 12.68 35.668366389017635 139.7390344214091 12.68 35.668366389017635 139.7390344214091 34.04 35.66836893214814 139.7390590509586 34.04 35.66836893214814 139.7390590509586 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668366389017635 139.7390344214091 12.68 35.668286266513284 139.73904666620396 12.68 35.668286266513284 139.73904666620396 34.04 35.668366389017635 139.7390344214091 34.04 35.668366389017635 139.7390344214091 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668286266513284 139.73904666620396 12.68 35.66828808370093 139.7390651108389 12.68 35.66828808370093 139.7390651108389 34.04 35.668286266513284 139.73904666620396 34.04 35.668286266513284 139.73904666620396 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66828808370093 139.7390651108389 12.68 35.66827032882354 139.7390678932046 12.68 35.66827032882354 139.7390678932046 34.04 35.66828808370093 139.7390651108389 34.04 35.66828808370093 139.7390651108389 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66827032882354 139.7390678932046 12.68 35.6682795026083 139.7391572443163 12.68 35.6682795026083 139.7391572443163 34.04 35.66827032882354 139.7390678932046 34.04 35.66827032882354 139.7390678932046 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6682795026083 139.7391572443163 12.68 35.66829997991819 139.73917787623458 12.68 35.66829997991819 139.73917787623458 34.04 35.6682795026083 139.7391572443163 34.04 35.6682795026083 139.7391572443163 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66829997991819 139.73917787623458 12.68 35.66838406795672 139.73916496415245 12.68 35.66838406795672 139.73916496415245 34.04 35.66829997991819 139.73917787623458 34.04 35.66829997991819 139.73917787623458 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66838406795672 139.73916496415245 12.68 35.66840135357472 139.73913843348393 12.68 35.66840135357472 139.73913843348393 34.04 35.66838406795672 139.73916496415245 34.04 35.66838406795672 139.73916496415245 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66840135357472 139.73913843348393 12.68 35.6683973918983 139.73909793250672 12.68 35.6683973918983 139.73909793250672 34.04 35.66840135357472 139.73913843348393 34.04 35.66840135357472 139.73913843348393 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683973918983 139.73909793250672 12.68 35.66837550907137 139.73910115051356 12.68 35.66837550907137 139.73910115051356 34.04 35.6683973918983 139.73909793250672 34.04 35.6683973918983 139.73909793250672 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66837550907137 139.73910115051356 12.68 35.668371284453706 139.73905869472148 12.68 35.668371284453706 139.73905869472148 34.04 35.66837550907137 139.73910115051356 34.04 35.66837550907137 139.73910115051356 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668371284453706 139.73905869472148 34.04 35.66836893214814 139.7390590509586 34.04 35.668366389017635 139.7390344214091 34.04 35.668286266513284 139.73904666620396 34.04 35.66828808370093 139.7390651108389 34.04 35.66827032882354 139.7390678932046 34.04 35.6682795026083 139.7391572443163 34.04 35.66829997991819 139.73917787623458 34.04 35.66838406795672 139.73916496415245 34.04 35.66840135357472 139.73913843348393 34.04 35.6683973918983 139.73909793250672 34.04 35.66837550907137 139.73910115051356 34.04 35.668371284453706 139.73905869472148 34.04</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0eca079b-8c1f-49d1-b195-ec70d92ae160"/>
							<gml:surfaceMember xlink:href="#poly-9b6f944c-a9eb-48c6-96dc-2a6113a9d2ee"/>
							<gml:surfaceMember xlink:href="#poly-38204af6-7815-4796-99c4-7c7f6339a3ad"/>
							<gml:surfaceMember xlink:href="#poly-1e955bfc-3410-43e6-8abb-5bd766a3522a"/>
							<gml:surfaceMember xlink:href="#poly-4cded97d-857a-411a-8bd9-01901b250322"/>
							<gml:surfaceMember xlink:href="#poly-552e2511-457c-442b-8d60-04148f828f44"/>
							<gml:surfaceMember xlink:href="#poly-1a3308fe-9dbc-4696-ab00-5db645b3476c"/>
							<gml:surfaceMember xlink:href="#poly-14ecbc77-b5c6-435f-bb49-f7754ba67a80"/>
							<gml:surfaceMember xlink:href="#poly-e2249bab-b613-4ac4-ab62-009ff4b24efc"/>
							<gml:surfaceMember xlink:href="#poly-20519b7e-f2a5-4d23-b1bd-5f9ca5655667"/>
							<gml:surfaceMember xlink:href="#poly-196d8fe9-867d-45cd-b74e-ffcf76b44924"/>
							<gml:surfaceMember xlink:href="#poly-c1e61cd1-8fba-4231-bc37-f35c63c3fb31"/>
							<gml:surfaceMember xlink:href="#poly-2a31afcf-31d6-4c61-8a03-80c56214984e"/>
							<gml:surfaceMember xlink:href="#poly-8aac66c6-5923-4014-9176-c749ec27a759"/>
							<gml:surfaceMember xlink:href="#poly-2d1e08b2-152e-4617-bded-2645e6f1fd4a"/>
							<gml:surfaceMember xlink:href="#poly-c253429e-4ded-4b0d-93ec-c0b5a300052b"/>
							<gml:surfaceMember xlink:href="#poly-787cd582-2424-4e4e-b6b4-5d65bf361bc0"/>
							<gml:surfaceMember xlink:href="#poly-6c2b57e9-9409-4f76-abaa-8512d0305fee"/>
							<gml:surfaceMember xlink:href="#poly-b4688638-49eb-40fa-8d6e-e58cacb243a7"/>
							<gml:surfaceMember xlink:href="#poly-a7001610-68b3-49bd-bb62-eb96d8883597"/>
							<gml:surfaceMember xlink:href="#poly-769193eb-fffc-464e-ab2b-fb8ea5beff48"/>
							<gml:surfaceMember xlink:href="#poly-1d7e8df8-12b2-463d-9b74-5a7b212d0c54"/>
							<gml:surfaceMember xlink:href="#poly-ef906677-37df-483c-b893-174ed74027d4"/>
							<gml:surfaceMember xlink:href="#poly-331300c1-1b8d-40e5-a9d7-10ba5d0d530c"/>
							<gml:surfaceMember xlink:href="#poly-73b0771c-6ac9-4df8-83cc-bc286c468b86"/>
							<gml:surfaceMember xlink:href="#poly-46039bfc-286c-4237-9913-d45890e50be7"/>
							<gml:surfaceMember xlink:href="#poly-5b0ba99d-c50a-4b6a-93a6-129d656e89f0"/>
							<gml:surfaceMember xlink:href="#poly-80bba9da-2511-47d3-87f4-40303c3759b0"/>
							<gml:surfaceMember xlink:href="#poly-0b034bd3-4ff7-425e-ac4e-ef7de083b71d"/>
							<gml:surfaceMember xlink:href="#poly-9323d887-9ad1-4ebf-a9ce-5ebfcbc29862"/>
							<gml:surfaceMember xlink:href="#poly-87ab7b07-c3d9-4962-a573-820ecd7d7ea2"/>
							<gml:surfaceMember xlink:href="#poly-00fd61d0-6809-458f-995c-af3009cc8fd5"/>
							<gml:surfaceMember xlink:href="#poly-7ba19650-e8e4-4584-96c8-bdeb01ced12b"/>
							<gml:surfaceMember xlink:href="#poly-02521ec2-83f5-4206-8a79-dd7a4ffe410e"/>
							<gml:surfaceMember xlink:href="#poly-8c8137f6-f780-4f25-a04f-b006a6388751"/>
							<gml:surfaceMember xlink:href="#poly-080480a8-eea3-4f95-a42c-0bd407500dc2"/>
							<gml:surfaceMember xlink:href="#poly-9a13109d-59d6-461b-8edc-2b372b96da48"/>
							<gml:surfaceMember xlink:href="#poly-5f3b2209-727b-4c46-9e97-14e3bbe2fa9c"/>
							<gml:surfaceMember xlink:href="#poly-7e27f3bd-b7b6-44af-bbfc-1094ae740b83"/>
							<gml:surfaceMember xlink:href="#poly-1782270f-6c8b-41ee-a8ea-5132e06ae053"/>
							<gml:surfaceMember xlink:href="#poly-d2f0d0b4-0eb7-46d7-8da8-2f6e6d461a5c"/>
							<gml:surfaceMember xlink:href="#poly-705d91e0-65be-4a61-873f-2dc7a95c978f"/>
							<gml:surfaceMember xlink:href="#poly-b86b4968-23f9-4c71-8ff8-78f6ed9e012a"/>
							<gml:surfaceMember xlink:href="#poly-1660760b-d04e-4fbe-a756-940968f8004f"/>
							<gml:surfaceMember xlink:href="#poly-d836ab0f-a2a6-4ebf-9d64-fe563f10bcb4"/>
							<gml:surfaceMember xlink:href="#poly-8dee8a24-1941-45aa-b474-c57fbce1d9fc"/>
							<gml:surfaceMember xlink:href="#poly-8cde5849-774f-48e2-84a2-bf9f111144d9"/>
							<gml:surfaceMember xlink:href="#poly-c1182bd5-2bf5-49f9-8615-ad6ae38babcd"/>
							<gml:surfaceMember xlink:href="#poly-048b4ca1-7cbb-4430-913d-8cd7b670bb6a"/>
							<gml:surfaceMember xlink:href="#poly-e80e6499-099e-4e6b-afee-61a298c2e34f"/>
							<gml:surfaceMember xlink:href="#poly-fc66c7b6-3554-47d7-b7e6-9b92288597d9"/>
							<gml:surfaceMember xlink:href="#poly-d0467bf5-c687-49ee-935c-f61dc28ffd67"/>
							<gml:surfaceMember xlink:href="#poly-5ac0f781-8152-446d-960d-5f83d66f2b57"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4b8a7b10-359c-4487-8872-a70f80bee6d3_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99ee9061-ecc2-439b-aaf9-038f32730483">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668297463312534 139.73911798792744 34.251 35.668293501733025 139.73907761955525 34.251 35.66832030549168 139.73907367777215 34.251 35.66832425805878 139.73911404616823 34.251 35.66832632974611 139.73913520782463 34.251 35.668299534999164 139.73913914957686 34.251 35.668297463312534 139.73911798792744 34.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00f076d6-338e-4030-ae89-f3eeb3fe1fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00f076d6-338e-4030-ae89-f3eeb3fe1fa4_0">
											<gml:posList>35.66832030549168 139.73907367777215 34.251 35.668293501733025 139.73907761955525 34.251 35.668293501733025 139.73907761955525 35.932 35.66832030549168 139.73907367777215 35.932 35.66832030549168 139.73907367777215 34.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a891678-94ce-4091-bdc2-28f87290858f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a891678-94ce-4091-bdc2-28f87290858f_0">
											<gml:posList>35.66832030549168 139.73907367777215 34.251 35.66832030549168 139.73907367777215 35.932 35.66832425805878 139.73911404616823 35.932 35.66832425805878 139.73911404616823 34.251 35.66832030549168 139.73907367777215 34.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4394c8dc-56fe-4b3f-91df-5ffd2b619d2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4394c8dc-56fe-4b3f-91df-5ffd2b619d2b_0">
											<gml:posList>35.66832030549168 139.73907367777215 35.932 35.668293501733025 139.73907761955525 35.932 35.668297463312534 139.73911798792744 35.932 35.66832425805878 139.73911404616823 35.932 35.66832030549168 139.73907367777215 35.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f229c999-bf8f-44de-a1fa-f4ed2a3f968d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f229c999-bf8f-44de-a1fa-f4ed2a3f968d_0">
											<gml:posList>35.668293501733025 139.73907761955525 34.251 35.668297463312534 139.73911798792744 34.251 35.668297463312534 139.73911798792744 35.932 35.668293501733025 139.73907761955525 35.932 35.668293501733025 139.73907761955525 34.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1cd0060-1f8f-4a5f-9e4b-909e8f4d9bae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e1cd0060-1f8f-4a5f-9e4b-909e8f4d9bae_0">
											<gml:posList>35.668297463312534 139.73911798792744 35.932 35.668297463312534 139.73911798792744 36.273 35.66832425805878 139.73911404616823 36.273 35.66832425805878 139.73911404616823 35.932 35.668297463312534 139.73911798792744 35.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-087d9c15-67b3-4359-b455-6f4512d02eef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-087d9c15-67b3-4359-b455-6f4512d02eef_0">
											<gml:posList>35.66832632974611 139.73913520782463 36.273 35.66832632974611 139.73913520782463 34.251 35.66832425805878 139.73911404616823 34.251 35.66832425805878 139.73911404616823 35.932 35.66832425805878 139.73911404616823 36.273 35.66832632974611 139.73913520782463 36.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2115febc-2bed-4c24-b838-bb4dd4f09e7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2115febc-2bed-4c24-b838-bb4dd4f09e7c_0">
											<gml:posList>35.668297463312534 139.73911798792744 36.273 35.668299534999164 139.73913914957686 36.273 35.66832632974611 139.73913520782463 36.273 35.66832425805878 139.73911404616823 36.273 35.668297463312534 139.73911798792744 36.273</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6244c5e-7306-424d-b4c2-9893b4eab32b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6244c5e-7306-424d-b4c2-9893b4eab32b_0">
											<gml:posList>35.668297463312534 139.73911798792744 35.932 35.668297463312534 139.73911798792744 34.251 35.668299534999164 139.73913914957686 34.251 35.668299534999164 139.73913914957686 36.273 35.668297463312534 139.73911798792744 36.273 35.668297463312534 139.73911798792744 35.932</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b329a4e-3712-4c5e-a161-3e6b3d612b7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b329a4e-3712-4c5e-a161-3e6b3d612b7d_0">
											<gml:posList>35.668299534999164 139.73913914957686 34.251 35.66832632974611 139.73913520782463 34.251 35.66832632974611 139.73913520782463 36.273 35.668299534999164 139.73913914957686 36.273 35.668299534999164 139.73913914957686 34.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4b8a7b10-359c-4487-8872-a70f80bee6d3_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03f2e396-71c4-436b-83dc-5a9ef6312356">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6683973918983 139.7390979325067 12.68 35.66837550907136 139.73910115051356 12.68 35.66837128445373 139.73905869472145 12.68 35.66839317621541 139.73905537727882 12.68 35.6683973918983 139.7390979325067 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0be2dffa-34ad-44bf-b105-4a4c702a664e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66835501598899 139.73915253840562 34.251 35.668351454179636 139.73911620131557 34.251 35.66836058404632 139.73911486507006 34.251 35.66836415496484 139.73915132365929 34.251 35.66835501598899 139.73915253840562 34.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13e662da-f9cd-4c06-8822-9ed9c52ac7d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13e662da-f9cd-4c06-8822-9ed9c52ac7d4_0">
											<gml:posList>35.66836058404632 139.73911486507006 34.251 35.668351454179636 139.73911620131557 34.251 35.668351454179636 139.73911620131557 34.626 35.66836058404632 139.73911486507006 34.626 35.66836058404632 139.73911486507006 34.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b9a394a-7cac-459b-a41d-914d16baacbc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b9a394a-7cac-459b-a41d-914d16baacbc_0">
											<gml:posList>35.66835501598899 139.73915253840562 34.626 35.66836415496484 139.73915132365929 34.626 35.66836058404632 139.73911486507006 34.626 35.668351454179636 139.73911620131557 34.626 35.66835501598899 139.73915253840562 34.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-985872bd-6705-4c10-86ae-14d0d5232ed0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-985872bd-6705-4c10-86ae-14d0d5232ed0_0">
											<gml:posList>35.66836058404632 139.73911486507006 34.626 35.66836415496484 139.73915132365929 34.626 35.66836415496484 139.73915132365929 34.251 35.66836058404632 139.73911486507006 34.251 35.66836058404632 139.73911486507006 34.626</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01e5e68f-0e83-4ae0-a8ca-d8aeef615d93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01e5e68f-0e83-4ae0-a8ca-d8aeef615d93_0">
											<gml:posList>35.66837550907136 139.73910115051356 12.68 35.66837550907136 139.73910115051356 34.338 35.66837128445373 139.73905869472145 34.338 35.66837128445373 139.73905869472145 12.68 35.66837550907136 139.73910115051356 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73f84220-0fbd-4b86-a0f8-aa6665331e2a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73f84220-0fbd-4b86-a0f8-aa6665331e2a_0">
											<gml:posList>35.66839317621541 139.73905537727882 34.338 35.66839317621541 139.73905537727882 12.68 35.66837128445373 139.73905869472145 12.68 35.66837128445373 139.73905869472145 34.338 35.66839317621541 139.73905537727882 34.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81ed5ff2-e53a-4263-832f-debb67a93086">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81ed5ff2-e53a-4263-832f-debb67a93086_0">
											<gml:posList>35.66837128445373 139.73905869472145 34.338 35.66837550907136 139.73910115051356 34.338 35.6683973918983 139.7390979325067 34.338 35.66839317621541 139.73905537727882 34.338 35.66837128445373 139.73905869472145 34.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e58a49a2-2fb8-424e-a404-c1ac9423f972">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e58a49a2-2fb8-424e-a404-c1ac9423f972_0">
											<gml:posList>35.66837550907136 139.73910115051356 34.338 35.66837550907136 139.73910115051356 12.68 35.6683973918983 139.7390979325067 12.68 35.6683973918983 139.7390979325067 34.338 35.66837550907136 139.73910115051356 34.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5123bc3c-1c33-44af-b57d-734c35b8d79e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5123bc3c-1c33-44af-b57d-734c35b8d79e_0">
											<gml:posList>35.66839317621541 139.73905537727882 12.68 35.66839317621541 139.73905537727882 34.338 35.6683973918983 139.7390979325067 34.338 35.6683973918983 139.7390979325067 12.68 35.66839317621541 139.73905537727882 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87c76320-164c-4734-9307-58c885c1abd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87c76320-164c-4734-9307-58c885c1abd6_0">
											<gml:posList>35.668351454179636 139.73911620131557 34.251 35.66835501598899 139.73915253840562 34.251 35.66835501598899 139.73915253840562 34.626 35.668351454179636 139.73911620131557 34.626 35.668351454179636 139.73911620131557 34.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dcdfaf73-913d-4951-a14a-aa6f054a8d99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dcdfaf73-913d-4951-a14a-aa6f054a8d99_0">
											<gml:posList>35.66835501598899 139.73915253840562 34.251 35.66836415496484 139.73915132365929 34.251 35.66836415496484 139.73915132365929 34.626 35.66835501598899 139.73915253840562 34.626 35.66835501598899 139.73915253840562 34.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0eca079b-8c1f-49d1-b195-ec70d92ae160">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0eca079b-8c1f-49d1-b195-ec70d92ae160">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0eca079b-8c1f-49d1-b195-ec70d92ae160">
											<gml:posList>35.668299979918196 139.73917787623458 12.68 35.6682795026083 139.73915724431626 12.68 35.668270328823525 139.7390678932046 12.68 35.66828808370092 139.73906511083888 12.68 35.6682862665133 139.73904666620396 12.68 35.668366389017606 139.7390344214091 12.68 35.66836893214815 139.7390590509586 12.68 35.66837128445373 139.73905869472145 12.68 35.66837550907136 139.73910115051356 12.68 35.6683973918983 139.7390979325067 12.68 35.66840135357469 139.73913843348393 12.68 35.66838406795672 139.73916496415245 12.68 35.668299979918196 139.73917787623458 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9b6f944c-a9eb-48c6-96dc-2a6113a9d2ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b6f944c-a9eb-48c6-96dc-2a6113a9d2ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b6f944c-a9eb-48c6-96dc-2a6113a9d2ee">
											<gml:posList>35.6682795026083 139.73915724431626 34.493 35.66828086295518 139.73915631485704 34.493 35.66827194349097 139.739069437742 34.493 35.668270328823525 139.7390678932046 34.493 35.6682795026083 139.73915724431626 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38204af6-7815-4796-99c4-7c7f6339a3ad">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38204af6-7815-4796-99c4-7c7f6339a3ad">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38204af6-7815-4796-99c4-7c7f6339a3ad">
											<gml:posList>35.66828808370092 139.73906511083888 34.493 35.668270328823525 139.7390678932046 34.493 35.66827194349097 139.739069437742 34.493 35.66828968935469 139.73906665538718 34.493 35.66828808370092 139.73906511083888 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e955bfc-3410-43e6-8abb-5bd766a3522a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e955bfc-3410-43e6-8abb-5bd766a3522a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e955bfc-3410-43e6-8abb-5bd766a3522a">
											<gml:posList>35.66828808370092 139.73906511083888 34.493 35.66828968935469 139.73906665538718 34.493 35.668287881181016 139.73904821074126 34.493 35.6682862665133 139.73904666620396 34.493 35.66828808370092 139.73906511083888 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4cded97d-857a-411a-8bd9-01901b250322">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cded97d-857a-411a-8bd9-01901b250322">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cded97d-857a-411a-8bd9-01901b250322">
											<gml:posList>35.668299979918196 139.73917787623458 34.493 35.66830042915343 139.73917601998363 34.493 35.66828086295518 139.73915631485704 34.493 35.6682795026083 139.73915724431626 34.493 35.668299979918196 139.73917787623458 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-552e2511-457c-442b-8d60-04148f828f44">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-552e2511-457c-442b-8d60-04148f828f44">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-552e2511-457c-442b-8d60-04148f828f44">
											<gml:posList>35.6682862665133 139.73904666620396 34.493 35.668287881181016 139.73904821074126 34.493 35.66836513766681 139.73903641115743 34.493 35.668366389017606 139.7390344214091 34.493 35.6682862665133 139.73904666620396 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a3308fe-9dbc-4696-ab00-5db645b3476c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a3308fe-9dbc-4696-ab00-5db645b3476c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a3308fe-9dbc-4696-ab00-5db645b3476c">
											<gml:posList>35.66838330048569 139.73916329711017 34.251 35.66839380689868 139.73914716867802 34.251 35.66836415496484 139.73915132365929 34.251 35.66836042051147 139.73911321941105 34.251 35.66839198297345 139.7391085761475 34.251 35.6683955984873 139.73914442716907 34.251 35.668399829857634 139.73913792715854 34.251 35.66839617658407 139.7390999001205 34.251 35.66837424869709 139.7391031292257 34.251 35.66837001506643 139.73906067344478 34.251 35.66836767177456 139.73906102967123 34.251 35.66836513766681 139.73903641115743 34.251 35.668287881181016 139.73904821074126 34.251 35.66828968935469 139.73906665538718 34.251 35.66827194349097 139.739069437742 34.251 35.66828086295518 139.73915631485704 34.251 35.66830042915343 139.73917601998363 34.251 35.66838330048569 139.73916329711017 34.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-14ecbc77-b5c6-435f-bb49-f7754ba67a80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14ecbc77-b5c6-435f-bb49-f7754ba67a80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14ecbc77-b5c6-435f-bb49-f7754ba67a80">
											<gml:posList>35.66838406795672 139.73916496415245 34.493 35.66838330048569 139.73916329711017 34.493 35.66830042915343 139.73917601998363 34.493 35.668299979918196 139.73917787623458 34.493 35.66838406795672 139.73916496415245 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e2249bab-b613-4ac4-ab62-009ff4b24efc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2249bab-b613-4ac4-ab62-009ff4b24efc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2249bab-b613-4ac4-ab62-009ff4b24efc">
											<gml:posList>35.66836415496484 139.73915132365929 38.418 35.66836531632717 139.73914952180016 38.418 35.668361890855 139.73911463156895 38.418 35.66836042051147 139.73911321941105 38.418 35.66836415496484 139.73915132365929 38.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-20519b7e-f2a5-4d23-b1bd-5f9ca5655667">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-20519b7e-f2a5-4d23-b1bd-5f9ca5655667">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-20519b7e-f2a5-4d23-b1bd-5f9ca5655667">
											<gml:posList>35.66836893214815 139.7390590509586 34.493 35.668366389017606 139.7390344214091 34.493 35.66836513766681 139.73903641115743 34.493 35.66836767177456 139.73906102967123 34.493 35.66836893214815 139.7390590509586 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-196d8fe9-867d-45cd-b74e-ffcf76b44924">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-196d8fe9-867d-45cd-b74e-ffcf76b44924">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-196d8fe9-867d-45cd-b74e-ffcf76b44924">
											<gml:posList>35.66836893214815 139.7390590509586 34.493 35.66836767177456 139.73906102967123 34.493 35.66837001506643 139.73906067344478 34.493 35.66837128445373 139.73905869472145 34.493 35.66836893214815 139.7390590509586 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1e61cd1-8fba-4231-bc37-f35c63c3fb31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1e61cd1-8fba-4231-bc37-f35c63c3fb31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1e61cd1-8fba-4231-bc37-f35c63c3fb31">
											<gml:posList>35.66837550907136 139.73910115051356 34.493 35.66837128445373 139.73905869472145 34.493 35.66837001506643 139.73906067344478 34.493 35.66837424869709 139.7391031292257 34.493 35.66837550907136 139.73910115051356 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2a31afcf-31d6-4c61-8a03-80c56214984e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a31afcf-31d6-4c61-8a03-80c56214984e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a31afcf-31d6-4c61-8a03-80c56214984e">
											<gml:posList>35.66836042051147 139.73911321941105 38.418 35.668361890855 139.73911463156895 38.418 35.66839083061683 139.73911036695122 38.418 35.66839198297345 139.7391085761475 38.418 35.66836042051147 139.73911321941105 38.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8aac66c6-5923-4014-9176-c749ec27a759">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8aac66c6-5923-4014-9176-c749ec27a759">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8aac66c6-5923-4014-9176-c749ec27a759">
											<gml:posList>35.66839426520764 139.73914538973597 37.869 35.66839083061683 139.73911036695122 37.869 35.668361890855 139.73911463156895 37.869 35.66836531632717 139.73914952180016 37.869 35.66839426520764 139.73914538973597 37.869</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d1e08b2-152e-4617-bded-2645e6f1fd4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d1e08b2-152e-4617-bded-2645e6f1fd4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d1e08b2-152e-4617-bded-2645e6f1fd4a">
											<gml:posList>35.66839584378461 139.73914689013577 38.418 35.66839426520764 139.73914538973597 38.418 35.66836531632717 139.73914952180016 38.418 35.66836415496484 139.73915132365929 38.418 35.66839584378461 139.73914689013577 38.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c253429e-4ded-4b0d-93ec-c0b5a300052b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c253429e-4ded-4b0d-93ec-c0b5a300052b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c253429e-4ded-4b0d-93ec-c0b5a300052b">
											<gml:posList>35.66839617658407 139.7390999001205 34.493 35.6683973918983 139.7390979325067 34.493 35.66837550907136 139.73910115051356 34.493 35.66837424869709 139.7391031292257 34.493 35.66839617658407 139.7390999001205 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-787cd582-2424-4e4e-b6b4-5d65bf361bc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-787cd582-2424-4e4e-b6b4-5d65bf361bc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-787cd582-2424-4e4e-b6b4-5d65bf361bc0">
											<gml:posList>35.66838406795672 139.73916496415245 34.493 35.66839584378461 139.73914689013577 34.493 35.66839380689868 139.73914716867802 34.493 35.66838330048569 139.73916329711017 34.493 35.66838406795672 139.73916496415245 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6c2b57e9-9409-4f76-abaa-8512d0305fee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6c2b57e9-9409-4f76-abaa-8512d0305fee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6c2b57e9-9409-4f76-abaa-8512d0305fee">
											<gml:posList>35.66839198297345 139.7391085761475 38.418 35.66839083061683 139.73911036695122 38.418 35.66839426520764 139.73914538973597 38.418 35.66839584378461 139.73914689013577 38.418 35.66839198297345 139.7391085761475 38.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4688638-49eb-40fa-8d6e-e58cacb243a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4688638-49eb-40fa-8d6e-e58cacb243a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4688638-49eb-40fa-8d6e-e58cacb243a7">
											<gml:posList>35.6683955984873 139.73914442716907 34.493 35.66839584378461 139.73914689013577 34.493 35.66840135357469 139.73913843348393 34.493 35.668399829857634 139.73913792715854 34.493 35.6683955984873 139.73914442716907 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a7001610-68b3-49bd-bb62-eb96d8883597">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a7001610-68b3-49bd-bb62-eb96d8883597">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a7001610-68b3-49bd-bb62-eb96d8883597">
											<gml:posList>35.66839617658407 139.7390999001205 34.493 35.668399829857634 139.73913792715854 34.493 35.66840135357469 139.73913843348393 34.493 35.6683973918983 139.7390979325067 34.493 35.66839617658407 139.7390999001205 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-769193eb-fffc-464e-ab2b-fb8ea5beff48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-769193eb-fffc-464e-ab2b-fb8ea5beff48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-769193eb-fffc-464e-ab2b-fb8ea5beff48">
											<gml:posList>35.668270328823525 139.7390678932046 12.68 35.6682795026083 139.73915724431626 12.68 35.6682795026083 139.73915724431626 34.493 35.668270328823525 139.7390678932046 34.493 35.668270328823525 139.7390678932046 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1d7e8df8-12b2-463d-9b74-5a7b212d0c54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d7e8df8-12b2-463d-9b74-5a7b212d0c54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d7e8df8-12b2-463d-9b74-5a7b212d0c54">
											<gml:posList>35.66828086295518 139.73915631485704 34.493 35.66828086295518 139.73915631485704 34.251 35.66827194349097 139.739069437742 34.251 35.66827194349097 139.739069437742 34.493 35.66828086295518 139.73915631485704 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef906677-37df-483c-b893-174ed74027d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef906677-37df-483c-b893-174ed74027d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef906677-37df-483c-b893-174ed74027d4">
											<gml:posList>35.66828808370092 139.73906511083888 12.68 35.668270328823525 139.7390678932046 12.68 35.668270328823525 139.7390678932046 34.493 35.66828808370092 139.73906511083888 34.493 35.66828808370092 139.73906511083888 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-331300c1-1b8d-40e5-a9d7-10ba5d0d530c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-331300c1-1b8d-40e5-a9d7-10ba5d0d530c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-331300c1-1b8d-40e5-a9d7-10ba5d0d530c">
											<gml:posList>35.66827194349097 139.739069437742 34.493 35.66827194349097 139.739069437742 34.251 35.66828968935469 139.73906665538718 34.251 35.66828968935469 139.73906665538718 34.493 35.66827194349097 139.739069437742 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-73b0771c-6ac9-4df8-83cc-bc286c468b86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-73b0771c-6ac9-4df8-83cc-bc286c468b86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-73b0771c-6ac9-4df8-83cc-bc286c468b86">
											<gml:posList>35.6682862665133 139.73904666620396 12.68 35.66828808370092 139.73906511083888 12.68 35.66828808370092 139.73906511083888 34.493 35.6682862665133 139.73904666620396 34.493 35.6682862665133 139.73904666620396 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-46039bfc-286c-4237-9913-d45890e50be7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46039bfc-286c-4237-9913-d45890e50be7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46039bfc-286c-4237-9913-d45890e50be7">
											<gml:posList>35.66828968935469 139.73906665538718 34.493 35.66828968935469 139.73906665538718 34.251 35.668287881181016 139.73904821074126 34.251 35.668287881181016 139.73904821074126 34.493 35.66828968935469 139.73906665538718 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b0ba99d-c50a-4b6a-93a6-129d656e89f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b0ba99d-c50a-4b6a-93a6-129d656e89f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b0ba99d-c50a-4b6a-93a6-129d656e89f0">
											<gml:posList>35.6682795026083 139.73915724431626 12.68 35.668299979918196 139.73917787623458 12.68 35.668299979918196 139.73917787623458 34.493 35.6682795026083 139.73915724431626 34.493 35.6682795026083 139.73915724431626 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-80bba9da-2511-47d3-87f4-40303c3759b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80bba9da-2511-47d3-87f4-40303c3759b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80bba9da-2511-47d3-87f4-40303c3759b0">
											<gml:posList>35.66830042915343 139.73917601998363 34.493 35.66830042915343 139.73917601998363 34.251 35.66828086295518 139.73915631485704 34.251 35.66828086295518 139.73915631485704 34.493 35.66830042915343 139.73917601998363 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b034bd3-4ff7-425e-ac4e-ef7de083b71d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b034bd3-4ff7-425e-ac4e-ef7de083b71d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b034bd3-4ff7-425e-ac4e-ef7de083b71d">
											<gml:posList>35.668366389017606 139.7390344214091 12.68 35.6682862665133 139.73904666620396 12.68 35.6682862665133 139.73904666620396 34.493 35.668366389017606 139.7390344214091 34.493 35.668366389017606 139.7390344214091 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9323d887-9ad1-4ebf-a9ce-5ebfcbc29862">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9323d887-9ad1-4ebf-a9ce-5ebfcbc29862">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9323d887-9ad1-4ebf-a9ce-5ebfcbc29862">
											<gml:posList>35.668287881181016 139.73904821074126 34.493 35.668287881181016 139.73904821074126 34.251 35.66836513766681 139.73903641115743 34.251 35.66836513766681 139.73903641115743 34.493 35.668287881181016 139.73904821074126 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87ab7b07-c3d9-4962-a573-820ecd7d7ea2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87ab7b07-c3d9-4962-a573-820ecd7d7ea2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87ab7b07-c3d9-4962-a573-820ecd7d7ea2">
											<gml:posList>35.66838330048569 139.73916329711017 34.493 35.66838330048569 139.73916329711017 34.251 35.66830042915343 139.73917601998363 34.251 35.66830042915343 139.73917601998363 34.493 35.66838330048569 139.73916329711017 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00fd61d0-6809-458f-995c-af3009cc8fd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00fd61d0-6809-458f-995c-af3009cc8fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00fd61d0-6809-458f-995c-af3009cc8fd5">
											<gml:posList>35.668299979918196 139.73917787623458 12.68 35.66838406795672 139.73916496415245 12.68 35.66838406795672 139.73916496415245 34.493 35.668299979918196 139.73917787623458 34.493 35.668299979918196 139.73917787623458 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ba19650-e8e4-4584-96c8-bdeb01ced12b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ba19650-e8e4-4584-96c8-bdeb01ced12b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ba19650-e8e4-4584-96c8-bdeb01ced12b">
											<gml:posList>35.66836042051147 139.73911321941105 34.251 35.66836415496484 139.73915132365929 34.251 35.66836415496484 139.73915132365929 38.418 35.66836042051147 139.73911321941105 38.418 35.66836042051147 139.73911321941105 34.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02521ec2-83f5-4206-8a79-dd7a4ffe410e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02521ec2-83f5-4206-8a79-dd7a4ffe410e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02521ec2-83f5-4206-8a79-dd7a4ffe410e">
											<gml:posList>35.66836531632717 139.73914952180016 38.418 35.66836531632717 139.73914952180016 37.869 35.668361890855 139.73911463156895 37.869 35.668361890855 139.73911463156895 38.418 35.66836531632717 139.73914952180016 38.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c8137f6-f780-4f25-a04f-b006a6388751">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c8137f6-f780-4f25-a04f-b006a6388751">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c8137f6-f780-4f25-a04f-b006a6388751">
											<gml:posList>35.66836513766681 139.73903641115743 34.493 35.66836513766681 139.73903641115743 34.251 35.66836767177456 139.73906102967123 34.251 35.66836767177456 139.73906102967123 34.493 35.66836513766681 139.73903641115743 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-080480a8-eea3-4f95-a42c-0bd407500dc2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-080480a8-eea3-4f95-a42c-0bd407500dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-080480a8-eea3-4f95-a42c-0bd407500dc2">
											<gml:posList>35.66836893214815 139.7390590509586 12.68 35.668366389017606 139.7390344214091 12.68 35.668366389017606 139.7390344214091 34.493 35.66836893214815 139.7390590509586 34.493 35.66836893214815 139.7390590509586 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a13109d-59d6-461b-8edc-2b372b96da48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a13109d-59d6-461b-8edc-2b372b96da48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a13109d-59d6-461b-8edc-2b372b96da48">
											<gml:posList>35.66836767177456 139.73906102967123 34.493 35.66836767177456 139.73906102967123 34.251 35.66837001506643 139.73906067344478 34.251 35.66837001506643 139.73906067344478 34.493 35.66836767177456 139.73906102967123 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f3b2209-727b-4c46-9e97-14e3bbe2fa9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f3b2209-727b-4c46-9e97-14e3bbe2fa9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f3b2209-727b-4c46-9e97-14e3bbe2fa9c">
											<gml:posList>35.66837128445373 139.73905869472145 12.68 35.66836893214815 139.7390590509586 12.68 35.66836893214815 139.7390590509586 34.493 35.66837128445373 139.73905869472145 34.493 35.66837128445373 139.73905869472145 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e27f3bd-b7b6-44af-bbfc-1094ae740b83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e27f3bd-b7b6-44af-bbfc-1094ae740b83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e27f3bd-b7b6-44af-bbfc-1094ae740b83">
											<gml:posList>35.66837001506643 139.73906067344478 34.493 35.66837001506643 139.73906067344478 34.251 35.66837424869709 139.7391031292257 34.251 35.66837424869709 139.7391031292257 34.493 35.66837001506643 139.73906067344478 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1782270f-6c8b-41ee-a8ea-5132e06ae053">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1782270f-6c8b-41ee-a8ea-5132e06ae053">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1782270f-6c8b-41ee-a8ea-5132e06ae053">
											<gml:posList>35.66837550907136 139.73910115051356 12.68 35.66837128445373 139.73905869472145 12.68 35.66837128445373 139.73905869472145 34.493 35.66837550907136 139.73910115051356 34.493 35.66837550907136 139.73910115051356 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2f0d0b4-0eb7-46d7-8da8-2f6e6d461a5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2f0d0b4-0eb7-46d7-8da8-2f6e6d461a5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2f0d0b4-0eb7-46d7-8da8-2f6e6d461a5c">
											<gml:posList>35.66836042051147 139.73911321941105 38.418 35.66839198297345 139.7391085761475 38.418 35.66839198297345 139.7391085761475 34.251 35.66836042051147 139.73911321941105 34.251 35.66836042051147 139.73911321941105 38.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-705d91e0-65be-4a61-873f-2dc7a95c978f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-705d91e0-65be-4a61-873f-2dc7a95c978f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-705d91e0-65be-4a61-873f-2dc7a95c978f">
											<gml:posList>35.668361890855 139.73911463156895 38.418 35.668361890855 139.73911463156895 37.869 35.66839083061683 139.73911036695122 37.869 35.66839083061683 139.73911036695122 38.418 35.668361890855 139.73911463156895 38.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b86b4968-23f9-4c71-8ff8-78f6ed9e012a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b86b4968-23f9-4c71-8ff8-78f6ed9e012a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b86b4968-23f9-4c71-8ff8-78f6ed9e012a">
											<gml:posList>35.66839426520764 139.73914538973597 38.418 35.66839426520764 139.73914538973597 37.869 35.66836531632717 139.73914952180016 37.869 35.66836531632717 139.73914952180016 38.418 35.66839426520764 139.73914538973597 38.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1660760b-d04e-4fbe-a756-940968f8004f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1660760b-d04e-4fbe-a756-940968f8004f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1660760b-d04e-4fbe-a756-940968f8004f">
											<gml:posList>35.66839584378461 139.73914689013577 38.418 35.66836415496484 139.73915132365929 38.418 35.66836415496484 139.73915132365929 34.251 35.66839380689868 139.73914716867802 34.251 35.66839380689868 139.73914716867802 34.493 35.66839584378461 139.73914689013577 34.493 35.66839584378461 139.73914689013577 38.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d836ab0f-a2a6-4ebf-9d64-fe563f10bcb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d836ab0f-a2a6-4ebf-9d64-fe563f10bcb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d836ab0f-a2a6-4ebf-9d64-fe563f10bcb4">
											<gml:posList>35.66837424869709 139.7391031292257 34.493 35.66837424869709 139.7391031292257 34.251 35.66839617658407 139.7390999001205 34.251 35.66839617658407 139.7390999001205 34.493 35.66837424869709 139.7391031292257 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8dee8a24-1941-45aa-b474-c57fbce1d9fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dee8a24-1941-45aa-b474-c57fbce1d9fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dee8a24-1941-45aa-b474-c57fbce1d9fc">
											<gml:posList>35.6683973918983 139.7390979325067 12.68 35.66837550907136 139.73910115051356 12.68 35.66837550907136 139.73910115051356 34.493 35.6683973918983 139.7390979325067 34.493 35.6683973918983 139.7390979325067 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cde5849-774f-48e2-84a2-bf9f111144d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cde5849-774f-48e2-84a2-bf9f111144d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cde5849-774f-48e2-84a2-bf9f111144d9">
											<gml:posList>35.66839380689868 139.73914716867802 34.493 35.66839380689868 139.73914716867802 34.251 35.66838330048569 139.73916329711017 34.251 35.66838330048569 139.73916329711017 34.493 35.66839380689868 139.73914716867802 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1182bd5-2bf5-49f9-8615-ad6ae38babcd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1182bd5-2bf5-49f9-8615-ad6ae38babcd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1182bd5-2bf5-49f9-8615-ad6ae38babcd">
											<gml:posList>35.66839083061683 139.73911036695122 38.418 35.66839083061683 139.73911036695122 37.869 35.66839426520764 139.73914538973597 37.869 35.66839426520764 139.73914538973597 38.418 35.66839083061683 139.73911036695122 38.418</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-048b4ca1-7cbb-4430-913d-8cd7b670bb6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-048b4ca1-7cbb-4430-913d-8cd7b670bb6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-048b4ca1-7cbb-4430-913d-8cd7b670bb6a">
											<gml:posList>35.66838406795672 139.73916496415245 12.68 35.66840135357469 139.73913843348393 12.68 35.66840135357469 139.73913843348393 34.493 35.66839584378461 139.73914689013577 34.493 35.66838406795672 139.73916496415245 34.493 35.66838406795672 139.73916496415245 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e80e6499-099e-4e6b-afee-61a298c2e34f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e80e6499-099e-4e6b-afee-61a298c2e34f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e80e6499-099e-4e6b-afee-61a298c2e34f">
											<gml:posList>35.66839198297345 139.7391085761475 34.251 35.66839198297345 139.7391085761475 38.418 35.66839584378461 139.73914689013577 38.418 35.66839584378461 139.73914689013577 34.493 35.6683955984873 139.73914442716907 34.493 35.6683955984873 139.73914442716907 34.251 35.66839198297345 139.7391085761475 34.251</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fc66c7b6-3554-47d7-b7e6-9b92288597d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fc66c7b6-3554-47d7-b7e6-9b92288597d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fc66c7b6-3554-47d7-b7e6-9b92288597d9">
											<gml:posList>35.668399829857634 139.73913792715854 34.493 35.668399829857634 139.73913792715854 34.251 35.6683955984873 139.73914442716907 34.251 35.6683955984873 139.73914442716907 34.493 35.668399829857634 139.73913792715854 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d0467bf5-c687-49ee-935c-f61dc28ffd67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0467bf5-c687-49ee-935c-f61dc28ffd67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0467bf5-c687-49ee-935c-f61dc28ffd67">
											<gml:posList>35.66839617658407 139.7390999001205 34.493 35.66839617658407 139.7390999001205 34.251 35.668399829857634 139.73913792715854 34.251 35.668399829857634 139.73913792715854 34.493 35.66839617658407 139.7390999001205 34.493</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5ac0f781-8152-446d-960d-5f83d66f2b57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ac0f781-8152-446d-960d-5f83d66f2b57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ac0f781-8152-446d-960d-5f83d66f2b57">
											<gml:posList>35.66840135357469 139.73913843348393 12.68 35.6683973918983 139.7390979325067 12.68 35.6683973918983 139.7390979325067 34.493 35.66840135357469 139.73913843348393 34.493 35.66840135357469 139.73913843348393 12.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7738</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">149.4098</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>