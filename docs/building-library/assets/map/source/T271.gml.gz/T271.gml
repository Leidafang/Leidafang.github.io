<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4ba790c9-49d9-48f1-b45a-49aa3c1b1b95">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門一・二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667878588379004 139.74627011360215 0 35.66784410299213 139.7462343291575 0 35.667842176075695 139.7462371258659 0 35.667809792459934 139.74620352625715 0 35.6677967092028 139.74622246210723 0 35.66786356918012 139.74629184617527 0 35.667878588379004 139.74627011360215 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667878588379004 139.74627011360215 6.53 35.66786356918012 139.74629184617527 6.53 35.6677967092028 139.74622246210723 6.53 35.667809792459934 139.74620352625715 6.53 35.667842176075695 139.7462371258659 6.53 35.66784410299213 139.7462343291575 6.53 35.667878588379004 139.74627011360215 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667878588379004 139.74627011360215 6.53 35.66784410299213 139.7462343291575 6.53 35.66784410299213 139.7462343291575 9.530000000000001 35.667878588379004 139.74627011360215 9.530000000000001 35.667878588379004 139.74627011360215 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66784410299213 139.7462343291575 6.53 35.667842176075695 139.7462371258659 6.53 35.667842176075695 139.7462371258659 9.530000000000001 35.66784410299213 139.7462343291575 9.530000000000001 35.66784410299213 139.7462343291575 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667842176075695 139.7462371258659 6.53 35.667809792459934 139.74620352625715 6.53 35.667809792459934 139.74620352625715 9.530000000000001 35.667842176075695 139.7462371258659 9.530000000000001 35.667842176075695 139.7462371258659 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667809792459934 139.74620352625715 6.53 35.6677967092028 139.74622246210723 6.53 35.6677967092028 139.74622246210723 9.530000000000001 35.667809792459934 139.74620352625715 9.530000000000001 35.667809792459934 139.74620352625715 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6677967092028 139.74622246210723 6.53 35.66786356918012 139.74629184617527 6.53 35.66786356918012 139.74629184617527 9.530000000000001 35.6677967092028 139.74622246210723 9.530000000000001 35.6677967092028 139.74622246210723 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66786356918012 139.74629184617527 6.53 35.667878588379004 139.74627011360215 6.53 35.667878588379004 139.74627011360215 9.530000000000001 35.66786356918012 139.74629184617527 9.530000000000001 35.66786356918012 139.74629184617527 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667878588379004 139.74627011360215 9.530000000000001 35.66784410299213 139.7462343291575 9.530000000000001 35.667842176075695 139.7462371258659 9.530000000000001 35.667809792459934 139.74620352625715 9.530000000000001 35.6677967092028 139.74622246210723 9.530000000000001 35.66786356918012 139.74629184617527 9.530000000000001 35.667878588379004 139.74627011360215 9.530000000000001</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-e11b2ea8-f977-4059-8f1a-719dcb0e30c0"/>
							<gml:surfaceMember xlink:href="#poly-5fa4c8d8-a154-4824-b110-080cf06b0bb6"/>
							<gml:surfaceMember xlink:href="#poly-ac9ef5b6-592e-4dec-bdb5-b1dd2f20d3a5"/>
							<gml:surfaceMember xlink:href="#poly-1cf353c3-cf36-4522-b84a-0f1145cdd75f"/>
							<gml:surfaceMember xlink:href="#poly-c6e924fa-b4c3-4340-8a6b-0c10f48e23fb"/>
							<gml:surfaceMember xlink:href="#poly-a9e09ffc-1c80-4c61-94dc-7c79b3437a42"/>
							<gml:surfaceMember xlink:href="#poly-046b65a0-36ef-48fe-80c5-05cbbbca6eba"/>
							<gml:surfaceMember xlink:href="#poly-a26ffecd-c3ce-4a32-9e03-a2a6b978a7d5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-e11b2ea8-f977-4059-8f1a-719dcb0e30c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e11b2ea8-f977-4059-8f1a-719dcb0e30c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e11b2ea8-f977-4059-8f1a-719dcb0e30c0">
											<gml:posList>35.667863569180106 139.74629184617524 6.53 35.667796709202776 139.74622246210723 6.53 35.66780979245995 139.74620352625712 6.53 35.66784217607567 139.74623712586586 6.53 35.667844102992106 139.7462343291575 6.53 35.66787858837901 139.74627011360212 6.53 35.667863569180106 139.74629184617524 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5fa4c8d8-a154-4824-b110-080cf06b0bb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5fa4c8d8-a154-4824-b110-080cf06b0bb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5fa4c8d8-a154-4824-b110-080cf06b0bb6">
											<gml:posList>35.667863569180106 139.74629184617524 9.417 35.66787858837901 139.74627011360212 9.417 35.667844102992106 139.7462343291575 9.417 35.66784217607567 139.74623712586586 9.417 35.66780979245995 139.74620352625712 9.417 35.667796709202776 139.74622246210723 9.417 35.667863569180106 139.74629184617524 9.417</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac9ef5b6-592e-4dec-bdb5-b1dd2f20d3a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac9ef5b6-592e-4dec-bdb5-b1dd2f20d3a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac9ef5b6-592e-4dec-bdb5-b1dd2f20d3a5">
											<gml:posList>35.667796709202776 139.74622246210723 6.53 35.667863569180106 139.74629184617524 6.53 35.667863569180106 139.74629184617524 9.417 35.667796709202776 139.74622246210723 9.417 35.667796709202776 139.74622246210723 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cf353c3-cf36-4522-b84a-0f1145cdd75f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cf353c3-cf36-4522-b84a-0f1145cdd75f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cf353c3-cf36-4522-b84a-0f1145cdd75f">
											<gml:posList>35.66780979245995 139.74620352625712 6.53 35.667796709202776 139.74622246210723 6.53 35.667796709202776 139.74622246210723 9.417 35.66780979245995 139.74620352625712 9.417 35.66780979245995 139.74620352625712 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c6e924fa-b4c3-4340-8a6b-0c10f48e23fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6e924fa-b4c3-4340-8a6b-0c10f48e23fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6e924fa-b4c3-4340-8a6b-0c10f48e23fb">
											<gml:posList>35.66784217607567 139.74623712586586 6.53 35.66780979245995 139.74620352625712 6.53 35.66780979245995 139.74620352625712 9.417 35.66784217607567 139.74623712586586 9.417 35.66784217607567 139.74623712586586 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a9e09ffc-1c80-4c61-94dc-7c79b3437a42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a9e09ffc-1c80-4c61-94dc-7c79b3437a42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a9e09ffc-1c80-4c61-94dc-7c79b3437a42">
											<gml:posList>35.667844102992106 139.7462343291575 6.53 35.66784217607567 139.74623712586586 6.53 35.66784217607567 139.74623712586586 9.417 35.667844102992106 139.7462343291575 9.417 35.667844102992106 139.7462343291575 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-046b65a0-36ef-48fe-80c5-05cbbbca6eba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-046b65a0-36ef-48fe-80c5-05cbbbca6eba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-046b65a0-36ef-48fe-80c5-05cbbbca6eba">
											<gml:posList>35.66787858837901 139.74627011360212 6.53 35.667844102992106 139.7462343291575 6.53 35.667844102992106 139.7462343291575 9.417 35.66787858837901 139.74627011360212 9.417 35.66787858837901 139.74627011360212 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a26ffecd-c3ce-4a32-9e03-a2a6b978a7d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a26ffecd-c3ce-4a32-9e03-a2a6b978a7d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a26ffecd-c3ce-4a32-9e03-a2a6b978a7d5">
											<gml:posList>35.667863569180106 139.74629184617524 6.53 35.66787858837901 139.74627011360212 6.53 35.66787858837901 139.74627011360212 9.417 35.667863569180106 139.74629184617524 9.417 35.667863569180106 139.74629184617524 6.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8506</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.04</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>