<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4d34a279-4ce0-4c6f-99b3-0a49b142781d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">20.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67124861458041 139.74030235931855 0 35.671335046808885 139.74017356857183 0 35.67129003508719 139.74013065043687 0 35.67117581963438 139.74023229934258 0 35.67124861458041 139.74030235931855 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67124861458041 139.74030235931855 9.51 35.67117581963438 139.74023229934258 9.51 35.67129003508719 139.74013065043687 9.51 35.671335046808885 139.74017356857183 9.51 35.67124861458041 139.74030235931855 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67124861458041 139.74030235931855 9.51 35.671335046808885 139.74017356857183 9.51 35.671335046808885 139.74017356857183 29.61 35.67124861458041 139.74030235931855 29.61 35.67124861458041 139.74030235931855 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671335046808885 139.74017356857183 9.51 35.67129003508719 139.74013065043687 9.51 35.67129003508719 139.74013065043687 29.61 35.671335046808885 139.74017356857183 29.61 35.671335046808885 139.74017356857183 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129003508719 139.74013065043687 9.51 35.67117581963438 139.74023229934258 9.51 35.67117581963438 139.74023229934258 29.61 35.67129003508719 139.74013065043687 29.61 35.67129003508719 139.74013065043687 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67117581963438 139.74023229934258 9.51 35.67124861458041 139.74030235931855 9.51 35.67124861458041 139.74030235931855 29.61 35.67117581963438 139.74023229934258 29.61 35.67117581963438 139.74023229934258 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67124861458041 139.74030235931855 29.61 35.671335046808885 139.74017356857183 29.61 35.67129003508719 139.74013065043687 29.61 35.67117581963438 139.74023229934258 29.61 35.67124861458041 139.74030235931855 29.61</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-56742410-e254-46bd-8b71-9389b4194346"/>
							<gml:surfaceMember xlink:href="#poly-5d6e0b74-c6a1-43dc-b7ef-70f1328e5c01"/>
							<gml:surfaceMember xlink:href="#poly-53c7f683-f16e-4024-a6a9-52b6159a9e6d"/>
							<gml:surfaceMember xlink:href="#poly-d3dcf914-5579-4fee-ad20-e72dddf67e67"/>
							<gml:surfaceMember xlink:href="#poly-457d0421-6031-4f0b-8837-666c04e01c9b"/>
							<gml:surfaceMember xlink:href="#poly-06fae4a0-1ef7-4103-87b1-0dd3acea7432"/>
							<gml:surfaceMember xlink:href="#poly-35d1cdbc-c6ff-4f8a-b62e-4f01fc9e6b5f"/>
							<gml:surfaceMember xlink:href="#poly-7b1f08cb-9b8b-4c1b-be75-0bfab048a62c"/>
							<gml:surfaceMember xlink:href="#poly-54280abf-33ba-4a7b-a832-b387203c1e70"/>
							<gml:surfaceMember xlink:href="#poly-d858d65c-6f32-40fd-babc-d7aab642123e"/>
							<gml:surfaceMember xlink:href="#poly-c9b09613-f660-404c-aaf9-7136b678385b"/>
							<gml:surfaceMember xlink:href="#poly-e34bc115-7e9d-47c1-890c-59a63b31c8d2"/>
							<gml:surfaceMember xlink:href="#poly-d25d3b3a-f793-4bcf-90ce-9abf574a612e"/>
							<gml:surfaceMember xlink:href="#poly-e6c6e5d4-92dd-4088-adaa-1ea2d6bfee7f"/>
							<gml:surfaceMember xlink:href="#poly-f681696a-eb12-4fae-a942-1490dcdc04c5"/>
							<gml:surfaceMember xlink:href="#poly-026a6993-61f1-4782-95dd-73c9b3c44ff9"/>
							<gml:surfaceMember xlink:href="#poly-f9525d2b-7728-4f5d-90fd-b9289f629768"/>
							<gml:surfaceMember xlink:href="#poly-38842b3a-4433-4e9b-a99b-33efd4f60219"/>
							<gml:surfaceMember xlink:href="#poly-7cfd89a8-c6cf-4df1-baaf-133ce6e4eac8"/>
							<gml:surfaceMember xlink:href="#poly-008912f6-87a2-4462-a06b-acfcfba42cf1"/>
							<gml:surfaceMember xlink:href="#poly-0b91f94f-aec6-4a90-bbde-2630c9a63a18"/>
							<gml:surfaceMember xlink:href="#poly-324e5a09-1b37-47bf-bb4f-b500ef8f5279"/>
							<gml:surfaceMember xlink:href="#poly-96d9a822-7dee-4ea8-97fd-f1ff2f539c9c"/>
							<gml:surfaceMember xlink:href="#poly-f55e56ec-e646-4482-b1f7-96f0f81acd88"/>
							<gml:surfaceMember xlink:href="#poly-bb9bb458-668c-4c80-90f4-feda915c4730"/>
							<gml:surfaceMember xlink:href="#poly-66b45905-720f-4c61-8591-5ae2a45c782c"/>
							<gml:surfaceMember xlink:href="#poly-1ceb9bb5-cced-4ab1-80b5-68c8e324d70a"/>
							<gml:surfaceMember xlink:href="#poly-81c985b3-4698-4192-a670-cbcae598b163"/>
							<gml:surfaceMember xlink:href="#poly-1e82cbf0-159d-4459-b271-ebdeb1608663"/>
							<gml:surfaceMember xlink:href="#poly-fa148894-c7e8-444e-a3a2-2fac25e5ae6f"/>
							<gml:surfaceMember xlink:href="#poly-e450fecd-9554-44b9-b5f1-3aac814391a1"/>
							<gml:surfaceMember xlink:href="#poly-259fdd9b-7489-4f19-9d5d-31f09eb576ef"/>
							<gml:surfaceMember xlink:href="#poly-b8e4f790-2a5e-4cdc-9afc-1eb935e42b4a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4d34a279-4ce0-4c6f-99b3-0a49b142781d_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-045a410e-cec5-4704-8e8a-4c59fbdaef2c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67125419600286 139.74022321657696 29.735 35.67123630845856 139.74020599395536 29.735 35.67124746300229 139.740188582952 29.735 35.67126535955423 139.74020579451528 29.735 35.67125419600286 139.74022321657696 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42bd073a-c32d-4679-af02-69cf2d02f798">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42bd073a-c32d-4679-af02-69cf2d02f798_0">
											<gml:posList>35.67124746300229 139.740188582952 29.735 35.67124746300229 139.740188582952 31.864 35.67126535955423 139.74020579451528 31.864 35.67126535955423 139.74020579451528 29.735 35.67124746300229 139.740188582952 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e0786b9-3a94-4648-bba8-fd2a2efa48e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e0786b9-3a94-4648-bba8-fd2a2efa48e9_0">
											<gml:posList>35.67123630845856 139.74020599395536 29.735 35.67123630845856 139.74020599395536 31.864 35.67124746300229 139.740188582952 31.864 35.67124746300229 139.740188582952 29.735 35.67123630845856 139.74020599395536 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8105c461-b910-4625-94e5-c8415df6b9b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8105c461-b910-4625-94e5-c8415df6b9b5_0">
											<gml:posList>35.67124746300229 139.740188582952 31.864 35.67123630845856 139.74020599395536 31.864 35.67125419600286 139.74022321657696 31.864 35.67126535955423 139.74020579451528 31.864 35.67124746300229 139.740188582952 31.864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec6a4016-45de-4d5a-a0c4-1b49ddb49159">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec6a4016-45de-4d5a-a0c4-1b49ddb49159_0">
											<gml:posList>35.67126535955423 139.74020579451528 29.735 35.67126535955423 139.74020579451528 31.864 35.67125419600286 139.74022321657696 31.864 35.67125419600286 139.74022321657696 29.735 35.67126535955423 139.74020579451528 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f15c3c3-be58-4c4f-8e80-d52f7483ff5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f15c3c3-be58-4c4f-8e80-d52f7483ff5d_0">
											<gml:posList>35.67125419600286 139.74022321657696 29.735 35.67125419600286 139.74022321657696 31.864 35.67123630845856 139.74020599395536 31.864 35.67123630845856 139.74020599395536 29.735 35.67125419600286 139.74022321657696 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4d34a279-4ce0-4c6f-99b3-0a49b142781d_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99582f31-1d86-45a3-88a0-325411be172e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67126300350403 139.7401547077396 30.077 35.671264834614384 139.7401564178006 30.077 35.67125490834004 139.74016527748697 30.077 35.67125306819899 139.7401635453437 30.077 35.67126300350403 139.7401547077396 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c7c9e4a-3268-4122-947b-db789ba6bef1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671264834614384 139.7401564178006 29.735 35.67126764894689 139.7401590656615 29.735 35.671260482879546 139.74017051803983 29.735 35.67125490834004 139.74016527748697 29.735 35.671264834614384 139.7401564178006 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee8c31a6-29f7-4138-9f9b-ad4a6cc2d0f5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67126693233947 139.74017651977718 29.735 35.671277942522565 139.7401589321887 29.735 35.671284049256506 139.74016466921148 29.735 35.671273039072574 139.74018225680052 29.735 35.67126693233947 139.74017651977718 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca1c0b80-059d-4ddf-9cb5-40b26c533268">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67129513990779 139.74015788488907 29.735 35.671300795810396 139.74016343464837 29.735 35.671278396197664 139.74019774865195 29.735 35.671272740296615 139.7401921988918 29.735 35.67129513990779 139.74015788488907 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acf1ef6d-685b-4625-8bf4-e1f4459f2911">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671288521825126 139.74013199985492 30.077 35.67129765947903 139.7401407158774 30.077 35.67129743440958 139.74014106962338 30.077 35.67128998356987 139.74013396441217 30.077 35.67127765229217 139.7401449698978 30.077 35.671275866250255 139.74014325978442 30.077 35.671288521825126 139.74013199985492 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d2212a5-f214-44b2-b201-294dc0bbfc49">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67128998356987 139.74013396441217 29.735 35.67129743440958 139.74014106962338 29.735 35.67128843165624 139.7401552525992 29.735 35.67127765229217 139.7401449698978 29.735 35.67128998356987 139.74013396441217 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e5cf5aa-b3db-4cd9-959e-7c282f578a80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e5cf5aa-b3db-4cd9-959e-7c282f578a80_0">
											<gml:posList>35.671273039072574 139.74018225680052 29.735 35.671284049256506 139.74016466921148 29.735 35.671284049256506 139.74016466921148 31.387 35.671273039072574 139.74018225680052 31.387 35.671273039072574 139.74018225680052 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57896ed3-2983-46d7-bc0d-9ff9282de040">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57896ed3-2983-46d7-bc0d-9ff9282de040_0">
											<gml:posList>35.671288521825126 139.74013199985492 30.077 35.671288521825126 139.74013199985492 30.688 35.67129765947903 139.7401407158774 30.688 35.67129765947903 139.7401407158774 30.077 35.671288521825126 139.74013199985492 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69179d52-3d12-4d5d-ad1d-b39b0c353b72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69179d52-3d12-4d5d-ad1d-b39b0c353b72_0">
											<gml:posList>35.67128998356987 139.74013396441217 30.077 35.67129743440958 139.74014106962338 30.077 35.67129743440958 139.74014106962338 29.735 35.67128998356987 139.74013396441217 29.735 35.67128998356987 139.74013396441217 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01998541-5b31-406e-9cff-112d6d6b56aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01998541-5b31-406e-9cff-112d6d6b56aa_0">
											<gml:posList>35.671288521825126 139.74013199985492 30.077 35.671275866250255 139.74014325978442 30.077 35.671275866250255 139.74014325978442 30.688 35.671288521825126 139.74013199985492 30.688 35.671288521825126 139.74013199985492 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1d2f0a1-eb77-4477-8189-0dcd4d181e9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1d2f0a1-eb77-4477-8189-0dcd4d181e9b_0">
											<gml:posList>35.67127765229217 139.7401449698978 29.735 35.67127765229217 139.7401449698978 30.077 35.67128998356987 139.74013396441217 30.077 35.67128998356987 139.74013396441217 29.735 35.67127765229217 139.7401449698978 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-48ae5f08-b923-4f0c-81b5-093fb9011128">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-48ae5f08-b923-4f0c-81b5-093fb9011128_0">
											<gml:posList>35.67128843165624 139.7401552525992 30.688 35.67129765947903 139.7401407158774 30.688 35.671288521825126 139.74013199985492 30.688 35.671275866250255 139.74014325978442 30.688 35.67128843165624 139.7401552525992 30.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d940023-99c3-4bc8-b7f3-896ba94f3e64">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d940023-99c3-4bc8-b7f3-896ba94f3e64_0">
											<gml:posList>35.67129765947903 139.7401407158774 30.688 35.67128843165624 139.7401552525992 30.688 35.67128843165624 139.7401552525992 29.735 35.67129743440958 139.74014106962338 29.735 35.67129743440958 139.74014106962338 30.077 35.67129765947903 139.7401407158774 30.077 35.67129765947903 139.7401407158774 30.688</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5158567a-0cce-47dd-97a0-07c71bdbfe0e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5158567a-0cce-47dd-97a0-07c71bdbfe0e_0">
											<gml:posList>35.67127765229217 139.7401449698978 30.077 35.67127765229217 139.7401449698978 29.735 35.67128843165624 139.7401552525992 29.735 35.67128843165624 139.7401552525992 30.688 35.671275866250255 139.74014325978442 30.688 35.671275866250255 139.74014325978442 30.077 35.67127765229217 139.7401449698978 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc5bd478-7b13-4c6a-a399-e61dc0dcbef8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc5bd478-7b13-4c6a-a399-e61dc0dcbef8_0">
											<gml:posList>35.671264834614384 139.7401564178006 30.077 35.67126300350403 139.7401547077396 30.077 35.67126300350403 139.7401547077396 33.095 35.67126764894689 139.7401590656615 33.095 35.67126764894689 139.7401590656615 29.735 35.671264834614384 139.7401564178006 29.735 35.671264834614384 139.7401564178006 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea619b99-b6a7-45e2-8cfb-a88b62566a10">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea619b99-b6a7-45e2-8cfb-a88b62566a10_0">
											<gml:posList>35.67126300350403 139.7401547077396 30.077 35.67125306819899 139.7401635453437 30.077 35.67125306819899 139.7401635453437 33.095 35.67126300350403 139.7401547077396 33.095 35.67126300350403 139.7401547077396 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bece62a-20c6-455e-b7eb-b4141333780b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bece62a-20c6-455e-b7eb-b4141333780b_0">
											<gml:posList>35.671300795810396 139.74016343464837 29.735 35.67129513990779 139.74015788488907 29.735 35.67129513990779 139.74015788488907 31.387 35.671300795810396 139.74016343464837 31.387 35.671300795810396 139.74016343464837 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-561f8e38-ca83-4d3a-9f0d-90cfa5565fe0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-561f8e38-ca83-4d3a-9f0d-90cfa5565fe0_0">
											<gml:posList>35.67125490834004 139.74016527748697 30.077 35.671264834614384 139.7401564178006 30.077 35.671264834614384 139.7401564178006 29.735 35.67125490834004 139.74016527748697 29.735 35.67125490834004 139.74016527748697 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac9f6f6f-3bca-41aa-82cd-c08023606f21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac9f6f6f-3bca-41aa-82cd-c08023606f21_0">
											<gml:posList>35.671277942522565 139.7401589321887 29.735 35.671277942522565 139.7401589321887 31.387 35.671284049256506 139.74016466921148 31.387 35.671284049256506 139.74016466921148 29.735 35.671277942522565 139.7401589321887 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2498162-2419-4cb8-bd29-60f8c36f60fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2498162-2419-4cb8-bd29-60f8c36f60fb_0">
											<gml:posList>35.671260482879546 139.74017051803983 33.095 35.67126764894689 139.7401590656615 33.095 35.67126300350403 139.7401547077396 33.095 35.67125306819899 139.7401635453437 33.095 35.671260482879546 139.74017051803983 33.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1243f849-0e4d-4814-a96c-14afe1ae4d25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1243f849-0e4d-4814-a96c-14afe1ae4d25_0">
											<gml:posList>35.671260482879546 139.74017051803983 29.735 35.67126764894689 139.7401590656615 29.735 35.67126764894689 139.7401590656615 33.095 35.671260482879546 139.74017051803983 33.095 35.671260482879546 139.74017051803983 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee957f20-e98f-4868-a370-96a48e025a36">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee957f20-e98f-4868-a370-96a48e025a36_0">
											<gml:posList>35.671260482879546 139.74017051803983 29.735 35.671260482879546 139.74017051803983 33.095 35.67125306819899 139.7401635453437 33.095 35.67125306819899 139.7401635453437 30.077 35.67125490834004 139.74016527748697 30.077 35.67125490834004 139.74016527748697 29.735 35.671260482879546 139.74017051803983 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92c2c97d-692a-483d-b02f-ef98af454adc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92c2c97d-692a-483d-b02f-ef98af454adc_0">
											<gml:posList>35.671277942522565 139.7401589321887 29.735 35.67126693233947 139.74017651977718 29.735 35.67126693233947 139.74017651977718 31.387 35.671277942522565 139.7401589321887 31.387 35.671277942522565 139.7401589321887 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b84248a6-5ce5-4a12-b257-6ad57e22e9d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b84248a6-5ce5-4a12-b257-6ad57e22e9d6_0">
											<gml:posList>35.67126693233947 139.74017651977718 31.387 35.671273039072574 139.74018225680052 31.387 35.671284049256506 139.74016466921148 31.387 35.671277942522565 139.7401589321887 31.387 35.67126693233947 139.74017651977718 31.387</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24c5b33b-c048-4ca9-ad08-36d028a46b4e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24c5b33b-c048-4ca9-ad08-36d028a46b4e_0">
											<gml:posList>35.67129513990779 139.74015788488907 29.735 35.671272740296615 139.7401921988918 29.735 35.671272740296615 139.7401921988918 31.387 35.67129513990779 139.74015788488907 31.387 35.67129513990779 139.74015788488907 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82cbc4ae-3337-4b53-a68b-bbf20eb3325a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82cbc4ae-3337-4b53-a68b-bbf20eb3325a_0">
											<gml:posList>35.671278396197664 139.74019774865195 31.387 35.671300795810396 139.74016343464837 31.387 35.67129513990779 139.74015788488907 31.387 35.671272740296615 139.7401921988918 31.387 35.671278396197664 139.74019774865195 31.387</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ce61266-49a8-46e8-8e6d-a83cb533a49d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ce61266-49a8-46e8-8e6d-a83cb533a49d_0">
											<gml:posList>35.671273039072574 139.74018225680052 29.735 35.671273039072574 139.74018225680052 31.387 35.67126693233947 139.74017651977718 31.387 35.67126693233947 139.74017651977718 29.735 35.671273039072574 139.74018225680052 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1b8ad24-9383-450f-b287-396a3fb4f718">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1b8ad24-9383-450f-b287-396a3fb4f718_0">
											<gml:posList>35.671278396197664 139.74019774865195 29.735 35.671300795810396 139.74016343464837 29.735 35.671300795810396 139.74016343464837 31.387 35.671278396197664 139.74019774865195 31.387 35.671278396197664 139.74019774865195 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fd0c4ad-d6c8-4ecf-846f-cdac0b48e3e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fd0c4ad-d6c8-4ecf-846f-cdac0b48e3e4_0">
											<gml:posList>35.671272740296615 139.7401921988918 29.735 35.671278396197664 139.74019774865195 29.735 35.671278396197664 139.74019774865195 31.387 35.671272740296615 139.7401921988918 31.387 35.671272740296615 139.7401921988918 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-56742410-e254-46bd-8b71-9389b4194346">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56742410-e254-46bd-8b71-9389b4194346">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56742410-e254-46bd-8b71-9389b4194346">
											<gml:posList>35.671248614580406 139.74030235931855 9.51 35.67117581963435 139.74023229934255 9.51 35.671290035087175 139.74013065043684 9.51 35.671335046808885 139.74017356857183 9.51 35.671248614580406 139.74030235931855 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5d6e0b74-c6a1-43dc-b7ef-70f1328e5c01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d6e0b74-c6a1-43dc-b7ef-70f1328e5c01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d6e0b74-c6a1-43dc-b7ef-70f1328e5c01">
											<gml:posList>35.671221848116794 139.74019134116526 33.217 35.67117581963435 139.74023229934255 33.217 35.67117928095463 139.74023236160141 33.217 35.67122178749865 139.74019454468453 33.217 35.671221848116794 139.74019134116526 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53c7f683-f16e-4024-a6a9-52b6159a9e6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53c7f683-f16e-4024-a6a9-52b6159a9e6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53c7f683-f16e-4024-a6a9-52b6159a9e6d">
											<gml:posList>35.67121919956109 139.74020490919068 33.217 35.67122558258295 139.74019493794535 33.217 35.67122264444301 139.7401953721672 33.217 35.67121626142111 139.74020534341213 33.217 35.67121919956109 139.74020490919068 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3dcf914-5579-4fee-ad20-e72dddf67e67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3dcf914-5579-4fee-ad20-e72dddf67e67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3dcf914-5579-4fee-ad20-e72dddf67e67">
											<gml:posList>35.671221848116794 139.74019134116526 33.217 35.67122178749865 139.74019454468453 33.217 35.67122264444301 139.7401953721672 33.217 35.67122558258295 139.74019493794535 33.217 35.671221848116794 139.74019134116526 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-457d0421-6031-4f0b-8837-666c04e01c9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-457d0421-6031-4f0b-8837-666c04e01c9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-457d0421-6031-4f0b-8837-666c04e01c9b">
											<gml:posList>35.67121919956109 139.74020490919068 33.217 35.67121626142111 139.74020534341213 33.217 35.671237748113924 139.74022601936565 33.217 35.6712406862625 139.7402255961912 33.217 35.67121919956109 139.74020490919068 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06fae4a0-1ef7-4103-87b1-0dd3acea7432">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06fae4a0-1ef7-4103-87b1-0dd3acea7432">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06fae4a0-1ef7-4103-87b1-0dd3acea7432">
											<gml:posList>35.671221848116794 139.74019134116526 30.077 35.67122371534988 139.74019313955526 30.077 35.67128998356987 139.74013396441217 30.077 35.671290035087175 139.74013065043684 30.077 35.671221848116794 139.74019134116526 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35d1cdbc-c6ff-4f8a-b62e-4f01fc9e6b5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35d1cdbc-c6ff-4f8a-b62e-4f01fc9e6b5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35d1cdbc-c6ff-4f8a-b62e-4f01fc9e6b5f">
											<gml:posList>35.67122558258295 139.74019493794535 29.735 35.67121919956109 139.74020490919068 29.735 35.6712406862625 139.7402255961912 29.735 35.671214622948014 139.7402662550237 29.735 35.671229840433284 139.74028090694722 29.735 35.671312372176786 139.74015532419335 29.735 35.67128998356987 139.74013396441217 29.735 35.67122371534988 139.74019313955526 29.735 35.67122558258295 139.74019493794535 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b1f08cb-9b8b-4c1b-be75-0bfab048a62c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b1f08cb-9b8b-4c1b-be75-0bfab048a62c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b1f08cb-9b8b-4c1b-be75-0bfab048a62c">
											<gml:posList>35.671315445522346 139.7401548898124 30.077 35.671312372176786 139.74015532419335 30.077 35.671229840433284 139.74028090694722 30.077 35.671230185831426 139.74028462917522 30.077 35.671315445522346 139.7401548898124 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-54280abf-33ba-4a7b-a832-b387203c1e70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-54280abf-33ba-4a7b-a832-b387203c1e70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-54280abf-33ba-4a7b-a832-b387203c1e70">
											<gml:posList>35.671290035087175 139.74013065043684 30.077 35.67128998356987 139.74013396441217 30.077 35.671312372176786 139.74015532419335 30.077 35.671315445522346 139.7401548898124 30.077 35.671290035087175 139.74013065043684 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d858d65c-6f32-40fd-babc-d7aab642123e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d858d65c-6f32-40fd-babc-d7aab642123e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d858d65c-6f32-40fd-babc-d7aab642123e">
											<gml:posList>35.671248614580406 139.74030235931855 25.742 35.671335046808885 139.74017356857183 25.742 35.671315445522346 139.7401548898124 30.077 35.671248614580406 139.74030235931855 25.742</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9b09613-f660-404c-aaf9-7136b678385b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9b09613-f660-404c-aaf9-7136b678385b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9b09613-f660-404c-aaf9-7136b678385b">
											<gml:posList>35.671315445522346 139.7401548898124 30.077 35.671230185831426 139.74028462917522 30.077 35.671248614580406 139.74030235931855 25.742 35.671315445522346 139.7401548898124 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e34bc115-7e9d-47c1-890c-59a63b31c8d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e34bc115-7e9d-47c1-890c-59a63b31c8d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e34bc115-7e9d-47c1-890c-59a63b31c8d2">
											<gml:posList>35.67121626142111 139.74020534341213 32.98 35.67122264444301 139.7401953721672 32.98 35.67122178749865 139.74019454468453 32.98 35.67117928095463 139.74023236160141 32.98 35.67121292720724 139.7402647546852 32.98 35.671237748113924 139.74022601936565 32.98 35.67121626142111 139.74020534341213 32.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d25d3b3a-f793-4bcf-90ce-9abf574a612e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d25d3b3a-f793-4bcf-90ce-9abf574a612e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d25d3b3a-f793-4bcf-90ce-9abf574a612e">
											<gml:posList>35.6712406862625 139.7402255961912 33.217 35.671237748113924 139.74022601936565 33.217 35.67121292720724 139.7402647546852 33.217 35.67121328152569 139.7402683553919 33.217 35.6712406862625 139.7402255961912 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6c6e5d4-92dd-4088-adaa-1ea2d6bfee7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6c6e5d4-92dd-4088-adaa-1ea2d6bfee7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6c6e5d4-92dd-4088-adaa-1ea2d6bfee7f">
											<gml:posList>35.67121328152569 139.7402683553919 33.217 35.67121292720724 139.7402647546852 33.217 35.67117928095463 139.74023236160141 33.217 35.67117581963435 139.74023229934255 33.217 35.67121328152569 139.7402683553919 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f681696a-eb12-4fae-a942-1490dcdc04c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f681696a-eb12-4fae-a942-1490dcdc04c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f681696a-eb12-4fae-a942-1490dcdc04c5">
											<gml:posList>35.67121328152569 139.7402683553919 30.077 35.671230185831426 139.74028462917522 30.077 35.671229840433284 139.74028090694722 30.077 35.671214622948014 139.7402662550237 30.077 35.67121328152569 139.7402683553919 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-026a6993-61f1-4782-95dd-73c9b3c44ff9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-026a6993-61f1-4782-95dd-73c9b3c44ff9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-026a6993-61f1-4782-95dd-73c9b3c44ff9">
											<gml:posList>35.67122264444301 139.7401953721672 33.217 35.67122264444301 139.7401953721672 32.98 35.67121626142111 139.74020534341213 32.98 35.67121626142111 139.74020534341213 33.217 35.67122264444301 139.7401953721672 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9525d2b-7728-4f5d-90fd-b9289f629768">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9525d2b-7728-4f5d-90fd-b9289f629768">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9525d2b-7728-4f5d-90fd-b9289f629768">
											<gml:posList>35.67117928095463 139.74023236160141 33.217 35.67117928095463 139.74023236160141 32.98 35.67122178749865 139.74019454468453 32.98 35.67122178749865 139.74019454468453 33.217 35.67117928095463 139.74023236160141 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38842b3a-4433-4e9b-a99b-33efd4f60219">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38842b3a-4433-4e9b-a99b-33efd4f60219">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38842b3a-4433-4e9b-a99b-33efd4f60219">
											<gml:posList>35.671312372176786 139.74015532419335 30.077 35.671312372176786 139.74015532419335 29.735 35.671229840433284 139.74028090694722 29.735 35.671229840433284 139.74028090694722 30.077 35.671312372176786 139.74015532419335 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cfd89a8-c6cf-4df1-baaf-133ce6e4eac8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cfd89a8-c6cf-4df1-baaf-133ce6e4eac8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cfd89a8-c6cf-4df1-baaf-133ce6e4eac8">
											<gml:posList>35.671237748113924 139.74022601936565 33.217 35.671237748113924 139.74022601936565 32.98 35.67121292720724 139.7402647546852 32.98 35.67121292720724 139.7402647546852 33.217 35.671237748113924 139.74022601936565 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-008912f6-87a2-4462-a06b-acfcfba42cf1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-008912f6-87a2-4462-a06b-acfcfba42cf1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-008912f6-87a2-4462-a06b-acfcfba42cf1">
											<gml:posList>35.67121292720724 139.7402647546852 33.217 35.67121292720724 139.7402647546852 32.98 35.67117928095463 139.74023236160141 32.98 35.67117928095463 139.74023236160141 33.217 35.67121292720724 139.7402647546852 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b91f94f-aec6-4a90-bbde-2630c9a63a18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b91f94f-aec6-4a90-bbde-2630c9a63a18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b91f94f-aec6-4a90-bbde-2630c9a63a18">
											<gml:posList>35.67117581963435 139.74023229934255 33.217 35.67117581963435 139.74023229934255 9.51 35.671248614580406 139.74030235931855 9.51 35.671248614580406 139.74030235931855 25.742 35.671230185831426 139.74028462917522 30.077 35.67121328152569 139.7402683553919 30.077 35.67121328152569 139.7402683553919 33.217 35.67117581963435 139.74023229934255 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-324e5a09-1b37-47bf-bb4f-b500ef8f5279">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-324e5a09-1b37-47bf-bb4f-b500ef8f5279">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-324e5a09-1b37-47bf-bb4f-b500ef8f5279">
											<gml:posList>35.671229840433284 139.74028090694722 30.077 35.671229840433284 139.74028090694722 29.735 35.671214622948014 139.7402662550237 29.735 35.671214622948014 139.7402662550237 30.077 35.671229840433284 139.74028090694722 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96d9a822-7dee-4ea8-97fd-f1ff2f539c9c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96d9a822-7dee-4ea8-97fd-f1ff2f539c9c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96d9a822-7dee-4ea8-97fd-f1ff2f539c9c">
											<gml:posList>35.67122178749865 139.74019454468453 33.217 35.67122178749865 139.74019454468453 32.98 35.67122264444301 139.7401953721672 32.98 35.67122264444301 139.7401953721672 33.217 35.67122178749865 139.74019454468453 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f55e56ec-e646-4482-b1f7-96f0f81acd88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f55e56ec-e646-4482-b1f7-96f0f81acd88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f55e56ec-e646-4482-b1f7-96f0f81acd88">
											<gml:posList>35.67121919956109 139.74020490919068 29.735 35.67122558258295 139.74019493794535 29.735 35.67122558258295 139.74019493794535 33.217 35.67121919956109 139.74020490919068 33.217 35.67121919956109 139.74020490919068 29.735</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb9bb458-668c-4c80-90f4-feda915c4730">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb9bb458-668c-4c80-90f4-feda915c4730">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb9bb458-668c-4c80-90f4-feda915c4730">
											<gml:posList>35.67122371534988 139.74019313955526 30.077 35.671221848116794 139.74019134116526 30.077 35.671221848116794 139.74019134116526 33.217 35.67122558258295 139.74019493794535 33.217 35.67122558258295 139.74019493794535 29.735 35.67122371534988 139.74019313955526 29.735 35.67122371534988 139.74019313955526 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66b45905-720f-4c61-8591-5ae2a45c782c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66b45905-720f-4c61-8591-5ae2a45c782c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66b45905-720f-4c61-8591-5ae2a45c782c">
											<gml:posList>35.67121328152569 139.7402683553919 33.217 35.67121328152569 139.7402683553919 30.077 35.671214622948014 139.7402662550237 30.077 35.671214622948014 139.7402662550237 29.735 35.6712406862625 139.7402255961912 29.735 35.6712406862625 139.7402255961912 33.217 35.67121328152569 139.7402683553919 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1ceb9bb5-cced-4ab1-80b5-68c8e324d70a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ceb9bb5-cced-4ab1-80b5-68c8e324d70a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ceb9bb5-cced-4ab1-80b5-68c8e324d70a">
											<gml:posList>35.67121626142111 139.74020534341213 33.217 35.67121626142111 139.74020534341213 32.98 35.671237748113924 139.74022601936565 32.98 35.671237748113924 139.74022601936565 33.217 35.67121626142111 139.74020534341213 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81c985b3-4698-4192-a670-cbcae598b163">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81c985b3-4698-4192-a670-cbcae598b163">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81c985b3-4698-4192-a670-cbcae598b163">
											<gml:posList>35.67121919956109 139.74020490919068 33.217 35.6712406862625 139.7402255961912 33.217 35.6712406862625 139.7402255961912 29.735 35.67121919956109 139.74020490919068 29.735 35.67121919956109 139.74020490919068 33.217</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e82cbf0-159d-4459-b271-ebdeb1608663">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e82cbf0-159d-4459-b271-ebdeb1608663">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e82cbf0-159d-4459-b271-ebdeb1608663">
											<gml:posList>35.67117581963435 139.74023229934255 9.51 35.67117581963435 139.74023229934255 33.217 35.671221848116794 139.74019134116526 33.217 35.671221848116794 139.74019134116526 30.077 35.671290035087175 139.74013065043684 30.077 35.671290035087175 139.74013065043684 9.51 35.67117581963435 139.74023229934255 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fa148894-c7e8-444e-a3a2-2fac25e5ae6f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa148894-c7e8-444e-a3a2-2fac25e5ae6f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa148894-c7e8-444e-a3a2-2fac25e5ae6f">
											<gml:posList>35.67122371534988 139.74019313955526 30.077 35.67122371534988 139.74019313955526 29.735 35.67128998356987 139.74013396441217 29.735 35.67128998356987 139.74013396441217 30.077 35.67122371534988 139.74019313955526 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e450fecd-9554-44b9-b5f1-3aac814391a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e450fecd-9554-44b9-b5f1-3aac814391a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e450fecd-9554-44b9-b5f1-3aac814391a1">
											<gml:posList>35.671248614580406 139.74030235931855 9.51 35.671335046808885 139.74017356857183 9.51 35.671335046808885 139.74017356857183 25.742 35.671248614580406 139.74030235931855 25.742 35.671248614580406 139.74030235931855 9.51</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-259fdd9b-7489-4f19-9d5d-31f09eb576ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-259fdd9b-7489-4f19-9d5d-31f09eb576ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-259fdd9b-7489-4f19-9d5d-31f09eb576ef">
											<gml:posList>35.67128998356987 139.74013396441217 30.077 35.67128998356987 139.74013396441217 29.735 35.671312372176786 139.74015532419335 29.735 35.671312372176786 139.74015532419335 30.077 35.67128998356987 139.74013396441217 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8e4f790-2a5e-4cdc-9afc-1eb935e42b4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8e4f790-2a5e-4cdc-9afc-1eb935e42b4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8e4f790-2a5e-4cdc-9afc-1eb935e42b4a">
											<gml:posList>35.671290035087175 139.74013065043684 30.077 35.671315445522346 139.7401548898124 30.077 35.671335046808885 139.74017356857183 25.742 35.671335046808885 139.74017356857183 9.51 35.671290035087175 139.74013065043684 9.51 35.671290035087175 139.74013065043684 30.077</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5350</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">125.0794</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>