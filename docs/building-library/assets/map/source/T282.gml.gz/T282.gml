<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_4fb5bf82-ffbf-4a6a-873a-962a8658933c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">26.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67156114478169 139.74033369990303 0 35.671565529378704 139.74032711114904 0 35.67157636322714 139.74033793512336 0 35.671620587204394 139.74027132908432 0 35.67148942637818 139.74014047087985 0 35.67145269313085 139.74019574561365 0 35.6714714561944 139.74021450271346 0 35.67145957183493 139.74023230123368 0 35.67156114478169 139.74033369990303 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156114478169 139.74033369990303 8.92 35.67145957183493 139.74023230123368 8.92 35.6714714561944 139.74021450271346 8.92 35.67145269313085 139.74019574561365 8.92 35.67148942637818 139.74014047087985 8.92 35.671620587204394 139.74027132908432 8.92 35.67157636322714 139.74033793512336 8.92 35.671565529378704 139.74032711114904 8.92 35.67156114478169 139.74033369990303 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156114478169 139.74033369990303 8.92 35.671565529378704 139.74032711114904 8.92 35.671565529378704 139.74032711114904 35.84 35.67156114478169 139.74033369990303 35.84 35.67156114478169 139.74033369990303 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671565529378704 139.74032711114904 8.92 35.67157636322714 139.74033793512336 8.92 35.67157636322714 139.74033793512336 35.84 35.671565529378704 139.74032711114904 35.84 35.671565529378704 139.74032711114904 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67157636322714 139.74033793512336 8.92 35.671620587204394 139.74027132908432 8.92 35.671620587204394 139.74027132908432 35.84 35.67157636322714 139.74033793512336 35.84 35.67157636322714 139.74033793512336 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671620587204394 139.74027132908432 8.92 35.67148942637818 139.74014047087985 8.92 35.67148942637818 139.74014047087985 35.84 35.671620587204394 139.74027132908432 35.84 35.671620587204394 139.74027132908432 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67148942637818 139.74014047087985 8.92 35.67145269313085 139.74019574561365 8.92 35.67145269313085 139.74019574561365 35.84 35.67148942637818 139.74014047087985 35.84 35.67148942637818 139.74014047087985 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145269313085 139.74019574561365 8.92 35.6714714561944 139.74021450271346 8.92 35.6714714561944 139.74021450271346 35.84 35.67145269313085 139.74019574561365 35.84 35.67145269313085 139.74019574561365 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6714714561944 139.74021450271346 8.92 35.67145957183493 139.74023230123368 8.92 35.67145957183493 139.74023230123368 35.84 35.6714714561944 139.74021450271346 35.84 35.6714714561944 139.74021450271346 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67145957183493 139.74023230123368 8.92 35.67156114478169 139.74033369990303 8.92 35.67156114478169 139.74033369990303 35.84 35.67145957183493 139.74023230123368 35.84 35.67145957183493 139.74023230123368 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67156114478169 139.74033369990303 35.84 35.671565529378704 139.74032711114904 35.84 35.67157636322714 139.74033793512336 35.84 35.671620587204394 139.74027132908432 35.84 35.67148942637818 139.74014047087985 35.84 35.67145269313085 139.74019574561365 35.84 35.6714714561944 139.74021450271346 35.84 35.67145957183493 139.74023230123368 35.84 35.67156114478169 139.74033369990303 35.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-f4d476a6-5ddb-425a-a2c6-101ad0492def"/>
							<gml:surfaceMember xlink:href="#poly-4ef427be-1886-4339-869a-13b9aabcd6de"/>
							<gml:surfaceMember xlink:href="#poly-1e207b8a-84f7-41dd-9bd3-379e7c7c7234"/>
							<gml:surfaceMember xlink:href="#poly-deada91e-a288-4030-866e-3bb98c6ccc16"/>
							<gml:surfaceMember xlink:href="#poly-5003e270-959f-4205-ac36-05c6612b5f33"/>
							<gml:surfaceMember xlink:href="#poly-3f8040ec-502f-4454-bc43-4bc9c82eafa4"/>
							<gml:surfaceMember xlink:href="#poly-16a8f94d-b113-40b5-af3e-3e8e952f465b"/>
							<gml:surfaceMember xlink:href="#poly-79a2dcad-037e-4708-9fcc-898085bca06e"/>
							<gml:surfaceMember xlink:href="#poly-412fdb1e-c81d-4a43-a9f7-3316d8c4ad12"/>
							<gml:surfaceMember xlink:href="#poly-4dd99b20-c800-40ee-b6a8-db8b0c88e017"/>
							<gml:surfaceMember xlink:href="#poly-961a90e7-cedf-4189-beb8-9bdf7bf3d531"/>
							<gml:surfaceMember xlink:href="#poly-5763b491-1f28-475a-a180-4f25b358ca0d"/>
							<gml:surfaceMember xlink:href="#poly-9ca7fd46-33b7-4316-a37d-85c706b347e7"/>
							<gml:surfaceMember xlink:href="#poly-2d187c3f-f93d-4288-9be6-3371b2ea9762"/>
							<gml:surfaceMember xlink:href="#poly-ddd9f65b-89d5-42d0-94ea-17d9c632db6b"/>
							<gml:surfaceMember xlink:href="#poly-dfaeac35-bf0a-4f74-ac18-2764628e5cd6"/>
							<gml:surfaceMember xlink:href="#poly-22af4392-4614-4309-a5b6-b710994cb2bc"/>
							<gml:surfaceMember xlink:href="#poly-39400fcd-ba72-4665-8262-640eb43b3a7c"/>
							<gml:surfaceMember xlink:href="#poly-4ee5cbbc-b515-4f85-8ef6-17e293f00b80"/>
							<gml:surfaceMember xlink:href="#poly-3e895a17-fae4-4bbe-8a7b-c2f194f35acd"/>
							<gml:surfaceMember xlink:href="#poly-d2059d7f-930d-46e2-878c-1903aa4e580a"/>
							<gml:surfaceMember xlink:href="#poly-41b6b686-d241-4ab8-8c85-8b777150fd32"/>
							<gml:surfaceMember xlink:href="#poly-a2f7c226-2d47-441b-adef-9cc675eab8e2"/>
							<gml:surfaceMember xlink:href="#poly-c1a91541-d7ac-4147-8d7b-9dd3195445ae"/>
							<gml:surfaceMember xlink:href="#poly-70b10de3-d0f6-4c98-beee-10d777937bbc"/>
							<gml:surfaceMember xlink:href="#poly-99af4ef4-654b-4e13-a2ab-4553565ad804"/>
							<gml:surfaceMember xlink:href="#poly-e37a7c52-21d7-4042-91f2-1be368614c9d"/>
							<gml:surfaceMember xlink:href="#poly-3fcc7ff4-82f9-42f1-af8d-e553a0bfb260"/>
							<gml:surfaceMember xlink:href="#poly-795ec639-b834-47c2-bad7-6f8caf4db640"/>
							<gml:surfaceMember xlink:href="#poly-87232d0f-bf3d-4242-b453-5df79c620f2e"/>
							<gml:surfaceMember xlink:href="#poly-70b33af6-37e6-4149-b5fd-7aa10b1e1534"/>
							<gml:surfaceMember xlink:href="#poly-22c7149e-773d-48de-87e1-1a7ed3b5f861"/>
							<gml:surfaceMember xlink:href="#poly-096192d4-4f79-44a2-99d1-52d5bf568f8a"/>
							<gml:surfaceMember xlink:href="#poly-0cc884fc-3fcc-43f7-95d8-850c9fb126d0"/>
							<gml:surfaceMember xlink:href="#poly-beadacc3-4266-4c39-a93c-fd80dc3a3190"/>
							<gml:surfaceMember xlink:href="#poly-e4aa6ee3-a460-4719-a07e-530f47a9da4a"/>
							<gml:surfaceMember xlink:href="#poly-9e799a4a-9708-40ed-8f7c-7ac72723ae1b"/>
							<gml:surfaceMember xlink:href="#poly-259aa24e-eebe-4ae4-bbe6-d3ff95128438"/>
							<gml:surfaceMember xlink:href="#poly-c63c7426-f1a0-421f-8a35-6114ca9f4036"/>
							<gml:surfaceMember xlink:href="#poly-4171856a-0dd9-4c75-a63d-c783fe317a5b"/>
							<gml:surfaceMember xlink:href="#poly-f8c7ac17-e1bb-4f3e-99b6-c9dd25e5865d"/>
							<gml:surfaceMember xlink:href="#poly-7c4f1f6d-9c4e-47f2-a138-5c0d6028df5d"/>
							<gml:surfaceMember xlink:href="#poly-bd37f596-66ca-4526-9509-994d713f4755"/>
							<gml:surfaceMember xlink:href="#poly-4942b80e-d71f-4610-bb5a-53da03022567"/>
							<gml:surfaceMember xlink:href="#poly-212eabb0-79bd-4020-8bd3-704426473152"/>
							<gml:surfaceMember xlink:href="#poly-4165e64e-4ac3-449e-b085-61499a046dfd"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_4fb5bf82-ffbf-4a6a-873a-962a8658933c_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c62089f-0d71-4a29-abce-448a1ec79869">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67153535027688 139.740302302763 39.333 35.67154707716013 139.740313998361 39.333 35.671546636008344 139.74031467270444 39.333 35.67153490911662 139.74030296606003 39.333 35.67153535027688 139.740302302763 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f104905b-9a63-40a6-8453-9034b842b814">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671538168302725 139.74029806871462 39.028 35.67154989519491 139.74030977535878 39.028 35.67154707716013 139.740313998361 39.028 35.67153535027688 139.740302302763 39.028 35.671538168302725 139.74029806871462 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-851d2a29-8698-4ad2-9cad-d5f603af6eea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67154382274347 139.74025508053387 39.028 35.671544534810344 139.74025505761438 39.028 35.671545247013846 139.74025521143741 39.028 35.6715459142939 139.74025555310178 39.028 35.67154650057 139.74025604951 39.028 35.67154699681136 139.74025667857987 39.028 35.67154736696308 139.74025744035313 39.028 35.67154761096541 139.74025825750496 39.028 35.67154771079942 139.7402591411027 39.028 35.671547648377924 139.74026001384237 39.028 35.671547441711255 139.74026085361024 39.028 35.671547099787546 139.7402616272566 39.028 35.67154664060861 139.74026230162124 39.028 35.67154607315403 139.74026283250817 39.028 35.67154542445642 139.74026320883948 39.028 35.67154472154842 139.7402634195374 39.028 35.671544009481536 139.74026344245686 39.028 35.671543297278056 139.74026328863374 39.028 35.671542639011754 139.7402629469589 39.028 35.67154204372195 139.74026245056103 39.028 35.67154154747209 139.7402618104448 39.028 35.67154117732892 139.74026105971797 39.028 35.671540933318084 139.74026023151978 39.028 35.67154084250633 139.74025935895807 39.028 35.67154089591411 139.74025848622895 39.028 35.67154110258076 139.74025764646115 39.028 35.67154144449591 139.74025686176844 39.028 35.67154190368334 139.74025619845017 39.028 35.67154248015163 139.74025566755282 39.028 35.67154311982695 139.7402552801855 39.028 35.67154382274347 139.74025508053387 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-012d24c3-d2ce-4650-a2eb-5b6d3c62e808">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671591701847056 139.7402643812716 43.256 35.67160949965464 139.74028213431515 43.256 35.67159995620706 139.74029650574715 43.256 35.67158215840157 139.74027875270252 43.256 35.671591701847056 139.7402643812716 43.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0724d7d3-8c33-46af-9031-ffbdcbb1ff0b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0724d7d3-8c33-46af-9031-ffbdcbb1ff0b_0">
											<gml:posList>35.67154382274347 139.74025508053387 39.028 35.67154382274347 139.74025508053387 40.606 35.671544534810344 139.74025505761438 40.606 35.671544534810344 139.74025505761438 39.028 35.67154382274347 139.74025508053387 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca6ec6f8-1a4a-4708-97b8-8749762a5cb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca6ec6f8-1a4a-4708-97b8-8749762a5cb0_0">
											<gml:posList>35.671544534810344 139.74025505761438 39.028 35.671544534810344 139.74025505761438 40.606 35.671545247013846 139.74025521143741 40.606 35.671545247013846 139.74025521143741 39.028 35.671544534810344 139.74025505761438 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e420361a-817a-458a-b04d-9e64d0a29327">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e420361a-817a-458a-b04d-9e64d0a29327_0">
											<gml:posList>35.67154311982695 139.7402552801855 39.028 35.67154311982695 139.7402552801855 40.606 35.67154382274347 139.74025508053387 40.606 35.67154382274347 139.74025508053387 39.028 35.67154311982695 139.7402552801855 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-403495f4-fcaf-4ace-877b-dd9d521e6a40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-403495f4-fcaf-4ace-877b-dd9d521e6a40_0">
											<gml:posList>35.6715459142939 139.74025555310178 39.028 35.671545247013846 139.74025521143741 39.028 35.671545247013846 139.74025521143741 40.606 35.6715459142939 139.74025555310178 40.606 35.6715459142939 139.74025555310178 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9bdbae6-2b84-4f3c-be9e-a064b841cd0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9bdbae6-2b84-4f3c-be9e-a064b841cd0f_0">
											<gml:posList>35.67154311982695 139.7402552801855 39.028 35.67154248015163 139.74025566755282 39.028 35.67154248015163 139.74025566755282 40.606 35.67154311982695 139.7402552801855 40.606 35.67154311982695 139.7402552801855 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6df0fcc5-70bc-428f-9df2-c277108653fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6df0fcc5-70bc-428f-9df2-c277108653fb_0">
											<gml:posList>35.6715459142939 139.74025555310178 39.028 35.6715459142939 139.74025555310178 40.606 35.67154650057 139.74025604951 40.606 35.67154650057 139.74025604951 39.028 35.6715459142939 139.74025555310178 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-215ea236-0d4d-4b41-abee-7d9beb414a79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-215ea236-0d4d-4b41-abee-7d9beb414a79_0">
											<gml:posList>35.67154248015163 139.74025566755282 39.028 35.67154190368334 139.74025619845017 39.028 35.67154190368334 139.74025619845017 40.606 35.67154248015163 139.74025566755282 40.606 35.67154248015163 139.74025566755282 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90a7fc73-bf3a-4687-a097-ed5d662c23a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90a7fc73-bf3a-4687-a097-ed5d662c23a5_0">
											<gml:posList>35.67154699681136 139.74025667857987 39.028 35.67154650057 139.74025604951 39.028 35.67154650057 139.74025604951 40.606 35.67154699681136 139.74025667857987 40.606 35.67154699681136 139.74025667857987 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8af70a07-7282-483b-8e39-1a4afb6fe6d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8af70a07-7282-483b-8e39-1a4afb6fe6d9_0">
											<gml:posList>35.67154190368334 139.74025619845017 39.028 35.67154144449591 139.74025686176844 39.028 35.67154144449591 139.74025686176844 40.606 35.67154190368334 139.74025619845017 40.606 35.67154190368334 139.74025619845017 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5b4b4312-e384-4ea2-8921-91306e177888">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5b4b4312-e384-4ea2-8921-91306e177888_0">
											<gml:posList>35.67154699681136 139.74025667857987 39.028 35.67154699681136 139.74025667857987 40.606 35.67154736696308 139.74025744035313 40.606 35.67154736696308 139.74025744035313 39.028 35.67154699681136 139.74025667857987 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6a6ab1b-2446-45aa-bdd1-e96b74b94bfa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6a6ab1b-2446-45aa-bdd1-e96b74b94bfa_0">
											<gml:posList>35.67154144449591 139.74025686176844 39.028 35.67154110258076 139.74025764646115 39.028 35.67154110258076 139.74025764646115 40.606 35.67154144449591 139.74025686176844 40.606 35.67154144449591 139.74025686176844 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54c0b424-3e1e-49bd-b9a7-99342da60490">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54c0b424-3e1e-49bd-b9a7-99342da60490_0">
											<gml:posList>35.67154761096541 139.74025825750496 39.028 35.67154736696308 139.74025744035313 39.028 35.67154736696308 139.74025744035313 40.606 35.67154761096541 139.74025825750496 40.606 35.67154761096541 139.74025825750496 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0980e113-2b6c-458f-9dd9-077d9e4f84de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0980e113-2b6c-458f-9dd9-077d9e4f84de_0">
											<gml:posList>35.67154089591411 139.74025848622895 39.028 35.67154089591411 139.74025848622895 40.606 35.67154110258076 139.74025764646115 40.606 35.67154110258076 139.74025764646115 39.028 35.67154089591411 139.74025848622895 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9022727-d97f-4c4c-b062-a0312ad92c9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9022727-d97f-4c4c-b062-a0312ad92c9c_0">
											<gml:posList>35.67154771079942 139.7402591411027 39.028 35.67154761096541 139.74025825750496 39.028 35.67154761096541 139.74025825750496 40.606 35.67154771079942 139.7402591411027 40.606 35.67154771079942 139.7402591411027 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-143cdd42-175f-470a-8a41-73b8cfa42b39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-143cdd42-175f-470a-8a41-73b8cfa42b39_0">
											<gml:posList>35.67154089591411 139.74025848622895 39.028 35.67154084250633 139.74025935895807 39.028 35.67154084250633 139.74025935895807 40.606 35.67154089591411 139.74025848622895 40.606 35.67154089591411 139.74025848622895 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db63fc2e-ee2f-4cb1-b7df-732f0070caf6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db63fc2e-ee2f-4cb1-b7df-732f0070caf6_0">
											<gml:posList>35.67154248015163 139.74025566755282 40.606 35.67154190368334 139.74025619845017 40.606 35.67154144449591 139.74025686176844 40.606 35.67154110258076 139.74025764646115 40.606 35.67154089591411 139.74025848622895 40.606 35.67154084250633 139.74025935895807 40.606 35.671540933318084 139.74026023151978 40.606 35.67154117732892 139.74026105971797 40.606 35.67154154747209 139.7402618104448 40.606 35.67154204372195 139.74026245056103 40.606 35.671542639011754 139.7402629469589 40.606 35.671543297278056 139.74026328863374 40.606 35.671544009481536 139.74026344245686 40.606 35.67154472154842 139.7402634195374 40.606 35.67154542445642 139.74026320883948 40.606 35.67154607315403 139.74026283250817 40.606 35.67154664060861 139.74026230162124 40.606 35.671547099787546 139.7402616272566 40.606 35.671547441711255 139.74026085361024 40.606 35.671547648377924 139.74026001384237 40.606 35.67154771079942 139.7402591411027 40.606 35.67154761096541 139.74025825750496 40.606 35.67154736696308 139.74025744035313 40.606 35.67154699681136 139.74025667857987 40.606 35.67154650057 139.74025604951 40.606 35.6715459142939 139.74025555310178 40.606 35.671545247013846 139.74025521143741 40.606 35.671544534810344 139.74025505761438 40.606 35.67154382274347 139.74025508053387 40.606 35.67154311982695 139.7402552801855 40.606 35.67154248015163 139.74025566755282 40.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14a8cd07-8769-4f41-b8e9-6ad787d1a14d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14a8cd07-8769-4f41-b8e9-6ad787d1a14d_0">
											<gml:posList>35.671547648377924 139.74026001384237 39.028 35.67154771079942 139.7402591411027 39.028 35.67154771079942 139.7402591411027 40.606 35.671547648377924 139.74026001384237 40.606 35.671547648377924 139.74026001384237 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf6f65fa-922f-4239-b476-ae3edea5f189">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf6f65fa-922f-4239-b476-ae3edea5f189_0">
											<gml:posList>35.67154084250633 139.74025935895807 39.028 35.671540933318084 139.74026023151978 39.028 35.671540933318084 139.74026023151978 40.606 35.67154084250633 139.74025935895807 40.606 35.67154084250633 139.74025935895807 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bdc2474-d9f0-46b5-82a2-dbda5b05d8ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bdc2474-d9f0-46b5-82a2-dbda5b05d8ad_0">
											<gml:posList>35.671547441711255 139.74026085361024 39.028 35.671547648377924 139.74026001384237 39.028 35.671547648377924 139.74026001384237 40.606 35.671547441711255 139.74026085361024 40.606 35.671547441711255 139.74026085361024 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a787b39-e310-47fe-ba6e-3b5e8335ed86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a787b39-e310-47fe-ba6e-3b5e8335ed86_0">
											<gml:posList>35.671540933318084 139.74026023151978 39.028 35.67154117732892 139.74026105971797 39.028 35.67154117732892 139.74026105971797 40.606 35.671540933318084 139.74026023151978 40.606 35.671540933318084 139.74026023151978 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7add636-f996-482e-8cfa-ec9eabc8bf09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7add636-f996-482e-8cfa-ec9eabc8bf09_0">
											<gml:posList>35.671547099787546 139.7402616272566 39.028 35.671547441711255 139.74026085361024 39.028 35.671547441711255 139.74026085361024 40.606 35.671547099787546 139.7402616272566 40.606 35.671547099787546 139.7402616272566 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4bc57242-cfca-4023-a222-e681c864f695">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4bc57242-cfca-4023-a222-e681c864f695_0">
											<gml:posList>35.67154117732892 139.74026105971797 39.028 35.67154154747209 139.7402618104448 39.028 35.67154154747209 139.7402618104448 40.606 35.67154117732892 139.74026105971797 40.606 35.67154117732892 139.74026105971797 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b75a3e17-092f-43a4-96b2-6ff344a9c088">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b75a3e17-092f-43a4-96b2-6ff344a9c088_0">
											<gml:posList>35.67154664060861 139.74026230162124 39.028 35.671547099787546 139.7402616272566 39.028 35.671547099787546 139.7402616272566 40.606 35.67154664060861 139.74026230162124 40.606 35.67154664060861 139.74026230162124 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14fcd246-0997-4096-9758-f16480a7496b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14fcd246-0997-4096-9758-f16480a7496b_0">
											<gml:posList>35.67154154747209 139.7402618104448 39.028 35.67154204372195 139.74026245056103 39.028 35.67154204372195 139.74026245056103 40.606 35.67154154747209 139.7402618104448 40.606 35.67154154747209 139.7402618104448 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2d66a50-8ef0-4e56-8e1f-3e8729e23ff9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2d66a50-8ef0-4e56-8e1f-3e8729e23ff9_0">
											<gml:posList>35.67154607315403 139.74026283250817 39.028 35.67154664060861 139.74026230162124 39.028 35.67154664060861 139.74026230162124 40.606 35.67154607315403 139.74026283250817 40.606 35.67154607315403 139.74026283250817 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9007b1cd-9322-480f-90e0-185c13a89700">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9007b1cd-9322-480f-90e0-185c13a89700_0">
											<gml:posList>35.67154204372195 139.74026245056103 39.028 35.671542639011754 139.7402629469589 39.028 35.671542639011754 139.7402629469589 40.606 35.67154204372195 139.74026245056103 40.606 35.67154204372195 139.74026245056103 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73925a3f-9243-4f8d-a5a1-a8cfcaf94c0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73925a3f-9243-4f8d-a5a1-a8cfcaf94c0a_0">
											<gml:posList>35.67154542445642 139.74026320883948 39.028 35.67154607315403 139.74026283250817 39.028 35.67154607315403 139.74026283250817 40.606 35.67154542445642 139.74026320883948 40.606 35.67154542445642 139.74026320883948 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13917fab-b5cb-460d-bad6-ac16cc808398">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13917fab-b5cb-460d-bad6-ac16cc808398_0">
											<gml:posList>35.671543297278056 139.74026328863374 39.028 35.671543297278056 139.74026328863374 40.606 35.671542639011754 139.7402629469589 40.606 35.671542639011754 139.7402629469589 39.028 35.671543297278056 139.74026328863374 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5ec030c-1c83-4508-8fce-d7aa89df4920">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5ec030c-1c83-4508-8fce-d7aa89df4920_0">
											<gml:posList>35.67154542445642 139.74026320883948 39.028 35.67154542445642 139.74026320883948 40.606 35.67154472154842 139.7402634195374 40.606 35.67154472154842 139.7402634195374 39.028 35.67154542445642 139.74026320883948 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8edb27c-91f4-4881-a126-10f80242eb18">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8edb27c-91f4-4881-a126-10f80242eb18_0">
											<gml:posList>35.671543297278056 139.74026328863374 39.028 35.671544009481536 139.74026344245686 39.028 35.671544009481536 139.74026344245686 40.606 35.671543297278056 139.74026328863374 40.606 35.671543297278056 139.74026328863374 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f4cd9378-5dfd-4447-8718-3be5e0295e7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f4cd9378-5dfd-4447-8718-3be5e0295e7f_0">
											<gml:posList>35.671544009481536 139.74026344245686 39.028 35.67154472154842 139.7402634195374 39.028 35.67154472154842 139.7402634195374 40.606 35.671544009481536 139.74026344245686 40.606 35.671544009481536 139.74026344245686 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-982b6626-502b-4229-8b59-6d3fe13d3714">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-982b6626-502b-4229-8b59-6d3fe13d3714_0">
											<gml:posList>35.671591701847056 139.7402643812716 43.256 35.67158215840157 139.74027875270252 43.256 35.67158215840157 139.74027875270252 43.601 35.671591701847056 139.7402643812716 43.601 35.671591701847056 139.7402643812716 43.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97b05b73-62cf-4af5-bc5e-d8058f600ba0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97b05b73-62cf-4af5-bc5e-d8058f600ba0_0">
											<gml:posList>35.67160949965464 139.74028213431515 43.256 35.671591701847056 139.7402643812716 43.256 35.671591701847056 139.7402643812716 43.601 35.67160949965464 139.74028213431515 43.601 35.67160949965464 139.74028213431515 43.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b0c6bd0-b86e-414a-b8f0-a994030cddec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b0c6bd0-b86e-414a-b8f0-a994030cddec_0">
											<gml:posList>35.67159995620706 139.74029650574715 43.601 35.67160949965464 139.74028213431515 43.601 35.671591701847056 139.7402643812716 43.601 35.67158215840157 139.74027875270252 43.601 35.67159995620706 139.74029650574715 43.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bb1891c-4be4-4958-84ee-068341a3f9e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bb1891c-4be4-4958-84ee-068341a3f9e1_0">
											<gml:posList>35.67159995620706 139.74029650574715 43.256 35.67159995620706 139.74029650574715 43.601 35.67158215840157 139.74027875270252 43.601 35.67158215840157 139.74027875270252 43.256 35.67159995620706 139.74029650574715 43.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77c9c487-597d-414b-ab5c-5d1381a1add4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77c9c487-597d-414b-ab5c-5d1381a1add4_0">
											<gml:posList>35.67159995620706 139.74029650574715 43.256 35.67160949965464 139.74028213431515 43.256 35.67160949965464 139.74028213431515 43.601 35.67159995620706 139.74029650574715 43.601 35.67159995620706 139.74029650574715 43.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-203276ee-f6e0-43ae-ae4d-83f58d441375">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-203276ee-f6e0-43ae-ae4d-83f58d441375_0">
											<gml:posList>35.67153535027688 139.740302302763 39.333 35.67153490911662 139.74030296606003 39.333 35.67153490911662 139.74030296606003 40.362 35.671538168302725 139.74029806871462 40.362 35.671538168302725 139.74029806871462 39.028 35.67153535027688 139.740302302763 39.028 35.67153535027688 139.740302302763 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8c894ed9-ad2e-43e7-abc1-7434ee134dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8c894ed9-ad2e-43e7-abc1-7434ee134dc2_0">
											<gml:posList>35.67154989519491 139.74030977535878 39.028 35.671538168302725 139.74029806871462 39.028 35.671538168302725 139.74029806871462 40.362 35.67154989519491 139.74030977535878 40.362 35.67154989519491 139.74030977535878 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce8d35ce-be7d-4845-a378-3fcb0e4ce0f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce8d35ce-be7d-4845-a378-3fcb0e4ce0f3_0">
											<gml:posList>35.671546636008344 139.74031467270444 40.362 35.67154989519491 139.74030977535878 40.362 35.671538168302725 139.74029806871462 40.362 35.67153490911662 139.74030296606003 40.362 35.671546636008344 139.74031467270444 40.362</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e28cc6d0-d77d-438e-ad73-5b4a5245580c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e28cc6d0-d77d-438e-ad73-5b4a5245580c_0">
											<gml:posList>35.67153535027688 139.740302302763 39.333 35.67153535027688 139.740302302763 39.028 35.67154707716013 139.740313998361 39.028 35.67154707716013 139.740313998361 39.333 35.67153535027688 139.740302302763 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe0eca2c-a576-4bd5-bc7f-79d882c1976c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe0eca2c-a576-4bd5-bc7f-79d882c1976c_0">
											<gml:posList>35.671546636008344 139.74031467270444 39.333 35.671546636008344 139.74031467270444 40.362 35.67153490911662 139.74030296606003 40.362 35.67153490911662 139.74030296606003 39.333 35.671546636008344 139.74031467270444 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d81a4c7-5aef-43f4-b988-805106066d89">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d81a4c7-5aef-43f4-b988-805106066d89_0">
											<gml:posList>35.67154989519491 139.74030977535878 39.028 35.67154989519491 139.74030977535878 40.362 35.671546636008344 139.74031467270444 40.362 35.671546636008344 139.74031467270444 39.333 35.67154707716013 139.740313998361 39.333 35.67154707716013 139.740313998361 39.028 35.67154989519491 139.74030977535878 39.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-f4d476a6-5ddb-425a-a2c6-101ad0492def">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4d476a6-5ddb-425a-a2c6-101ad0492def">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4d476a6-5ddb-425a-a2c6-101ad0492def">
											<gml:posList>35.67156552937868 139.74032711114904 8.92 35.67156114478167 139.74033369990303 8.92 35.67145957183494 139.74023230123368 8.92 35.67147145619441 139.74021450271346 8.92 35.67145269313084 139.74019574561368 8.92 35.67148942637821 139.74014047087985 8.92 35.67162058720437 139.74027132908432 8.92 35.67157636322714 139.74033793512334 8.92 35.67156552937868 139.74032711114904 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ef427be-1886-4339-869a-13b9aabcd6de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ef427be-1886-4339-869a-13b9aabcd6de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ef427be-1886-4339-869a-13b9aabcd6de">
											<gml:posList>35.67147145619441 139.74021450271346 21.132 35.67147591756772 139.74021395625763 21.132 35.67145715449553 139.74019518811056 21.132 35.67145269313084 139.74019574561368 21.132 35.67147145619441 139.74021450271346 21.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1e207b8a-84f7-41dd-9bd3-379e7c7c7234">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e207b8a-84f7-41dd-9bd3-379e7c7c7234">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e207b8a-84f7-41dd-9bd3-379e7c7c7234">
											<gml:posList>35.67145269313084 139.74019574561368 21.132 35.67145715449553 139.74019518811056 21.132 35.671489881296075 139.74014593832516 21.132 35.67148942637821 139.74014047087985 21.132 35.67145269313084 139.74019574561368 21.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-deada91e-a288-4030-866e-3bb98c6ccc16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-deada91e-a288-4030-866e-3bb98c6ccc16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-deada91e-a288-4030-866e-3bb98c6ccc16">
											<gml:posList>35.67149437879849 139.74026203089753 20.121 35.67149670164036 139.74025853753443 20.121 35.67148863712331 139.7402504609229 20.121 35.67152512651244 139.74019452368756 20.121 35.67153391223339 139.7402027320164 20.121 35.671539712028626 139.74020786186426 20.121 35.67154459179243 139.74020052137342 20.121 35.671489881296075 139.74014593832516 20.121 35.67145715449553 139.74019518811056 20.121 35.67147591756772 139.74021395625763 20.121 35.67146403319979 139.74023174373258 20.121 35.671491916148604 139.74025957040632 20.121 35.67149437879849 139.74026203089753 20.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5003e270-959f-4205-ac36-05c6612b5f33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5003e270-959f-4205-ac36-05c6612b5f33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5003e270-959f-4205-ac36-05c6612b5f33">
											<gml:posList>35.671489881296075 139.74014593832516 21.132 35.67154459179243 139.74020052137342 21.132 35.67154659050594 139.74019750337897 21.132 35.67148942637821 139.74014047087985 21.132 35.671489881296075 139.74014593832516 21.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3f8040ec-502f-4454-bc43-4bc9c82eafa4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3f8040ec-502f-4454-bc43-4bc9c82eafa4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3f8040ec-502f-4454-bc43-4bc9c82eafa4">
											<gml:posList>35.67147145619441 139.74021450271346 21.132 35.67145957183494 139.74023230123368 21.132 35.67146403319979 139.74023174373258 21.132 35.67147591756772 139.74021395625763 21.132 35.67147145619441 139.74021450271346 21.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16a8f94d-b113-40b5-af3e-3e8e952f465b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16a8f94d-b113-40b5-af3e-3e8e952f465b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16a8f94d-b113-40b5-af3e-3e8e952f465b">
											<gml:posList>35.67152512651244 139.74019452368756 33.179 35.67148863712331 139.7402504609229 33.179 35.67149670164036 139.74025853753443 33.179 35.67153391223339 139.7402027320164 33.179 35.67152512651244 139.74019452368756 33.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-79a2dcad-037e-4708-9fcc-898085bca06e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79a2dcad-037e-4708-9fcc-898085bca06e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79a2dcad-037e-4708-9fcc-898085bca06e">
											<gml:posList>35.67151089053842 139.74028353014646 36.109 35.67155949911088 139.74021037955777 36.109 35.67154659050594 139.74019750337897 36.109 35.671539712028626 139.74020786186426 36.109 35.67153391223339 139.7402027320164 36.109 35.67149237106108 139.74026503785248 36.109 35.67151089053842 139.74028353014646 36.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-412fdb1e-c81d-4a43-a9f7-3316d8c4ad12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-412fdb1e-c81d-4a43-a9f7-3316d8c4ad12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-412fdb1e-c81d-4a43-a9f7-3316d8c4ad12">
											<gml:posList>35.671491916148604 139.74025957040632 21.132 35.67146403319979 139.74023174373258 21.132 35.67145957183494 139.74023230123368 21.132 35.67149237106108 139.74026503785248 21.132 35.67149437879849 139.74026203089753 21.132 35.671491916148604 139.74025957040632 21.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4dd99b20-c800-40ee-b6a8-db8b0c88e017">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4dd99b20-c800-40ee-b6a8-db8b0c88e017">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4dd99b20-c800-40ee-b6a8-db8b0c88e017">
											<gml:posList>35.67159355701393 139.7402505710848 43.601 35.67159383900956 139.74025389573183 43.601 35.671615398442896 139.74027540019327 43.601 35.671618111308206 139.74027505460512 43.601 35.67159355701393 139.7402505710848 43.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-961a90e7-cedf-4189-beb8-9bdf7bf3d531">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-961a90e7-cedf-4189-beb8-9bdf7bf3d531">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-961a90e7-cedf-4189-beb8-9bdf7bf3d531">
											<gml:posList>35.67157308362493 139.74028140333053 43.601 35.67157580549546 139.74028104668588 43.601 35.67159383900956 139.74025389573183 43.601 35.67159355701393 139.7402505710848 43.601 35.67157308362493 139.74028140333053 43.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5763b491-1f28-475a-a180-4f25b358ca0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5763b491-1f28-475a-a180-4f25b358ca0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5763b491-1f28-475a-a180-4f25b358ca0d">
											<gml:posList>35.67156114478167 139.74033369990303 39.333 35.67156552937868 139.74032711114904 39.333 35.6715868040788 139.74029508497404 39.333 35.67157308362493 139.74028140333053 39.333 35.67159355701393 139.7402505710848 39.333 35.671618111308206 139.74027505460512 39.333 35.67162058720437 139.74027132908432 39.333 35.67155949911088 139.74021037955777 39.333 35.67151089053842 139.74028353014646 39.333 35.67156114478167 139.74033369990303 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9ca7fd46-33b7-4316-a37d-85c706b347e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ca7fd46-33b7-4316-a37d-85c706b347e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ca7fd46-33b7-4316-a37d-85c706b347e7">
											<gml:posList>35.671615398442896 139.74027540019327 43.256 35.67159383900956 139.74025389573183 43.256 35.67157580549546 139.74028104668588 43.256 35.67159734690511 139.74030256221718 43.256 35.671615398442896 139.74027540019327 43.256</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d187c3f-f93d-4288-9be6-3371b2ea9762">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d187c3f-f93d-4288-9be6-3371b2ea9762">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d187c3f-f93d-4288-9be6-3371b2ea9762">
											<gml:posList>35.671618111308206 139.74027505460512 43.601 35.671615398442896 139.74027540019327 43.601 35.67159734690511 139.74030256221718 43.601 35.67159763792156 139.74030589790047 43.601 35.671618111308206 139.74027505460512 43.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ddd9f65b-89d5-42d0-94ea-17d9c632db6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ddd9f65b-89d5-42d0-94ea-17d9c632db6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ddd9f65b-89d5-42d0-94ea-17d9c632db6b">
											<gml:posList>35.67159763792156 139.74030589790047 43.601 35.67159734690511 139.74030256221718 43.601 35.67157580549546 139.74028104668588 43.601 35.67157308362493 139.74028140333053 43.601 35.67159763792156 139.74030589790047 43.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dfaeac35-bf0a-4f74-ac18-2764628e5cd6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfaeac35-bf0a-4f74-ac18-2764628e5cd6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfaeac35-bf0a-4f74-ac18-2764628e5cd6">
											<gml:posList>35.67159763792156 139.74030589790047 39.088 35.6715868040788 139.74029508497404 39.088 35.67157043614824 139.74031971539964 37.6 35.67158127900254 139.74033052831678 37.6 35.67159763792156 139.74030589790047 39.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22af4392-4614-4309-a5b6-b710994cb2bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22af4392-4614-4309-a5b6-b710994cb2bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22af4392-4614-4309-a5b6-b710994cb2bc">
											<gml:posList>35.67156552937868 139.74032711114904 37.6 35.67157636322714 139.74033793512334 37.6 35.67158127900254 139.74033052831678 37.6 35.67157043614824 139.74031971539964 37.6 35.67156552937868 139.74032711114904 37.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39400fcd-ba72-4665-8262-640eb43b3a7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39400fcd-ba72-4665-8262-640eb43b3a7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39400fcd-ba72-4665-8262-640eb43b3a7c">
											<gml:posList>35.671491916148604 139.74025957040632 21.132 35.671491916148604 139.74025957040632 20.121 35.67146403319979 139.74023174373258 20.121 35.67146403319979 139.74023174373258 21.132 35.671491916148604 139.74025957040632 21.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ee5cbbc-b515-4f85-8ef6-17e293f00b80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ee5cbbc-b515-4f85-8ef6-17e293f00b80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ee5cbbc-b515-4f85-8ef6-17e293f00b80">
											<gml:posList>35.67149437879849 139.74026203089753 21.132 35.67149437879849 139.74026203089753 20.121 35.671491916148604 139.74025957040632 20.121 35.671491916148604 139.74025957040632 21.132 35.67149437879849 139.74026203089753 21.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e895a17-fae4-4bbe-8a7b-c2f194f35acd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e895a17-fae4-4bbe-8a7b-c2f194f35acd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e895a17-fae4-4bbe-8a7b-c2f194f35acd">
											<gml:posList>35.67157580549546 139.74028104668588 43.601 35.67157580549546 139.74028104668588 43.256 35.67159383900956 139.74025389573183 43.256 35.67159383900956 139.74025389573183 43.601 35.67157580549546 139.74028104668588 43.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d2059d7f-930d-46e2-878c-1903aa4e580a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d2059d7f-930d-46e2-878c-1903aa4e580a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d2059d7f-930d-46e2-878c-1903aa4e580a">
											<gml:posList>35.67145957183494 139.74023230123368 8.92 35.67156114478167 139.74033369990303 8.92 35.67156114478167 139.74033369990303 39.333 35.67151089053842 139.74028353014646 39.333 35.67151089053842 139.74028353014646 36.109 35.67149237106108 139.74026503785248 36.109 35.67149237106108 139.74026503785248 21.132 35.67145957183494 139.74023230123368 21.132 35.67145957183494 139.74023230123368 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41b6b686-d241-4ab8-8c85-8b777150fd32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41b6b686-d241-4ab8-8c85-8b777150fd32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41b6b686-d241-4ab8-8c85-8b777150fd32">
											<gml:posList>35.67145269313084 139.74019574561368 8.92 35.67147145619441 139.74021450271346 8.92 35.67147145619441 139.74021450271346 21.132 35.67145269313084 139.74019574561368 21.132 35.67145269313084 139.74019574561368 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2f7c226-2d47-441b-adef-9cc675eab8e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2f7c226-2d47-441b-adef-9cc675eab8e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2f7c226-2d47-441b-adef-9cc675eab8e2">
											<gml:posList>35.67147145619441 139.74021450271346 8.92 35.67145957183494 139.74023230123368 8.92 35.67145957183494 139.74023230123368 21.132 35.67147145619441 139.74021450271346 21.132 35.67147145619441 139.74021450271346 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1a91541-d7ac-4147-8d7b-9dd3195445ae">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1a91541-d7ac-4147-8d7b-9dd3195445ae">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1a91541-d7ac-4147-8d7b-9dd3195445ae">
											<gml:posList>35.67147591756772 139.74021395625763 21.132 35.67147591756772 139.74021395625763 20.121 35.67145715449553 139.74019518811056 20.121 35.67145715449553 139.74019518811056 21.132 35.67147591756772 139.74021395625763 21.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70b10de3-d0f6-4c98-beee-10d777937bbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70b10de3-d0f6-4c98-beee-10d777937bbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70b10de3-d0f6-4c98-beee-10d777937bbc">
											<gml:posList>35.67146403319979 139.74023174373258 21.132 35.67146403319979 139.74023174373258 20.121 35.67147591756772 139.74021395625763 20.121 35.67147591756772 139.74021395625763 21.132 35.67146403319979 139.74023174373258 21.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99af4ef4-654b-4e13-a2ab-4553565ad804">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99af4ef4-654b-4e13-a2ab-4553565ad804">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99af4ef4-654b-4e13-a2ab-4553565ad804">
											<gml:posList>35.67148942637821 139.74014047087985 8.92 35.67145269313084 139.74019574561368 8.92 35.67145269313084 139.74019574561368 21.132 35.67148942637821 139.74014047087985 21.132 35.67148942637821 139.74014047087985 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e37a7c52-21d7-4042-91f2-1be368614c9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e37a7c52-21d7-4042-91f2-1be368614c9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e37a7c52-21d7-4042-91f2-1be368614c9d">
											<gml:posList>35.67145715449553 139.74019518811056 21.132 35.67145715449553 139.74019518811056 20.121 35.671489881296075 139.74014593832516 20.121 35.671489881296075 139.74014593832516 21.132 35.67145715449553 139.74019518811056 21.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3fcc7ff4-82f9-42f1-af8d-e553a0bfb260">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fcc7ff4-82f9-42f1-af8d-e553a0bfb260">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fcc7ff4-82f9-42f1-af8d-e553a0bfb260">
											<gml:posList>35.67148863712331 139.7402504609229 20.121 35.67149670164036 139.74025853753443 20.121 35.67149670164036 139.74025853753443 33.179 35.67148863712331 139.7402504609229 33.179 35.67148863712331 139.7402504609229 20.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-795ec639-b834-47c2-bad7-6f8caf4db640">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-795ec639-b834-47c2-bad7-6f8caf4db640">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-795ec639-b834-47c2-bad7-6f8caf4db640">
											<gml:posList>35.67148863712331 139.7402504609229 33.179 35.67152512651244 139.74019452368756 33.179 35.67152512651244 139.74019452368756 20.121 35.67148863712331 139.7402504609229 20.121 35.67148863712331 139.7402504609229 33.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87232d0f-bf3d-4242-b453-5df79c620f2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87232d0f-bf3d-4242-b453-5df79c620f2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87232d0f-bf3d-4242-b453-5df79c620f2e">
											<gml:posList>35.67149237106108 139.74026503785248 36.109 35.67153391223339 139.7402027320164 36.109 35.67153391223339 139.7402027320164 33.179 35.67149670164036 139.74025853753443 33.179 35.67149670164036 139.74025853753443 20.121 35.67149437879849 139.74026203089753 20.121 35.67149437879849 139.74026203089753 21.132 35.67149237106108 139.74026503785248 21.132 35.67149237106108 139.74026503785248 36.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70b33af6-37e6-4149-b5fd-7aa10b1e1534">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70b33af6-37e6-4149-b5fd-7aa10b1e1534">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70b33af6-37e6-4149-b5fd-7aa10b1e1534">
											<gml:posList>35.671489881296075 139.74014593832516 21.132 35.671489881296075 139.74014593832516 20.121 35.67154459179243 139.74020052137342 20.121 35.67154459179243 139.74020052137342 21.132 35.671489881296075 139.74014593832516 21.132</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22c7149e-773d-48de-87e1-1a7ed3b5f861">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22c7149e-773d-48de-87e1-1a7ed3b5f861">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22c7149e-773d-48de-87e1-1a7ed3b5f861">
											<gml:posList>35.67152512651244 139.74019452368756 33.179 35.67153391223339 139.7402027320164 33.179 35.67153391223339 139.7402027320164 20.121 35.67152512651244 139.74019452368756 20.121 35.67152512651244 139.74019452368756 33.179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-096192d4-4f79-44a2-99d1-52d5bf568f8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-096192d4-4f79-44a2-99d1-52d5bf568f8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-096192d4-4f79-44a2-99d1-52d5bf568f8a">
											<gml:posList>35.67151089053842 139.74028353014646 36.109 35.67151089053842 139.74028353014646 39.333 35.67155949911088 139.74021037955777 39.333 35.67155949911088 139.74021037955777 36.109 35.67151089053842 139.74028353014646 36.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0cc884fc-3fcc-43f7-95d8-850c9fb126d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cc884fc-3fcc-43f7-95d8-850c9fb126d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cc884fc-3fcc-43f7-95d8-850c9fb126d0">
											<gml:posList>35.671539712028626 139.74020786186426 36.109 35.671539712028626 139.74020786186426 20.121 35.67153391223339 139.7402027320164 20.121 35.67153391223339 139.7402027320164 33.179 35.67153391223339 139.7402027320164 36.109 35.671539712028626 139.74020786186426 36.109</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-beadacc3-4266-4c39-a93c-fd80dc3a3190">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-beadacc3-4266-4c39-a93c-fd80dc3a3190">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-beadacc3-4266-4c39-a93c-fd80dc3a3190">
											<gml:posList>35.671539712028626 139.74020786186426 20.121 35.671539712028626 139.74020786186426 36.109 35.67154659050594 139.74019750337897 36.109 35.67154659050594 139.74019750337897 21.132 35.67154459179243 139.74020052137342 21.132 35.67154459179243 139.74020052137342 20.121 35.671539712028626 139.74020786186426 20.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4aa6ee3-a460-4719-a07e-530f47a9da4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4aa6ee3-a460-4719-a07e-530f47a9da4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4aa6ee3-a460-4719-a07e-530f47a9da4a">
											<gml:posList>35.67162058720437 139.74027132908432 8.92 35.67148942637821 139.74014047087985 8.92 35.67148942637821 139.74014047087985 21.132 35.67154659050594 139.74019750337897 21.132 35.67154659050594 139.74019750337897 36.109 35.67155949911088 139.74021037955777 36.109 35.67155949911088 139.74021037955777 39.333 35.67162058720437 139.74027132908432 39.333 35.67162058720437 139.74027132908432 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e799a4a-9708-40ed-8f7c-7ac72723ae1b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e799a4a-9708-40ed-8f7c-7ac72723ae1b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e799a4a-9708-40ed-8f7c-7ac72723ae1b">
											<gml:posList>35.67156114478167 139.74033369990303 39.333 35.67156114478167 139.74033369990303 8.92 35.67156552937868 139.74032711114904 8.92 35.67156552937868 139.74032711114904 37.6 35.67156552937868 139.74032711114904 39.333 35.67156114478167 139.74033369990303 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-259aa24e-eebe-4ae4-bbe6-d3ff95128438">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-259aa24e-eebe-4ae4-bbe6-d3ff95128438">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-259aa24e-eebe-4ae4-bbe6-d3ff95128438">
											<gml:posList>35.67157636322714 139.74033793512334 37.6 35.67156552937868 139.74032711114904 37.6 35.67156552937868 139.74032711114904 8.92 35.67157636322714 139.74033793512334 8.92 35.67157636322714 139.74033793512334 37.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c63c7426-f1a0-421f-8a35-6114ca9f4036">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c63c7426-f1a0-421f-8a35-6114ca9f4036">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c63c7426-f1a0-421f-8a35-6114ca9f4036">
											<gml:posList>35.67156552937868 139.74032711114904 39.333 35.67156552937868 139.74032711114904 37.6 35.67157043614824 139.74031971539964 37.6 35.6715868040788 139.74029508497404 39.088 35.6715868040788 139.74029508497404 39.333 35.67156552937868 139.74032711114904 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4171856a-0dd9-4c75-a63d-c783fe317a5b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4171856a-0dd9-4c75-a63d-c783fe317a5b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4171856a-0dd9-4c75-a63d-c783fe317a5b">
											<gml:posList>35.67159355701393 139.7402505710848 43.601 35.67159355701393 139.7402505710848 39.333 35.67157308362493 139.74028140333053 39.333 35.67157308362493 139.74028140333053 43.601 35.67159355701393 139.7402505710848 43.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8c7ac17-e1bb-4f3e-99b6-c9dd25e5865d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8c7ac17-e1bb-4f3e-99b6-c9dd25e5865d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8c7ac17-e1bb-4f3e-99b6-c9dd25e5865d">
											<gml:posList>35.67159763792156 139.74030589790047 39.088 35.67159763792156 139.74030589790047 43.601 35.67157308362493 139.74028140333053 43.601 35.67157308362493 139.74028140333053 39.333 35.6715868040788 139.74029508497404 39.333 35.6715868040788 139.74029508497404 39.088 35.67159763792156 139.74030589790047 39.088</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c4f1f6d-9c4e-47f2-a138-5c0d6028df5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c4f1f6d-9c4e-47f2-a138-5c0d6028df5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c4f1f6d-9c4e-47f2-a138-5c0d6028df5d">
											<gml:posList>35.67159734690511 139.74030256221718 43.601 35.67159734690511 139.74030256221718 43.256 35.67157580549546 139.74028104668588 43.256 35.67157580549546 139.74028104668588 43.601 35.67159734690511 139.74030256221718 43.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd37f596-66ca-4526-9509-994d713f4755">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd37f596-66ca-4526-9509-994d713f4755">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd37f596-66ca-4526-9509-994d713f4755">
											<gml:posList>35.67157636322714 139.74033793512334 8.92 35.67162058720437 139.74027132908432 8.92 35.67162058720437 139.74027132908432 39.333 35.671618111308206 139.74027505460512 39.333 35.671618111308206 139.74027505460512 43.601 35.67159763792156 139.74030589790047 43.601 35.67159763792156 139.74030589790047 39.088 35.67158127900254 139.74033052831678 37.6 35.67157636322714 139.74033793512334 37.6 35.67157636322714 139.74033793512334 8.92</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4942b80e-d71f-4610-bb5a-53da03022567">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4942b80e-d71f-4610-bb5a-53da03022567">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4942b80e-d71f-4610-bb5a-53da03022567">
											<gml:posList>35.67159355701393 139.7402505710848 39.333 35.67159355701393 139.7402505710848 43.601 35.671618111308206 139.74027505460512 43.601 35.671618111308206 139.74027505460512 39.333 35.67159355701393 139.7402505710848 39.333</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-212eabb0-79bd-4020-8bd3-704426473152">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-212eabb0-79bd-4020-8bd3-704426473152">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-212eabb0-79bd-4020-8bd3-704426473152">
											<gml:posList>35.67159383900956 139.74025389573183 43.601 35.67159383900956 139.74025389573183 43.256 35.671615398442896 139.74027540019327 43.256 35.671615398442896 139.74027540019327 43.601 35.67159383900956 139.74025389573183 43.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4165e64e-4ac3-449e-b085-61499a046dfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4165e64e-4ac3-449e-b085-61499a046dfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4165e64e-4ac3-449e-b085-61499a046dfd">
											<gml:posList>35.671615398442896 139.74027540019327 43.601 35.671615398442896 139.74027540019327 43.256 35.67159734690511 139.74030256221718 43.256 35.67159734690511 139.74030256221718 43.601 35.671615398442896 139.74027540019327 43.601</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2905</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">148.2411</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.09</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>