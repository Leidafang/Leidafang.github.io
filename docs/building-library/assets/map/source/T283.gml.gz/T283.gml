<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_50af5ad9-b7ee-43d3-ada7-70f4a8f36d10">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門駅南地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">413</bldg:usage>
			<bldg:measuredHeight uom="m">15.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66877152592588 139.7489558278111 0 35.66874912662105 139.74901991838857 0 35.668826852863546 139.7490597128847 0 35.66884997297789 139.74899517965602 0 35.66877152592588 139.7489558278111 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877152592588 139.7489558278111 5.569 35.66884997297789 139.74899517965602 5.569 35.668826852863546 139.7490597128847 5.569 35.66874912662105 139.74901991838857 5.569 35.66877152592588 139.7489558278111 5.569</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877152592588 139.7489558278111 5.569 35.66874912662105 139.74901991838857 5.569 35.66874912662105 139.74901991838857 21.48 35.66877152592588 139.7489558278111 21.48 35.66877152592588 139.7489558278111 5.569</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66874912662105 139.74901991838857 5.569 35.668826852863546 139.7490597128847 5.569 35.668826852863546 139.7490597128847 21.48 35.66874912662105 139.74901991838857 21.48 35.66874912662105 139.74901991838857 5.569</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668826852863546 139.7490597128847 5.569 35.66884997297789 139.74899517965602 5.569 35.66884997297789 139.74899517965602 21.48 35.668826852863546 139.7490597128847 21.48 35.668826852863546 139.7490597128847 5.569</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884997297789 139.74899517965602 5.569 35.66877152592588 139.7489558278111 5.569 35.66877152592588 139.7489558278111 21.48 35.66884997297789 139.74899517965602 21.48 35.66884997297789 139.74899517965602 5.569</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877152592588 139.7489558278111 21.48 35.66874912662105 139.74901991838857 21.48 35.668826852863546 139.7490597128847 21.48 35.66884997297789 139.74899517965602 21.48 35.66877152592588 139.7489558278111 21.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1c79153e-9a1d-457a-b2ac-59fa32ac7853"/>
							<gml:surfaceMember xlink:href="#poly-c03f6197-1e98-461c-9f22-2da5cc365c7b"/>
							<gml:surfaceMember xlink:href="#poly-5bc8d37e-b573-4088-9801-a70dd1c26098"/>
							<gml:surfaceMember xlink:href="#poly-67d21662-3de3-415d-8949-d7434738a89d"/>
							<gml:surfaceMember xlink:href="#poly-9a51b01c-492c-44e6-9b73-ce60877a2155"/>
							<gml:surfaceMember xlink:href="#poly-87e85ec6-0b92-44d1-8044-aaf81c2a9b02"/>
							<gml:surfaceMember xlink:href="#poly-a5a4c715-36eb-4a20-a9a5-4b279ed5300e"/>
							<gml:surfaceMember xlink:href="#poly-1bb90092-cf5b-4462-9979-34d3457c1d9a"/>
							<gml:surfaceMember xlink:href="#poly-3343b686-1d98-4129-bea2-c965b4615681"/>
							<gml:surfaceMember xlink:href="#poly-35db9d80-8a9d-4618-ad6f-897f54dc35d1"/>
							<gml:surfaceMember xlink:href="#poly-34cc878b-16ac-4f2b-8554-e95fd193e5d4"/>
							<gml:surfaceMember xlink:href="#poly-96ad49c8-07c6-42c2-b958-37e606344582"/>
							<gml:surfaceMember xlink:href="#poly-481cf9c2-513c-48c2-a07d-099f46f1fd45"/>
							<gml:surfaceMember xlink:href="#poly-98459109-1986-4486-8d90-117635604232"/>
							<gml:surfaceMember xlink:href="#poly-913f9586-668f-4725-a564-340312576aaf"/>
							<gml:surfaceMember xlink:href="#poly-7e8a0ed5-dbfd-40ce-a7fa-775817cba7bb"/>
							<gml:surfaceMember xlink:href="#poly-c761fc3e-df27-428c-b8f5-c69f011fe5ce"/>
							<gml:surfaceMember xlink:href="#poly-7a2b5200-5494-4c81-988e-d8dd058cff16"/>
							<gml:surfaceMember xlink:href="#poly-ecee7fa4-cb09-4c47-a14d-17fcdfc5518d"/>
							<gml:surfaceMember xlink:href="#poly-43ff8fe5-6a13-4142-9d7e-787f1e7011e9"/>
							<gml:surfaceMember xlink:href="#poly-dab752b0-1867-4e57-af31-1b49b1582f1a"/>
							<gml:surfaceMember xlink:href="#poly-2526e273-0fe1-4490-8916-ee3d8ef584c8"/>
							<gml:surfaceMember xlink:href="#poly-305afac1-b6e7-48e2-8eeb-bb5c922efbfe"/>
							<gml:surfaceMember xlink:href="#poly-45924083-abe2-46df-93eb-bf7231936de8"/>
							<gml:surfaceMember xlink:href="#poly-9459fcd6-f9df-4b69-8ae0-8ee207189705"/>
							<gml:surfaceMember xlink:href="#poly-a6305e10-0ce0-4076-ae61-160a8df8321b"/>
							<gml:surfaceMember xlink:href="#poly-11e08ac6-7d3f-4465-890d-4104910dd976"/>
							<gml:surfaceMember xlink:href="#poly-de9aad82-c23d-40e0-a845-7dadfa4d2e65"/>
							<gml:surfaceMember xlink:href="#poly-841db583-1ce7-46a9-936b-152ffc70bafd"/>
							<gml:surfaceMember xlink:href="#poly-9a99bf22-712c-4a84-a899-154ca59afd4f"/>
							<gml:surfaceMember xlink:href="#poly-0b17cb39-74b9-470a-946f-50a98116ec5d"/>
							<gml:surfaceMember xlink:href="#poly-0c5b8a42-dc47-4587-82a9-ef569d3c5861"/>
							<gml:surfaceMember xlink:href="#poly-13afa9e1-6192-45b9-b156-839ed9da65c7"/>
							<gml:surfaceMember xlink:href="#poly-b1ed90b7-a17e-4688-b099-99ab0481b809"/>
							<gml:surfaceMember xlink:href="#poly-5f0deeec-5d7e-4e97-ac26-c74f1fd54f79"/>
							<gml:surfaceMember xlink:href="#poly-9e220db1-d78c-4756-84f2-aafd09b3f50f"/>
							<gml:surfaceMember xlink:href="#poly-646156ae-432c-4f9b-827b-e8e46cc72c12"/>
							<gml:surfaceMember xlink:href="#poly-af25c204-7547-453e-9429-955f0a308314"/>
							<gml:surfaceMember xlink:href="#poly-dabb7ab9-ca3e-49b4-bb11-13c97ca9f4c3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1c79153e-9a1d-457a-b2ac-59fa32ac7853">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c79153e-9a1d-457a-b2ac-59fa32ac7853">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c79153e-9a1d-457a-b2ac-59fa32ac7853">
											<gml:posList>35.66877152592584 139.7489558278111 5.569 35.66884997297787 139.74899517965602 5.569 35.668826852863546 139.74905971288473 5.569 35.668749126621044 139.74901991838857 5.569 35.66877152592584 139.7489558278111 5.569</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c03f6197-1e98-461c-9f22-2da5cc365c7b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c03f6197-1e98-461c-9f22-2da5cc365c7b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c03f6197-1e98-461c-9f22-2da5cc365c7b">
											<gml:posList>35.668814114220254 139.7489792779312 21.6 35.66881470787268 139.7489774878474 21.6 35.668812662491746 139.74897853937347 21.6 35.668814114220254 139.7489792779312 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5bc8d37e-b573-4088-9801-a70dd1c26098">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5bc8d37e-b573-4088-9801-a70dd1c26098">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5bc8d37e-b573-4088-9801-a70dd1c26098">
											<gml:posList>35.66883594433158 139.74902911682375 24.142 35.668838224007985 139.74902797668395 24.142 35.66883660096481 139.7490271609829 24.142 35.66883594433158 139.74902911682375 24.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67d21662-3de3-415d-8949-d7434738a89d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67d21662-3de3-415d-8949-d7434738a89d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67d21662-3de3-415d-8949-d7434738a89d">
											<gml:posList>35.668749126621044 139.74901991838857 21.6 35.66875119905902 139.74901888892802 21.6 35.66877237496545 139.7489583233224 21.6 35.66877152592584 139.7489558278111 21.6 35.668749126621044 139.74901991838857 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a51b01c-492c-44e6-9b73-ce60877a2155">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a51b01c-492c-44e6-9b73-ce60877a2155">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a51b01c-492c-44e6-9b73-ce60877a2155">
											<gml:posList>35.66880580726333 139.7490489319738 21.6 35.66880494918868 139.74904640333185 21.6 35.66875119905902 139.74901888892802 21.6 35.668749126621044 139.74901991838857 21.6 35.66880580726333 139.7490489319738 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87e85ec6-0b92-44d1-8044-aaf81c2a9b02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87e85ec6-0b92-44d1-8044-aaf81c2a9b02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87e85ec6-0b92-44d1-8044-aaf81c2a9b02">
											<gml:posList>35.668812662491746 139.74897853937347 21.287 35.66877237496545 139.7489583233224 21.287 35.66875119905902 139.74901888892802 21.287 35.66880494918868 139.74904640333185 21.287 35.668806409930525 139.74904714188125 21.287 35.66881645721401 139.74901706398566 21.287 35.66880363517686 139.7490106265796 21.287 35.668814114220254 139.7489792779312 21.287 35.668812662491746 139.74897853937347 21.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5a4c715-36eb-4a20-a9a5-4b279ed5300e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5a4c715-36eb-4a20-a9a5-4b279ed5300e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5a4c715-36eb-4a20-a9a5-4b279ed5300e">
											<gml:posList>35.66877152592584 139.7489558278111 21.6 35.66877237496545 139.7489583233224 21.6 35.668812662491746 139.74897853937347 21.6 35.66881470787268 139.7489774878474 21.6 35.66877152592584 139.7489558278111 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1bb90092-cf5b-4462-9979-34d3457c1d9a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bb90092-cf5b-4462-9979-34d3457c1d9a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bb90092-cf5b-4462-9979-34d3457c1d9a">
											<gml:posList>35.66880494918868 139.74904640333185 21.6 35.66880580726333 139.7490489319738 21.6 35.668806409930525 139.74904714188125 21.6 35.66880494918868 139.74904640333185 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3343b686-1d98-4129-bea2-c965b4615681">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3343b686-1d98-4129-bea2-c965b4615681">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3343b686-1d98-4129-bea2-c965b4615681">
											<gml:posList>35.66880363517686 139.7490106265796 25.68 35.66880577065667 139.74900951972953 25.68 35.668815602065585 139.74898010481928 25.68 35.66881470787268 139.7489774878474 25.68 35.66880363517686 139.7490106265796 25.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35db9d80-8a9d-4618-ad6f-897f54dc35d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35db9d80-8a9d-4618-ad6f-897f54dc35d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35db9d80-8a9d-4618-ad6f-897f54dc35d1">
											<gml:posList>35.66880580726333 139.7490489319738 24.142 35.66880804187131 139.74904779188236 24.142 35.6688174055735 139.74901980240756 24.142 35.66881645721401 139.74901706398566 24.142 35.66880580726333 139.7490489319738 24.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-34cc878b-16ac-4f2b-8554-e95fd193e5d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34cc878b-16ac-4f2b-8554-e95fd193e5d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34cc878b-16ac-4f2b-8554-e95fd193e5d4">
											<gml:posList>35.668826852863546 139.74905971288473 24.142 35.668825949565864 139.74905696336862 24.142 35.66880804187131 139.74904779188236 24.142 35.66880580726333 139.7490489319738 24.142 35.668826852863546 139.74905971288473 24.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-96ad49c8-07c6-42c2-b958-37e606344582">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96ad49c8-07c6-42c2-b958-37e606344582">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96ad49c8-07c6-42c2-b958-37e606344582">
											<gml:posList>35.66881805320833 139.74901786866866 24.142 35.66881645721401 139.74901706398566 24.142 35.6688174055735 139.74901980240756 24.142 35.66881805320833 139.74901786866866 24.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-481cf9c2-513c-48c2-a07d-099f46f1fd45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-481cf9c2-513c-48c2-a07d-099f46f1fd45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-481cf9c2-513c-48c2-a07d-099f46f1fd45">
											<gml:posList>35.668838224007985 139.74902797668395 25.68 35.66883735686503 139.7490253707284 25.68 35.66880577065667 139.74900951972953 25.68 35.66880363517686 139.7490106265796 25.68 35.668838224007985 139.74902797668395 25.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98459109-1986-4486-8d90-117635604232">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98459109-1986-4486-8d90-117635604232">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98459109-1986-4486-8d90-117635604232">
											<gml:posList>35.6688174055735 139.74901980240756 24.01 35.66880804187131 139.74904779188236 24.01 35.668825949565864 139.74905696336862 24.01 35.66883594433158 139.74902911682375 24.01 35.66883660096481 139.7490271609829 24.01 35.66881805320833 139.74901786866866 24.01 35.6688174055735 139.74901980240756 24.01</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-913f9586-668f-4725-a564-340312576aaf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-913f9586-668f-4725-a564-340312576aaf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-913f9586-668f-4725-a564-340312576aaf">
											<gml:posList>35.66883735686503 139.7490253707284 25.346 35.668847792406346 139.74899625341638 25.346 35.668815602065585 139.74898010481928 25.346 35.66880577065667 139.74900951972953 25.346 35.66883735686503 139.7490253707284 25.346</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7e8a0ed5-dbfd-40ce-a7fa-775817cba7bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e8a0ed5-dbfd-40ce-a7fa-775817cba7bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e8a0ed5-dbfd-40ce-a7fa-775817cba7bb">
											<gml:posList>35.668838224007985 139.74902797668395 24.142 35.66883594433158 139.74902911682375 24.142 35.668825949565864 139.74905696336862 24.142 35.668826852863546 139.74905971288473 24.142 35.668838224007985 139.74902797668395 24.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c761fc3e-df27-428c-b8f5-c69f011fe5ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c761fc3e-df27-428c-b8f5-c69f011fe5ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c761fc3e-df27-428c-b8f5-c69f011fe5ce">
											<gml:posList>35.66881470787268 139.7489774878474 25.68 35.668815602065585 139.74898010481928 25.68 35.668847792406346 139.74899625341638 25.68 35.66884997297787 139.74899517965602 25.68 35.66881470787268 139.7489774878474 25.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a2b5200-5494-4c81-988e-d8dd058cff16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a2b5200-5494-4c81-988e-d8dd058cff16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a2b5200-5494-4c81-988e-d8dd058cff16">
											<gml:posList>35.66884997297787 139.74899517965602 25.68 35.668847792406346 139.74899625341638 25.68 35.66883735686503 139.7490253707284 25.68 35.668838224007985 139.74902797668395 25.68 35.66884997297787 139.74899517965602 25.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ecee7fa4-cb09-4c47-a14d-17fcdfc5518d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ecee7fa4-cb09-4c47-a14d-17fcdfc5518d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ecee7fa4-cb09-4c47-a14d-17fcdfc5518d">
											<gml:posList>35.66884997297787 139.74899517965602 5.569 35.66877152592584 139.7489558278111 5.569 35.66877152592584 139.7489558278111 21.6 35.66881470787268 139.7489774878474 21.6 35.66881470787268 139.7489774878474 25.68 35.66884997297787 139.74899517965602 25.68 35.66884997297787 139.74899517965602 5.569</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-43ff8fe5-6a13-4142-9d7e-787f1e7011e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-43ff8fe5-6a13-4142-9d7e-787f1e7011e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-43ff8fe5-6a13-4142-9d7e-787f1e7011e9">
											<gml:posList>35.668812662491746 139.74897853937347 21.6 35.668812662491746 139.74897853937347 21.287 35.668814114220254 139.7489792779312 21.287 35.668814114220254 139.7489792779312 21.6 35.668812662491746 139.74897853937347 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dab752b0-1867-4e57-af31-1b49b1582f1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dab752b0-1867-4e57-af31-1b49b1582f1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dab752b0-1867-4e57-af31-1b49b1582f1a">
											<gml:posList>35.6688174055735 139.74901980240756 24.142 35.6688174055735 139.74901980240756 24.01 35.66881805320833 139.74901786866866 24.01 35.66881805320833 139.74901786866866 24.142 35.6688174055735 139.74901980240756 24.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2526e273-0fe1-4490-8916-ee3d8ef584c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2526e273-0fe1-4490-8916-ee3d8ef584c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2526e273-0fe1-4490-8916-ee3d8ef584c8">
											<gml:posList>35.66884997297787 139.74899517965602 5.569 35.66884997297787 139.74899517965602 25.68 35.668838224007985 139.74902797668395 25.68 35.668838224007985 139.74902797668395 24.142 35.668826852863546 139.74905971288473 24.142 35.668826852863546 139.74905971288473 5.569 35.66884997297787 139.74899517965602 5.569</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-305afac1-b6e7-48e2-8eeb-bb5c922efbfe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-305afac1-b6e7-48e2-8eeb-bb5c922efbfe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-305afac1-b6e7-48e2-8eeb-bb5c922efbfe">
											<gml:posList>35.66883660096481 139.7490271609829 24.142 35.66883660096481 139.7490271609829 24.01 35.66883594433158 139.74902911682375 24.01 35.66883594433158 139.74902911682375 24.142 35.66883660096481 139.7490271609829 24.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45924083-abe2-46df-93eb-bf7231936de8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45924083-abe2-46df-93eb-bf7231936de8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45924083-abe2-46df-93eb-bf7231936de8">
											<gml:posList>35.66877152592584 139.7489558278111 5.569 35.668749126621044 139.74901991838857 5.569 35.668749126621044 139.74901991838857 21.6 35.66877152592584 139.7489558278111 21.6 35.66877152592584 139.7489558278111 5.569</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9459fcd6-f9df-4b69-8ae0-8ee207189705">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9459fcd6-f9df-4b69-8ae0-8ee207189705">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9459fcd6-f9df-4b69-8ae0-8ee207189705">
											<gml:posList>35.66875119905902 139.74901888892802 21.6 35.66875119905902 139.74901888892802 21.287 35.66877237496545 139.7489583233224 21.287 35.66877237496545 139.7489583233224 21.6 35.66875119905902 139.74901888892802 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6305e10-0ce0-4076-ae61-160a8df8321b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6305e10-0ce0-4076-ae61-160a8df8321b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6305e10-0ce0-4076-ae61-160a8df8321b">
											<gml:posList>35.66880494918868 139.74904640333185 21.6 35.66880494918868 139.74904640333185 21.287 35.66875119905902 139.74901888892802 21.287 35.66875119905902 139.74901888892802 21.6 35.66880494918868 139.74904640333185 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11e08ac6-7d3f-4465-890d-4104910dd976">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11e08ac6-7d3f-4465-890d-4104910dd976">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11e08ac6-7d3f-4465-890d-4104910dd976">
											<gml:posList>35.668826852863546 139.74905971288473 5.569 35.668826852863546 139.74905971288473 24.142 35.66880580726333 139.7490489319738 24.142 35.66880580726333 139.7490489319738 21.6 35.668749126621044 139.74901991838857 21.6 35.668749126621044 139.74901991838857 5.569 35.668826852863546 139.74905971288473 5.569</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de9aad82-c23d-40e0-a845-7dadfa4d2e65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de9aad82-c23d-40e0-a845-7dadfa4d2e65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de9aad82-c23d-40e0-a845-7dadfa4d2e65">
											<gml:posList>35.66877237496545 139.7489583233224 21.6 35.66877237496545 139.7489583233224 21.287 35.668812662491746 139.74897853937347 21.287 35.668812662491746 139.74897853937347 21.6 35.66877237496545 139.7489583233224 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-841db583-1ce7-46a9-936b-152ffc70bafd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-841db583-1ce7-46a9-936b-152ffc70bafd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-841db583-1ce7-46a9-936b-152ffc70bafd">
											<gml:posList>35.668806409930525 139.74904714188125 21.6 35.668806409930525 139.74904714188125 21.287 35.66880494918868 139.74904640333185 21.287 35.66880494918868 139.74904640333185 21.6 35.668806409930525 139.74904714188125 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a99bf22-712c-4a84-a899-154ca59afd4f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a99bf22-712c-4a84-a899-154ca59afd4f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a99bf22-712c-4a84-a899-154ca59afd4f">
											<gml:posList>35.66880363517686 139.7490106265796 21.287 35.66880363517686 139.7490106265796 25.68 35.66881470787268 139.7489774878474 25.68 35.66881470787268 139.7489774878474 21.6 35.668814114220254 139.7489792779312 21.6 35.668814114220254 139.7489792779312 21.287 35.66880363517686 139.7490106265796 21.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b17cb39-74b9-470a-946f-50a98116ec5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b17cb39-74b9-470a-946f-50a98116ec5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b17cb39-74b9-470a-946f-50a98116ec5d">
											<gml:posList>35.66880577065667 139.74900951972953 25.68 35.66880577065667 139.74900951972953 25.346 35.668815602065585 139.74898010481928 25.346 35.668815602065585 139.74898010481928 25.68 35.66880577065667 139.74900951972953 25.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c5b8a42-dc47-4587-82a9-ef569d3c5861">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c5b8a42-dc47-4587-82a9-ef569d3c5861">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c5b8a42-dc47-4587-82a9-ef569d3c5861">
											<gml:posList>35.668806409930525 139.74904714188125 21.6 35.66880580726333 139.7490489319738 21.6 35.66880580726333 139.7490489319738 24.142 35.66881645721401 139.74901706398566 24.142 35.66881645721401 139.74901706398566 21.287 35.668806409930525 139.74904714188125 21.287 35.668806409930525 139.74904714188125 21.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-13afa9e1-6192-45b9-b156-839ed9da65c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-13afa9e1-6192-45b9-b156-839ed9da65c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-13afa9e1-6192-45b9-b156-839ed9da65c7">
											<gml:posList>35.66880804187131 139.74904779188236 24.142 35.66880804187131 139.74904779188236 24.01 35.6688174055735 139.74901980240756 24.01 35.6688174055735 139.74901980240756 24.142 35.66880804187131 139.74904779188236 24.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b1ed90b7-a17e-4688-b099-99ab0481b809">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1ed90b7-a17e-4688-b099-99ab0481b809">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1ed90b7-a17e-4688-b099-99ab0481b809">
											<gml:posList>35.668825949565864 139.74905696336862 24.142 35.668825949565864 139.74905696336862 24.01 35.66880804187131 139.74904779188236 24.01 35.66880804187131 139.74904779188236 24.142 35.668825949565864 139.74905696336862 24.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5f0deeec-5d7e-4e97-ac26-c74f1fd54f79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f0deeec-5d7e-4e97-ac26-c74f1fd54f79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f0deeec-5d7e-4e97-ac26-c74f1fd54f79">
											<gml:posList>35.66881805320833 139.74901786866866 24.142 35.66881805320833 139.74901786866866 24.01 35.66883660096481 139.7490271609829 24.01 35.66883660096481 139.7490271609829 24.142 35.668838224007985 139.74902797668395 24.142 35.668838224007985 139.74902797668395 25.68 35.66880363517686 139.7490106265796 25.68 35.66880363517686 139.7490106265796 21.287 35.66881645721401 139.74901706398566 21.287 35.66881645721401 139.74901706398566 24.142 35.66881805320833 139.74901786866866 24.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9e220db1-d78c-4756-84f2-aafd09b3f50f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e220db1-d78c-4756-84f2-aafd09b3f50f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e220db1-d78c-4756-84f2-aafd09b3f50f">
											<gml:posList>35.66883735686503 139.7490253707284 25.68 35.66883735686503 139.7490253707284 25.346 35.66880577065667 139.74900951972953 25.346 35.66880577065667 139.74900951972953 25.68 35.66883735686503 139.7490253707284 25.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-646156ae-432c-4f9b-827b-e8e46cc72c12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-646156ae-432c-4f9b-827b-e8e46cc72c12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-646156ae-432c-4f9b-827b-e8e46cc72c12">
											<gml:posList>35.66883594433158 139.74902911682375 24.142 35.66883594433158 139.74902911682375 24.01 35.668825949565864 139.74905696336862 24.01 35.668825949565864 139.74905696336862 24.142 35.66883594433158 139.74902911682375 24.142</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af25c204-7547-453e-9429-955f0a308314">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af25c204-7547-453e-9429-955f0a308314">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af25c204-7547-453e-9429-955f0a308314">
											<gml:posList>35.668815602065585 139.74898010481928 25.68 35.668815602065585 139.74898010481928 25.346 35.668847792406346 139.74899625341638 25.346 35.668847792406346 139.74899625341638 25.68 35.668815602065585 139.74898010481928 25.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dabb7ab9-ca3e-49b4-bb11-13c97ca9f4c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dabb7ab9-ca3e-49b4-bb11-13c97ca9f4c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dabb7ab9-ca3e-49b4-bb11-13c97ca9f4c3">
											<gml:posList>35.668847792406346 139.74899625341638 25.68 35.668847792406346 139.74899625341638 25.346 35.66883735686503 139.7490253707284 25.346 35.66883735686503 139.7490253707284 25.68 35.668847792406346 139.74899625341638 25.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4935</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">59.4839</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1230</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>