<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_50dc7e9f-bb39-4fc4-ba9d-8d98b10b99ab">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">411</bldg:usage>
			<bldg:measuredHeight uom="m">4.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66733939956095 139.73827700084254 0 35.66729303238665 139.73834487722834 0 35.667325598336745 139.73837830754138 0 35.667339103333994 139.73835851949494 0 35.66737043196705 139.73830887550048 0 35.66733939956095 139.73827700084254 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66733939956095 139.73827700084254 14.074 35.66737043196705 139.73830887550048 14.074 35.667339103333994 139.73835851949494 14.074 35.667325598336745 139.73837830754138 14.074 35.66729303238665 139.73834487722834 14.074 35.66733939956095 139.73827700084254 14.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66733939956095 139.73827700084254 14.074 35.66729303238665 139.73834487722834 14.074 35.66729303238665 139.73834487722834 18.98 35.66733939956095 139.73827700084254 18.98 35.66733939956095 139.73827700084254 14.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66729303238665 139.73834487722834 14.074 35.667325598336745 139.73837830754138 14.074 35.667325598336745 139.73837830754138 18.98 35.66729303238665 139.73834487722834 18.98 35.66729303238665 139.73834487722834 14.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667325598336745 139.73837830754138 14.074 35.667339103333994 139.73835851949494 14.074 35.667339103333994 139.73835851949494 18.98 35.667325598336745 139.73837830754138 18.98 35.667325598336745 139.73837830754138 14.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667339103333994 139.73835851949494 14.074 35.66737043196705 139.73830887550048 14.074 35.66737043196705 139.73830887550048 18.98 35.667339103333994 139.73835851949494 18.98 35.667339103333994 139.73835851949494 14.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66737043196705 139.73830887550048 14.074 35.66733939956095 139.73827700084254 14.074 35.66733939956095 139.73827700084254 18.98 35.66737043196705 139.73830887550048 18.98 35.66737043196705 139.73830887550048 14.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66733939956095 139.73827700084254 18.98 35.66729303238665 139.73834487722834 18.98 35.667325598336745 139.73837830754138 18.98 35.667339103333994 139.73835851949494 18.98 35.66737043196705 139.73830887550048 18.98 35.66733939956095 139.73827700084254 18.98</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-952cc1cb-2b45-41e7-adf3-f3278357ec5a"/>
							<gml:surfaceMember xlink:href="#poly-4312fa4d-2051-49a4-9839-8f1c55676d0a"/>
							<gml:surfaceMember xlink:href="#poly-268479a7-27f6-45f8-9021-e8fd65a53ba7"/>
							<gml:surfaceMember xlink:href="#poly-de808b65-a01a-4515-b85a-2af3afa17aec"/>
							<gml:surfaceMember xlink:href="#poly-c1bd6697-4524-46bf-a6f4-fbbfc4655198"/>
							<gml:surfaceMember xlink:href="#poly-0e42c963-2c10-4ef2-a82d-ca9c22d6aed0"/>
							<gml:surfaceMember xlink:href="#poly-320a8f35-d8e6-40cf-b73a-0109eb002a8c"/>
							<gml:surfaceMember xlink:href="#poly-96447b35-23bb-4c7a-93bb-845561709fe4"/>
							<gml:surfaceMember xlink:href="#poly-be499786-b66f-4db9-889a-aea7dd1817df"/>
							<gml:surfaceMember xlink:href="#poly-af6d48f8-ba97-4770-93ae-d82147d4dc3a"/>
							<gml:surfaceMember xlink:href="#poly-5af60aeb-20a1-4508-bea5-068c04730e6a"/>
							<gml:surfaceMember xlink:href="#poly-c0e2e281-ea42-4375-8a54-74483aa46d89"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-952cc1cb-2b45-41e7-adf3-f3278357ec5a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-952cc1cb-2b45-41e7-adf3-f3278357ec5a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-952cc1cb-2b45-41e7-adf3-f3278357ec5a">
											<gml:posList>35.66733939956095 139.73827700084254 14.074 35.667370431967036 139.73830887550048 14.074 35.66733910333398 139.73835851949497 14.074 35.667325598336724 139.73837830754135 14.074 35.66729303238666 139.73834487722834 14.074 35.66733939956095 139.73827700084254 14.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4312fa4d-2051-49a4-9839-8f1c55676d0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4312fa4d-2051-49a4-9839-8f1c55676d0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4312fa4d-2051-49a4-9839-8f1c55676d0a">
											<gml:posList>35.667361609540535 139.7383228589473 16.767 35.667370431967036 139.73830887550048 16.767 35.66733939956095 139.73827700084254 16.767 35.667328586560416 139.73829283130192 16.767 35.667361609540535 139.7383228589473 16.767</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-268479a7-27f6-45f8-9021-e8fd65a53ba7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-268479a7-27f6-45f8-9021-e8fd65a53ba7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-268479a7-27f6-45f8-9021-e8fd65a53ba7">
											<gml:posList>35.667328586560416 139.73829283130192 20.231 35.66729303238666 139.73834487722834 20.231 35.667309315362864 139.73836159238147 21.799 35.66734510255829 139.7383078451162 21.799 35.667328586560416 139.73829283130192 20.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-de808b65-a01a-4515-b85a-2af3afa17aec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de808b65-a01a-4515-b85a-2af3afa17aec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de808b65-a01a-4515-b85a-2af3afa17aec">
											<gml:posList>35.66733910333398 139.73835851949497 20.231 35.667361609540535 139.7383228589473 20.231 35.66734510255829 139.7383078451162 21.799 35.66733910333398 139.73835851949497 20.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c1bd6697-4524-46bf-a6f4-fbbfc4655198">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1bd6697-4524-46bf-a6f4-fbbfc4655198">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1bd6697-4524-46bf-a6f4-fbbfc4655198">
											<gml:posList>35.66733910333398 139.73835851949497 20.231 35.66734510255829 139.7383078451162 21.799 35.667325598336724 139.73837830754135 20.231 35.66733910333398 139.73835851949497 20.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e42c963-2c10-4ef2-a82d-ca9c22d6aed0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e42c963-2c10-4ef2-a82d-ca9c22d6aed0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e42c963-2c10-4ef2-a82d-ca9c22d6aed0">
											<gml:posList>35.66734510255829 139.7383078451162 21.799 35.667309315362864 139.73836159238147 21.799 35.667325598336724 139.73837830754135 20.231 35.66734510255829 139.7383078451162 21.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-320a8f35-d8e6-40cf-b73a-0109eb002a8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-320a8f35-d8e6-40cf-b73a-0109eb002a8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-320a8f35-d8e6-40cf-b73a-0109eb002a8c">
											<gml:posList>35.667370431967036 139.73830887550048 14.074 35.66733939956095 139.73827700084254 14.074 35.66733939956095 139.73827700084254 16.767 35.667370431967036 139.73830887550048 16.767 35.667370431967036 139.73830887550048 14.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-96447b35-23bb-4c7a-93bb-845561709fe4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-96447b35-23bb-4c7a-93bb-845561709fe4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-96447b35-23bb-4c7a-93bb-845561709fe4">
											<gml:posList>35.667361609540535 139.7383228589473 20.231 35.667361609540535 139.7383228589473 16.767 35.667328586560416 139.73829283130192 16.767 35.667328586560416 139.73829283130192 20.231 35.66734510255829 139.7383078451162 21.799 35.667361609540535 139.7383228589473 20.231</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be499786-b66f-4db9-889a-aea7dd1817df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be499786-b66f-4db9-889a-aea7dd1817df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be499786-b66f-4db9-889a-aea7dd1817df">
											<gml:posList>35.66729303238666 139.73834487722834 14.074 35.66729303238666 139.73834487722834 20.231 35.667328586560416 139.73829283130192 20.231 35.667328586560416 139.73829283130192 16.767 35.66733939956095 139.73827700084254 16.767 35.66733939956095 139.73827700084254 14.074 35.66729303238666 139.73834487722834 14.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af6d48f8-ba97-4770-93ae-d82147d4dc3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af6d48f8-ba97-4770-93ae-d82147d4dc3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af6d48f8-ba97-4770-93ae-d82147d4dc3a">
											<gml:posList>35.667370431967036 139.73830887550048 14.074 35.667370431967036 139.73830887550048 16.767 35.667361609540535 139.7383228589473 16.767 35.667361609540535 139.7383228589473 20.231 35.66733910333398 139.73835851949497 20.231 35.66733910333398 139.73835851949497 14.074 35.667370431967036 139.73830887550048 14.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5af60aeb-20a1-4508-bea5-068c04730e6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5af60aeb-20a1-4508-bea5-068c04730e6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5af60aeb-20a1-4508-bea5-068c04730e6a">
											<gml:posList>35.66729303238666 139.73834487722834 14.074 35.667325598336724 139.73837830754135 14.074 35.667325598336724 139.73837830754135 20.231 35.667309315362864 139.73836159238147 21.799 35.66729303238666 139.73834487722834 20.231 35.66729303238666 139.73834487722834 14.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0e2e281-ea42-4375-8a54-74483aa46d89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0e2e281-ea42-4375-8a54-74483aa46d89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0e2e281-ea42-4375-8a54-74483aa46d89">
											<gml:posList>35.667325598336724 139.73837830754135 14.074 35.66733910333398 139.73835851949497 14.074 35.66733910333398 139.73835851949497 20.231 35.667325598336724 139.73837830754135 20.231 35.667325598336724 139.73837830754135 14.074</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7796</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">36.98591</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1310</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">21</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>