<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_560509e3-3cff-4223-9824-94df09e297cd">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3003</bldg:class>
			<bldg:measuredHeight uom="m">3.3</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672265838249 139.7390704310207 0 35.67229322430217 139.73905040461483 0 35.6722601155466 139.73900266735936 0 35.67223606838425 139.73902755031207 0 35.672265838249 139.7390704310207 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672265838249 139.7390704310207 9.619 35.67223606838425 139.73902755031207 9.619 35.6722601155466 139.73900266735936 9.619 35.67229322430217 139.73905040461483 9.619 35.672265838249 139.7390704310207 9.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672265838249 139.7390704310207 9.619 35.67229322430217 139.73905040461483 9.619 35.67229322430217 139.73905040461483 12.88 35.672265838249 139.7390704310207 12.88 35.672265838249 139.7390704310207 9.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67229322430217 139.73905040461483 9.619 35.6722601155466 139.73900266735936 9.619 35.6722601155466 139.73900266735936 12.88 35.67229322430217 139.73905040461483 12.88 35.67229322430217 139.73905040461483 9.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6722601155466 139.73900266735936 9.619 35.67223606838425 139.73902755031207 9.619 35.67223606838425 139.73902755031207 12.88 35.6722601155466 139.73900266735936 12.88 35.6722601155466 139.73900266735936 9.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67223606838425 139.73902755031207 9.619 35.672265838249 139.7390704310207 9.619 35.672265838249 139.7390704310207 12.88 35.67223606838425 139.73902755031207 12.88 35.67223606838425 139.73902755031207 9.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672265838249 139.7390704310207 12.88 35.67229322430217 139.73905040461483 12.88 35.6722601155466 139.73900266735936 12.88 35.67223606838425 139.73902755031207 12.88 35.672265838249 139.7390704310207 12.88</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-b3615b4e-0d33-4501-a682-db3dd81fe65c"/>
							<gml:surfaceMember xlink:href="#poly-f792e391-dc7e-41eb-9376-5fb54e7364d3"/>
							<gml:surfaceMember xlink:href="#poly-4b5177d6-ef14-49e6-8e2d-f8f63de69359"/>
							<gml:surfaceMember xlink:href="#poly-8cd20de1-4d81-4992-b633-256ce4a28389"/>
							<gml:surfaceMember xlink:href="#poly-ff97a81b-90d1-4eab-82c0-e473b5c0ab91"/>
							<gml:surfaceMember xlink:href="#poly-ceaa0da2-19d5-4496-a038-b8ad61de7517"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-b3615b4e-0d33-4501-a682-db3dd81fe65c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3615b4e-0d33-4501-a682-db3dd81fe65c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3615b4e-0d33-4501-a682-db3dd81fe65c">
											<gml:posList>35.67226583824897 139.73907043102068 9.619 35.672236068384244 139.73902755031207 9.619 35.672260115546585 139.73900266735933 9.619 35.672293224302166 139.73905040461483 9.619 35.67226583824897 139.73907043102068 9.619</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f792e391-dc7e-41eb-9376-5fb54e7364d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f792e391-dc7e-41eb-9376-5fb54e7364d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f792e391-dc7e-41eb-9376-5fb54e7364d3">
											<gml:posList>35.672260115546585 139.73900266735933 13.633 35.672236068384244 139.73902755031207 13.633 35.67226583824897 139.73907043102068 13.633 35.672293224302166 139.73905040461483 13.633 35.672260115546585 139.73900266735933 13.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b5177d6-ef14-49e6-8e2d-f8f63de69359">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b5177d6-ef14-49e6-8e2d-f8f63de69359">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b5177d6-ef14-49e6-8e2d-f8f63de69359">
											<gml:posList>35.67226583824897 139.73907043102068 13.633 35.67226583824897 139.73907043102068 9.619 35.672293224302166 139.73905040461483 9.619 35.672293224302166 139.73905040461483 13.633 35.67226583824897 139.73907043102068 13.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8cd20de1-4d81-4992-b633-256ce4a28389">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8cd20de1-4d81-4992-b633-256ce4a28389">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8cd20de1-4d81-4992-b633-256ce4a28389">
											<gml:posList>35.672260115546585 139.73900266735933 13.633 35.672260115546585 139.73900266735933 9.619 35.672236068384244 139.73902755031207 9.619 35.672236068384244 139.73902755031207 13.633 35.672260115546585 139.73900266735933 13.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff97a81b-90d1-4eab-82c0-e473b5c0ab91">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff97a81b-90d1-4eab-82c0-e473b5c0ab91">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff97a81b-90d1-4eab-82c0-e473b5c0ab91">
											<gml:posList>35.672293224302166 139.73905040461483 13.633 35.672293224302166 139.73905040461483 9.619 35.672260115546585 139.73900266735933 9.619 35.672260115546585 139.73900266735933 13.633 35.672293224302166 139.73905040461483 13.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ceaa0da2-19d5-4496-a038-b8ad61de7517">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ceaa0da2-19d5-4496-a038-b8ad61de7517">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ceaa0da2-19d5-4496-a038-b8ad61de7517">
											<gml:posList>35.672236068384244 139.73902755031207 13.633 35.672236068384244 139.73902755031207 9.619 35.67226583824897 139.73907043102068 9.619 35.67226583824897 139.73907043102068 13.633 35.672236068384244 139.73902755031207 13.633</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5773</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>