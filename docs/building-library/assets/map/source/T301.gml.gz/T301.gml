<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_565ebfe7-26e5-44af-9382-6f36e9c3872e">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">11.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.668556238833006 139.73975406648225 0 35.66858657747835 139.73970564954112 0 35.66857909058945 139.73969858883618 0 35.66858422197056 139.73969029833498 0 35.66853163191173 139.7396388853713 0 35.668494990986645 139.73969669876462 0 35.66842409137829 139.7396302847009 0 35.66837277689419 139.73971230585988 0 35.668470196460724 139.73980398434276 0 35.6685216911091 139.73972174201216 0 35.668556238833006 139.73975406648225 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668556238833006 139.73975406648225 11.182 35.6685216911091 139.73972174201216 11.182 35.668470196460724 139.73980398434276 11.182 35.66837277689419 139.73971230585988 11.182 35.66842409137829 139.7396302847009 11.182 35.668494990986645 139.73969669876462 11.182 35.66853163191173 139.7396388853713 11.182 35.66858422197056 139.73969029833498 11.182 35.66857909058945 139.73969858883618 11.182 35.66858657747835 139.73970564954112 11.182 35.668556238833006 139.73975406648225 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668556238833006 139.73975406648225 11.182 35.66858657747835 139.73970564954112 11.182 35.66858657747835 139.73970564954112 23.11 35.668556238833006 139.73975406648225 23.11 35.668556238833006 139.73975406648225 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858657747835 139.73970564954112 11.182 35.66857909058945 139.73969858883618 11.182 35.66857909058945 139.73969858883618 23.11 35.66858657747835 139.73970564954112 23.11 35.66858657747835 139.73970564954112 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66857909058945 139.73969858883618 11.182 35.66858422197056 139.73969029833498 11.182 35.66858422197056 139.73969029833498 23.11 35.66857909058945 139.73969858883618 23.11 35.66857909058945 139.73969858883618 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66858422197056 139.73969029833498 11.182 35.66853163191173 139.7396388853713 11.182 35.66853163191173 139.7396388853713 23.11 35.66858422197056 139.73969029833498 23.11 35.66858422197056 139.73969029833498 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66853163191173 139.7396388853713 11.182 35.668494990986645 139.73969669876462 11.182 35.668494990986645 139.73969669876462 23.11 35.66853163191173 139.7396388853713 23.11 35.66853163191173 139.7396388853713 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668494990986645 139.73969669876462 11.182 35.66842409137829 139.7396302847009 11.182 35.66842409137829 139.7396302847009 23.11 35.668494990986645 139.73969669876462 23.11 35.668494990986645 139.73969669876462 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66842409137829 139.7396302847009 11.182 35.66837277689419 139.73971230585988 11.182 35.66837277689419 139.73971230585988 23.11 35.66842409137829 139.7396302847009 23.11 35.66842409137829 139.7396302847009 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66837277689419 139.73971230585988 11.182 35.668470196460724 139.73980398434276 11.182 35.668470196460724 139.73980398434276 23.11 35.66837277689419 139.73971230585988 23.11 35.66837277689419 139.73971230585988 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668470196460724 139.73980398434276 11.182 35.6685216911091 139.73972174201216 11.182 35.6685216911091 139.73972174201216 23.11 35.668470196460724 139.73980398434276 23.11 35.668470196460724 139.73980398434276 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6685216911091 139.73972174201216 11.182 35.668556238833006 139.73975406648225 11.182 35.668556238833006 139.73975406648225 23.11 35.6685216911091 139.73972174201216 23.11 35.6685216911091 139.73972174201216 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668556238833006 139.73975406648225 23.11 35.66858657747835 139.73970564954112 23.11 35.66857909058945 139.73969858883618 23.11 35.66858422197056 139.73969029833498 23.11 35.66853163191173 139.7396388853713 23.11 35.668494990986645 139.73969669876462 23.11 35.66842409137829 139.7396302847009 23.11 35.66837277689419 139.73971230585988 23.11 35.668470196460724 139.73980398434276 23.11 35.6685216911091 139.73972174201216 23.11 35.668556238833006 139.73975406648225 23.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-137535d5-96db-459b-8e07-3a8c2df30359"/>
							<gml:surfaceMember xlink:href="#poly-3bc3b5d7-7a0b-4eec-a7db-39b1d69a735c"/>
							<gml:surfaceMember xlink:href="#poly-9521b8b5-b28b-4380-b3ca-ecfa3f95b7c9"/>
							<gml:surfaceMember xlink:href="#poly-978cdecc-475e-464a-8386-913b6e04bb3e"/>
							<gml:surfaceMember xlink:href="#poly-6d0e391b-ae02-41de-8a06-1a984dc46ef3"/>
							<gml:surfaceMember xlink:href="#poly-6375ba33-64b5-4121-8cd9-e589ef0400e4"/>
							<gml:surfaceMember xlink:href="#poly-fa227f8d-eb70-4674-b2c6-124f779aff06"/>
							<gml:surfaceMember xlink:href="#poly-35e9732a-c4d6-4313-b38b-1bed1f59dd6a"/>
							<gml:surfaceMember xlink:href="#poly-bb1407f1-7d52-430c-b760-15de176b8240"/>
							<gml:surfaceMember xlink:href="#poly-35e3036a-cc36-447c-91a9-91aab2c0965d"/>
							<gml:surfaceMember xlink:href="#poly-d0c1e8fd-3e07-4ffe-a9d0-acb8312db932"/>
							<gml:surfaceMember xlink:href="#poly-733e1c0a-3aea-4955-a4df-ea5d1cac80e5"/>
							<gml:surfaceMember xlink:href="#poly-38add7e1-9695-44a1-85b5-ee0573678afa"/>
							<gml:surfaceMember xlink:href="#poly-26f6722f-b098-45b8-91a8-6f5a6d9327b9"/>
							<gml:surfaceMember xlink:href="#poly-eb856e07-e1b1-4946-95d8-d34f4ed79ca2"/>
							<gml:surfaceMember xlink:href="#poly-6f34e2db-bfb9-4276-a97b-c2fea2cc3b24"/>
							<gml:surfaceMember xlink:href="#poly-d01cc743-3f00-487c-bed7-259d61d522cc"/>
							<gml:surfaceMember xlink:href="#poly-d59c5f64-16a4-46dc-af0a-db8547d0e79b"/>
							<gml:surfaceMember xlink:href="#poly-15c06c72-305a-4667-8609-86109e827965"/>
							<gml:surfaceMember xlink:href="#poly-2d8ca7cd-f52a-4538-877d-c9f12942d3b7"/>
							<gml:surfaceMember xlink:href="#poly-36cbfcf2-a2f8-4b6f-a346-9ddd6b381bf7"/>
							<gml:surfaceMember xlink:href="#poly-1cf3bf0e-b43d-4a15-b5f1-afc23331571d"/>
							<gml:surfaceMember xlink:href="#poly-d3e42b0b-5b7a-4b6d-aff9-f5f62b62109c"/>
							<gml:surfaceMember xlink:href="#poly-9bba33cc-6cde-43ad-b47d-80e8ee7710c2"/>
							<gml:surfaceMember xlink:href="#poly-adcc1f76-fa3b-4b5d-a143-bb9394e3837a"/>
							<gml:surfaceMember xlink:href="#poly-6240beb5-6494-4694-a1bd-f2c803e3116b"/>
							<gml:surfaceMember xlink:href="#poly-a5791f58-6e8d-4802-afdf-318791e5efc4"/>
							<gml:surfaceMember xlink:href="#poly-699d4687-1a18-4a9e-82e4-ba2bfb79d0fd"/>
							<gml:surfaceMember xlink:href="#poly-3bfc36b6-9550-464a-81c2-b25a140a7665"/>
							<gml:surfaceMember xlink:href="#poly-560d216c-7015-49bf-8eff-30d6193d9d59"/>
							<gml:surfaceMember xlink:href="#poly-0277af88-9033-4b11-982b-86cbff5a9d2f"/>
							<gml:surfaceMember xlink:href="#poly-fe9ae0f9-9691-409b-b8f6-48836f62c41a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_565ebfe7-26e5-44af-9382-6f36e9c3872e_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13c5c959-d310-4798-bc8f-4f9967e299d8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668516930553764 139.73966211020152 18.988 35.668523988635286 139.73965094549249 18.988 35.668575260013924 139.7396989246897 18.988 35.668547397269705 139.73974363832448 18.988 35.66852168943456 139.73971958804347 18.988 35.66850908805406 139.73970776144185 18.988 35.66852990171625 139.7396742125153 18.988 35.668516930553764 139.73966211020152 18.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a4ad566-15da-49bd-a21d-25f23a443f97">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852168943456 139.73971958804347 23.747 35.66852084319204 139.73972093664383 23.747 35.668508241820255 139.73970912108814 23.747 35.668509079048924 139.73970777249838 23.747 35.66852168943456 139.73971958804347 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5772d540-68d9-4bbb-8343-7ad0b2a0ab2b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845591744001 139.73972115604138 23.385 35.66844552848061 139.73973773715954 23.385 35.668430419431296 139.7397235275598 23.385 35.66844080838878 139.73970694644294 23.385 35.66845591744001 139.73972115604138 23.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84d9af11-654a-4b5e-9945-fcad5659888e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66852168943456 139.73971958804347 18.988 35.668547397269705 139.73974363832448 18.988 35.66854655103551 139.73974499797106 18.988 35.66852084319204 139.73972093664383 18.988 35.66852168943456 139.73971958804347 18.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29f34f94-27fc-4265-a226-2b4f99415cfb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66845928850822 139.7397558586212 23.385 35.668472611531435 139.73976839132473 23.385 35.668461538371965 139.73978606679196 23.385 35.66844820632825 139.73977352305175 23.385 35.66845928850822 139.7397558586212 23.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12c77c0f-ddea-46f0-a007-d18ec06ddfe0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12c77c0f-ddea-46f0-a007-d18ec06ddfe0_0">
											<gml:posList>35.668516930553764 139.73966211020152 18.988 35.668516930553764 139.73966211020152 21.597 35.668523988635286 139.73965094549249 18.988 35.668516930553764 139.73966211020152 18.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64855b51-7b60-4fca-bd30-f871eecca24d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-64855b51-7b60-4fca-bd30-f871eecca24d_0">
											<gml:posList>35.668516930553764 139.73966211020152 21.597 35.668516930553764 139.73966211020152 18.988 35.66852990171625 139.7396742125153 18.988 35.66852990171625 139.7396742125153 21.597 35.668516930553764 139.73966211020152 21.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09f4cab5-6572-454a-916a-e0ae49559a68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09f4cab5-6572-454a-916a-e0ae49559a68_0">
											<gml:posList>35.66852990171625 139.7396742125153 21.597 35.66856145469737 139.7397037126868 21.594 35.668575260013924 139.7396989246897 18.988 35.668523988635286 139.73965094549249 18.988 35.668516930553764 139.73966211020152 21.597 35.66852990171625 139.7396742125153 21.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-caa5a530-283f-4d6e-b7b4-fc38eef44d66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-caa5a530-283f-4d6e-b7b4-fc38eef44d66_0">
											<gml:posList>35.66856145469737 139.7397037126868 24.306 35.66856145469737 139.7397037126868 21.594 35.66852990171625 139.7396742125153 21.597 35.66852990171625 139.7396742125153 24.306 35.66856145469737 139.7397037126868 24.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-faed62c3-7657-4c57-8716-ccd7f8e7b2df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-faed62c3-7657-4c57-8716-ccd7f8e7b2df_0">
											<gml:posList>35.66852990171625 139.7396742125153 24.306 35.66852990171625 139.7396742125153 21.597 35.66852990171625 139.7396742125153 18.988 35.66850908805406 139.73970776144185 18.988 35.668509079048924 139.73970777249838 23.747 35.668508241820255 139.73970912108814 23.747 35.668508241820255 139.73970912108814 24.306 35.66852990171625 139.7396742125153 24.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8ac923c-7818-4f71-86d5-2319aca81780">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8ac923c-7818-4f71-86d5-2319aca81780_0">
											<gml:posList>35.668508241820255 139.73970912108814 24.306 35.66853971366083 139.73973861031416 24.306 35.66856145469737 139.7397037126868 24.306 35.66852990171625 139.7396742125153 24.306 35.668508241820255 139.73970912108814 24.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af1fc42c-5760-4c41-a7fc-85e422cdb8d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af1fc42c-5760-4c41-a7fc-85e422cdb8d7_0">
											<gml:posList>35.668509079048924 139.73970777249838 23.747 35.66850908805406 139.73970776144185 18.988 35.66852168943456 139.73971958804347 18.988 35.66852168943456 139.73971958804347 23.747 35.668509079048924 139.73970777249838 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6fd2dc71-5491-468d-9152-98a0e0b0d63c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6fd2dc71-5491-468d-9152-98a0e0b0d63c_0">
											<gml:posList>35.66845591744001 139.73972115604138 23.385 35.66844080838878 139.73970694644294 23.385 35.66844080838878 139.73970694644294 25.554 35.66845591744001 139.73972115604138 25.554 35.66845591744001 139.73972115604138 23.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-316b8a9a-3bfb-4444-a627-f7b3b74a83e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-316b8a9a-3bfb-4444-a627-f7b3b74a83e0_0">
											<gml:posList>35.668430419431296 139.7397235275598 23.385 35.668430419431296 139.7397235275598 25.554 35.66844080838878 139.73970694644294 25.554 35.66844080838878 139.73970694644294 23.385 35.668430419431296 139.7397235275598 23.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1279ca9-4127-41e5-ad32-4575ee74aebd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1279ca9-4127-41e5-ad32-4575ee74aebd_0">
											<gml:posList>35.66852084319204 139.73972093664383 18.988 35.66852084319204 139.73972093664383 23.747 35.66852168943456 139.73971958804347 23.747 35.66852168943456 139.73971958804347 18.988 35.66852084319204 139.73972093664383 18.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19b7f7cc-99c6-43de-9282-d759b3a35002">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19b7f7cc-99c6-43de-9282-d759b3a35002_0">
											<gml:posList>35.66853971366083 139.73973861031416 24.306 35.66853971366083 139.73973861031416 21.594 35.66856145469737 139.7397037126868 21.594 35.66856145469737 139.7397037126868 24.306 35.66853971366083 139.73973861031416 24.306</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc6184ed-003f-409d-b638-da0d4dfd2a81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc6184ed-003f-409d-b638-da0d4dfd2a81_0">
											<gml:posList>35.66853971366083 139.73973861031416 21.594 35.66854655103551 139.73974499797106 18.988 35.668547397269705 139.73974363832448 18.988 35.668575260013924 139.7396989246897 18.988 35.66856145469737 139.7397037126868 21.594 35.66853971366083 139.73973861031416 21.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fb9e97d-2a37-4c75-9b9b-afc17a52b7e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fb9e97d-2a37-4c75-9b9b-afc17a52b7e9_0">
											<gml:posList>35.66845591744001 139.73972115604138 25.554 35.66844080838878 139.73970694644294 25.554 35.668430419431296 139.7397235275598 25.554 35.66844552848061 139.73973773715954 25.554 35.66845591744001 139.73972115604138 25.554</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b881a63-2b41-4c06-bf8f-460091efeb6a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b881a63-2b41-4c06-bf8f-460091efeb6a_0">
											<gml:posList>35.66852084319204 139.73972093664383 23.747 35.66852084319204 139.73972093664383 18.988 35.66854655103551 139.73974499797106 18.988 35.66853971366083 139.73973861031416 21.594 35.66853971366083 139.73973861031416 24.306 35.668508241820255 139.73970912108814 24.306 35.668508241820255 139.73970912108814 23.747 35.66852084319204 139.73972093664383 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-162d3fce-bd45-4ec0-ba27-1fa02c7d3270">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-162d3fce-bd45-4ec0-ba27-1fa02c7d3270_0">
											<gml:posList>35.66844552848061 139.73973773715954 23.385 35.66845591744001 139.73972115604138 23.385 35.66845591744001 139.73972115604138 25.554 35.66844552848061 139.73973773715954 25.554 35.66844552848061 139.73973773715954 23.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05e650aa-fec4-4bdc-8794-1ce41c5f73d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05e650aa-fec4-4bdc-8794-1ce41c5f73d6_0">
											<gml:posList>35.66844552848061 139.73973773715954 23.385 35.66844552848061 139.73973773715954 25.554 35.668430419431296 139.7397235275598 25.554 35.668430419431296 139.7397235275598 23.385 35.66844552848061 139.73973773715954 23.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2852602b-be82-4a3a-9399-eae7202c0eff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2852602b-be82-4a3a-9399-eae7202c0eff_0">
											<gml:posList>35.668472611531435 139.73976839132473 23.385 35.66845928850822 139.7397558586212 23.385 35.66845928850822 139.7397558586212 25.332 35.668472611531435 139.73976839132473 25.332 35.668472611531435 139.73976839132473 23.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec68971e-2d0d-4d4c-a7d3-38ec244444cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec68971e-2d0d-4d4c-a7d3-38ec244444cf_0">
											<gml:posList>35.66844820632825 139.73977352305175 23.385 35.66844820632825 139.73977352305175 25.332 35.66845928850822 139.7397558586212 25.332 35.66845928850822 139.7397558586212 23.385 35.66844820632825 139.73977352305175 23.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d896791-d30d-432a-b42f-066e1377d75c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d896791-d30d-432a-b42f-066e1377d75c_0">
											<gml:posList>35.66845928850822 139.7397558586212 25.332 35.66844820632825 139.73977352305175 25.332 35.668461538371965 139.73978606679196 25.332 35.668472611531435 139.73976839132473 25.332 35.66845928850822 139.7397558586212 25.332</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-239fd00a-1e77-4cbd-986c-129d6743f874">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-239fd00a-1e77-4cbd-986c-129d6743f874_0">
											<gml:posList>35.668461538371965 139.73978606679196 23.385 35.668472611531435 139.73976839132473 23.385 35.668472611531435 139.73976839132473 25.332 35.668461538371965 139.73978606679196 25.332 35.668461538371965 139.73978606679196 23.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55802eca-4c96-47f2-b4af-ed06729f12c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55802eca-4c96-47f2-b4af-ed06729f12c9_0">
											<gml:posList>35.66844820632825 139.73977352305175 23.385 35.668461538371965 139.73978606679196 23.385 35.668461538371965 139.73978606679196 25.332 35.66844820632825 139.73977352305175 25.332 35.66844820632825 139.73977352305175 23.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_565ebfe7-26e5-44af-9382-6f36e9c3872e_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a11d47e7-581f-40dd-b966-a414405cdb65">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66843808377937 139.73975016154432 26.521 35.66843845430359 139.73975139826297 26.521 35.668438608541294 139.739752690464 26.521 35.66843853744442 139.73975399397403 26.521 35.66843824097008 139.7397552535631 26.521 35.6684377461165 139.73975641396976 26.521 35.66843706185452 139.73975741995355 26.521 35.66843622420467 139.7397582272885 26.521 35.668435260182406 139.73975880280508 26.521 35.668434223861496 139.7397591353942 26.521 35.66843316027623 139.7397591808194 26.521 35.66843210549868 139.7397589611305 26.521 35.668431113602615 139.73975846521844 26.521 35.668430229699574 139.73975774826056 26.521 35.66842948082214 139.73975679917933 26.521 35.66842891209903 139.73975569524399 26.521 35.66842854158347 139.73975446957147 26.521 35.66842838733719 139.73975316632462 26.521 35.66842846744776 139.7397518628042 26.521 35.66842875490835 139.73975060322581 26.521 35.668429249761864 139.73974944281926 26.521 35.6684299340238 139.73974843683547 26.521 35.6684307806873 139.73974762948998 26.521 35.66843173569578 139.73974705398382 26.521 35.66843277202525 139.73974673244052 26.521 35.66843383560192 139.7397466759692 26.521 35.668434890388085 139.7397469067039 26.521 35.66843588227561 139.73974739156986 26.521 35.66843677520102 139.73974811956313 26.521 35.66843751505621 139.73974905760892 26.521 35.66843808377937 139.73975016154432 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f18ac68c-a047-4ff8-93b9-f24b0d41badb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f18ac68c-a047-4ff8-93b9-f24b0d41badb_0">
											<gml:posList>35.66842838733719 139.73975316632462 26.521 35.66842838733719 139.73975316632462 28.978 35.66842846744776 139.7397518628042 28.978 35.66842846744776 139.7397518628042 26.521 35.66842838733719 139.73975316632462 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfba4723-e012-44e8-be02-4f73344d08d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cfba4723-e012-44e8-be02-4f73344d08d8_0">
											<gml:posList>35.66842854158347 139.73975446957147 28.978 35.66842838733719 139.73975316632462 28.978 35.66842838733719 139.73975316632462 26.521 35.66842854158347 139.73975446957147 26.521 35.66842854158347 139.73975446957147 28.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21b42b97-7577-4007-81f3-6b554f361220">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21b42b97-7577-4007-81f3-6b554f361220_0">
											<gml:posList>35.66842846744776 139.7397518628042 26.521 35.66842846744776 139.7397518628042 28.978 35.66842875490835 139.73975060322581 28.978 35.66842875490835 139.73975060322581 26.521 35.66842846744776 139.7397518628042 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72b8713c-1110-4349-865b-2671025bb18d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72b8713c-1110-4349-865b-2671025bb18d_0">
											<gml:posList>35.66842891209903 139.73975569524399 26.521 35.66842891209903 139.73975569524399 28.978 35.66842854158347 139.73975446957147 28.978 35.66842854158347 139.73975446957147 26.521 35.66842891209903 139.73975569524399 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50293035-758f-43f3-95a3-0857d882caaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50293035-758f-43f3-95a3-0857d882caaf_0">
											<gml:posList>35.66842875490835 139.73975060322581 28.978 35.668429249761864 139.73974944281926 28.978 35.668429249761864 139.73974944281926 26.521 35.66842875490835 139.73975060322581 26.521 35.66842875490835 139.73975060322581 28.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35760aac-786c-4b17-a588-d2b72129452d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35760aac-786c-4b17-a588-d2b72129452d_0">
											<gml:posList>35.66842948082214 139.73975679917933 26.521 35.66842948082214 139.73975679917933 28.978 35.66842891209903 139.73975569524399 28.978 35.66842891209903 139.73975569524399 26.521 35.66842948082214 139.73975679917933 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7583b255-67bd-4f7c-86ce-a2f19fcd6764">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7583b255-67bd-4f7c-86ce-a2f19fcd6764_0">
											<gml:posList>35.668429249761864 139.73974944281926 26.521 35.668429249761864 139.73974944281926 28.978 35.6684299340238 139.73974843683547 28.978 35.6684299340238 139.73974843683547 26.521 35.668429249761864 139.73974944281926 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f5f8d0e-814a-49d4-acb7-41db05114ca8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f5f8d0e-814a-49d4-acb7-41db05114ca8_0">
											<gml:posList>35.668430229699574 139.73975774826056 26.521 35.668430229699574 139.73975774826056 28.978 35.66842948082214 139.73975679917933 28.978 35.66842948082214 139.73975679917933 26.521 35.668430229699574 139.73975774826056 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4188fdf2-ed9f-4bfb-8a31-c391df14cc15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4188fdf2-ed9f-4bfb-8a31-c391df14cc15_0">
											<gml:posList>35.6684299340238 139.73974843683547 26.521 35.6684299340238 139.73974843683547 28.978 35.6684307806873 139.73974762948998 28.978 35.6684307806873 139.73974762948998 26.521 35.6684299340238 139.73974843683547 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81108b11-b4e3-4d72-8fef-596596b99e50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81108b11-b4e3-4d72-8fef-596596b99e50_0">
											<gml:posList>35.668431113602615 139.73975846521844 26.521 35.668431113602615 139.73975846521844 28.978 35.668430229699574 139.73975774826056 28.978 35.668430229699574 139.73975774826056 26.521 35.668431113602615 139.73975846521844 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-125cfe1a-88ea-4033-8d13-ad0d3b43a836">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-125cfe1a-88ea-4033-8d13-ad0d3b43a836_0">
											<gml:posList>35.6684307806873 139.73974762948998 26.521 35.6684307806873 139.73974762948998 28.978 35.66843173569578 139.73974705398382 28.978 35.66843173569578 139.73974705398382 26.521 35.6684307806873 139.73974762948998 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e398735-c79d-4bf2-9937-25b200d5b6c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e398735-c79d-4bf2-9937-25b200d5b6c6_0">
											<gml:posList>35.66843210549868 139.7397589611305 26.521 35.66843210549868 139.7397589611305 28.978 35.668431113602615 139.73975846521844 28.978 35.668431113602615 139.73975846521844 26.521 35.66843210549868 139.7397589611305 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c48b7d8-c5da-47e3-804f-6dcc20aff01c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c48b7d8-c5da-47e3-804f-6dcc20aff01c_0">
											<gml:posList>35.66843173569578 139.73974705398382 28.978 35.66843277202525 139.73974673244052 28.978 35.66843277202525 139.73974673244052 26.521 35.66843173569578 139.73974705398382 26.521 35.66843173569578 139.73974705398382 28.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b23a2e89-9e44-4a89-abbb-39cc093da4ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b23a2e89-9e44-4a89-abbb-39cc093da4ab_0">
											<gml:posList>35.66843316027623 139.7397591808194 26.521 35.66843316027623 139.7397591808194 28.978 35.66843210549868 139.7397589611305 28.978 35.66843210549868 139.7397589611305 26.521 35.66843316027623 139.7397591808194 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81ab406f-2f76-464b-80ed-05872955b488">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81ab406f-2f76-464b-80ed-05872955b488_0">
											<gml:posList>35.66843277202525 139.73974673244052 28.978 35.66843383560192 139.7397466759692 28.978 35.66843383560192 139.7397466759692 26.521 35.66843277202525 139.73974673244052 26.521 35.66843277202525 139.73974673244052 28.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec15ae08-bb6d-4cf5-b586-4f4c9131a649">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec15ae08-bb6d-4cf5-b586-4f4c9131a649_0">
											<gml:posList>35.66843677520102 139.73974811956313 28.978 35.66843588227561 139.73974739156986 28.978 35.668434890388085 139.7397469067039 28.978 35.66843383560192 139.7397466759692 28.978 35.66843277202525 139.73974673244052 28.978 35.66843173569578 139.73974705398382 28.978 35.6684307806873 139.73974762948998 28.978 35.6684299340238 139.73974843683547 28.978 35.668429249761864 139.73974944281926 28.978 35.66842875490835 139.73975060322581 28.978 35.66842846744776 139.7397518628042 28.978 35.66842838733719 139.73975316632462 28.978 35.66842854158347 139.73975446957147 28.978 35.66842891209903 139.73975569524399 28.978 35.66842948082214 139.73975679917933 28.978 35.668430229699574 139.73975774826056 28.978 35.668431113602615 139.73975846521844 28.978 35.66843210549868 139.7397589611305 28.978 35.66843316027623 139.7397591808194 28.978 35.668434223861496 139.7397591353942 28.978 35.668435260182406 139.73975880280508 28.978 35.66843622420467 139.7397582272885 28.978 35.66843706185452 139.73975741995355 28.978 35.6684377461165 139.73975641396976 28.978 35.66843824097008 139.7397552535631 28.978 35.66843853744442 139.73975399397403 28.978 35.668438608541294 139.739752690464 28.978 35.66843845430359 139.73975139826297 28.978 35.66843808377937 139.73975016154432 28.978 35.66843751505621 139.73974905760892 28.978 35.66843677520102 139.73974811956313 28.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb552ca2-07bf-4d70-b9ce-189d8ab95c29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb552ca2-07bf-4d70-b9ce-189d8ab95c29_0">
											<gml:posList>35.668434223861496 139.7397591353942 26.521 35.668434223861496 139.7397591353942 28.978 35.66843316027623 139.7397591808194 28.978 35.66843316027623 139.7397591808194 26.521 35.668434223861496 139.7397591353942 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9bc3e44-eb70-4aff-8681-83a20849fa5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9bc3e44-eb70-4aff-8681-83a20849fa5f_0">
											<gml:posList>35.66843383560192 139.7397466759692 26.521 35.66843383560192 139.7397466759692 28.978 35.668434890388085 139.7397469067039 28.978 35.668434890388085 139.7397469067039 26.521 35.66843383560192 139.7397466759692 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b851541-bc4f-4bbb-a8c4-4032738c9de4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b851541-bc4f-4bbb-a8c4-4032738c9de4_0">
											<gml:posList>35.668435260182406 139.73975880280508 26.521 35.668435260182406 139.73975880280508 28.978 35.668434223861496 139.7397591353942 28.978 35.668434223861496 139.7397591353942 26.521 35.668435260182406 139.73975880280508 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-791fc443-9c14-4d99-8e6e-c6a170e1a63d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-791fc443-9c14-4d99-8e6e-c6a170e1a63d_0">
											<gml:posList>35.668434890388085 139.7397469067039 26.521 35.668434890388085 139.7397469067039 28.978 35.66843588227561 139.73974739156986 28.978 35.66843588227561 139.73974739156986 26.521 35.668434890388085 139.7397469067039 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95381a3d-33c9-40e1-957c-ac034117c988">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95381a3d-33c9-40e1-957c-ac034117c988_0">
											<gml:posList>35.66843622420467 139.7397582272885 28.978 35.668435260182406 139.73975880280508 28.978 35.668435260182406 139.73975880280508 26.521 35.66843622420467 139.7397582272885 26.521 35.66843622420467 139.7397582272885 28.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97d7eda1-5c39-44c4-b5ce-29bb511a8577">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97d7eda1-5c39-44c4-b5ce-29bb511a8577_0">
											<gml:posList>35.66843588227561 139.73974739156986 26.521 35.66843588227561 139.73974739156986 28.978 35.66843677520102 139.73974811956313 28.978 35.66843677520102 139.73974811956313 26.521 35.66843588227561 139.73974739156986 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65532ce2-b9dc-4d05-9974-70031fcb67e3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65532ce2-b9dc-4d05-9974-70031fcb67e3_0">
											<gml:posList>35.66843706185452 139.73975741995355 26.521 35.66843706185452 139.73975741995355 28.978 35.66843622420467 139.7397582272885 28.978 35.66843622420467 139.7397582272885 26.521 35.66843706185452 139.73975741995355 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27dd9052-4f16-4508-947f-4105a4a9dde7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27dd9052-4f16-4508-947f-4105a4a9dde7_0">
											<gml:posList>35.66843677520102 139.73974811956313 28.978 35.66843751505621 139.73974905760892 28.978 35.66843751505621 139.73974905760892 26.521 35.66843677520102 139.73974811956313 26.521 35.66843677520102 139.73974811956313 28.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f07d4d5-fc9d-4096-adcf-4b09f27a4d33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f07d4d5-fc9d-4096-adcf-4b09f27a4d33_0">
											<gml:posList>35.6684377461165 139.73975641396976 28.978 35.66843706185452 139.73975741995355 28.978 35.66843706185452 139.73975741995355 26.521 35.6684377461165 139.73975641396976 26.521 35.6684377461165 139.73975641396976 28.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aae2a220-10d5-4d85-bc34-3008ca3c54ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aae2a220-10d5-4d85-bc34-3008ca3c54ae_0">
											<gml:posList>35.66843751505621 139.73974905760892 28.978 35.66843808377937 139.73975016154432 28.978 35.66843808377937 139.73975016154432 26.521 35.66843751505621 139.73974905760892 26.521 35.66843751505621 139.73974905760892 28.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6535bb79-2931-4f82-889a-054952267a29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6535bb79-2931-4f82-889a-054952267a29_0">
											<gml:posList>35.66843824097008 139.7397552535631 28.978 35.6684377461165 139.73975641396976 28.978 35.6684377461165 139.73975641396976 26.521 35.66843824097008 139.7397552535631 26.521 35.66843824097008 139.7397552535631 28.978</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fd3c2cc-0f30-49bf-a3b7-e5a35b1ec7f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fd3c2cc-0f30-49bf-a3b7-e5a35b1ec7f3_0">
											<gml:posList>35.66843808377937 139.73975016154432 26.521 35.66843808377937 139.73975016154432 28.978 35.66843845430359 139.73975139826297 28.978 35.66843845430359 139.73975139826297 26.521 35.66843808377937 139.73975016154432 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3dc782c-90a2-4581-abc8-999f5d8226bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3dc782c-90a2-4581-abc8-999f5d8226bc_0">
											<gml:posList>35.66843853744442 139.73975399397403 26.521 35.66843853744442 139.73975399397403 28.978 35.66843824097008 139.7397552535631 28.978 35.66843824097008 139.7397552535631 26.521 35.66843853744442 139.73975399397403 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-631dba03-f7a7-4cc4-b991-d0bfdef64bde">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-631dba03-f7a7-4cc4-b991-d0bfdef64bde_0">
											<gml:posList>35.66843845430359 139.73975139826297 26.521 35.66843845430359 139.73975139826297 28.978 35.668438608541294 139.739752690464 28.978 35.668438608541294 139.739752690464 26.521 35.66843845430359 139.73975139826297 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf30f4da-3180-4706-8f9f-8d01e28f0f1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf30f4da-3180-4706-8f9f-8d01e28f0f1d_0">
											<gml:posList>35.668438608541294 139.739752690464 26.521 35.668438608541294 139.739752690464 28.978 35.66843853744442 139.73975399397403 28.978 35.66843853744442 139.73975399397403 26.521 35.668438608541294 139.739752690464 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-137535d5-96db-459b-8e07-3a8c2df30359">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-137535d5-96db-459b-8e07-3a8c2df30359">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-137535d5-96db-459b-8e07-3a8c2df30359">
											<gml:posList>35.66849499098665 139.73969669876462 11.182 35.66853163191172 139.73963888537128 11.182 35.66858422197054 139.73969029833498 11.182 35.66857909058946 139.73969858883618 11.182 35.66858657747833 139.73970564954112 11.182 35.668556238833 139.73975406648225 11.182 35.66852169110908 139.73972174201214 11.182 35.668470196460696 139.73980398434273 11.182 35.66837277689418 139.73971230585988 11.182 35.668424091378256 139.7396302847009 11.182 35.66849499098665 139.73969669876462 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3bc3b5d7-7a0b-4eec-a7db-39b1d69a735c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bc3b5d7-7a0b-4eec-a7db-39b1d69a735c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bc3b5d7-7a0b-4eec-a7db-39b1d69a735c">
											<gml:posList>35.668424091378256 139.7396302847009 20.478 35.66837277689418 139.73971230585988 20.478 35.66838554968126 139.73972432002378 23.747 35.668424091378256 139.7396302847009 20.478</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9521b8b5-b28b-4380-b3ca-ecfa3f95b7c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9521b8b5-b28b-4380-b3ca-ecfa3f95b7c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9521b8b5-b28b-4380-b3ca-ecfa3f95b7c9">
											<gml:posList>35.6683884427866 139.7397239300368 23.747 35.66838554968126 139.73972432002378 23.747 35.66841340447381 139.73975054381953 23.747 35.66841463782614 139.7397485761941 23.747 35.6683884427866 139.7397239300368 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-978cdecc-475e-464a-8386-913b6e04bb3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-978cdecc-475e-464a-8386-913b6e04bb3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-978cdecc-475e-464a-8386-913b6e04bb3e">
											<gml:posList>35.66838554968126 139.73972432002378 23.747 35.66843931765995 139.73964454937493 23.747 35.668424091378256 139.7396302847009 20.478 35.66838554968126 139.73972432002378 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d0e391b-ae02-41de-8a06-1a984dc46ef3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d0e391b-ae02-41de-8a06-1a984dc46ef3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d0e391b-ae02-41de-8a06-1a984dc46ef3">
											<gml:posList>35.66838554968126 139.73972432002378 23.747 35.6683884427866 139.7397239300368 23.747 35.66843963580451 139.7396479732607 23.747 35.66843931765995 139.73964454937493 23.747 35.66838554968126 139.73972432002378 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6375ba33-64b5-4121-8cd9-e589ef0400e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6375ba33-64b5-4121-8cd9-e589ef0400e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6375ba33-64b5-4121-8cd9-e589ef0400e4">
											<gml:posList>35.66845424614448 139.73975111472842 26.521 35.668428330728595 139.73972672228948 26.521 35.66841340447381 139.73975054381953 26.521 35.66843931987636 139.73977492521567 26.521 35.66845424614448 139.73975111472842 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa227f8d-eb70-4674-b2c6-124f779aff06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa227f8d-eb70-4674-b2c6-124f779aff06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa227f8d-eb70-4674-b2c6-124f779aff06">
											<gml:posList>35.6683884427866 139.7397239300368 23.385 35.66841463782614 139.7397485761941 23.385 35.668428330728595 139.73972672228948 23.385 35.66845424614448 139.73975111472842 23.385 35.66844055322908 139.73977295759 23.385 35.66846981519018 139.73980051634467 23.385 35.66851885214628 139.73972220925867 23.385 35.66843963580451 139.7396479732607 23.385 35.6683884427866 139.7397239300368 23.385</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35e9732a-c4d6-4313-b38b-1bed1f59dd6a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35e9732a-c4d6-4313-b38b-1bed1f59dd6a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35e9732a-c4d6-4313-b38b-1bed1f59dd6a">
											<gml:posList>35.66846981519018 139.73980051634467 23.747 35.66844055322908 139.73977295759 23.747 35.66843931987636 139.73977492521567 23.747 35.668470196460696 139.73980398434273 23.747 35.66846981519018 139.73980051634467 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bb1407f1-7d52-430c-b760-15de176b8240">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb1407f1-7d52-430c-b760-15de176b8240">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb1407f1-7d52-430c-b760-15de176b8240">
											<gml:posList>35.66843931765995 139.73964454937493 23.747 35.66843963580451 139.7396479732607 23.747 35.66851885214628 139.73972220925867 23.747 35.66852169110908 139.73972174201214 23.747 35.66843931765995 139.73964454937493 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-35e3036a-cc36-447c-91a9-91aab2c0965d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35e3036a-cc36-447c-91a9-91aab2c0965d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35e3036a-cc36-447c-91a9-91aab2c0965d">
											<gml:posList>35.66852169110908 139.73972174201214 23.747 35.66851885214628 139.73972220925867 23.747 35.66846981519018 139.73980051634467 23.747 35.668470196460696 139.73980398434273 23.747 35.66852169110908 139.73972174201214 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0c1e8fd-3e07-4ffe-a9d0-acb8312db932">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0c1e8fd-3e07-4ffe-a9d0-acb8312db932">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0c1e8fd-3e07-4ffe-a9d0-acb8312db932">
											<gml:posList>35.66852990171625 139.7396742125153 21.597 35.66851692153145 139.73966209916608 21.597 35.66849499098665 139.73969669876462 21.597 35.668508241820255 139.73970912108814 21.597 35.66852990171625 139.7396742125153 21.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-733e1c0a-3aea-4955-a4df-ea5d1cac80e5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-733e1c0a-3aea-4955-a4df-ea5d1cac80e5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-733e1c0a-3aea-4955-a4df-ea5d1cac80e5">
											<gml:posList>35.66852990171625 139.7396742125153 18.988 35.668508241820255 139.73970912108814 18.988 35.66852169110908 139.73972174201214 18.988 35.668556238833 139.73975406648225 18.988 35.66858657747833 139.73970564954112 18.988 35.66857909058946 139.73969858883618 18.988 35.66858422197054 139.73969029833498 18.988 35.66853163191172 139.73963888537128 18.988 35.66851692153145 139.73966209916608 18.988 35.66852990171625 139.7396742125153 18.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38add7e1-9695-44a1-85b5-ee0573678afa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38add7e1-9695-44a1-85b5-ee0573678afa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38add7e1-9695-44a1-85b5-ee0573678afa">
											<gml:posList>35.66843963580451 139.7396479732607 23.747 35.66843963580451 139.7396479732607 23.385 35.66851885214628 139.73972220925867 23.385 35.66851885214628 139.73972220925867 23.747 35.66843963580451 139.7396479732607 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-26f6722f-b098-45b8-91a8-6f5a6d9327b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26f6722f-b098-45b8-91a8-6f5a6d9327b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26f6722f-b098-45b8-91a8-6f5a6d9327b9">
											<gml:posList>35.668424091378256 139.7396302847009 11.182 35.66837277689418 139.73971230585988 11.182 35.66837277689418 139.73971230585988 20.478 35.668424091378256 139.7396302847009 20.478 35.668424091378256 139.7396302847009 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eb856e07-e1b1-4946-95d8-d34f4ed79ca2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eb856e07-e1b1-4946-95d8-d34f4ed79ca2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eb856e07-e1b1-4946-95d8-d34f4ed79ca2">
											<gml:posList>35.66841463782614 139.7397485761941 23.747 35.66841463782614 139.7397485761941 23.385 35.6683884427866 139.7397239300368 23.385 35.6683884427866 139.7397239300368 23.747 35.66841463782614 139.7397485761941 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f34e2db-bfb9-4276-a97b-c2fea2cc3b24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f34e2db-bfb9-4276-a97b-c2fea2cc3b24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f34e2db-bfb9-4276-a97b-c2fea2cc3b24">
											<gml:posList>35.6683884427866 139.7397239300368 23.747 35.6683884427866 139.7397239300368 23.385 35.66843963580451 139.7396479732607 23.385 35.66843963580451 139.7396479732607 23.747 35.6683884427866 139.7397239300368 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d01cc743-3f00-487c-bed7-259d61d522cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d01cc743-3f00-487c-bed7-259d61d522cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d01cc743-3f00-487c-bed7-259d61d522cc">
											<gml:posList>35.66841463782614 139.7397485761941 23.747 35.66841340447381 139.73975054381953 23.747 35.66841340447381 139.73975054381953 26.521 35.668428330728595 139.73972672228948 26.521 35.668428330728595 139.73972672228948 23.385 35.66841463782614 139.7397485761941 23.385 35.66841463782614 139.7397485761941 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d59c5f64-16a4-46dc-af0a-db8547d0e79b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d59c5f64-16a4-46dc-af0a-db8547d0e79b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d59c5f64-16a4-46dc-af0a-db8547d0e79b">
											<gml:posList>35.66843931987636 139.73977492521567 23.747 35.66843931987636 139.73977492521567 26.521 35.66841340447381 139.73975054381953 26.521 35.66841340447381 139.73975054381953 23.747 35.66838554968126 139.73972432002378 23.747 35.66837277689418 139.73971230585988 20.478 35.66837277689418 139.73971230585988 11.182 35.668470196460696 139.73980398434273 11.182 35.668470196460696 139.73980398434273 23.747 35.66843931987636 139.73977492521567 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15c06c72-305a-4667-8609-86109e827965">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15c06c72-305a-4667-8609-86109e827965">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15c06c72-305a-4667-8609-86109e827965">
											<gml:posList>35.668428330728595 139.73972672228948 26.521 35.66845424614448 139.73975111472842 26.521 35.66845424614448 139.73975111472842 23.385 35.668428330728595 139.73972672228948 23.385 35.668428330728595 139.73972672228948 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d8ca7cd-f52a-4538-877d-c9f12942d3b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d8ca7cd-f52a-4538-877d-c9f12942d3b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d8ca7cd-f52a-4538-877d-c9f12942d3b7">
											<gml:posList>35.66843931987636 139.73977492521567 26.521 35.66843931987636 139.73977492521567 23.747 35.66844055322908 139.73977295759 23.747 35.66844055322908 139.73977295759 23.385 35.66845424614448 139.73975111472842 23.385 35.66845424614448 139.73975111472842 26.521 35.66843931987636 139.73977492521567 26.521</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36cbfcf2-a2f8-4b6f-a346-9ddd6b381bf7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36cbfcf2-a2f8-4b6f-a346-9ddd6b381bf7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36cbfcf2-a2f8-4b6f-a346-9ddd6b381bf7">
											<gml:posList>35.66846981519018 139.73980051634467 23.747 35.66846981519018 139.73980051634467 23.385 35.66844055322908 139.73977295759 23.385 35.66844055322908 139.73977295759 23.747 35.66846981519018 139.73980051634467 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cf3bf0e-b43d-4a15-b5f1-afc23331571d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cf3bf0e-b43d-4a15-b5f1-afc23331571d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cf3bf0e-b43d-4a15-b5f1-afc23331571d">
											<gml:posList>35.66849499098665 139.73969669876462 21.597 35.66849499098665 139.73969669876462 11.182 35.668424091378256 139.7396302847009 11.182 35.668424091378256 139.7396302847009 20.478 35.66843931765995 139.73964454937493 23.747 35.66852169110908 139.73972174201214 23.747 35.66852169110908 139.73972174201214 18.988 35.668508241820255 139.73970912108814 18.988 35.668508241820255 139.73970912108814 21.597 35.66849499098665 139.73969669876462 21.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3e42b0b-5b7a-4b6d-aff9-f5f62b62109c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3e42b0b-5b7a-4b6d-aff9-f5f62b62109c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3e42b0b-5b7a-4b6d-aff9-f5f62b62109c">
											<gml:posList>35.66851885214628 139.73972220925867 23.747 35.66851885214628 139.73972220925867 23.385 35.66846981519018 139.73980051634467 23.385 35.66846981519018 139.73980051634467 23.747 35.66851885214628 139.73972220925867 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9bba33cc-6cde-43ad-b47d-80e8ee7710c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9bba33cc-6cde-43ad-b47d-80e8ee7710c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9bba33cc-6cde-43ad-b47d-80e8ee7710c2">
											<gml:posList>35.668470196460696 139.73980398434273 23.747 35.668470196460696 139.73980398434273 11.182 35.66852169110908 139.73972174201214 11.182 35.66852169110908 139.73972174201214 18.988 35.66852169110908 139.73972174201214 23.747 35.668470196460696 139.73980398434273 23.747</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adcc1f76-fa3b-4b5d-a143-bb9394e3837a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adcc1f76-fa3b-4b5d-a143-bb9394e3837a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adcc1f76-fa3b-4b5d-a143-bb9394e3837a">
											<gml:posList>35.66858422197054 139.73969029833498 11.182 35.66853163191172 139.73963888537128 11.182 35.66853163191172 139.73963888537128 18.988 35.66858422197054 139.73969029833498 18.988 35.66858422197054 139.73969029833498 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6240beb5-6494-4694-a1bd-f2c803e3116b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6240beb5-6494-4694-a1bd-f2c803e3116b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6240beb5-6494-4694-a1bd-f2c803e3116b">
											<gml:posList>35.66849499098665 139.73969669876462 11.182 35.66849499098665 139.73969669876462 21.597 35.66851692153145 139.73966209916608 21.597 35.66851692153145 139.73966209916608 18.988 35.66853163191172 139.73963888537128 18.988 35.66853163191172 139.73963888537128 11.182 35.66849499098665 139.73969669876462 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a5791f58-6e8d-4802-afdf-318791e5efc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5791f58-6e8d-4802-afdf-318791e5efc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5791f58-6e8d-4802-afdf-318791e5efc4">
											<gml:posList>35.66851692153145 139.73966209916608 21.597 35.66852990171625 139.7396742125153 21.597 35.66852990171625 139.7396742125153 18.988 35.66851692153145 139.73966209916608 18.988 35.66851692153145 139.73966209916608 21.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-699d4687-1a18-4a9e-82e4-ba2bfb79d0fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-699d4687-1a18-4a9e-82e4-ba2bfb79d0fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-699d4687-1a18-4a9e-82e4-ba2bfb79d0fd">
											<gml:posList>35.66852990171625 139.7396742125153 21.597 35.668508241820255 139.73970912108814 21.597 35.668508241820255 139.73970912108814 18.988 35.66852990171625 139.7396742125153 18.988 35.66852990171625 139.7396742125153 21.597</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3bfc36b6-9550-464a-81c2-b25a140a7665">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3bfc36b6-9550-464a-81c2-b25a140a7665">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3bfc36b6-9550-464a-81c2-b25a140a7665">
											<gml:posList>35.66857909058946 139.73969858883618 11.182 35.66858422197054 139.73969029833498 11.182 35.66858422197054 139.73969029833498 18.988 35.66857909058946 139.73969858883618 18.988 35.66857909058946 139.73969858883618 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-560d216c-7015-49bf-8eff-30d6193d9d59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-560d216c-7015-49bf-8eff-30d6193d9d59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-560d216c-7015-49bf-8eff-30d6193d9d59">
											<gml:posList>35.66858657747833 139.73970564954112 11.182 35.66857909058946 139.73969858883618 11.182 35.66857909058946 139.73969858883618 18.988 35.66858657747833 139.73970564954112 18.988 35.66858657747833 139.73970564954112 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0277af88-9033-4b11-982b-86cbff5a9d2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0277af88-9033-4b11-982b-86cbff5a9d2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0277af88-9033-4b11-982b-86cbff5a9d2f">
											<gml:posList>35.668556238833 139.73975406648225 11.182 35.66858657747833 139.73970564954112 11.182 35.66858657747833 139.73970564954112 18.988 35.668556238833 139.73975406648225 18.988 35.668556238833 139.73975406648225 11.182</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe9ae0f9-9691-409b-b8f6-48836f62c41a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe9ae0f9-9691-409b-b8f6-48836f62c41a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe9ae0f9-9691-409b-b8f6-48836f62c41a">
											<gml:posList>35.668556238833 139.73975406648225 18.988 35.66852169110908 139.73972174201214 18.988 35.66852169110908 139.73972174201214 11.182 35.668556238833 139.73975406648225 11.182 35.668556238833 139.73975406648225 18.988</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1191</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">127.50357</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.11</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>