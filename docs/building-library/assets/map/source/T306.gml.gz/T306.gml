<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5859501e-0bef-4b1a-b679-92a782402f3c">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">8.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.666811360112064 139.73768910829867 0 35.66674745698343 139.73758104654112 0 35.666688458689464 139.7376334738482 0 35.66675254187085 139.73774131443835 0 35.666811360112064 139.73768910829867 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666811360112064 139.73768910829867 13.848 35.66675254187085 139.73774131443835 13.848 35.666688458689464 139.7376334738482 13.848 35.66674745698343 139.73758104654112 13.848 35.666811360112064 139.73768910829867 13.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666811360112064 139.73768910829867 13.848 35.66674745698343 139.73758104654112 13.848 35.66674745698343 139.73758104654112 22.54 35.666811360112064 139.73768910829867 22.54 35.666811360112064 139.73768910829867 13.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66674745698343 139.73758104654112 13.848 35.666688458689464 139.7376334738482 13.848 35.666688458689464 139.7376334738482 22.54 35.66674745698343 139.73758104654112 22.54 35.66674745698343 139.73758104654112 13.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666688458689464 139.7376334738482 13.848 35.66675254187085 139.73774131443835 13.848 35.66675254187085 139.73774131443835 22.54 35.666688458689464 139.7376334738482 22.54 35.666688458689464 139.7376334738482 13.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66675254187085 139.73774131443835 13.848 35.666811360112064 139.73768910829867 13.848 35.666811360112064 139.73768910829867 22.54 35.66675254187085 139.73774131443835 22.54 35.66675254187085 139.73774131443835 13.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666811360112064 139.73768910829867 22.54 35.66674745698343 139.73758104654112 22.54 35.666688458689464 139.7376334738482 22.54 35.66675254187085 139.73774131443835 22.54 35.666811360112064 139.73768910829867 22.54</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-81bd66d6-6dfb-44f6-9cfd-097413154000"/>
							<gml:surfaceMember xlink:href="#poly-86d05373-6d7f-4c99-a505-6f3bd550c956"/>
							<gml:surfaceMember xlink:href="#poly-754a4392-aabd-460c-acc6-7c14ed358a67"/>
							<gml:surfaceMember xlink:href="#poly-06cd809d-1ecc-4762-b6ba-638d81c8efd9"/>
							<gml:surfaceMember xlink:href="#poly-7aca929a-b8db-4fa4-8abf-a3b90df9248b"/>
							<gml:surfaceMember xlink:href="#poly-e5e1c174-937a-4ccd-ad7a-f2e1bc5e7b4b"/>
							<gml:surfaceMember xlink:href="#poly-d3d90817-0f76-49b5-8c1b-18644f6e07ba"/>
							<gml:surfaceMember xlink:href="#poly-d4f6754e-d5b2-4b8c-9268-35a813d8f6b3"/>
							<gml:surfaceMember xlink:href="#poly-75d03ed4-2a26-464a-baf9-208f9d7c5aea"/>
							<gml:surfaceMember xlink:href="#poly-4ad70f90-5232-41e9-88e4-8f20984f86e3"/>
							<gml:surfaceMember xlink:href="#poly-f4d29d88-e310-427e-8733-9439035812d5"/>
							<gml:surfaceMember xlink:href="#poly-cb2ee1d9-5299-4dac-93db-98d9d05d9454"/>
							<gml:surfaceMember xlink:href="#poly-ab932d98-a6a7-4947-9021-2a38a5a5a5bf"/>
							<gml:surfaceMember xlink:href="#poly-7ad7b5e3-541a-497d-9a54-71681b541aa0"/>
							<gml:surfaceMember xlink:href="#poly-b666f1f7-8629-45b2-8d58-26506855d7fd"/>
							<gml:surfaceMember xlink:href="#poly-e4519dd3-2bf3-477b-a6a4-8011220b027d"/>
							<gml:surfaceMember xlink:href="#poly-e17acb27-2130-469a-80b4-964a3df1fc25"/>
							<gml:surfaceMember xlink:href="#poly-45309585-beef-46c6-8e86-7aadf6747c42"/>
							<gml:surfaceMember xlink:href="#poly-71d4c70d-ae1d-4391-92ea-398f0f252f2e"/>
							<gml:surfaceMember xlink:href="#poly-8edf7975-af8c-454d-8f20-07d236e7cdc4"/>
							<gml:surfaceMember xlink:href="#poly-70607cf2-15ff-4623-a7a6-b2a83d5da84a"/>
							<gml:surfaceMember xlink:href="#poly-936a8868-34ea-42ab-86e1-ecc40804eb3f"/>
							<gml:surfaceMember xlink:href="#poly-a40e3655-0e55-4bcc-9231-9ff618164187"/>
							<gml:surfaceMember xlink:href="#poly-98e038a3-b8df-4fb2-9196-3d3cfe930c95"/>
							<gml:surfaceMember xlink:href="#poly-e0c8252e-7324-4cca-8679-5c2c7cff73c0"/>
							<gml:surfaceMember xlink:href="#poly-6d80a728-c45f-4d46-aaf3-4e46e5ed1ace"/>
							<gml:surfaceMember xlink:href="#poly-ab6ab8ab-3d61-43cc-9e13-88ba82ae9a58"/>
							<gml:surfaceMember xlink:href="#poly-76a46086-1dd5-4cae-bfd0-526251c36e94"/>
							<gml:surfaceMember xlink:href="#poly-71eb183a-903f-4ae6-9c59-e907880d9efe"/>
							<gml:surfaceMember xlink:href="#poly-b7e2ead1-4312-41f7-829b-592c5b36942e"/>
							<gml:surfaceMember xlink:href="#poly-be2e1da2-96ea-4ae5-871c-2ca59555c8f0"/>
							<gml:surfaceMember xlink:href="#poly-56baaac9-30a6-4fdc-addd-33f5f65e7145"/>
							<gml:surfaceMember xlink:href="#poly-c4ca91ee-2f4a-4f25-a76b-c424be3d4979"/>
							<gml:surfaceMember xlink:href="#poly-538ab92d-1b6b-4a2b-bfff-f211c63c7c9f"/>
							<gml:surfaceMember xlink:href="#poly-3805e9f7-fe82-47ef-800f-abbbd7318f66"/>
							<gml:surfaceMember xlink:href="#poly-7020a298-fd1c-4bf5-bbc9-620ec9f89f0b"/>
							<gml:surfaceMember xlink:href="#poly-ded09a1e-e46b-41e9-bf92-79ec092b7d25"/>
							<gml:surfaceMember xlink:href="#poly-6ed2a4e5-4c0d-4ad6-afd2-a76d6fce3012"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5859501e-0bef-4b1a-b679-92a782402f3c_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a152267a-4463-4e9f-99c0-ac3854656d6a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66676480409042 139.7376776651909 24.895 35.666754226733964 139.7376609766199 24.895 35.66676867383477 139.73764721845566 24.895 35.66677926020683 139.73766390701707 24.895 35.66676480409042 139.7376776651909 24.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e63f90d4-7259-4580-b9e6-a8c261bec453">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e63f90d4-7259-4580-b9e6-a8c261bec453_0">
											<gml:posList>35.666754226733964 139.7376609766199 24.895 35.666754226733964 139.7376609766199 25.877 35.66676867383477 139.73764721845566 25.877 35.66676867383477 139.73764721845566 24.895 35.666754226733964 139.7376609766199 24.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-762ff137-1823-4c0b-a49d-9a313b6c3850">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-762ff137-1823-4c0b-a49d-9a313b6c3850_0">
											<gml:posList>35.66676867383477 139.73764721845566 24.895 35.66676867383477 139.73764721845566 25.877 35.66677926020683 139.73766390701707 25.877 35.66677926020683 139.73766390701707 24.895 35.66676867383477 139.73764721845566 24.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e10b4a2-4205-4b00-a736-8fcdd10bb89d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e10b4a2-4205-4b00-a736-8fcdd10bb89d_0">
											<gml:posList>35.66676480409042 139.7376776651909 25.877 35.66677926020683 139.73766390701707 25.877 35.66676867383477 139.73764721845566 25.877 35.666754226733964 139.7376609766199 25.877 35.66676480409042 139.7376776651909 25.877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fb32608-f746-43e0-8550-bb4c286cfab5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fb32608-f746-43e0-8550-bb4c286cfab5_0">
											<gml:posList>35.66676480409042 139.7376776651909 24.895 35.66676480409042 139.7376776651909 25.877 35.666754226733964 139.7376609766199 25.877 35.666754226733964 139.7376609766199 24.895 35.66676480409042 139.7376776651909 24.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25d8d516-9ced-48f3-9ae8-74d0d2b7ad87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25d8d516-9ced-48f3-9ae8-74d0d2b7ad87_0">
											<gml:posList>35.66677926020683 139.73766390701707 24.895 35.66677926020683 139.73766390701707 25.877 35.66676480409042 139.7376776651909 25.877 35.66676480409042 139.7376776651909 24.895 35.66677926020683 139.73766390701707 24.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5859501e-0bef-4b1a-b679-92a782402f3c_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01513f8b-d1e4-4b44-a2e8-e98514918b94">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66677163323317 139.73763951602814 22.449 35.66674454657424 139.73759367531815 22.449 35.66670478799081 139.7376289587388 22.449 35.6667179025889 139.7376511560992 22.449 35.66671606507867 139.73765278201765 22.449 35.666701686864734 139.73762845433538 22.449 35.66674463405052 139.73759032834897 22.449 35.66677371541297 139.73763952458913 22.449 35.66677163323317 139.73763951602814 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05e182c5-d022-412f-bb97-07ea5615e8bd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05e182c5-d022-412f-bb97-07ea5615e8bd_0">
											<gml:posList>35.666701686864734 139.73762845433538 22.449 35.666701686864734 139.73762845433538 23.984 35.66674463405052 139.73759032834897 23.984 35.66674463405052 139.73759032834897 22.449 35.666701686864734 139.73762845433538 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fead5ba0-e816-43b0-bc50-ea574851e8c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fead5ba0-e816-43b0-bc50-ea574851e8c2_0">
											<gml:posList>35.66674454657424 139.73759367531815 22.449 35.66674454657424 139.73759367531815 23.984 35.66670478799081 139.7376289587388 23.984 35.66670478799081 139.7376289587388 22.449 35.66674454657424 139.73759367531815 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d9c8fc9-a0f6-47c0-a9c9-8ccb82298240">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d9c8fc9-a0f6-47c0-a9c9-8ccb82298240_0">
											<gml:posList>35.66674463405052 139.73759032834897 23.984 35.66677371541297 139.73763952458913 23.984 35.66677371541297 139.73763952458913 22.449 35.66674463405052 139.73759032834897 22.449 35.66674463405052 139.73759032834897 23.984</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b47fadd-b58b-43d8-ac13-78eaac7f70d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b47fadd-b58b-43d8-ac13-78eaac7f70d8_0">
											<gml:posList>35.66674463405052 139.73759032834897 23.984 35.666701686864734 139.73762845433538 23.984 35.66670478799081 139.7376289587388 23.984 35.66674454657424 139.73759367531815 23.984 35.66677163323317 139.73763951602814 23.984 35.66677371541297 139.73763952458913 23.984 35.66674463405052 139.73759032834897 23.984</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7682e85f-f82e-4fe9-86a2-84f1b370f725">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7682e85f-f82e-4fe9-86a2-84f1b370f725_0">
											<gml:posList>35.66677163323317 139.73763951602814 23.984 35.66674454657424 139.73759367531815 23.984 35.66674454657424 139.73759367531815 22.449 35.66677163323317 139.73763951602814 22.449 35.66677163323317 139.73763951602814 23.984</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8af91c4b-0bc9-4f3e-8e17-4c0ecc1468b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8af91c4b-0bc9-4f3e-8e17-4c0ecc1468b0_0">
											<gml:posList>35.66677371541297 139.73763952458913 23.984 35.66677163323317 139.73763951602814 23.984 35.66677163323317 139.73763951602814 22.449 35.66677371541297 139.73763952458913 22.449 35.66677371541297 139.73763952458913 23.984</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6d42913-c870-4f5b-ab11-81844e6cb9cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6d42913-c870-4f5b-ab11-81844e6cb9cc_0">
											<gml:posList>35.6667179025889 139.7376511560992 22.449 35.66670478799081 139.7376289587388 22.449 35.66670478799081 139.7376289587388 23.984 35.6667179025889 139.7376511560992 23.984 35.6667179025889 139.7376511560992 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49f71ef1-1e1e-4ae8-8701-6c736e169d30">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49f71ef1-1e1e-4ae8-8701-6c736e169d30_0">
											<gml:posList>35.66670478799081 139.7376289587388 23.984 35.666701686864734 139.73762845433538 23.984 35.66671606507867 139.73765278201765 23.984 35.6667179025889 139.7376511560992 23.984 35.66670478799081 139.7376289587388 23.984</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5b18b95-d777-46f3-bb0e-6de84ee113da">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b5b18b95-d777-46f3-bb0e-6de84ee113da_0">
											<gml:posList>35.66671606507867 139.73765278201765 22.449 35.66671606507867 139.73765278201765 23.984 35.666701686864734 139.73762845433538 23.984 35.666701686864734 139.73762845433538 22.449 35.66671606507867 139.73765278201765 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79ddcc34-dde8-4f54-9ce0-1b53ea46d304">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79ddcc34-dde8-4f54-9ce0-1b53ea46d304_0">
											<gml:posList>35.66671606507867 139.73765278201765 22.449 35.6667179025889 139.7376511560992 22.449 35.6667179025889 139.7376511560992 23.984 35.66671606507867 139.73765278201765 23.984 35.66671606507867 139.73765278201765 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-81bd66d6-6dfb-44f6-9cfd-097413154000">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81bd66d6-6dfb-44f6-9cfd-097413154000">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81bd66d6-6dfb-44f6-9cfd-097413154000">
											<gml:posList>35.66681136011204 139.73768910829864 13.848 35.66675254187082 139.73774131443835 13.848 35.66668845868948 139.7376334738482 13.848 35.66674745698341 139.73758104654112 13.848 35.66681136011204 139.73768910829864 13.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-86d05373-6d7f-4c99-a505-6f3bd550c956">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86d05373-6d7f-4c99-a505-6f3bd550c956">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86d05373-6d7f-4c99-a505-6f3bd550c956">
											<gml:posList>35.66668845868948 139.7376334738482 22.613 35.66668995519648 139.73763375925174 22.613 35.66674722407571 139.73758286936942 22.613 35.66674745698341 139.73758104654112 22.613 35.66668845868948 139.7376334738482 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-754a4392-aabd-460c-acc6-7c14ed358a67">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-754a4392-aabd-460c-acc6-7c14ed358a67">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-754a4392-aabd-460c-acc6-7c14ed358a67">
											<gml:posList>35.66674745698341 139.73758104654112 22.613 35.66674722407571 139.73758286936942 22.613 35.66680986358766 139.73768880080212 22.613 35.66681136011204 139.73768910829864 22.613 35.66674745698341 139.73758104654112 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06cd809d-1ecc-4762-b6ba-638d81c8efd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06cd809d-1ecc-4762-b6ba-638d81c8efd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06cd809d-1ecc-4762-b6ba-638d81c8efd9">
											<gml:posList>35.66672873845808 139.73764152231607 25.092 35.666729036797626 139.73764263758142 25.092 35.666776160740056 139.73764280226246 25.092 35.66677662856735 139.73764168608216 25.092 35.66672873845808 139.73764152231607 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7aca929a-b8db-4fa4-8abf-a3b90df9248b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7aca929a-b8db-4fa4-8abf-a3b90df9248b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7aca929a-b8db-4fa4-8abf-a3b90df9248b">
											<gml:posList>35.66672873845808 139.73764152231607 25.092 35.66672666676662 139.73764336942952 25.092 35.66672792889035 139.7376436219758 25.092 35.666729036797626 139.73764263758142 25.092 35.66672873845808 139.73764152231607 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5e1c174-937a-4ccd-ad7a-f2e1bc5e7b4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5e1c174-937a-4ccd-ad7a-f2e1bc5e7b4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5e1c174-937a-4ccd-ad7a-f2e1bc5e7b4b">
											<gml:posList>35.66677662856735 139.73764168608216 25.092 35.666776160740056 139.73764280226246 25.092 35.66679592737668 139.73767622525202 25.092 35.666797198514054 139.73767647778828 25.092 35.66677662856735 139.73764168608216 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3d90817-0f76-49b5-8c1b-18644f6e07ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3d90817-0f76-49b5-8c1b-18644f6e07ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3d90817-0f76-49b5-8c1b-18644f6e07ba">
											<gml:posList>35.66668995519648 139.73763375925174 22.449 35.66675278378588 139.73773948055387 22.449 35.666755666153065 139.73773692554724 22.449 35.6667094266393 139.73765867732521 22.449 35.66672873845808 139.73764152231607 22.449 35.66677662856735 139.73764168608216 22.449 35.666797198514054 139.73767647778828 22.449 35.66678971337111 139.73768311417606 22.449 35.666798856576825 139.73769858943348 22.449 35.66680986358766 139.73768880080212 22.449 35.66674722407571 139.73758286936942 22.449 35.66668995519648 139.73763375925174 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d4f6754e-d5b2-4b8c-9268-35a813d8f6b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4f6754e-d5b2-4b8c-9268-35a813d8f6b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4f6754e-d5b2-4b8c-9268-35a813d8f6b3">
											<gml:posList>35.66678971337111 139.73768311417606 25.092 35.666797198514054 139.73767647778828 25.092 35.66679592737668 139.73767622525202 25.092 35.666788442233745 139.7376828616397 25.092 35.66678971337111 139.73768311417606 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-75d03ed4-2a26-464a-baf9-208f9d7c5aea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-75d03ed4-2a26-464a-baf9-208f9d7c5aea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-75d03ed4-2a26-464a-baf9-208f9d7c5aea">
											<gml:posList>35.666788442233745 139.7376828616397 24.895 35.66679592737668 139.73767622525202 24.895 35.666776160740056 139.73764280226246 24.895 35.666729036797626 139.73764263758142 24.895 35.66672792889035 139.7376436219758 24.895 35.66677373516725 139.73772113065766 24.895 35.66679821724257 139.73769939653687 24.895 35.666788442233745 139.7376828616397 24.895</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ad70f90-5232-41e9-88e4-8f20984f86e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ad70f90-5232-41e9-88e4-8f20984f86e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ad70f90-5232-41e9-88e4-8f20984f86e3">
											<gml:posList>35.66677353809308 139.73772267729936 25.092 35.66677373516725 139.73772113065766 25.092 35.66672792889035 139.7376436219758 25.092 35.66672666676662 139.73764336942952 25.092 35.66677353809308 139.73772267729936 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4d29d88-e310-427e-8733-9439035812d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4d29d88-e310-427e-8733-9439035812d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4d29d88-e310-427e-8733-9439035812d5">
											<gml:posList>35.66675254187082 139.73774131443835 22.613 35.66675278378588 139.73773948055387 22.613 35.66668995519648 139.73763375925174 22.613 35.66668845868948 139.7376334738482 22.613 35.66675254187082 139.73774131443835 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cb2ee1d9-5299-4dac-93db-98d9d05d9454">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb2ee1d9-5299-4dac-93db-98d9d05d9454">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb2ee1d9-5299-4dac-93db-98d9d05d9454">
											<gml:posList>35.666755666153065 139.73773692554724 22.613 35.66675629795579 139.73773798518698 22.613 35.66677353809308 139.73772267729936 25.092 35.66672666676662 139.73764336942952 25.092 35.6667094266393 139.73765867732521 22.613 35.666755666153065 139.73773692554724 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ab932d98-a6a7-4947-9021-2a38a5a5a5bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab932d98-a6a7-4947-9021-2a38a5a5a5bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab932d98-a6a7-4947-9021-2a38a5a5a5bf">
											<gml:posList>35.66678971337111 139.73768311417606 25.092 35.666788442233745 139.7376828616397 25.092 35.66679821724257 139.73769939653687 25.092 35.666799488379894 139.7376996490735 25.092 35.66678971337111 139.73768311417606 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7ad7b5e3-541a-497d-9a54-71681b541aa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ad7b5e3-541a-497d-9a54-71681b541aa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ad7b5e3-541a-497d-9a54-71681b541aa0">
											<gml:posList>35.66680986358766 139.73768880080212 22.613 35.666798856576825 139.73769858943348 22.613 35.666799488379894 139.7376996490735 22.613 35.66681136011204 139.73768910829864 22.613 35.66680986358766 139.73768880080212 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b666f1f7-8629-45b2-8d58-26506855d7fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b666f1f7-8629-45b2-8d58-26506855d7fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b666f1f7-8629-45b2-8d58-26506855d7fd">
											<gml:posList>35.666799488379894 139.7376996490735 25.092 35.66679821724257 139.73769939653687 25.092 35.66677373516725 139.73772113065766 25.092 35.66677353809308 139.73772267729936 25.092 35.666799488379894 139.7376996490735 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e4519dd3-2bf3-477b-a6a4-8011220b027d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4519dd3-2bf3-477b-a6a4-8011220b027d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4519dd3-2bf3-477b-a6a4-8011220b027d">
											<gml:posList>35.66675278378588 139.73773948055387 22.613 35.66675254187082 139.73774131443835 22.613 35.66675629795579 139.73773798518698 22.613 35.666755666153065 139.73773692554724 22.613 35.66675278378588 139.73773948055387 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e17acb27-2130-469a-80b4-964a3df1fc25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e17acb27-2130-469a-80b4-964a3df1fc25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e17acb27-2130-469a-80b4-964a3df1fc25">
											<gml:posList>35.66675278378588 139.73773948055387 22.613 35.66675278378588 139.73773948055387 22.449 35.66668995519648 139.73763375925174 22.449 35.66668995519648 139.73763375925174 22.613 35.66675278378588 139.73773948055387 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45309585-beef-46c6-8e86-7aadf6747c42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45309585-beef-46c6-8e86-7aadf6747c42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45309585-beef-46c6-8e86-7aadf6747c42">
											<gml:posList>35.66674722407571 139.73758286936942 22.613 35.66674722407571 139.73758286936942 22.449 35.66680986358766 139.73768880080212 22.449 35.66680986358766 139.73768880080212 22.613 35.66674722407571 139.73758286936942 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71d4c70d-ae1d-4391-92ea-398f0f252f2e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71d4c70d-ae1d-4391-92ea-398f0f252f2e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71d4c70d-ae1d-4391-92ea-398f0f252f2e">
											<gml:posList>35.66674745698341 139.73758104654112 13.848 35.66668845868948 139.7376334738482 13.848 35.66668845868948 139.7376334738482 22.613 35.66674745698341 139.73758104654112 22.613 35.66674745698341 139.73758104654112 13.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8edf7975-af8c-454d-8f20-07d236e7cdc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8edf7975-af8c-454d-8f20-07d236e7cdc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8edf7975-af8c-454d-8f20-07d236e7cdc4">
											<gml:posList>35.66668995519648 139.73763375925174 22.613 35.66668995519648 139.73763375925174 22.449 35.66674722407571 139.73758286936942 22.449 35.66674722407571 139.73758286936942 22.613 35.66668995519648 139.73763375925174 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-70607cf2-15ff-4623-a7a6-b2a83d5da84a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-70607cf2-15ff-4623-a7a6-b2a83d5da84a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-70607cf2-15ff-4623-a7a6-b2a83d5da84a">
											<gml:posList>35.66681136011204 139.73768910829864 13.848 35.66674745698341 139.73758104654112 13.848 35.66674745698341 139.73758104654112 22.613 35.66681136011204 139.73768910829864 22.613 35.66681136011204 139.73768910829864 13.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-936a8868-34ea-42ab-86e1-ecc40804eb3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-936a8868-34ea-42ab-86e1-ecc40804eb3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-936a8868-34ea-42ab-86e1-ecc40804eb3f">
											<gml:posList>35.66672873845808 139.73764152231607 25.092 35.66677662856735 139.73764168608216 25.092 35.66677662856735 139.73764168608216 22.449 35.66672873845808 139.73764152231607 22.449 35.66672873845808 139.73764152231607 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a40e3655-0e55-4bcc-9231-9ff618164187">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a40e3655-0e55-4bcc-9231-9ff618164187">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a40e3655-0e55-4bcc-9231-9ff618164187">
											<gml:posList>35.666729036797626 139.73764263758142 25.092 35.666729036797626 139.73764263758142 24.895 35.666776160740056 139.73764280226246 24.895 35.666776160740056 139.73764280226246 25.092 35.666729036797626 139.73764263758142 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-98e038a3-b8df-4fb2-9196-3d3cfe930c95">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98e038a3-b8df-4fb2-9196-3d3cfe930c95">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98e038a3-b8df-4fb2-9196-3d3cfe930c95">
											<gml:posList>35.66672792889035 139.7376436219758 25.092 35.66672792889035 139.7376436219758 24.895 35.666729036797626 139.73764263758142 24.895 35.666729036797626 139.73764263758142 25.092 35.66672792889035 139.7376436219758 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e0c8252e-7324-4cca-8679-5c2c7cff73c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e0c8252e-7324-4cca-8679-5c2c7cff73c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e0c8252e-7324-4cca-8679-5c2c7cff73c0">
											<gml:posList>35.66672873845808 139.73764152231607 22.449 35.6667094266393 139.73765867732521 22.449 35.6667094266393 139.73765867732521 22.613 35.66672666676662 139.73764336942952 25.092 35.66672873845808 139.73764152231607 25.092 35.66672873845808 139.73764152231607 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d80a728-c45f-4d46-aaf3-4e46e5ed1ace">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d80a728-c45f-4d46-aaf3-4e46e5ed1ace">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d80a728-c45f-4d46-aaf3-4e46e5ed1ace">
											<gml:posList>35.66677662856735 139.73764168608216 25.092 35.666797198514054 139.73767647778828 25.092 35.666797198514054 139.73767647778828 22.449 35.66677662856735 139.73764168608216 22.449 35.66677662856735 139.73764168608216 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab6ab8ab-3d61-43cc-9e13-88ba82ae9a58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab6ab8ab-3d61-43cc-9e13-88ba82ae9a58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab6ab8ab-3d61-43cc-9e13-88ba82ae9a58">
											<gml:posList>35.666776160740056 139.73764280226246 25.092 35.666776160740056 139.73764280226246 24.895 35.66679592737668 139.73767622525202 24.895 35.66679592737668 139.73767622525202 25.092 35.666776160740056 139.73764280226246 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76a46086-1dd5-4cae-bfd0-526251c36e94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76a46086-1dd5-4cae-bfd0-526251c36e94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76a46086-1dd5-4cae-bfd0-526251c36e94">
											<gml:posList>35.66679592737668 139.73767622525202 25.092 35.66679592737668 139.73767622525202 24.895 35.666788442233745 139.7376828616397 24.895 35.666788442233745 139.7376828616397 25.092 35.66679592737668 139.73767622525202 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71eb183a-903f-4ae6-9c59-e907880d9efe">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71eb183a-903f-4ae6-9c59-e907880d9efe">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71eb183a-903f-4ae6-9c59-e907880d9efe">
											<gml:posList>35.66678971337111 139.73768311417606 22.449 35.666797198514054 139.73767647778828 22.449 35.666797198514054 139.73767647778828 25.092 35.66678971337111 139.73768311417606 25.092 35.66678971337111 139.73768311417606 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b7e2ead1-4312-41f7-829b-592c5b36942e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7e2ead1-4312-41f7-829b-592c5b36942e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7e2ead1-4312-41f7-829b-592c5b36942e">
											<gml:posList>35.66677373516725 139.73772113065766 25.092 35.66677373516725 139.73772113065766 24.895 35.66672792889035 139.7376436219758 24.895 35.66672792889035 139.7376436219758 25.092 35.66677373516725 139.73772113065766 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be2e1da2-96ea-4ae5-871c-2ca59555c8f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be2e1da2-96ea-4ae5-871c-2ca59555c8f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be2e1da2-96ea-4ae5-871c-2ca59555c8f0">
											<gml:posList>35.66668845868948 139.7376334738482 13.848 35.66675254187082 139.73774131443835 13.848 35.66675254187082 139.73774131443835 22.613 35.66668845868948 139.7376334738482 22.613 35.66668845868948 139.7376334738482 13.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56baaac9-30a6-4fdc-addd-33f5f65e7145">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56baaac9-30a6-4fdc-addd-33f5f65e7145">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56baaac9-30a6-4fdc-addd-33f5f65e7145">
											<gml:posList>35.666788442233745 139.7376828616397 25.092 35.666788442233745 139.7376828616397 24.895 35.66679821724257 139.73769939653687 24.895 35.66679821724257 139.73769939653687 25.092 35.666788442233745 139.7376828616397 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c4ca91ee-2f4a-4f25-a76b-c424be3d4979">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c4ca91ee-2f4a-4f25-a76b-c424be3d4979">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c4ca91ee-2f4a-4f25-a76b-c424be3d4979">
											<gml:posList>35.66678971337111 139.73768311417606 22.449 35.66678971337111 139.73768311417606 25.092 35.666799488379894 139.7376996490735 25.092 35.666799488379894 139.7376996490735 22.613 35.666798856576825 139.73769858943348 22.613 35.666798856576825 139.73769858943348 22.449 35.66678971337111 139.73768311417606 22.449</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-538ab92d-1b6b-4a2b-bfff-f211c63c7c9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-538ab92d-1b6b-4a2b-bfff-f211c63c7c9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-538ab92d-1b6b-4a2b-bfff-f211c63c7c9f">
											<gml:posList>35.66680986358766 139.73768880080212 22.613 35.66680986358766 139.73768880080212 22.449 35.666798856576825 139.73769858943348 22.449 35.666798856576825 139.73769858943348 22.613 35.66680986358766 139.73768880080212 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3805e9f7-fe82-47ef-800f-abbbd7318f66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3805e9f7-fe82-47ef-800f-abbbd7318f66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3805e9f7-fe82-47ef-800f-abbbd7318f66">
											<gml:posList>35.66679821724257 139.73769939653687 25.092 35.66679821724257 139.73769939653687 24.895 35.66677373516725 139.73772113065766 24.895 35.66677373516725 139.73772113065766 25.092 35.66679821724257 139.73769939653687 25.092</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7020a298-fd1c-4bf5-bbc9-620ec9f89f0b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7020a298-fd1c-4bf5-bbc9-620ec9f89f0b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7020a298-fd1c-4bf5-bbc9-620ec9f89f0b">
											<gml:posList>35.66675629795579 139.73773798518698 22.613 35.66675254187082 139.73774131443835 22.613 35.66675254187082 139.73774131443835 13.848 35.66681136011204 139.73768910829864 13.848 35.66681136011204 139.73768910829864 22.613 35.666799488379894 139.7376996490735 22.613 35.666799488379894 139.7376996490735 25.092 35.66677353809308 139.73772267729936 25.092 35.66675629795579 139.73773798518698 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ded09a1e-e46b-41e9-bf92-79ec092b7d25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ded09a1e-e46b-41e9-bf92-79ec092b7d25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ded09a1e-e46b-41e9-bf92-79ec092b7d25">
											<gml:posList>35.666755666153065 139.73773692554724 22.613 35.666755666153065 139.73773692554724 22.449 35.66675278378588 139.73773948055387 22.449 35.66675278378588 139.73773948055387 22.613 35.666755666153065 139.73773692554724 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ed2a4e5-4c0d-4ad6-afd2-a76d6fce3012">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ed2a4e5-4c0d-4ad6-afd2-a76d6fce3012">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ed2a4e5-4c0d-4ad6-afd2-a76d6fce3012">
											<gml:posList>35.6667094266393 139.73765867732521 22.613 35.6667094266393 139.73765867732521 22.449 35.666755666153065 139.73773692554724 22.449 35.666755666153065 139.73773692554724 22.613 35.6667094266393 139.73765867732521 22.613</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9293</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">97.4969</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>