<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_58fd68d2-b439-4242-a25d-d583abb059fc">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>永田町二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">3.7</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.673118496102504 139.74016462517642 0 35.67320857580606 139.74002045009257 0 35.673168345329906 139.73998270635119 0 35.6730782746846 139.7401268813944 0 35.673118496102504 139.74016462517642 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673118496102504 139.74016462517642 7.71 35.6730782746846 139.7401268813944 7.71 35.673168345329906 139.73998270635119 7.71 35.67320857580606 139.74002045009257 7.71 35.673118496102504 139.74016462517642 7.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673118496102504 139.74016462517642 7.71 35.67320857580606 139.74002045009257 7.71 35.67320857580606 139.74002045009257 11.39 35.673118496102504 139.74016462517642 11.39 35.673118496102504 139.74016462517642 7.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67320857580606 139.74002045009257 7.71 35.673168345329906 139.73998270635119 7.71 35.673168345329906 139.73998270635119 11.39 35.67320857580606 139.74002045009257 11.39 35.67320857580606 139.74002045009257 7.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673168345329906 139.73998270635119 7.71 35.6730782746846 139.7401268813944 7.71 35.6730782746846 139.7401268813944 11.39 35.673168345329906 139.73998270635119 11.39 35.673168345329906 139.73998270635119 7.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6730782746846 139.7401268813944 7.71 35.673118496102504 139.74016462517642 7.71 35.673118496102504 139.74016462517642 11.39 35.6730782746846 139.7401268813944 11.39 35.6730782746846 139.7401268813944 7.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673118496102504 139.74016462517642 11.39 35.67320857580606 139.74002045009257 11.39 35.673168345329906 139.73998270635119 11.39 35.6730782746846 139.7401268813944 11.39 35.673118496102504 139.74016462517642 11.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1b14d081-da29-4a27-85d2-b1832d22ef05"/>
							<gml:surfaceMember xlink:href="#poly-cc464cc1-2844-498f-9aa3-3f67bb05559c"/>
							<gml:surfaceMember xlink:href="#poly-be628a79-7ced-4064-b905-1ac5215ae128"/>
							<gml:surfaceMember xlink:href="#poly-4967ddf6-3d52-467e-a50f-787ab9886459"/>
							<gml:surfaceMember xlink:href="#poly-ab804c50-cadd-470a-8e51-33ba7e268288"/>
							<gml:surfaceMember xlink:href="#poly-8bad7ef6-e1f6-42d8-b3e8-36012bfcf79e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1b14d081-da29-4a27-85d2-b1832d22ef05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b14d081-da29-4a27-85d2-b1832d22ef05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b14d081-da29-4a27-85d2-b1832d22ef05">
											<gml:posList>35.67320857580605 139.74002045009257 7.71 35.67311849610249 139.74016462517642 7.71 35.67307827468458 139.7401268813944 7.71 35.673168345329884 139.73998270635119 7.71 35.67320857580605 139.74002045009257 7.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc464cc1-2844-498f-9aa3-3f67bb05559c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc464cc1-2844-498f-9aa3-3f67bb05559c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc464cc1-2844-498f-9aa3-3f67bb05559c">
											<gml:posList>35.67311849610249 139.74016462517642 10.972 35.67320857580605 139.74002045009257 10.972 35.673168345329884 139.73998270635119 10.972 35.67307827468458 139.7401268813944 10.972 35.67311849610249 139.74016462517642 10.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be628a79-7ced-4064-b905-1ac5215ae128">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be628a79-7ced-4064-b905-1ac5215ae128">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be628a79-7ced-4064-b905-1ac5215ae128">
											<gml:posList>35.67307827468458 139.7401268813944 7.71 35.67311849610249 139.74016462517642 7.71 35.67311849610249 139.74016462517642 10.972 35.67307827468458 139.7401268813944 10.972 35.67307827468458 139.7401268813944 7.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4967ddf6-3d52-467e-a50f-787ab9886459">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4967ddf6-3d52-467e-a50f-787ab9886459">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4967ddf6-3d52-467e-a50f-787ab9886459">
											<gml:posList>35.673168345329884 139.73998270635119 7.71 35.67307827468458 139.7401268813944 7.71 35.67307827468458 139.7401268813944 10.972 35.673168345329884 139.73998270635119 10.972 35.673168345329884 139.73998270635119 7.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab804c50-cadd-470a-8e51-33ba7e268288">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab804c50-cadd-470a-8e51-33ba7e268288">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab804c50-cadd-470a-8e51-33ba7e268288">
											<gml:posList>35.67311849610249 139.74016462517642 7.71 35.67320857580605 139.74002045009257 7.71 35.67320857580605 139.74002045009257 10.972 35.67311849610249 139.74016462517642 10.972 35.67311849610249 139.74016462517642 7.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8bad7ef6-e1f6-42d8-b3e8-36012bfcf79e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bad7ef6-e1f6-42d8-b3e8-36012bfcf79e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bad7ef6-e1f6-42d8-b3e8-36012bfcf79e">
											<gml:posList>35.67320857580605 139.74002045009257 7.71 35.673168345329884 139.73998270635119 7.71 35.673168345329884 139.73998270635119 10.972 35.67320857580605 139.74002045009257 10.972 35.67320857580605 139.74002045009257 7.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4529</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.33</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>