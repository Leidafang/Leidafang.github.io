<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5a7961e1-dd2e-49d8-93b6-d28d2d33a1cd">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>赤坂一丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.670038788601744 139.7440731616324 0 35.670045448951846 139.74404777001857 0 35.6700120703648 139.74403461801478 0 35.670005410009246 139.7440599985729 0 35.670038788601744 139.7440731616324 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670038788601744 139.7440731616324 9.031 35.670005410009246 139.7440599985729 9.031 35.6700120703648 139.74403461801478 9.031 35.670045448951846 139.74404777001857 9.031 35.670038788601744 139.7440731616324 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670038788601744 139.7440731616324 9.031 35.670045448951846 139.74404777001857 9.031 35.670045448951846 139.74404777001857 12.031 35.670038788601744 139.7440731616324 12.031 35.670038788601744 139.7440731616324 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670045448951846 139.74404777001857 9.031 35.6700120703648 139.74403461801478 9.031 35.6700120703648 139.74403461801478 12.031 35.670045448951846 139.74404777001857 12.031 35.670045448951846 139.74404777001857 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6700120703648 139.74403461801478 9.031 35.670005410009246 139.7440599985729 9.031 35.670005410009246 139.7440599985729 12.031 35.6700120703648 139.74403461801478 12.031 35.6700120703648 139.74403461801478 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670005410009246 139.7440599985729 9.031 35.670038788601744 139.7440731616324 9.031 35.670038788601744 139.7440731616324 12.031 35.670005410009246 139.7440599985729 12.031 35.670005410009246 139.7440599985729 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670038788601744 139.7440731616324 12.031 35.670045448951846 139.74404777001857 12.031 35.6700120703648 139.74403461801478 12.031 35.670005410009246 139.7440599985729 12.031 35.670038788601744 139.7440731616324 12.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4c325d4f-1c20-419b-945f-1a8f6b42cf68"/>
							<gml:surfaceMember xlink:href="#poly-8c259a6e-cd0b-4a31-b8ab-ca78a2f9fcda"/>
							<gml:surfaceMember xlink:href="#poly-f4c7719b-cc75-4456-b7b2-e11fb1bf8fe2"/>
							<gml:surfaceMember xlink:href="#poly-07efe6b5-5fdb-4a32-b75c-ca29cc627c30"/>
							<gml:surfaceMember xlink:href="#poly-e2d662a9-7ce8-46a0-b3a4-cc8f2502917a"/>
							<gml:surfaceMember xlink:href="#poly-ffe11966-f302-4763-b860-5291b52dc93a"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4c325d4f-1c20-419b-945f-1a8f6b42cf68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c325d4f-1c20-419b-945f-1a8f6b42cf68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c325d4f-1c20-419b-945f-1a8f6b42cf68">
											<gml:posList>35.67003878860172 139.7440731616324 9.031 35.670005410009196 139.7440599985729 9.031 35.670012070364784 139.74403461801478 9.031 35.67004544895184 139.74404777001857 9.031 35.67003878860172 139.7440731616324 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c259a6e-cd0b-4a31-b8ab-ca78a2f9fcda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c259a6e-cd0b-4a31-b8ab-ca78a2f9fcda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c259a6e-cd0b-4a31-b8ab-ca78a2f9fcda">
											<gml:posList>35.670005410009196 139.7440599985729 11.1 35.67003878860172 139.7440731616324 11.1 35.67004544895184 139.74404777001857 11.1 35.670012070364784 139.74403461801478 11.1 35.670005410009196 139.7440599985729 11.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f4c7719b-cc75-4456-b7b2-e11fb1bf8fe2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4c7719b-cc75-4456-b7b2-e11fb1bf8fe2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4c7719b-cc75-4456-b7b2-e11fb1bf8fe2">
											<gml:posList>35.67004544895184 139.74404777001857 9.031 35.670012070364784 139.74403461801478 9.031 35.670012070364784 139.74403461801478 11.1 35.67004544895184 139.74404777001857 11.1 35.67004544895184 139.74404777001857 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07efe6b5-5fdb-4a32-b75c-ca29cc627c30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07efe6b5-5fdb-4a32-b75c-ca29cc627c30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07efe6b5-5fdb-4a32-b75c-ca29cc627c30">
											<gml:posList>35.670012070364784 139.74403461801478 9.031 35.670005410009196 139.7440599985729 9.031 35.670005410009196 139.7440599985729 11.1 35.670012070364784 139.74403461801478 11.1 35.670012070364784 139.74403461801478 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2d662a9-7ce8-46a0-b3a4-cc8f2502917a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2d662a9-7ce8-46a0-b3a4-cc8f2502917a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2d662a9-7ce8-46a0-b3a4-cc8f2502917a">
											<gml:posList>35.67003878860172 139.7440731616324 9.031 35.67004544895184 139.74404777001857 9.031 35.67004544895184 139.74404777001857 11.1 35.67003878860172 139.7440731616324 11.1 35.67003878860172 139.7440731616324 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffe11966-f302-4763-b860-5291b52dc93a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffe11966-f302-4763-b860-5291b52dc93a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffe11966-f302-4763-b860-5291b52dc93a">
											<gml:posList>35.670005410009196 139.7440599985729 9.031 35.67003878860172 139.7440731616324 9.031 35.67003878860172 139.7440731616324 11.1 35.670005410009196 139.7440599985729 11.1 35.670005410009196 139.7440599985729 9.031</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6505</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>