<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5abb963c-104f-45e2-b39d-1f6e489b539c">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">5.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6708977867671 139.73819709276006 0 35.67082384697645 139.7382197039435 0 35.67082901387725 139.7382451043524 0 35.67090296267764 139.7382224821339 0 35.6708977867671 139.73819709276006 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708977867671 139.73819709276006 17.727 35.67090296267764 139.7382224821339 17.727 35.67082901387725 139.7382451043524 17.727 35.67082384697645 139.7382197039435 17.727 35.6708977867671 139.73819709276006 17.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708977867671 139.73819709276006 17.727 35.67082384697645 139.7382197039435 17.727 35.67082384697645 139.7382197039435 22.78 35.6708977867671 139.73819709276006 22.78 35.6708977867671 139.73819709276006 17.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67082384697645 139.7382197039435 17.727 35.67082901387725 139.7382451043524 17.727 35.67082901387725 139.7382451043524 22.78 35.67082384697645 139.7382197039435 22.78 35.67082384697645 139.7382197039435 17.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67082901387725 139.7382451043524 17.727 35.67090296267764 139.7382224821339 17.727 35.67090296267764 139.7382224821339 22.78 35.67082901387725 139.7382451043524 22.78 35.67082901387725 139.7382451043524 17.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67090296267764 139.7382224821339 17.727 35.6708977867671 139.73819709276006 17.727 35.6708977867671 139.73819709276006 22.78 35.67090296267764 139.7382224821339 22.78 35.67090296267764 139.7382224821339 17.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6708977867671 139.73819709276006 22.78 35.67082384697645 139.7382197039435 22.78 35.67082901387725 139.7382451043524 22.78 35.67090296267764 139.7382224821339 22.78 35.6708977867671 139.73819709276006 22.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-494affd8-f4b0-4993-80f8-b8526d2980d8"/>
							<gml:surfaceMember xlink:href="#poly-39c30d41-0589-4fa8-8399-d11692fca069"/>
							<gml:surfaceMember xlink:href="#poly-6a397e15-9853-4ee7-bb32-bb058f7c6d48"/>
							<gml:surfaceMember xlink:href="#poly-fdb838bb-f2d6-49e0-ba9b-6696d5c3e535"/>
							<gml:surfaceMember xlink:href="#poly-66086dbb-c85d-47d3-814a-49e49dcc4fd5"/>
							<gml:surfaceMember xlink:href="#poly-44098275-1882-4709-b1d5-398edb9b7476"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-494affd8-f4b0-4993-80f8-b8526d2980d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-494affd8-f4b0-4993-80f8-b8526d2980d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-494affd8-f4b0-4993-80f8-b8526d2980d8">
											<gml:posList>35.67089778676709 139.73819709276006 17.727 35.67090296267766 139.7382224821339 17.727 35.67082901387724 139.7382451043524 17.727 35.67082384697642 139.73821970394349 17.727 35.67089778676709 139.73819709276006 17.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-39c30d41-0589-4fa8-8399-d11692fca069">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39c30d41-0589-4fa8-8399-d11692fca069">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39c30d41-0589-4fa8-8399-d11692fca069">
											<gml:posList>35.67082901387724 139.7382451043524 20.781 35.67090296267766 139.7382224821339 20.781 35.67089778676709 139.73819709276006 20.781 35.67082384697642 139.73821970394349 20.781 35.67082901387724 139.7382451043524 20.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a397e15-9853-4ee7-bb32-bb058f7c6d48">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a397e15-9853-4ee7-bb32-bb058f7c6d48">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a397e15-9853-4ee7-bb32-bb058f7c6d48">
											<gml:posList>35.67089778676709 139.73819709276006 17.727 35.67082384697642 139.73821970394349 17.727 35.67082384697642 139.73821970394349 20.781 35.67089778676709 139.73819709276006 20.781 35.67089778676709 139.73819709276006 17.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fdb838bb-f2d6-49e0-ba9b-6696d5c3e535">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fdb838bb-f2d6-49e0-ba9b-6696d5c3e535">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fdb838bb-f2d6-49e0-ba9b-6696d5c3e535">
											<gml:posList>35.67090296267766 139.7382224821339 17.727 35.67089778676709 139.73819709276006 17.727 35.67089778676709 139.73819709276006 20.781 35.67090296267766 139.7382224821339 20.781 35.67090296267766 139.7382224821339 17.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66086dbb-c85d-47d3-814a-49e49dcc4fd5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66086dbb-c85d-47d3-814a-49e49dcc4fd5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66086dbb-c85d-47d3-814a-49e49dcc4fd5">
											<gml:posList>35.67082384697642 139.73821970394349 17.727 35.67082901387724 139.7382451043524 17.727 35.67082901387724 139.7382451043524 20.781 35.67082384697642 139.73821970394349 20.781 35.67082384697642 139.73821970394349 17.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-44098275-1882-4709-b1d5-398edb9b7476">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44098275-1882-4709-b1d5-398edb9b7476">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44098275-1882-4709-b1d5-398edb9b7476">
											<gml:posList>35.67082901387724 139.7382451043524 17.727 35.67090296267766 139.7382224821339 17.727 35.67090296267766 139.7382224821339 20.781 35.67082901387724 139.7382451043524 20.781 35.67082901387724 139.7382451043524 17.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3397</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>