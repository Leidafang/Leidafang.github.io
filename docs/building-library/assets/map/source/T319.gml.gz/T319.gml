<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5b3fe8f5-5e47-436f-84be-ebc2353f056b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">62</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67234288941732 139.73928024658488 0 35.67233538853853 139.7392899210971 0 35.672362800769996 139.73932645296443 0 35.672492638879824 139.73919360955657 0 35.67236151876509 139.7390011119984 0 35.67226557767263 139.73907148074636 0 35.67221379019561 139.73912445442744 0 35.67232472335852 139.73928743709249 0 35.67233706054022 139.73927255399232 0 35.67234288941732 139.73928024658488 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234288941732 139.73928024658488 9.08 35.67233706054022 139.73927255399232 9.08 35.67232472335852 139.73928743709249 9.08 35.67221379019561 139.73912445442744 9.08 35.67226557767263 139.73907148074636 9.08 35.67236151876509 139.7390011119984 9.08 35.672492638879824 139.73919360955657 9.08 35.672362800769996 139.73932645296443 9.08 35.67233538853853 139.7392899210971 9.08 35.67234288941732 139.73928024658488 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234288941732 139.73928024658488 9.08 35.67233538853853 139.7392899210971 9.08 35.67233538853853 139.7392899210971 65.63 35.67234288941732 139.73928024658488 65.63 35.67234288941732 139.73928024658488 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67233538853853 139.7392899210971 9.08 35.672362800769996 139.73932645296443 9.08 35.672362800769996 139.73932645296443 65.63 35.67233538853853 139.7392899210971 65.63 35.67233538853853 139.7392899210971 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672362800769996 139.73932645296443 9.08 35.672492638879824 139.73919360955657 9.08 35.672492638879824 139.73919360955657 65.63 35.672362800769996 139.73932645296443 65.63 35.672362800769996 139.73932645296443 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672492638879824 139.73919360955657 9.08 35.67236151876509 139.7390011119984 9.08 35.67236151876509 139.7390011119984 65.63 35.672492638879824 139.73919360955657 65.63 35.672492638879824 139.73919360955657 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67236151876509 139.7390011119984 9.08 35.67226557767263 139.73907148074636 9.08 35.67226557767263 139.73907148074636 65.63 35.67236151876509 139.7390011119984 65.63 35.67236151876509 139.7390011119984 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67226557767263 139.73907148074636 9.08 35.67221379019561 139.73912445442744 9.08 35.67221379019561 139.73912445442744 65.63 35.67226557767263 139.73907148074636 65.63 35.67226557767263 139.73907148074636 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67221379019561 139.73912445442744 9.08 35.67232472335852 139.73928743709249 9.08 35.67232472335852 139.73928743709249 65.63 35.67221379019561 139.73912445442744 65.63 35.67221379019561 139.73912445442744 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67232472335852 139.73928743709249 9.08 35.67233706054022 139.73927255399232 9.08 35.67233706054022 139.73927255399232 65.63 35.67232472335852 139.73928743709249 65.63 35.67232472335852 139.73928743709249 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67233706054022 139.73927255399232 9.08 35.67234288941732 139.73928024658488 9.08 35.67234288941732 139.73928024658488 65.63 35.67233706054022 139.73927255399232 65.63 35.67233706054022 139.73927255399232 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67234288941732 139.73928024658488 65.63 35.67233538853853 139.7392899210971 65.63 35.672362800769996 139.73932645296443 65.63 35.672492638879824 139.73919360955657 65.63 35.67236151876509 139.7390011119984 65.63 35.67226557767263 139.73907148074636 65.63 35.67221379019561 139.73912445442744 65.63 35.67232472335852 139.73928743709249 65.63 35.67233706054022 139.73927255399232 65.63 35.67234288941732 139.73928024658488 65.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8843f8ff-8716-426b-a71c-680418f23e38"/>
							<gml:surfaceMember xlink:href="#poly-d957686d-2c6b-488a-bd40-fb9d1eb1633a"/>
							<gml:surfaceMember xlink:href="#poly-4e0f6f40-bf93-4eab-9ca0-f791dda44f24"/>
							<gml:surfaceMember xlink:href="#poly-c67e78a5-db3e-45b7-8165-9ec703901d80"/>
							<gml:surfaceMember xlink:href="#poly-1cadfaf4-0ae4-46a7-97b6-e8c0e4102bef"/>
							<gml:surfaceMember xlink:href="#poly-55f90cdc-066b-4033-9992-54eb34a27541"/>
							<gml:surfaceMember xlink:href="#poly-1bc87b85-e818-468a-87c0-e6010738eb87"/>
							<gml:surfaceMember xlink:href="#poly-eafdb9d9-db75-42be-b0fa-fb3b705bb4d5"/>
							<gml:surfaceMember xlink:href="#poly-67d7ca66-932f-4d0c-b5f6-3b5410edd333"/>
							<gml:surfaceMember xlink:href="#poly-3d7e0c5b-0432-4f50-9723-78c781817201"/>
							<gml:surfaceMember xlink:href="#poly-fa34a86a-81ae-4fb7-ae2a-923797ba8918"/>
							<gml:surfaceMember xlink:href="#poly-879d63ba-1c8d-4772-8862-0677def665f3"/>
							<gml:surfaceMember xlink:href="#poly-ee9b7bd6-7b01-4013-ad42-fe17ff67aeef"/>
							<gml:surfaceMember xlink:href="#poly-673f2e3e-b722-4cd0-b298-e13f5e66593d"/>
							<gml:surfaceMember xlink:href="#poly-afa13a2a-7d36-40cc-b702-f50c6d888ca1"/>
							<gml:surfaceMember xlink:href="#poly-94adc736-7048-4f52-9f10-81129fba43d5"/>
							<gml:surfaceMember xlink:href="#poly-38ccba6c-06ea-45ad-9aac-f5319079b2ab"/>
							<gml:surfaceMember xlink:href="#poly-afab427c-7418-4175-ba08-c6252da7d391"/>
							<gml:surfaceMember xlink:href="#poly-aac1b36a-b140-4f52-befc-33570cad280c"/>
							<gml:surfaceMember xlink:href="#poly-332353b6-3745-4cf8-9e55-df5e0690e33b"/>
							<gml:surfaceMember xlink:href="#poly-86062ffd-866f-4ac8-a810-4cb13a76fc3e"/>
							<gml:surfaceMember xlink:href="#poly-4e84accf-9fb5-4a02-a556-62ee4543edbf"/>
							<gml:surfaceMember xlink:href="#poly-dffe9d9e-364b-42e3-927a-c0dfc6ea9688"/>
							<gml:surfaceMember xlink:href="#poly-ffacf9f5-1c58-4853-93f7-543a279bae92"/>
							<gml:surfaceMember xlink:href="#poly-ce0c6c92-62db-4025-9c22-ab21285af60d"/>
							<gml:surfaceMember xlink:href="#poly-9b56258c-01f2-40fe-bb31-35951ea14917"/>
							<gml:surfaceMember xlink:href="#poly-699cfa70-3795-4e1c-99aa-f4e121a8676f"/>
							<gml:surfaceMember xlink:href="#poly-7c3b8686-5fd8-4a36-84ae-6da7b3cf861d"/>
							<gml:surfaceMember xlink:href="#poly-8333ff32-fddb-4de7-99a1-d996da5bf7f7"/>
							<gml:surfaceMember xlink:href="#poly-b046feba-9026-4cb9-b29b-faa531b5541e"/>
							<gml:surfaceMember xlink:href="#poly-dd181a58-bd66-4357-a1ed-5a3da9c4be23"/>
							<gml:surfaceMember xlink:href="#poly-cb7c6313-5fc5-46a1-9aaa-8b0e2e71f507"/>
							<gml:surfaceMember xlink:href="#poly-b281fc77-8802-4555-bc06-8399617a9b41"/>
							<gml:surfaceMember xlink:href="#poly-12676edb-4f99-4f58-885b-d73dd32fb996"/>
							<gml:surfaceMember xlink:href="#poly-28ce6248-01a8-4970-a622-8b9487f29f4b"/>
							<gml:surfaceMember xlink:href="#poly-cf2c4b69-f200-43ce-abfc-9a5ec4eafcb0"/>
							<gml:surfaceMember xlink:href="#poly-3cff4a04-2972-44bf-ad2b-f9eaf4dc44fd"/>
							<gml:surfaceMember xlink:href="#poly-f684367c-c347-4ded-aacd-f26557d9827e"/>
							<gml:surfaceMember xlink:href="#poly-5b1468e3-49ad-401b-b96d-db89be014e8a"/>
							<gml:surfaceMember xlink:href="#poly-9676b984-a3ba-4297-b3f8-f330fdb416d3"/>
							<gml:surfaceMember xlink:href="#poly-8abb9d01-0439-4513-995f-919b07b22188"/>
							<gml:surfaceMember xlink:href="#poly-6890a96d-2602-446f-84f8-1c505c519187"/>
							<gml:surfaceMember xlink:href="#poly-a20ab449-9adc-498c-b3d9-c527ccc7386e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5b3fe8f5-5e47-436f-84be-ebc2353f056b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa6eb805-b69f-49d5-aaa2-efa9efb393b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672358525338986 139.73913816984154 75.036 35.67237178073261 139.73915635895509 75.036 35.67235914528334 139.7391701819628 75.036 35.67234588990042 139.73915200389635 75.036 35.672358525338986 139.73913816984154 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1412a615-727d-4a42-8d23-6f00e9ed56ea">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67241174672332 139.73916676203342 75.036 35.67239812010932 139.7391810280719 75.036 35.67238038825574 139.73915560872607 75.036 35.67239400584439 139.73914133165047 75.036 35.67241174672332 139.73916676203342 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-944acb5e-a329-49ae-a1b0-fb8967df6a54">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67232552064827 139.7392003784752 75.036 35.672302302885335 139.73916784058292 75.036 35.672314560293934 139.73915470291334 75.036 35.672337778060374 139.73918724080676 75.036 35.67232552064827 139.7392003784752 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d19073c-10bf-403c-8def-0544c31bbd51">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67236991946662 139.73919679145394 75.036 35.672348926309525 139.73921961614292 75.036 35.6723360317678 139.73920180218238 75.036 35.67235702492155 139.73917897749243 75.036 35.67236991946662 139.73919679145394 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1da2b2a-7929-429a-a63e-1fdf83714126">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672313273119265 139.7392030992543 75.036 35.672318786537865 139.73921081430294 75.036 35.67230521421656 139.73922535641674 75.036 35.6722997098126 139.73921764135784 75.036 35.672313273119265 139.7392030992543 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a5a046a-fcd1-4ee3-a964-7bf0a0f6cbd8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672322631632156 139.7392175260771 75.036 35.67233436303922 139.7392348774482 75.036 35.67232329395688 139.7392461247581 75.036 35.6723115535377 139.73922877339834 75.036 35.672322631632156 139.7392175260771 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73700d33-dbc9-4581-a667-0347c894f68b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73700d33-dbc9-4581-a667-0347c894f68b_0">
											<gml:posList>35.67234588990042 139.73915200389635 75.036 35.67234588990042 139.73915200389635 75.968 35.672358525338986 139.73913816984154 75.968 35.672358525338986 139.73913816984154 75.036 35.67234588990042 139.73915200389635 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0200cb5c-29ca-47fc-ae11-b772097baa4c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0200cb5c-29ca-47fc-ae11-b772097baa4c_0">
											<gml:posList>35.67234588990042 139.73915200389635 75.036 35.67235914528334 139.7391701819628 75.036 35.67235914528334 139.7391701819628 75.968 35.67234588990042 139.73915200389635 75.968 35.67234588990042 139.73915200389635 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7a133035-66fd-4840-bd4b-0c279fcd2688">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7a133035-66fd-4840-bd4b-0c279fcd2688_0">
											<gml:posList>35.67236991946662 139.73919679145394 77.415 35.67235702492155 139.73917897749243 77.415 35.6723360317678 139.73920180218238 77.415 35.672348926309525 139.73921961614292 77.415 35.67236991946662 139.73919679145394 77.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b3239d2-9175-4bed-9f4a-de9e33382855">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b3239d2-9175-4bed-9f4a-de9e33382855_0">
											<gml:posList>35.67235914528334 139.7391701819628 75.968 35.67237178073261 139.73915635895509 75.968 35.672358525338986 139.73913816984154 75.968 35.67234588990042 139.73915200389635 75.968 35.67235914528334 139.7391701819628 75.968</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99115956-3815-4684-88a0-98bbbfba85b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99115956-3815-4684-88a0-98bbbfba85b5_0">
											<gml:posList>35.672348926309525 139.73921961614292 75.036 35.67236991946662 139.73919679145394 75.036 35.67236991946662 139.73919679145394 77.415 35.672348926309525 139.73921961614292 77.415 35.672348926309525 139.73921961614292 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-780a8321-0145-4862-ad4d-78329e99c276">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-780a8321-0145-4862-ad4d-78329e99c276_0">
											<gml:posList>35.67235702492155 139.73917897749243 77.415 35.67236991946662 139.73919679145394 77.415 35.67236991946662 139.73919679145394 75.036 35.67235702492155 139.73917897749243 75.036 35.67235702492155 139.73917897749243 77.415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fd8a183-720e-420a-ad42-ed0cf0f6410a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fd8a183-720e-420a-ad42-ed0cf0f6410a_0">
											<gml:posList>35.672358525338986 139.73913816984154 75.036 35.672358525338986 139.73913816984154 75.968 35.67237178073261 139.73915635895509 75.968 35.67237178073261 139.73915635895509 75.036 35.672358525338986 139.73913816984154 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb9cc800-2891-4fc1-b5dd-157f8bff3ea4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cb9cc800-2891-4fc1-b5dd-157f8bff3ea4_0">
											<gml:posList>35.67235914528334 139.7391701819628 75.036 35.67237178073261 139.73915635895509 75.036 35.67237178073261 139.73915635895509 75.968 35.67235914528334 139.7391701819628 75.968 35.67235914528334 139.7391701819628 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99ff015c-22fa-4902-8fc5-332a50a0d5ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99ff015c-22fa-4902-8fc5-332a50a0d5ec_0">
											<gml:posList>35.67238038825574 139.73915560872607 75.036 35.67238038825574 139.73915560872607 77.871 35.67239400584439 139.73914133165047 77.871 35.67239400584439 139.73914133165047 75.036 35.67238038825574 139.73915560872607 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e497cc64-d305-4df8-b0ca-e509d98a4592">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e497cc64-d305-4df8-b0ca-e509d98a4592_0">
											<gml:posList>35.67238038825574 139.73915560872607 75.036 35.67239812010932 139.7391810280719 75.036 35.67239812010932 139.7391810280719 77.871 35.67238038825574 139.73915560872607 77.871 35.67238038825574 139.73915560872607 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d77fc061-b80d-4fde-b47a-4b3c5415abe7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d77fc061-b80d-4fde-b47a-4b3c5415abe7_0">
											<gml:posList>35.67238038825574 139.73915560872607 77.871 35.67239812010932 139.7391810280719 77.871 35.67241174672332 139.73916676203342 77.871 35.67239400584439 139.73914133165047 77.871 35.67238038825574 139.73915560872607 77.871</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-43b591d8-c705-415d-a64a-5d9678fb8672">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-43b591d8-c705-415d-a64a-5d9678fb8672_0">
											<gml:posList>35.67241174672332 139.73916676203342 75.036 35.67239400584439 139.73914133165047 75.036 35.67239400584439 139.73914133165047 77.871 35.67241174672332 139.73916676203342 77.871 35.67241174672332 139.73916676203342 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e7dafa0-1e2d-4552-95a8-1a73156a3be7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e7dafa0-1e2d-4552-95a8-1a73156a3be7_0">
											<gml:posList>35.67239812010932 139.7391810280719 75.036 35.67241174672332 139.73916676203342 75.036 35.67241174672332 139.73916676203342 77.871 35.67239812010932 139.7391810280719 77.871 35.67239812010932 139.7391810280719 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ec64018-cda0-466f-9f22-4eb091fd8422">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ec64018-cda0-466f-9f22-4eb091fd8422_0">
											<gml:posList>35.67230521421656 139.73922535641674 75.036 35.67230521421656 139.73922535641674 76.564 35.6722997098126 139.73921764135784 76.564 35.6722997098126 139.73921764135784 75.036 35.67230521421656 139.73922535641674 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f27ad9e8-c646-4ec4-bed4-119d3b39725d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f27ad9e8-c646-4ec4-bed4-119d3b39725d_0">
											<gml:posList>35.672313273119265 139.7392030992543 76.564 35.672313273119265 139.7392030992543 75.036 35.6722997098126 139.73921764135784 75.036 35.6722997098126 139.73921764135784 76.564 35.672313273119265 139.7392030992543 76.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96ac69a3-ce08-4d19-b998-073fae9766ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96ac69a3-ce08-4d19-b998-073fae9766ac_0">
											<gml:posList>35.672302302885335 139.73916784058292 75.036 35.672302302885335 139.73916784058292 76.064 35.672314560293934 139.73915470291334 76.064 35.672314560293934 139.73915470291334 75.036 35.672302302885335 139.73916784058292 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-afaf9495-3207-4b6d-a12f-07a1c785a2cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-afaf9495-3207-4b6d-a12f-07a1c785a2cb_0">
											<gml:posList>35.672313273119265 139.7392030992543 76.564 35.6722997098126 139.73921764135784 76.564 35.67230521421656 139.73922535641674 76.564 35.672318786537865 139.73921081430294 76.564 35.672313273119265 139.7392030992543 76.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11a89c35-f132-4423-9aba-8e6959d29b8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-11a89c35-f132-4423-9aba-8e6959d29b8b_0">
											<gml:posList>35.67230521421656 139.73922535641674 75.036 35.672318786537865 139.73921081430294 75.036 35.672318786537865 139.73921081430294 76.564 35.67230521421656 139.73922535641674 76.564 35.67230521421656 139.73922535641674 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d47ba4b3-a999-4474-a66a-9780ce632f0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d47ba4b3-a999-4474-a66a-9780ce632f0f_0">
											<gml:posList>35.67232552064827 139.7392003784752 75.036 35.67232552064827 139.7392003784752 76.064 35.672302302885335 139.73916784058292 76.064 35.672302302885335 139.73916784058292 75.036 35.67232552064827 139.7392003784752 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50f6e181-c352-48d9-abfe-8472219aa85e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50f6e181-c352-48d9-abfe-8472219aa85e_0">
											<gml:posList>35.672313273119265 139.7392030992543 76.564 35.672318786537865 139.73921081430294 76.564 35.672318786537865 139.73921081430294 75.036 35.672313273119265 139.7392030992543 75.036 35.672313273119265 139.7392030992543 76.564</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2bed76a-78d0-4687-aafc-8a492dcc551f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2bed76a-78d0-4687-aafc-8a492dcc551f_0">
											<gml:posList>35.672322631632156 139.7392175260771 75.036 35.6723115535377 139.73922877339834 75.036 35.6723115535377 139.73922877339834 77.129 35.672322631632156 139.7392175260771 77.129 35.672322631632156 139.7392175260771 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13f18cf0-8c8a-408c-a4b7-61832ebb426d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13f18cf0-8c8a-408c-a4b7-61832ebb426d_0">
											<gml:posList>35.6723115535377 139.73922877339834 75.036 35.67232329395688 139.7392461247581 75.036 35.67232329395688 139.7392461247581 77.129 35.6723115535377 139.73922877339834 77.129 35.6723115535377 139.73922877339834 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e64fb67b-0175-47ad-9d26-5651a0bccfab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e64fb67b-0175-47ad-9d26-5651a0bccfab_0">
											<gml:posList>35.672314560293934 139.73915470291334 76.064 35.672302302885335 139.73916784058292 76.064 35.67232552064827 139.7392003784752 76.064 35.672337778060374 139.73918724080676 76.064 35.672314560293934 139.73915470291334 76.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-056f4672-7113-4a0c-b49c-ffc4a03339d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-056f4672-7113-4a0c-b49c-ffc4a03339d7_0">
											<gml:posList>35.67232329395688 139.7392461247581 77.129 35.67233436303922 139.7392348774482 77.129 35.672322631632156 139.7392175260771 77.129 35.6723115535377 139.73922877339834 77.129 35.67232329395688 139.7392461247581 77.129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8101cb7-b36d-40b9-9876-79154cb62da6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8101cb7-b36d-40b9-9876-79154cb62da6_0">
											<gml:posList>35.672314560293934 139.73915470291334 76.064 35.672337778060374 139.73918724080676 76.064 35.672337778060374 139.73918724080676 75.036 35.672314560293934 139.73915470291334 75.036 35.672314560293934 139.73915470291334 76.064</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71ab3a5a-22fa-4121-b4b1-d8bb2bd62a32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71ab3a5a-22fa-4121-b4b1-d8bb2bd62a32_0">
											<gml:posList>35.67233436303922 139.7392348774482 75.036 35.672322631632156 139.7392175260771 75.036 35.672322631632156 139.7392175260771 77.129 35.67233436303922 139.7392348774482 77.129 35.67233436303922 139.7392348774482 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac4b1c22-ee43-443e-8af1-3c5de5257ec3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac4b1c22-ee43-443e-8af1-3c5de5257ec3_0">
											<gml:posList>35.67233436303922 139.7392348774482 75.036 35.67233436303922 139.7392348774482 77.129 35.67232329395688 139.7392461247581 77.129 35.67232329395688 139.7392461247581 75.036 35.67233436303922 139.7392348774482 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1afbdc9d-088e-44d1-8c44-47206bedeb15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1afbdc9d-088e-44d1-8c44-47206bedeb15_0">
											<gml:posList>35.67232552064827 139.7392003784752 75.036 35.672337778060374 139.73918724080676 75.036 35.672337778060374 139.73918724080676 76.064 35.67232552064827 139.7392003784752 76.064 35.67232552064827 139.7392003784752 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e359228-6ded-4978-a051-156d01c97194">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e359228-6ded-4978-a051-156d01c97194_0">
											<gml:posList>35.6723360317678 139.73920180218238 75.036 35.672348926309525 139.73921961614292 75.036 35.672348926309525 139.73921961614292 77.415 35.6723360317678 139.73920180218238 77.415 35.6723360317678 139.73920180218238 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6dc1bcf-bb36-48da-8513-0ff54011d00e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6dc1bcf-bb36-48da-8513-0ff54011d00e_0">
											<gml:posList>35.6723360317678 139.73920180218238 75.036 35.6723360317678 139.73920180218238 77.415 35.67235702492155 139.73917897749243 77.415 35.67235702492155 139.73917897749243 75.036 35.6723360317678 139.73920180218238 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5b3fe8f5-5e47-436f-84be-ebc2353f056b_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a630c2c-b57c-4848-8d3b-a80a18179c31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67233145818678 139.7392087005859 75.036 35.67232535199676 139.73921524729897 75.036 35.67229168489655 139.7391680739847 75.036 35.67229779108404 139.7391615272708 75.036 35.67233145818678 139.7392087005859 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e7ccec50-28b6-4fef-b0f2-ba786a7ba21a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67232472335852 139.73928743709249 9.34 35.67233706054023 139.73927255399232 9.34 35.672342889417294 139.73928024658488 9.34 35.67233538853853 139.7392899210971 9.34 35.67236280077 139.7393264529644 9.34 35.67235600984138 139.73933339814909 9.34 35.67232472335852 139.73928743709249 9.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a226ed3-a79f-4d8e-8e3d-a7964ca7c40f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a226ed3-a79f-4d8e-8e3d-a7964ca7c40f_0">
											<gml:posList>35.67229779108404 139.7391615272708 75.347 35.67229779108404 139.7391615272708 75.036 35.67229168489655 139.7391680739847 75.036 35.67229168489655 139.7391680739847 75.347 35.67229779108404 139.7391615272708 75.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-473bd245-9ba0-43f7-8c4a-4dd010f217ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-473bd245-9ba0-43f7-8c4a-4dd010f217ef_0">
											<gml:posList>35.67233145818678 139.7392087005859 75.347 35.67233145818678 139.7392087005859 75.036 35.67229779108404 139.7391615272708 75.036 35.67229779108404 139.7391615272708 75.347 35.67233145818678 139.7392087005859 75.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a928d1c9-c7b0-4086-b270-d4d1bc3aa3a8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a928d1c9-c7b0-4086-b270-d4d1bc3aa3a8_0">
											<gml:posList>35.67233145818678 139.7392087005859 75.347 35.67229779108404 139.7391615272708 75.347 35.67229168489655 139.7391680739847 75.347 35.67232535199676 139.73921524729897 75.347 35.67233145818678 139.7392087005859 75.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94598b3e-02ba-43f0-ba34-48d8039238bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94598b3e-02ba-43f0-ba34-48d8039238bf_0">
											<gml:posList>35.67232535199676 139.73921524729897 75.036 35.67232535199676 139.73921524729897 75.347 35.67229168489655 139.7391680739847 75.347 35.67229168489655 139.7391680739847 75.036 35.67232535199676 139.73921524729897 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-991e3a8d-cea9-403e-9e45-37283c17215a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-991e3a8d-cea9-403e-9e45-37283c17215a_0">
											<gml:posList>35.67232535199676 139.73921524729897 75.347 35.67232535199676 139.73921524729897 75.036 35.67233145818678 139.7392087005859 75.036 35.67233145818678 139.7392087005859 75.347 35.67232535199676 139.73921524729897 75.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2c41778-7eec-4e34-8b3d-1c23457104d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2c41778-7eec-4e34-8b3d-1c23457104d2_0">
											<gml:posList>35.672342889417294 139.73928024658488 75.631 35.672342889417294 139.73928024658488 9.34 35.67233706054023 139.73927255399232 9.34 35.67233706054023 139.73927255399232 75.631 35.672342889417294 139.73928024658488 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71403b18-22f8-44a6-8237-779a9775500e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71403b18-22f8-44a6-8237-779a9775500e_0">
											<gml:posList>35.67233706054023 139.73927255399232 75.631 35.67233706054023 139.73927255399232 9.34 35.67232472335852 139.73928743709249 9.34 35.67232472335852 139.73928743709249 75.631 35.67233706054023 139.73927255399232 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b517c04f-1878-4fe6-a43b-22aefddb98df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b517c04f-1878-4fe6-a43b-22aefddb98df_0">
											<gml:posList>35.67233538853853 139.7392899210971 75.631 35.67233538853853 139.7392899210971 9.34 35.672342889417294 139.73928024658488 9.34 35.672342889417294 139.73928024658488 75.631 35.67233538853853 139.7392899210971 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0fa07c28-ffca-48d7-aaa2-4c684578fe27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0fa07c28-ffca-48d7-aaa2-4c684578fe27_0">
											<gml:posList>35.67232472335852 139.73928743709249 75.631 35.67235600984138 139.73933339814909 75.631 35.67236280077 139.7393264529644 75.631 35.67233538853853 139.7392899210971 75.631 35.672342889417294 139.73928024658488 75.631 35.67233706054023 139.73927255399232 75.631 35.67232472335852 139.73928743709249 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1cd4fce-ab4f-45a4-a486-872b10c09934">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1cd4fce-ab4f-45a4-a486-872b10c09934_0">
											<gml:posList>35.67236280077 139.7393264529644 75.631 35.67236280077 139.7393264529644 9.34 35.67233538853853 139.7392899210971 9.34 35.67233538853853 139.7392899210971 75.631 35.67236280077 139.7393264529644 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00ab4368-5700-42ff-885d-e74e15d5c9c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00ab4368-5700-42ff-885d-e74e15d5c9c3_0">
											<gml:posList>35.67232472335852 139.73928743709249 75.631 35.67232472335852 139.73928743709249 9.34 35.67235600984138 139.73933339814909 9.34 35.67235600984138 139.73933339814909 75.631 35.67232472335852 139.73928743709249 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6662b46a-72d5-4842-89a2-41f97ae9947f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6662b46a-72d5-4842-89a2-41f97ae9947f_0">
											<gml:posList>35.67235600984138 139.73933339814909 75.631 35.67235600984138 139.73933339814909 9.34 35.67236280077 139.7393264529644 9.34 35.67236280077 139.7393264529644 75.631 35.67235600984138 139.73933339814909 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8843f8ff-8716-426b-a71c-680418f23e38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8843f8ff-8716-426b-a71c-680418f23e38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8843f8ff-8716-426b-a71c-680418f23e38">
											<gml:posList>35.67236280077 139.7393264529644 9.08 35.67233538853853 139.7392899210971 9.08 35.672342889417294 139.73928024658488 9.08 35.67233706054023 139.73927255399232 9.08 35.67232472335852 139.73928743709249 9.08 35.67221379019562 139.7391244544274 9.08 35.672265577672626 139.73907148074636 9.08 35.67236151876508 139.7390011119984 9.08 35.672492638879824 139.73919360955654 9.08 35.67236280077 139.7393264529644 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d957686d-2c6b-488a-bd40-fb9d1eb1633a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d957686d-2c6b-488a-bd40-fb9d1eb1633a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d957686d-2c6b-488a-bd40-fb9d1eb1633a">
											<gml:posList>35.672265577672626 139.73907148074636 75.631 35.67221379019562 139.7391244544274 75.631 35.67222371518245 139.73912556950907 75.631 35.67226981054623 139.73907842403042 75.631 35.672265577672626 139.73907148074636 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e0f6f40-bf93-4eab-9ca0-f791dda44f24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e0f6f40-bf93-4eab-9ca0-f791dda44f24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e0f6f40-bf93-4eab-9ca0-f791dda44f24">
											<gml:posList>35.67232472335852 139.73928743709249 75.631 35.67232522719198 139.73927469985549 75.631 35.67229200952327 139.73922589110336 75.631 35.67228889338358 139.73922923081088 75.631 35.67226359116184 139.73919375699862 75.631 35.672267373763056 139.73918970953093 75.631 35.67222371518245 139.73912556950907 75.631 35.67221379019562 139.7391244544274 75.631 35.67232472335852 139.73928743709249 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c67e78a5-db3e-45b7-8165-9ec703901d80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c67e78a5-db3e-45b7-8165-9ec703901d80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c67e78a5-db3e-45b7-8165-9ec703901d80">
											<gml:posList>35.67226952257793 139.73919424712722 80.208 35.67226359116184 139.73919375699862 80.208 35.67228889338358 139.73922923081088 80.208 35.67228930233384 139.73922196171912 80.208 35.67226952257793 139.73919424712722 80.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1cadfaf4-0ae4-46a7-97b6-e8c0e4102bef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cadfaf4-0ae4-46a7-97b6-e8c0e4102bef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cadfaf4-0ae4-46a7-97b6-e8c0e4102bef">
											<gml:posList>35.67228989821043 139.73916555747613 80.208 35.67226359116184 139.73919375699862 80.208 35.67226952257793 139.73919424712722 80.208 35.67228949827729 139.7391728265576 80.208 35.67228989821043 139.73916555747613 80.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55f90cdc-066b-4033-9992-54eb34a27541">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55f90cdc-066b-4033-9992-54eb34a27541">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55f90cdc-066b-4033-9992-54eb34a27541">
											<gml:posList>35.67228949827729 139.7391728265576 80.11 35.67226952257793 139.73919424712722 80.11 35.67228930233384 139.73922196171912 80.11 35.67230928705178 139.73920054114055 80.11 35.67228949827729 139.7391728265576 80.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1bc87b85-e818-468a-87c0-e6010738eb87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1bc87b85-e818-468a-87c0-e6010738eb87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1bc87b85-e818-468a-87c0-e6010738eb87">
											<gml:posList>35.67228930233384 139.73922196171912 80.208 35.67228889338358 139.73922923081088 80.208 35.67231520945409 139.7392010312805 80.208 35.67230928705178 139.73920054114055 80.208 35.67228930233384 139.73922196171912 80.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eafdb9d9-db75-42be-b0fa-fb3b705bb4d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eafdb9d9-db75-42be-b0fa-fb3b705bb4d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eafdb9d9-db75-42be-b0fa-fb3b705bb4d5">
											<gml:posList>35.67228949827729 139.7391728265576 80.208 35.67230928705178 139.73920054114055 80.208 35.67231520945409 139.7392010312805 80.208 35.67228989821043 139.73916555747613 80.208 35.67228949827729 139.7391728265576 80.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67d7ca66-932f-4d0c-b5f6-3b5410edd333">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67d7ca66-932f-4d0c-b5f6-3b5410edd333">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67d7ca66-932f-4d0c-b5f6-3b5410edd333">
											<gml:posList>35.672265577672626 139.73907148074636 75.631 35.67226981054623 139.73907842403042 75.631 35.67235995916996 139.73901233711004 75.631 35.67236151876508 139.7390011119984 75.631 35.672265577672626 139.73907148074636 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3d7e0c5b-0432-4f50-9723-78c781817201">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d7e0c5b-0432-4f50-9723-78c781817201">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d7e0c5b-0432-4f50-9723-78c781817201">
											<gml:posList>35.67232472335852 139.73928743709249 75.631 35.67233706054023 139.73927255399232 75.631 35.672337276192 139.7392601484873 75.631 35.67232522719198 139.73927469985549 75.631 35.67232472335852 139.73928743709249 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa34a86a-81ae-4fb7-ae2a-923797ba8918">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa34a86a-81ae-4fb7-ae2a-923797ba8918">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa34a86a-81ae-4fb7-ae2a-923797ba8918">
											<gml:posList>35.672345033304616 139.73929002024886 75.631 35.67235255218494 139.73928031257475 75.631 35.672342889417294 139.73928024658488 75.631 35.67233538853853 139.7392899210971 75.631 35.672345033304616 139.73929002024886 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-879d63ba-1c8d-4772-8862-0677def665f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-879d63ba-1c8d-4772-8862-0677def665f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-879d63ba-1c8d-4772-8862-0677def665f3">
											<gml:posList>35.67235255218494 139.73928031257475 75.631 35.672337276192 139.7392601484873 75.631 35.67233706054023 139.73927255399232 75.631 35.672342889417294 139.73928024658488 75.631 35.67235255218494 139.73928031257475 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee9b7bd6-7b01-4013-ad42-fe17ff67aeef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee9b7bd6-7b01-4013-ad42-fe17ff67aeef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee9b7bd6-7b01-4013-ad42-fe17ff67aeef">
											<gml:posList>35.67236343144655 139.73931454406278 75.631 35.672345033304616 139.73929002024886 75.631 35.67233538853853 139.7392899210971 75.631 35.67236280077 139.7393264529644 75.631 35.67236343144655 139.73931454406278 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-673f2e3e-b722-4cd0-b298-e13f5e66593d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-673f2e3e-b722-4cd0-b298-e13f5e66593d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-673f2e3e-b722-4cd0-b298-e13f5e66593d">
											<gml:posList>35.67236343144655 139.73931454406278 75.036 35.672482695883886 139.73919251657705 75.036 35.67235995916996 139.73901233711004 75.036 35.67226981054623 139.73907842403042 75.036 35.67222371518245 139.73912556950907 75.036 35.672267373763056 139.73918970953093 75.036 35.67228989821043 139.73916555747613 75.036 35.67231520945409 139.7392010312805 75.036 35.67229200952327 139.73922589110336 75.036 35.67232522719198 139.73927469985549 75.036 35.672337276192 139.7392601484873 75.036 35.67235255218494 139.73928031257475 75.036 35.672345033304616 139.73929002024886 75.036 35.67236343144655 139.73931454406278 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-afa13a2a-7d36-40cc-b702-f50c6d888ca1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afa13a2a-7d36-40cc-b702-f50c6d888ca1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afa13a2a-7d36-40cc-b702-f50c6d888ca1">
											<gml:posList>35.672492638879824 139.73919360955654 75.631 35.67236151876508 139.7390011119984 75.631 35.67235995916996 139.73901233711004 75.631 35.672482695883886 139.73919251657705 75.631 35.672492638879824 139.73919360955654 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94adc736-7048-4f52-9f10-81129fba43d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94adc736-7048-4f52-9f10-81129fba43d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94adc736-7048-4f52-9f10-81129fba43d5">
											<gml:posList>35.67236280077 139.7393264529644 75.631 35.672492638879824 139.73919360955654 75.631 35.672482695883886 139.73919251657705 75.631 35.67236343144655 139.73931454406278 75.631 35.67236280077 139.7393264529644 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38ccba6c-06ea-45ad-9aac-f5319079b2ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38ccba6c-06ea-45ad-9aac-f5319079b2ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38ccba6c-06ea-45ad-9aac-f5319079b2ab">
											<gml:posList>35.67228949827729 139.7391728265576 80.11 35.67230928705178 139.73920054114055 80.11 35.67230928705178 139.73920054114055 80.208 35.67228949827729 139.7391728265576 80.208 35.67228949827729 139.7391728265576 80.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afab427c-7418-4175-ba08-c6252da7d391">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afab427c-7418-4175-ba08-c6252da7d391">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afab427c-7418-4175-ba08-c6252da7d391">
											<gml:posList>35.67228930233384 139.73922196171912 80.11 35.67226952257793 139.73919424712722 80.11 35.67226952257793 139.73919424712722 80.208 35.67228930233384 139.73922196171912 80.208 35.67228930233384 139.73922196171912 80.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aac1b36a-b140-4f52-befc-33570cad280c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aac1b36a-b140-4f52-befc-33570cad280c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aac1b36a-b140-4f52-befc-33570cad280c">
											<gml:posList>35.672265577672626 139.73907148074636 9.08 35.672265577672626 139.73907148074636 75.631 35.67236151876508 139.7390011119984 75.631 35.67236151876508 139.7390011119984 9.08 35.672265577672626 139.73907148074636 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-332353b6-3745-4cf8-9e55-df5e0690e33b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-332353b6-3745-4cf8-9e55-df5e0690e33b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-332353b6-3745-4cf8-9e55-df5e0690e33b">
											<gml:posList>35.67235995916996 139.73901233711004 75.631 35.67226981054623 139.73907842403042 75.631 35.67226981054623 139.73907842403042 75.036 35.67235995916996 139.73901233711004 75.036 35.67235995916996 139.73901233711004 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86062ffd-866f-4ac8-a810-4cb13a76fc3e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86062ffd-866f-4ac8-a810-4cb13a76fc3e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86062ffd-866f-4ac8-a810-4cb13a76fc3e">
											<gml:posList>35.67236151876508 139.7390011119984 75.631 35.672492638879824 139.73919360955654 75.631 35.672492638879824 139.73919360955654 9.08 35.67236151876508 139.7390011119984 9.08 35.67236151876508 139.7390011119984 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4e84accf-9fb5-4a02-a556-62ee4543edbf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e84accf-9fb5-4a02-a556-62ee4543edbf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e84accf-9fb5-4a02-a556-62ee4543edbf">
											<gml:posList>35.672265577672626 139.73907148074636 75.631 35.672265577672626 139.73907148074636 9.08 35.67221379019562 139.7391244544274 9.08 35.67221379019562 139.7391244544274 75.631 35.672265577672626 139.73907148074636 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dffe9d9e-364b-42e3-927a-c0dfc6ea9688">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dffe9d9e-364b-42e3-927a-c0dfc6ea9688">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dffe9d9e-364b-42e3-927a-c0dfc6ea9688">
											<gml:posList>35.67222371518245 139.73912556950907 75.036 35.67226981054623 139.73907842403042 75.036 35.67226981054623 139.73907842403042 75.631 35.67222371518245 139.73912556950907 75.631 35.67222371518245 139.73912556950907 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffacf9f5-1c58-4853-93f7-543a279bae92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffacf9f5-1c58-4853-93f7-543a279bae92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffacf9f5-1c58-4853-93f7-543a279bae92">
											<gml:posList>35.67235995916996 139.73901233711004 75.036 35.672482695883886 139.73919251657705 75.036 35.672482695883886 139.73919251657705 75.631 35.67235995916996 139.73901233711004 75.631 35.67235995916996 139.73901233711004 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce0c6c92-62db-4025-9c22-ab21285af60d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce0c6c92-62db-4025-9c22-ab21285af60d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce0c6c92-62db-4025-9c22-ab21285af60d">
											<gml:posList>35.67222371518245 139.73912556950907 75.036 35.67222371518245 139.73912556950907 75.631 35.672267373763056 139.73918970953093 75.631 35.672267373763056 139.73918970953093 75.036 35.67222371518245 139.73912556950907 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b56258c-01f2-40fe-bb31-35951ea14917">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b56258c-01f2-40fe-bb31-35951ea14917">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b56258c-01f2-40fe-bb31-35951ea14917">
											<gml:posList>35.672267373763056 139.73918970953093 75.631 35.67226359116184 139.73919375699862 75.631 35.67226359116184 139.73919375699862 80.208 35.67228989821043 139.73916555747613 80.208 35.67228989821043 139.73916555747613 75.036 35.672267373763056 139.73918970953093 75.036 35.672267373763056 139.73918970953093 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-699cfa70-3795-4e1c-99aa-f4e121a8676f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-699cfa70-3795-4e1c-99aa-f4e121a8676f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-699cfa70-3795-4e1c-99aa-f4e121a8676f">
											<gml:posList>35.67231520945409 139.7392010312805 80.208 35.67231520945409 139.7392010312805 75.036 35.67228989821043 139.73916555747613 75.036 35.67228989821043 139.73916555747613 80.208 35.67231520945409 139.7392010312805 80.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7c3b8686-5fd8-4a36-84ae-6da7b3cf861d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7c3b8686-5fd8-4a36-84ae-6da7b3cf861d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7c3b8686-5fd8-4a36-84ae-6da7b3cf861d">
											<gml:posList>35.67226952257793 139.73919424712722 80.11 35.67228949827729 139.7391728265576 80.11 35.67228949827729 139.7391728265576 80.208 35.67226952257793 139.73919424712722 80.208 35.67226952257793 139.73919424712722 80.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8333ff32-fddb-4de7-99a1-d996da5bf7f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8333ff32-fddb-4de7-99a1-d996da5bf7f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8333ff32-fddb-4de7-99a1-d996da5bf7f7">
											<gml:posList>35.67232472335852 139.73928743709249 75.631 35.67221379019562 139.7391244544274 75.631 35.67221379019562 139.7391244544274 9.08 35.67232472335852 139.73928743709249 9.08 35.67232472335852 139.73928743709249 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b046feba-9026-4cb9-b29b-faa531b5541e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b046feba-9026-4cb9-b29b-faa531b5541e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b046feba-9026-4cb9-b29b-faa531b5541e">
											<gml:posList>35.67230928705178 139.73920054114055 80.11 35.67228930233384 139.73922196171912 80.11 35.67228930233384 139.73922196171912 80.208 35.67230928705178 139.73920054114055 80.208 35.67230928705178 139.73920054114055 80.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd181a58-bd66-4357-a1ed-5a3da9c4be23">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd181a58-bd66-4357-a1ed-5a3da9c4be23">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd181a58-bd66-4357-a1ed-5a3da9c4be23">
											<gml:posList>35.67226359116184 139.73919375699862 75.631 35.67228889338358 139.73922923081088 75.631 35.67228889338358 139.73922923081088 80.208 35.67226359116184 139.73919375699862 80.208 35.67226359116184 139.73919375699862 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb7c6313-5fc5-46a1-9aaa-8b0e2e71f507">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb7c6313-5fc5-46a1-9aaa-8b0e2e71f507">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb7c6313-5fc5-46a1-9aaa-8b0e2e71f507">
											<gml:posList>35.67231520945409 139.7392010312805 75.036 35.67231520945409 139.7392010312805 80.208 35.67228889338358 139.73922923081088 80.208 35.67228889338358 139.73922923081088 75.631 35.67229200952327 139.73922589110336 75.631 35.67229200952327 139.73922589110336 75.036 35.67231520945409 139.7392010312805 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b281fc77-8802-4555-bc06-8399617a9b41">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b281fc77-8802-4555-bc06-8399617a9b41">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b281fc77-8802-4555-bc06-8399617a9b41">
											<gml:posList>35.67232522719198 139.73927469985549 75.631 35.67232522719198 139.73927469985549 75.036 35.67229200952327 139.73922589110336 75.036 35.67229200952327 139.73922589110336 75.631 35.67232522719198 139.73927469985549 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12676edb-4f99-4f58-885b-d73dd32fb996">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12676edb-4f99-4f58-885b-d73dd32fb996">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12676edb-4f99-4f58-885b-d73dd32fb996">
											<gml:posList>35.672482695883886 139.73919251657705 75.036 35.67236343144655 139.73931454406278 75.036 35.67236343144655 139.73931454406278 75.631 35.672482695883886 139.73919251657705 75.631 35.672482695883886 139.73919251657705 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28ce6248-01a8-4970-a622-8b9487f29f4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28ce6248-01a8-4970-a622-8b9487f29f4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28ce6248-01a8-4970-a622-8b9487f29f4b">
											<gml:posList>35.672492638879824 139.73919360955654 75.631 35.67236280077 139.7393264529644 75.631 35.67236280077 139.7393264529644 9.08 35.672492638879824 139.73919360955654 9.08 35.672492638879824 139.73919360955654 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf2c4b69-f200-43ce-abfc-9a5ec4eafcb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf2c4b69-f200-43ce-abfc-9a5ec4eafcb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf2c4b69-f200-43ce-abfc-9a5ec4eafcb0">
											<gml:posList>35.672337276192 139.7392601484873 75.036 35.67232522719198 139.73927469985549 75.036 35.67232522719198 139.73927469985549 75.631 35.672337276192 139.7392601484873 75.631 35.672337276192 139.7392601484873 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cff4a04-2972-44bf-ad2b-f9eaf4dc44fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cff4a04-2972-44bf-ad2b-f9eaf4dc44fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cff4a04-2972-44bf-ad2b-f9eaf4dc44fd">
											<gml:posList>35.672337276192 139.7392601484873 75.631 35.67235255218494 139.73928031257475 75.631 35.67235255218494 139.73928031257475 75.036 35.672337276192 139.7392601484873 75.036 35.672337276192 139.7392601484873 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f684367c-c347-4ded-aacd-f26557d9827e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f684367c-c347-4ded-aacd-f26557d9827e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f684367c-c347-4ded-aacd-f26557d9827e">
											<gml:posList>35.67233706054023 139.73927255399232 75.631 35.67233706054023 139.73927255399232 9.08 35.672342889417294 139.73928024658488 9.08 35.672342889417294 139.73928024658488 75.631 35.67233706054023 139.73927255399232 75.631</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5b1468e3-49ad-401b-b96d-db89be014e8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5b1468e3-49ad-401b-b96d-db89be014e8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5b1468e3-49ad-401b-b96d-db89be014e8a">
											<gml:posList>35.67233706054023 139.73927255399232 9.08 35.67233706054023 139.73927255399232 75.631 35.67232472335852 139.73928743709249 75.631 35.67232472335852 139.73928743709249 9.08 35.67233706054023 139.73927255399232 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9676b984-a3ba-4297-b3f8-f330fdb416d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9676b984-a3ba-4297-b3f8-f330fdb416d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9676b984-a3ba-4297-b3f8-f330fdb416d3">
											<gml:posList>35.67233538853853 139.7392899210971 9.08 35.67233538853853 139.7392899210971 75.631 35.672342889417294 139.73928024658488 75.631 35.672342889417294 139.73928024658488 9.08 35.67233538853853 139.7392899210971 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8abb9d01-0439-4513-995f-919b07b22188">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8abb9d01-0439-4513-995f-919b07b22188">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8abb9d01-0439-4513-995f-919b07b22188">
											<gml:posList>35.672345033304616 139.73929002024886 75.036 35.67235255218494 139.73928031257475 75.036 35.67235255218494 139.73928031257475 75.631 35.672345033304616 139.73929002024886 75.631 35.672345033304616 139.73929002024886 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6890a96d-2602-446f-84f8-1c505c519187">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6890a96d-2602-446f-84f8-1c505c519187">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6890a96d-2602-446f-84f8-1c505c519187">
											<gml:posList>35.67236343144655 139.73931454406278 75.036 35.672345033304616 139.73929002024886 75.036 35.672345033304616 139.73929002024886 75.631 35.67236343144655 139.73931454406278 75.631 35.67236343144655 139.73931454406278 75.036</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a20ab449-9adc-498c-b3d9-c527ccc7386e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a20ab449-9adc-498c-b3d9-c527ccc7386e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a20ab449-9adc-498c-b3d9-c527ccc7386e">
											<gml:posList>35.67236280077 139.7393264529644 9.08 35.67236280077 139.7393264529644 75.631 35.67233538853853 139.7392899210971 75.631 35.67233538853853 139.7392899210971 9.08 35.67236280077 139.7393264529644 9.08</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-5939</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">571.575</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>