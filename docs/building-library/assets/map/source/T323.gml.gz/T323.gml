<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5c1d8119-748f-47a1-bc70-e848bde31b90">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">18.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>6</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67391622658984 139.73776944833358 0 35.67396747013679 139.73794061192663 0 35.67402486711731 139.73791480467438 0 35.67397362353404 139.73774364097545 0 35.67391622658984 139.73776944833358 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67391622658984 139.73776944833358 9.086 35.67397362353404 139.73774364097545 9.086 35.67402486711731 139.73791480467438 9.086 35.67396747013679 139.73794061192663 9.086 35.67391622658984 139.73776944833358 9.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67391622658984 139.73776944833358 9.086 35.67396747013679 139.73794061192663 9.086 35.67396747013679 139.73794061192663 27.409999999999997 35.67391622658984 139.73776944833358 27.409999999999997 35.67391622658984 139.73776944833358 9.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67396747013679 139.73794061192663 9.086 35.67402486711731 139.73791480467438 9.086 35.67402486711731 139.73791480467438 27.409999999999997 35.67396747013679 139.73794061192663 27.409999999999997 35.67396747013679 139.73794061192663 9.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67402486711731 139.73791480467438 9.086 35.67397362353404 139.73774364097545 9.086 35.67397362353404 139.73774364097545 27.409999999999997 35.67402486711731 139.73791480467438 27.409999999999997 35.67402486711731 139.73791480467438 9.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67397362353404 139.73774364097545 9.086 35.67391622658984 139.73776944833358 9.086 35.67391622658984 139.73776944833358 27.409999999999997 35.67397362353404 139.73774364097545 27.409999999999997 35.67397362353404 139.73774364097545 9.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67391622658984 139.73776944833358 27.409999999999997 35.67396747013679 139.73794061192663 27.409999999999997 35.67402486711731 139.73791480467438 27.409999999999997 35.67397362353404 139.73774364097545 27.409999999999997 35.67391622658984 139.73776944833358 27.409999999999997</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-7d019a5b-441b-4d11-ba7e-995742a97ba7"/>
							<gml:surfaceMember xlink:href="#poly-af06f2bd-e96e-42fc-aa92-8ea0bdf262a3"/>
							<gml:surfaceMember xlink:href="#poly-2812c2f4-44b8-435e-9c17-045242ebff0e"/>
							<gml:surfaceMember xlink:href="#poly-9dc22543-0937-4b03-8387-9a4d70a9fe07"/>
							<gml:surfaceMember xlink:href="#poly-cc810f58-1b67-4e4a-b12f-bd5a7f05bb61"/>
							<gml:surfaceMember xlink:href="#poly-fa66b088-ca24-42c8-96a3-7321efa2ee42"/>
							<gml:surfaceMember xlink:href="#poly-ca3aa295-ace9-4f04-9a28-a5f41dcaa4a0"/>
							<gml:surfaceMember xlink:href="#poly-5413784c-fc5f-4b18-9dc8-3a7982b11691"/>
							<gml:surfaceMember xlink:href="#poly-01547b7d-0858-457f-b879-f9bcad251587"/>
							<gml:surfaceMember xlink:href="#poly-6f6b33c3-5186-49bd-8c2b-1e8783ce7efd"/>
							<gml:surfaceMember xlink:href="#poly-f2807336-1b26-404a-af74-8a8ac327171f"/>
							<gml:surfaceMember xlink:href="#poly-dad8b8d9-0316-4ea2-bc64-534cde524d8c"/>
							<gml:surfaceMember xlink:href="#poly-6e3ad0fb-d449-44cb-9013-68094c1b7590"/>
							<gml:surfaceMember xlink:href="#poly-50c3cf71-70e3-4538-bdf5-57bcdde34e8d"/>
							<gml:surfaceMember xlink:href="#poly-979c0778-f8df-4f8e-98ff-8655e6597405"/>
							<gml:surfaceMember xlink:href="#poly-df41d498-577f-4394-8805-7a12abdc27b4"/>
							<gml:surfaceMember xlink:href="#poly-02156721-e8f4-418c-af62-3c4a8fa2e61e"/>
							<gml:surfaceMember xlink:href="#poly-f674fb01-08b1-4499-ada4-d7b365c3120f"/>
							<gml:surfaceMember xlink:href="#poly-14214752-878c-4b78-af23-6e59656a7d89"/>
							<gml:surfaceMember xlink:href="#poly-7e1ddeae-90ee-46bc-8ce0-56cf5c058a20"/>
							<gml:surfaceMember xlink:href="#poly-5e2408e9-6500-4ccb-ba6b-cdbda9405718"/>
							<gml:surfaceMember xlink:href="#poly-97747220-c9c6-414a-bff1-304034275a00"/>
							<gml:surfaceMember xlink:href="#poly-2da34400-08ae-4dc9-8ef3-5ceb84d1df72"/>
							<gml:surfaceMember xlink:href="#poly-95bb1ccb-80a5-4d8a-a8cd-71f17bfdb20d"/>
							<gml:surfaceMember xlink:href="#poly-8fa41288-9a1b-43e8-9b2c-4ec6a7e49cf6"/>
							<gml:surfaceMember xlink:href="#poly-e2e9fa90-563b-4941-86af-4afa6449ecbc"/>
							<gml:surfaceMember xlink:href="#poly-0a4a9204-2a4f-4d8e-b4d0-9c58f785244f"/>
							<gml:surfaceMember xlink:href="#poly-9a2fbdcc-4582-4dce-9c7d-adabf68be185"/>
							<gml:surfaceMember xlink:href="#poly-6a8c0280-d751-4134-a747-5703a83439ee"/>
							<gml:surfaceMember xlink:href="#poly-2ae92cd1-5ac5-4aee-ad2f-11437e693d87"/>
							<gml:surfaceMember xlink:href="#poly-fedc7621-797a-443b-9f3d-5d2ea96cfd0c"/>
							<gml:surfaceMember xlink:href="#poly-3b4e66d6-956c-4bb6-831b-10762a1a40d1"/>
							<gml:surfaceMember xlink:href="#poly-edd430bb-1974-4605-8380-1993ae44fca5"/>
							<gml:surfaceMember xlink:href="#poly-f8e7e172-4938-467a-8b63-2f9709aa6f18"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5c1d8119-748f-47a1-bc70-e848bde31b90_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb290b21-1835-4cf9-9534-3ce0f0dd778d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67396422234522 139.7378801458653 27.727 35.67395666685633 139.7378549019865 27.727 35.67399142040057 139.73783927362138 27.727 35.67399897589271 139.73786451750965 27.727 35.67396422234522 139.7378801458653 27.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e975133-8269-46c9-915f-1e19e33614b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e975133-8269-46c9-915f-1e19e33614b7_0">
											<gml:posList>35.67395666685633 139.7378549019865 30.738 35.67395666685633 139.7378549019865 27.727 35.67396422234522 139.7378801458653 27.727 35.67396422234522 139.7378801458653 30.738 35.67395666685633 139.7378549019865 30.738</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0814a910-a83d-4098-b41a-a7eab565334a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0814a910-a83d-4098-b41a-a7eab565334a_0">
											<gml:posList>35.67399142040057 139.73783927362138 27.727 35.67395666685633 139.7378549019865 27.727 35.67395666685633 139.7378549019865 30.738 35.67399142040057 139.73783927362138 30.738 35.67399142040057 139.73783927362138 27.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77f6db73-4527-4851-b739-2c0deeedb114">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77f6db73-4527-4851-b739-2c0deeedb114_0">
											<gml:posList>35.67399142040057 139.73783927362138 30.738 35.67395666685633 139.7378549019865 30.738 35.67396422234522 139.7378801458653 30.738 35.67399897589271 139.73786451750965 30.738 35.67399142040057 139.73783927362138 30.738</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f375eae-70ff-43cc-a8e0-8901a11fe984">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f375eae-70ff-43cc-a8e0-8901a11fe984_0">
											<gml:posList>35.67399897589271 139.73786451750965 27.727 35.67399897589271 139.73786451750965 30.738 35.67396422234522 139.7378801458653 30.738 35.67396422234522 139.7378801458653 27.727 35.67399897589271 139.73786451750965 27.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13be4268-9eb5-459a-b6e9-e21bb569fd11">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13be4268-9eb5-459a-b6e9-e21bb569fd11_0">
											<gml:posList>35.67399897589271 139.73786451750965 30.738 35.67399897589271 139.73786451750965 27.727 35.67399142040057 139.73783927362138 27.727 35.67399142040057 139.73783927362138 30.738 35.67399897589271 139.73786451750965 30.738</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-7d019a5b-441b-4d11-ba7e-995742a97ba7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d019a5b-441b-4d11-ba7e-995742a97ba7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d019a5b-441b-4d11-ba7e-995742a97ba7">
											<gml:posList>35.67391622658984 139.73776944833358 9.086 35.67397362353402 139.73774364097542 9.086 35.67402486711731 139.73791480467438 9.086 35.673967470136766 139.73794061192663 9.086 35.67391622658984 139.73776944833358 9.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-af06f2bd-e96e-42fc-aa92-8ea0bdf262a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af06f2bd-e96e-42fc-aa92-8ea0bdf262a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af06f2bd-e96e-42fc-aa92-8ea0bdf262a3">
											<gml:posList>35.67391622658984 139.73776944833358 25.944 35.67392222760015 139.73778947997945 25.944 35.67397915459026 139.73776210455472 25.944 35.67397362353402 139.73774364097542 25.944 35.67391622658984 139.73776944833358 25.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2812c2f4-44b8-435e-9c17-045242ebff0e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2812c2f4-44b8-435e-9c17-045242ebff0e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2812c2f4-44b8-435e-9c17-045242ebff0e">
											<gml:posList>35.67392222760015 139.73778947997945 28.095 35.67392696187883 139.73779209241633 28.095 35.67397697797041 139.73776802821013 28.095 35.67397915459026 139.73776210455472 28.095 35.67392222760015 139.73778947997945 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9dc22543-0937-4b03-8387-9a4d70a9fe07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9dc22543-0937-4b03-8387-9a4d70a9fe07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9dc22543-0937-4b03-8387-9a4d70a9fe07">
											<gml:posList>35.67392696187883 139.73779209241633 28.095 35.67392222760015 139.73778947997945 28.095 35.67392956622149 139.7378140281545 28.095 35.673933053294206 139.7378124664081 28.095 35.67392696187883 139.73779209241633 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cc810f58-1b67-4e4a-b12f-bd5a7f05bb61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc810f58-1b67-4e4a-b12f-bd5a7f05bb61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc810f58-1b67-4e4a-b12f-bd5a7f05bb61">
											<gml:posList>35.67392956622149 139.7378140281545 32.4 35.673933506994615 139.73781626594908 32.4 35.67394933845113 139.73780913297867 32.4 35.673951164414504 139.73780431441935 32.4 35.67392956622149 139.7378140281545 32.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa66b088-ca24-42c8-96a3-7321efa2ee42">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa66b088-ca24-42c8-96a3-7321efa2ee42">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa66b088-ca24-42c8-96a3-7321efa2ee42">
											<gml:posList>35.67397915459026 139.73776210455472 28.095 35.67397697797041 139.73776802821013 28.095 35.67400698302467 139.7378682307319 28.095 35.67401169925663 139.73787082110414 28.095 35.67397915459026 139.73776210455472 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ca3aa295-ace9-4f04-9a28-a5f41dcaa4a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca3aa295-ace9-4f04-9a28-a5f41dcaa4a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca3aa295-ace9-4f04-9a28-a5f41dcaa4a0">
											<gml:posList>35.673951164414504 139.73780431441935 32.4 35.67394933845113 139.73780913297867 32.4 35.6739584212979 139.7378394565374 32.4 35.67396236207053 139.73784169433398 32.4 35.673951164414504 139.73780431441935 32.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5413784c-fc5f-4b18-9dc8-3a7982b11691">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5413784c-fc5f-4b18-9dc8-3a7982b11691">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5413784c-fc5f-4b18-9dc8-3a7982b11691">
											<gml:posList>35.6739584212979 139.7378394565374 32.181 35.67394933845113 139.73780913297867 32.181 35.673933506994615 139.73781626594908 32.181 35.6739425898396 139.73784658950262 32.181 35.6739584212979 139.7378394565374 32.181</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-01547b7d-0858-457f-b879-f9bcad251587">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01547b7d-0858-457f-b879-f9bcad251587">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01547b7d-0858-457f-b879-f9bcad251587">
											<gml:posList>35.67397697797041 139.73776802821013 27.727 35.67392696187883 139.73779209241633 27.727 35.673933053294206 139.7378124664081 27.727 35.673951164414504 139.73780431441935 27.727 35.67396236207053 139.73784169433398 27.727 35.67394425094773 139.7378498463154 27.727 35.673957030201876 139.73789253783787 27.727 35.67400698302467 139.7378682307319 27.727 35.67397697797041 139.73776802821013 27.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6f6b33c3-5186-49bd-8c2b-1e8783ce7efd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f6b33c3-5186-49bd-8c2b-1e8783ce7efd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f6b33c3-5186-49bd-8c2b-1e8783ce7efd">
											<gml:posList>35.67394076387453 139.73785140806044 32.4 35.6739425898396 139.73784658950262 32.4 35.673933506994615 139.73781626594908 32.4 35.67392956622149 139.7378140281545 32.4 35.67394076387453 139.73785140806044 32.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f2807336-1b26-404a-af74-8a8ac327171f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2807336-1b26-404a-af74-8a8ac327171f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2807336-1b26-404a-af74-8a8ac327171f">
											<gml:posList>35.67396236207053 139.73784169433398 32.4 35.6739584212979 139.7378394565374 32.4 35.6739425898396 139.73784658950262 32.4 35.67394076387453 139.73785140806044 32.4 35.67396236207053 139.73784169433398 32.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dad8b8d9-0316-4ea2-bc64-534cde524d8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dad8b8d9-0316-4ea2-bc64-534cde524d8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dad8b8d9-0316-4ea2-bc64-534cde524d8c">
											<gml:posList>35.673957030201876 139.73789253783787 28.095 35.67394425094773 139.7378498463154 28.095 35.67394076387453 139.73785140806044 28.095 35.67395485358435 139.73789847253485 28.095 35.673957030201876 139.73789253783787 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e3ad0fb-d449-44cb-9013-68094c1b7590">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e3ad0fb-d449-44cb-9013-68094c1b7590">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e3ad0fb-d449-44cb-9013-68094c1b7590">
											<gml:posList>35.67401169925663 139.73787082110414 28.095 35.67400698302467 139.7378682307319 28.095 35.673957030201876 139.73789253783787 28.095 35.67395485358435 139.73789847253485 28.095 35.67401169925663 139.73787082110414 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50c3cf71-70e3-4538-bdf5-57bcdde34e8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50c3cf71-70e3-4538-bdf5-57bcdde34e8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50c3cf71-70e3-4538-bdf5-57bcdde34e8d">
											<gml:posList>35.67402486711731 139.73791480467438 22.524 35.67401169925663 139.73787082110414 28.095 35.67395485358435 139.73789847253485 28.095 35.67402486711731 139.73791480467438 22.524</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-979c0778-f8df-4f8e-98ff-8655e6597405">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-979c0778-f8df-4f8e-98ff-8655e6597405">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-979c0778-f8df-4f8e-98ff-8655e6597405">
											<gml:posList>35.67395485358435 139.73789847253485 28.095 35.673967470136766 139.73794061192663 22.524 35.67402486711731 139.73791480467438 22.524 35.67395485358435 139.73789847253485 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-df41d498-577f-4394-8805-7a12abdc27b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-df41d498-577f-4394-8805-7a12abdc27b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-df41d498-577f-4394-8805-7a12abdc27b4">
											<gml:posList>35.67394933845113 139.73780913297867 32.4 35.67394933845113 139.73780913297867 32.181 35.6739584212979 139.7378394565374 32.181 35.6739584212979 139.7378394565374 32.4 35.67394933845113 139.73780913297867 32.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-02156721-e8f4-418c-af62-3c4a8fa2e61e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-02156721-e8f4-418c-af62-3c4a8fa2e61e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-02156721-e8f4-418c-af62-3c4a8fa2e61e">
											<gml:posList>35.67397362353402 139.73774364097542 9.086 35.67391622658984 139.73776944833358 9.086 35.67391622658984 139.73776944833358 25.944 35.67397362353402 139.73774364097542 25.944 35.67397362353402 139.73774364097542 9.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f674fb01-08b1-4499-ada4-d7b365c3120f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f674fb01-08b1-4499-ada4-d7b365c3120f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f674fb01-08b1-4499-ada4-d7b365c3120f">
											<gml:posList>35.67392222760015 139.73778947997945 28.095 35.67397915459026 139.73776210455472 28.095 35.67397915459026 139.73776210455472 25.944 35.67392222760015 139.73778947997945 25.944 35.67392222760015 139.73778947997945 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14214752-878c-4b78-af23-6e59656a7d89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14214752-878c-4b78-af23-6e59656a7d89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14214752-878c-4b78-af23-6e59656a7d89">
											<gml:posList>35.67392696187883 139.73779209241633 28.095 35.67392696187883 139.73779209241633 27.727 35.67397697797041 139.73776802821013 27.727 35.67397697797041 139.73776802821013 28.095 35.67392696187883 139.73779209241633 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e1ddeae-90ee-46bc-8ce0-56cf5c058a20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e1ddeae-90ee-46bc-8ce0-56cf5c058a20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e1ddeae-90ee-46bc-8ce0-56cf5c058a20">
											<gml:posList>35.673933053294206 139.7378124664081 28.095 35.673933053294206 139.7378124664081 27.727 35.67392696187883 139.73779209241633 27.727 35.67392696187883 139.73779209241633 28.095 35.673933053294206 139.7378124664081 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e2408e9-6500-4ccb-ba6b-cdbda9405718">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e2408e9-6500-4ccb-ba6b-cdbda9405718">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e2408e9-6500-4ccb-ba6b-cdbda9405718">
											<gml:posList>35.673933053294206 139.7378124664081 28.095 35.67392956622149 139.7378140281545 28.095 35.67392956622149 139.7378140281545 32.4 35.673951164414504 139.73780431441935 32.4 35.673951164414504 139.73780431441935 27.727 35.673933053294206 139.7378124664081 27.727 35.673933053294206 139.7378124664081 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97747220-c9c6-414a-bff1-304034275a00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97747220-c9c6-414a-bff1-304034275a00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97747220-c9c6-414a-bff1-304034275a00">
											<gml:posList>35.673933506994615 139.73781626594908 32.4 35.673933506994615 139.73781626594908 32.181 35.67394933845113 139.73780913297867 32.181 35.67394933845113 139.73780913297867 32.4 35.673933506994615 139.73781626594908 32.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2da34400-08ae-4dc9-8ef3-5ceb84d1df72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2da34400-08ae-4dc9-8ef3-5ceb84d1df72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2da34400-08ae-4dc9-8ef3-5ceb84d1df72">
											<gml:posList>35.67397697797041 139.73776802821013 28.095 35.67397697797041 139.73776802821013 27.727 35.67400698302467 139.7378682307319 27.727 35.67400698302467 139.7378682307319 28.095 35.67397697797041 139.73776802821013 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95bb1ccb-80a5-4d8a-a8cd-71f17bfdb20d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95bb1ccb-80a5-4d8a-a8cd-71f17bfdb20d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95bb1ccb-80a5-4d8a-a8cd-71f17bfdb20d">
											<gml:posList>35.673951164414504 139.73780431441935 32.4 35.67396236207053 139.73784169433398 32.4 35.67396236207053 139.73784169433398 27.727 35.673951164414504 139.73780431441935 27.727 35.673951164414504 139.73780431441935 32.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fa41288-9a1b-43e8-9b2c-4ec6a7e49cf6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fa41288-9a1b-43e8-9b2c-4ec6a7e49cf6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fa41288-9a1b-43e8-9b2c-4ec6a7e49cf6">
											<gml:posList>35.67397915459026 139.73776210455472 25.944 35.67397915459026 139.73776210455472 28.095 35.67401169925663 139.73787082110414 28.095 35.67402486711731 139.73791480467438 22.524 35.67402486711731 139.73791480467438 9.086 35.67397362353402 139.73774364097542 9.086 35.67397362353402 139.73774364097542 25.944 35.67397915459026 139.73776210455472 25.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e2e9fa90-563b-4941-86af-4afa6449ecbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e2e9fa90-563b-4941-86af-4afa6449ecbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e2e9fa90-563b-4941-86af-4afa6449ecbc">
											<gml:posList>35.6739425898396 139.73784658950262 32.4 35.6739425898396 139.73784658950262 32.181 35.673933506994615 139.73781626594908 32.181 35.673933506994615 139.73781626594908 32.4 35.6739425898396 139.73784658950262 32.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a4a9204-2a4f-4d8e-b4d0-9c58f785244f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a4a9204-2a4f-4d8e-b4d0-9c58f785244f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a4a9204-2a4f-4d8e-b4d0-9c58f785244f">
											<gml:posList>35.67392222760015 139.73778947997945 25.944 35.67391622658984 139.73776944833358 25.944 35.67391622658984 139.73776944833358 9.086 35.67395485358435 139.73789847253485 28.095 35.67394076387453 139.73785140806044 28.095 35.67394076387453 139.73785140806044 32.4 35.67392956622149 139.7378140281545 32.4 35.67392956622149 139.7378140281545 28.095 35.67392222760015 139.73778947997945 28.095 35.67392222760015 139.73778947997945 25.944</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a2fbdcc-4582-4dce-9c7d-adabf68be185">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a2fbdcc-4582-4dce-9c7d-adabf68be185">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a2fbdcc-4582-4dce-9c7d-adabf68be185">
											<gml:posList>35.6739584212979 139.7378394565374 32.4 35.6739584212979 139.7378394565374 32.181 35.6739425898396 139.73784658950262 32.181 35.6739425898396 139.73784658950262 32.4 35.6739584212979 139.7378394565374 32.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a8c0280-d751-4134-a747-5703a83439ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a8c0280-d751-4134-a747-5703a83439ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a8c0280-d751-4134-a747-5703a83439ee">
											<gml:posList>35.67396236207053 139.73784169433398 27.727 35.67396236207053 139.73784169433398 32.4 35.67394076387453 139.73785140806044 32.4 35.67394076387453 139.73785140806044 28.095 35.67394425094773 139.7378498463154 28.095 35.67394425094773 139.7378498463154 27.727 35.67396236207053 139.73784169433398 27.727</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ae92cd1-5ac5-4aee-ad2f-11437e693d87">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ae92cd1-5ac5-4aee-ad2f-11437e693d87">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ae92cd1-5ac5-4aee-ad2f-11437e693d87">
											<gml:posList>35.67395485358435 139.73789847253485 28.095 35.67391622658984 139.73776944833358 9.086 35.673967470136766 139.73794061192663 9.086 35.67395485358435 139.73789847253485 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fedc7621-797a-443b-9f3d-5d2ea96cfd0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fedc7621-797a-443b-9f3d-5d2ea96cfd0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fedc7621-797a-443b-9f3d-5d2ea96cfd0c">
											<gml:posList>35.673957030201876 139.73789253783787 28.095 35.673957030201876 139.73789253783787 27.727 35.67394425094773 139.7378498463154 27.727 35.67394425094773 139.7378498463154 28.095 35.673957030201876 139.73789253783787 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b4e66d6-956c-4bb6-831b-10762a1a40d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b4e66d6-956c-4bb6-831b-10762a1a40d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b4e66d6-956c-4bb6-831b-10762a1a40d1">
											<gml:posList>35.67400698302467 139.7378682307319 28.095 35.67400698302467 139.7378682307319 27.727 35.673957030201876 139.73789253783787 27.727 35.673957030201876 139.73789253783787 28.095 35.67400698302467 139.7378682307319 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-edd430bb-1974-4605-8380-1993ae44fca5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-edd430bb-1974-4605-8380-1993ae44fca5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-edd430bb-1974-4605-8380-1993ae44fca5">
											<gml:posList>35.67395485358435 139.73789847253485 28.095 35.673967470136766 139.73794061192663 9.086 35.673967470136766 139.73794061192663 22.524 35.67395485358435 139.73789847253485 28.095</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8e7e172-4938-467a-8b63-2f9709aa6f18">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8e7e172-4938-467a-8b63-2f9709aa6f18">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8e7e172-4938-467a-8b63-2f9709aa6f18">
											<gml:posList>35.673967470136766 139.73794061192663 9.086 35.67402486711731 139.73791480467438 9.086 35.67402486711731 139.73791480467438 22.524 35.673967470136766 139.73794061192663 22.524 35.673967470136766 139.73794061192663 9.086</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2777</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">101.20274</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1242</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>