<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5d9cba0b-0472-4b93-8247-f57d238e2bd1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">20</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66721541929062 139.74194944226844 0 35.667261681331915 139.7418591451156 0 35.667168154160855 139.74178712262218 0 35.66712180195161 139.74187730935586 0 35.66721541929062 139.74194944226844 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66721541929062 139.74194944226844 28.07 35.66712180195161 139.74187730935586 28.07 35.667168154160855 139.74178712262218 28.07 35.667261681331915 139.7418591451156 28.07 35.66721541929062 139.74194944226844 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66721541929062 139.74194944226844 28.07 35.667261681331915 139.7418591451156 28.07 35.667261681331915 139.7418591451156 48.11 35.66721541929062 139.74194944226844 48.11 35.66721541929062 139.74194944226844 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667261681331915 139.7418591451156 28.07 35.667168154160855 139.74178712262218 28.07 35.667168154160855 139.74178712262218 48.11 35.667261681331915 139.7418591451156 48.11 35.667261681331915 139.7418591451156 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667168154160855 139.74178712262218 28.07 35.66712180195161 139.74187730935586 28.07 35.66712180195161 139.74187730935586 48.11 35.667168154160855 139.74178712262218 48.11 35.667168154160855 139.74178712262218 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66712180195161 139.74187730935586 28.07 35.66721541929062 139.74194944226844 28.07 35.66721541929062 139.74194944226844 48.11 35.66712180195161 139.74187730935586 48.11 35.66712180195161 139.74187730935586 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66721541929062 139.74194944226844 48.11 35.667261681331915 139.7418591451156 48.11 35.667168154160855 139.74178712262218 48.11 35.66712180195161 139.74187730935586 48.11 35.66721541929062 139.74194944226844 48.11</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-2aa77661-64b7-4348-9fd2-668c2f9ad4a7"/>
							<gml:surfaceMember xlink:href="#poly-1f91b940-c7d2-4921-9f8d-9b78ebef0fa7"/>
							<gml:surfaceMember xlink:href="#poly-5961962a-5107-4413-bfba-74b33cda643e"/>
							<gml:surfaceMember xlink:href="#poly-05011227-50ca-4bcd-a24d-2a670e283d8c"/>
							<gml:surfaceMember xlink:href="#poly-ba5da491-578b-475d-b4ce-b730642a741a"/>
							<gml:surfaceMember xlink:href="#poly-c93fe4db-5b8b-4a2e-8861-36edbe3f0414"/>
							<gml:surfaceMember xlink:href="#poly-8fbbdb05-bbcf-4c6f-af66-219ec51da1a9"/>
							<gml:surfaceMember xlink:href="#poly-1f2c7ebd-1191-4d4d-afc0-2e7a2e21f426"/>
							<gml:surfaceMember xlink:href="#poly-ad6cf741-fd3b-47af-b23b-9fabf25db5a6"/>
							<gml:surfaceMember xlink:href="#poly-b49244a7-17fe-45df-a6b2-1bcb3bf33242"/>
							<gml:surfaceMember xlink:href="#poly-abc5bfb8-351e-40dd-9d24-f643de7fdab5"/>
							<gml:surfaceMember xlink:href="#poly-8eeae56e-387c-4482-ad28-a09909f6e330"/>
							<gml:surfaceMember xlink:href="#poly-71279d32-3c8d-4928-94fb-166c0676f72c"/>
							<gml:surfaceMember xlink:href="#poly-46767919-3d17-45d4-8703-c89b4cc6478a"/>
							<gml:surfaceMember xlink:href="#poly-b808af59-ce87-4956-973b-8178c101c450"/>
							<gml:surfaceMember xlink:href="#poly-18a403ba-f099-46df-88cb-59ca92e5d825"/>
							<gml:surfaceMember xlink:href="#poly-8290d142-5ae9-44ac-b3bd-7c5ea18c2718"/>
							<gml:surfaceMember xlink:href="#poly-199428d3-2950-43d3-bf84-dc9640e39e81"/>
							<gml:surfaceMember xlink:href="#poly-45a1ac2e-06bb-421c-bf0c-be27f6b31be2"/>
							<gml:surfaceMember xlink:href="#poly-a5d78bd7-dc36-4805-ab98-9910067dded4"/>
							<gml:surfaceMember xlink:href="#poly-af1e5ce1-1baf-43d3-a46c-bc5e6a6c22e9"/>
							<gml:surfaceMember xlink:href="#poly-38894b65-8e30-48dc-8d04-9b8874ee8c88"/>
							<gml:surfaceMember xlink:href="#poly-fb96a416-3b58-4947-86bb-3e0dc1eed767"/>
							<gml:surfaceMember xlink:href="#poly-9546f4dd-404a-4028-9e5e-dd53a96e6cac"/>
							<gml:surfaceMember xlink:href="#poly-35697725-4880-4070-a8bf-4641afaffd12"/>
							<gml:surfaceMember xlink:href="#poly-1cd965ae-51f7-43a0-9815-ed7a5713d43d"/>
							<gml:surfaceMember xlink:href="#poly-97f0989e-ea87-47ba-a9ab-2547bb71b238"/>
							<gml:surfaceMember xlink:href="#poly-8eea2ab7-1569-40de-9daa-00f5850532c8"/>
							<gml:surfaceMember xlink:href="#poly-c322d326-3ac0-46f7-a6aa-4cbc378c560e"/>
							<gml:surfaceMember xlink:href="#poly-8c5330bd-e31f-460f-aaa0-96fb7a810858"/>
							<gml:surfaceMember xlink:href="#poly-2a9ba9d6-d71a-46d4-ab38-4906723686a1"/>
							<gml:surfaceMember xlink:href="#poly-7a4f8909-e615-4c1b-acb7-0a2d64f7d413"/>
							<gml:surfaceMember xlink:href="#poly-d98b4b12-7cc9-4527-9ef7-504bcaaf2a28"/>
							<gml:surfaceMember xlink:href="#poly-69f16b83-e5e8-4a43-8945-b816ec004542"/>
							<gml:surfaceMember xlink:href="#poly-0e43c60f-a6c9-4331-92d0-28c134e775bb"/>
							<gml:surfaceMember xlink:href="#poly-12616cba-ebb2-46f2-acbc-2cd465e117e1"/>
							<gml:surfaceMember xlink:href="#poly-d6685d43-a5e8-4cd6-b75a-7d1b052dead6"/>
							<gml:surfaceMember xlink:href="#poly-e07de90a-5e8b-451d-a7ac-b9c727ae0941"/>
							<gml:surfaceMember xlink:href="#poly-11d85e5f-f0ee-46a9-a578-4760d82dc4ff"/>
							<gml:surfaceMember xlink:href="#poly-aef86b8b-2037-4e75-9f56-e172161cbbed"/>
							<gml:surfaceMember xlink:href="#poly-68dc30cc-69df-4729-8c9e-cd93b2e177c1"/>
							<gml:surfaceMember xlink:href="#poly-53ae02f3-a795-4d5d-93c1-b1dbe44b3df2"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5d9cba0b-0472-4b93-8247-f57d238e2bd1_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f088734c-c2dd-43af-87e0-aedc0eec6ce6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717730202197 139.74185686652132 50.591 35.667192030073394 139.74186821586886 50.591 35.667182948669904 139.74188593267561 50.591 35.66716821160638 139.74187458333637 50.591 35.66717730202197 139.74185686652132 50.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-683ee90f-eb0c-4934-a19e-e68944767976">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-683ee90f-eb0c-4934-a19e-e68944767976_0">
											<gml:posList>35.66716821160638 139.74187458333637 50.591 35.66716821160638 139.74187458333637 52.9 35.66717730202197 139.74185686652132 52.9 35.66717730202197 139.74185686652132 50.591 35.66716821160638 139.74187458333637 50.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3611bf82-062f-45d3-be6d-c15ec9bbc697">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3611bf82-062f-45d3-be6d-c15ec9bbc697_0">
											<gml:posList>35.667182948669904 139.74188593267561 50.591 35.667182948669904 139.74188593267561 52.9 35.66716821160638 139.74187458333637 52.9 35.66716821160638 139.74187458333637 50.591 35.667182948669904 139.74188593267561 50.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b481a1ad-f413-486b-9c6e-115f0e4ebba9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b481a1ad-f413-486b-9c6e-115f0e4ebba9_0">
											<gml:posList>35.66717730202197 139.74185686652132 52.9 35.66716821160638 139.74187458333637 52.9 35.667182948669904 139.74188593267561 52.9 35.667192030073394 139.74186821586886 52.9 35.66717730202197 139.74185686652132 52.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29ed7694-97d9-4870-abab-ec3b57cab80b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29ed7694-97d9-4870-abab-ec3b57cab80b_0">
											<gml:posList>35.66717730202197 139.74185686652132 50.591 35.66717730202197 139.74185686652132 52.9 35.667192030073394 139.74186821586886 52.9 35.667192030073394 139.74186821586886 50.591 35.66717730202197 139.74185686652132 50.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ea13197-dd8e-4b34-8707-00551177c47d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ea13197-dd8e-4b34-8707-00551177c47d_0">
											<gml:posList>35.667192030073394 139.74186821586886 50.591 35.667192030073394 139.74186821586886 52.9 35.667182948669904 139.74188593267561 52.9 35.667182948669904 139.74188593267561 50.591 35.667192030073394 139.74186821586886 50.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-2aa77661-64b7-4348-9fd2-668c2f9ad4a7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2aa77661-64b7-4348-9fd2-668c2f9ad4a7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2aa77661-64b7-4348-9fd2-668c2f9ad4a7">
											<gml:posList>35.66721541929061 139.74194944226844 28.07 35.667121801951595 139.74187730935583 28.07 35.66716815416085 139.74178712262218 28.07 35.66726168133188 139.74185914511557 28.07 35.66721541929061 139.74194944226844 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f91b940-c7d2-4921-9f8d-9b78ebef0fa7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f91b940-c7d2-4921-9f8d-9b78ebef0fa7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f91b940-c7d2-4921-9f8d-9b78ebef0fa7">
											<gml:posList>35.667121801951595 139.74187730935583 51.2 35.6671230185448 139.74187696554813 51.2 35.66716843471166 139.74178860244137 51.2 35.66716815416085 139.74178712262218 51.2 35.667121801951595 139.74187730935583 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5961962a-5107-4413-bfba-74b33cda643e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5961962a-5107-4413-bfba-74b33cda643e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5961962a-5107-4413-bfba-74b33cda643e">
											<gml:posList>35.66717163199489 139.74191570301397 51.2 35.66717136045098 139.74191421213817 51.2 35.6671230185448 139.74187696554813 51.2 35.667121801951595 139.74187730935583 51.2 35.66717163199489 139.74191570301397 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05011227-50ca-4bcd-a24d-2a670e283d8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05011227-50ca-4bcd-a24d-2a670e283d8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05011227-50ca-4bcd-a24d-2a670e283d8c">
											<gml:posList>35.66716778690048 139.74183759137952 50.591 35.66718597669826 139.7418021135437 50.591 35.66716843471166 139.74178860244137 50.591 35.6671230185448 139.74187696554813 50.591 35.66717136045098 139.74191421213817 50.591 35.667198514671526 139.74186124960482 50.591 35.66716778690048 139.74183759137952 50.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ba5da491-578b-475d-b4ce-b730642a741a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ba5da491-578b-475d-b4ce-b730642a741a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ba5da491-578b-475d-b4ce-b730642a741a">
											<gml:posList>35.66716778690048 139.74183759137952 55.768 35.667169391008315 139.7418371477165 55.768 35.66718680677564 139.74180318404066 55.768 35.667186444723626 139.74180120725225 55.768 35.66716778690048 139.74183759137952 55.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c93fe4db-5b8b-4a2e-8861-36edbe3f0414">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c93fe4db-5b8b-4a2e-8861-36edbe3f0414">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c93fe4db-5b8b-4a2e-8861-36edbe3f0414">
											<gml:posList>35.667186444723626 139.74180120725225 51.2 35.66716815416085 139.74178712262218 51.2 35.66716843471166 139.74178860244137 51.2 35.66718597669826 139.7418021135437 51.2 35.667186444723626 139.74180120725225 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8fbbdb05-bbcf-4c6f-af66-219ec51da1a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fbbdb05-bbcf-4c6f-af66-219ec51da1a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fbbdb05-bbcf-4c6f-af66-219ec51da1a9">
											<gml:posList>35.66717163199489 139.74191570301397 48.2 35.66719242081254 139.74193171784484 48.2 35.66719213112399 139.7419300723478 48.2 35.66717215401124 139.7419146751578 48.2 35.66717163199489 139.74191570301397 48.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f2c7ebd-1191-4d4d-afc0-2e7a2e21f426">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f2c7ebd-1191-4d4d-afc0-2e7a2e21f426">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f2c7ebd-1191-4d4d-afc0-2e7a2e21f426">
											<gml:posList>35.66719926324725 139.74186182313363 55.768 35.66719889219086 139.74185985740067 55.768 35.667169391008315 139.7418371477165 55.768 35.66716778690048 139.74183759137952 55.768 35.66719926324725 139.74186182313363 55.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ad6cf741-fd3b-47af-b23b-9fabf25db5a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad6cf741-fd3b-47af-b23b-9fabf25db5a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad6cf741-fd3b-47af-b23b-9fabf25db5a6">
											<gml:posList>35.66717163199489 139.74191570301397 51.2 35.66719926324725 139.74186182313363 51.2 35.667198514671526 139.74186124960482 51.2 35.66717136045098 139.74191421213817 51.2 35.66717163199489 139.74191570301397 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b49244a7-17fe-45df-a6b2-1bcb3bf33242">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b49244a7-17fe-45df-a6b2-1bcb3bf33242">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b49244a7-17fe-45df-a6b2-1bcb3bf33242">
											<gml:posList>35.66721630797288 139.74182590476312 55.338 35.66718680677564 139.74180318404066 55.338 35.667169391008315 139.7418371477165 55.338 35.66719889219086 139.74185985740067 55.338 35.66721630797288 139.74182590476312 55.338</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-abc5bfb8-351e-40dd-9d24-f643de7fdab5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-abc5bfb8-351e-40dd-9d24-f643de7fdab5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-abc5bfb8-351e-40dd-9d24-f643de7fdab5">
											<gml:posList>35.667186444723626 139.74180120725225 55.768 35.66718680677564 139.74180318404066 55.768 35.66721630797288 139.74182590476312 55.768 35.66721792108601 139.7418254500435 55.768 35.667186444723626 139.74180120725225 55.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8eeae56e-387c-4482-ad28-a09909f6e330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8eeae56e-387c-4482-ad28-a09909f6e330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8eeae56e-387c-4482-ad28-a09909f6e330">
											<gml:posList>35.66719242081254 139.74193171784484 45.3 35.66721541929061 139.74194944226844 45.3 35.66721509343004 139.74194764217054 45.3 35.66719301487177 139.74193060153985 45.3 35.66719242081254 139.74193171784484 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71279d32-3c8d-4928-94fb-166c0676f72c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71279d32-3c8d-4928-94fb-166c0676f72c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71279d32-3c8d-4928-94fb-166c0676f72c">
											<gml:posList>35.667238720003425 139.74184287871446 47.796 35.6672173900567 139.7418264779111 47.796 35.66717215401124 139.7419146751578 47.796 35.66719213112399 139.7419300723478 47.796 35.667238720003425 139.74184287871446 47.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-46767919-3d17-45d4-8703-c89b4cc6478a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-46767919-3d17-45d4-8703-c89b4cc6478a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-46767919-3d17-45d4-8703-c89b4cc6478a">
											<gml:posList>35.66721792108601 139.7418254500435 55.768 35.66721630797288 139.74182590476312 55.768 35.66719889219086 139.74185985740067 55.768 35.66719926324725 139.74186182313363 55.768 35.66721792108601 139.7418254500435 55.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b808af59-ce87-4956-973b-8178c101c450">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b808af59-ce87-4956-973b-8178c101c450">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b808af59-ce87-4956-973b-8178c101c450">
											<gml:posList>35.667240080790975 139.74184250160374 48.2 35.667238720003425 139.74184287871446 48.2 35.66719213112399 139.7419300723478 48.2 35.66719242081254 139.74193171784484 48.2 35.667240080790975 139.74184250160374 48.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-18a403ba-f099-46df-88cb-59ca92e5d825">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18a403ba-f099-46df-88cb-59ca92e5d825">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18a403ba-f099-46df-88cb-59ca92e5d825">
											<gml:posList>35.667239468730294 139.74184365106808 44.933 35.66719301487177 139.74193060153985 44.933 35.66721509343004 139.74194764217054 44.933 35.667239468730294 139.74184365106808 44.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8290d142-5ae9-44ac-b3bd-7c5ea18c2718">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8290d142-5ae9-44ac-b3bd-7c5ea18c2718">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8290d142-5ae9-44ac-b3bd-7c5ea18c2718">
											<gml:posList>35.667238720003425 139.74184287871446 48.2 35.667240080790975 139.74184250160374 48.2 35.66721792108601 139.7418254500435 48.2 35.6672173900567 139.7418264779111 48.2 35.667238720003425 139.74184287871446 48.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-199428d3-2950-43d3-bf84-dc9640e39e81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-199428d3-2950-43d3-bf84-dc9640e39e81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-199428d3-2950-43d3-bf84-dc9640e39e81">
											<gml:posList>35.667239468730294 139.74184365106808 44.933 35.66721509343004 139.74194764217054 44.933 35.667260221426844 139.74185956652252 44.933 35.667239468730294 139.74184365106808 44.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-45a1ac2e-06bb-421c-bf0c-be27f6b31be2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45a1ac2e-06bb-421c-bf0c-be27f6b31be2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45a1ac2e-06bb-421c-bf0c-be27f6b31be2">
											<gml:posList>35.66726168133188 139.74185914511557 45.3 35.667260221426844 139.74185956652252 45.3 35.66721509343004 139.74194764217054 45.3 35.66721541929061 139.74194944226844 45.3 35.66726168133188 139.74185914511557 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5d78bd7-dc36-4805-ab98-9910067dded4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5d78bd7-dc36-4805-ab98-9910067dded4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5d78bd7-dc36-4805-ab98-9910067dded4">
											<gml:posList>35.667260221426844 139.74185956652252 45.3 35.66726168133188 139.74185914511557 45.3 35.667240080790975 139.74184250160374 45.3 35.667239468730294 139.74184365106808 45.3 35.667260221426844 139.74185956652252 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-af1e5ce1-1baf-43d3-a46c-bc5e6a6c22e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-af1e5ce1-1baf-43d3-a46c-bc5e6a6c22e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-af1e5ce1-1baf-43d3-a46c-bc5e6a6c22e9">
											<gml:posList>35.6671230185448 139.74187696554813 51.2 35.6671230185448 139.74187696554813 50.591 35.66716843471166 139.74178860244137 50.591 35.66716843471166 139.74178860244137 51.2 35.6671230185448 139.74187696554813 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38894b65-8e30-48dc-8d04-9b8874ee8c88">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38894b65-8e30-48dc-8d04-9b8874ee8c88">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38894b65-8e30-48dc-8d04-9b8874ee8c88">
											<gml:posList>35.667169391008315 139.7418371477165 55.768 35.667169391008315 139.7418371477165 55.338 35.66718680677564 139.74180318404066 55.338 35.66718680677564 139.74180318404066 55.768 35.667169391008315 139.7418371477165 55.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb96a416-3b58-4947-86bb-3e0dc1eed767">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb96a416-3b58-4947-86bb-3e0dc1eed767">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb96a416-3b58-4947-86bb-3e0dc1eed767">
											<gml:posList>35.66719889219086 139.74185985740067 55.768 35.66719889219086 139.74185985740067 55.338 35.667169391008315 139.7418371477165 55.338 35.667169391008315 139.7418371477165 55.768 35.66719889219086 139.74185985740067 55.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9546f4dd-404a-4028-9e5e-dd53a96e6cac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9546f4dd-404a-4028-9e5e-dd53a96e6cac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9546f4dd-404a-4028-9e5e-dd53a96e6cac">
											<gml:posList>35.66717136045098 139.74191421213817 50.591 35.66717136045098 139.74191421213817 51.2 35.667198514671526 139.74186124960482 51.2 35.667198514671526 139.74186124960482 50.591 35.66717136045098 139.74191421213817 50.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35697725-4880-4070-a8bf-4641afaffd12">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35697725-4880-4070-a8bf-4641afaffd12">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35697725-4880-4070-a8bf-4641afaffd12">
											<gml:posList>35.66718597669826 139.7418021135437 50.591 35.66718597669826 139.7418021135437 51.2 35.66716843471166 139.74178860244137 51.2 35.66716843471166 139.74178860244137 50.591 35.66718597669826 139.7418021135437 50.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1cd965ae-51f7-43a0-9815-ed7a5713d43d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cd965ae-51f7-43a0-9815-ed7a5713d43d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cd965ae-51f7-43a0-9815-ed7a5713d43d">
											<gml:posList>35.66718680677564 139.74180318404066 55.768 35.66718680677564 139.74180318404066 55.338 35.66721630797288 139.74182590476312 55.338 35.66721630797288 139.74182590476312 55.768 35.66718680677564 139.74180318404066 55.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-97f0989e-ea87-47ba-a9ab-2547bb71b238">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-97f0989e-ea87-47ba-a9ab-2547bb71b238">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-97f0989e-ea87-47ba-a9ab-2547bb71b238">
											<gml:posList>35.66716778690048 139.74183759137952 50.591 35.66716778690048 139.74183759137952 55.768 35.667186444723626 139.74180120725225 55.768 35.667186444723626 139.74180120725225 51.2 35.66718597669826 139.7418021135437 51.2 35.66718597669826 139.7418021135437 50.591 35.66716778690048 139.74183759137952 50.591</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8eea2ab7-1569-40de-9daa-00f5850532c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8eea2ab7-1569-40de-9daa-00f5850532c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8eea2ab7-1569-40de-9daa-00f5850532c8">
											<gml:posList>35.66726168133188 139.74185914511557 45.3 35.66726168133188 139.74185914511557 28.07 35.66716815416085 139.74178712262218 28.07 35.66716815416085 139.74178712262218 51.2 35.667186444723626 139.74180120725225 51.2 35.667186444723626 139.74180120725225 55.768 35.66721792108601 139.7418254500435 55.768 35.66721792108601 139.7418254500435 48.2 35.667240080790975 139.74184250160374 48.2 35.667240080790975 139.74184250160374 45.3 35.66726168133188 139.74185914511557 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c322d326-3ac0-46f7-a6aa-4cbc378c560e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c322d326-3ac0-46f7-a6aa-4cbc378c560e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c322d326-3ac0-46f7-a6aa-4cbc378c560e">
											<gml:posList>35.66716815416085 139.74178712262218 28.07 35.667121801951595 139.74187730935583 28.07 35.667121801951595 139.74187730935583 51.2 35.66716815416085 139.74178712262218 51.2 35.66716815416085 139.74178712262218 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c5330bd-e31f-460f-aaa0-96fb7a810858">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c5330bd-e31f-460f-aaa0-96fb7a810858">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c5330bd-e31f-460f-aaa0-96fb7a810858">
											<gml:posList>35.667238720003425 139.74184287871446 47.796 35.667238720003425 139.74184287871446 48.2 35.6672173900567 139.7418264779111 48.2 35.6672173900567 139.7418264779111 47.796 35.667238720003425 139.74184287871446 47.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2a9ba9d6-d71a-46d4-ab38-4906723686a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2a9ba9d6-d71a-46d4-ab38-4906723686a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2a9ba9d6-d71a-46d4-ab38-4906723686a1">
											<gml:posList>35.66721630797288 139.74182590476312 55.768 35.66721630797288 139.74182590476312 55.338 35.66719889219086 139.74185985740067 55.338 35.66719889219086 139.74185985740067 55.768 35.66721630797288 139.74182590476312 55.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a4f8909-e615-4c1b-acb7-0a2d64f7d413">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a4f8909-e615-4c1b-acb7-0a2d64f7d413">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a4f8909-e615-4c1b-acb7-0a2d64f7d413">
											<gml:posList>35.66719926324725 139.74186182313363 55.768 35.66716778690048 139.74183759137952 55.768 35.66716778690048 139.74183759137952 50.591 35.667198514671526 139.74186124960482 50.591 35.667198514671526 139.74186124960482 51.2 35.66719926324725 139.74186182313363 51.2 35.66719926324725 139.74186182313363 55.768</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d98b4b12-7cc9-4527-9ef7-504bcaaf2a28">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d98b4b12-7cc9-4527-9ef7-504bcaaf2a28">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d98b4b12-7cc9-4527-9ef7-504bcaaf2a28">
											<gml:posList>35.667260221426844 139.74185956652252 45.3 35.667239468730294 139.74184365106808 45.3 35.667239468730294 139.74184365106808 44.933 35.667260221426844 139.74185956652252 44.933 35.667260221426844 139.74185956652252 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69f16b83-e5e8-4a43-8945-b816ec004542">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69f16b83-e5e8-4a43-8945-b816ec004542">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69f16b83-e5e8-4a43-8945-b816ec004542">
											<gml:posList>35.6672173900567 139.7418264779111 48.2 35.66721792108601 139.7418254500435 48.2 35.66721792108601 139.7418254500435 55.768 35.66719926324725 139.74186182313363 55.768 35.66719926324725 139.74186182313363 51.2 35.66717163199489 139.74191570301397 51.2 35.66717163199489 139.74191570301397 48.2 35.66717215401124 139.7419146751578 48.2 35.66717215401124 139.7419146751578 47.796 35.6672173900567 139.7418264779111 47.796 35.6672173900567 139.7418264779111 48.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e43c60f-a6c9-4331-92d0-28c134e775bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e43c60f-a6c9-4331-92d0-28c134e775bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e43c60f-a6c9-4331-92d0-28c134e775bb">
											<gml:posList>35.667238720003425 139.74184287871446 48.2 35.667238720003425 139.74184287871446 47.796 35.66719213112399 139.7419300723478 47.796 35.66719213112399 139.7419300723478 48.2 35.667238720003425 139.74184287871446 48.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12616cba-ebb2-46f2-acbc-2cd465e117e1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12616cba-ebb2-46f2-acbc-2cd465e117e1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12616cba-ebb2-46f2-acbc-2cd465e117e1">
											<gml:posList>35.66719301487177 139.74193060153985 45.3 35.66719301487177 139.74193060153985 44.933 35.667239468730294 139.74184365106808 44.933 35.667239468730294 139.74184365106808 45.3 35.667240080790975 139.74184250160374 45.3 35.667240080790975 139.74184250160374 48.2 35.66719242081254 139.74193171784484 48.2 35.66719242081254 139.74193171784484 45.3 35.66719301487177 139.74193060153985 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d6685d43-a5e8-4cd6-b75a-7d1b052dead6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d6685d43-a5e8-4cd6-b75a-7d1b052dead6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d6685d43-a5e8-4cd6-b75a-7d1b052dead6">
											<gml:posList>35.66717136045098 139.74191421213817 51.2 35.66717136045098 139.74191421213817 50.591 35.6671230185448 139.74187696554813 50.591 35.6671230185448 139.74187696554813 51.2 35.66717136045098 139.74191421213817 51.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e07de90a-5e8b-451d-a7ac-b9c727ae0941">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e07de90a-5e8b-451d-a7ac-b9c727ae0941">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e07de90a-5e8b-451d-a7ac-b9c727ae0941">
											<gml:posList>35.667260221426844 139.74185956652252 45.3 35.667260221426844 139.74185956652252 44.933 35.66721509343004 139.74194764217054 44.933 35.66721509343004 139.74194764217054 45.3 35.667260221426844 139.74185956652252 45.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-11d85e5f-f0ee-46a9-a578-4760d82dc4ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11d85e5f-f0ee-46a9-a578-4760d82dc4ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11d85e5f-f0ee-46a9-a578-4760d82dc4ff">
											<gml:posList>35.66721541929061 139.74194944226844 28.07 35.66726168133188 139.74185914511557 28.07 35.66726168133188 139.74185914511557 45.3 35.66721541929061 139.74194944226844 45.3 35.66721541929061 139.74194944226844 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aef86b8b-2037-4e75-9f56-e172161cbbed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aef86b8b-2037-4e75-9f56-e172161cbbed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aef86b8b-2037-4e75-9f56-e172161cbbed">
											<gml:posList>35.66721541929061 139.74194944226844 28.07 35.66721541929061 139.74194944226844 45.3 35.66719242081254 139.74193171784484 45.3 35.66719242081254 139.74193171784484 48.2 35.66717163199489 139.74191570301397 48.2 35.66717163199489 139.74191570301397 51.2 35.667121801951595 139.74187730935583 51.2 35.667121801951595 139.74187730935583 28.07 35.66721541929061 139.74194944226844 28.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-68dc30cc-69df-4729-8c9e-cd93b2e177c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-68dc30cc-69df-4729-8c9e-cd93b2e177c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-68dc30cc-69df-4729-8c9e-cd93b2e177c1">
											<gml:posList>35.66717215401124 139.7419146751578 47.796 35.66717215401124 139.7419146751578 48.2 35.66719213112399 139.7419300723478 48.2 35.66719213112399 139.7419300723478 47.796 35.66717215401124 139.7419146751578 47.796</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53ae02f3-a795-4d5d-93c1-b1dbe44b3df2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53ae02f3-a795-4d5d-93c1-b1dbe44b3df2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53ae02f3-a795-4d5d-93c1-b1dbe44b3df2">
											<gml:posList>35.66719301487177 139.74193060153985 44.933 35.66719301487177 139.74193060153985 45.3 35.66721509343004 139.74194764217054 45.3 35.66721509343004 139.74194764217054 44.933 35.66719301487177 139.74193060153985 44.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8942</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">118.33445</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>