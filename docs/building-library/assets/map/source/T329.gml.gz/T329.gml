<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5e72c714-d32b-45d3-9694-5581f7498a76">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">15.5</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66701554282559 139.74627233197216 0 35.66716721864159 139.74636196978986 0 35.66719430048385 139.74629345632573 0 35.66704163430628 139.74620547655368 0 35.66701554282559 139.74627233197216 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66701554282559 139.74627233197216 7.618 35.66704163430628 139.74620547655368 7.618 35.66719430048385 139.74629345632573 7.618 35.66716721864159 139.74636196978986 7.618 35.66701554282559 139.74627233197216 7.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66701554282559 139.74627233197216 7.618 35.66716721864159 139.74636196978986 7.618 35.66716721864159 139.74636196978986 23.16 35.66701554282559 139.74627233197216 23.16 35.66701554282559 139.74627233197216 7.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716721864159 139.74636196978986 7.618 35.66719430048385 139.74629345632573 7.618 35.66719430048385 139.74629345632573 23.16 35.66716721864159 139.74636196978986 23.16 35.66716721864159 139.74636196978986 7.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66719430048385 139.74629345632573 7.618 35.66704163430628 139.74620547655368 7.618 35.66704163430628 139.74620547655368 23.16 35.66719430048385 139.74629345632573 23.16 35.66719430048385 139.74629345632573 7.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66704163430628 139.74620547655368 7.618 35.66701554282559 139.74627233197216 7.618 35.66701554282559 139.74627233197216 23.16 35.66704163430628 139.74620547655368 23.16 35.66704163430628 139.74620547655368 7.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66701554282559 139.74627233197216 23.16 35.66716721864159 139.74636196978986 23.16 35.66719430048385 139.74629345632573 23.16 35.66704163430628 139.74620547655368 23.16 35.66701554282559 139.74627233197216 23.16</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-1854ef4d-de0c-4814-999d-26aaa1cfa45f"/>
							<gml:surfaceMember xlink:href="#poly-636383ee-d683-4142-8182-d053d993b1ed"/>
							<gml:surfaceMember xlink:href="#poly-815a4a5e-4790-445d-8484-095b32316e52"/>
							<gml:surfaceMember xlink:href="#poly-98bbc854-b643-4cd5-9689-250c6080b5f8"/>
							<gml:surfaceMember xlink:href="#poly-219051f2-5229-4b85-ad0e-fdf76aa2438f"/>
							<gml:surfaceMember xlink:href="#poly-255f3bcc-a7b7-4601-a6ae-eb1a9a6d997c"/>
							<gml:surfaceMember xlink:href="#poly-4be2623f-64ac-460f-8d81-29530b6567bb"/>
							<gml:surfaceMember xlink:href="#poly-0ab2e2ac-3c0b-45de-ad28-d8ad891d4373"/>
							<gml:surfaceMember xlink:href="#poly-17fd21af-4699-411a-88df-4f95b6eda745"/>
							<gml:surfaceMember xlink:href="#poly-2339529a-1ff9-44a7-8dde-d19a8733d293"/>
							<gml:surfaceMember xlink:href="#poly-74232472-7fbf-4a4f-9861-086de6c1ddce"/>
							<gml:surfaceMember xlink:href="#poly-30eb43fc-2007-4d24-9b0b-f4c1c5c4d3df"/>
							<gml:surfaceMember xlink:href="#poly-c256448c-c2fe-4440-b686-8ba8296282e3"/>
							<gml:surfaceMember xlink:href="#poly-a22c80b4-bd7f-45e6-9634-e772d82b9fbc"/>
							<gml:surfaceMember xlink:href="#poly-4ef0e77a-ae4c-402c-b058-860973cc7cd7"/>
							<gml:surfaceMember xlink:href="#poly-30554fbb-2a23-441c-b4c0-933182b27e64"/>
							<gml:surfaceMember xlink:href="#poly-da7d4a9f-50fa-4e17-bf16-b3059b46abe9"/>
							<gml:surfaceMember xlink:href="#poly-9cf63b5b-3a5d-4e49-9846-fa3e30843e2f"/>
							<gml:surfaceMember xlink:href="#poly-b55d7647-0bac-4a32-9e2e-3731fae5cb60"/>
							<gml:surfaceMember xlink:href="#poly-8624b7dd-9725-4f92-a1f4-10719d3b5843"/>
							<gml:surfaceMember xlink:href="#poly-cdc3c214-c681-449c-af3a-8c8b20a63a4b"/>
							<gml:surfaceMember xlink:href="#poly-9a410bd8-18bb-464a-883a-5aa27b2f5fa6"/>
							<gml:surfaceMember xlink:href="#poly-37dbd274-281a-4e44-b11f-bbeeb3e79e07"/>
							<gml:surfaceMember xlink:href="#poly-45578597-c1b8-43f0-a9af-6972d285b2cc"/>
							<gml:surfaceMember xlink:href="#poly-4012ba04-71f6-4cb4-955e-d712996f8214"/>
							<gml:surfaceMember xlink:href="#poly-31e20703-f36b-4ff9-b05c-be38f5adee9f"/>
							<gml:surfaceMember xlink:href="#poly-01979828-6907-4553-ac76-680f45e238b4"/>
							<gml:surfaceMember xlink:href="#poly-4f6c5b60-14d6-4711-b128-34139de4143f"/>
							<gml:surfaceMember xlink:href="#poly-efac5d3b-dbc4-4e99-9cce-036aa5ae9d17"/>
							<gml:surfaceMember xlink:href="#poly-a42edb7f-b746-457f-946c-87c6b6507766"/>
							<gml:surfaceMember xlink:href="#poly-942980b3-2157-4b33-a6c4-05dbcff6c178"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5e72c714-d32b-45d3-9694-5581f7498a76_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3508c4c5-a20e-482b-baf4-a14fdfd04679">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667117325492086 139.74625925368312 25.759 35.66712929167834 139.74626611118438 25.759 35.667123848674144 139.74628036619112 25.759 35.66711188248869 139.7462735086882 25.759 35.667117325492086 139.74625925368312 25.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b7080b67-1a93-4db7-9b3a-44a37e3d6bc3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667149480086024 139.7462753125193 23.498 35.66716512557354 139.74628451879045 23.498 35.66716040207677 139.7462965749039 23.498 35.66714475658217 139.7462873575851 23.498 35.667149480086024 139.7462753125193 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35c66918-ef17-4e0f-b168-af876dd2fee5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35c66918-ef17-4e0f-b168-af876dd2fee5_0">
											<gml:posList>35.66712929167834 139.74626611118438 25.759 35.667117325492086 139.74625925368312 25.759 35.667117325492086 139.74625925368312 27.67 35.66712929167834 139.74626611118438 27.67 35.66712929167834 139.74626611118438 25.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3efa0e28-fa27-4d88-afca-be379c61e85d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3efa0e28-fa27-4d88-afca-be379c61e85d_0">
											<gml:posList>35.66711188248869 139.7462735086882 25.759 35.66711188248869 139.7462735086882 27.67 35.667117325492086 139.74625925368312 27.67 35.667117325492086 139.74625925368312 25.759 35.66711188248869 139.7462735086882 25.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2b3780f-85e5-4ff6-9262-e1f25e576087">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2b3780f-85e5-4ff6-9262-e1f25e576087_0">
											<gml:posList>35.667123848674144 139.74628036619112 27.67 35.66712929167834 139.74626611118438 27.67 35.667117325492086 139.74625925368312 27.67 35.66711188248869 139.7462735086882 27.67 35.667123848674144 139.74628036619112 27.67</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-655c3090-7c9a-4279-9062-d3c7d329d305">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-655c3090-7c9a-4279-9062-d3c7d329d305_0">
											<gml:posList>35.667123848674144 139.74628036619112 25.759 35.66712929167834 139.74626611118438 25.759 35.66712929167834 139.74626611118438 27.67 35.667123848674144 139.74628036619112 27.67 35.667123848674144 139.74628036619112 25.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33202786-fa7e-4012-b9b3-401d4bb26195">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33202786-fa7e-4012-b9b3-401d4bb26195_0">
											<gml:posList>35.66711188248869 139.7462735086882 25.759 35.667123848674144 139.74628036619112 25.759 35.667123848674144 139.74628036619112 27.67 35.66711188248869 139.7462735086882 27.67 35.66711188248869 139.7462735086882 25.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3879e52-c95c-42e0-b0af-cc35db4b7b9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3879e52-c95c-42e0-b0af-cc35db4b7b9e_0">
											<gml:posList>35.66716512557354 139.74628451879045 23.498 35.667149480086024 139.7462753125193 23.498 35.667149480086024 139.7462753125193 25.197 35.66716512557354 139.74628451879045 25.197 35.66716512557354 139.74628451879045 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b579d531-4aeb-4aa6-ad74-6bcdc2b9be87">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b579d531-4aeb-4aa6-ad74-6bcdc2b9be87_0">
											<gml:posList>35.66714475658217 139.7462873575851 23.498 35.66714475658217 139.7462873575851 25.197 35.667149480086024 139.7462753125193 25.197 35.667149480086024 139.7462753125193 23.498 35.66714475658217 139.7462873575851 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b798dbe-c9eb-4071-ae71-430d26e16162">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b798dbe-c9eb-4071-ae71-430d26e16162_0">
											<gml:posList>35.66716040207677 139.7462965749039 25.197 35.66716512557354 139.74628451879045 25.197 35.667149480086024 139.7462753125193 25.197 35.66714475658217 139.7462873575851 25.197 35.66716040207677 139.7462965749039 25.197</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70771ed6-af87-48a8-923b-c8bce914a12f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70771ed6-af87-48a8-923b-c8bce914a12f_0">
											<gml:posList>35.66716040207677 139.7462965749039 23.498 35.66716512557354 139.74628451879045 23.498 35.66716512557354 139.74628451879045 25.197 35.66716040207677 139.7462965749039 25.197 35.66716040207677 139.7462965749039 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99f8c4e8-70f3-4537-afbb-54f524abba47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99f8c4e8-70f3-4537-afbb-54f524abba47_0">
											<gml:posList>35.66714475658217 139.7462873575851 23.498 35.66716040207677 139.7462965749039 23.498 35.66716040207677 139.7462965749039 25.197 35.66714475658217 139.7462873575851 25.197 35.66714475658217 139.7462873575851 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5e72c714-d32b-45d3-9694-5581f7498a76_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59c614e4-1d31-44a6-9af7-69cd0d75ecc6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66703372383166 139.7462353529893 23.7 35.667020408178914 139.74626947687412 23.7 35.66701735123093 139.74626769077415 23.7 35.66703066688318 139.7462335668903 23.7 35.66703372383166 139.7462353529893 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d55c3b64-d452-4dcf-a908-71428daa2351">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667020408178914 139.74626947687412 23.498 35.66703372383166 139.7462353529893 23.498 35.66705187618569 139.7462460035168 23.498 35.66703856052199 139.74628011636182 23.498 35.667020408178914 139.74626947687412 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5e17c53-1e62-4a5c-86e6-7247772a3abb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715684125245 139.7463459204288 23.498 35.66713419811527 139.74633256851283 23.498 35.66714580447423 139.74630300836662 23.498 35.66716844761463 139.74631636027615 23.498 35.66715684125245 139.7463459204288 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a80ab528-7f85-4666-b81d-4dc93da0cd7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a80ab528-7f85-4666-b81d-4dc93da0cd7c_0">
											<gml:posList>35.667020408178914 139.74626947687412 23.7 35.66703372383166 139.7462353529893 23.7 35.66703372383166 139.7462353529893 23.498 35.667020408178914 139.74626947687412 23.498 35.667020408178914 139.74626947687412 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bf6ad08-9347-4651-a35e-c2a87670163d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bf6ad08-9347-4651-a35e-c2a87670163d_0">
											<gml:posList>35.66703066688318 139.7462335668903 23.7 35.66701735123093 139.74626769077415 23.7 35.66701735123093 139.74626769077415 24.86 35.66703066688318 139.7462335668903 24.86 35.66703066688318 139.7462335668903 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b0fa147-507b-4e4c-aa42-c5f0e4ddb01c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b0fa147-507b-4e4c-aa42-c5f0e4ddb01c_0">
											<gml:posList>35.667020408178914 139.74626947687412 23.7 35.667020408178914 139.74626947687412 23.498 35.66703856052199 139.74628011636182 23.498 35.66703856052199 139.74628011636182 24.86 35.66701735123093 139.74626769077415 24.86 35.66701735123093 139.74626769077415 23.7 35.667020408178914 139.74626947687412 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-19f7f9b1-772a-4911-b610-0d4777fff7f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-19f7f9b1-772a-4911-b610-0d4777fff7f0_0">
											<gml:posList>35.66705187618569 139.7462460035168 24.86 35.66703066688318 139.7462335668903 24.86 35.66701735123093 139.74626769077415 24.86 35.66703856052199 139.74628011636182 24.86 35.66705187618569 139.7462460035168 24.86</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28d6ad15-766c-4bdc-9092-235bb69805f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28d6ad15-766c-4bdc-9092-235bb69805f0_0">
											<gml:posList>35.66703372383166 139.7462353529893 23.7 35.66703066688318 139.7462335668903 23.7 35.66703066688318 139.7462335668903 24.86 35.66705187618569 139.7462460035168 24.86 35.66705187618569 139.7462460035168 23.498 35.66703372383166 139.7462353529893 23.498 35.66703372383166 139.7462353529893 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5816ffb-70df-45fe-9c36-1a89146d3635">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5816ffb-70df-45fe-9c36-1a89146d3635_0">
											<gml:posList>35.66705187618569 139.7462460035168 23.498 35.66705187618569 139.7462460035168 24.86 35.66703856052199 139.74628011636182 24.86 35.66703856052199 139.74628011636182 23.498 35.66705187618569 139.7462460035168 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e553882c-46b8-411e-a67e-fb0f92cc9832">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e553882c-46b8-411e-a67e-fb0f92cc9832_0">
											<gml:posList>35.66713419811527 139.74633256851283 23.498 35.66713419811527 139.74633256851283 24.646 35.66714580447423 139.74630300836662 24.646 35.66714580447423 139.74630300836662 23.498 35.66713419811527 139.74633256851283 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33fb07f8-6383-45eb-b431-7dfa3ed9dacb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33fb07f8-6383-45eb-b431-7dfa3ed9dacb_0">
											<gml:posList>35.66713419811527 139.74633256851283 23.498 35.66715684125245 139.7463459204288 23.498 35.66715684125245 139.7463459204288 24.646 35.66713419811527 139.74633256851283 24.646 35.66713419811527 139.74633256851283 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ea0abfa-6470-42b4-a6a9-5d4eeb601536">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ea0abfa-6470-42b4-a6a9-5d4eeb601536_0">
											<gml:posList>35.66714580447423 139.74630300836662 24.646 35.66713419811527 139.74633256851283 24.646 35.66715684125245 139.7463459204288 24.646 35.66716844761463 139.74631636027615 24.646 35.66714580447423 139.74630300836662 24.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af29c1b3-407f-46aa-896e-93e3b692bb62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af29c1b3-407f-46aa-896e-93e3b692bb62_0">
											<gml:posList>35.66714580447423 139.74630300836662 23.498 35.66714580447423 139.74630300836662 24.646 35.66716844761463 139.74631636027615 24.646 35.66716844761463 139.74631636027615 23.498 35.66714580447423 139.74630300836662 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc437648-81ea-43ac-a288-5bba06602eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc437648-81ea-43ac-a288-5bba06602eb2_0">
											<gml:posList>35.66715684125245 139.7463459204288 23.498 35.66716844761463 139.74631636027615 23.498 35.66716844761463 139.74631636027615 24.646 35.66715684125245 139.7463459204288 24.646 35.66715684125245 139.7463459204288 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-1854ef4d-de0c-4814-999d-26aaa1cfa45f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1854ef4d-de0c-4814-999d-26aaa1cfa45f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1854ef4d-de0c-4814-999d-26aaa1cfa45f">
											<gml:posList>35.66701554282558 139.74627233197216 7.618 35.66704163430627 139.74620547655365 7.618 35.667194300483814 139.7462934563257 7.618 35.66716721864157 139.74636196978986 7.618 35.66701554282558 139.74627233197216 7.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-636383ee-d683-4142-8182-d053d993b1ed">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-636383ee-d683-4142-8182-d053d993b1ed">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-636383ee-d683-4142-8182-d053d993b1ed">
											<gml:posList>35.66701554282558 139.74627233197216 23.7 35.667020048292606 139.74627039406604 23.7 35.66704323371628 139.74621097562436 23.7 35.66704163430627 139.74620547655365 23.7 35.66701554282558 139.74627233197216 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-815a4a5e-4790-445d-8484-095b32316e52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-815a4a5e-4790-445d-8484-095b32316e52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-815a4a5e-4790-445d-8484-095b32316e52">
											<gml:posList>35.66704163430627 139.74620547655365 23.7 35.66704323371628 139.74621097562436 23.7 35.66707467771856 139.74622908971796 23.7 35.667079174139154 139.74622710763455 23.7 35.66704163430627 139.74620547655365 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98bbc854-b643-4cd5-9689-250c6080b5f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98bbc854-b643-4cd5-9689-250c6080b5f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98bbc854-b643-4cd5-9689-250c6080b5f8">
											<gml:posList>35.66706634474303 139.74626055721808 26.665 35.66707118357404 139.74625842012352 26.665 35.66708091807943 139.74623303733767 26.665 35.667079174139154 139.74622710763455 26.665 35.66706634474303 139.74626055721808 26.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-219051f2-5229-4b85-ad0e-fdf76aa2438f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-219051f2-5229-4b85-ad0e-fdf76aa2438f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-219051f2-5229-4b85-ad0e-fdf76aa2438f">
											<gml:posList>35.6670777346511 139.74623085372616 23.7 35.667079174139154 139.74622710763455 23.7 35.66707467771856 139.74622908971796 23.7 35.6670777346511 139.74623085372616 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-255f3bcc-a7b7-4601-a6ae-eb1a9a6d997c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-255f3bcc-a7b7-4601-a6ae-eb1a9a6d997c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-255f3bcc-a7b7-4601-a6ae-eb1a9a6d997c">
											<gml:posList>35.66716721864157 139.74636196978986 23.7 35.66716563723401 139.74635642650483 23.7 35.667020048292606 139.74627039406604 23.7 35.66701554282558 139.74627233197216 23.7 35.66716721864157 139.74636196978986 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4be2623f-64ac-460f-8d81-29530b6567bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4be2623f-64ac-460f-8d81-29530b6567bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4be2623f-64ac-460f-8d81-29530b6567bb">
											<gml:posList>35.667131036241884 139.74629784390916 26.665 35.66712929229681 139.7462919031551 26.665 35.66707118357404 139.74625842012352 26.665 35.66706634474303 139.74626055721808 26.665 35.667131036241884 139.74629784390916 26.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ab2e2ac-3c0b-45de-ad28-d8ad891d4373">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ab2e2ac-3c0b-45de-ad28-d8ad891d4373">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ab2e2ac-3c0b-45de-ad28-d8ad891d4373">
											<gml:posList>35.66714548309094 139.7462699044097 23.498 35.667142435180715 139.74626815143458 23.498 35.667131036241884 139.74629784390916 23.498 35.66706634474303 139.74626055721808 23.498 35.6670777346511 139.74623085372616 23.498 35.66707467771856 139.74622908971796 23.498 35.66704323371628 139.74621097562436 23.498 35.667020048292606 139.74627039406604 23.498 35.66716563723401 139.74635642650483 23.498 35.66718975896961 139.74629540531978 23.498 35.66714548309094 139.7462699044097 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-17fd21af-4699-411a-88df-4f95b6eda745">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-17fd21af-4699-411a-88df-4f95b6eda745">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-17fd21af-4699-411a-88df-4f95b6eda745">
											<gml:posList>35.66713902680915 139.74626652035488 25.759 35.66708091807943 139.74623303733767 25.759 35.66707118357404 139.74625842012352 25.759 35.66712929229681 139.7462919031551 25.759 35.66713902680915 139.74626652035488 25.759</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2339529a-1ff9-44a7-8dde-d19a8733d293">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2339529a-1ff9-44a7-8dde-d19a8733d293">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2339529a-1ff9-44a7-8dde-d19a8733d293">
											<gml:posList>35.667079174139154 139.74622710763455 26.665 35.66708091807943 139.74623303733767 26.665 35.66713902680915 139.74626652035488 26.665 35.667143874661924 139.7462643942948 26.665 35.667079174139154 139.74622710763455 26.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-74232472-7fbf-4a4f-9861-086de6c1ddce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74232472-7fbf-4a4f-9861-086de6c1ddce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74232472-7fbf-4a4f-9861-086de6c1ddce">
											<gml:posList>35.667143874661924 139.7462643942948 26.665 35.66713902680915 139.74626652035488 26.665 35.66712929229681 139.7462919031551 26.665 35.667131036241884 139.74629784390916 26.665 35.667143874661924 139.7462643942948 26.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-30eb43fc-2007-4d24-9b0b-f4c1c5c4d3df">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30eb43fc-2007-4d24-9b0b-f4c1c5c4d3df">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30eb43fc-2007-4d24-9b0b-f4c1c5c4d3df">
											<gml:posList>35.667194300483814 139.7462934563257 23.7 35.667143874661924 139.7462643942948 23.7 35.667142435180715 139.74626815143458 23.7 35.66714548309094 139.7462699044097 23.7 35.66718975896961 139.74629540531978 23.7 35.667194300483814 139.7462934563257 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c256448c-c2fe-4440-b686-8ba8296282e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c256448c-c2fe-4440-b686-8ba8296282e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c256448c-c2fe-4440-b686-8ba8296282e3">
											<gml:posList>35.667194300483814 139.7462934563257 23.7 35.66718975896961 139.74629540531978 23.7 35.66716563723401 139.74635642650483 23.7 35.66716721864157 139.74636196978986 23.7 35.667194300483814 139.7462934563257 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a22c80b4-bd7f-45e6-9634-e772d82b9fbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a22c80b4-bd7f-45e6-9634-e772d82b9fbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a22c80b4-bd7f-45e6-9634-e772d82b9fbc">
											<gml:posList>35.66716563723401 139.74635642650483 23.7 35.66716563723401 139.74635642650483 23.498 35.667020048292606 139.74627039406604 23.498 35.667020048292606 139.74627039406604 23.7 35.66716563723401 139.74635642650483 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ef0e77a-ae4c-402c-b058-860973cc7cd7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ef0e77a-ae4c-402c-b058-860973cc7cd7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ef0e77a-ae4c-402c-b058-860973cc7cd7">
											<gml:posList>35.66712929229681 139.7462919031551 26.665 35.66712929229681 139.7462919031551 25.759 35.66707118357404 139.74625842012352 25.759 35.66707118357404 139.74625842012352 26.665 35.66712929229681 139.7462919031551 26.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30554fbb-2a23-441c-b4c0-933182b27e64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30554fbb-2a23-441c-b4c0-933182b27e64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30554fbb-2a23-441c-b4c0-933182b27e64">
											<gml:posList>35.66708091807943 139.74623303733767 26.665 35.66708091807943 139.74623303733767 25.759 35.66713902680915 139.74626652035488 25.759 35.66713902680915 139.74626652035488 26.665 35.66708091807943 139.74623303733767 26.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-da7d4a9f-50fa-4e17-bf16-b3059b46abe9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-da7d4a9f-50fa-4e17-bf16-b3059b46abe9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-da7d4a9f-50fa-4e17-bf16-b3059b46abe9">
											<gml:posList>35.667142435180715 139.74626815143458 23.7 35.667142435180715 139.74626815143458 23.498 35.66714548309094 139.7462699044097 23.498 35.66714548309094 139.7462699044097 23.7 35.667142435180715 139.74626815143458 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cf63b5b-3a5d-4e49-9846-fa3e30843e2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cf63b5b-3a5d-4e49-9846-fa3e30843e2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cf63b5b-3a5d-4e49-9846-fa3e30843e2f">
											<gml:posList>35.66714548309094 139.7462699044097 23.7 35.66714548309094 139.7462699044097 23.498 35.66718975896961 139.74629540531978 23.498 35.66718975896961 139.74629540531978 23.7 35.66714548309094 139.7462699044097 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b55d7647-0bac-4a32-9e2e-3731fae5cb60">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b55d7647-0bac-4a32-9e2e-3731fae5cb60">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b55d7647-0bac-4a32-9e2e-3731fae5cb60">
											<gml:posList>35.66704163430627 139.74620547655365 7.618 35.66701554282558 139.74627233197216 7.618 35.66701554282558 139.74627233197216 23.7 35.66704163430627 139.74620547655365 23.7 35.66704163430627 139.74620547655365 7.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8624b7dd-9725-4f92-a1f4-10719d3b5843">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8624b7dd-9725-4f92-a1f4-10719d3b5843">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8624b7dd-9725-4f92-a1f4-10719d3b5843">
											<gml:posList>35.667020048292606 139.74627039406604 23.7 35.667020048292606 139.74627039406604 23.498 35.66704323371628 139.74621097562436 23.498 35.66704323371628 139.74621097562436 23.7 35.667020048292606 139.74627039406604 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cdc3c214-c681-449c-af3a-8c8b20a63a4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cdc3c214-c681-449c-af3a-8c8b20a63a4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cdc3c214-c681-449c-af3a-8c8b20a63a4b">
											<gml:posList>35.66704323371628 139.74621097562436 23.7 35.66704323371628 139.74621097562436 23.498 35.66707467771856 139.74622908971796 23.498 35.66707467771856 139.74622908971796 23.7 35.66704323371628 139.74621097562436 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9a410bd8-18bb-464a-883a-5aa27b2f5fa6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a410bd8-18bb-464a-883a-5aa27b2f5fa6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a410bd8-18bb-464a-883a-5aa27b2f5fa6">
											<gml:posList>35.6670777346511 139.74623085372616 23.7 35.6670777346511 139.74623085372616 23.498 35.66706634474303 139.74626055721808 23.498 35.66706634474303 139.74626055721808 26.665 35.667079174139154 139.74622710763455 26.665 35.667079174139154 139.74622710763455 23.7 35.6670777346511 139.74623085372616 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-37dbd274-281a-4e44-b11f-bbeeb3e79e07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-37dbd274-281a-4e44-b11f-bbeeb3e79e07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-37dbd274-281a-4e44-b11f-bbeeb3e79e07">
											<gml:posList>35.66707118357404 139.74625842012352 26.665 35.66707118357404 139.74625842012352 25.759 35.66708091807943 139.74623303733767 25.759 35.66708091807943 139.74623303733767 26.665 35.66707118357404 139.74625842012352 26.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45578597-c1b8-43f0-a9af-6972d285b2cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45578597-c1b8-43f0-a9af-6972d285b2cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45578597-c1b8-43f0-a9af-6972d285b2cc">
											<gml:posList>35.66707467771856 139.74622908971796 23.7 35.66707467771856 139.74622908971796 23.498 35.6670777346511 139.74623085372616 23.498 35.6670777346511 139.74623085372616 23.7 35.66707467771856 139.74622908971796 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4012ba04-71f6-4cb4-955e-d712996f8214">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4012ba04-71f6-4cb4-955e-d712996f8214">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4012ba04-71f6-4cb4-955e-d712996f8214">
											<gml:posList>35.66701554282558 139.74627233197216 7.618 35.66716721864157 139.74636196978986 7.618 35.66716721864157 139.74636196978986 23.7 35.66701554282558 139.74627233197216 23.7 35.66701554282558 139.74627233197216 7.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-31e20703-f36b-4ff9-b05c-be38f5adee9f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-31e20703-f36b-4ff9-b05c-be38f5adee9f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-31e20703-f36b-4ff9-b05c-be38f5adee9f">
											<gml:posList>35.66706634474303 139.74626055721808 23.498 35.667131036241884 139.74629784390916 23.498 35.667131036241884 139.74629784390916 26.665 35.66706634474303 139.74626055721808 26.665 35.66706634474303 139.74626055721808 23.498</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-01979828-6907-4553-ac76-680f45e238b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-01979828-6907-4553-ac76-680f45e238b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-01979828-6907-4553-ac76-680f45e238b4">
											<gml:posList>35.667079174139154 139.74622710763455 23.7 35.667079174139154 139.74622710763455 26.665 35.667143874661924 139.7462643942948 26.665 35.667143874661924 139.7462643942948 23.7 35.667194300483814 139.7462934563257 23.7 35.667194300483814 139.7462934563257 7.618 35.66704163430627 139.74620547655365 7.618 35.66704163430627 139.74620547655365 23.7 35.667079174139154 139.74622710763455 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f6c5b60-14d6-4711-b128-34139de4143f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f6c5b60-14d6-4711-b128-34139de4143f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f6c5b60-14d6-4711-b128-34139de4143f">
											<gml:posList>35.66713902680915 139.74626652035488 26.665 35.66713902680915 139.74626652035488 25.759 35.66712929229681 139.7462919031551 25.759 35.66712929229681 139.7462919031551 26.665 35.66713902680915 139.74626652035488 26.665</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efac5d3b-dbc4-4e99-9cce-036aa5ae9d17">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efac5d3b-dbc4-4e99-9cce-036aa5ae9d17">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efac5d3b-dbc4-4e99-9cce-036aa5ae9d17">
											<gml:posList>35.667142435180715 139.74626815143458 23.7 35.667143874661924 139.7462643942948 23.7 35.667143874661924 139.7462643942948 26.665 35.667131036241884 139.74629784390916 26.665 35.667131036241884 139.74629784390916 23.498 35.667142435180715 139.74626815143458 23.498 35.667142435180715 139.74626815143458 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a42edb7f-b746-457f-946c-87c6b6507766">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a42edb7f-b746-457f-946c-87c6b6507766">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a42edb7f-b746-457f-946c-87c6b6507766">
											<gml:posList>35.66718975896961 139.74629540531978 23.7 35.66718975896961 139.74629540531978 23.498 35.66716563723401 139.74635642650483 23.498 35.66716563723401 139.74635642650483 23.7 35.66718975896961 139.74629540531978 23.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-942980b3-2157-4b33-a6c4-05dbcff6c178">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-942980b3-2157-4b33-a6c4-05dbcff6c178">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-942980b3-2157-4b33-a6c4-05dbcff6c178">
											<gml:posList>35.66716721864157 139.74636196978986 7.618 35.667194300483814 139.7462934563257 7.618 35.667194300483814 139.7462934563257 23.7 35.66716721864157 139.74636196978986 23.7 35.66716721864157 139.74636196978986 7.618</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11436</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">127.1619</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.02</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>