<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_5ef91010-44b4-41f1-ae1e-38250461106b">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>8</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13101008003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">57.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>14</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67006189058981 139.74787470224118 0 35.67006864523877 139.74786674176528 0 35.6700769454704 139.74787744774946 0 35.670144582545646 139.74779850559455 0 35.670136733464204 139.74778846190176 0 35.670147180752146 139.74777629990433 0 35.6698659584223 139.74740511664476 0 35.6698525391641 139.74742081661233 0 35.6698427955133 139.74740845532435 0 35.669774077988365 139.74748872420838 0 35.669782468391126 139.74749943001757 0 35.66976589683566 139.74751866810323 0 35.6697859257241 139.7475444947237 0 35.6697223416852 139.74761879301522 0 35.66984973206305 139.74778258224626 0 35.66985756748985 139.7477734055497 0 35.669869990792854 139.74778944240654 0 35.66984002697636 139.74782445764546 0 35.670105633103155 139.74816572357688 0 35.670120223304586 139.74814869689322 0 35.67012924523415 139.74816028584485 0 35.67019751290782 139.7480805699698 0 35.67018885191074 139.74806953294518 0 35.67020182103597 139.74805449627297 0 35.67006189058981 139.74787470224118 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006189058981 139.74787470224118 6.23 35.67020182103597 139.74805449627297 6.23 35.67018885191074 139.74806953294518 6.23 35.67019751290782 139.7480805699698 6.23 35.67012924523415 139.74816028584485 6.23 35.670120223304586 139.74814869689322 6.23 35.670105633103155 139.74816572357688 6.23 35.66984002697636 139.74782445764546 6.23 35.669869990792854 139.74778944240654 6.23 35.66985756748985 139.7477734055497 6.23 35.66984973206305 139.74778258224626 6.23 35.6697223416852 139.74761879301522 6.23 35.6697859257241 139.7475444947237 6.23 35.66976589683566 139.74751866810323 6.23 35.669782468391126 139.74749943001757 6.23 35.669774077988365 139.74748872420838 6.23 35.6698427955133 139.74740845532435 6.23 35.6698525391641 139.74742081661233 6.23 35.6698659584223 139.74740511664476 6.23 35.670147180752146 139.74777629990433 6.23 35.670136733464204 139.74778846190176 6.23 35.670144582545646 139.74779850559455 6.23 35.6700769454704 139.74787744774946 6.23 35.67006864523877 139.74786674176528 6.23 35.67006189058981 139.74787470224118 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006189058981 139.74787470224118 6.23 35.67006864523877 139.74786674176528 6.23 35.67006864523877 139.74786674176528 57.900000000000006 35.67006189058981 139.74787470224118 57.900000000000006 35.67006189058981 139.74787470224118 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006864523877 139.74786674176528 6.23 35.6700769454704 139.74787744774946 6.23 35.6700769454704 139.74787744774946 57.900000000000006 35.67006864523877 139.74786674176528 57.900000000000006 35.67006864523877 139.74786674176528 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6700769454704 139.74787744774946 6.23 35.670144582545646 139.74779850559455 6.23 35.670144582545646 139.74779850559455 57.900000000000006 35.6700769454704 139.74787744774946 57.900000000000006 35.6700769454704 139.74787744774946 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670144582545646 139.74779850559455 6.23 35.670136733464204 139.74778846190176 6.23 35.670136733464204 139.74778846190176 57.900000000000006 35.670144582545646 139.74779850559455 57.900000000000006 35.670144582545646 139.74779850559455 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670136733464204 139.74778846190176 6.23 35.670147180752146 139.74777629990433 6.23 35.670147180752146 139.74777629990433 57.900000000000006 35.670136733464204 139.74778846190176 57.900000000000006 35.670136733464204 139.74778846190176 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670147180752146 139.74777629990433 6.23 35.6698659584223 139.74740511664476 6.23 35.6698659584223 139.74740511664476 57.900000000000006 35.670147180752146 139.74777629990433 57.900000000000006 35.670147180752146 139.74777629990433 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698659584223 139.74740511664476 6.23 35.6698525391641 139.74742081661233 6.23 35.6698525391641 139.74742081661233 57.900000000000006 35.6698659584223 139.74740511664476 57.900000000000006 35.6698659584223 139.74740511664476 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698525391641 139.74742081661233 6.23 35.6698427955133 139.74740845532435 6.23 35.6698427955133 139.74740845532435 57.900000000000006 35.6698525391641 139.74742081661233 57.900000000000006 35.6698525391641 139.74742081661233 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698427955133 139.74740845532435 6.23 35.669774077988365 139.74748872420838 6.23 35.669774077988365 139.74748872420838 57.900000000000006 35.6698427955133 139.74740845532435 57.900000000000006 35.6698427955133 139.74740845532435 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669774077988365 139.74748872420838 6.23 35.669782468391126 139.74749943001757 6.23 35.669782468391126 139.74749943001757 57.900000000000006 35.669774077988365 139.74748872420838 57.900000000000006 35.669774077988365 139.74748872420838 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669782468391126 139.74749943001757 6.23 35.66976589683566 139.74751866810323 6.23 35.66976589683566 139.74751866810323 57.900000000000006 35.669782468391126 139.74749943001757 57.900000000000006 35.669782468391126 139.74749943001757 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66976589683566 139.74751866810323 6.23 35.6697859257241 139.7475444947237 6.23 35.6697859257241 139.7475444947237 57.900000000000006 35.66976589683566 139.74751866810323 57.900000000000006 35.66976589683566 139.74751866810323 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6697859257241 139.7475444947237 6.23 35.6697223416852 139.74761879301522 6.23 35.6697223416852 139.74761879301522 57.900000000000006 35.6697859257241 139.7475444947237 57.900000000000006 35.6697859257241 139.7475444947237 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6697223416852 139.74761879301522 6.23 35.66984973206305 139.74778258224626 6.23 35.66984973206305 139.74778258224626 57.900000000000006 35.6697223416852 139.74761879301522 57.900000000000006 35.6697223416852 139.74761879301522 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66984973206305 139.74778258224626 6.23 35.66985756748985 139.7477734055497 6.23 35.66985756748985 139.7477734055497 57.900000000000006 35.66984973206305 139.74778258224626 57.900000000000006 35.66984973206305 139.74778258224626 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66985756748985 139.7477734055497 6.23 35.669869990792854 139.74778944240654 6.23 35.669869990792854 139.74778944240654 57.900000000000006 35.66985756748985 139.7477734055497 57.900000000000006 35.66985756748985 139.7477734055497 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669869990792854 139.74778944240654 6.23 35.66984002697636 139.74782445764546 6.23 35.66984002697636 139.74782445764546 57.900000000000006 35.669869990792854 139.74778944240654 57.900000000000006 35.669869990792854 139.74778944240654 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66984002697636 139.74782445764546 6.23 35.670105633103155 139.74816572357688 6.23 35.670105633103155 139.74816572357688 57.900000000000006 35.66984002697636 139.74782445764546 57.900000000000006 35.66984002697636 139.74782445764546 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670105633103155 139.74816572357688 6.23 35.670120223304586 139.74814869689322 6.23 35.670120223304586 139.74814869689322 57.900000000000006 35.670105633103155 139.74816572357688 57.900000000000006 35.670105633103155 139.74816572357688 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670120223304586 139.74814869689322 6.23 35.67012924523415 139.74816028584485 6.23 35.67012924523415 139.74816028584485 57.900000000000006 35.670120223304586 139.74814869689322 57.900000000000006 35.670120223304586 139.74814869689322 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67012924523415 139.74816028584485 6.23 35.67019751290782 139.7480805699698 6.23 35.67019751290782 139.7480805699698 57.900000000000006 35.67012924523415 139.74816028584485 57.900000000000006 35.67012924523415 139.74816028584485 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67019751290782 139.7480805699698 6.23 35.67018885191074 139.74806953294518 6.23 35.67018885191074 139.74806953294518 57.900000000000006 35.67019751290782 139.7480805699698 57.900000000000006 35.67019751290782 139.7480805699698 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67018885191074 139.74806953294518 6.23 35.67020182103597 139.74805449627297 6.23 35.67020182103597 139.74805449627297 57.900000000000006 35.67018885191074 139.74806953294518 57.900000000000006 35.67018885191074 139.74806953294518 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67020182103597 139.74805449627297 6.23 35.67006189058981 139.74787470224118 6.23 35.67006189058981 139.74787470224118 57.900000000000006 35.67020182103597 139.74805449627297 57.900000000000006 35.67020182103597 139.74805449627297 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67006189058981 139.74787470224118 57.900000000000006 35.67006864523877 139.74786674176528 57.900000000000006 35.6700769454704 139.74787744774946 57.900000000000006 35.670144582545646 139.74779850559455 57.900000000000006 35.670136733464204 139.74778846190176 57.900000000000006 35.670147180752146 139.74777629990433 57.900000000000006 35.6698659584223 139.74740511664476 57.900000000000006 35.6698525391641 139.74742081661233 57.900000000000006 35.6698427955133 139.74740845532435 57.900000000000006 35.669774077988365 139.74748872420838 57.900000000000006 35.669782468391126 139.74749943001757 57.900000000000006 35.66976589683566 139.74751866810323 57.900000000000006 35.6697859257241 139.7475444947237 57.900000000000006 35.6697223416852 139.74761879301522 57.900000000000006 35.66984973206305 139.74778258224626 57.900000000000006 35.66985756748985 139.7477734055497 57.900000000000006 35.669869990792854 139.74778944240654 57.900000000000006 35.66984002697636 139.74782445764546 57.900000000000006 35.670105633103155 139.74816572357688 57.900000000000006 35.670120223304586 139.74814869689322 57.900000000000006 35.67012924523415 139.74816028584485 57.900000000000006 35.67019751290782 139.7480805699698 57.900000000000006 35.67018885191074 139.74806953294518 57.900000000000006 35.67020182103597 139.74805449627297 57.900000000000006 35.67006189058981 139.74787470224118 57.900000000000006</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-9e53f95c-a872-4762-8b35-696247f97b5f"/>
							<gml:surfaceMember xlink:href="#poly-9a8eba84-6d89-4f23-bf68-6e4b644114ef"/>
							<gml:surfaceMember xlink:href="#poly-bc8329a5-36ed-4784-b3b5-095d34909ce8"/>
							<gml:surfaceMember xlink:href="#poly-e6b220b5-54eb-4dc3-af1a-46b72ff495b0"/>
							<gml:surfaceMember xlink:href="#poly-8f614d9c-cf64-46ed-a504-03f1e31b8a72"/>
							<gml:surfaceMember xlink:href="#poly-984494b3-a968-4d6d-8ac7-e1c34f9f76f9"/>
							<gml:surfaceMember xlink:href="#poly-9cb58684-04c0-4053-b688-a6fb0ee4c931"/>
							<gml:surfaceMember xlink:href="#poly-ec9a0068-c0c7-4946-a381-a067c2cf3c54"/>
							<gml:surfaceMember xlink:href="#poly-faa087f8-3d19-4282-9cca-914a974fbe86"/>
							<gml:surfaceMember xlink:href="#poly-4aa7316a-7c0f-4994-850b-1e190cd6177d"/>
							<gml:surfaceMember xlink:href="#poly-82deefb6-48e6-43d5-ac85-e4732e2878c7"/>
							<gml:surfaceMember xlink:href="#poly-2390376f-ba55-4436-bbd4-1b25be25b548"/>
							<gml:surfaceMember xlink:href="#poly-50db96bc-551e-4f51-9ead-9a12b8c5fdb9"/>
							<gml:surfaceMember xlink:href="#poly-f23d5961-6a24-4cbf-af91-ec45e463a988"/>
							<gml:surfaceMember xlink:href="#poly-d367b190-3758-40aa-be0a-3f7098ddddb5"/>
							<gml:surfaceMember xlink:href="#poly-d7eb142d-1bc6-44fa-8f76-6ee6ad78323c"/>
							<gml:surfaceMember xlink:href="#poly-2d9f8b26-58a2-47c1-ad1c-7c671707ad05"/>
							<gml:surfaceMember xlink:href="#poly-9e2df9d7-aba0-4980-ad35-fe76fa10e793"/>
							<gml:surfaceMember xlink:href="#poly-d71fa8cc-cb4a-4310-a0b9-0cf23f45cd52"/>
							<gml:surfaceMember xlink:href="#poly-55b9b92d-3a05-4de2-8c9b-9c9ecb14fe43"/>
							<gml:surfaceMember xlink:href="#poly-1ac4e09f-2334-411b-a167-3b8cb552cfc6"/>
							<gml:surfaceMember xlink:href="#poly-e5479f0f-341c-447c-a985-d1644fed30a9"/>
							<gml:surfaceMember xlink:href="#poly-352e5635-9f59-40b9-849a-0d6c3cd16330"/>
							<gml:surfaceMember xlink:href="#poly-4e7e693e-5d43-4308-a2df-dd24d387f5fd"/>
							<gml:surfaceMember xlink:href="#poly-0e0f8e65-ded2-4e68-ad4b-56a908403875"/>
							<gml:surfaceMember xlink:href="#poly-09f571c3-11b7-4cf1-86b3-7758ec1e48f7"/>
							<gml:surfaceMember xlink:href="#poly-8942334c-0c9a-4a42-a9ef-1d7a553b8161"/>
							<gml:surfaceMember xlink:href="#poly-adac6feb-7681-4009-94dc-015ecc099a74"/>
							<gml:surfaceMember xlink:href="#poly-ed77eefd-934f-47b3-add2-a1d2b1ace7d0"/>
							<gml:surfaceMember xlink:href="#poly-e1d7ed1d-0e29-47f4-abd8-9b0be45ddb70"/>
							<gml:surfaceMember xlink:href="#poly-926f0a42-5955-4801-8c7f-4ba265151f56"/>
							<gml:surfaceMember xlink:href="#poly-904e6272-18f0-4fc0-b834-9d70d02a9f7e"/>
							<gml:surfaceMember xlink:href="#poly-f7949d4c-f3e9-4e9e-85e4-1116ab37be08"/>
							<gml:surfaceMember xlink:href="#poly-1a105b8f-3cc2-492d-abca-78ef9aef17de"/>
							<gml:surfaceMember xlink:href="#poly-eef9a495-ebe7-479b-9cde-4a15a05b8484"/>
							<gml:surfaceMember xlink:href="#poly-42bd0ac4-e471-4827-b6d9-46fdde6028a0"/>
							<gml:surfaceMember xlink:href="#poly-71b34b6f-352b-4f32-ac25-06c077149766"/>
							<gml:surfaceMember xlink:href="#poly-9acf5595-ad5c-4637-b6b8-e3d4834bfa06"/>
							<gml:surfaceMember xlink:href="#poly-91fdfb08-4ea2-423d-918e-e524c674742e"/>
							<gml:surfaceMember xlink:href="#poly-feaaea18-50c5-4e47-b53e-68e1a6ccc269"/>
							<gml:surfaceMember xlink:href="#poly-e1dc3a94-6fd7-473f-920c-c665647c7041"/>
							<gml:surfaceMember xlink:href="#poly-1c51afde-3d38-4db1-b62d-5bee0f2369a0"/>
							<gml:surfaceMember xlink:href="#poly-41fce141-dcb7-4b7e-8b7d-3358af6a90a0"/>
							<gml:surfaceMember xlink:href="#poly-a82710ad-528e-4ee2-bc46-fdfe8f3ea6d7"/>
							<gml:surfaceMember xlink:href="#poly-24355b6e-623a-4606-8b92-2a97376c5d06"/>
							<gml:surfaceMember xlink:href="#poly-c0a695fd-8dea-444e-bbb2-4be4e3e22f20"/>
							<gml:surfaceMember xlink:href="#poly-cf23f610-7b2d-4de0-8d34-69133bdb69a5"/>
							<gml:surfaceMember xlink:href="#poly-6f8a5825-87d9-4cdc-b21a-5acd17b49184"/>
							<gml:surfaceMember xlink:href="#poly-e8042b85-0836-4cff-9737-e74bba42201f"/>
							<gml:surfaceMember xlink:href="#poly-3d2aaa8f-b62a-4dba-88e7-a004ac3d88ca"/>
							<gml:surfaceMember xlink:href="#poly-f631d435-4941-417b-a10f-b7930cc2b141"/>
							<gml:surfaceMember xlink:href="#poly-47afabd5-19a7-4237-b154-0c8f33c87707"/>
							<gml:surfaceMember xlink:href="#poly-915bcea9-e95a-428f-b046-10b1790cf27f"/>
							<gml:surfaceMember xlink:href="#poly-4cf2b215-5e9f-4015-8871-9603a0bdd62c"/>
							<gml:surfaceMember xlink:href="#poly-8819d459-15d1-4931-b7b8-d8bdc295b536"/>
							<gml:surfaceMember xlink:href="#poly-9b6b8a66-d3ee-4a18-a6a9-b4ae1322cfcf"/>
							<gml:surfaceMember xlink:href="#poly-455c549a-c3c0-4e27-88bd-e8ae767f3703"/>
							<gml:surfaceMember xlink:href="#poly-f7897122-d983-4610-8302-01fe1ac4896c"/>
							<gml:surfaceMember xlink:href="#poly-7532bb37-5b31-4954-94c5-8b065b9a018a"/>
							<gml:surfaceMember xlink:href="#poly-739c80bb-ae8e-4b6e-84fa-d45bc79bc7cf"/>
							<gml:surfaceMember xlink:href="#poly-ab92e6b4-8c6e-4927-a618-965a373ce703"/>
							<gml:surfaceMember xlink:href="#poly-e66a8823-34b5-41cd-b8dc-2c614ed8dce5"/>
							<gml:surfaceMember xlink:href="#poly-52ce875e-a15a-47ea-ad62-c1c6355e5d15"/>
							<gml:surfaceMember xlink:href="#poly-6f0c3838-fb82-41bf-a41f-ab0919b052c0"/>
							<gml:surfaceMember xlink:href="#poly-34eb6228-781f-4c0c-9cdc-9bb5337f07a1"/>
							<gml:surfaceMember xlink:href="#poly-8460100f-fe23-415d-ad13-fe1bd828a79d"/>
							<gml:surfaceMember xlink:href="#poly-c7ae42a5-c7a8-449c-89c7-efa5bf492cd9"/>
							<gml:surfaceMember xlink:href="#poly-ebe42325-e1c2-44b4-a71c-3f1268350947"/>
							<gml:surfaceMember xlink:href="#poly-ebf31d8e-4e73-43bd-a101-44ab79a74e30"/>
							<gml:surfaceMember xlink:href="#poly-959a9e56-fd6a-42df-a54a-ce686a53755e"/>
							<gml:surfaceMember xlink:href="#poly-8a27a1af-c777-4008-ad3a-b8fd416dfc4e"/>
							<gml:surfaceMember xlink:href="#poly-8c07426b-1fbd-40bd-83cb-0bf3439b963a"/>
							<gml:surfaceMember xlink:href="#poly-bb119cec-6f36-414f-9c05-4e0d81816c01"/>
							<gml:surfaceMember xlink:href="#poly-81ab6a3b-e936-4082-bf41-5ee4e76522ab"/>
							<gml:surfaceMember xlink:href="#poly-e32ac4d3-e94c-4682-95ad-94a08c50cf47"/>
							<gml:surfaceMember xlink:href="#poly-8111f1e4-1706-4e2d-b7fc-113cdea49b8d"/>
							<gml:surfaceMember xlink:href="#poly-d3fca5cf-04c4-46d7-a610-cf9d1e4a25d9"/>
							<gml:surfaceMember xlink:href="#poly-104f1502-7a1e-4686-a6e9-c92fba330579"/>
							<gml:surfaceMember xlink:href="#poly-6784c6e7-2365-4aed-9f73-68c8129d7632"/>
							<gml:surfaceMember xlink:href="#poly-a4eeff25-5eaf-4b37-8de3-0fd04ed415ac"/>
							<gml:surfaceMember xlink:href="#poly-db1d5472-966d-4f7f-b55c-1cf1d6f2eb64"/>
							<gml:surfaceMember xlink:href="#poly-3567987e-a141-4255-91cc-fc9f30d2bf72"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5ef91010-44b4-41f1-ae1e-38250461106b_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-59c43bad-66ab-466b-a7dd-c9c1b083cc83">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66984871602459 139.74748216018475 57.356 35.669854048325966 139.74748943391288 57.356 35.66983563871245 139.74750971232663 57.356 35.669821626759514 139.74749059533576 57.356 35.669852393503945 139.74745670583133 57.356 35.669861082165845 139.7474685380394 57.356 35.66984871602459 139.74748216018475 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e11572e8-6372-4893-9394-4529d7c9fd9d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66992705497289 139.74757155050514 57.356 35.66987142607402 139.74750105799163 57.356 35.66987780241338 139.74749350661733 57.356 35.66993343131662 139.74756399913116 57.356 35.66992705497289 139.74757155050514 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-02b60bd1-5ceb-4ffc-b7ac-9de61debafd2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698632752585 139.74751033446967 57.356 35.66992508575119 139.74759092764177 57.356 35.66991921361595 139.7475976941937 57.356 35.66985740311986 139.74751708997607 57.356 35.6698632752585 139.74751033446967 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac493200-6da8-4534-849a-bae3fa669017">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669825490773015 139.7476004234034 66.052 35.66983555027771 139.7476133366837 66.052 35.66982159060112 139.74762964472825 66.052 35.669811540104 139.74761672039236 66.052 35.669825490773015 139.7476004234034 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce8a904f-5d38-4a1a-9562-2ecd372b447d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66984155793665 139.74763234074686 66.052 35.66984464689273 139.74762847127997 66.052 35.66985020408031 139.74763511514442 66.052 35.669838127436215 139.74765025028023 66.052 35.66982418032338 139.74763355230905 66.052 35.66983315899592 139.74762228664991 66.052 35.66984155793665 139.74763234074686 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d5b2ed5-820c-4f4a-ab20-5b14769b9902">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002947975183 139.7476879784829 57.356 35.6700231934434 139.74769539720538 57.356 35.66995976940734 139.74761458465517 57.356 35.66996605571872 139.74760717697845 57.356 35.67002947975183 139.7476879784829 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-839aae16-3283-43db-94af-62f8f5b27402">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66995976940734 139.74761458465517 57.356 35.6700231934434 139.74769539720538 57.356 35.6700231934434 139.74769539720538 59.947 35.66995976940734 139.74761458465517 59.947 35.66995976940734 139.74761458465517 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97b2bed5-932c-416d-8b48-af3888372358">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670014466441685 139.74770566845547 57.356 35.6700086033845 139.74771253441276 57.356 35.66993686964429 139.7476203862993 57.356 35.66994274171001 139.7476135203318 57.356 35.670014466441685 139.74770566845547 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8237e4c0-2719-4dbb-82f8-3c308bc1a142">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66999275246174 139.74773116419797 57.356 35.669921125815435 139.74763749159638 57.356 35.669926997968645 139.74763074713957 57.356 35.669998624620106 139.74772441974196 57.356 35.66999275246174 139.74773116419797 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc1157ec-d58c-468f-b26b-a04b2071d922">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66983433236229 139.74772587651793 66.052 35.66982348697896 139.74771057808732 66.052 35.66986872871242 139.7476624346641 66.052 35.66987957410179 139.74767773309682 66.052 35.66983433236229 139.74772587651793 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ea10129-bc3c-434a-90fe-86ebbe5b890b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669854974320046 139.74775195662022 66.052 35.669845175914155 139.74773860119322 66.052 35.669890146257 139.74768906624237 66.052 35.66989994466044 139.74770241062458 66.052 35.669854974320046 139.74775195662022 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e99fc38-7ea4-4624-a5a4-fd4dfc24f3e2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67003864601612 139.7476996666313 57.356 35.67007776499335 139.74774950957342 57.356 35.67007096533063 139.74775753638542 57.356 35.67003184635668 139.74770769344363 57.356 35.67003864601612 139.7476996666313 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dca83a80-0c33-46c4-8c8c-995a9a5cc884">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67002237008376 139.7477163748392 57.356 35.670062066772466 139.74776739910797 57.356 35.670055627304336 139.74777492845286 57.356 35.67001592160506 139.74772390419406 57.356 35.67002237008376 139.7477163748392 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25ed7d44-a429-4588-9f81-47b8b410b43d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67000802403634 139.7477344175712 57.356 35.67004661189591 139.74778525523723 57.356 35.6700402353344 139.747792519403 57.356 35.67000165649157 139.74774168172786 57.356 35.67000802403634 139.7477344175712 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0197f15-2565-40a2-93af-9830dd35867f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669888323500466 139.7477623486296 57.356 35.66991113680857 139.74773635467645 57.356 35.66993712971932 139.74777061432908 57.356 35.66991432541765 139.7477966082714 57.356 35.669888323500466 139.7477623486296 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1258af8a-62cb-4dbb-8de0-fafee80c5521">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66986848311114 139.74777339390153 57.356 35.66987573677816 139.74778272019216 57.356 35.66987363855784 139.74778550607093 57.356 35.66986441807802 139.74777361916315 57.356 35.66986135963091 139.7477696899837 57.356 35.669873590300526 139.74775564826987 57.356 35.66987843501214 139.7477617516426 57.356 35.66986848311114 139.74777339390153 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c61495bb-a719-4ce7-8a42-822d96d5a950">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698583785132 139.74777310643717 58.2 35.66986135963091 139.7477696899837 58.2 35.66986441807802 139.74777361916315 58.2 35.66987363855784 139.74778550607093 58.2 35.66987080181624 139.74778914329414 58.2 35.6698583785132 139.74777310643717 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46e058ef-df71-4a82-b870-2eff6a100387">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6701046403815 139.74778255327539 57.356 35.670062211299786 139.74783127922285 57.356 35.67005306288747 139.74781932592776 57.356 35.670064663111674 139.7478060028645 57.356 35.670061261767536 139.7478015438214 57.356 35.670079959021116 139.74778007211887 57.356 35.670084073109535 139.74778545828403 57.356 35.670096204707995 139.7477715271015 57.356 35.6701046403815 139.74778255327539 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-229689e5-57b1-4cb8-87c2-864272c59f1c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66997044101005 139.74786727724822 57.356 35.6699446202661 139.7478342545408 57.356 35.66996725290704 139.74780768637993 57.356 35.66999307365817 139.74784070908808 57.356 35.66997044101005 139.74786727724822 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce1dee8c-df58-4248-9327-0fed0ec6ffff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66991639701603 139.74785787931202 57.356 35.66990732137469 139.74784685383835 57.356 35.66991255375339 139.7478403751889 57.356 35.669921629403156 139.74785141170875 57.356 35.66991639701603 139.74785787931202 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-64c89218-d551-4dcc-aaf3-096edce65a3b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66998244361803 139.7479001931923 57.356 35.670003789004056 139.7478760123905 57.356 35.670015725403076 139.74789183993332 57.356 35.66999438001393 139.7479160207345 57.356 35.66998244361803 139.7479001931923 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9a47301-6ea3-44d4-8f5a-77ca22c9de46">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670043906332296 139.7479228939483 57.356 35.67005245094013 139.74793502463643 57.356 35.67003434691204 139.74795416491295 57.356 35.67002580231393 139.74794204527169 57.356 35.670043906332296 139.7479228939483 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4934190e-f56e-4107-9e76-aa428405cbc2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670068347426906 139.74795517809767 57.356 35.67012985898602 139.74803410415677 57.356 35.67012327539904 139.7480417993333 57.356 35.67006176385273 139.74796288432097 57.356 35.670068347426906 139.74795517809767 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf213e6d-4688-46e9-a2bb-9378b1568648">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670053189325465 139.74797211704035 57.356 35.670109025889175 139.7480434935174 57.356 35.67010250536634 139.7480511444392 57.356 35.67004667782083 139.747979767953 57.356 35.670053189325465 139.74797211704035 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e25ed55d-e36b-4916-9b77-3cc3261986cf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67014000404243 139.7480533358913 57.356 35.67015217571339 139.7480704887847 57.356 35.67013242350522 139.7480915418039 57.356 35.67012025182939 139.74807437786535 57.356 35.67014000404243 139.7480533358913 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fbefb451-0c6a-4f1e-bd99-b5058fe6cac7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670112590537194 139.74811311407106 57.356 35.670104100139156 139.74810113794433 57.356 35.670118358137394 139.74808596736813 57.356 35.67012683953101 139.74809795455116 57.356 35.670112590537194 139.74811311407106 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-58092bc6-2d4f-403e-ad7d-83af5e57d537">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-58092bc6-2d4f-403e-ad7d-83af5e57d537_0">
											<gml:posList>35.66987142607402 139.74750105799163 57.356 35.66992705497289 139.74757155050514 57.356 35.66992705497289 139.74757155050514 59.947 35.66987142607402 139.74750105799163 59.947 35.66987142607402 139.74750105799163 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97605943-e3df-41a1-a805-443138480c63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97605943-e3df-41a1-a805-443138480c63_0">
											<gml:posList>35.66993686964429 139.7476203862993 57.356 35.6700086033845 139.74771253441276 57.356 35.6700086033845 139.74771253441276 59.947 35.66993686964429 139.7476203862993 59.947 35.66993686964429 139.7476203862993 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79a10260-09b6-4b8d-923e-c4826b1e8c7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79a10260-09b6-4b8d-923e-c4826b1e8c7d_0">
											<gml:posList>35.669926997968645 139.74763074713957 57.356 35.669926997968645 139.74763074713957 59.947 35.669998624620106 139.74772441974196 59.947 35.669998624620106 139.74772441974196 57.356 35.669926997968645 139.74763074713957 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a5919d9-a99a-4fc2-85f7-1b1db8c59bf8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a5919d9-a99a-4fc2-85f7-1b1db8c59bf8_0">
											<gml:posList>35.67003184635668 139.74770769344363 57.356 35.67007096533063 139.74775753638542 57.356 35.67007096533063 139.74775753638542 59.947 35.67003184635668 139.74770769344363 59.947 35.67003184635668 139.74770769344363 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41c250ff-fd1f-4b7b-9625-886adbbdb781">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41c250ff-fd1f-4b7b-9625-886adbbdb781_0">
											<gml:posList>35.67004661189591 139.74778525523723 57.356 35.67000802403634 139.7477344175712 57.356 35.67000802403634 139.7477344175712 59.947 35.67004661189591 139.74778525523723 59.947 35.67004661189591 139.74778525523723 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2574b4b8-cf69-409b-a08f-4a1bfefedf7b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2574b4b8-cf69-409b-a08f-4a1bfefedf7b_0">
											<gml:posList>35.670053189325465 139.74797211704035 57.356 35.670053189325465 139.74797211704035 60.028 35.670109025889175 139.7480434935174 60.028 35.670109025889175 139.7480434935174 57.356 35.670053189325465 139.74797211704035 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-315619ab-7d4c-4edc-9e77-b419d704b39b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-315619ab-7d4c-4edc-9e77-b419d704b39b_0">
											<gml:posList>35.669852393503945 139.74745670583133 57.356 35.669821626759514 139.74749059533576 57.356 35.669821626759514 139.74749059533576 59.375 35.669852393503945 139.74745670583133 59.375 35.669852393503945 139.74745670583133 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77a39ed1-1244-4a2c-90cb-b639770c88d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77a39ed1-1244-4a2c-90cb-b639770c88d7_0">
											<gml:posList>35.669852393503945 139.74745670583133 59.375 35.669821626759514 139.74749059533576 59.375 35.66983563871245 139.74750971232663 59.375 35.669854048325966 139.74748943391288 59.375 35.66984871602459 139.74748216018475 59.375 35.669861082165845 139.7474685380394 59.375 35.669852393503945 139.74745670583133 59.375</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7088ad8-58c8-42bb-9d0b-fdecc828490d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7088ad8-58c8-42bb-9d0b-fdecc828490d_0">
											<gml:posList>35.669821626759514 139.74749059533576 57.356 35.66983563871245 139.74750971232663 57.356 35.66983563871245 139.74750971232663 59.375 35.669821626759514 139.74749059533576 59.375 35.669821626759514 139.74749059533576 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d5f74fd0-2b16-4773-8218-cef05f805d99">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d5f74fd0-2b16-4773-8218-cef05f805d99_0">
											<gml:posList>35.66983555027771 139.7476133366837 66.052 35.669825490773015 139.7476004234034 66.052 35.669825490773015 139.7476004234034 69.543 35.66983555027771 139.7476133366837 69.543 35.66983555027771 139.7476133366837 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a1cf68e-c09e-4e6f-b416-f1776fe9b4f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a1cf68e-c09e-4e6f-b416-f1776fe9b4f0_0">
											<gml:posList>35.669825490773015 139.7476004234034 66.052 35.669811540104 139.74761672039236 66.052 35.669811540104 139.74761672039236 69.543 35.669825490773015 139.7476004234034 69.543 35.669825490773015 139.7476004234034 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71e24ad8-52cb-41ae-943f-e16122fb9b46">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71e24ad8-52cb-41ae-943f-e16122fb9b46_0">
											<gml:posList>35.66982159060112 139.74762964472825 69.543 35.66983555027771 139.7476133366837 69.543 35.669825490773015 139.7476004234034 69.543 35.669811540104 139.74761672039236 69.543 35.66982159060112 139.74762964472825 69.543</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3210eaf8-3d0c-42ca-9e51-48f168264ebb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3210eaf8-3d0c-42ca-9e51-48f168264ebb_0">
											<gml:posList>35.66982159060112 139.74762964472825 66.052 35.66983555027771 139.7476133366837 66.052 35.66983555027771 139.7476133366837 69.543 35.66982159060112 139.74762964472825 69.543 35.66982159060112 139.74762964472825 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2f6bb8e-47a5-4d06-8d28-03b1caeeaf02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2f6bb8e-47a5-4d06-8d28-03b1caeeaf02_0">
											<gml:posList>35.669811540104 139.74761672039236 66.052 35.66982159060112 139.74762964472825 66.052 35.66982159060112 139.74762964472825 69.543 35.669811540104 139.74761672039236 69.543 35.669811540104 139.74761672039236 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05726bed-3a73-4b0b-b6c9-45ac624b2660">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05726bed-3a73-4b0b-b6c9-45ac624b2660_0">
											<gml:posList>35.66984155793665 139.74763234074686 66.052 35.66983315899592 139.74762228664991 66.052 35.66983315899592 139.74762228664991 66.828 35.66984155793665 139.74763234074686 66.828 35.66984155793665 139.74763234074686 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00e2e3f7-f9e0-4aef-8974-8b47619f6aea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00e2e3f7-f9e0-4aef-8974-8b47619f6aea_0">
											<gml:posList>35.66983315899592 139.74762228664991 66.052 35.66982418032338 139.74763355230905 66.052 35.66982418032338 139.74763355230905 66.828 35.66983315899592 139.74762228664991 66.828 35.66983315899592 139.74762228664991 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8fb394da-33cf-49db-9ac9-a8506aa85e82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8fb394da-33cf-49db-9ac9-a8506aa85e82_0">
											<gml:posList>35.66984464689273 139.74762847127997 66.052 35.66984155793665 139.74763234074686 66.052 35.66984155793665 139.74763234074686 66.828 35.66984464689273 139.74762847127997 66.828 35.66984464689273 139.74762847127997 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f51bdd66-fbf3-4a22-9534-2984531a017a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f51bdd66-fbf3-4a22-9534-2984531a017a_0">
											<gml:posList>35.66982418032338 139.74763355230905 66.828 35.669838127436215 139.74765025028023 66.828 35.66985020408031 139.74763511514442 66.828 35.66984464689273 139.74762847127997 66.828 35.66984155793665 139.74763234074686 66.828 35.66983315899592 139.74762228664991 66.828 35.66982418032338 139.74763355230905 66.828</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36426239-a89b-4f3d-ba6f-528b81c933de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36426239-a89b-4f3d-ba6f-528b81c933de_0">
											<gml:posList>35.66982418032338 139.74763355230905 66.052 35.669838127436215 139.74765025028023 66.052 35.669838127436215 139.74765025028023 66.828 35.66982418032338 139.74763355230905 66.828 35.66982418032338 139.74763355230905 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0504e2f1-5cf5-426d-9c30-89db442bd5ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0504e2f1-5cf5-426d-9c30-89db442bd5ad_0">
											<gml:posList>35.66982348697896 139.74771057808732 66.052 35.66983433236229 139.74772587651793 66.052 35.66983433236229 139.74772587651793 67.762 35.66982348697896 139.74771057808732 67.762 35.66982348697896 139.74771057808732 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1e265a17-7d42-4b48-bc66-4cbfc39b61ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1e265a17-7d42-4b48-bc66-4cbfc39b61ce_0">
											<gml:posList>35.669838127436215 139.74765025028023 66.052 35.66985020408031 139.74763511514442 66.052 35.66985020408031 139.74763511514442 66.828 35.669838127436215 139.74765025028023 66.828 35.669838127436215 139.74765025028023 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-193df007-df51-4471-a99a-a270f878ea90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-193df007-df51-4471-a99a-a270f878ea90_0">
											<gml:posList>35.66983563871245 139.74750971232663 57.356 35.669854048325966 139.74748943391288 57.356 35.669854048325966 139.74748943391288 59.375 35.66983563871245 139.74750971232663 59.375 35.66983563871245 139.74750971232663 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a28338d-6db2-4f5c-b0d9-30e74be79424">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a28338d-6db2-4f5c-b0d9-30e74be79424_0">
											<gml:posList>35.66982348697896 139.74771057808732 66.052 35.66982348697896 139.74771057808732 67.762 35.66986872871242 139.7476624346641 67.762 35.66986872871242 139.7476624346641 66.052 35.66982348697896 139.74771057808732 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53a12da7-68f9-4199-aaec-1b0098ee4b39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53a12da7-68f9-4199-aaec-1b0098ee4b39_0">
											<gml:posList>35.66985020408031 139.74763511514442 66.052 35.66984464689273 139.74762847127997 66.052 35.66984464689273 139.74762847127997 66.828 35.66985020408031 139.74763511514442 66.828 35.66985020408031 139.74763511514442 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-469cc1c6-4aa6-4908-a6b6-3c0c122e2ad9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-469cc1c6-4aa6-4908-a6b6-3c0c122e2ad9_0">
											<gml:posList>35.669845175914155 139.74773860119322 66.052 35.669854974320046 139.74775195662022 66.052 35.669854974320046 139.74775195662022 67.762 35.669845175914155 139.74773860119322 67.762 35.669845175914155 139.74773860119322 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75656fe3-e8fb-498c-ba38-30cd379060a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75656fe3-e8fb-498c-ba38-30cd379060a4_0">
											<gml:posList>35.66986872871242 139.7476624346641 67.762 35.66982348697896 139.74771057808732 67.762 35.66983433236229 139.74772587651793 67.762 35.66987957410179 139.74767773309682 67.762 35.66986872871242 139.7476624346641 67.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae3127b3-377f-452c-b7f7-a611ded34f59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ae3127b3-377f-452c-b7f7-a611ded34f59_0">
											<gml:posList>35.669854048325966 139.74748943391288 57.356 35.66984871602459 139.74748216018475 57.356 35.66984871602459 139.74748216018475 59.375 35.669854048325966 139.74748943391288 59.375 35.669854048325966 139.74748943391288 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebca4eaa-9881-425c-8813-440074ff6019">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebca4eaa-9881-425c-8813-440074ff6019_0">
											<gml:posList>35.66984871602459 139.74748216018475 57.356 35.669861082165845 139.7474685380394 57.356 35.669861082165845 139.7474685380394 59.375 35.66984871602459 139.74748216018475 59.375 35.66984871602459 139.74748216018475 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7af2a85b-2dbe-4e97-8d20-82862890f1d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7af2a85b-2dbe-4e97-8d20-82862890f1d7_0">
											<gml:posList>35.669861082165845 139.7474685380394 57.356 35.669852393503945 139.74745670583133 57.356 35.669852393503945 139.74745670583133 59.375 35.669861082165845 139.7474685380394 59.375 35.669861082165845 139.7474685380394 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9cc7be81-7934-462f-b974-e180c789a54d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9cc7be81-7934-462f-b974-e180c789a54d_0">
											<gml:posList>35.66987957410179 139.74767773309682 66.052 35.66987957410179 139.74767773309682 67.762 35.66983433236229 139.74772587651793 67.762 35.66983433236229 139.74772587651793 66.052 35.66987957410179 139.74767773309682 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af30ea05-7f37-45b5-8120-dcc0fffd7dc2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af30ea05-7f37-45b5-8120-dcc0fffd7dc2_0">
											<gml:posList>35.6698632752585 139.74751033446967 57.356 35.66985740311986 139.74751708997607 57.356 35.66985740311986 139.74751708997607 59.947 35.6698632752585 139.74751033446967 59.947 35.6698632752585 139.74751033446967 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-762c52f7-8c97-4c38-8dc3-17cd95d7d3d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-762c52f7-8c97-4c38-8dc3-17cd95d7d3d7_0">
											<gml:posList>35.66986441807802 139.74777361916315 58.2 35.66986135963091 139.7477696899837 58.2 35.66986135963091 139.7477696899837 57.356 35.66986441807802 139.74777361916315 57.356 35.66986441807802 139.74777361916315 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a0dbe54-7e16-4581-a09a-0c0d2696d23c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a0dbe54-7e16-4581-a09a-0c0d2696d23c_0">
											<gml:posList>35.6698583785132 139.74777310643717 58.2 35.66987080181624 139.74778914329414 58.2 35.66987080181624 139.74778914329414 59.359 35.6698583785132 139.74777310643717 59.359 35.6698583785132 139.74777310643717 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16e0fe42-51d8-4c67-9598-41dab04d363c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16e0fe42-51d8-4c67-9598-41dab04d363c_0">
											<gml:posList>35.6698583785132 139.74777310643717 59.359 35.669873590300526 139.74775564826987 59.359 35.669873590300526 139.74775564826987 57.356 35.66986135963091 139.7477696899837 57.356 35.66986135963091 139.7477696899837 58.2 35.6698583785132 139.74777310643717 58.2 35.6698583785132 139.74777310643717 59.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f00a530e-9be5-46aa-9810-4611e7d9da7d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f00a530e-9be5-46aa-9810-4611e7d9da7d_0">
											<gml:posList>35.669890146257 139.74768906624237 66.052 35.669845175914155 139.74773860119322 66.052 35.669845175914155 139.74773860119322 67.762 35.669890146257 139.74768906624237 67.762 35.669890146257 139.74768906624237 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d96bd199-517e-4655-b47d-5db32ddc96f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d96bd199-517e-4655-b47d-5db32ddc96f2_0">
											<gml:posList>35.669873590300526 139.74775564826987 59.359 35.6698583785132 139.74777310643717 59.359 35.66987080181624 139.74778914329414 59.359 35.66987573677816 139.74778272019216 59.359 35.66986848311114 139.74777339390153 59.359 35.66987843501214 139.7477617516426 59.359 35.669873590300526 139.74775564826987 59.359</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6087bd7c-8334-48d5-b2c8-c860ad8c0e2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6087bd7c-8334-48d5-b2c8-c860ad8c0e2e_0">
											<gml:posList>35.66986441807802 139.74777361916315 57.356 35.66987363855784 139.74778550607093 57.356 35.66987363855784 139.74778550607093 58.2 35.66986441807802 139.74777361916315 58.2 35.66986441807802 139.74777361916315 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a823e8b2-a8f3-47c8-8d1c-f872751ff547">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a823e8b2-a8f3-47c8-8d1c-f872751ff547_0">
											<gml:posList>35.66987573677816 139.74778272019216 57.356 35.66986848311114 139.74777339390153 57.356 35.66986848311114 139.74777339390153 59.359 35.66987573677816 139.74778272019216 59.359 35.66987573677816 139.74778272019216 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dda4f06-5d5d-48e5-93c0-8e1e5a1dd47b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dda4f06-5d5d-48e5-93c0-8e1e5a1dd47b_0">
											<gml:posList>35.669890146257 139.74768906624237 67.762 35.669845175914155 139.74773860119322 67.762 35.669854974320046 139.74775195662022 67.762 35.66989994466044 139.74770241062458 67.762 35.669890146257 139.74768906624237 67.762</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8078e6a4-c7cd-42e1-899d-e3ab1e6174c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8078e6a4-c7cd-42e1-899d-e3ab1e6174c4_0">
											<gml:posList>35.66987573677816 139.74778272019216 57.356 35.66987573677816 139.74778272019216 59.359 35.66987080181624 139.74778914329414 59.359 35.66987080181624 139.74778914329414 58.2 35.66987363855784 139.74778550607093 58.2 35.66987363855784 139.74778550607093 57.356 35.66987573677816 139.74778272019216 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ef038bcc-ec41-4810-ab1d-61ed6976f485">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ef038bcc-ec41-4810-ab1d-61ed6976f485_0">
											<gml:posList>35.66987843501214 139.7477617516426 57.356 35.66987843501214 139.7477617516426 59.359 35.66986848311114 139.74777339390153 59.359 35.66986848311114 139.74777339390153 57.356 35.66987843501214 139.7477617516426 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce182854-d0f7-49df-9dc5-a98237e9898b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce182854-d0f7-49df-9dc5-a98237e9898b_0">
											<gml:posList>35.66987957410179 139.74767773309682 66.052 35.66986872871242 139.7476624346641 66.052 35.66986872871242 139.7476624346641 67.762 35.66987957410179 139.74767773309682 67.762 35.66987957410179 139.74767773309682 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03766ce3-1cc2-41a7-b506-4e3bd2710484">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03766ce3-1cc2-41a7-b506-4e3bd2710484_0">
											<gml:posList>35.66987780241338 139.74749350661733 57.356 35.66987142607402 139.74750105799163 57.356 35.66987142607402 139.74750105799163 59.947 35.66987780241338 139.74749350661733 59.947 35.66987780241338 139.74749350661733 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d93fbdd-38b9-4225-9af1-ee62f32cb949">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d93fbdd-38b9-4225-9af1-ee62f32cb949_0">
											<gml:posList>35.66987843501214 139.7477617516426 57.356 35.669873590300526 139.74775564826987 57.356 35.669873590300526 139.74775564826987 59.359 35.66987843501214 139.7477617516426 59.359 35.66987843501214 139.7477617516426 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc661df2-c69d-4c14-ad18-01e5f8d68c66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc661df2-c69d-4c14-ad18-01e5f8d68c66_0">
											<gml:posList>35.669854974320046 139.74775195662022 66.052 35.66989994466044 139.74770241062458 66.052 35.66989994466044 139.74770241062458 67.762 35.669854974320046 139.74775195662022 67.762 35.669854974320046 139.74775195662022 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-54420868-9fc1-4415-ad4e-db18309706df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-54420868-9fc1-4415-ad4e-db18309706df_0">
											<gml:posList>35.66985740311986 139.74751708997607 57.356 35.66991921361595 139.7475976941937 57.356 35.66991921361595 139.7475976941937 59.947 35.66985740311986 139.74751708997607 59.947 35.66985740311986 139.74751708997607 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa1d5475-db8d-4120-8cfa-ccfcf691c9a4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa1d5475-db8d-4120-8cfa-ccfcf691c9a4_0">
											<gml:posList>35.66991921361595 139.7475976941937 59.947 35.66992508575119 139.74759092764177 59.947 35.6698632752585 139.74751033446967 59.947 35.66985740311986 139.74751708997607 59.947 35.66991921361595 139.7475976941937 59.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c98366d-8853-4c22-a1cb-51fca88b362d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c98366d-8853-4c22-a1cb-51fca88b362d_0">
											<gml:posList>35.6698632752585 139.74751033446967 57.356 35.6698632752585 139.74751033446967 59.947 35.66992508575119 139.74759092764177 59.947 35.66992508575119 139.74759092764177 57.356 35.6698632752585 139.74751033446967 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95eeb0c4-16fe-4cb6-b3f4-b8139fce417f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95eeb0c4-16fe-4cb6-b3f4-b8139fce417f_0">
											<gml:posList>35.66989994466044 139.74770241062458 66.052 35.669890146257 139.74768906624237 66.052 35.669890146257 139.74768906624237 67.762 35.66989994466044 139.74770241062458 67.762 35.66989994466044 139.74770241062458 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f740cdd-7e75-459d-9976-b64fbaf14910">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f740cdd-7e75-459d-9976-b64fbaf14910_0">
											<gml:posList>35.66991113680857 139.74773635467645 57.356 35.669888323500466 139.7477623486296 57.356 35.669888323500466 139.7477623486296 61.962 35.66991113680857 139.74773635467645 61.962 35.66991113680857 139.74773635467645 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d10fd1d-0325-4770-ae49-f4f3916494ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d10fd1d-0325-4770-ae49-f4f3916494ba_0">
											<gml:posList>35.66991432541765 139.7477966082714 57.356 35.66991432541765 139.7477966082714 61.962 35.669888323500466 139.7477623486296 61.962 35.669888323500466 139.7477623486296 57.356 35.66991432541765 139.7477966082714 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d524542-58b8-4eef-82f9-1e92e00343c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d524542-58b8-4eef-82f9-1e92e00343c7_0">
											<gml:posList>35.66992705497289 139.74757155050514 59.947 35.66993343131662 139.74756399913116 59.947 35.66987780241338 139.74749350661733 59.947 35.66987142607402 139.74750105799163 59.947 35.66992705497289 139.74757155050514 59.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7563e6d3-26f0-4f03-bb01-8f9cf9e3c41b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7563e6d3-26f0-4f03-bb01-8f9cf9e3c41b_0">
											<gml:posList>35.66987780241338 139.74749350661733 57.356 35.66987780241338 139.74749350661733 59.947 35.66993343131662 139.74756399913116 59.947 35.66993343131662 139.74756399913116 57.356 35.66987780241338 139.74749350661733 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5711d413-3e74-4955-a23d-3ffd38e6363a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5711d413-3e74-4955-a23d-3ffd38e6363a_0">
											<gml:posList>35.66991255375339 139.7478403751889 57.356 35.66990732137469 139.74784685383835 57.356 35.66990732137469 139.74784685383835 59.91 35.66991255375339 139.7478403751889 59.91 35.66991255375339 139.7478403751889 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c772948-e344-4b18-925a-01f59beb1622">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c772948-e344-4b18-925a-01f59beb1622_0">
											<gml:posList>35.66990732137469 139.74784685383835 57.356 35.66991639701603 139.74785787931202 57.356 35.66991639701603 139.74785787931202 59.91 35.66990732137469 139.74784685383835 59.91 35.66990732137469 139.74784685383835 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7517da76-ef5d-408a-9712-158a4f2f5405">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7517da76-ef5d-408a-9712-158a4f2f5405_0">
											<gml:posList>35.669888323500466 139.7477623486296 61.962 35.66991432541765 139.7477966082714 61.962 35.66993712971932 139.74777061432908 61.962 35.66991113680857 139.74773635467645 61.962 35.669888323500466 139.7477623486296 61.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dbdd4a89-9197-4f47-a995-5e5a81993a69">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dbdd4a89-9197-4f47-a995-5e5a81993a69_0">
											<gml:posList>35.66991639701603 139.74785787931202 59.91 35.669921629403156 139.74785141170875 59.91 35.66991255375339 139.7478403751889 59.91 35.66990732137469 139.74784685383835 59.91 35.66991639701603 139.74785787931202 59.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e850260a-b6d3-4ad7-a85c-54e58f34933a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e850260a-b6d3-4ad7-a85c-54e58f34933a_0">
											<gml:posList>35.669921629403156 139.74785141170875 57.356 35.66991255375339 139.7478403751889 57.356 35.66991255375339 139.7478403751889 59.91 35.669921629403156 139.74785141170875 59.91 35.669921629403156 139.74785141170875 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd0a62df-5339-48b4-8dc4-405edf9b4f81">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fd0a62df-5339-48b4-8dc4-405edf9b4f81_0">
											<gml:posList>35.669921629403156 139.74785141170875 57.356 35.669921629403156 139.74785141170875 59.91 35.66991639701603 139.74785787931202 59.91 35.66991639701603 139.74785787931202 57.356 35.669921629403156 139.74785141170875 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94f91a50-ce02-4732-96d6-cdfecb24211c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94f91a50-ce02-4732-96d6-cdfecb24211c_0">
											<gml:posList>35.66991921361595 139.7475976941937 57.356 35.66992508575119 139.74759092764177 57.356 35.66992508575119 139.74759092764177 59.947 35.66991921361595 139.7475976941937 59.947 35.66991921361595 139.7475976941937 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c030359-3d8a-4eac-aea7-25bfeda693b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c030359-3d8a-4eac-aea7-25bfeda693b3_0">
											<gml:posList>35.66993712971932 139.74777061432908 57.356 35.66991113680857 139.74773635467645 57.356 35.66991113680857 139.74773635467645 61.962 35.66993712971932 139.74777061432908 61.962 35.66993712971932 139.74777061432908 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca5c271a-2fee-40f5-a68c-d209249565d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca5c271a-2fee-40f5-a68c-d209249565d8_0">
											<gml:posList>35.669926997968645 139.74763074713957 57.356 35.669921125815435 139.74763749159638 57.356 35.669921125815435 139.74763749159638 59.947 35.669926997968645 139.74763074713957 59.947 35.669926997968645 139.74763074713957 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd596254-4f46-43a9-b702-f963188bea5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd596254-4f46-43a9-b702-f963188bea5c_0">
											<gml:posList>35.66991432541765 139.7477966082714 57.356 35.66993712971932 139.74777061432908 57.356 35.66993712971932 139.74777061432908 61.962 35.66991432541765 139.7477966082714 61.962 35.66991432541765 139.7477966082714 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67eed44e-76e2-4811-acc0-dd1b81e2f2ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67eed44e-76e2-4811-acc0-dd1b81e2f2ca_0">
											<gml:posList>35.66992705497289 139.74757155050514 57.356 35.66993343131662 139.74756399913116 57.356 35.66993343131662 139.74756399913116 59.947 35.66992705497289 139.74757155050514 59.947 35.66992705497289 139.74757155050514 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-833c7d01-8bfe-4981-a3c9-1bcabc177d96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-833c7d01-8bfe-4981-a3c9-1bcabc177d96_0">
											<gml:posList>35.66993686964429 139.7476203862993 57.356 35.66993686964429 139.7476203862993 59.947 35.66994274171001 139.7476135203318 59.947 35.66994274171001 139.7476135203318 57.356 35.66993686964429 139.7476203862993 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a376f53d-d5e7-4f25-9837-ccc638d2efca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a376f53d-d5e7-4f25-9837-ccc638d2efca_0">
											<gml:posList>35.66996725290704 139.74780768637993 57.356 35.6699446202661 139.7478342545408 57.356 35.6699446202661 139.7478342545408 61.962 35.66996725290704 139.74780768637993 61.962 35.66996725290704 139.74780768637993 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-102eaef2-d2c7-4e04-8fce-ca956a40cb39">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-102eaef2-d2c7-4e04-8fce-ca956a40cb39_0">
											<gml:posList>35.669921125815435 139.74763749159638 57.356 35.66999275246174 139.74773116419797 57.356 35.66999275246174 139.74773116419797 59.947 35.669921125815435 139.74763749159638 59.947 35.669921125815435 139.74763749159638 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d3f73fd-c6ae-4a7d-9d9a-4dc88263604b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d3f73fd-c6ae-4a7d-9d9a-4dc88263604b_0">
											<gml:posList>35.6699446202661 139.7478342545408 57.356 35.66997044101005 139.74786727724822 57.356 35.66997044101005 139.74786727724822 61.962 35.6699446202661 139.7478342545408 61.962 35.6699446202661 139.7478342545408 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b340fa82-675d-4c1f-926f-f66e5eac9306">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b340fa82-675d-4c1f-926f-f66e5eac9306_0">
											<gml:posList>35.669926997968645 139.74763074713957 59.947 35.669921125815435 139.74763749159638 59.947 35.66999275246174 139.74773116419797 59.947 35.669998624620106 139.74772441974196 59.947 35.669926997968645 139.74763074713957 59.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-839353f9-ffe0-4349-8d8b-3c49d5527c58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-839353f9-ffe0-4349-8d8b-3c49d5527c58_0">
											<gml:posList>35.66995976940734 139.74761458465517 57.356 35.66995976940734 139.74761458465517 59.947 35.66996605571872 139.74760717697845 59.947 35.66996605571872 139.74760717697845 57.356 35.66995976940734 139.74761458465517 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-97ac2196-ef60-4425-a969-0b791eb41fd2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-97ac2196-ef60-4425-a969-0b791eb41fd2_0">
											<gml:posList>35.66997044101005 139.74786727724822 61.962 35.66999307365817 139.74784070908808 61.962 35.66996725290704 139.74780768637993 61.962 35.6699446202661 139.7478342545408 61.962 35.66997044101005 139.74786727724822 61.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d735e2c-1548-47c8-b197-1136236a094f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d735e2c-1548-47c8-b197-1136236a094f_0">
											<gml:posList>35.670014466441685 139.74770566845547 59.947 35.66994274171001 139.7476135203318 59.947 35.66993686964429 139.7476203862993 59.947 35.6700086033845 139.74771253441276 59.947 35.670014466441685 139.74770566845547 59.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f1e0bc6-7d54-4c68-9903-432e73963ed6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f1e0bc6-7d54-4c68-9903-432e73963ed6_0">
											<gml:posList>35.66994274171001 139.7476135203318 57.356 35.66994274171001 139.7476135203318 59.947 35.670014466441685 139.74770566845547 59.947 35.670014466441685 139.74770566845547 57.356 35.66994274171001 139.7476135203318 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d54b1bb-05b5-45d2-963b-b88cfcea24ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d54b1bb-05b5-45d2-963b-b88cfcea24ff_0">
											<gml:posList>35.66999307365817 139.74784070908808 57.356 35.66996725290704 139.74780768637993 57.356 35.66996725290704 139.74780768637993 61.962 35.66999307365817 139.74784070908808 61.962 35.66999307365817 139.74784070908808 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad795810-e7b9-4b6c-9ece-a562b087146b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad795810-e7b9-4b6c-9ece-a562b087146b_0">
											<gml:posList>35.66999307365817 139.74784070908808 57.356 35.66999307365817 139.74784070908808 61.962 35.66997044101005 139.74786727724822 61.962 35.66997044101005 139.74786727724822 57.356 35.66999307365817 139.74784070908808 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f9adc861-cd81-4413-8faa-f4446addba40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f9adc861-cd81-4413-8faa-f4446addba40_0">
											<gml:posList>35.66998244361803 139.7479001931923 57.356 35.66999438001393 139.7479160207345 57.356 35.66999438001393 139.7479160207345 61.962 35.66998244361803 139.7479001931923 61.962 35.66998244361803 139.7479001931923 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6a8e85a-3553-468b-bad0-ee156c008104">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6a8e85a-3553-468b-bad0-ee156c008104_0">
											<gml:posList>35.670003789004056 139.7478760123905 57.356 35.66998244361803 139.7479001931923 57.356 35.66998244361803 139.7479001931923 61.962 35.670003789004056 139.7478760123905 61.962 35.670003789004056 139.7478760123905 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b24ffff9-277f-4174-8ca5-19ced9d34ea2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b24ffff9-277f-4174-8ca5-19ced9d34ea2_0">
											<gml:posList>35.66995976940734 139.74761458465517 59.947 35.6700231934434 139.74769539720538 59.947 35.67002947975183 139.7476879784829 59.947 35.66996605571872 139.74760717697845 59.947 35.66995976940734 139.74761458465517 59.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1fcbaa2-7244-44bf-983d-2e8ace997ca1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1fcbaa2-7244-44bf-983d-2e8ace997ca1_0">
											<gml:posList>35.66999275246174 139.74773116419797 57.356 35.669998624620106 139.74772441974196 57.356 35.669998624620106 139.74772441974196 59.947 35.66999275246174 139.74773116419797 59.947 35.66999275246174 139.74773116419797 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e05e28da-fe6a-4ae7-9804-8ecae9436014">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e05e28da-fe6a-4ae7-9804-8ecae9436014_0">
											<gml:posList>35.67002947975183 139.7476879784829 57.356 35.66996605571872 139.74760717697845 57.356 35.66996605571872 139.74760717697845 59.947 35.67002947975183 139.7476879784829 59.947 35.67002947975183 139.7476879784829 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6df54e2c-df76-4bc9-8fc6-abd3e8b8a8f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6df54e2c-df76-4bc9-8fc6-abd3e8b8a8f8_0">
											<gml:posList>35.670015725403076 139.74789183993332 61.962 35.670003789004056 139.7478760123905 61.962 35.66998244361803 139.7479001931923 61.962 35.66999438001393 139.7479160207345 61.962 35.670015725403076 139.74789183993332 61.962</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20aa0217-91a2-496c-ab3a-b36439354eec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20aa0217-91a2-496c-ab3a-b36439354eec_0">
											<gml:posList>35.67000165649157 139.74774168172786 59.947 35.67000802403634 139.7477344175712 59.947 35.67000802403634 139.7477344175712 57.356 35.67000165649157 139.74774168172786 57.356 35.67000165649157 139.74774168172786 59.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a83ab3a0-2eb4-43a9-8d93-3e17b1d4f1cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a83ab3a0-2eb4-43a9-8d93-3e17b1d4f1cc_0">
											<gml:posList>35.670015725403076 139.74789183993332 57.356 35.670015725403076 139.74789183993332 61.962 35.66999438001393 139.7479160207345 61.962 35.66999438001393 139.7479160207345 57.356 35.670015725403076 139.74789183993332 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe2e4bc3-2b1c-4adc-a6d8-b712dd92cbdd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe2e4bc3-2b1c-4adc-a6d8-b712dd92cbdd_0">
											<gml:posList>35.670015725403076 139.74789183993332 57.356 35.670003789004056 139.7478760123905 57.356 35.670003789004056 139.7478760123905 61.962 35.670015725403076 139.74789183993332 61.962 35.670015725403076 139.74789183993332 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a92ed850-bf7a-4c46-afc3-c100a6d37692">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a92ed850-bf7a-4c46-afc3-c100a6d37692_0">
											<gml:posList>35.6700086033845 139.74771253441276 57.356 35.670014466441685 139.74770566845547 57.356 35.670014466441685 139.74770566845547 59.947 35.6700086033845 139.74771253441276 59.947 35.6700086033845 139.74771253441276 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7968a769-0e9e-4827-b1e3-237109e6a84d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7968a769-0e9e-4827-b1e3-237109e6a84d_0">
											<gml:posList>35.67002237008376 139.7477163748392 57.356 35.67001592160506 139.74772390419406 57.356 35.67001592160506 139.74772390419406 59.947 35.67002237008376 139.7477163748392 59.947 35.67002237008376 139.7477163748392 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a0170f7-27d5-436f-b22f-ff99ba6f0aa1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a0170f7-27d5-436f-b22f-ff99ba6f0aa1_0">
											<gml:posList>35.67000165649157 139.74774168172786 57.356 35.6700402353344 139.747792519403 57.356 35.6700402353344 139.747792519403 59.947 35.67000165649157 139.74774168172786 59.947 35.67000165649157 139.74774168172786 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75af939a-91d7-44b7-8229-73bc5aabc87d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75af939a-91d7-44b7-8229-73bc5aabc87d_0">
											<gml:posList>35.6700402353344 139.747792519403 59.947 35.67004661189591 139.74778525523723 59.947 35.67000802403634 139.7477344175712 59.947 35.67000165649157 139.74774168172786 59.947 35.6700402353344 139.747792519403 59.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b7b3b4e-24b1-43ed-b0ca-13b486907de2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b7b3b4e-24b1-43ed-b0ca-13b486907de2_0">
											<gml:posList>35.67002947975183 139.7476879784829 57.356 35.67002947975183 139.7476879784829 59.947 35.6700231934434 139.74769539720538 59.947 35.6700231934434 139.74769539720538 57.356 35.67002947975183 139.7476879784829 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f8e6d917-1275-4ba0-94cf-d42d215459bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f8e6d917-1275-4ba0-94cf-d42d215459bc_0">
											<gml:posList>35.67002580231393 139.74794204527169 57.356 35.67003434691204 139.74795416491295 57.356 35.67003434691204 139.74795416491295 59.707 35.67002580231393 139.74794204527169 59.707 35.67002580231393 139.74794204527169 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f1fd5788-cc71-4153-89e7-6001ae8dc05f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f1fd5788-cc71-4153-89e7-6001ae8dc05f_0">
											<gml:posList>35.670043906332296 139.7479228939483 57.356 35.67002580231393 139.74794204527169 57.356 35.67002580231393 139.74794204527169 59.707 35.670043906332296 139.7479228939483 59.707 35.670043906332296 139.7479228939483 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b596cb2e-38a1-4a20-a534-048ea780f014">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b596cb2e-38a1-4a20-a534-048ea780f014_0">
											<gml:posList>35.67003864601612 139.7476996666313 57.356 35.67003184635668 139.74770769344363 57.356 35.67003184635668 139.74770769344363 59.947 35.67003864601612 139.7476996666313 59.947 35.67003864601612 139.7476996666313 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5587b52-1b32-4a3f-aed4-d6465c4f40c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5587b52-1b32-4a3f-aed4-d6465c4f40c2_0">
											<gml:posList>35.670055627304336 139.74777492845286 57.356 35.670055627304336 139.74777492845286 59.947 35.67001592160506 139.74772390419406 59.947 35.67001592160506 139.74772390419406 57.356 35.670055627304336 139.74777492845286 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-939f266a-85e4-43cf-8fc6-976dae498a12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-939f266a-85e4-43cf-8fc6-976dae498a12_0">
											<gml:posList>35.67003434691204 139.74795416491295 59.707 35.67005245094013 139.74793502463643 59.707 35.670043906332296 139.7479228939483 59.707 35.67002580231393 139.74794204527169 59.707 35.67003434691204 139.74795416491295 59.707</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a08ba2cb-08be-4d90-ad05-0b0f0e47c4be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a08ba2cb-08be-4d90-ad05-0b0f0e47c4be_0">
											<gml:posList>35.670055627304336 139.74777492845286 59.947 35.670062066772466 139.74776739910797 59.947 35.67002237008376 139.7477163748392 59.947 35.67001592160506 139.74772390419406 59.947 35.670055627304336 139.74777492845286 59.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bdd46c76-33b5-4108-954c-85ce4fe85c74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bdd46c76-33b5-4108-954c-85ce4fe85c74_0">
											<gml:posList>35.670062066772466 139.74776739910797 57.356 35.67002237008376 139.7477163748392 57.356 35.67002237008376 139.7477163748392 59.947 35.670062066772466 139.74776739910797 59.947 35.670062066772466 139.74776739910797 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-edcfdc75-d15b-4baa-a827-737dd3a33042">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-edcfdc75-d15b-4baa-a827-737dd3a33042_0">
											<gml:posList>35.67005245094013 139.74793502463643 57.356 35.67005245094013 139.74793502463643 59.707 35.67003434691204 139.74795416491295 59.707 35.67003434691204 139.74795416491295 57.356 35.67005245094013 139.74793502463643 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b9a5df5-4067-46d7-9f5b-b67a245e66e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b9a5df5-4067-46d7-9f5b-b67a245e66e2_0">
											<gml:posList>35.6700402353344 139.747792519403 57.356 35.67004661189591 139.74778525523723 57.356 35.67004661189591 139.74778525523723 59.947 35.6700402353344 139.747792519403 59.947 35.6700402353344 139.747792519403 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d47b9d3a-ecb5-4399-bac7-0a2f883f271f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d47b9d3a-ecb5-4399-bac7-0a2f883f271f_0">
											<gml:posList>35.67005245094013 139.74793502463643 57.356 35.670043906332296 139.7479228939483 57.356 35.670043906332296 139.7479228939483 59.707 35.67005245094013 139.74793502463643 59.707 35.67005245094013 139.74793502463643 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa619fcd-62c0-4e65-b920-17ece35af51f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa619fcd-62c0-4e65-b920-17ece35af51f_0">
											<gml:posList>35.670053189325465 139.74797211704035 57.356 35.67004667782083 139.747979767953 57.356 35.67004667782083 139.747979767953 60.028 35.670053189325465 139.74797211704035 60.028 35.670053189325465 139.74797211704035 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da07b50a-426c-4805-ba56-763aacb9ac0a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da07b50a-426c-4805-ba56-763aacb9ac0a_0">
											<gml:posList>35.67007096533063 139.74775753638542 59.947 35.67007776499335 139.74774950957342 59.947 35.67003864601612 139.7476996666313 59.947 35.67003184635668 139.74770769344363 59.947 35.67007096533063 139.74775753638542 59.947</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fde1c44c-e19a-4f3e-8b69-acea186ee2e0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fde1c44c-e19a-4f3e-8b69-acea186ee2e0_0">
											<gml:posList>35.67005306288747 139.74781932592776 57.356 35.670062211299786 139.74783127922285 57.356 35.670062211299786 139.74783127922285 59.596 35.67005306288747 139.74781932592776 59.596 35.67005306288747 139.74781932592776 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce5fb8f4-ba6d-4e7f-91b8-b4e1ce005c2b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce5fb8f4-ba6d-4e7f-91b8-b4e1ce005c2b_0">
											<gml:posList>35.67007776499335 139.74774950957342 57.356 35.67003864601612 139.7476996666313 57.356 35.67003864601612 139.7476996666313 59.947 35.67007776499335 139.74774950957342 59.947 35.67007776499335 139.74774950957342 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-789b944c-2285-4348-81ab-de86eb09df67">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-789b944c-2285-4348-81ab-de86eb09df67_0">
											<gml:posList>35.67005306288747 139.74781932592776 57.356 35.67005306288747 139.74781932592776 59.596 35.670064663111674 139.7478060028645 59.596 35.670064663111674 139.7478060028645 57.356 35.67005306288747 139.74781932592776 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1e20249-906b-4d3a-a5ba-fbf59f179412">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1e20249-906b-4d3a-a5ba-fbf59f179412_0">
											<gml:posList>35.670062066772466 139.74776739910797 57.356 35.670062066772466 139.74776739910797 59.947 35.670055627304336 139.74777492845286 59.947 35.670055627304336 139.74777492845286 57.356 35.670062066772466 139.74776739910797 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-57ba3797-a516-412d-bfaf-1e4adf89e015">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-57ba3797-a516-412d-bfaf-1e4adf89e015_0">
											<gml:posList>35.670061261767536 139.7478015438214 57.356 35.670064663111674 139.7478060028645 57.356 35.670064663111674 139.7478060028645 59.596 35.670061261767536 139.7478015438214 59.596 35.670061261767536 139.7478015438214 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-75c70799-13e2-4133-8703-74c34af4764d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-75c70799-13e2-4133-8703-74c34af4764d_0">
											<gml:posList>35.670068347426906 139.74795517809767 57.356 35.67006176385273 139.74796288432097 57.356 35.67006176385273 139.74796288432097 60.028 35.670068347426906 139.74795517809767 60.028 35.670068347426906 139.74795517809767 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74e9aab0-72c2-4a84-84be-9ea0c7adda01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74e9aab0-72c2-4a84-84be-9ea0c7adda01_0">
											<gml:posList>35.670079959021116 139.74778007211887 57.356 35.670061261767536 139.7478015438214 57.356 35.670061261767536 139.7478015438214 59.596 35.670079959021116 139.74778007211887 59.596 35.670079959021116 139.74778007211887 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-84979efd-1226-4c16-8303-aad2d1fbd9b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-84979efd-1226-4c16-8303-aad2d1fbd9b0_0">
											<gml:posList>35.67007096533063 139.74775753638542 57.356 35.67007776499335 139.74774950957342 57.356 35.67007776499335 139.74774950957342 59.947 35.67007096533063 139.74775753638542 59.947 35.67007096533063 139.74775753638542 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-225c9215-ea34-42a8-9b9e-d434f0f96be5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-225c9215-ea34-42a8-9b9e-d434f0f96be5_0">
											<gml:posList>35.67010250536634 139.7480511444392 57.356 35.67010250536634 139.7480511444392 60.028 35.67004667782083 139.747979767953 60.028 35.67004667782083 139.747979767953 57.356 35.67010250536634 139.7480511444392 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa16dd31-6f0d-46ea-b246-0ed9fc7b9096">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa16dd31-6f0d-46ea-b246-0ed9fc7b9096_0">
											<gml:posList>35.67010250536634 139.7480511444392 60.028 35.670109025889175 139.7480434935174 60.028 35.670053189325465 139.74797211704035 60.028 35.67004667782083 139.747979767953 60.028 35.67010250536634 139.7480511444392 60.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2f6b86c-2024-48d6-8737-d1071386b45c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2f6b86c-2024-48d6-8737-d1071386b45c_0">
											<gml:posList>35.670084073109535 139.74778545828403 59.596 35.670079959021116 139.74778007211887 59.596 35.670061261767536 139.7478015438214 59.596 35.670064663111674 139.7478060028645 59.596 35.67005306288747 139.74781932592776 59.596 35.670062211299786 139.74783127922285 59.596 35.6701046403815 139.74778255327539 59.596 35.670096204707995 139.7477715271015 59.596 35.670084073109535 139.74778545828403 59.596</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-98883f23-722a-49c7-b858-d89772b703b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-98883f23-722a-49c7-b858-d89772b703b0_0">
											<gml:posList>35.670079959021116 139.74778007211887 57.356 35.670079959021116 139.74778007211887 59.596 35.670084073109535 139.74778545828403 59.596 35.670084073109535 139.74778545828403 57.356 35.670079959021116 139.74778007211887 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66d33928-027f-46fd-80c7-45d711aa0fa4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66d33928-027f-46fd-80c7-45d711aa0fa4_0">
											<gml:posList>35.670062211299786 139.74783127922285 57.356 35.6701046403815 139.74778255327539 57.356 35.6701046403815 139.74778255327539 59.596 35.670062211299786 139.74783127922285 59.596 35.670062211299786 139.74783127922285 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de8ec460-50a6-434f-a1ee-bf2f33c45222">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de8ec460-50a6-434f-a1ee-bf2f33c45222_0">
											<gml:posList>35.670096204707995 139.7477715271015 57.356 35.670084073109535 139.74778545828403 57.356 35.670084073109535 139.74778545828403 59.596 35.670096204707995 139.7477715271015 59.596 35.670096204707995 139.7477715271015 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a51d47dd-1ee0-4ff6-b4b8-beefea712c51">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a51d47dd-1ee0-4ff6-b4b8-beefea712c51_0">
											<gml:posList>35.67012327539904 139.7480417993333 57.356 35.67012327539904 139.7480417993333 60.028 35.67006176385273 139.74796288432097 60.028 35.67006176385273 139.74796288432097 57.356 35.67012327539904 139.7480417993333 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d9d260e-a83e-4698-b429-d3f1851b5571">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d9d260e-a83e-4698-b429-d3f1851b5571_0">
											<gml:posList>35.67012327539904 139.7480417993333 60.028 35.67012985898602 139.74803410415677 60.028 35.670068347426906 139.74795517809767 60.028 35.67006176385273 139.74796288432097 60.028 35.67012327539904 139.7480417993333 60.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcaf9db9-2bab-44f9-924f-75331d926514">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcaf9db9-2bab-44f9-924f-75331d926514_0">
											<gml:posList>35.670068347426906 139.74795517809767 60.028 35.67012985898602 139.74803410415677 60.028 35.67012985898602 139.74803410415677 57.356 35.670068347426906 139.74795517809767 57.356 35.670068347426906 139.74795517809767 60.028</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99edb26b-8a54-4772-ae85-e61d742603bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99edb26b-8a54-4772-ae85-e61d742603bf_0">
											<gml:posList>35.670096204707995 139.7477715271015 57.356 35.670096204707995 139.7477715271015 59.596 35.6701046403815 139.74778255327539 59.596 35.6701046403815 139.74778255327539 57.356 35.670096204707995 139.7477715271015 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-745b315e-4380-468b-b711-90477415f0b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-745b315e-4380-468b-b711-90477415f0b3_0">
											<gml:posList>35.67010250536634 139.7480511444392 57.356 35.670109025889175 139.7480434935174 57.356 35.670109025889175 139.7480434935174 60.028 35.67010250536634 139.7480511444392 60.028 35.67010250536634 139.7480511444392 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac30f827-f95d-4de3-95d1-e6c235dec6ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac30f827-f95d-4de3-95d1-e6c235dec6ba_0">
											<gml:posList>35.670104100139156 139.74810113794433 57.356 35.670112590537194 139.74811311407106 57.356 35.670112590537194 139.74811311407106 59.365 35.670104100139156 139.74810113794433 59.365 35.670104100139156 139.74810113794433 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-206ec23c-4598-4d5a-9c5a-a83e4f5d66a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-206ec23c-4598-4d5a-9c5a-a83e4f5d66a5_0">
											<gml:posList>35.670104100139156 139.74810113794433 57.356 35.670104100139156 139.74810113794433 59.365 35.670118358137394 139.74808596736813 59.365 35.670118358137394 139.74808596736813 57.356 35.670104100139156 139.74810113794433 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60e96a64-63a6-478f-bc6f-28966df91fe5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60e96a64-63a6-478f-bc6f-28966df91fe5_0">
											<gml:posList>35.670118358137394 139.74808596736813 59.365 35.670104100139156 139.74810113794433 59.365 35.670112590537194 139.74811311407106 59.365 35.67012683953101 139.74809795455116 59.365 35.670118358137394 139.74808596736813 59.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d0c5042-9bda-4b77-8081-8b5db96119e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d0c5042-9bda-4b77-8081-8b5db96119e8_0">
											<gml:posList>35.670112590537194 139.74811311407106 57.356 35.67012683953101 139.74809795455116 57.356 35.67012683953101 139.74809795455116 59.365 35.670112590537194 139.74811311407106 59.365 35.670112590537194 139.74811311407106 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b43bb7a-4169-4450-b0fb-c689f743dc5f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b43bb7a-4169-4450-b0fb-c689f743dc5f_0">
											<gml:posList>35.67012683953101 139.74809795455116 57.356 35.670118358137394 139.74808596736813 57.356 35.670118358137394 139.74808596736813 59.365 35.67012683953101 139.74809795455116 59.365 35.67012683953101 139.74809795455116 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-859b9c00-3bc0-4907-8a7c-2ab43aa32034">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-859b9c00-3bc0-4907-8a7c-2ab43aa32034_0">
											<gml:posList>35.67012025182939 139.74807437786535 57.356 35.67013242350522 139.7480915418039 57.356 35.67013242350522 139.7480915418039 59.365 35.67012025182939 139.74807437786535 59.365 35.67012025182939 139.74807437786535 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c5faeb6c-34f0-44e2-bddc-201e36c3ad5c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c5faeb6c-34f0-44e2-bddc-201e36c3ad5c_0">
											<gml:posList>35.67012327539904 139.7480417993333 57.356 35.67012985898602 139.74803410415677 57.356 35.67012985898602 139.74803410415677 60.028 35.67012327539904 139.7480417993333 60.028 35.67012327539904 139.7480417993333 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eca589d1-a79b-4658-9aab-fcd491a42103">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eca589d1-a79b-4658-9aab-fcd491a42103_0">
											<gml:posList>35.67014000404243 139.7480533358913 57.356 35.67012025182939 139.74807437786535 57.356 35.67012025182939 139.74807437786535 59.365 35.67014000404243 139.7480533358913 59.365 35.67014000404243 139.7480533358913 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-87fe94e2-8e63-4289-a81e-67337ac33472">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-87fe94e2-8e63-4289-a81e-67337ac33472_0">
											<gml:posList>35.67013242350522 139.7480915418039 59.365 35.67015217571339 139.7480704887847 59.365 35.67014000404243 139.7480533358913 59.365 35.67012025182939 139.74807437786535 59.365 35.67013242350522 139.7480915418039 59.365</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90a35330-d0f0-4f47-8eca-f9c9f4ceb904">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90a35330-d0f0-4f47-8eca-f9c9f4ceb904_0">
											<gml:posList>35.67013242350522 139.7480915418039 57.356 35.67015217571339 139.7480704887847 57.356 35.67015217571339 139.7480704887847 59.365 35.67013242350522 139.7480915418039 59.365 35.67013242350522 139.7480915418039 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08a3f400-adb2-4b5f-9e0f-780844280def">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08a3f400-adb2-4b5f-9e0f-780844280def_0">
											<gml:posList>35.67015217571339 139.7480704887847 57.356 35.67014000404243 139.7480533358913 57.356 35.67014000404243 139.7480533358913 59.365 35.67015217571339 139.7480704887847 59.365 35.67015217571339 139.7480704887847 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5ef91010-44b4-41f1-ae1e-38250461106b_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-76147ffa-bcc6-4dad-8346-6988bb78d5ad">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669970110060056 139.74779471508913 57.356 35.669935939397774 139.74783334696318 57.356 35.669941785805314 139.7478411062072 57.356 35.669935580328556 139.74784812716024 57.356 35.66998324480363 139.7479114373758 57.356 35.6699808400667 139.74791415730422 57.356 35.669988048834306 139.74792373773124 57.356 35.66998498662009 139.7479271984556 57.356 35.66987573677816 139.74778272019216 57.356 35.66986848311114 139.74777339390153 57.356 35.66987424711517 139.74776666062073 57.356 35.669906131731096 139.74780901084318 57.356 35.669912409268335 139.7478019235357 57.356 35.669920042082275 139.74781205580197 57.356 35.669954140682954 139.74777350132686 57.356 35.66995955403527 139.74778069767402 57.356 35.669920690991916 139.74782463672804 57.356 35.66992638402553 139.74783219730196 57.356 35.66996524706376 139.74778824720227 57.356 35.669970110060056 139.74779471508913 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08e99638-478e-4e45-8277-d475f6eeca52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08e99638-478e-4e45-8277-d475f6eeca52_0">
											<gml:posList>35.66986848311114 139.74777339390153 57.356 35.66986848311114 139.74777339390153 58.885 35.66987424711517 139.74776666062073 58.885 35.66987424711517 139.74776666062073 57.356 35.66986848311114 139.74777339390153 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67aabe6e-df58-4ca7-95ef-f9f11bfa7992">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67aabe6e-df58-4ca7-95ef-f9f11bfa7992_0">
											<gml:posList>35.66987573677816 139.74778272019216 57.356 35.66987573677816 139.74778272019216 58.885 35.66986848311114 139.74777339390153 58.885 35.66986848311114 139.74777339390153 57.356 35.66987573677816 139.74778272019216 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f5b7e2b-bc31-41af-843c-614128e0c28d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f5b7e2b-bc31-41af-843c-614128e0c28d_0">
											<gml:posList>35.66987424711517 139.74776666062073 57.356 35.66987424711517 139.74776666062073 58.885 35.669906131731096 139.74780901084318 58.885 35.669906131731096 139.74780901084318 57.356 35.66987424711517 139.74776666062073 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa9f87b8-b25c-4fc2-8fce-8ad3ad152b76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aa9f87b8-b25c-4fc2-8fce-8ad3ad152b76_0">
											<gml:posList>35.669906131731096 139.74780901084318 58.885 35.669912409268335 139.7478019235357 58.885 35.669912409268335 139.7478019235357 57.356 35.669906131731096 139.74780901084318 57.356 35.669906131731096 139.74780901084318 58.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb470ce2-46b9-4557-94bc-adf8281ee5b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bb470ce2-46b9-4557-94bc-adf8281ee5b2_0">
											<gml:posList>35.669912409268335 139.7478019235357 57.356 35.669912409268335 139.7478019235357 58.885 35.669920042082275 139.74781205580197 58.885 35.669920042082275 139.74781205580197 57.356 35.669912409268335 139.7478019235357 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86ca6234-116c-448f-b3a6-cc5d599d3063">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86ca6234-116c-448f-b3a6-cc5d599d3063_0">
											<gml:posList>35.669920690991916 139.74782463672804 57.356 35.669920690991916 139.74782463672804 58.885 35.66992638402553 139.74783219730196 58.885 35.66992638402553 139.74783219730196 57.356 35.669920690991916 139.74782463672804 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b0b216e3-bfa5-4d41-b959-34175a940613">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b0b216e3-bfa5-4d41-b959-34175a940613_0">
											<gml:posList>35.66992638402553 139.74783219730196 58.885 35.669920690991916 139.74782463672804 58.885 35.66995955403527 139.74778069767402 58.885 35.669954140682954 139.74777350132686 58.885 35.669920042082275 139.74781205580197 58.885 35.669912409268335 139.7478019235357 58.885 35.669906131731096 139.74780901084318 58.885 35.66987424711517 139.74776666062073 58.885 35.66986848311114 139.74777339390153 58.885 35.66987573677816 139.74778272019216 58.885 35.66998498662009 139.7479271984556 58.885 35.669988048834306 139.74792373773124 58.885 35.6699808400667 139.74791415730422 58.885 35.66998324480363 139.7479114373758 58.885 35.669935580328556 139.74784812716024 58.885 35.669941785805314 139.7478411062072 58.885 35.669935939397774 139.74783334696318 58.885 35.669970110060056 139.74779471508913 58.885 35.66996524706376 139.74778824720227 58.885 35.66992638402553 139.74783219730196 58.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81012c9a-fe15-4a5b-bfe7-9fe7594450ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81012c9a-fe15-4a5b-bfe7-9fe7594450ca_0">
											<gml:posList>35.66998498662009 139.7479271984556 57.356 35.66998498662009 139.7479271984556 58.885 35.66987573677816 139.74778272019216 58.885 35.66987573677816 139.74778272019216 57.356 35.66998498662009 139.7479271984556 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c566b1b-5f92-424f-8dd6-db7036eaafd3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c566b1b-5f92-424f-8dd6-db7036eaafd3_0">
											<gml:posList>35.669920042082275 139.74781205580197 57.356 35.669920042082275 139.74781205580197 58.885 35.669954140682954 139.74777350132686 58.885 35.669954140682954 139.74777350132686 57.356 35.669920042082275 139.74781205580197 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c192be34-5a93-4354-9fe3-a5ddc40252ec">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c192be34-5a93-4354-9fe3-a5ddc40252ec_0">
											<gml:posList>35.669941785805314 139.7478411062072 57.356 35.669941785805314 139.7478411062072 58.885 35.669935580328556 139.74784812716024 58.885 35.669935580328556 139.74784812716024 57.356 35.669941785805314 139.7478411062072 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d51e8bad-1da3-41c1-af61-00bf7ca3d4c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d51e8bad-1da3-41c1-af61-00bf7ca3d4c2_0">
											<gml:posList>35.669935939397774 139.74783334696318 57.356 35.669935939397774 139.74783334696318 58.885 35.669941785805314 139.7478411062072 58.885 35.669941785805314 139.7478411062072 57.356 35.669935939397774 139.74783334696318 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b6bf1d5-bdee-4b8d-879d-c0f10966196f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b6bf1d5-bdee-4b8d-879d-c0f10966196f_0">
											<gml:posList>35.66995955403527 139.74778069767402 57.356 35.66995955403527 139.74778069767402 58.885 35.669920690991916 139.74782463672804 58.885 35.669920690991916 139.74782463672804 57.356 35.66995955403527 139.74778069767402 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23f8cecf-ff67-45c4-ac37-66e4eeef7b1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23f8cecf-ff67-45c4-ac37-66e4eeef7b1c_0">
											<gml:posList>35.66992638402553 139.74783219730196 57.356 35.66992638402553 139.74783219730196 58.885 35.66996524706376 139.74778824720227 58.885 35.66996524706376 139.74778824720227 57.356 35.66992638402553 139.74783219730196 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebf56c47-4948-4de5-98a2-b46f96169217">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebf56c47-4948-4de5-98a2-b46f96169217_0">
											<gml:posList>35.669970110060056 139.74779471508913 57.356 35.669970110060056 139.74779471508913 58.885 35.669935939397774 139.74783334696318 58.885 35.669935939397774 139.74783334696318 57.356 35.669970110060056 139.74779471508913 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-163a8047-085f-41df-bc20-aab48632fea6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-163a8047-085f-41df-bc20-aab48632fea6_0">
											<gml:posList>35.669954140682954 139.74777350132686 57.356 35.669954140682954 139.74777350132686 58.885 35.66995955403527 139.74778069767402 58.885 35.66995955403527 139.74778069767402 57.356 35.669954140682954 139.74777350132686 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7ee4e87-83b6-4d59-9b9e-d7502784b81e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7ee4e87-83b6-4d59-9b9e-d7502784b81e_0">
											<gml:posList>35.669935580328556 139.74784812716024 58.885 35.66998324480363 139.7479114373758 58.885 35.66998324480363 139.7479114373758 57.356 35.669935580328556 139.74784812716024 57.356 35.669935580328556 139.74784812716024 58.885</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16538800-9b55-4efc-8c84-0e2f3cdc5326">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16538800-9b55-4efc-8c84-0e2f3cdc5326_0">
											<gml:posList>35.66996524706376 139.74778824720227 57.356 35.66996524706376 139.74778824720227 58.885 35.669970110060056 139.74779471508913 58.885 35.669970110060056 139.74779471508913 57.356 35.66996524706376 139.74778824720227 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26bcda5e-8bcf-4146-8494-695521aef8f7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26bcda5e-8bcf-4146-8494-695521aef8f7_0">
											<gml:posList>35.66998324480363 139.7479114373758 57.356 35.66998324480363 139.7479114373758 58.885 35.6699808400667 139.74791415730422 58.885 35.6699808400667 139.74791415730422 57.356 35.66998324480363 139.7479114373758 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69fcf548-9b7b-4a46-955a-40fb3db78b60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69fcf548-9b7b-4a46-955a-40fb3db78b60_0">
											<gml:posList>35.6699808400667 139.74791415730422 57.356 35.6699808400667 139.74791415730422 58.885 35.669988048834306 139.74792373773124 58.885 35.669988048834306 139.74792373773124 57.356 35.6699808400667 139.74791415730422 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3857db5d-c7d8-4c26-92b3-ab90938530e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3857db5d-c7d8-4c26-92b3-ab90938530e9_0">
											<gml:posList>35.669988048834306 139.74792373773124 57.356 35.669988048834306 139.74792373773124 58.885 35.66998498662009 139.7479271984556 58.885 35.66998498662009 139.7479271984556 57.356 35.669988048834306 139.74792373773124 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_5ef91010-44b4-41f1-ae1e-38250461106b_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49093c80-bab0-4897-bc31-aba08bda9e4b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669802383818514 139.74754311843395 57.356 35.66983362669129 139.74750696398027 57.356 35.66983518757742 139.747509083177 57.356 35.669803989741155 139.74754519339763 57.356 35.669802383818514 139.74754311843395 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4185f522-0fa2-4aab-9c84-9d883dc0e591">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66987042382832 139.74778997216166 58.2 35.66987134245926 139.74778888865492 58.2 35.66987425657628 139.74779266334295 58.2 35.66987332893159 139.7477937468593 58.2 35.66987042382832 139.74778997216166 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c0c89c7-3e19-497d-a997-1dd4b2c63bdd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66989368988797 139.74781762909896 57.356 35.66988563829317 139.7478270379959 57.356 35.669965482642525 139.74792964939587 57.356 35.66996362735069 139.7479318164278 57.356 35.66988246579916 139.74782751636542 57.356 35.66989140000952 139.74781707923162 57.356 35.66987332893159 139.7477937468593 57.356 35.66987425657628 139.74779266334295 57.356 35.66989368988797 139.74781762909896 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da36429f-3c23-4f3c-9c59-ac11d69747b2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698685522991 139.74746538187551 57.356 35.67010235747143 139.74776643927356 57.356 35.67009705279089 139.74777264186483 57.356 35.6700957896999 139.74777099732577 57.356 35.67009971643434 139.74776641999966 57.356 35.669868608846926 139.74746883927233 57.356 35.66985656749903 139.74748288082625 57.356 35.669855133001505 139.74748103764887 57.356 35.6698685522991 139.74746538187551 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a5797c97-e02f-43a8-a87a-7e163c5b7b2d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67010445141641 139.74810077304556 57.356 35.670102186891576 139.74809783715781 57.356 35.670097332465794 139.74810345379882 57.356 35.670013120839776 139.74799409747106 57.356 35.67001429166111 139.7479927375411 57.356 35.67009716802168 139.74810034998546 57.356 35.67010195040007 139.74809482179066 57.356 35.6701055952994 139.74809955674513 57.356 35.67010445141641 139.74810077304556 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45719c7e-e86a-4e05-b867-ae7476568f0e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011645768032 139.7480880018939 57.356 35.67011144153692 139.7480816335563 57.356 35.670146846720044 139.74804238180127 57.356 35.67002795498222 139.74788894383977 57.356 35.670027334584006 139.74784033012386 57.356 35.670051075160984 139.74781270031886 57.356 35.67005472906945 139.74781741315545 57.356 35.670053576246175 139.74781872888462 57.356 35.670051176398765 139.74781563850402 57.356 35.6700289308682 139.74784153245886 57.356 35.67002929722775 139.74788781569575 57.356 35.670148964859344 139.74804225803956 57.356 35.67011326236411 139.7480817089438 57.356 35.670117331346944 139.748087062036 57.356 35.67011645768032 139.7480880018939 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d78eb3e3-7281-4136-abc7-d4bd2e2eb53e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d78eb3e3-7281-4136-abc7-d4bd2e2eb53e_0">
											<gml:posList>35.67009716802168 139.74810034998546 57.356 35.67001429166111 139.7479927375411 57.356 35.67001429166111 139.7479927375411 59.136 35.67009716802168 139.74810034998546 59.136 35.67009716802168 139.74810034998546 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-329e03dc-1b23-487d-8372-1ac8d0e0fcc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-329e03dc-1b23-487d-8372-1ac8d0e0fcc4_0">
											<gml:posList>35.669855133001505 139.74748103764887 57.356 35.669855133001505 139.74748103764887 59.136 35.6698685522991 139.74746538187551 59.136 35.6698685522991 139.74746538187551 57.356 35.669855133001505 139.74748103764887 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-463c9987-eeb0-4b1d-b94e-10cefe98da0c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-463c9987-eeb0-4b1d-b94e-10cefe98da0c_0">
											<gml:posList>35.66985656749903 139.74748288082625 57.356 35.669868608846926 139.74746883927233 57.356 35.669868608846926 139.74746883927233 59.136 35.66985656749903 139.74748288082625 59.136 35.66985656749903 139.74748288082625 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-085530aa-fa55-433e-bc98-1b8039d49fea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-085530aa-fa55-433e-bc98-1b8039d49fea_0">
											<gml:posList>35.669855133001505 139.74748103764887 57.356 35.66985656749903 139.74748288082625 57.356 35.66985656749903 139.74748288082625 59.136 35.669855133001505 139.74748103764887 59.136 35.669855133001505 139.74748103764887 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3929373-b190-4506-94cc-daf60e09cf1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3929373-b190-4506-94cc-daf60e09cf1f_0">
											<gml:posList>35.66983518757742 139.747509083177 57.356 35.66983362669129 139.74750696398027 57.356 35.66983362669129 139.74750696398027 59.136 35.66983518757742 139.747509083177 59.136 35.66983518757742 139.747509083177 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fcb70d02-eecd-4f35-b0ee-6b0a340e97f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fcb70d02-eecd-4f35-b0ee-6b0a340e97f3_0">
											<gml:posList>35.66983362669129 139.74750696398027 57.356 35.669802383818514 139.74754311843395 57.356 35.669802383818514 139.74754311843395 59.136 35.66983362669129 139.74750696398027 59.136 35.66983362669129 139.74750696398027 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e76ab51-3d34-46a1-bf45-0315928e6168">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3e76ab51-3d34-46a1-bf45-0315928e6168_0">
											<gml:posList>35.66983518757742 139.747509083177 59.136 35.66983362669129 139.74750696398027 59.136 35.669802383818514 139.74754311843395 59.136 35.669803989741155 139.74754519339763 59.136 35.66983518757742 139.747509083177 59.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ae9f032-276d-4a95-a465-5f953031ecae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ae9f032-276d-4a95-a465-5f953031ecae_0">
											<gml:posList>35.669803989741155 139.74754519339763 57.356 35.66983518757742 139.747509083177 57.356 35.66983518757742 139.747509083177 59.136 35.669803989741155 139.74754519339763 59.136 35.669803989741155 139.74754519339763 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b24e4c5a-f0d8-480c-b52c-e533f0f8cad0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b24e4c5a-f0d8-480c-b52c-e533f0f8cad0_0">
											<gml:posList>35.669802383818514 139.74754311843395 57.356 35.669803989741155 139.74754519339763 57.356 35.669803989741155 139.74754519339763 59.136 35.669802383818514 139.74754311843395 59.136 35.669802383818514 139.74754311843395 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8857df0c-eead-45af-926d-572eeef507e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8857df0c-eead-45af-926d-572eeef507e7_0">
											<gml:posList>35.6698685522991 139.74746538187551 57.356 35.6698685522991 139.74746538187551 59.136 35.67010235747143 139.74776643927356 59.136 35.67010235747143 139.74776643927356 57.356 35.6698685522991 139.74746538187551 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b3535f93-ea36-49bc-ad82-fbea9bfa2c5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b3535f93-ea36-49bc-ad82-fbea9bfa2c5b_0">
											<gml:posList>35.669868608846926 139.74746883927233 57.356 35.67009971643434 139.74776641999966 57.356 35.67009971643434 139.74776641999966 59.136 35.669868608846926 139.74746883927233 59.136 35.669868608846926 139.74746883927233 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16c6e6f1-ea9d-46fe-86ff-1b911249464c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16c6e6f1-ea9d-46fe-86ff-1b911249464c_0">
											<gml:posList>35.66985656749903 139.74748288082625 59.136 35.669868608846926 139.74746883927233 59.136 35.67009971643434 139.74776641999966 59.136 35.6700957896999 139.74777099732577 59.136 35.67009705279089 139.74777264186483 59.136 35.67010235747143 139.74776643927356 59.136 35.6698685522991 139.74746538187551 59.136 35.669855133001505 139.74748103764887 59.136 35.66985656749903 139.74748288082625 59.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9bfbcfa-a15a-4022-94f7-213a439822e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9bfbcfa-a15a-4022-94f7-213a439822e4_0">
											<gml:posList>35.67009971643434 139.74776641999966 57.356 35.6700957896999 139.74777099732577 57.356 35.6700957896999 139.74777099732577 59.136 35.67009971643434 139.74776641999966 59.136 35.67009971643434 139.74776641999966 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c777b9c7-a5f9-4a3c-a39a-a2517f74b264">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c777b9c7-a5f9-4a3c-a39a-a2517f74b264_0">
											<gml:posList>35.67010235747143 139.74776643927356 57.356 35.67010235747143 139.74776643927356 59.136 35.67009705279089 139.74777264186483 59.136 35.67009705279089 139.74777264186483 57.356 35.67010235747143 139.74776643927356 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a2dea79-7cf9-42f4-8016-79f63fd5d5e4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a2dea79-7cf9-42f4-8016-79f63fd5d5e4_0">
											<gml:posList>35.6700957896999 139.74777099732577 57.356 35.67009705279089 139.74777264186483 57.356 35.67009705279089 139.74777264186483 59.136 35.6700957896999 139.74777099732577 59.136 35.6700957896999 139.74777099732577 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1cacbe23-131a-4e0c-87ae-2203db6855e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1cacbe23-131a-4e0c-87ae-2203db6855e7_0">
											<gml:posList>35.66987134245926 139.74778888865492 58.2 35.66987042382832 139.74778997216166 58.2 35.66987042382832 139.74778997216166 59.136 35.66987134245926 139.74778888865492 59.136 35.66987134245926 139.74778888865492 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f276f13-7489-4f4c-9107-ce324d3ef75e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f276f13-7489-4f4c-9107-ce324d3ef75e_0">
											<gml:posList>35.66987425657628 139.74779266334295 58.2 35.66987425657628 139.74779266334295 57.356 35.66987332893159 139.7477937468593 57.356 35.66987332893159 139.7477937468593 58.2 35.66987425657628 139.74779266334295 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f76d3fb6-34cf-4e96-b07a-3cbc215fe940">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f76d3fb6-34cf-4e96-b07a-3cbc215fe940_0">
											<gml:posList>35.66987134245926 139.74778888865492 59.136 35.66989368988797 139.74781762909896 59.136 35.66989368988797 139.74781762909896 57.356 35.66987425657628 139.74779266334295 57.356 35.66987425657628 139.74779266334295 58.2 35.66987134245926 139.74778888865492 58.2 35.66987134245926 139.74778888865492 59.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46fe7e77-759d-40eb-8805-82c5348ecfcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46fe7e77-759d-40eb-8805-82c5348ecfcc_0">
											<gml:posList>35.66987332893159 139.7477937468593 58.2 35.66987332893159 139.7477937468593 57.356 35.66989140000952 139.74781707923162 57.356 35.66989140000952 139.74781707923162 59.136 35.66987042382832 139.74778997216166 59.136 35.66987042382832 139.74778997216166 58.2 35.66987332893159 139.7477937468593 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-81c1756c-a688-4331-b2fc-04b825683600">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-81c1756c-a688-4331-b2fc-04b825683600_0">
											<gml:posList>35.67005472906945 139.74781741315545 57.356 35.670051075160984 139.74781270031886 57.356 35.670051075160984 139.74781270031886 59.136 35.67005472906945 139.74781741315545 59.136 35.67005472906945 139.74781741315545 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d47e35e3-f09e-4ac2-85f6-76cf1a96f06e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d47e35e3-f09e-4ac2-85f6-76cf1a96f06e_0">
											<gml:posList>35.670051176398765 139.74781563850402 57.356 35.670053576246175 139.74781872888462 57.356 35.670053576246175 139.74781872888462 59.136 35.670051176398765 139.74781563850402 59.136 35.670051176398765 139.74781563850402 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd1682d5-4606-45b3-a980-53ea261d784e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd1682d5-4606-45b3-a980-53ea261d784e_0">
											<gml:posList>35.670053576246175 139.74781872888462 57.356 35.67005472906945 139.74781741315545 57.356 35.67005472906945 139.74781741315545 59.136 35.670053576246175 139.74781872888462 59.136 35.670053576246175 139.74781872888462 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee64e4f6-97fc-42b1-a205-3e1ce51748c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ee64e4f6-97fc-42b1-a205-3e1ce51748c3_0">
											<gml:posList>35.66989140000952 139.74781707923162 57.356 35.66988246579916 139.74782751636542 57.356 35.66988246579916 139.74782751636542 59.136 35.66989140000952 139.74781707923162 59.136 35.66989140000952 139.74781707923162 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d9422865-d4af-4498-9d61-75bf6f64e38e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d9422865-d4af-4498-9d61-75bf6f64e38e_0">
											<gml:posList>35.66988563829317 139.7478270379959 57.356 35.66989368988797 139.74781762909896 57.356 35.66989368988797 139.74781762909896 59.136 35.66988563829317 139.7478270379959 59.136 35.66988563829317 139.7478270379959 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12baa45e-7b02-46d6-ac3e-4de8d6da5fca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12baa45e-7b02-46d6-ac3e-4de8d6da5fca_0">
											<gml:posList>35.670027334584006 139.74784033012386 57.356 35.670027334584006 139.74784033012386 59.136 35.670051075160984 139.74781270031886 59.136 35.670051075160984 139.74781270031886 57.356 35.670027334584006 139.74784033012386 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0a2c6175-6b4c-4dba-bc60-f522d0bc6cac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0a2c6175-6b4c-4dba-bc60-f522d0bc6cac_0">
											<gml:posList>35.670051176398765 139.74781563850402 57.356 35.670051176398765 139.74781563850402 59.136 35.6700289308682 139.74784153245886 59.136 35.6700289308682 139.74784153245886 57.356 35.670051176398765 139.74781563850402 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73c390f6-a164-4392-89f4-7c5b140cea25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73c390f6-a164-4392-89f4-7c5b140cea25_0">
											<gml:posList>35.66987042382832 139.74778997216166 59.136 35.66989140000952 139.74781707923162 59.136 35.66988246579916 139.74782751636542 59.136 35.66996362735069 139.7479318164278 59.136 35.669965482642525 139.74792964939587 59.136 35.66988563829317 139.7478270379959 59.136 35.66989368988797 139.74781762909896 59.136 35.66987134245926 139.74778888865492 59.136 35.66987042382832 139.74778997216166 59.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28d5667d-f08c-46ce-a6a0-cd09dac2a855">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28d5667d-f08c-46ce-a6a0-cd09dac2a855_0">
											<gml:posList>35.670027334584006 139.74784033012386 57.356 35.67002795498222 139.74788894383977 57.356 35.67002795498222 139.74788894383977 59.136 35.670027334584006 139.74784033012386 59.136 35.670027334584006 139.74784033012386 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ab6136bd-4a02-44bc-8248-055611350f1c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ab6136bd-4a02-44bc-8248-055611350f1c_0">
											<gml:posList>35.67002929722775 139.74788781569575 57.356 35.6700289308682 139.74784153245886 57.356 35.6700289308682 139.74784153245886 59.136 35.67002929722775 139.74788781569575 59.136 35.67002929722775 139.74788781569575 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0a2c38b-1c43-4aee-a578-2b7b0b312950">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0a2c38b-1c43-4aee-a578-2b7b0b312950_0">
											<gml:posList>35.669965482642525 139.74792964939587 57.356 35.66988563829317 139.7478270379959 57.356 35.66988563829317 139.7478270379959 59.136 35.669965482642525 139.74792964939587 59.136 35.669965482642525 139.74792964939587 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46ee96cd-7a80-4fe9-b5a0-97ea01f20041">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46ee96cd-7a80-4fe9-b5a0-97ea01f20041_0">
											<gml:posList>35.66996362735069 139.7479318164278 57.356 35.66996362735069 139.7479318164278 59.136 35.66988246579916 139.74782751636542 59.136 35.66988246579916 139.74782751636542 57.356 35.66996362735069 139.7479318164278 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d58ab0c8-d2e6-4d14-bd67-0f7d0fc298c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d58ab0c8-d2e6-4d14-bd67-0f7d0fc298c1_0">
											<gml:posList>35.669965482642525 139.74792964939587 57.356 35.669965482642525 139.74792964939587 59.136 35.66996362735069 139.7479318164278 59.136 35.66996362735069 139.7479318164278 57.356 35.669965482642525 139.74792964939587 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f4a04ae-a2d2-4b8b-9918-7c0c37bd0a31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f4a04ae-a2d2-4b8b-9918-7c0c37bd0a31_0">
											<gml:posList>35.67011326236411 139.7480817089438 59.136 35.670148964859344 139.74804225803956 59.136 35.67002929722775 139.74788781569575 59.136 35.6700289308682 139.74784153245886 59.136 35.670051176398765 139.74781563850402 59.136 35.670053576246175 139.74781872888462 59.136 35.67005472906945 139.74781741315545 59.136 35.670051075160984 139.74781270031886 59.136 35.670027334584006 139.74784033012386 59.136 35.67002795498222 139.74788894383977 59.136 35.670146846720044 139.74804238180127 59.136 35.67011144153692 139.7480816335563 59.136 35.67011645768032 139.7480880018939 59.136 35.670117331346944 139.748087062036 59.136 35.67011326236411 139.7480817089438 59.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e75dd4b3-ad4b-47ad-9243-496a47371051">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e75dd4b3-ad4b-47ad-9243-496a47371051_0">
											<gml:posList>35.67002929722775 139.74788781569575 57.356 35.67002929722775 139.74788781569575 59.136 35.670148964859344 139.74804225803956 59.136 35.670148964859344 139.74804225803956 57.356 35.67002929722775 139.74788781569575 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe4091ef-8674-48dd-9f27-2fef0c8d8259">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe4091ef-8674-48dd-9f27-2fef0c8d8259_0">
											<gml:posList>35.670146846720044 139.74804238180127 57.356 35.670146846720044 139.74804238180127 59.136 35.67002795498222 139.74788894383977 59.136 35.67002795498222 139.74788894383977 57.356 35.670146846720044 139.74804238180127 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af9f5044-ea96-47c8-aa25-41a24e951bd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af9f5044-ea96-47c8-aa25-41a24e951bd4_0">
											<gml:posList>35.67001429166111 139.7479927375411 57.356 35.670013120839776 139.74799409747106 57.356 35.670013120839776 139.74799409747106 59.136 35.67001429166111 139.7479927375411 59.136 35.67001429166111 139.7479927375411 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea1ef1fc-cd1e-40ff-abe6-5591f0002b27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea1ef1fc-cd1e-40ff-abe6-5591f0002b27_0">
											<gml:posList>35.67010195040007 139.74809482179066 59.136 35.67009716802168 139.74810034998546 59.136 35.67001429166111 139.7479927375411 59.136 35.670013120839776 139.74799409747106 59.136 35.670097332465794 139.74810345379882 59.136 35.670102186891576 139.74809783715781 59.136 35.67010445141641 139.74810077304556 59.136 35.6701055952994 139.74809955674513 59.136 35.67010195040007 139.74809482179066 59.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30f4c24f-327c-4ad7-8a10-2e65fb0b1268">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30f4c24f-327c-4ad7-8a10-2e65fb0b1268_0">
											<gml:posList>35.670097332465794 139.74810345379882 59.136 35.670013120839776 139.74799409747106 59.136 35.670013120839776 139.74799409747106 57.356 35.670097332465794 139.74810345379882 57.356 35.670097332465794 139.74810345379882 59.136</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e3639453-df34-44fc-a87f-1c8638681637">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e3639453-df34-44fc-a87f-1c8638681637_0">
											<gml:posList>35.67011326236411 139.7480817089438 57.356 35.670148964859344 139.74804225803956 57.356 35.670148964859344 139.74804225803956 59.136 35.67011326236411 139.7480817089438 59.136 35.67011326236411 139.7480817089438 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78c8da7b-4326-45ca-84b2-50964c6f9667">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78c8da7b-4326-45ca-84b2-50964c6f9667_0">
											<gml:posList>35.670146846720044 139.74804238180127 57.356 35.67011144153692 139.7480816335563 57.356 35.67011144153692 139.7480816335563 59.136 35.670146846720044 139.74804238180127 59.136 35.670146846720044 139.74804238180127 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea375967-3fea-4b4a-ae7b-74d04918d388">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea375967-3fea-4b4a-ae7b-74d04918d388_0">
											<gml:posList>35.670117331346944 139.748087062036 57.356 35.67011326236411 139.7480817089438 57.356 35.67011326236411 139.7480817089438 59.136 35.670117331346944 139.748087062036 59.136 35.670117331346944 139.748087062036 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33afc5f8-9fa3-4e7d-a89f-a134619bf428">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33afc5f8-9fa3-4e7d-a89f-a134619bf428_0">
											<gml:posList>35.67011144153692 139.7480816335563 57.356 35.67011645768032 139.7480880018939 57.356 35.67011645768032 139.7480880018939 59.136 35.67011144153692 139.7480816335563 59.136 35.67011144153692 139.7480816335563 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d841c92-025a-46d5-b100-f0cf2191de7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d841c92-025a-46d5-b100-f0cf2191de7e_0">
											<gml:posList>35.67011645768032 139.7480880018939 57.356 35.670117331346944 139.748087062036 57.356 35.670117331346944 139.748087062036 59.136 35.67011645768032 139.7480880018939 59.136 35.67011645768032 139.7480880018939 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5db38e6a-4688-45a6-97ac-8b056bb1b7d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5db38e6a-4688-45a6-97ac-8b056bb1b7d8_0">
											<gml:posList>35.6701055952994 139.74809955674513 57.356 35.67010195040007 139.74809482179066 57.356 35.67010195040007 139.74809482179066 59.136 35.6701055952994 139.74809955674513 59.136 35.6701055952994 139.74809955674513 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a93a1dd-7bb6-4f59-bd8e-1d217148d0e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a93a1dd-7bb6-4f59-bd8e-1d217148d0e9_0">
											<gml:posList>35.67010195040007 139.74809482179066 57.356 35.67009716802168 139.74810034998546 57.356 35.67009716802168 139.74810034998546 59.136 35.67010195040007 139.74809482179066 59.136 35.67010195040007 139.74809482179066 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2acaef9-e43d-44a0-bbf1-c626ce1f5eb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2acaef9-e43d-44a0-bbf1-c626ce1f5eb8_0">
											<gml:posList>35.670102186891576 139.74809783715781 57.356 35.67010445141641 139.74810077304556 57.356 35.67010445141641 139.74810077304556 59.136 35.670102186891576 139.74809783715781 59.136 35.670102186891576 139.74809783715781 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80d04f76-8a8e-456a-86a3-deaf4bdc51e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80d04f76-8a8e-456a-86a3-deaf4bdc51e2_0">
											<gml:posList>35.67010445141641 139.74810077304556 57.356 35.6701055952994 139.74809955674513 57.356 35.6701055952994 139.74809955674513 59.136 35.67010445141641 139.74810077304556 59.136 35.67010445141641 139.74810077304556 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fc41a9c-97af-41f5-9ee4-36d6fd7a2660">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9fc41a9c-97af-41f5-9ee4-36d6fd7a2660_0">
											<gml:posList>35.670102186891576 139.74809783715781 57.356 35.670102186891576 139.74809783715781 59.136 35.670097332465794 139.74810345379882 59.136 35.670097332465794 139.74810345379882 57.356 35.670102186891576 139.74809783715781 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-9e53f95c-a872-4762-8b35-696247f97b5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e53f95c-a872-4762-8b35-696247f97b5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e53f95c-a872-4762-8b35-696247f97b5f">
											<gml:posList>35.670120223304544 139.74814869689322 6.23 35.67010563310315 139.74816572357685 6.23 35.66984002697636 139.74782445764546 6.23 35.66986999079284 139.74778944240654 6.23 35.669857567489835 139.7477734055497 6.23 35.66984973206303 139.74778258224626 6.23 35.66972234168519 139.7476187930152 6.23 35.669785925724085 139.74754449472368 6.23 35.66976589683565 139.7475186681032 6.23 35.66978246839111 139.74749943001757 6.23 35.669774077988336 139.74748872420838 6.23 35.6698427955133 139.74740845532435 6.23 35.66985253916408 139.74742081661236 6.23 35.6698659584223 139.74740511664476 6.23 35.670147180752146 139.74777629990436 6.23 35.670136733464204 139.74778846190176 6.23 35.670144582545646 139.74779850559455 6.23 35.67007694547037 139.74787744774943 6.23 35.67006864523876 139.74786674176528 6.23 35.670061890589785 139.74787470224118 6.23 35.67020182103597 139.74805449627297 6.23 35.67018885191072 139.74806953294515 6.23 35.67019751290781 139.7480805699698 6.23 35.67012924523414 139.74816028584485 6.23 35.670120223304544 139.74814869689322 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a8eba84-6d89-4f23-bf68-6e4b644114ef">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a8eba84-6d89-4f23-bf68-6e4b644114ef">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a8eba84-6d89-4f23-bf68-6e4b644114ef">
											<gml:posList>35.66972234168519 139.7476187930152 68.63 35.669728335946274 139.74761897439203 68.63 35.66979497310396 139.7475411159586 68.63 35.66979510307597 139.74753377011015 68.63 35.66972234168519 139.7476187930152 68.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc8329a5-36ed-4784-b3b5-095d34909ce8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc8329a5-36ed-4784-b3b5-095d34909ce8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc8329a5-36ed-4784-b3b5-095d34909ce8">
											<gml:posList>35.669785925724085 139.74754449472368 58.2 35.66978609099563 139.7475360884052 58.2 35.66977275644595 139.74751889273116 58.2 35.66976589683565 139.7475186681032 58.2 35.669785925724085 139.74754449472368 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e6b220b5-54eb-4dc3-af1a-46b72ff495b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6b220b5-54eb-4dc3-af1a-46b72ff495b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6b220b5-54eb-4dc3-af1a-46b72ff495b0">
											<gml:posList>35.66978246839111 139.74749943001757 58.2 35.66976589683565 139.7475186681032 58.2 35.66977275644595 139.74751889273116 58.2 35.66978934601314 139.7474996325323 58.2 35.66978246839111 139.74749943001757 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8f614d9c-cf64-46ed-a504-03f1e31b8a72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f614d9c-cf64-46ed-a504-03f1e31b8a72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f614d9c-cf64-46ed-a504-03f1e31b8a72">
											<gml:posList>35.66978246839111 139.74749943001757 58.2 35.66978934601314 139.7474996325323 58.2 35.66978094658879 139.74748891568566 58.2 35.669774077988336 139.74748872420838 58.2 35.66978246839111 139.74749943001757 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-984494b3-a968-4d6d-8ac7-e1c34f9f76f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-984494b3-a968-4d6d-8ac7-e1c34f9f76f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-984494b3-a968-4d6d-8ac7-e1c34f9f76f9">
											<gml:posList>35.66984973206303 139.74778258224626 68.63 35.66984987107135 139.7477752474297 68.63 35.669728335946274 139.74761897439203 68.63 35.66972234168519 139.7476187930152 68.63 35.66984973206303 139.74778258224626 68.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9cb58684-04c0-4053-b688-a6fb0ee4c931">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cb58684-04c0-4053-b688-a6fb0ee4c931">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cb58684-04c0-4053-b688-a6fb0ee4c931">
											<gml:posList>35.66978609099563 139.7475360884052 58.2 35.669785925724085 139.74754449472368 58.2 35.66978943815718 139.7475403928332 58.2 35.66978609099563 139.7475360884052 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec9a0068-c0c7-4946-a381-a067c2cf3c54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec9a0068-c0c7-4946-a381-a067c2cf3c54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec9a0068-c0c7-4946-a381-a067c2cf3c54">
											<gml:posList>35.669774077988336 139.74748872420838 58.2 35.66978094658879 139.74748891568566 58.2 35.669842657268205 139.74741682848153 58.2 35.6698427955133 139.74740845532435 58.2 35.669774077988336 139.74748872420838 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-faa087f8-3d19-4282-9cca-914a974fbe86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faa087f8-3d19-4282-9cca-914a974fbe86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faa087f8-3d19-4282-9cca-914a974fbe86">
											<gml:posList>35.66991651732677 139.74769736690573 66.052 35.66979497310396 139.7475411159586 66.052 35.669728335946274 139.74761897439203 66.052 35.66984987107135 139.7477752474297 66.052 35.66991651732677 139.74769736690573 66.052</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4aa7316a-7c0f-4994-850b-1e190cd6177d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4aa7316a-7c0f-4994-850b-1e190cd6177d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4aa7316a-7c0f-4994-850b-1e190cd6177d">
											<gml:posList>35.66985253916408 139.74742081661236 58.2 35.6698427955133 139.74740845532435 58.2 35.669842657268205 139.74741682848153 58.2 35.669852400918124 139.74742918977054 58.2 35.66985253916408 139.74742081661236 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-82deefb6-48e6-43d5-ac85-e4732e2878c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82deefb6-48e6-43d5-ac85-e4732e2878c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82deefb6-48e6-43d5-ac85-e4732e2878c7">
											<gml:posList>35.66986999079284 139.74778944240654 58.2 35.66984002697636 139.74782445764546 58.2 35.66984688656251 139.74782464916126 58.2 35.66987684136529 139.74778963392902 58.2 35.66986999079284 139.74778944240654 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2390376f-ba55-4436-bbd4-1b25be25b548">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2390376f-ba55-4436-bbd4-1b25be25b548">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2390376f-ba55-4436-bbd4-1b25be25b548">
											<gml:posList>35.66979510307597 139.74753377011015 68.63 35.66979497310396 139.7475411159586 68.63 35.66991651732677 139.74769736690573 68.63 35.66992250256596 139.74769753725226 68.63 35.66979510307597 139.74753377011015 68.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-50db96bc-551e-4f51-9ead-9a12b8c5fdb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50db96bc-551e-4f51-9ead-9a12b8c5fdb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50db96bc-551e-4f51-9ead-9a12b8c5fdb9">
											<gml:posList>35.66985253916408 139.74742081661236 58.2 35.669852400918124 139.74742918977054 58.2 35.66986574813069 139.74741357825107 58.2 35.6698659584223 139.74740511664476 58.2 35.66985253916408 139.74742081661236 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f23d5961-6a24-4cbf-af91-ec45e463a988">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f23d5961-6a24-4cbf-af91-ec45e463a988">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f23d5961-6a24-4cbf-af91-ec45e463a988">
											<gml:posList>35.66986107092483 139.74776931472138 58.2 35.669857567489835 139.7477734055497 58.2 35.66986441807802 139.74777361916315 58.2 35.66986107092483 139.74776931472138 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d367b190-3758-40aa-be0a-3f7098ddddb5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d367b190-3758-40aa-be0a-3f7098ddddb5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d367b190-3758-40aa-be0a-3f7098ddddb5">
											<gml:posList>35.66986999079284 139.74778944240654 58.2 35.66987684136529 139.74778963392902 58.2 35.66986441807802 139.74777361916315 58.2 35.669857567489835 139.7477734055497 58.2 35.66986999079284 139.74778944240654 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d7eb142d-1bc6-44fa-8f76-6ee6ad78323c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7eb142d-1bc6-44fa-8f76-6ee6ad78323c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7eb142d-1bc6-44fa-8f76-6ee6ad78323c">
											<gml:posList>35.66992250256596 139.74769753725226 68.63 35.66991651732677 139.74769736690573 68.63 35.66984987107135 139.7477752474297 68.63 35.66984973206303 139.74778258224626 68.63 35.66992250256596 139.74769753725226 68.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d9f8b26-58a2-47c1-ad1c-7c671707ad05">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d9f8b26-58a2-47c1-ad1c-7c671707ad05">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d9f8b26-58a2-47c1-ad1c-7c671707ad05">
											<gml:posList>35.67010563310315 139.74816572357685 58.2 35.67010578939646 139.74815730618937 58.2 35.66984688656251 139.74782464916126 58.2 35.66984002697636 139.74782445764546 58.2 35.67010563310315 139.74816572357685 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9e2df9d7-aba0-4980-ad35-fe76fa10e793">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9e2df9d7-aba0-4980-ad35-fe76fa10e793">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9e2df9d7-aba0-4980-ad35-fe76fa10e793">
											<gml:posList>35.67018195625477 139.74806931935356 57.356 35.67019494339964 139.74805427161724 57.356 35.670055040017665 139.74787451071103 57.356 35.67006879248177 139.74785830229834 57.356 35.67007710174354 139.74786903036446 57.356 35.67013770492451 139.74779830305334 57.356 35.67012985583518 139.74778824831523 57.356 35.67014035716622 139.74777603103 57.356 35.66986574813069 139.74741357825107 57.356 35.669852400918124 139.74742918977054 57.356 35.669842657268205 139.74741682848153 57.356 35.66978094658879 139.74748891568566 57.356 35.66978934601314 139.7474996325323 57.356 35.66977275644595 139.74751889273116 57.356 35.66978609099563 139.7475360884052 57.356 35.66978943815718 139.7475403928332 57.356 35.66979510307597 139.74753377011015 57.356 35.66992250256596 139.74769753725226 57.356 35.66986107092483 139.74776931472138 57.356 35.66986441807802 139.74777361916315 57.356 35.66987684136529 139.74778963392902 57.356 35.66984688656251 139.74782464916126 57.356 35.67010578939646 139.74815730618937 57.356 35.670120379604484 139.7481402905504 57.356 35.670129401527085 139.7481518684549 57.356 35.670190626281254 139.7480803784601 57.356 35.67018195625477 139.74806931935356 57.356</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d71fa8cc-cb4a-4310-a0b9-0cf23f45cd52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d71fa8cc-cb4a-4310-a0b9-0cf23f45cd52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d71fa8cc-cb4a-4310-a0b9-0cf23f45cd52">
											<gml:posList>35.6698659584223 139.74740511664476 58.2 35.66986574813069 139.74741357825107 58.2 35.67014035716622 139.74777603103 58.2 35.670147180752146 139.74777629990436 58.2 35.6698659584223 139.74740511664476 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-55b9b92d-3a05-4de2-8c9b-9c9ecb14fe43">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55b9b92d-3a05-4de2-8c9b-9c9ecb14fe43">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55b9b92d-3a05-4de2-8c9b-9c9ecb14fe43">
											<gml:posList>35.67006864523876 139.74786674176528 58.2 35.67006879248177 139.74785830229834 58.2 35.670055040017665 139.74787451071103 58.2 35.670061890589785 139.74787470224118 58.2 35.67006864523876 139.74786674176528 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1ac4e09f-2334-411b-a167-3b8cb552cfc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1ac4e09f-2334-411b-a167-3b8cb552cfc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1ac4e09f-2334-411b-a167-3b8cb552cfc6">
											<gml:posList>35.67006864523876 139.74786674176528 58.2 35.67007694547037 139.74787744774943 58.2 35.67007710174354 139.74786903036446 58.2 35.67006879248177 139.74785830229834 58.2 35.67006864523876 139.74786674176528 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5479f0f-341c-447c-a985-d1644fed30a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5479f0f-341c-447c-a985-d1644fed30a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5479f0f-341c-447c-a985-d1644fed30a9">
											<gml:posList>35.670144582545646 139.74779850559455 58.2 35.67013770492451 139.74779830305334 58.2 35.67007710174354 139.74786903036446 58.2 35.67007694547037 139.74787744774943 58.2 35.670144582545646 139.74779850559455 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-352e5635-9f59-40b9-849a-0d6c3cd16330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-352e5635-9f59-40b9-849a-0d6c3cd16330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-352e5635-9f59-40b9-849a-0d6c3cd16330">
											<gml:posList>35.670120223304544 139.74814869689322 58.2 35.670120379604484 139.7481402905504 58.2 35.67010578939646 139.74815730618937 58.2 35.67010563310315 139.74816572357685 58.2 35.670120223304544 139.74814869689322 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e7e693e-5d43-4308-a2df-dd24d387f5fd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e7e693e-5d43-4308-a2df-dd24d387f5fd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e7e693e-5d43-4308-a2df-dd24d387f5fd">
											<gml:posList>35.670120223304544 139.74814869689322 58.2 35.67012924523414 139.74816028584485 58.2 35.670129401527085 139.7481518684549 58.2 35.670120379604484 139.7481402905504 58.2 35.670120223304544 139.74814869689322 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0e0f8e65-ded2-4e68-ad4b-56a908403875">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e0f8e65-ded2-4e68-ad4b-56a908403875">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e0f8e65-ded2-4e68-ad4b-56a908403875">
											<gml:posList>35.670061890589785 139.74787470224118 58.2 35.670055040017665 139.74787451071103 58.2 35.67019494339964 139.74805427161724 58.2 35.67020182103597 139.74805449627297 58.2 35.670061890589785 139.74787470224118 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-09f571c3-11b7-4cf1-86b3-7758ec1e48f7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-09f571c3-11b7-4cf1-86b3-7758ec1e48f7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-09f571c3-11b7-4cf1-86b3-7758ec1e48f7">
											<gml:posList>35.670136733464204 139.74778846190176 58.2 35.67012985583518 139.74778824831523 58.2 35.67013770492451 139.74779830305334 58.2 35.670144582545646 139.74779850559455 58.2 35.670136733464204 139.74778846190176 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8942334c-0c9a-4a42-a9ef-1d7a553b8161">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8942334c-0c9a-4a42-a9ef-1d7a553b8161">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8942334c-0c9a-4a42-a9ef-1d7a553b8161">
											<gml:posList>35.670136733464204 139.74778846190176 58.2 35.670147180752146 139.74777629990436 58.2 35.67014035716622 139.74777603103 58.2 35.67012985583518 139.74778824831523 58.2 35.670136733464204 139.74778846190176 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-adac6feb-7681-4009-94dc-015ecc099a74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adac6feb-7681-4009-94dc-015ecc099a74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adac6feb-7681-4009-94dc-015ecc099a74">
											<gml:posList>35.67019751290781 139.7480805699698 58.2 35.670190626281254 139.7480803784601 58.2 35.670129401527085 139.7481518684549 58.2 35.67012924523414 139.74816028584485 58.2 35.67019751290781 139.7480805699698 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed77eefd-934f-47b3-add2-a1d2b1ace7d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed77eefd-934f-47b3-add2-a1d2b1ace7d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed77eefd-934f-47b3-add2-a1d2b1ace7d0">
											<gml:posList>35.67018885191072 139.74806953294515 58.2 35.67018195625477 139.74806931935356 58.2 35.670190626281254 139.7480803784601 58.2 35.67019751290781 139.7480805699698 58.2 35.67018885191072 139.74806953294515 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e1d7ed1d-0e29-47f4-abd8-9b0be45ddb70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1d7ed1d-0e29-47f4-abd8-9b0be45ddb70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1d7ed1d-0e29-47f4-abd8-9b0be45ddb70">
											<gml:posList>35.67018885191072 139.74806953294515 58.2 35.67020182103597 139.74805449627297 58.2 35.67019494339964 139.74805427161724 58.2 35.67018195625477 139.74806931935356 58.2 35.67018885191072 139.74806953294515 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-926f0a42-5955-4801-8c7f-4ba265151f56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-926f0a42-5955-4801-8c7f-4ba265151f56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-926f0a42-5955-4801-8c7f-4ba265151f56">
											<gml:posList>35.66979497310396 139.7475411159586 68.63 35.66979497310396 139.7475411159586 66.052 35.66991651732677 139.74769736690573 66.052 35.66991651732677 139.74769736690573 68.63 35.66979497310396 139.7475411159586 68.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-904e6272-18f0-4fc0-b834-9d70d02a9f7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-904e6272-18f0-4fc0-b834-9d70d02a9f7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-904e6272-18f0-4fc0-b834-9d70d02a9f7e">
											<gml:posList>35.66984987107135 139.7477752474297 68.63 35.66984987107135 139.7477752474297 66.052 35.669728335946274 139.74761897439203 66.052 35.669728335946274 139.74761897439203 68.63 35.66984987107135 139.7477752474297 68.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7949d4c-f3e9-4e9e-85e4-1116ab37be08">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7949d4c-f3e9-4e9e-85e4-1116ab37be08">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7949d4c-f3e9-4e9e-85e4-1116ab37be08">
											<gml:posList>35.66986441807802 139.74777361916315 58.2 35.66986441807802 139.74777361916315 57.356 35.66986107092483 139.74776931472138 57.356 35.66986107092483 139.74776931472138 58.2 35.66986441807802 139.74777361916315 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a105b8f-3cc2-492d-abca-78ef9aef17de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a105b8f-3cc2-492d-abca-78ef9aef17de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a105b8f-3cc2-492d-abca-78ef9aef17de">
											<gml:posList>35.66987684136529 139.74778963392902 58.2 35.66987684136529 139.74778963392902 57.356 35.66986441807802 139.74777361916315 57.356 35.66986441807802 139.74777361916315 58.2 35.66987684136529 139.74778963392902 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eef9a495-ebe7-479b-9cde-4a15a05b8484">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eef9a495-ebe7-479b-9cde-4a15a05b8484">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eef9a495-ebe7-479b-9cde-4a15a05b8484">
											<gml:posList>35.670055040017665 139.74787451071103 58.2 35.670055040017665 139.74787451071103 57.356 35.67019494339964 139.74805427161724 57.356 35.67019494339964 139.74805427161724 58.2 35.670055040017665 139.74787451071103 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-42bd0ac4-e471-4827-b6d9-46fdde6028a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-42bd0ac4-e471-4827-b6d9-46fdde6028a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-42bd0ac4-e471-4827-b6d9-46fdde6028a0">
											<gml:posList>35.6698659584223 139.74740511664476 6.23 35.66985253916408 139.74742081661236 6.23 35.66985253916408 139.74742081661236 58.2 35.6698659584223 139.74740511664476 58.2 35.6698659584223 139.74740511664476 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-71b34b6f-352b-4f32-ac25-06c077149766">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71b34b6f-352b-4f32-ac25-06c077149766">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71b34b6f-352b-4f32-ac25-06c077149766">
											<gml:posList>35.66985253916408 139.74742081661236 6.23 35.6698427955133 139.74740845532435 6.23 35.6698427955133 139.74740845532435 58.2 35.66985253916408 139.74742081661236 58.2 35.66985253916408 139.74742081661236 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9acf5595-ad5c-4637-b6b8-e3d4834bfa06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9acf5595-ad5c-4637-b6b8-e3d4834bfa06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9acf5595-ad5c-4637-b6b8-e3d4834bfa06">
											<gml:posList>35.669852400918124 139.74742918977054 58.2 35.669852400918124 139.74742918977054 57.356 35.66986574813069 139.74741357825107 57.356 35.66986574813069 139.74741357825107 58.2 35.669852400918124 139.74742918977054 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91fdfb08-4ea2-423d-918e-e524c674742e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91fdfb08-4ea2-423d-918e-e524c674742e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91fdfb08-4ea2-423d-918e-e524c674742e">
											<gml:posList>35.669842657268205 139.74741682848153 58.2 35.669842657268205 139.74741682848153 57.356 35.669852400918124 139.74742918977054 57.356 35.669852400918124 139.74742918977054 58.2 35.669842657268205 139.74741682848153 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-feaaea18-50c5-4e47-b53e-68e1a6ccc269">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-feaaea18-50c5-4e47-b53e-68e1a6ccc269">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-feaaea18-50c5-4e47-b53e-68e1a6ccc269">
											<gml:posList>35.6698427955133 139.74740845532435 6.23 35.669774077988336 139.74748872420838 6.23 35.669774077988336 139.74748872420838 58.2 35.6698427955133 139.74740845532435 58.2 35.6698427955133 139.74740845532435 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1dc3a94-6fd7-473f-920c-c665647c7041">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1dc3a94-6fd7-473f-920c-c665647c7041">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1dc3a94-6fd7-473f-920c-c665647c7041">
											<gml:posList>35.66978094658879 139.74748891568566 58.2 35.66978094658879 139.74748891568566 57.356 35.669842657268205 139.74741682848153 57.356 35.669842657268205 139.74741682848153 58.2 35.66978094658879 139.74748891568566 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c51afde-3d38-4db1-b62d-5bee0f2369a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c51afde-3d38-4db1-b62d-5bee0f2369a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c51afde-3d38-4db1-b62d-5bee0f2369a0">
											<gml:posList>35.669774077988336 139.74748872420838 6.23 35.66978246839111 139.74749943001757 6.23 35.66978246839111 139.74749943001757 58.2 35.669774077988336 139.74748872420838 58.2 35.669774077988336 139.74748872420838 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41fce141-dcb7-4b7e-8b7d-3358af6a90a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41fce141-dcb7-4b7e-8b7d-3358af6a90a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41fce141-dcb7-4b7e-8b7d-3358af6a90a0">
											<gml:posList>35.66978934601314 139.7474996325323 58.2 35.66978934601314 139.7474996325323 57.356 35.66978094658879 139.74748891568566 57.356 35.66978094658879 139.74748891568566 58.2 35.66978934601314 139.7474996325323 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a82710ad-528e-4ee2-bc46-fdfe8f3ea6d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a82710ad-528e-4ee2-bc46-fdfe8f3ea6d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a82710ad-528e-4ee2-bc46-fdfe8f3ea6d7">
											<gml:posList>35.66978246839111 139.74749943001757 6.23 35.66976589683565 139.7475186681032 6.23 35.66976589683565 139.7475186681032 58.2 35.66978246839111 139.74749943001757 58.2 35.66978246839111 139.74749943001757 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-24355b6e-623a-4606-8b92-2a97376c5d06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-24355b6e-623a-4606-8b92-2a97376c5d06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-24355b6e-623a-4606-8b92-2a97376c5d06">
											<gml:posList>35.66977275644595 139.74751889273116 58.2 35.66977275644595 139.74751889273116 57.356 35.66978934601314 139.7474996325323 57.356 35.66978934601314 139.7474996325323 58.2 35.66977275644595 139.74751889273116 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0a695fd-8dea-444e-bbb2-4be4e3e22f20">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0a695fd-8dea-444e-bbb2-4be4e3e22f20">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0a695fd-8dea-444e-bbb2-4be4e3e22f20">
											<gml:posList>35.66978609099563 139.7475360884052 58.2 35.66978609099563 139.7475360884052 57.356 35.66977275644595 139.74751889273116 57.356 35.66977275644595 139.74751889273116 58.2 35.66978609099563 139.7475360884052 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf23f610-7b2d-4de0-8d34-69133bdb69a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf23f610-7b2d-4de0-8d34-69133bdb69a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf23f610-7b2d-4de0-8d34-69133bdb69a5">
											<gml:posList>35.66976589683565 139.7475186681032 6.23 35.669785925724085 139.74754449472368 6.23 35.669785925724085 139.74754449472368 58.2 35.66976589683565 139.7475186681032 58.2 35.66976589683565 139.7475186681032 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f8a5825-87d9-4cdc-b21a-5acd17b49184">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f8a5825-87d9-4cdc-b21a-5acd17b49184">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f8a5825-87d9-4cdc-b21a-5acd17b49184">
											<gml:posList>35.66978943815718 139.7475403928332 58.2 35.66978943815718 139.7475403928332 57.356 35.66978609099563 139.7475360884052 57.356 35.66978609099563 139.7475360884052 58.2 35.66978943815718 139.7475403928332 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e8042b85-0836-4cff-9737-e74bba42201f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e8042b85-0836-4cff-9737-e74bba42201f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e8042b85-0836-4cff-9737-e74bba42201f">
											<gml:posList>35.669785925724085 139.74754449472368 58.2 35.669785925724085 139.74754449472368 6.23 35.66972234168519 139.7476187930152 6.23 35.66972234168519 139.7476187930152 68.63 35.66979510307597 139.74753377011015 68.63 35.66979510307597 139.74753377011015 57.356 35.66978943815718 139.7475403928332 57.356 35.66978943815718 139.7475403928332 58.2 35.669785925724085 139.74754449472368 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3d2aaa8f-b62a-4dba-88e7-a004ac3d88ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d2aaa8f-b62a-4dba-88e7-a004ac3d88ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d2aaa8f-b62a-4dba-88e7-a004ac3d88ca">
											<gml:posList>35.669728335946274 139.74761897439203 68.63 35.669728335946274 139.74761897439203 66.052 35.66979497310396 139.7475411159586 66.052 35.66979497310396 139.7475411159586 68.63 35.669728335946274 139.74761897439203 68.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f631d435-4941-417b-a10f-b7930cc2b141">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f631d435-4941-417b-a10f-b7930cc2b141">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f631d435-4941-417b-a10f-b7930cc2b141">
											<gml:posList>35.670147180752146 139.74777629990436 6.23 35.6698659584223 139.74740511664476 6.23 35.6698659584223 139.74740511664476 58.2 35.670147180752146 139.74777629990436 58.2 35.670147180752146 139.74777629990436 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-47afabd5-19a7-4237-b154-0c8f33c87707">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-47afabd5-19a7-4237-b154-0c8f33c87707">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-47afabd5-19a7-4237-b154-0c8f33c87707">
											<gml:posList>35.66986574813069 139.74741357825107 58.2 35.66986574813069 139.74741357825107 57.356 35.67014035716622 139.74777603103 57.356 35.67014035716622 139.74777603103 58.2 35.66986574813069 139.74741357825107 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-915bcea9-e95a-428f-b046-10b1790cf27f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-915bcea9-e95a-428f-b046-10b1790cf27f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-915bcea9-e95a-428f-b046-10b1790cf27f">
											<gml:posList>35.66979510307597 139.74753377011015 68.63 35.66992250256596 139.74769753725226 68.63 35.66992250256596 139.74769753725226 57.356 35.66979510307597 139.74753377011015 57.356 35.66979510307597 139.74753377011015 68.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4cf2b215-5e9f-4015-8871-9603a0bdd62c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cf2b215-5e9f-4015-8871-9603a0bdd62c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cf2b215-5e9f-4015-8871-9603a0bdd62c">
											<gml:posList>35.66972234168519 139.7476187930152 68.63 35.66972234168519 139.7476187930152 6.23 35.66984973206303 139.74778258224626 6.23 35.66984973206303 139.74778258224626 68.63 35.66972234168519 139.7476187930152 68.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8819d459-15d1-4931-b7b8-d8bdc295b536">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8819d459-15d1-4931-b7b8-d8bdc295b536">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8819d459-15d1-4931-b7b8-d8bdc295b536">
											<gml:posList>35.66991651732677 139.74769736690573 68.63 35.66991651732677 139.74769736690573 66.052 35.66984987107135 139.7477752474297 66.052 35.66984987107135 139.7477752474297 68.63 35.66991651732677 139.74769736690573 68.63</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b6b8a66-d3ee-4a18-a6a9-b4ae1322cfcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b6b8a66-d3ee-4a18-a6a9-b4ae1322cfcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b6b8a66-d3ee-4a18-a6a9-b4ae1322cfcf">
											<gml:posList>35.66986107092483 139.74776931472138 58.2 35.66986107092483 139.74776931472138 57.356 35.66992250256596 139.74769753725226 57.356 35.66992250256596 139.74769753725226 68.63 35.66984973206303 139.74778258224626 68.63 35.66984973206303 139.74778258224626 6.23 35.669857567489835 139.7477734055497 6.23 35.669857567489835 139.7477734055497 58.2 35.66986107092483 139.74776931472138 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-455c549a-c3c0-4e27-88bd-e8ae767f3703">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-455c549a-c3c0-4e27-88bd-e8ae767f3703">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-455c549a-c3c0-4e27-88bd-e8ae767f3703">
											<gml:posList>35.669857567489835 139.7477734055497 6.23 35.66986999079284 139.74778944240654 6.23 35.66986999079284 139.74778944240654 58.2 35.669857567489835 139.7477734055497 58.2 35.669857567489835 139.7477734055497 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7897122-d983-4610-8302-01fe1ac4896c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7897122-d983-4610-8302-01fe1ac4896c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7897122-d983-4610-8302-01fe1ac4896c">
											<gml:posList>35.67014035716622 139.74777603103 58.2 35.67014035716622 139.74777603103 57.356 35.67012985583518 139.74778824831523 57.356 35.67012985583518 139.74778824831523 58.2 35.67014035716622 139.74777603103 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7532bb37-5b31-4954-94c5-8b065b9a018a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7532bb37-5b31-4954-94c5-8b065b9a018a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7532bb37-5b31-4954-94c5-8b065b9a018a">
											<gml:posList>35.670136733464204 139.74778846190176 6.23 35.670147180752146 139.74777629990436 6.23 35.670147180752146 139.74777629990436 58.2 35.670136733464204 139.74778846190176 58.2 35.670136733464204 139.74778846190176 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-739c80bb-ae8e-4b6e-84fa-d45bc79bc7cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-739c80bb-ae8e-4b6e-84fa-d45bc79bc7cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-739c80bb-ae8e-4b6e-84fa-d45bc79bc7cf">
											<gml:posList>35.67012985583518 139.74778824831523 58.2 35.67012985583518 139.74778824831523 57.356 35.67013770492451 139.74779830305334 57.356 35.67013770492451 139.74779830305334 58.2 35.67012985583518 139.74778824831523 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab92e6b4-8c6e-4927-a618-965a373ce703">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab92e6b4-8c6e-4927-a618-965a373ce703">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab92e6b4-8c6e-4927-a618-965a373ce703">
											<gml:posList>35.670144582545646 139.74779850559455 6.23 35.670136733464204 139.74778846190176 6.23 35.670136733464204 139.74778846190176 58.2 35.670144582545646 139.74779850559455 58.2 35.670144582545646 139.74779850559455 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e66a8823-34b5-41cd-b8dc-2c614ed8dce5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e66a8823-34b5-41cd-b8dc-2c614ed8dce5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e66a8823-34b5-41cd-b8dc-2c614ed8dce5">
											<gml:posList>35.66986999079284 139.74778944240654 6.23 35.66984002697636 139.74782445764546 6.23 35.66984002697636 139.74782445764546 58.2 35.66986999079284 139.74778944240654 58.2 35.66986999079284 139.74778944240654 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-52ce875e-a15a-47ea-ad62-c1c6355e5d15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-52ce875e-a15a-47ea-ad62-c1c6355e5d15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-52ce875e-a15a-47ea-ad62-c1c6355e5d15">
											<gml:posList>35.66984688656251 139.74782464916126 58.2 35.66984688656251 139.74782464916126 57.356 35.66987684136529 139.74778963392902 57.356 35.66987684136529 139.74778963392902 58.2 35.66984688656251 139.74782464916126 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6f0c3838-fb82-41bf-a41f-ab0919b052c0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6f0c3838-fb82-41bf-a41f-ab0919b052c0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6f0c3838-fb82-41bf-a41f-ab0919b052c0">
											<gml:posList>35.67013770492451 139.74779830305334 58.2 35.67013770492451 139.74779830305334 57.356 35.67007710174354 139.74786903036446 57.356 35.67007710174354 139.74786903036446 58.2 35.67013770492451 139.74779830305334 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34eb6228-781f-4c0c-9cdc-9bb5337f07a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34eb6228-781f-4c0c-9cdc-9bb5337f07a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34eb6228-781f-4c0c-9cdc-9bb5337f07a1">
											<gml:posList>35.67007694547037 139.74787744774943 6.23 35.670144582545646 139.74779850559455 6.23 35.670144582545646 139.74779850559455 58.2 35.67007694547037 139.74787744774943 58.2 35.67007694547037 139.74787744774943 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8460100f-fe23-415d-ad13-fe1bd828a79d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8460100f-fe23-415d-ad13-fe1bd828a79d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8460100f-fe23-415d-ad13-fe1bd828a79d">
											<gml:posList>35.67007710174354 139.74786903036446 58.2 35.67007710174354 139.74786903036446 57.356 35.67006879248177 139.74785830229834 57.356 35.67006879248177 139.74785830229834 58.2 35.67007710174354 139.74786903036446 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7ae42a5-c7a8-449c-89c7-efa5bf492cd9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7ae42a5-c7a8-449c-89c7-efa5bf492cd9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7ae42a5-c7a8-449c-89c7-efa5bf492cd9">
											<gml:posList>35.67006879248177 139.74785830229834 58.2 35.67006879248177 139.74785830229834 57.356 35.670055040017665 139.74787451071103 57.356 35.670055040017665 139.74787451071103 58.2 35.67006879248177 139.74785830229834 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebe42325-e1c2-44b4-a71c-3f1268350947">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebe42325-e1c2-44b4-a71c-3f1268350947">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebe42325-e1c2-44b4-a71c-3f1268350947">
											<gml:posList>35.670061890589785 139.74787470224118 6.23 35.67006864523876 139.74786674176528 6.23 35.67006864523876 139.74786674176528 58.2 35.670061890589785 139.74787470224118 58.2 35.670061890589785 139.74787470224118 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ebf31d8e-4e73-43bd-a101-44ab79a74e30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ebf31d8e-4e73-43bd-a101-44ab79a74e30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ebf31d8e-4e73-43bd-a101-44ab79a74e30">
											<gml:posList>35.67020182103597 139.74805449627297 6.23 35.670061890589785 139.74787470224118 6.23 35.670061890589785 139.74787470224118 58.2 35.67020182103597 139.74805449627297 58.2 35.67020182103597 139.74805449627297 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-959a9e56-fd6a-42df-a54a-ce686a53755e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-959a9e56-fd6a-42df-a54a-ce686a53755e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-959a9e56-fd6a-42df-a54a-ce686a53755e">
											<gml:posList>35.67010578939646 139.74815730618937 58.2 35.67010578939646 139.74815730618937 57.356 35.66984688656251 139.74782464916126 57.356 35.66984688656251 139.74782464916126 58.2 35.67010578939646 139.74815730618937 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a27a1af-c777-4008-ad3a-b8fd416dfc4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a27a1af-c777-4008-ad3a-b8fd416dfc4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a27a1af-c777-4008-ad3a-b8fd416dfc4e">
											<gml:posList>35.66984002697636 139.74782445764546 6.23 35.67010563310315 139.74816572357685 6.23 35.67010563310315 139.74816572357685 58.2 35.66984002697636 139.74782445764546 58.2 35.66984002697636 139.74782445764546 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8c07426b-1fbd-40bd-83cb-0bf3439b963a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c07426b-1fbd-40bd-83cb-0bf3439b963a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c07426b-1fbd-40bd-83cb-0bf3439b963a">
											<gml:posList>35.67019494339964 139.74805427161724 58.2 35.67019494339964 139.74805427161724 57.356 35.67018195625477 139.74806931935356 57.356 35.67018195625477 139.74806931935356 58.2 35.67019494339964 139.74805427161724 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb119cec-6f36-414f-9c05-4e0d81816c01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb119cec-6f36-414f-9c05-4e0d81816c01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb119cec-6f36-414f-9c05-4e0d81816c01">
											<gml:posList>35.67018885191072 139.74806953294515 6.23 35.67020182103597 139.74805449627297 6.23 35.67020182103597 139.74805449627297 58.2 35.67018885191072 139.74806953294515 58.2 35.67018885191072 139.74806953294515 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81ab6a3b-e936-4082-bf41-5ee4e76522ab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81ab6a3b-e936-4082-bf41-5ee4e76522ab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81ab6a3b-e936-4082-bf41-5ee4e76522ab">
											<gml:posList>35.67018195625477 139.74806931935356 58.2 35.67018195625477 139.74806931935356 57.356 35.670190626281254 139.7480803784601 57.356 35.670190626281254 139.7480803784601 58.2 35.67018195625477 139.74806931935356 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e32ac4d3-e94c-4682-95ad-94a08c50cf47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e32ac4d3-e94c-4682-95ad-94a08c50cf47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e32ac4d3-e94c-4682-95ad-94a08c50cf47">
											<gml:posList>35.67019751290781 139.7480805699698 6.23 35.67018885191072 139.74806953294515 6.23 35.67018885191072 139.74806953294515 58.2 35.67019751290781 139.7480805699698 58.2 35.67019751290781 139.7480805699698 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8111f1e4-1706-4e2d-b7fc-113cdea49b8d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8111f1e4-1706-4e2d-b7fc-113cdea49b8d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8111f1e4-1706-4e2d-b7fc-113cdea49b8d">
											<gml:posList>35.670190626281254 139.7480803784601 58.2 35.670190626281254 139.7480803784601 57.356 35.670129401527085 139.7481518684549 57.356 35.670129401527085 139.7481518684549 58.2 35.670190626281254 139.7480803784601 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d3fca5cf-04c4-46d7-a610-cf9d1e4a25d9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3fca5cf-04c4-46d7-a610-cf9d1e4a25d9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3fca5cf-04c4-46d7-a610-cf9d1e4a25d9">
											<gml:posList>35.67012924523414 139.74816028584485 6.23 35.67019751290781 139.7480805699698 6.23 35.67019751290781 139.7480805699698 58.2 35.67012924523414 139.74816028584485 58.2 35.67012924523414 139.74816028584485 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-104f1502-7a1e-4686-a6e9-c92fba330579">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-104f1502-7a1e-4686-a6e9-c92fba330579">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-104f1502-7a1e-4686-a6e9-c92fba330579">
											<gml:posList>35.670129401527085 139.7481518684549 58.2 35.670129401527085 139.7481518684549 57.356 35.670120379604484 139.7481402905504 57.356 35.670120379604484 139.7481402905504 58.2 35.670129401527085 139.7481518684549 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6784c6e7-2365-4aed-9f73-68c8129d7632">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6784c6e7-2365-4aed-9f73-68c8129d7632">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6784c6e7-2365-4aed-9f73-68c8129d7632">
											<gml:posList>35.670120379604484 139.7481402905504 58.2 35.670120379604484 139.7481402905504 57.356 35.67010578939646 139.74815730618937 57.356 35.67010578939646 139.74815730618937 58.2 35.670120379604484 139.7481402905504 58.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a4eeff25-5eaf-4b37-8de3-0fd04ed415ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a4eeff25-5eaf-4b37-8de3-0fd04ed415ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a4eeff25-5eaf-4b37-8de3-0fd04ed415ac">
											<gml:posList>35.670120223304544 139.74814869689322 6.23 35.67012924523414 139.74816028584485 6.23 35.67012924523414 139.74816028584485 58.2 35.670120223304544 139.74814869689322 58.2 35.670120223304544 139.74814869689322 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-db1d5472-966d-4f7f-b55c-1cf1d6f2eb64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db1d5472-966d-4f7f-b55c-1cf1d6f2eb64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db1d5472-966d-4f7f-b55c-1cf1d6f2eb64">
											<gml:posList>35.67010563310315 139.74816572357685 6.23 35.670120223304544 139.74814869689322 6.23 35.670120223304544 139.74814869689322 58.2 35.67010563310315 139.74816572357685 58.2 35.67010563310315 139.74816572357685 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3567987e-a141-4255-91cc-fc9f30d2bf72">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3567987e-a141-4255-91cc-fc9f30d2bf72">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3567987e-a141-4255-91cc-fc9f30d2bf72">
											<gml:posList>35.67006864523876 139.74786674176528 6.23 35.67007694547037 139.74787744774943 6.23 35.67007694547037 139.74787744774943 58.2 35.67006864523876 139.74786674176528 58.2 35.67006864523876 139.74786674176528 6.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都千代田区霞が関三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4041</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1537.1562</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.07</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>