<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_613975c3-eb66-4358-84e6-f8a967f89cca">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:measuredHeight uom="m">5.2</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669998463817116 139.74703194421014 0 35.67001768054497 139.74705633565034 0 35.670066985778085 139.74705650351922 0 35.670067342211304 139.74705075910285 0 35.670047404305286 139.74702625796303 0 35.66999927038121 139.74702542607946 0 35.669998463817116 139.74703194421014 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669998463817116 139.74703194421014 5.71 35.66999927038121 139.74702542607946 5.71 35.670047404305286 139.74702625796303 5.71 35.670067342211304 139.74705075910285 5.71 35.670066985778085 139.74705650351922 5.71 35.67001768054497 139.74705633565034 5.71 35.669998463817116 139.74703194421014 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669998463817116 139.74703194421014 5.71 35.67001768054497 139.74705633565034 5.71 35.67001768054497 139.74705633565034 10.89 35.669998463817116 139.74703194421014 10.89 35.669998463817116 139.74703194421014 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67001768054497 139.74705633565034 5.71 35.670066985778085 139.74705650351922 5.71 35.670066985778085 139.74705650351922 10.89 35.67001768054497 139.74705633565034 10.89 35.67001768054497 139.74705633565034 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670066985778085 139.74705650351922 5.71 35.670067342211304 139.74705075910285 5.71 35.670067342211304 139.74705075910285 10.89 35.670066985778085 139.74705650351922 10.89 35.670066985778085 139.74705650351922 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670067342211304 139.74705075910285 5.71 35.670047404305286 139.74702625796303 5.71 35.670047404305286 139.74702625796303 10.89 35.670067342211304 139.74705075910285 10.89 35.670067342211304 139.74705075910285 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670047404305286 139.74702625796303 5.71 35.66999927038121 139.74702542607946 5.71 35.66999927038121 139.74702542607946 10.89 35.670047404305286 139.74702625796303 10.89 35.670047404305286 139.74702625796303 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66999927038121 139.74702542607946 5.71 35.669998463817116 139.74703194421014 5.71 35.669998463817116 139.74703194421014 10.89 35.66999927038121 139.74702542607946 10.89 35.66999927038121 139.74702542607946 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669998463817116 139.74703194421014 10.89 35.67001768054497 139.74705633565034 10.89 35.670066985778085 139.74705650351922 10.89 35.670067342211304 139.74705075910285 10.89 35.670047404305286 139.74702625796303 10.89 35.66999927038121 139.74702542607946 10.89 35.669998463817116 139.74703194421014 10.89</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8224e1b4-0147-4984-881b-d8d97308c1c1"/>
							<gml:surfaceMember xlink:href="#poly-6856d061-2c3b-4587-a0dd-4f1566642ba7"/>
							<gml:surfaceMember xlink:href="#poly-6e49b71b-2ce1-4a3c-a177-f7b619013458"/>
							<gml:surfaceMember xlink:href="#poly-92cedb85-5346-4191-80ce-6e76ac129025"/>
							<gml:surfaceMember xlink:href="#poly-caf686e1-7490-454a-b0b3-58693ab72363"/>
							<gml:surfaceMember xlink:href="#poly-f518c9c7-65db-4315-9262-056c1dd75c4b"/>
							<gml:surfaceMember xlink:href="#poly-b4236a55-fe78-48d5-8220-2a05bc5803ff"/>
							<gml:surfaceMember xlink:href="#poly-9c5bf4e2-3d83-4a3d-8fa4-4d09b7eaa8de"/>
							<gml:surfaceMember xlink:href="#poly-7445a8eb-6689-4cea-b467-0647025b1f0f"/>
							<gml:surfaceMember xlink:href="#poly-8fab097c-2137-487e-810b-90eefe455954"/>
							<gml:surfaceMember xlink:href="#poly-35b38b63-050a-4937-a0d6-ae5bc10bb6a8"/>
							<gml:surfaceMember xlink:href="#poly-5e22fc47-ea5f-4041-ab44-479464a3b22e"/>
							<gml:surfaceMember xlink:href="#poly-a6da7c8d-fee1-4c97-89b8-900ec7908593"/>
							<gml:surfaceMember xlink:href="#poly-9d9b3618-5308-4630-ae4c-5cc133ae6f56"/>
							<gml:surfaceMember xlink:href="#poly-19773438-3dcd-46ae-bbe5-6d030494d83c"/>
							<gml:surfaceMember xlink:href="#poly-8f366c95-7591-4251-b565-d3b88a4638cc"/>
							<gml:surfaceMember xlink:href="#poly-0c926f6d-5df5-45ff-b450-da7faa058cf5"/>
							<gml:surfaceMember xlink:href="#poly-61d9a8eb-e380-4a31-98c7-346baabdf235"/>
							<gml:surfaceMember xlink:href="#poly-6de4e1a9-4a2f-422b-9cb6-786da1abc0de"/>
							<gml:surfaceMember xlink:href="#poly-f310cd55-2823-4fb9-8ed6-2fa631fb4dc0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8224e1b4-0147-4984-881b-d8d97308c1c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8224e1b4-0147-4984-881b-d8d97308c1c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8224e1b4-0147-4984-881b-d8d97308c1c1">
											<gml:posList>35.66999846381709 139.74703194421014 5.71 35.66999927038118 139.74702542607946 5.71 35.67004740430528 139.74702625796303 5.71 35.67006734221129 139.74705075910285 5.71 35.67006698577806 139.74705650351922 5.71 35.67001768054494 139.74705633565034 5.71 35.66999846381709 139.74703194421014 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6856d061-2c3b-4587-a0dd-4f1566642ba7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6856d061-2c3b-4587-a0dd-4f1566642ba7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6856d061-2c3b-4587-a0dd-4f1566642ba7">
											<gml:posList>35.66999846381709 139.74703194421014 13.1 35.67000007683049 139.74703132388632 13.1 35.67000057872517 139.74702731357266 13.1 35.66999927038118 139.74702542607946 13.1 35.66999846381709 139.74703194421014 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e49b71b-2ce1-4a3c-a177-f7b619013458">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e49b71b-2ce1-4a3c-a177-f7b619013458">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e49b71b-2ce1-4a3c-a177-f7b619013458">
											<gml:posList>35.67001768054494 139.74705633565034 13.1 35.67001832820345 139.7470544791901 13.1 35.67000007683049 139.74703132388632 13.1 35.66999846381709 139.74703194421014 13.1 35.67001768054494 139.74705633565034 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-92cedb85-5346-4191-80ce-6e76ac129025">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-92cedb85-5346-4191-80ce-6e76ac129025">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-92cedb85-5346-4191-80ce-6e76ac129025">
											<gml:posList>35.67004740430528 139.74702625796303 13.1 35.66999927038118 139.74702542607946 13.1 35.67000057872517 139.74702731357266 13.1 35.67004676566094 139.7470281144145 13.1 35.67004740430528 139.74702625796303 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-caf686e1-7490-454a-b0b3-58693ab72363">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-caf686e1-7490-454a-b0b3-58693ab72363">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-caf686e1-7490-454a-b0b3-58693ab72363">
											<gml:posList>35.6700655782994 139.74705463822312 12.91 35.67006576531602 139.74705146775767 12.91 35.67004676566094 139.7470281144145 12.91 35.67000057872517 139.74702731357266 12.91 35.67000007683049 139.74703132388632 12.91 35.67001832820345 139.7470544791901 12.91 35.6700655782994 139.74705463822312 12.91</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f518c9c7-65db-4315-9262-056c1dd75c4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f518c9c7-65db-4315-9262-056c1dd75c4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f518c9c7-65db-4315-9262-056c1dd75c4b">
											<gml:posList>35.67001768054494 139.74705633565034 13.1 35.67006698577806 139.74705650351922 13.1 35.6700655782994 139.74705463822312 13.1 35.67001832820345 139.7470544791901 13.1 35.67001768054494 139.74705633565034 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b4236a55-fe78-48d5-8220-2a05bc5803ff">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b4236a55-fe78-48d5-8220-2a05bc5803ff">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b4236a55-fe78-48d5-8220-2a05bc5803ff">
											<gml:posList>35.67004740430528 139.74702625796303 13.1 35.67004676566094 139.7470281144145 13.1 35.67006576531602 139.74705146775767 13.1 35.67006734221129 139.74705075910285 13.1 35.67004740430528 139.74702625796303 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9c5bf4e2-3d83-4a3d-8fa4-4d09b7eaa8de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9c5bf4e2-3d83-4a3d-8fa4-4d09b7eaa8de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9c5bf4e2-3d83-4a3d-8fa4-4d09b7eaa8de">
											<gml:posList>35.67006734221129 139.74705075910285 13.1 35.67006576531602 139.74705146775767 13.1 35.6700655782994 139.74705463822312 13.1 35.67006698577806 139.74705650351922 13.1 35.67006734221129 139.74705075910285 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7445a8eb-6689-4cea-b467-0647025b1f0f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7445a8eb-6689-4cea-b467-0647025b1f0f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7445a8eb-6689-4cea-b467-0647025b1f0f">
											<gml:posList>35.67004740430528 139.74702625796303 5.71 35.66999927038118 139.74702542607946 5.71 35.66999927038118 139.74702542607946 13.1 35.67004740430528 139.74702625796303 13.1 35.67004740430528 139.74702625796303 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fab097c-2137-487e-810b-90eefe455954">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fab097c-2137-487e-810b-90eefe455954">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fab097c-2137-487e-810b-90eefe455954">
											<gml:posList>35.67000057872517 139.74702731357266 13.1 35.67000057872517 139.74702731357266 12.91 35.67004676566094 139.7470281144145 12.91 35.67004676566094 139.7470281144145 13.1 35.67000057872517 139.74702731357266 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-35b38b63-050a-4937-a0d6-ae5bc10bb6a8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-35b38b63-050a-4937-a0d6-ae5bc10bb6a8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-35b38b63-050a-4937-a0d6-ae5bc10bb6a8">
											<gml:posList>35.66999927038118 139.74702542607946 5.71 35.66999846381709 139.74703194421014 5.71 35.66999846381709 139.74703194421014 13.1 35.66999927038118 139.74702542607946 13.1 35.66999927038118 139.74702542607946 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e22fc47-ea5f-4041-ab44-479464a3b22e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e22fc47-ea5f-4041-ab44-479464a3b22e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e22fc47-ea5f-4041-ab44-479464a3b22e">
											<gml:posList>35.67000007683049 139.74703132388632 13.1 35.67000007683049 139.74703132388632 12.91 35.67000057872517 139.74702731357266 12.91 35.67000057872517 139.74702731357266 13.1 35.67000007683049 139.74703132388632 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a6da7c8d-fee1-4c97-89b8-900ec7908593">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a6da7c8d-fee1-4c97-89b8-900ec7908593">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a6da7c8d-fee1-4c97-89b8-900ec7908593">
											<gml:posList>35.67006734221129 139.74705075910285 5.71 35.67004740430528 139.74702625796303 5.71 35.67004740430528 139.74702625796303 13.1 35.67006734221129 139.74705075910285 13.1 35.67006734221129 139.74705075910285 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d9b3618-5308-4630-ae4c-5cc133ae6f56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d9b3618-5308-4630-ae4c-5cc133ae6f56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d9b3618-5308-4630-ae4c-5cc133ae6f56">
											<gml:posList>35.67004676566094 139.7470281144145 13.1 35.67004676566094 139.7470281144145 12.91 35.67006576531602 139.74705146775767 12.91 35.67006576531602 139.74705146775767 13.1 35.67004676566094 139.7470281144145 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-19773438-3dcd-46ae-bbe5-6d030494d83c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19773438-3dcd-46ae-bbe5-6d030494d83c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19773438-3dcd-46ae-bbe5-6d030494d83c">
											<gml:posList>35.67001832820345 139.7470544791901 13.1 35.67001832820345 139.7470544791901 12.91 35.67000007683049 139.74703132388632 12.91 35.67000007683049 139.74703132388632 13.1 35.67001832820345 139.7470544791901 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f366c95-7591-4251-b565-d3b88a4638cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f366c95-7591-4251-b565-d3b88a4638cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f366c95-7591-4251-b565-d3b88a4638cc">
											<gml:posList>35.66999846381709 139.74703194421014 5.71 35.67001768054494 139.74705633565034 5.71 35.67001768054494 139.74705633565034 13.1 35.66999846381709 139.74703194421014 13.1 35.66999846381709 139.74703194421014 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c926f6d-5df5-45ff-b450-da7faa058cf5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c926f6d-5df5-45ff-b450-da7faa058cf5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c926f6d-5df5-45ff-b450-da7faa058cf5">
											<gml:posList>35.67006576531602 139.74705146775767 13.1 35.67006576531602 139.74705146775767 12.91 35.6700655782994 139.74705463822312 12.91 35.6700655782994 139.74705463822312 13.1 35.67006576531602 139.74705146775767 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-61d9a8eb-e380-4a31-98c7-346baabdf235">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-61d9a8eb-e380-4a31-98c7-346baabdf235">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-61d9a8eb-e380-4a31-98c7-346baabdf235">
											<gml:posList>35.67006698577806 139.74705650351922 5.71 35.67006734221129 139.74705075910285 5.71 35.67006734221129 139.74705075910285 13.1 35.67006698577806 139.74705650351922 13.1 35.67006698577806 139.74705650351922 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6de4e1a9-4a2f-422b-9cb6-786da1abc0de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6de4e1a9-4a2f-422b-9cb6-786da1abc0de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6de4e1a9-4a2f-422b-9cb6-786da1abc0de">
											<gml:posList>35.6700655782994 139.74705463822312 13.1 35.6700655782994 139.74705463822312 12.91 35.67001832820345 139.7470544791901 12.91 35.67001832820345 139.7470544791901 13.1 35.6700655782994 139.74705463822312 13.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f310cd55-2823-4fb9-8ed6-2fa631fb4dc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f310cd55-2823-4fb9-8ed6-2fa631fb4dc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f310cd55-2823-4fb9-8ed6-2fa631fb4dc0">
											<gml:posList>35.67001768054494 139.74705633565034 5.71 35.67006698577806 139.74705650351922 5.71 35.67006698577806 139.74705650351922 13.1 35.67001768054494 139.74705633565034 13.1 35.67001768054494 139.74705633565034 5.71</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-2613</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>