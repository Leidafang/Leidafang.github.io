<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_61dca10f-e365-49e1-8448-4884135b2fd7">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67013629299949 139.74733460606225 0 35.67013243071129 139.74727796515813 0 35.670113953917586 139.74727986284725 0 35.67011781619695 139.7473364926922 0 35.67013629299949 139.74733460606225 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013629299949 139.74733460606225 8.364 35.67011781619695 139.7473364926922 8.364 35.670113953917586 139.74727986284725 8.364 35.67013243071129 139.74727796515813 8.364 35.67013629299949 139.74733460606225 8.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013629299949 139.74733460606225 8.364 35.67013243071129 139.74727796515813 8.364 35.67013243071129 139.74727796515813 11.364 35.67013629299949 139.74733460606225 11.364 35.67013629299949 139.74733460606225 8.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013243071129 139.74727796515813 8.364 35.670113953917586 139.74727986284725 8.364 35.670113953917586 139.74727986284725 11.364 35.67013243071129 139.74727796515813 11.364 35.67013243071129 139.74727796515813 8.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670113953917586 139.74727986284725 8.364 35.67011781619695 139.7473364926922 8.364 35.67011781619695 139.7473364926922 11.364 35.670113953917586 139.74727986284725 11.364 35.670113953917586 139.74727986284725 8.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67011781619695 139.7473364926922 8.364 35.67013629299949 139.74733460606225 8.364 35.67013629299949 139.74733460606225 11.364 35.67011781619695 139.7473364926922 11.364 35.67011781619695 139.7473364926922 8.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67013629299949 139.74733460606225 11.364 35.67013243071129 139.74727796515813 11.364 35.670113953917586 139.74727986284725 11.364 35.67011781619695 139.7473364926922 11.364 35.67013629299949 139.74733460606225 11.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-03179f1c-13d7-4865-81c7-12c0fe81521d"/>
							<gml:surfaceMember xlink:href="#poly-d59dd761-4160-4b62-af80-5eae9c37b493"/>
							<gml:surfaceMember xlink:href="#poly-8fea1a53-be4e-450c-b9a9-968632f4e2d2"/>
							<gml:surfaceMember xlink:href="#poly-003d9b86-8856-481e-8864-29d0f3df1cda"/>
							<gml:surfaceMember xlink:href="#poly-8dde8733-d4c6-4994-8d8f-688ef184bb2f"/>
							<gml:surfaceMember xlink:href="#poly-7b594a28-4380-464f-840b-528fac8b252e"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-03179f1c-13d7-4865-81c7-12c0fe81521d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03179f1c-13d7-4865-81c7-12c0fe81521d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03179f1c-13d7-4865-81c7-12c0fe81521d">
											<gml:posList>35.67013629299949 139.74733460606225 8.364 35.67011781619696 139.7473364926922 8.364 35.67011395391756 139.74727986284725 8.364 35.6701324307113 139.74727796515813 8.364 35.67013629299949 139.74733460606225 8.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d59dd761-4160-4b62-af80-5eae9c37b493">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d59dd761-4160-4b62-af80-5eae9c37b493">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d59dd761-4160-4b62-af80-5eae9c37b493">
											<gml:posList>35.67011781619696 139.7473364926922 11.585 35.67013629299949 139.74733460606225 11.585 35.6701324307113 139.74727796515813 11.585 35.67011395391756 139.74727986284725 11.585 35.67011781619696 139.7473364926922 11.585</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8fea1a53-be4e-450c-b9a9-968632f4e2d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8fea1a53-be4e-450c-b9a9-968632f4e2d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8fea1a53-be4e-450c-b9a9-968632f4e2d2">
											<gml:posList>35.6701324307113 139.74727796515813 8.364 35.67011395391756 139.74727986284725 8.364 35.67011395391756 139.74727986284725 11.585 35.6701324307113 139.74727796515813 11.585 35.6701324307113 139.74727796515813 8.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-003d9b86-8856-481e-8864-29d0f3df1cda">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-003d9b86-8856-481e-8864-29d0f3df1cda">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-003d9b86-8856-481e-8864-29d0f3df1cda">
											<gml:posList>35.67013629299949 139.74733460606225 8.364 35.6701324307113 139.74727796515813 8.364 35.6701324307113 139.74727796515813 11.585 35.67013629299949 139.74733460606225 11.585 35.67013629299949 139.74733460606225 8.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8dde8733-d4c6-4994-8d8f-688ef184bb2f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8dde8733-d4c6-4994-8d8f-688ef184bb2f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8dde8733-d4c6-4994-8d8f-688ef184bb2f">
											<gml:posList>35.67011395391756 139.74727986284725 8.364 35.67011781619696 139.7473364926922 8.364 35.67011781619696 139.7473364926922 11.585 35.67011395391756 139.74727986284725 11.585 35.67011395391756 139.74727986284725 8.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b594a28-4380-464f-840b-528fac8b252e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b594a28-4380-464f-840b-528fac8b252e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b594a28-4380-464f-840b-528fac8b252e">
											<gml:posList>35.67011781619696 139.7473364926922 8.364 35.67013629299949 139.74733460606225 8.364 35.67013629299949 139.74733460606225 11.585 35.67011781619696 139.7473364926922 11.585 35.67011781619696 139.7473364926922 8.364</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-2283</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>