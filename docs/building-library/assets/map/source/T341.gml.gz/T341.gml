<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6245198e-6269-4802-831d-672633678ead">
			<core:creationDate>2023-08-22</core:creationDate>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>虎ノ門一・二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:measuredHeight uom="m">32.4</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.666969468373544 139.74783375083595 0 35.666957440934034 139.74787126521713 0 35.666932663111886 139.74794882751414 0 35.666943733934815 139.74795412654012 0 35.66695674877855 139.74796035576236 0 35.666915749783854 139.74808884198532 0 35.667283948662586 139.7482652634324 0 35.667465559953904 139.74811715346215 0 35.667441411490955 139.74802073997174 0 35.66734840953503 139.7479761761595 0 35.66735700576528 139.74794923724207 0 35.667308729819936 139.74792610674896 0 35.66729574103464 139.7479667957671 0 35.66726921837004 139.74797986913015 0 35.66720522221675 139.7479474768903 0 35.667212656449344 139.74792417995914 0 35.667139969312565 139.74788935481752 0 35.66713305577406 139.7479109490163 0 35.66712618033084 139.74790746807327 0 35.667129572770044 139.74789683728312 0 35.66706802408214 139.7478673509172 0 35.66706506688391 139.7478765353409 0 35.66699491120843 139.74784103160485 0 35.66699352339889 139.74784527135546 0 35.666969468373544 139.74783375083595 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666969468373544 139.74783375083595 5.34 35.66699352339889 139.74784527135546 5.34 35.66699491120843 139.74784103160485 5.34 35.66706506688391 139.7478765353409 5.34 35.66706802408214 139.7478673509172 5.34 35.667129572770044 139.74789683728312 5.34 35.66712618033084 139.74790746807327 5.34 35.66713305577406 139.7479109490163 5.34 35.667139969312565 139.74788935481752 5.34 35.667212656449344 139.74792417995914 5.34 35.66720522221675 139.7479474768903 5.34 35.66726921837004 139.74797986913015 5.34 35.66729574103464 139.7479667957671 5.34 35.667308729819936 139.74792610674896 5.34 35.66735700576528 139.74794923724207 5.34 35.66734840953503 139.7479761761595 5.34 35.667441411490955 139.74802073997174 5.34 35.667465559953904 139.74811715346215 5.34 35.667283948662586 139.7482652634324 5.34 35.666915749783854 139.74808884198532 5.34 35.66695674877855 139.74796035576236 5.34 35.666943733934815 139.74795412654012 5.34 35.666932663111886 139.74794882751414 5.34 35.666957440934034 139.74787126521713 5.34 35.666969468373544 139.74783375083595 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666969468373544 139.74783375083595 5.34 35.666957440934034 139.74787126521713 5.34 35.666957440934034 139.74787126521713 35.483999999999995 35.666969468373544 139.74783375083595 35.483999999999995 35.666969468373544 139.74783375083595 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666957440934034 139.74787126521713 5.34 35.666932663111886 139.74794882751414 5.34 35.666932663111886 139.74794882751414 35.483999999999995 35.666957440934034 139.74787126521713 35.483999999999995 35.666957440934034 139.74787126521713 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666932663111886 139.74794882751414 5.34 35.666943733934815 139.74795412654012 5.34 35.666943733934815 139.74795412654012 35.483999999999995 35.666932663111886 139.74794882751414 35.483999999999995 35.666932663111886 139.74794882751414 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666943733934815 139.74795412654012 5.34 35.66695674877855 139.74796035576236 5.34 35.66695674877855 139.74796035576236 35.483999999999995 35.666943733934815 139.74795412654012 35.483999999999995 35.666943733934815 139.74795412654012 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66695674877855 139.74796035576236 5.34 35.666915749783854 139.74808884198532 5.34 35.666915749783854 139.74808884198532 35.483999999999995 35.66695674877855 139.74796035576236 35.483999999999995 35.66695674877855 139.74796035576236 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666915749783854 139.74808884198532 5.34 35.667283948662586 139.7482652634324 5.34 35.667283948662586 139.7482652634324 35.483999999999995 35.666915749783854 139.74808884198532 35.483999999999995 35.666915749783854 139.74808884198532 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667283948662586 139.7482652634324 5.34 35.667465559953904 139.74811715346215 5.34 35.667465559953904 139.74811715346215 35.483999999999995 35.667283948662586 139.7482652634324 35.483999999999995 35.667283948662586 139.7482652634324 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667465559953904 139.74811715346215 5.34 35.667441411490955 139.74802073997174 5.34 35.667441411490955 139.74802073997174 35.483999999999995 35.667465559953904 139.74811715346215 35.483999999999995 35.667465559953904 139.74811715346215 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667441411490955 139.74802073997174 5.34 35.66734840953503 139.7479761761595 5.34 35.66734840953503 139.7479761761595 35.483999999999995 35.667441411490955 139.74802073997174 35.483999999999995 35.667441411490955 139.74802073997174 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66734840953503 139.7479761761595 5.34 35.66735700576528 139.74794923724207 5.34 35.66735700576528 139.74794923724207 35.483999999999995 35.66734840953503 139.7479761761595 35.483999999999995 35.66734840953503 139.7479761761595 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66735700576528 139.74794923724207 5.34 35.667308729819936 139.74792610674896 5.34 35.667308729819936 139.74792610674896 35.483999999999995 35.66735700576528 139.74794923724207 35.483999999999995 35.66735700576528 139.74794923724207 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667308729819936 139.74792610674896 5.34 35.66729574103464 139.7479667957671 5.34 35.66729574103464 139.7479667957671 35.483999999999995 35.667308729819936 139.74792610674896 35.483999999999995 35.667308729819936 139.74792610674896 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66729574103464 139.7479667957671 5.34 35.66726921837004 139.74797986913015 5.34 35.66726921837004 139.74797986913015 35.483999999999995 35.66729574103464 139.7479667957671 35.483999999999995 35.66729574103464 139.7479667957671 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66726921837004 139.74797986913015 5.34 35.66720522221675 139.7479474768903 5.34 35.66720522221675 139.7479474768903 35.483999999999995 35.66726921837004 139.74797986913015 35.483999999999995 35.66726921837004 139.74797986913015 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66720522221675 139.7479474768903 5.34 35.667212656449344 139.74792417995914 5.34 35.667212656449344 139.74792417995914 35.483999999999995 35.66720522221675 139.7479474768903 35.483999999999995 35.66720522221675 139.7479474768903 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667212656449344 139.74792417995914 5.34 35.667139969312565 139.74788935481752 5.34 35.667139969312565 139.74788935481752 35.483999999999995 35.667212656449344 139.74792417995914 35.483999999999995 35.667212656449344 139.74792417995914 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667139969312565 139.74788935481752 5.34 35.66713305577406 139.7479109490163 5.34 35.66713305577406 139.7479109490163 35.483999999999995 35.667139969312565 139.74788935481752 35.483999999999995 35.667139969312565 139.74788935481752 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713305577406 139.7479109490163 5.34 35.66712618033084 139.74790746807327 5.34 35.66712618033084 139.74790746807327 35.483999999999995 35.66713305577406 139.7479109490163 35.483999999999995 35.66713305577406 139.7479109490163 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66712618033084 139.74790746807327 5.34 35.667129572770044 139.74789683728312 5.34 35.667129572770044 139.74789683728312 35.483999999999995 35.66712618033084 139.74790746807327 35.483999999999995 35.66712618033084 139.74790746807327 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667129572770044 139.74789683728312 5.34 35.66706802408214 139.7478673509172 5.34 35.66706802408214 139.7478673509172 35.483999999999995 35.667129572770044 139.74789683728312 35.483999999999995 35.667129572770044 139.74789683728312 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66706802408214 139.7478673509172 5.34 35.66706506688391 139.7478765353409 5.34 35.66706506688391 139.7478765353409 35.483999999999995 35.66706802408214 139.7478673509172 35.483999999999995 35.66706802408214 139.7478673509172 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66706506688391 139.7478765353409 5.34 35.66699491120843 139.74784103160485 5.34 35.66699491120843 139.74784103160485 35.483999999999995 35.66706506688391 139.7478765353409 35.483999999999995 35.66706506688391 139.7478765353409 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66699491120843 139.74784103160485 5.34 35.66699352339889 139.74784527135546 5.34 35.66699352339889 139.74784527135546 35.483999999999995 35.66699491120843 139.74784103160485 35.483999999999995 35.66699491120843 139.74784103160485 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66699352339889 139.74784527135546 5.34 35.666969468373544 139.74783375083595 5.34 35.666969468373544 139.74783375083595 35.483999999999995 35.66699352339889 139.74784527135546 35.483999999999995 35.66699352339889 139.74784527135546 5.34</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666969468373544 139.74783375083595 35.483999999999995 35.666957440934034 139.74787126521713 35.483999999999995 35.666932663111886 139.74794882751414 35.483999999999995 35.666943733934815 139.74795412654012 35.483999999999995 35.66695674877855 139.74796035576236 35.483999999999995 35.666915749783854 139.74808884198532 35.483999999999995 35.667283948662586 139.7482652634324 35.483999999999995 35.667465559953904 139.74811715346215 35.483999999999995 35.667441411490955 139.74802073997174 35.483999999999995 35.66734840953503 139.7479761761595 35.483999999999995 35.66735700576528 139.74794923724207 35.483999999999995 35.667308729819936 139.74792610674896 35.483999999999995 35.66729574103464 139.7479667957671 35.483999999999995 35.66726921837004 139.74797986913015 35.483999999999995 35.66720522221675 139.7479474768903 35.483999999999995 35.667212656449344 139.74792417995914 35.483999999999995 35.667139969312565 139.74788935481752 35.483999999999995 35.66713305577406 139.7479109490163 35.483999999999995 35.66712618033084 139.74790746807327 35.483999999999995 35.667129572770044 139.74789683728312 35.483999999999995 35.66706802408214 139.7478673509172 35.483999999999995 35.66706506688391 139.7478765353409 35.483999999999995 35.66699491120843 139.74784103160485 35.483999999999995 35.66699352339889 139.74784527135546 35.483999999999995 35.666969468373544 139.74783375083595 35.483999999999995</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p828_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p828_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p828_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p40_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p40_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p40_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p40_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p33_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p33_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p33_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p33_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p33_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p32_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p32_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p32_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p32_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p32_4"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p827_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p827_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p827_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p634_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p634_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p634_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p634_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_b_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p43_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p43_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p43_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p43_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p42_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p42_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p42_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p42_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p58_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p58_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p34_0"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p34_1"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p34_2"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p34_3"/>
							<gml:surfaceMember xlink:href="#poly_TMmnt0005_p38_0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gml_af9a9c1e-46af-493c-a2b6-89834e52e166">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5dd33004-482c-4b85-a8e5-f6a354369085">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ee18be1d-e925-4395-a3ee-b2455e2c4e74">
											<gml:posList>35.666962244035105 139.74809930247784 6.049024998509424 35.66696639678343 139.74808639878037 6.049024998509424 35.66695724291785 139.74808197475755 6.049024998509424 35.66694693456128 139.74807699289835 6.049024998509424 35.666940112520685 139.74807369582052 6.049024998509424 35.66693306820659 139.7480852021455 6.049024998509424 35.66691907038414 139.74807843712432 6.049024998509424 35.66700865293279 139.74779769176794 6.049024998509424 35.667091383447506 139.7478376740657 6.049024998509424 35.66708755102188 139.74784958252985 6.049024998509424 35.66709469228057 139.74785303381066 6.049024998509424 35.66710183352196 139.74785648509211 6.049024998509424 35.66710566594826 139.7478445766262 6.049024998509424 35.66711141288572 139.74784735403125 6.049024998509424 35.667107432553045 139.74785972211106 6.049024998509424 35.667116383599 139.74786404790225 6.049024998509424 35.66713461097799 139.7478728568996 6.049024998509424 35.66714655280541 139.74787862832568 6.049024998509424 35.66716164614876 139.7478859225773 6.049024998509424 35.667171196913415 139.74789053830827 6.049024998509424 35.667175177257796 139.74787817022013 6.049024998509424 35.66741770556413 139.74799538079301 6.049024998509424 35.66731842134189 139.74815755366072 6.049024998509424 35.66731479006079 139.74815563120444 6.049024998509424 35.667308262813144 139.74817414669047 6.049024998509424 35.66726461817862 139.74824543642663 6.049024998509424 35.66717355491945 139.74820142647013 6.049024998509424 35.667186236367826 139.74816673436297 6.049024998509424 35.66720012511882 139.74817408607748 6.049024998509424 35.667245545693696 139.748049831094 6.049024998509424 35.66715824726571 139.748003619527 6.049024998509424 35.667099094637734 139.74816544062796 6.049024998509424 35.666992430390714 139.7481138910339 6.049024998509424 35.666996201196405 139.74810217412963 6.049024998509424 35.66698703215382 139.74809774287206 6.049024998509424 35.66697672373671 139.74809276100905 6.049024998509424 35.666967020923536 139.74808807177246 6.049024998509424 35.66696325012457 139.74809978867313 6.049024998509424 35.666962244035105 139.74809930247784 6.049024998509424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="gnd_TMmnt0005_b_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_b_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_b_0">
											<gml:posList>35.6669158567422 139.74808886987776 5.40587027 35.66695685210045 139.7479603937019 5.40668899 35.66693276897935 139.747948853637 5.4055812 35.66696949496681 139.74783375684578 5.4063354 35.666993578092544 139.74784529690132 5.40744319 35.666994937035646 139.7478410380561 5.40747148 35.66706511169402 139.74787655774253 5.4107201 35.667068047865136 139.74786735595956 5.41078129 35.6671295729753 139.7478968372893 5.41362695 35.66712618067729 139.74790746854498 5.41355627 35.66713309597125 139.74791096880767 5.41387797 35.66713999107754 139.74788935996034 5.41402179 35.66721265647589 139.74792417950403 5.41739473 35.66720522264817 139.74794747666823 5.41723969 35.667269263714026 139.74797989195127 5.42023443 35.66729574443862 139.74796681881622 5.42128605 35.667308734919466 139.74792610740386 5.42155877 35.66735700555229 139.74794923761885 5.42381492 35.66734840988802 139.74797617593524 5.42363419 35.66744141154245 139.74802074037848 5.42799569 35.66746555986244 139.7481171533708 5.42974859 35.667284002652146 139.74826527796753 5.42296541 35.6669158567422 139.74808886987776 5.40587027</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_e5ee6466-791c-4527-8674-cf7a3951119a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_36ecbe7e-f54d-4f05-b4e3-597e57584cee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1df7291e-bcfa-4531-8a55-8dc591873024">
											<gml:posList>35.66698318469728 139.74787750765907 21.176886021458643 35.66699737018868 139.74783305132198 21.176886021458643 35.66724867065396 139.74795450086583 21.176886021458643 35.66717102653268 139.74817539169234 21.176886021458643 35.667042738757786 139.74810753581943 21.176886021458643 35.66710320592359 139.74793551216348 21.176886021458643 35.66698318469728 139.74787750765907 21.176886021458643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_57be4a8f-b372-41b4-8ed0-9f8c0a94337a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ed8b7871-51ab-47e2-804a-2263400cd164">
									<gml:exterior>
										<gml:LinearRing gml:id="line_22f4d9e5-913a-4d40-85d2-4f54de5987b7">
											<gml:posList>35.66720012511882 139.74817408607748 11.276731907689111 35.667186236367826 139.74816673436297 11.276731907689111 35.667173555022366 139.74820142613294 11.276731907689111 35.66709909474066 139.74816544029073 11.276731907689111 35.66715824726571 139.748003619527 11.276731907689111 35.667245545693696 139.748049831094 11.276731907689111 35.66720012511882 139.74817408607748 11.276731907689111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_0b5d5af8-3ac5-40dc-afa6-1f4ae488111c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_16eb7a9a-de15-466a-ac54-b1bbb1fb86e6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_004e26b9-bbf2-49bd-8ff0-6540fdb7e4eb">
											<gml:posList>35.66696325021243 139.74809978833594 11.276731907689111 35.66696702101571 139.74808807143526 11.27672427829458 35.66699620128816 139.74810217396097 11.27672427829458 35.66699243048246 139.74811389086526 11.276731907689111 35.66696325021243 139.74809978833594 11.276731907689111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_87a3639b-a216-47a9-b813-3e7f500207e9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9cf4e99f-2d76-4957-9e1b-1156ffae15cf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_25a42ab8-9588-4e3d-af1d-104541246f48">
											<gml:posList>35.66732987851348 139.7481636189275 11.276884495579736 35.6673197175112 139.74818021617514 11.276884495579736 35.667308261852284 139.74817414938826 11.276884495579736 35.66731479006079 139.74815563120444 11.276884495579736 35.66732987851348 139.7481636189275 11.276884495579736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_2f3da43e-7bd6-453b-97b6-bafce7f210f3">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9ccda471-7dd9-4d01-ac71-59a4a3e8740c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_269e1a21-c08f-491f-bb3b-52be48a31cc3">
											<gml:posList>35.66710211362066 139.74785561476085 10.776884495579736 35.66710183352196 139.74785648509211 10.776884495579736 35.66709469228057 139.74785303381066 10.776884495579736 35.66708755102188 139.74784958252985 10.776884495579736 35.66708783112051 139.74784871219867 10.776884495579736 35.66710211362066 139.74785561476085 10.776884495579736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_f4a06c81-3611-4204-ae9e-8ffe366f1670">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_7cca25ca-ec0e-44f8-af97-c56e771820e5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5fd27ed5-13f6-4786-bb10-42e41f1339a7">
											<gml:posList>35.66694011258074 139.74807369565193 11.27672427829458 35.6669663968756 139.74808639844318 11.27672427829458 35.66696224412727 139.74809930214064 11.276731907689111 35.66693306829661 139.7480852018083 11.276731907689111 35.66694011258074 139.74807369565193 11.27672427829458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterCeilingSurface gml:id="gml_ecb7c5de-b37a-42e3-92f5-14ca5bbe652a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c5411603-9c14-41dc-afed-9abc87efd32c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_335b2427-805b-4eac-88cc-e6fafa8cb44e">
											<gml:posList>35.667171196913415 139.74789053830827 10.776884495579736 35.66716164614876 139.7478859225773 10.776884495579736 35.66714655280541 139.74787862832568 10.776884495579736 35.66713461097799 139.7478728568996 10.776884495579736 35.667116383599 139.74786404790225 10.776884495579736 35.667107432553045 139.74785972211106 10.776884495579736 35.667107860557856 139.7478583921666 10.776884495579736 35.667171624918566 139.74788920836286 10.776884495579736 35.667171196913415 139.74789053830827 10.776884495579736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterCeilingSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0005_p634_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p634_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p634_0">
											<gml:posList>35.66694370727745 139.74795411921608 36.08631003 35.66696845792099 139.74787655089 36.08681615 35.66695741396153 139.74787125890458 36.0863083 35.66693266290511 139.74794882701363 36.08580217 35.66694370727745 139.74795411921608 36.08631003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0005_p828_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p828_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p828_0">
											<gml:posList>35.66699488420162 139.74784102509022 20.64570304 35.66698082472115 139.74788490369866 36.25740222 35.667139945783475 139.74796115068273 36.2647541 35.66734878510733 139.74806122195878 36.27448886 35.667465450615005 139.7481171257864 36.27996943 35.66744139500411 139.7480207362688 10.10321864 35.66731204993313 139.74795875685243 10.09715798 35.66726920220491 139.74797987666074 22.94244763 35.66699488420162 139.74784102509022 20.64570304</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0005_p33_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p33_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p33_1">
											<gml:posList>35.66731256929872 139.74816864760788 37.84370674 35.66734877957642 139.7480612205688 37.84448874 35.66713994030414 139.74796114931735 37.83475398 35.667105353773685 139.74806375912885 37.83400748 35.66731256929872 139.74816864760788 37.84370674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_7ac58d72-a8d7-4336-b264-3b6acc4b713b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f169dfba-a627-4f0c-8d22-f28520253a40">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d5fa08ac-6459-45bd-9430-40731f9a3bd4">
											<gml:posList>35.66726197874285 139.74823371061692 32.87688296970083 35.66729216208212 139.74814808381464 32.87688296970083 35.66724443813765 139.748122821101 32.87688296970083 35.66721359289762 139.7482103258286 32.87688296970083 35.66726197874285 139.74823371061692 32.87688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_9b217a4e-a64f-4ef6-9872-e57181a6c4c9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_75e76511-3b23-42ac-a754-bf8ba9e23efe">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b947c86e-f6c1-47bc-bd9b-aae60054ff0b">
											<gml:posList>35.66706215546485 139.74810523880612 31.476881443821924 35.667159212707936 139.74815661593442 31.476881443821924 35.66717929830707 139.74809963537993 31.476881443821924 35.66708224103996 139.7480482581393 31.476881443821924 35.66706215546485 139.74810523880612 31.476881443821924</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0005_p32_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p32_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p32_1">
											<gml:posList>35.66735179262312 139.74820985447536 36.27571227 35.667168790751894 139.7481172249508 36.2671226 35.66715324236396 139.74816335440738 36.26679344 35.66731094641348 139.74824317906993 36.27419115 35.66735179262312 139.74820985447536 36.27571227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0005_p40_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p40_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p40_0">
											<gml:posList>35.667308724650304 139.7479261048801 8.34178187 35.66729573417539 139.74796681627402 8.34150915 35.66731205610563 139.74795875837813 8.34215812 35.667348399600655 139.74797617338865 8.34385728 35.66735699526095 139.74794923508452 8.34403801 35.667308724650304 139.7479261048801 8.34178187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0005_p43_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p43_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p43_0">
											<gml:posList>35.66706799999746 139.74786734419445 19.17100354 35.667065063832624 139.74787654595752 19.17094236 35.66712613268371 139.74790745669335 19.17377852 35.667129524974435 139.74789682546066 19.1738492 35.66706799999746 139.74786734419445 19.17100354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0005_p42_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p42_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p42_0">
											<gml:posList>35.66713994795759 139.74788934935404 17.76924415 35.6671330528647 139.74791095815948 17.76910033 35.667205179401414 139.74794746594935 17.77246204 35.66721261321474 139.74792416883025 17.77261708 35.66713994795759 139.74788934935404 17.76924415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0005_p827_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p827_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p827_0">
											<gml:posList>35.666993525116155 139.74784528388952 20.68766534 35.6669694420484 139.74783374386152 20.68655755 35.666957467265505 139.74787127208108 20.68630948 35.66696851125174 139.74787656407926 20.68681733 35.666943760548286 139.74795413259247 20.68631121 35.66695679921248 139.74796038041455 20.68691113 35.666993525116155 139.74784528388952 20.68766534</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="gml_9e4539fa-4cd4-443e-b5bc-0b41a42165eb">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_dfeca949-04b4-4525-a5fb-9fe3bdcb4e35">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4ace0293-989f-4e84-bb5e-957db157b73b">
											<gml:posList>35.66744792937604 139.74809450514292 37.399992405735986 35.66729216208212 139.74814808381464 37.399992405735986 35.66726461855555 139.7482454345722 37.399992405735986 35.66744792937604 139.74809450514292 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5ff5af8c-4c63-4748-acff-1daa4b67bbe8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b9a4b238-ed99-4fd2-b397-038a1367affa">
											<gml:posList>35.66729216208212 139.74814808381464 37.399992405735986 35.66744792937604 139.74809450514292 37.399992405735986 35.66724443813765 139.748122821101 37.399992405735986 35.66729216208212 139.74814808381464 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a3c01993-0758-48a7-b8e7-83d1625df1e8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_21506406-02e6-4867-8edd-d8b90a513ca0">
											<gml:posList>35.66724443813765 139.748122821101 37.399992405735986 35.66744792937604 139.74809450514292 37.399992405735986 35.66698528780475 139.7478709168089 37.399992405735986 35.66724443813765 139.748122821101 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_fb9fb56d-8baf-4d91-aecb-491d33ba6ee8">
									<gml:exterior>
										<gml:LinearRing gml:id="line_29958db1-1c9f-4f9e-b900-6a45f6c21119">
											<gml:posList>35.66726461855555 139.7482454345722 37.399992405735986 35.66729216208212 139.74814808381464 37.399992405735986 35.66726197874285 139.74823371061692 37.399992405735986 35.66726461855555 139.7482454345722 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_88cf1eff-2b13-46f8-871c-900f9a137dee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_30ab582d-3b2b-455a-86b4-840e4fb19a5c">
											<gml:posList>35.66726461855555 139.7482454345722 37.399992405735986 35.66726197874285 139.74823371061692 37.399992405735986 35.66721359289762 139.7482103258286 37.399992405735986 35.66726461855555 139.7482454345722 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_365c9ef0-7d71-469f-ae0b-c6d2709cc3e0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f2e75d85-1ab8-414a-8f6c-f985f5e46a4f">
											<gml:posList>35.667094834601116 139.74805492454627 37.399992405735986 35.66698528780475 139.7478709168089 37.399992405735986 35.6669190709331 139.74807843543826 37.399992405735986 35.667094834601116 139.74805492454627 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_467caf13-6dcf-48af-83bf-c18e00b51faf">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1117cf70-46ae-465c-8b63-b20a2404c60b">
											<gml:posList>35.66698528780475 139.7478709168089 37.399992405735986 35.667094834601116 139.74805492454627 37.399992405735986 35.66716667945769 139.74809295550222 37.399992405735986 35.66698528780475 139.7478709168089 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b6a98d49-74d5-45f1-9d63-368492024f2c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_79077de1-d453-4019-92dd-8476774aba33">
											<gml:posList>35.667094834601116 139.74805492454627 37.399992405735986 35.6669190709331 139.74807843543826 37.399992405735986 35.66707474903138 139.7481119050518 37.399992405735986 35.667094834601116 139.74805492454627 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_da2409a2-7167-4b65-a197-366ad9f38724">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ea5b0d17-3cab-4dba-91b4-214d32a0f084">
											<gml:posList>35.66707474903138 139.7481119050518 37.399992405735986 35.6669190709331 139.74807843543826 37.399992405735986 35.667071201879914 139.74812259090456 37.399992405735986 35.66707474903138 139.7481119050518 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e0f852f8-e061-4a7a-9d3f-39d39894db96">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ae6e7b4a-e7c9-48a1-8c16-fad9a2d1c705">
											<gml:posList>35.66707474903138 139.7481119050518 37.399992405735986 35.667071201879914 139.74812259090456 37.399992405735986 35.66714659386178 139.7481499362179 37.399992405735986 35.66707474903138 139.7481119050518 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_96781e23-a766-432b-988d-de1a3480ec34">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a2b0a136-7323-48f5-9fc8-b4c7e59ed2e4">
											<gml:posList>35.667071201879914 139.74812259090456 37.399992405735986 35.6669190709331 139.74807843543826 37.399992405735986 35.66706237842551 139.74814769418944 37.399992405735986 35.667071201879914 139.74812259090456 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_acfbcf0d-ce9c-48ec-8285-39dfd0d3929d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f3609d10-502d-4df8-9df6-f483c62d9359">
											<gml:posList>35.66724443813765 139.748122821101 37.399992405735986 35.66716667945769 139.74809295550222 37.399992405735986 35.66714659386178 139.7481499362179 37.399992405735986 35.66724443813765 139.748122821101 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_738e50ad-b32a-404a-a7a6-676e2c781391">
									<gml:exterior>
										<gml:LinearRing gml:id="line_35f7c58e-fb15-472c-92cb-065826abfae9">
											<gml:posList>35.66716667945769 139.74809295550222 37.399992405735986 35.66724443813765 139.748122821101 37.399992405735986 35.66698528780475 139.7478709168089 37.399992405735986 35.66716667945769 139.74809295550222 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eab08ecd-7ffd-408d-9c27-71c998bdec6e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4351a1a7-5af8-4688-8ebf-f9437c19b591">
											<gml:posList>35.66724443813765 139.748122821101 37.399992405735986 35.66714659386178 139.7481499362179 37.399992405735986 35.66721359289762 139.7482103258286 37.399992405735986 35.66724443813765 139.748122821101 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_59db1634-c3e0-4e2f-899b-7480b3be57d2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_81ec456a-c9b0-47c0-9ff9-d99fc2113c4c">
											<gml:posList>35.66721359289762 139.7482103258286 37.399992405735986 35.66714659386178 139.7481499362179 37.399992405735986 35.6671426952203 139.74816040620775 37.399992405735986 35.66721359289762 139.7482103258286 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_922206f7-5100-4a2b-ad36-f8cd3b076f2f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2f5d41d0-78ff-40d1-8c7e-536b3ffe12ee">
											<gml:posList>35.6671426952203 139.74816040620775 37.399992405735986 35.66714659386178 139.7481499362179 37.399992405735986 35.667071201879914 139.74812259090456 37.399992405735986 35.6671426952203 139.74816040620775 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_3a1031e5-4bdb-4d66-86de-8b59b9bb418a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d6039223-562d-436e-8d9f-2d8b353f898c">
											<gml:posList>35.66721359289762 139.7482103258286 37.399992405735986 35.6671426952203 139.74816040620775 37.399992405735986 35.66713485228036 139.7481827198805 37.399992405735986 35.66721359289762 139.7482103258286 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_b1afb1b8-5af9-45c6-b1a6-0e9d79af87ee">
									<gml:exterior>
										<gml:LinearRing gml:id="line_86c43d5d-cfc8-4361-838a-ecaed9078d77">
											<gml:posList>35.66721359289762 139.7482103258286 37.399992405735986 35.66713485228036 139.7481827198805 37.399992405735986 35.66726461855555 139.7482454345722 37.399992405735986 35.66721359289762 139.7482103258286 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0005_p38_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p38_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p38_0">
											<gml:posList>35.6671089175214 139.7481408998784 14.56472252 35.66715331814257 139.74816337396723 14.56679514 35.66716886658369 139.74811724435378 14.5671243 35.66712446595405 139.74809477028617 14.56505168 35.6671089175214 139.7481408998784 14.56472252</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="roof_TMmnt0005_p32_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p32_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p32_0">
											<gml:posList>35.66735179262312 139.74820985447536 36.27571227 35.667465450615005 139.7481171257864 36.27996943 35.66734878510733 139.74806122195878 36.27448886 35.66731257482064 139.74816864902428 36.27370686 35.667105359244474 139.74806376051956 36.2640076 35.667139945783475 139.74796115068273 36.2647541 35.66698082472115 139.74788490369866 36.25740222 35.66691575016238 139.7480888424303 36.25609123 35.66728389428579 139.74826524966733 36.27318629 35.66731094641348 139.74824317906993 36.27419115 35.66715324236396 139.74816335440738 36.26679344 35.66710884189427 139.74814088039494 36.26472083 35.667124390273834 139.74809475095958 36.26504998 35.667168790751894 139.7481172249508 36.2671226 35.66735179262312 139.74820985447536 36.27571227</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p33_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p33_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p33_4">
											<gml:posList>35.667105353773685 139.74806375912885 37.83400748 35.667105359244474 139.74806376051956 36.2640076 35.66731257482064 139.74816864902428 36.27370686 35.66731256929872 139.74816864760788 37.84370674 35.667105353773685 139.74806375912885 37.83400748</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_b21919d3-681c-4c76-8505-363dc8a92d5d">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4853c5bc-50a0-4c82-867d-aef5a9a69fd7">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9149df37-9404-4e7d-9720-7d5278b85f0e">
											<gml:posList>35.66708224103996 139.7480482581393 31.476881443821924 35.66717929830707 139.74809963537993 31.476881443821924 35.66716667945769 139.74809295550222 37.399992405735986 35.667094834601116 139.74805492454627 37.399992405735986 35.66708224103996 139.7480482581393 31.476881443821924</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_4754a27f-89f8-428a-8396-71f29cea9a61">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9dd72a77-452b-4206-beee-fd200e5b2162">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4a84673e-fa75-4531-b1ec-0f875fcf5f32">
											<gml:posList>35.66693306829661 139.7480852018083 11.276731907689111 35.66691907038414 139.74807843712432 6.049024998509424 35.66693306820659 139.7480852021455 6.049024998509424 35.66693306829661 139.7480852018083 11.276731907689111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_882612bd-c1e3-44e1-aa3a-3e88f4d2c147">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1883483b-4a22-42b3-8a99-46b08a9b2948">
											<gml:posList>35.66691907038414 139.74807843712432 6.049024998509424 35.66693306829661 139.7480852018083 11.276731907689111 35.6669190709331 139.74807843543826 37.399992405735986 35.66691907038414 139.74807843712432 6.049024998509424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e0eef900-6dca-4b08-94bd-03146aef6f2f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8a610655-5c5f-4b58-aec1-7366bde6a189">
											<gml:posList>35.6669190709331 139.74807843543826 37.399992405735986 35.66693306829661 139.7480852018083 11.276731907689111 35.667023045327475 139.74812868628794 15.37688296970083 35.6669190709331 139.74807843543826 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5f27c6be-d6bd-4ae8-88f3-537adfcae3e9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_79d17c64-bdec-4e8c-8961-ace1afbeb72e">
											<gml:posList>35.667023045327475 139.74812868628794 15.37688296970083 35.66693306829661 139.7480852018083 11.276731907689111 35.66696224412727 139.74809930214064 11.276731907689111 35.667023045327475 139.74812868628794 15.37688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bc136c04-9d34-4da9-bd5b-2be898893761">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7194aba3-95e7-456b-9d56-2eb6f4e45eb7">
											<gml:posList>35.667023045327475 139.74812868628794 15.37688296970083 35.66696224412727 139.74809930214064 11.276731907689111 35.66696325021243 139.74809978833594 11.276731907689111 35.667023045327475 139.74812868628794 15.37688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_2228111c-2d3f-4c04-8960-aee228b8f0d0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f70e5d9b-0aaf-488e-91e5-984399017fb2">
											<gml:posList>35.667023045327475 139.74812868628794 15.37688296970083 35.66696325021243 139.74809978833594 11.276731907689111 35.66699243048246 139.74811389086526 11.276731907689111 35.667023045327475 139.74812868628794 15.37688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6731c7c3-4db4-477b-bdc9-8fd21ccf26ab">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2940b03d-bbcc-4993-8827-2260ee4526ab">
											<gml:posList>35.6669190709331 139.74807843543826 37.399992405735986 35.667023045327475 139.74812868628794 15.37688296970083 35.66706237842551 139.74814769418944 37.399992405735986 35.6669190709331 139.74807843543826 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_02565a50-f037-4031-8248-ce06c13ff0dc">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c7423281-10b5-4134-b329-c6e10689e074">
											<gml:posList>35.66696224412727 139.74809930214064 11.276731907689111 35.66696325012457 139.74809978867313 6.049024998509424 35.66696325021243 139.74809978833594 11.276731907689111 35.66696224412727 139.74809930214064 11.276731907689111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0713922f-827f-423d-9036-9b1b457f445c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a1cac3cf-7ceb-49d1-80fd-91039d6868c3">
											<gml:posList>35.66696325012457 139.74809978867313 6.049024998509424 35.66696224412727 139.74809930214064 11.276731907689111 35.666962244035105 139.74809930247784 6.049024998509424 35.66696325012457 139.74809978867313 6.049024998509424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a5cb01b0-633b-483e-91e6-ae251ac2e09b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1d2cbd45-f7dd-443f-a794-080905587f2f">
											<gml:posList>35.66699243048246 139.74811389086526 11.276731907689111 35.667099094637734 139.74816544062796 6.049024998509424 35.66709909474066 139.74816544029073 11.276731907689111 35.66699243048246 139.74811389086526 11.276731907689111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ef240b46-3f65-4cde-b5d0-efc3d39c3ebb">
									<gml:exterior>
										<gml:LinearRing gml:id="line_aa11ec7d-972d-4c5b-b9fb-2a00a923b5c5">
											<gml:posList>35.667099094637734 139.74816544062796 6.049024998509424 35.66699243048246 139.74811389086526 11.276731907689111 35.666992430390714 139.7481138910339 6.049024998509424 35.667099094637734 139.74816544062796 6.049024998509424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_eccf2dfd-9852-494d-938b-5f32e0f65f13">
									<gml:exterior>
										<gml:LinearRing gml:id="line_9d1e1339-a56b-40b9-b265-fe3a0d8b37e6">
											<gml:posList>35.66699243048246 139.74811389086526 11.276731907689111 35.66709909474066 139.74816544029073 11.276731907689111 35.667023045327475 139.74812868628794 15.37688296970083 35.66699243048246 139.74811389086526 11.276731907689111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_76e704eb-693a-440c-8118-f1def988d563">
									<gml:exterior>
										<gml:LinearRing gml:id="line_cd3a0fd5-fb1b-416a-b021-9b7796f08155">
											<gml:posList>35.667023045327475 139.74812868628794 15.37688296970083 35.66709909474066 139.74816544029073 11.276731907689111 35.66717405676283 139.74820166830622 15.37688296970083 35.667023045327475 139.74812868628794 15.37688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_af041bdf-cd5b-45eb-8254-86d16b43700e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_626a8725-f511-4270-b2fe-55e5ff90c7e8">
											<gml:posList>35.667173555022366 139.74820142613294 11.276731907689111 35.66717405676283 139.74820166830622 15.37688296970083 35.66709909474066 139.74816544029073 11.276731907689111 35.667173555022366 139.74820142613294 11.276731907689111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_af91b592-52ab-48b4-8a74-63da2db131f3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d7c8c389-2d3d-463d-a37b-9883fea98652">
											<gml:posList>35.66713485228036 139.7481827198805 37.399992405735986 35.66717405676283 139.74820166830622 15.37688296970083 35.66726461855555 139.7482454345722 37.399992405735986 35.66713485228036 139.7481827198805 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_89030592-a9ef-4eb2-ae8c-91f559926371">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d1186241-a17c-4309-8300-819dec3cc788">
											<gml:posList>35.66717405676283 139.74820166830622 15.37688296970083 35.66726461817862 139.74824543642663 6.049024998509424 35.66726461855555 139.7482454345722 37.399992405735986 35.66717405676283 139.74820166830622 15.37688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_773f75ea-da2d-4827-b885-7f1a0d562ee6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_f23eda09-c377-4300-b734-d78c34d8f8cc">
											<gml:posList>35.667173555022366 139.74820142613294 11.276731907689111 35.66726461817862 139.74824543642663 6.049024998509424 35.66717405676283 139.74820166830622 15.37688296970083 35.667173555022366 139.74820142613294 11.276731907689111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_63c0e531-ed12-4650-a1e2-6d4fbb8d57c5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_35099847-cba0-4451-974a-77e84d963dff">
											<gml:posList>35.66726461817862 139.74824543642663 6.049024998509424 35.667173555022366 139.74820142613294 11.276731907689111 35.66717355491945 139.74820142647013 6.049024998509424 35.66726461817862 139.74824543642663 6.049024998509424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p827_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p827_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p827_2">
											<gml:posList>35.66694370727745 139.74795411921608 36.08631003 35.66693266290511 139.74794882701363 36.08580217 35.66693276897935 139.747948853637 5.4055812 35.66695685210045 139.7479603937019 5.40668899 35.66695679921248 139.74796038041455 20.68691113 35.666943760548286 139.74795413259247 20.68631121 35.66694370727745 139.74795411921608 36.08631003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_621416a5-e242-41b9-8304-537dea862790">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f241c7f4-49b6-463a-9888-bf52b7a3b588">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5feb73ff-ab14-483d-9a2a-f1cc6481fbd2">
											<gml:posList>35.66717929830707 139.74809963537993 31.476881443821924 35.667159212707936 139.74815661593442 31.476881443821924 35.66714659386178 139.7481499362179 37.399992405735986 35.66716667945769 139.74809295550222 37.399992405735986 35.66717929830707 139.74809963537993 31.476881443821924</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p827_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p827_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p827_1">
											<gml:posList>35.6669694420484 139.74783374386152 20.68655755 35.666993525116155 139.74784528388952 20.68766534 35.666993578092544 139.74784529690132 5.40744319 35.66696949496681 139.74783375684578 5.4063354 35.6669694420484 139.74783374386152 20.68655755</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p634_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p634_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p634_1">
											<gml:posList>35.66695741396153 139.74787125890458 36.0863083 35.666957467265505 139.74787127208108 20.68630948 35.6669694420484 139.74783374386152 20.68655755 35.66696949496681 139.74783375684578 5.4063354 35.66693276897935 139.747948853637 5.4055812 35.66693266290511 139.74794882701363 36.08580217 35.66695741396153 139.74787125890458 36.0863083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_197bb059-4691-4a62-a3c4-8f542b813c55">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8e191dfd-f4f1-4bfc-b2e2-e808e43c6077">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b69477bf-fd18-4f1b-b494-33202ce1337f">
											<gml:posList>35.66694011258074 139.74807369565193 11.27672427829458 35.66693306829661 139.7480852018083 11.276731907689111 35.66693306820659 139.7480852021455 6.049024998509424 35.666940112520685 139.74807369582052 6.049024998509424 35.66694011258074 139.74807369565193 11.27672427829458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p33_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p33_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p33_3">
											<gml:posList>35.66734877957642 139.7480612205688 37.84448874 35.66731256929872 139.74816864760788 37.84370674 35.66731257482064 139.74816864902428 36.27370686 35.66734878510733 139.74806122195878 36.27448886 35.66734877957642 139.7480612205688 37.84448874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_e5b44ae5-9d69-4f29-9d84-9efbc831d56c">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_cab03f07-e636-498b-a053-5fe2234a5f96">
									<gml:exterior>
										<gml:LinearRing gml:id="line_50d6a72c-37ae-40e8-ac30-8c19bb4955ba">
											<gml:posList>35.6669663968756 139.74808639844318 11.27672427829458 35.66696639678343 139.74808639878037 6.049024998509424 35.666962244035105 139.74809930247784 6.049024998509424 35.66696224412727 139.74809930214064 11.276731907689111 35.6669663968756 139.74808639844318 11.27672427829458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_88e31dca-a222-4a70-9669-9c4f1a53943e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8f03e157-207b-4036-8f7d-05726f82c933">
									<gml:exterior>
										<gml:LinearRing gml:id="line_98eee592-99e1-4806-a6bf-dd742860e5ed">
											<gml:posList>35.666967020923536 139.74808807177246 6.049024998509424 35.66696702101571 139.74808807143526 11.27672427829458 35.66696325021243 139.74809978833594 11.276731907689111 35.66696325012457 139.74809978867313 6.049024998509424 35.666967020923536 139.74808807177246 6.049024998509424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_235f9b65-2fc4-4d9c-ab1d-2936cb308aca">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_899301ff-58c5-41b9-a69e-7a040342f5c5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c87d66ef-659c-4cae-98ca-946421ad37d0">
											<gml:posList>35.66699620128816 139.74810217396097 11.27672427829458 35.666996201196405 139.74810217412963 6.049024998509424 35.666992430390714 139.7481138910339 6.049024998509424 35.66699243048246 139.74811389086526 11.276731907689111 35.66699620128816 139.74810217396097 11.27672427829458</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_626864c9-4ca3-4364-a243-ecbec86b26bf">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_760b9788-3fad-46b2-9c29-7cee8b89eec9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7a8dd1e2-9634-41ca-aa54-ac16f8bd7123">
											<gml:posList>35.66697672373671 139.74809276100905 6.049024998509424 35.666976723801056 139.74809276084042 9.676886021458643 35.666987032217634 139.74809774270346 9.676886021458643 35.66698703215382 139.74809774287206 6.049024998509424 35.666996201196405 139.74810217412963 6.049024998509424 35.66699620128816 139.74810217396097 11.27672427829458 35.66696702101571 139.74808807143526 11.27672427829458 35.666967020923536 139.74808807177246 6.049024998509424 35.66697672373671 139.74809276100905 6.049024998509424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_ba219e4a-7b52-4adc-ad4f-7c95231ceeb4">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_547673a1-8f23-492f-9a32-39c39826fc64">
											<gml:exterior>
												<gml:LinearRing gml:id="line_badddb40-57f0-4234-8073-7b9423ec9368">
													<gml:posList>35.666987032217634 139.74809774270346 9.676886021458643 35.666976723801056 139.74809276084042 9.676886021458643 35.66697672373671 139.74809276100905 6.049024998509424 35.66698703215382 139.74809774287206 6.049024998509424 35.666987032217634 139.74809774270346 9.676886021458643</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_ce8845e9-920f-4834-8f04-6b50324bd991">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_68589374-98cb-4e4b-bf13-ece76073126a">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0fe8c1e2-23d3-4965-8994-81db957c7cb9">
											<gml:posList>35.66698751049082 139.74786395098587 15.37688296970083 35.66709742857257 139.74791707267994 15.37688296970083 35.66704651891001 139.74789246869594 12.599996983372705 35.66703495983853 139.7478868824357 12.599996983372705 35.66698751049082 139.74786395098587 10.076925694310205 35.66698751049082 139.74786395098587 15.37688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p32_4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p32_4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p32_4">
											<gml:posList>35.667465450615005 139.7481171257864 36.27996943 35.66735179262312 139.74820985447536 36.27571227 35.66731094641348 139.74824317906993 36.27419115 35.66728389428579 139.74826524966733 36.27318629 35.667284002652146 139.74826527796753 5.42296541 35.66746555986244 139.7481171533708 5.42974859 35.667465450615005 139.7481171257864 36.27996943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2d3923cd-a916-4370-9224-8b4875bc8b09">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_66c1f37b-7ce5-4ef4-ab0e-7799e7aa6564">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c7761795-dbc7-4cf0-8878-5a41738df17b">
											<gml:posList>35.66709469228057 139.74785303381066 10.776884495579736 35.66709469228057 139.74785303381066 6.049024998509424 35.66708755102188 139.74784958252985 6.049024998509424 35.66708755102188 139.74784958252985 10.776884495579736 35.66709469228057 139.74785303381066 10.776884495579736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_769e3105-06c1-4131-8bcb-a5c7711dd4e1">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_e44f42b1-f1ee-4c05-bbc9-5eab52d56a22">
											<gml:exterior>
												<gml:LinearRing gml:id="line_733cd459-29a6-4e97-bdca-5dd8b052c212">
													<gml:posList>35.66710183352196 139.74785648509211 6.049024998509424 35.66709469228057 139.74785303381066 6.049024998509424 35.66709469228057 139.74785303381066 10.776884495579736 35.66710183352196 139.74785648509211 10.776884495579736 35.66710183352196 139.74785648509211 6.049024998509424</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p634_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p634_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p634_3">
											<gml:posList>35.66694370727745 139.74795411921608 36.08631003 35.666943760548286 139.74795413259247 20.68631121 35.66696851125174 139.74787656407926 20.68681733 35.66696845792099 139.74787655089 36.08681615 35.66694370727745 139.74795411921608 36.08631003</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_736135ca-9462-457e-8cad-e5f0be7e5e60">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_74721d90-1c28-4642-b033-3fe6be06b7c9">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2e80c7b2-cb11-42ac-aa21-27d07b002cc1">
											<gml:posList>35.667159212707936 139.74815661593442 31.476881443821924 35.66706215546485 139.74810523880612 31.476881443821924 35.66707474903138 139.7481119050518 37.399992405735986 35.66714659386178 139.7481499362179 37.399992405735986 35.667159212707936 139.74815661593442 31.476881443821924</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p34_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p34_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p34_2">
											<gml:posList>35.667124390273834 139.74809475095958 36.26504998 35.66712446595405 139.74809477028617 14.56505168 35.66716886658369 139.74811724435378 14.5671243 35.667168790751894 139.7481172249508 36.2671226 35.667124390273834 139.74809475095958 36.26504998</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_b44c603f-f9ca-4cce-8ae7-9778612db0a1">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0ce65b94-bcfe-44fc-a6bd-3927004913d5">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5c53aeed-e12d-43c0-91ce-0b7f9d3e7d95">
											<gml:posList>35.66726197874285 139.74823371061692 32.87688296970083 35.66721359289762 139.7482103258286 32.87688296970083 35.66721359289762 139.7482103258286 37.399992405735986 35.66726197874285 139.74823371061692 37.399992405735986 35.66726197874285 139.74823371061692 32.87688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f6e208ba-c336-419d-98c8-471840c90a35">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d8a4004c-cd57-4273-b3ec-8d7e082eaf36">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ff9e8394-a020-41ce-827b-c9289bd96ee2">
											<gml:posList>35.667002443673304 139.74781715123336 10.00481265720083 35.66704949013252 139.74784567408236 12.599996983372705 35.667060636385436 139.7478524316639 12.599996983372705 35.66710969534587 139.74788217453425 15.37688296970083 35.66700242908098 139.74781719692476 10.456694065892236 35.667002443673304 139.74781715123336 10.00481265720083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p634_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p634_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p634_2">
											<gml:posList>35.66696845792099 139.74787655089 36.08681615 35.66696851125174 139.74787656407926 20.68681733 35.666957467265505 139.74787127208108 20.68630948 35.66695741396153 139.74787125890458 36.0863083 35.66696845792099 139.74787655089 36.08681615</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_ac4aee45-969d-4fe5-b299-2887313af97e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_ef910cc9-a963-432b-b5ee-f4942a76a5dd">
									<gml:exterior>
										<gml:LinearRing gml:id="line_77f07b56-b43d-4a1c-9cdf-f84fa41420e4">
											<gml:posList>35.66724443813765 139.748122821101 32.87688296970083 35.66729216208212 139.74814808381464 32.87688296970083 35.66729216208212 139.74814808381464 37.399992405735986 35.66724443813765 139.748122821101 37.399992405735986 35.66724443813765 139.748122821101 32.87688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_cb90db39-9e52-4051-ae2a-f3014bf16704">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5f143e68-c1b7-4d3b-a8af-bf1947fde310">
									<gml:exterior>
										<gml:LinearRing gml:id="line_129bd011-410f-422b-9153-f08f93b66706">
											<gml:posList>35.66714655280541 139.74787862832568 10.776884495579736 35.66714655280541 139.74787862832568 6.049024998509424 35.66713461097799 139.7478728568996 6.049024998509424 35.66713461097799 139.7478728568996 10.776884495579736 35.66714655280541 139.74787862832568 10.776884495579736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_22c5a12c-1619-4f99-ac7b-d29f83da2938">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_f8802212-e9c7-4755-ab74-21f1fa3a02d0">
											<gml:exterior>
												<gml:LinearRing gml:id="line_94077d7e-1661-4dae-b47b-15ee1633c54c">
													<gml:posList>35.667116383599 139.74786404790225 10.776884495579736 35.66713461097799 139.7478728568996 10.776884495579736 35.66713461097799 139.7478728568996 6.049024998509424 35.667116383599 139.74786404790225 6.049024998509424 35.667116383599 139.74786404790225 10.776884495579736</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_599a00a2-83bd-41fd-9a6d-38e4c372a19e">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_edf9e87a-48b5-4faa-99cc-0e6f7613ef1d">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8430a2ec-9cd7-4c93-b34b-c8a47e348f2f">
											<gml:posList>35.667171196913415 139.74789053830827 10.776884495579736 35.667171624918566 139.74788920836286 10.776884495579736 35.667175177257796 139.74787817022013 6.049024998509424 35.667171196913415 139.74789053830827 6.049024998509424 35.667171196913415 139.74789053830827 10.776884495579736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7dc4fa9e-4d29-46c9-8ad5-e318dabf58d6">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_01ad5097-45eb-49ce-a94a-db95167d1d3f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_5fc55cf9-c487-47fc-b89c-a0af2853e770">
											<gml:posList>35.667116383599 139.74786404790225 10.776884495579736 35.667116383599 139.74786404790225 6.049024998509424 35.667107432553045 139.74785972211106 6.049024998509424 35.667107432553045 139.74785972211106 10.776884495579736 35.667116383599 139.74786404790225 10.776884495579736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_c4bf0db9-fee0-4a01-9fdb-9fd281885f18">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c91d83dc-886c-4ced-a517-d4e9306af4f1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d61972cc-0394-4b65-95fd-f016e1e915d4">
											<gml:posList>35.667042738757786 139.74810753581943 21.176886021458643 35.66717102653268 139.74817539169234 21.176886021458643 35.6671426952203 139.74816040620775 37.399992405735986 35.667071201879914 139.74812259090456 37.399992405735986 35.667042738757786 139.74810753581943 21.176886021458643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p42_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p42_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p42_1">
											<gml:posList>35.66713999107754 139.74788935996034 5.41402179 35.66713309597125 139.74791096880767 5.41387797 35.6671330528647 139.74791095815948 17.76910033 35.66713994795759 139.74788934935404 17.76924415 35.66713999107754 139.74788935996034 5.41402179</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_df42aaf7-a340-46f8-9391-c56a47ddfb1b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c3479b43-4317-4e01-9dc3-b084ebbecfa4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_be2c01c4-7633-4223-8904-45424909f552">
											<gml:posList>35.667107432553045 139.74785972211106 10.776884495579736 35.667107432553045 139.74785972211106 6.049024998509424 35.66711141288572 139.74784735403125 6.049024998509424 35.667107860557856 139.7478583921666 10.776884495579736 35.667107432553045 139.74785972211106 10.776884495579736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_da2382b0-3594-4e32-a11a-c587427f514f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_01adcdff-639a-464d-af7e-1d909d36b62c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c23033c6-e0c5-48eb-a0df-9a88eae17ca9">
											<gml:posList>35.66706215546485 139.74810523880612 31.476881443821924 35.66708224103996 139.7480482581393 31.476881443821924 35.667094834601116 139.74805492454627 37.399992405735986 35.66707474903138 139.7481119050518 37.399992405735986 35.66706215546485 139.74810523880612 31.476881443821924</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p34_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p34_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p34_0">
											<gml:posList>35.66715324236396 139.74816335440738 36.26679344 35.66715331814257 139.74816337396723 14.56679514 35.6671089175214 139.7481408998784 14.56472252 35.66710884189427 139.74814088039494 36.26472083 35.66715324236396 139.74816335440738 36.26679344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7c12a2b7-3676-40b6-9802-d9be7a825e34">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_de36557c-9660-48c2-b387-c1669d41b717">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a21e288e-eb53-4836-8f35-84bfc866d4a7">
											<gml:posList>35.667042738757786 139.74810753581943 21.176886021458643 35.66706237842551 139.74814769418944 37.399992405735986 35.667023045327475 139.74812868628794 15.37688296970083 35.667042738757786 139.74810753581943 21.176886021458643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_bb6363f1-4aa6-4c7e-a293-f3f1fdd244ab">
									<gml:exterior>
										<gml:LinearRing gml:id="line_2451ad77-03f5-4938-bc1c-682dca9bd0fa">
											<gml:posList>35.66706237842551 139.74814769418944 37.399992405735986 35.667042738757786 139.74810753581943 21.176886021458643 35.667071201879914 139.74812259090456 37.399992405735986 35.66706237842551 139.74814769418944 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_276692f3-d9ea-4fa6-a58f-370b0ed1191e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c7fde08c-cd02-4482-b1c7-4aec01ad0a0e">
											<gml:posList>35.667042738757786 139.74810753581943 21.176886021458643 35.667023045327475 139.74812868628794 15.37688296970083 35.66709742857257 139.74791707267994 15.37688296970083 35.667042738757786 139.74810753581943 21.176886021458643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_600271f5-6ee8-41ac-b383-3b903ca88108">
									<gml:exterior>
										<gml:LinearRing gml:id="line_90365089-c3bd-44aa-acc7-1a7aa66bb587">
											<gml:posList>35.667042738757786 139.74810753581943 21.176886021458643 35.66709742857257 139.74791707267994 15.37688296970083 35.66710320592359 139.74793551216348 21.176886021458643 35.667042738757786 139.74810753581943 21.176886021458643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p42_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p42_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p42_2">
											<gml:posList>35.66713994795759 139.74788934935404 17.76924415 35.66721261321474 139.74792416883025 17.77261708 35.66721265647589 139.74792417950403 5.41739473 35.66713999107754 139.74788935996034 5.41402179 35.66713994795759 139.74788934935404 17.76924415</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p58_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p58_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p58_0">
											<gml:posList>35.66720522264817 139.74794747666823 5.41723969 35.667205179401414 139.74794746594935 17.77246204 35.6671330528647 139.74791095815948 17.76910033 35.66713309597125 139.74791096880767 5.41387797 35.66712618067729 139.74790746854498 5.41355627 35.66712613268371 139.74790745669335 19.17377852 35.667065063832624 139.74787654595752 19.17094236 35.66706511169402 139.74787655774253 5.4107201 35.666994937035646 139.7478410380561 5.40747148 35.66699488420162 139.74784102509022 20.64570304 35.66726920220491 139.74797987666074 22.94244763 35.667269263714026 139.74797989195127 5.42023443 35.66720522264817 139.74794747666823 5.41723969</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f023e758-399c-4ff3-8c08-f039a9fd9179">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_0a997219-8441-4ca9-b51d-a67c91051bef">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ffd3bca-ab0c-4551-8b5c-bb84616e032c">
											<gml:posList>35.66708755102188 139.74784958252985 6.049024998509424 35.667091383447506 139.7478376740657 6.049024998509424 35.66708783112051 139.74784871219867 10.776884495579736 35.66708755102188 139.74784958252985 10.776884495579736 35.66708755102188 139.74784958252985 6.049024998509424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_cb39f944-3067-4c4f-ae39-48000bc86fda">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c5fe21da-cf7f-40d3-a614-0d3c71973828">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d843e673-03c1-4da7-adad-43d6c748d508">
											<gml:posList>35.667186236367826 139.74816673436297 11.276731907689111 35.667186236367826 139.74816673436297 6.049024998509424 35.66717355491945 139.74820142647013 6.049024998509424 35.667173555022366 139.74820142613294 11.276731907689111 35.667186236367826 139.74816673436297 11.276731907689111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p32_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p32_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p32_2">
											<gml:posList>35.66728389428579 139.74826524966733 36.27318629 35.66691575016238 139.7480888424303 36.25609123 35.6669158567422 139.74808886987776 5.40587027 35.667284002652146 139.74826527796753 5.42296541 35.66728389428579 139.74826524966733 36.27318629</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p42_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p42_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p42_3">
											<gml:posList>35.66721261321474 139.74792416883025 17.77261708 35.667205179401414 139.74794746594935 17.77246204 35.66720522264817 139.74794747666823 5.41723969 35.66721265647589 139.74792417950403 5.41739473 35.66721261321474 139.74792416883025 17.77261708</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p32_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p32_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p32_3">
											<gml:posList>35.66691575016238 139.7480888424303 36.25609123 35.66698082472115 139.74788490369866 36.25740222 35.66699488420162 139.74784102509022 20.64570304 35.666994937035646 139.7478410380561 5.40747148 35.666993578092544 139.74784529690132 5.40744319 35.666993525116155 139.74784528388952 20.68766534 35.66695679921248 139.74796038041455 20.68691113 35.66695685210045 139.7479603937019 5.40668899 35.6669158567422 139.74808886987776 5.40587027 35.66691575016238 139.7480888424303 36.25609123</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p43_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p43_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p43_1">
											<gml:posList>35.667068047865136 139.74786735595956 5.41078129 35.66706511169402 139.74787655774253 5.4107201 35.667065063832624 139.74787654595752 19.17094236 35.66706799999746 139.74786734419445 19.17100354 35.667068047865136 139.74786735595956 5.41078129</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_0daabb8c-3e48-4655-97fd-cad754845d46">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_4f94723a-1033-437b-bfbf-920dac7cc3a6">
									<gml:exterior>
										<gml:LinearRing gml:id="line_4717f684-131c-48d1-8c91-70cdeeff38f3">
											<gml:posList>35.66716164614876 139.7478859225773 6.049024998509424 35.66716164614876 139.7478859225773 10.776884495579736 35.667171196913415 139.74789053830827 10.776884495579736 35.667171196913415 139.74789053830827 6.049024998509424 35.66716164614876 139.7478859225773 6.049024998509424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_ca00ee4c-94bb-4943-a4a0-8c75dae40b01">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_0b4cea52-503d-45e2-babf-ce9e9bfedee5">
											<gml:exterior>
												<gml:LinearRing gml:id="line_9cc9cc6a-a8d1-43c7-9e32-c298269f7fb9">
													<gml:posList>35.66714655280541 139.74787862832568 10.776884495579736 35.66716164614876 139.7478859225773 10.776884495579736 35.66716164614876 139.7478859225773 6.049024998509424 35.66714655280541 139.74787862832568 6.049024998509424 35.66714655280541 139.74787862832568 10.776884495579736</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p40_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p40_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p40_1">
											<gml:posList>35.667308734919466 139.74792610740386 5.42155877 35.66729574443862 139.74796681881622 5.42128605 35.66729573417539 139.74796681627402 8.34150915 35.667308724650304 139.7479261048801 8.34178187 35.667308734919466 139.74792610740386 5.42155877</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p40_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p40_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p40_2">
											<gml:posList>35.667308724650304 139.7479261048801 8.34178187 35.66735699526095 139.74794923508452 8.34403801 35.66735700555229 139.74794923761885 5.42381492 35.667308734919466 139.74792610740386 5.42155877 35.667308724650304 139.7479261048801 8.34178187</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d2b2ac78-18c1-42bc-aac3-4240b33f9c06">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_78e027bd-f1b9-411a-8988-981c1a9c3348">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8ff14379-8bfb-42a3-a943-4fd7bd96f671">
											<gml:posList>35.66721359289762 139.7482103258286 32.87688296970083 35.66724443813765 139.748122821101 32.87688296970083 35.66724443813765 139.748122821101 37.399992405735986 35.66721359289762 139.7482103258286 37.399992405735986 35.66721359289762 139.7482103258286 32.87688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_9cd5b067-b6e4-4c81-bd48-8fc40da2f0d5">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f7011c5c-3cc5-4eaa-bda7-ef9362ab7eb2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_48bfb675-0eb2-43c6-b8d7-76146847c0ce">
											<gml:posList>35.66698751049082 139.74786395098587 15.37688296970083 35.66698318469728 139.74787750765907 21.176886021458643 35.66710320592359 139.74793551216348 21.176886021458643 35.66709742857257 139.74791707267994 15.37688296970083 35.66698751049082 139.74786395098587 15.37688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_dc1a43a8-819c-4a02-ad14-3b7b8042a638">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_feee8be2-b742-4cf1-9c0e-a8692d42bd9f">
									<gml:exterior>
										<gml:LinearRing gml:id="line_864bedea-1565-416b-8593-98672d477592">
											<gml:posList>35.66711284591951 139.74787321145678 15.37688296970083 35.667263857511195 139.74794619307502 15.37688296970083 35.66724867065396 139.74795450086583 21.176886021458643 35.66699737018868 139.74783305132198 21.176886021458643 35.66698528780475 139.7478709168089 37.399992405735986 35.66744792937604 139.74809450514292 37.399992405735986 35.66741770556413 139.74799538079301 6.049024998509424 35.667175177257796 139.74787817022013 6.049024998509424 35.667171624918566 139.74788920836286 10.776884495579736 35.667107860557856 139.7478583921666 10.776884495579736 35.66711141288572 139.74784735403125 6.049024998509424 35.66710566594826 139.7478445766262 6.049024998509424 35.66710211362066 139.74785561476085 10.776884495579736 35.66708783112051 139.74784871219867 10.776884495579736 35.667091383447506 139.7478376740657 6.049024998509424 35.66700865293279 139.74779769176794 6.049024998509424 35.667005365558104 139.74780799424488 10.456724583470361 35.66711284591951 139.74787321145678 15.37688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_ec742ddd-6c6c-4151-899d-107012cc2e76">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_d238b05e-94be-445a-8219-d506a6361147">
									<gml:exterior>
										<gml:LinearRing gml:id="line_6e016842-229a-4d75-ab72-0063a4da496e">
											<gml:posList>35.667005365558104 139.74780799424488 10.456724583470361 35.66700242908098 139.74781719692476 10.456694065892236 35.66710969534587 139.74788217453425 15.37688296970083 35.66711284591951 139.74787321145678 15.37688296970083 35.667005365558104 139.74780799424488 10.456724583470361</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p33_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p33_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p33_2">
											<gml:posList>35.667105353773685 139.74806375912885 37.83400748 35.66713994030414 139.74796114931735 37.83475398 35.667139945783475 139.74796115068273 36.2647541 35.667105359244474 139.74806376051956 36.2640076 35.667105353773685 139.74806375912885 37.83400748</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p43_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p43_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p43_3">
											<gml:posList>35.667129524974435 139.74789682546066 19.1738492 35.66712613268371 139.74790745669335 19.17377852 35.66712618067729 139.74790746854498 5.41355627 35.6671295729753 139.7478968372893 5.41362695 35.667129524974435 139.74789682546066 19.1738492</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p33_0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p33_0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p33_0">
											<gml:posList>35.66734877957642 139.7480612205688 37.84448874 35.66734878510733 139.74806122195878 36.27448886 35.667139945783475 139.74796115068273 36.2647541 35.66713994030414 139.74796114931735 37.83475398 35.66734877957642 139.7480612205688 37.84448874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p34_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p34_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p34_3">
											<gml:posList>35.667168790751894 139.7481172249508 36.2671226 35.66716886658369 139.74811724435378 14.5671243 35.66715331814257 139.74816337396723 14.56679514 35.66715324236396 139.74816335440738 36.26679344 35.667168790751894 139.7481172249508 36.2671226</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_f767e7a8-aac5-4399-ae0f-cb53aad6b076">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f970004d-e526-43fd-b789-6edad96080c4">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ce6fbb70-bd0f-470f-a212-f2c816e3289b">
											<gml:posList>35.667245545693696 139.748049831094 6.049024998509424 35.667245545693696 139.748049831094 11.276731907689111 35.66715824726571 139.748003619527 11.276731907689111 35.66715824726571 139.748003619527 6.049024998509424 35.667245545693696 139.748049831094 6.049024998509424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p828_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p828_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p828_2">
											<gml:posList>35.66744139500411 139.7480207362688 10.10321864 35.667465450615005 139.7481171257864 36.27996943 35.66746555986244 139.7481171533708 5.42974859 35.66744141154245 139.74802074037848 5.42799569 35.66744139500411 139.7480207362688 10.10321864</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p34_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p34_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p34_1">
											<gml:posList>35.66710884189427 139.74814088039494 36.26472083 35.6671089175214 139.7481408998784 14.56472252 35.66712446595405 139.74809477028617 14.56505168 35.667124390273834 139.74809475095958 36.26504998 35.66710884189427 139.74814088039494 36.26472083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_a6e72ee1-5bad-475f-9cac-3b33bd0faea2">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8b42d807-e349-443f-8ac3-6aade91c0225">
									<gml:exterior>
										<gml:LinearRing gml:id="line_0ba7a243-9cd1-48e2-9894-78df3fdd2232">
											<gml:posList>35.666957242977894 139.74808197458896 9.676886021458643 35.66695724291785 139.74808197475755 6.049024998509424 35.66696639678343 139.74808639878037 6.049024998509424 35.6669663968756 139.74808639844318 11.27672427829458 35.66694011258074 139.74807369565193 11.27672427829458 35.666940112520685 139.74807369582052 6.049024998509424 35.66694693456128 139.74807699289835 6.049024998509424 35.666946934625635 139.74807699272972 9.676886021458643 35.666957242977894 139.74808197458896 9.676886021458643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_a441f7c7-a254-4388-a792-65ff4aebc71f">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_600b2893-2622-48c3-8e1a-56f65506f2de">
											<gml:exterior>
												<gml:LinearRing gml:id="line_5dfba4ad-73ed-4ccc-a387-7005cf197a6c">
													<gml:posList>35.66694693456128 139.74807699289835 6.049024998509424 35.66695724291785 139.74808197475755 6.049024998509424 35.666957242977894 139.74808197458896 9.676886021458643 35.666946934625635 139.74807699272972 9.676886021458643 35.66694693456128 139.74807699289835 6.049024998509424</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7bf7410d-72e4-4681-af12-ad0047282993">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_11a81eb3-50d5-4f54-bad2-03094e5d0a01">
									<gml:exterior>
										<gml:LinearRing gml:id="line_67dde1ee-8b31-4ff4-b0df-5c5778f38bfa">
											<gml:posList>35.667186236367826 139.74816673436297 11.276731907689111 35.66720012511882 139.74817408607748 11.276731907689111 35.66720012511882 139.74817408607748 6.049024998509424 35.667186236367826 139.74816673436297 6.049024998509424 35.667186236367826 139.74816673436297 11.276731907689111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_fef42133-b0c6-42f7-9971-6641cd5f3c4f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a1f0fb62-9a10-4a10-b9f6-94a44f52f806">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c8cc78b0-8644-40c6-ac11-266146046240">
											<gml:posList>35.66710211362066 139.74785561476085 10.776884495579736 35.66710566594826 139.7478445766262 6.049024998509424 35.66710183352196 139.74785648509211 6.049024998509424 35.66710183352196 139.74785648509211 10.776884495579736 35.66710211362066 139.74785561476085 10.776884495579736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_7063e446-5c7e-4522-8847-7ac803472cb4">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_f6e66d25-5f1e-4188-aaea-839ef6dffa98">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7514bfe0-2106-4ae7-9ae0-eaaa7b5fc935">
											<gml:posList>35.66715824726571 139.748003619527 11.276731907689111 35.66709909474066 139.74816544029073 11.276731907689111 35.667099094637734 139.74816544062796 6.049024998509424 35.66715824726571 139.748003619527 6.049024998509424 35.66715824726571 139.748003619527 11.276731907689111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_ed0a6e5e-1cbe-43bb-937f-94d320751713">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_74c36dfd-6d3b-445f-b21f-9fa6843a0a32">
									<gml:exterior>
										<gml:LinearRing gml:id="line_7cdad568-2955-4269-b759-a7be9ba8a7f8">
											<gml:posList>35.66717102653268 139.74817539169234 21.176886021458643 35.66713485228036 139.7481827198805 37.399992405735986 35.6671426952203 139.74816040620775 37.399992405735986 35.66717102653268 139.74817539169234 21.176886021458643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_5d867945-c700-41ce-8d9b-75fa70d346f1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_c7f9d062-dcff-4cae-915d-0ab6163103b5">
											<gml:posList>35.66717102653268 139.74817539169234 21.176886021458643 35.66717405676283 139.74820166830622 15.37688296970083 35.66713485228036 139.7481827198805 37.399992405735986 35.66717102653268 139.74817539169234 21.176886021458643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_180f4f75-3df7-4ffd-a589-2620e3814d38">
									<gml:exterior>
										<gml:LinearRing gml:id="line_581d8ee7-7725-4178-8647-f978b7d7c87f">
											<gml:posList>35.66717102653268 139.74817539169234 21.176886021458643 35.667263857511195 139.74794619307502 15.37688296970083 35.66717405676283 139.74820166830622 15.37688296970083 35.66717102653268 139.74817539169234 21.176886021458643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_e12001b8-5d78-4d22-98ab-b7ef55165791">
									<gml:exterior>
										<gml:LinearRing gml:id="line_26b398ea-c526-43ce-a658-2111731d3ad4">
											<gml:posList>35.667263857511195 139.74794619307502 15.37688296970083 35.66717102653268 139.74817539169234 21.176886021458643 35.66724867065396 139.74795450086583 21.176886021458643 35.667263857511195 139.74794619307502 15.37688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p43_2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p43_2">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p43_2">
											<gml:posList>35.66706799999746 139.74786734419445 19.17100354 35.667129524974435 139.74789682546066 19.1738492 35.6671295729753 139.7478968372893 5.41362695 35.667068047865136 139.74786735595956 5.41078129 35.66706799999746 139.74786734419445 19.17100354</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_494e730f-b386-4b61-98ce-30600cd10264">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_6f9b4a35-75b0-4477-baec-b026fd7fe302">
									<gml:exterior>
										<gml:LinearRing gml:id="line_32660ac4-92b8-441f-a4f9-36f1cc2b25f1">
											<gml:posList>35.66731479006079 139.74815563120444 11.276884495579736 35.66731479006079 139.74815563120444 6.049024998509424 35.66731842134189 139.74815755366072 6.049024998509424 35.66732987851348 139.7481636189275 11.276884495579736 35.66731479006079 139.74815563120444 11.276884495579736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p58_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p58_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p58_1">
											<gml:posList>35.66726920220491 139.74797987666074 22.94244763 35.66731204993313 139.74795875685243 10.09715798 35.66731205610563 139.74795875837813 8.34215812 35.66729573417539 139.74796681627402 8.34150915 35.66729574443862 139.74796681881622 5.42128605 35.667269263714026 139.74797989195127 5.42023443 35.66726920220491 139.74797987666074 22.94244763</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p40_3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p40_3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p40_3">
											<gml:posList>35.66735699526095 139.74794923508452 8.34403801 35.667348399600655 139.74797617338865 8.34385728 35.66734840988802 139.74797617593524 5.42363419 35.66735700555229 139.74794923761885 5.42381492 35.66735699526095 139.74794923508452 8.34403801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_15645a71-e0df-4902-a1ac-05618d2db575">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a03b4c4a-6d56-4a11-bbc1-edf031c93f05">
									<gml:exterior>
										<gml:LinearRing gml:id="line_a3ea6467-80ae-425e-9da3-8060ef7219eb">
											<gml:posList>35.66726461855555 139.7482454345722 37.399992405735986 35.66726461817862 139.74824543642663 6.049024998509424 35.66744792937604 139.74809450514292 37.399992405735986 35.66726461855555 139.7482454345722 37.399992405735986</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_5458b593-8f2a-419c-9835-90c200a55d8b">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_a11a1154-cfd2-48d6-80c2-e2f2638bc541">
									<gml:exterior>
										<gml:LinearRing gml:id="line_899d5eac-0e37-48f6-98d8-7bd079c1010c">
											<gml:posList>35.6673197175112 139.74818021617514 11.276884495579736 35.66732987851348 139.7481636189275 11.276884495579736 35.66731842134189 139.74815755366072 6.049024998509424 35.66741770556413 139.74799538079301 6.049024998509424 35.66744792937604 139.74809450514292 37.399992405735986 35.66726461817862 139.74824543642663 6.049024998509424 35.667308262813144 139.74817414669047 6.049024998509424 35.6673197175112 139.74818021617514 11.276884495579736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_881cd7ae-5ae6-42eb-a152-ba893f947fb9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8784f4b0-9d08-4988-9e95-ffe70fbae890">
									<gml:exterior>
										<gml:LinearRing gml:id="line_b92a0779-05ec-407f-8013-dbe0ca3097af">
											<gml:posList>35.66698318469728 139.74787750765907 21.176886021458643 35.66698751049082 139.74786395098587 15.37688296970083 35.66698751049082 139.74786395098587 10.076925694310205 35.667002443673304 139.74781715123336 10.00481265720083 35.66700242908098 139.74781719692476 10.456694065892236 35.667005365558104 139.74780799424488 10.456724583470361 35.66700865293279 139.74779769176794 6.049024998509424 35.66691907038414 139.74807843712432 6.049024998509424 35.6669190709331 139.74807843543826 37.399992405735986 35.66698528780475 139.7478709168089 37.399992405735986 35.66699737018868 139.74783305132198 21.176886021458643 35.66698318469728 139.74787750765907 21.176886021458643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_33061977-6284-49f0-b2f1-c64108b23657">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_97e79a04-6de9-4cb5-931a-4afeeaf96d90">
									<gml:exterior>
										<gml:LinearRing gml:id="line_8d40225d-c045-425f-b7ea-a334257b4ae7">
											<gml:posList>35.667308261852284 139.74817414938826 11.276884495579736 35.6673197175112 139.74818021617514 11.276884495579736 35.667308262813144 139.74817414669047 6.049024998509424 35.667308261852284 139.74817414938826 11.276884495579736</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
					<bldg:opening>
						<bldg:Door gml:id="dor_41c11392-cfa0-4f56-9612-2dbdd615f1a6">
							<bldg:lod3MultiSurface>
								<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
									<gml:surfaceMember>
										<gml:Polygon gml:id="Poly_9cca97bd-6d52-400e-9902-71b8e53aa1fe">
											<gml:exterior>
												<gml:LinearRing gml:id="line_b475d5a2-2ff3-45f3-af4e-511f1ac30c33">
													<gml:posList>35.66731479006079 139.74815563120444 6.049024998509424 35.66731479006079 139.74815563120444 11.276884495579736 35.667308261852284 139.74817414938826 11.276884495579736 35.667308262813144 139.74817414669047 6.049024998509424 35.66731479006079 139.74815563120444 6.049024998509424</gml:posList>
												</gml:LinearRing>
											</gml:exterior>
										</gml:Polygon>
									</gml:surfaceMember>
								</gml:MultiSurface>
							</bldg:lod3MultiSurface>
						</bldg:Door>
					</bldg:opening>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_d3128e2a-7849-4aec-b2b5-f5885ab3ec97">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_799965ca-2a56-4f33-be07-28b08e1c6ef0">
									<gml:exterior>
										<gml:LinearRing gml:id="line_d6f80a3f-f51e-4d8d-a8c1-2a2fdab58e47">
											<gml:posList>35.66729216208212 139.74814808381464 32.87688296970083 35.66726197874285 139.74823371061692 32.87688296970083 35.66726197874285 139.74823371061692 37.399992405735986 35.66729216208212 139.74814808381464 37.399992405735986 35.66729216208212 139.74814808381464 32.87688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="wall_TMmnt0005_p828_1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly_TMmnt0005_p828_1">
									<gml:exterior>
										<gml:LinearRing gml:id="line_TMmnt0005_p828_1">
											<gml:posList>35.66734840988802 139.74797617593524 5.42363419 35.667348399600655 139.74797617338865 8.34385728 35.66731205610563 139.74795875837813 8.34215812 35.66731204993313 139.74795875685243 10.09715798 35.66744139500411 139.7480207362688 10.10321864 35.66744141154245 139.74802074037848 5.42799569 35.66734840988802 139.74797617593524 5.42363419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="gml_2f592a97-110e-4736-ade5-5b109eafe7c9">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_c947e9e3-31bf-41c9-9799-610cf4b1b23b">
									<gml:exterior>
										<gml:LinearRing gml:id="line_37d0c032-c6c8-4bbc-ac85-f8c2fed4c278">
											<gml:posList>35.66720012511882 139.74817408607748 11.276731907689111 35.667245545693696 139.748049831094 11.276731907689111 35.667245545693696 139.748049831094 6.049024998509424 35.66720012511882 139.74817408607748 6.049024998509424 35.66720012511882 139.74817408607748 11.276731907689111</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_06a2b3f8-3cfc-41d9-87ae-f35f647c8abe">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_782e2141-feca-4517-9479-58b2dcba14e3">
									<gml:exterior>
										<gml:LinearRing gml:id="line_fd47e45c-bdb1-40c9-97e5-f312bc364c0f">
											<gml:posList>35.66709742857257 139.74791707267994 15.37688296970083 35.66710969534587 139.74788217453425 15.37688296970083 35.667060636385436 139.7478524316639 12.599996983372705 35.66704651891001 139.74789246869594 12.599996983372705 35.66709742857257 139.74791707267994 15.37688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_56771e6d-4244-4cb1-a29e-52ab8341a615">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_9ab20746-c25f-4a42-8b24-65b456451e6e">
									<gml:exterior>
										<gml:LinearRing gml:id="line_bf719e32-9936-47b3-9b35-6040a40c1d22">
											<gml:posList>35.66704949013252 139.74784567408236 12.599996983372705 35.667002443673304 139.74781715123336 10.00481265720083 35.66698751049082 139.74786395098587 10.076925694310205 35.66703495983853 139.7478868824357 12.599996983372705 35.66704949013252 139.74784567408236 12.599996983372705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_da6697a9-8206-4c45-90d0-f0a1c5a8447f">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_29ffbaf6-d7c3-43aa-b92f-2ebab950bf11">
									<gml:exterior>
										<gml:LinearRing gml:id="line_ee375027-0912-4967-9cce-70b428f6af81">
											<gml:posList>35.66709742857257 139.74791707267994 15.37688296970083 35.667023045327475 139.74812868628794 15.37688296970083 35.66717405676283 139.74820166830622 15.37688296970083 35.667263857511195 139.74794619307502 15.37688296970083 35.66711284591951 139.74787321145678 15.37688296970083 35.66710969534587 139.74788217453425 15.37688296970083 35.66709742857257 139.74791707267994 15.37688296970083</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:OuterFloorSurface gml:id="gml_23257f36-541b-46a5-98af-c3d47a0df18a">
					<bldg:lod3MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="Poly_8934775a-60d3-4765-972e-fa989601962c">
									<gml:exterior>
										<gml:LinearRing gml:id="line_1894948b-9d8d-4795-a27b-9f1a50229dfd">
											<gml:posList>35.667060636385436 139.7478524316639 12.599996983372705 35.66704949013252 139.74784567408236 12.599996983372705 35.66703495983853 139.7478868824357 12.599996983372705 35.66704651891001 139.74789246869594 12.599996983372705 35.667060636385436 139.7478524316639 12.599996983372705</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod3MultiSurface>
				</bldg:OuterFloorSurface>
			</bldg:boundedBy>
			<bldg:lod3Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#Poly_0b4cea52-503d-45e2-babf-ce9e9bfedee5"/>
							<gml:surfaceMember xlink:href="#Poly_4f94723a-1033-437b-bfbf-920dac7cc3a6"/>
							<gml:surfaceMember xlink:href="#Poly_f8802212-e9c7-4755-ab74-21f1fa3a02d0"/>
							<gml:surfaceMember xlink:href="#Poly_5f143e68-c1b7-4d3b-a8af-bf1947fde310"/>
							<gml:surfaceMember xlink:href="#Poly_e44f42b1-f1ee-4c05-bbc9-5eab52d56a22"/>
							<gml:surfaceMember xlink:href="#Poly_600b2893-2622-48c3-8e1a-56f65506f2de"/>
							<gml:surfaceMember xlink:href="#Poly_547673a1-8f23-492f-9a32-39c39826fc64"/>
							<gml:surfaceMember xlink:href="#Poly_ed8b7871-51ab-47e2-804a-2263400cd164"/>
							<gml:surfaceMember xlink:href="#Poly_11a81eb3-50d5-4f54-bad2-03094e5d0a01"/>
							<gml:surfaceMember xlink:href="#Poly_c5fe21da-cf7f-40d3-a614-0d3c71973828"/>
							<gml:surfaceMember xlink:href="#Poly_c947e9e3-31bf-41c9-9799-610cf4b1b23b"/>
							<gml:surfaceMember xlink:href="#Poly_f970004d-e526-43fd-b789-6edad96080c4"/>
							<gml:surfaceMember xlink:href="#Poly_8b42d807-e349-443f-8ac3-6aade91c0225"/>
							<gml:surfaceMember xlink:href="#Poly_cab03f07-e636-498b-a053-5fe2234a5f96"/>
							<gml:surfaceMember xlink:href="#Poly_5dd33004-482c-4b85-a8e5-f6a354369085"/>
							<gml:surfaceMember xlink:href="#Poly_7cca25ca-ec0e-44f8-af97-c56e771820e5"/>
							<gml:surfaceMember xlink:href="#Poly_8e191dfd-f4f1-4bfc-b2e2-e808e43c6077"/>
							<gml:surfaceMember xlink:href="#Poly_8f03e157-207b-4036-8f7d-05726f82c933"/>
							<gml:surfaceMember xlink:href="#Poly_760b9788-3fad-46b2-9c29-7cee8b89eec9"/>
							<gml:surfaceMember xlink:href="#Poly_16eb7a9a-de15-466a-ac54-b1bbb1fb86e6"/>
							<gml:surfaceMember xlink:href="#Poly_899301ff-58c5-41b9-a69e-7a040342f5c5"/>
							<gml:surfaceMember xlink:href="#Poly_9cf4e99f-2d76-4957-9e1b-1156ffae15cf"/>
							<gml:surfaceMember xlink:href="#Poly_a11a1154-cfd2-48d6-80c2-e2f2638bc541"/>
							<gml:surfaceMember xlink:href="#Poly_97e79a04-6de9-4cb5-931a-4afeeaf96d90"/>
							<gml:surfaceMember xlink:href="#Poly_9cca97bd-6d52-400e-9902-71b8e53aa1fe"/>
							<gml:surfaceMember xlink:href="#Poly_6f9b4a35-75b0-4477-baec-b026fd7fe302"/>
							<gml:surfaceMember xlink:href="#Poly_f6e66d25-5f1e-4188-aaea-839ef6dffa98"/>
							<gml:surfaceMember xlink:href="#Poly_75e76511-3b23-42ac-a754-bf8ba9e23efe"/>
							<gml:surfaceMember xlink:href="#Poly_74721d90-1c28-4642-b033-3fe6be06b7c9"/>
							<gml:surfaceMember xlink:href="#Poly_f241c7f4-49b6-463a-9888-bf52b7a3b588"/>
							<gml:surfaceMember xlink:href="#Poly_f7011c5c-3cc5-4eaa-bda7-ef9362ab7eb2"/>
							<gml:surfaceMember xlink:href="#Poly_8784f4b0-9d08-4988-9e95-ffe70fbae890"/>
							<gml:surfaceMember xlink:href="#Poly_68589374-98cb-4e4b-bf13-ece76073126a"/>
							<gml:surfaceMember xlink:href="#Poly_d8a4004c-cd57-4273-b3ec-8d7e082eaf36"/>
							<gml:surfaceMember xlink:href="#Poly_9ab20746-c25f-4a42-8b24-65b456451e6e"/>
							<gml:surfaceMember xlink:href="#Poly_f169dfba-a627-4f0c-8d22-f28520253a40"/>
							<gml:surfaceMember xlink:href="#Poly_799965ca-2a56-4f33-be07-28b08e1c6ef0"/>
							<gml:surfaceMember xlink:href="#Poly_0ce65b94-bcfe-44fc-a6bd-3927004913d5"/>
							<gml:surfaceMember xlink:href="#Poly_36ecbe7e-f54d-4f05-b4e3-597e57584cee"/>
							<gml:surfaceMember xlink:href="#Poly_c91d83dc-886c-4ced-a517-d4e9306af4f1"/>
							<gml:surfaceMember xlink:href="#Poly_c5411603-9c14-41dc-afed-9abc87efd32c"/>
							<gml:surfaceMember xlink:href="#Poly_01ad5097-45eb-49ce-a94a-db95167d1d3f"/>
							<gml:surfaceMember xlink:href="#Poly_c3479b43-4317-4e01-9dc3-b084ebbecfa4"/>
							<gml:surfaceMember xlink:href="#Poly_feee8be2-b742-4cf1-9c0e-a8692d42bd9f"/>
							<gml:surfaceMember xlink:href="#Poly_d238b05e-94be-445a-8219-d506a6361147"/>
							<gml:surfaceMember xlink:href="#Poly_edf9e87a-48b5-4faa-99cc-0e6f7613ef1d"/>
							<gml:surfaceMember xlink:href="#Poly_a1f0fb62-9a10-4a10-b9f6-94a44f52f806"/>
							<gml:surfaceMember xlink:href="#Poly_9ccda471-7dd9-4d01-ac71-59a4a3e8740c"/>
							<gml:surfaceMember xlink:href="#Poly_66c1f37b-7ce5-4ef4-ab0e-7799e7aa6564"/>
							<gml:surfaceMember xlink:href="#Poly_a03b4c4a-6d56-4a11-bbc1-edf031c93f05"/>
							<gml:surfaceMember xlink:href="#Poly_0a997219-8441-4ca9-b51d-a67c91051bef"/>
							<gml:surfaceMember xlink:href="#Poly_782e2141-feca-4517-9479-58b2dcba14e3"/>
							<gml:surfaceMember xlink:href="#Poly_8934775a-60d3-4765-972e-fa989601962c"/>
							<gml:surfaceMember xlink:href="#Poly_ef910cc9-a963-432b-b5ee-f4942a76a5dd"/>
							<gml:surfaceMember xlink:href="#Poly_78e027bd-f1b9-411a-8988-981c1a9c3348"/>
							<gml:surfaceMember xlink:href="#Poly_01adcdff-639a-464d-af7e-1d909d36b62c"/>
							<gml:surfaceMember xlink:href="#Poly_4853c5bc-50a0-4c82-867d-aef5a9a69fd7"/>
							<gml:surfaceMember xlink:href="#Poly_dfeca949-04b4-4525-a5fb-9fe3bdcb4e35"/>
							<gml:surfaceMember xlink:href="#Poly_5ff5af8c-4c63-4748-acff-1daa4b67bbe8"/>
							<gml:surfaceMember xlink:href="#Poly_a3c01993-0758-48a7-b8e7-83d1625df1e8"/>
							<gml:surfaceMember xlink:href="#Poly_fb9fb56d-8baf-4d91-aecb-491d33ba6ee8"/>
							<gml:surfaceMember xlink:href="#Poly_88cf1eff-2b13-46f8-871c-900f9a137dee"/>
							<gml:surfaceMember xlink:href="#Poly_365c9ef0-7d71-469f-ae0b-c6d2709cc3e0"/>
							<gml:surfaceMember xlink:href="#Poly_467caf13-6dcf-48af-83bf-c18e00b51faf"/>
							<gml:surfaceMember xlink:href="#Poly_b6a98d49-74d5-45f1-9d63-368492024f2c"/>
							<gml:surfaceMember xlink:href="#Poly_da2409a2-7167-4b65-a197-366ad9f38724"/>
							<gml:surfaceMember xlink:href="#Poly_e0f852f8-e061-4a7a-9d3f-39d39894db96"/>
							<gml:surfaceMember xlink:href="#Poly_96781e23-a766-432b-988d-de1a3480ec34"/>
							<gml:surfaceMember xlink:href="#Poly_acfbcf0d-ce9c-48ec-8285-39dfd0d3929d"/>
							<gml:surfaceMember xlink:href="#Poly_738e50ad-b32a-404a-a7a6-676e2c781391"/>
							<gml:surfaceMember xlink:href="#Poly_eab08ecd-7ffd-408d-9c27-71c998bdec6e"/>
							<gml:surfaceMember xlink:href="#Poly_59db1634-c3e0-4e2f-899b-7480b3be57d2"/>
							<gml:surfaceMember xlink:href="#Poly_922206f7-5100-4a2b-ad36-f8cd3b076f2f"/>
							<gml:surfaceMember xlink:href="#Poly_3a1031e5-4bdb-4d66-86de-8b59b9bb418a"/>
							<gml:surfaceMember xlink:href="#Poly_b1afb1b8-5af9-45c6-b1a6-0e9d79af87ee"/>
							<gml:surfaceMember xlink:href="#Poly_de36557c-9660-48c2-b387-c1669d41b717"/>
							<gml:surfaceMember xlink:href="#Poly_bb6363f1-4aa6-4c7e-a293-f3f1fdd244ab"/>
							<gml:surfaceMember xlink:href="#Poly_276692f3-d9ea-4fa6-a58f-370b0ed1191e"/>
							<gml:surfaceMember xlink:href="#Poly_600271f5-6ee8-41ac-b383-3b903ca88108"/>
							<gml:surfaceMember xlink:href="#Poly_29ffbaf6-d7c3-43aa-b92f-2ebab950bf11"/>
							<gml:surfaceMember xlink:href="#Poly_74c36dfd-6d3b-445f-b21f-9fa6843a0a32"/>
							<gml:surfaceMember xlink:href="#Poly_5d867945-c700-41ce-8d9b-75fa70d346f1"/>
							<gml:surfaceMember xlink:href="#Poly_180f4f75-3df7-4ffd-a589-2620e3814d38"/>
							<gml:surfaceMember xlink:href="#Poly_e12001b8-5d78-4d22-98ab-b7ef55165791"/>
							<gml:surfaceMember xlink:href="#Poly_9dd72a77-452b-4206-beee-fd200e5b2162"/>
							<gml:surfaceMember xlink:href="#Poly_882612bd-c1e3-44e1-aa3a-3e88f4d2c147"/>
							<gml:surfaceMember xlink:href="#Poly_e0eef900-6dca-4b08-94bd-03146aef6f2f"/>
							<gml:surfaceMember xlink:href="#Poly_5f27c6be-d6bd-4ae8-88f3-537adfcae3e9"/>
							<gml:surfaceMember xlink:href="#Poly_bc136c04-9d34-4da9-bd5b-2be898893761"/>
							<gml:surfaceMember xlink:href="#Poly_2228111c-2d3f-4c04-8960-aee228b8f0d0"/>
							<gml:surfaceMember xlink:href="#Poly_6731c7c3-4db4-477b-bdc9-8fd21ccf26ab"/>
							<gml:surfaceMember xlink:href="#Poly_02565a50-f037-4031-8248-ce06c13ff0dc"/>
							<gml:surfaceMember xlink:href="#Poly_0713922f-827f-423d-9036-9b1b457f445c"/>
							<gml:surfaceMember xlink:href="#Poly_a5cb01b0-633b-483e-91e6-ae251ac2e09b"/>
							<gml:surfaceMember xlink:href="#Poly_ef240b46-3f65-4cde-b5d0-efc3d39c3ebb"/>
							<gml:surfaceMember xlink:href="#Poly_eccf2dfd-9852-494d-938b-5f32e0f65f13"/>
							<gml:surfaceMember xlink:href="#Poly_76e704eb-693a-440c-8118-f1def988d563"/>
							<gml:surfaceMember xlink:href="#Poly_af041bdf-cd5b-45eb-8254-86d16b43700e"/>
							<gml:surfaceMember xlink:href="#Poly_af91b592-52ab-48b4-8a74-63da2db131f3"/>
							<gml:surfaceMember xlink:href="#Poly_89030592-a9ef-4eb2-ae8c-91f559926371"/>
							<gml:surfaceMember xlink:href="#Poly_773f75ea-da2d-4827-b885-7f1a0d562ee6"/>
							<gml:surfaceMember xlink:href="#Poly_63c0e531-ed12-4650-a1e2-6d4fbb8d57c5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod3Solid>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">3</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">2</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">2</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
					<uro:lodType>3.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">9</uro:districtsAndZonesType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.06</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7000200000</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>