<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_63736c31-8d26-4d8f-aecb-287fc45c3807">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">38.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>11</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66877531006607 139.73999983921965 0 35.668741140651505 139.73996708331967 0 35.668638914363285 139.74012798821406 0 35.668650190753155 139.740139904809 0 35.66861633991277 139.7401926336509 0 35.66868750817 139.74025717023474 0 35.66886359943583 139.73997639614453 0 35.66881696464294 139.73993281856804 0 35.66877531006607 139.73999983921965 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877531006607 139.73999983921965 11.31 35.66881696464294 139.73993281856804 11.31 35.66886359943583 139.73997639614453 11.31 35.66868750817 139.74025717023474 11.31 35.66861633991277 139.7401926336509 11.31 35.668650190753155 139.740139904809 11.31 35.668638914363285 139.74012798821406 11.31 35.668741140651505 139.73996708331967 11.31 35.66877531006607 139.73999983921965 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877531006607 139.73999983921965 11.31 35.668741140651505 139.73996708331967 11.31 35.668741140651505 139.73996708331967 49.36 35.66877531006607 139.73999983921965 49.36 35.66877531006607 139.73999983921965 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668741140651505 139.73996708331967 11.31 35.668638914363285 139.74012798821406 11.31 35.668638914363285 139.74012798821406 49.36 35.668741140651505 139.73996708331967 49.36 35.668741140651505 139.73996708331967 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668638914363285 139.74012798821406 11.31 35.668650190753155 139.740139904809 11.31 35.668650190753155 139.740139904809 49.36 35.668638914363285 139.74012798821406 49.36 35.668638914363285 139.74012798821406 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668650190753155 139.740139904809 11.31 35.66861633991277 139.7401926336509 11.31 35.66861633991277 139.7401926336509 49.36 35.668650190753155 139.740139904809 49.36 35.668650190753155 139.740139904809 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66861633991277 139.7401926336509 11.31 35.66868750817 139.74025717023474 11.31 35.66868750817 139.74025717023474 49.36 35.66861633991277 139.7401926336509 49.36 35.66861633991277 139.7401926336509 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66868750817 139.74025717023474 11.31 35.66886359943583 139.73997639614453 11.31 35.66886359943583 139.73997639614453 49.36 35.66868750817 139.74025717023474 49.36 35.66868750817 139.74025717023474 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66886359943583 139.73997639614453 11.31 35.66881696464294 139.73993281856804 11.31 35.66881696464294 139.73993281856804 49.36 35.66886359943583 139.73997639614453 49.36 35.66886359943583 139.73997639614453 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66881696464294 139.73993281856804 11.31 35.66877531006607 139.73999983921965 11.31 35.66877531006607 139.73999983921965 49.36 35.66881696464294 139.73993281856804 49.36 35.66881696464294 139.73993281856804 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877531006607 139.73999983921965 49.36 35.668741140651505 139.73996708331967 49.36 35.668638914363285 139.74012798821406 49.36 35.668650190753155 139.740139904809 49.36 35.66861633991277 139.7401926336509 49.36 35.66868750817 139.74025717023474 49.36 35.66886359943583 139.73997639614453 49.36 35.66881696464294 139.73993281856804 49.36 35.66877531006607 139.73999983921965 49.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0cf269c1-4887-4f6d-bf79-4b4753f9c13f"/>
							<gml:surfaceMember xlink:href="#poly-800b69bc-7bd6-454e-9809-b51c0906ddf5"/>
							<gml:surfaceMember xlink:href="#poly-05ac1fc0-97bd-4ea5-81e8-893e515a4d66"/>
							<gml:surfaceMember xlink:href="#poly-fb53f1f1-1ba5-41ee-90a2-3ca18e3f4cb4"/>
							<gml:surfaceMember xlink:href="#poly-0fbf1f07-bc0b-4a46-90a6-e5795d415cc1"/>
							<gml:surfaceMember xlink:href="#poly-26449cb1-cf5e-4996-ae4f-8064ca3ed626"/>
							<gml:surfaceMember xlink:href="#poly-0221933a-8fa0-4d53-b674-0f65c2b39d70"/>
							<gml:surfaceMember xlink:href="#poly-b29f9ffe-00d2-42c5-aff8-dc226fd426a6"/>
							<gml:surfaceMember xlink:href="#poly-6d1b932e-0ba8-47d2-b4bd-94f4627c13d3"/>
							<gml:surfaceMember xlink:href="#poly-d9b5d654-bf38-4d45-963a-f55f266dfd62"/>
							<gml:surfaceMember xlink:href="#poly-67108731-f996-440c-b9ef-8152865b26cd"/>
							<gml:surfaceMember xlink:href="#poly-381d1299-724b-4ce1-a7db-6428be57467d"/>
							<gml:surfaceMember xlink:href="#poly-966ba6f0-cc43-412f-9ebe-6ca689ef207a"/>
							<gml:surfaceMember xlink:href="#poly-95f5c540-628a-40f5-8b9e-7dbf84a98584"/>
							<gml:surfaceMember xlink:href="#poly-a0c98371-0031-43f5-b7c6-f74075f38269"/>
							<gml:surfaceMember xlink:href="#poly-bcfbcf9e-e92e-4cc3-84b9-258c15f9936c"/>
							<gml:surfaceMember xlink:href="#poly-7386511b-3451-4092-ae7b-48d45047d023"/>
							<gml:surfaceMember xlink:href="#poly-0f7cbeeb-7775-4cd8-a507-c33b32a82724"/>
							<gml:surfaceMember xlink:href="#poly-59f02846-fdaf-43ab-bdbe-9b55c61ad327"/>
							<gml:surfaceMember xlink:href="#poly-d5734944-ecc5-4191-9289-7510e898df81"/>
							<gml:surfaceMember xlink:href="#poly-4d04adef-9b23-4ff0-865a-ff9cee4f3fec"/>
							<gml:surfaceMember xlink:href="#poly-50ce1841-8a52-4624-bc72-2ed769915511"/>
							<gml:surfaceMember xlink:href="#poly-fd113c13-6b43-4403-8429-021f38954f8a"/>
							<gml:surfaceMember xlink:href="#poly-d7ff8617-1312-4dd3-843c-d3b05d1ee197"/>
							<gml:surfaceMember xlink:href="#poly-ac390529-cdc8-44c1-810e-b4000a82da27"/>
							<gml:surfaceMember xlink:href="#poly-c1e03b76-8369-48a1-9c99-8048c6680900"/>
							<gml:surfaceMember xlink:href="#poly-e5925ae2-ae1c-4882-836b-b563eaab20ce"/>
							<gml:surfaceMember xlink:href="#poly-9604bd0f-7322-4f62-8634-4c113b3fb15c"/>
							<gml:surfaceMember xlink:href="#poly-d1234832-6244-46b0-abe0-d31a508a516f"/>
							<gml:surfaceMember xlink:href="#poly-8f747457-ec83-4dee-8974-c2cca68af07d"/>
							<gml:surfaceMember xlink:href="#poly-8999607c-cd13-4680-b37b-e67373db7d90"/>
							<gml:surfaceMember xlink:href="#poly-a053c5b3-f3e4-46ec-b681-26a86c71ee80"/>
							<gml:surfaceMember xlink:href="#poly-111e4731-374d-470a-9211-1d8c873e7f6b"/>
							<gml:surfaceMember xlink:href="#poly-6540ada6-5fec-4fb9-8119-2fd9b1ed0b77"/>
							<gml:surfaceMember xlink:href="#poly-239915e8-8bf9-4080-98f9-2c273e67b1e2"/>
							<gml:surfaceMember xlink:href="#poly-cf6f878c-8f44-4f7b-b039-91cef8838959"/>
							<gml:surfaceMember xlink:href="#poly-69304506-b9ef-433d-9c7f-ed635947b909"/>
							<gml:surfaceMember xlink:href="#poly-fec6cab0-4a4c-4044-9513-1cf649d5400a"/>
							<gml:surfaceMember xlink:href="#poly-4c5e745d-ed36-4837-96e9-5009f1f6c1da"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_63736c31-8d26-4d8f-aecb-287fc45c3807_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7f838a9-8606-4b83-810e-7f11d23be47c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66878700432125 139.73998102524743 11.31 35.66877532807637 139.73999981710662 11.31 35.66874259286328 139.7399683740146 11.31 35.668753927018656 139.73995014590474 11.31 35.66878700432125 139.73998102524743 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fd96b9f7-f3d0-44e3-a421-33fa83bee263">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668741262671624 139.7400547445003 49.634 35.66873541740518 139.74004910677752 49.634 35.668757591463724 139.74001456211812 49.634 35.66876344575404 139.74002021087546 49.634 35.668741262671624 139.7400547445003 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f35206dc-d5da-4178-b149-d5747dfcc799">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f35206dc-d5da-4178-b149-d5747dfcc799_0">
											<gml:posList>35.668753927018656 139.73995014590474 11.31 35.66874259286328 139.7399683740146 11.31 35.66874259286328 139.7399683740146 47.695 35.668748048388586 139.7399596081568 47.695 35.668753927018656 139.73995014590474 47.695 35.668753927018656 139.73995014590474 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c96d5eb-0f06-4162-9526-230de6909c9c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4c96d5eb-0f06-4162-9526-230de6909c9c_0">
											<gml:posList>35.668753927018656 139.73995014590474 11.31 35.668753927018656 139.73995014590474 47.695 35.66878700432125 139.73998102524743 45.487 35.66878700432125 139.73998102524743 11.31 35.668753927018656 139.73995014590474 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c772b76a-6851-4ba2-b424-ad4799164807">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c772b76a-6851-4ba2-b424-ad4799164807_0">
											<gml:posList>35.66878700432125 139.73998102524743 45.487 35.668753927018656 139.73995014590474 47.695 35.668748048388586 139.7399596081568 47.695 35.668781125688795 139.7399904875011 45.487 35.66878700432125 139.73998102524743 45.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d31bb0fd-a5ee-4137-a6b6-bc0428bfe101">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d31bb0fd-a5ee-4137-a6b6-bc0428bfe101_0">
											<gml:posList>35.668781125688795 139.7399904875011 45.487 35.668748048388586 139.7399596081568 47.695 35.668781125688795 139.7399904875011 49.673 35.668781125688795 139.7399904875011 45.487</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c15d9dce-6dbf-42bb-b244-5bd1efb94472">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c15d9dce-6dbf-42bb-b244-5bd1efb94472_0">
											<gml:posList>35.66877532807637 139.73999981710662 49.673 35.668781125688795 139.7399904875011 49.673 35.668748048388586 139.7399596081568 47.695 35.66874259286328 139.7399683740146 47.695 35.66877532807637 139.73999981710662 49.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c2a77d8a-1017-4e55-8b9b-43dad589f3e5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c2a77d8a-1017-4e55-8b9b-43dad589f3e5_0">
											<gml:posList>35.66877532807637 139.73999981710662 11.31 35.66877532807637 139.73999981710662 49.673 35.66874259286328 139.7399683740146 47.695 35.66874259286328 139.7399683740146 11.31 35.66877532807637 139.73999981710662 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f6e2681-f7a6-43ea-89f5-bc852941ea58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f6e2681-f7a6-43ea-89f5-bc852941ea58_0">
											<gml:posList>35.66878700432125 139.73998102524743 11.31 35.66878700432125 139.73998102524743 45.487 35.668781125688795 139.7399904875011 45.487 35.668781125688795 139.7399904875011 49.673 35.66877532807637 139.73999981710662 49.673 35.66877532807637 139.73999981710662 11.31 35.66878700432125 139.73998102524743 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aec89b41-e5b0-49ce-9075-cbcde46a09be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aec89b41-e5b0-49ce-9075-cbcde46a09be_0">
											<gml:posList>35.668757591463724 139.74001456211812 50.672 35.66876344575404 139.74002021087546 50.672 35.66876344575404 139.74002021087546 49.634 35.668757591463724 139.74001456211812 49.634 35.668757591463724 139.74001456211812 50.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0aea5ff1-2bd3-4db2-b7b2-873bc6bd89cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0aea5ff1-2bd3-4db2-b7b2-873bc6bd89cb_0">
											<gml:posList>35.668757591463724 139.74001456211812 49.634 35.66873541740518 139.74004910677752 49.634 35.66873541740518 139.74004910677752 50.672 35.668757591463724 139.74001456211812 50.672 35.668757591463724 139.74001456211812 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0869b4f-e960-4bd9-b339-74d3b1093ceb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0869b4f-e960-4bd9-b339-74d3b1093ceb_0">
											<gml:posList>35.668741262671624 139.7400547445003 50.672 35.66876344575404 139.74002021087546 50.672 35.668757591463724 139.74001456211812 50.672 35.66873541740518 139.74004910677752 50.672 35.668741262671624 139.7400547445003 50.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d31674e9-8964-4d51-b87e-3f83d50b8aa1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d31674e9-8964-4d51-b87e-3f83d50b8aa1_0">
											<gml:posList>35.66876344575404 139.74002021087546 49.634 35.66876344575404 139.74002021087546 50.672 35.668741262671624 139.7400547445003 50.672 35.668741262671624 139.7400547445003 49.634 35.66876344575404 139.74002021087546 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60358c35-d0df-4eff-8817-ddc3198a418c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60358c35-d0df-4eff-8817-ddc3198a418c_0">
											<gml:posList>35.668741262671624 139.7400547445003 50.672 35.66873541740518 139.74004910677752 50.672 35.66873541740518 139.74004910677752 49.634 35.668741262671624 139.7400547445003 49.634 35.668741262671624 139.7400547445003 50.672</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_63736c31-8d26-4d8f-aecb-287fc45c3807_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94c57cd2-b475-492d-ac09-d6ff9f67590b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66877797344773 139.74006359385461 49.634 35.668756974153574 139.74004381273932 49.634 35.66877490735164 139.74001521577367 49.634 35.66879590665042 139.7400349968859 49.634 35.66877797344773 139.74006359385461 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-612fefea-b9f1-4b2d-87d0-4b6693bc9560">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668732070828945 139.74009245530183 49.634 35.66870314198145 139.7400642994776 49.634 35.66871626831671 139.74004404788167 49.634 35.66874519716887 139.74007220370316 49.634 35.668732070828945 139.74009245530183 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e387719-e9a9-40b4-b8c4-0d4ce171bdc0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e387719-e9a9-40b4-b8c4-0d4ce171bdc0_0">
											<gml:posList>35.66879590665042 139.7400349968859 49.634 35.66877490735164 139.74001521577367 49.634 35.66877490735164 139.74001521577367 52.468 35.66879590665042 139.7400349968859 52.468 35.66879590665042 139.7400349968859 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0beeeff7-5c89-4e8b-a341-2225c2773f95">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0beeeff7-5c89-4e8b-a341-2225c2773f95_0">
											<gml:posList>35.668756974153574 139.74004381273932 49.634 35.668756974153574 139.74004381273932 52.468 35.66877490735164 139.74001521577367 52.468 35.66877490735164 139.74001521577367 49.634 35.668756974153574 139.74004381273932 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f201545-18fc-4109-84f5-50e675b4d163">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f201545-18fc-4109-84f5-50e675b4d163_0">
											<gml:posList>35.66877797344773 139.74006359385461 52.468 35.66879590665042 139.7400349968859 52.468 35.66877490735164 139.74001521577367 52.468 35.668756974153574 139.74004381273932 52.468 35.66877797344773 139.74006359385461 52.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a50076a2-e45f-4369-acb3-8afa0902568e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a50076a2-e45f-4369-acb3-8afa0902568e_0">
											<gml:posList>35.66879590665042 139.7400349968859 49.634 35.66879590665042 139.7400349968859 52.468 35.66877797344773 139.74006359385461 52.468 35.66877797344773 139.74006359385461 49.634 35.66879590665042 139.7400349968859 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e65d0590-cb88-421d-a5d1-7504969ef194">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e65d0590-cb88-421d-a5d1-7504969ef194_0">
											<gml:posList>35.668756974153574 139.74004381273932 49.634 35.66877797344773 139.74006359385461 49.634 35.66877797344773 139.74006359385461 52.468 35.668756974153574 139.74004381273932 52.468 35.668756974153574 139.74004381273932 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-557e8553-6a22-429c-b485-327241e9593c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-557e8553-6a22-429c-b485-327241e9593c_0">
											<gml:posList>35.66871626831671 139.74004404788167 49.634 35.66870314198145 139.7400642994776 49.634 35.66870314198145 139.7400642994776 52.509 35.66871626831671 139.74004404788167 52.509 35.66871626831671 139.74004404788167 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffe979d5-db5f-4b85-a42c-d722a7e9a026">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffe979d5-db5f-4b85-a42c-d722a7e9a026_0">
											<gml:posList>35.66871626831671 139.74004404788167 49.634 35.66871626831671 139.74004404788167 52.509 35.66874519716887 139.74007220370316 52.509 35.66874519716887 139.74007220370316 49.634 35.66871626831671 139.74004404788167 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c762cd9-2ec5-407f-b513-1386a79ce923">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c762cd9-2ec5-407f-b513-1386a79ce923_0">
											<gml:posList>35.668732070828945 139.74009245530183 52.509 35.66874519716887 139.74007220370316 52.509 35.66871626831671 139.74004404788167 52.509 35.66870314198145 139.7400642994776 52.509 35.668732070828945 139.74009245530183 52.509</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eda6df0f-3849-465b-9356-a7f6eb5c7a57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eda6df0f-3849-465b-9356-a7f6eb5c7a57_0">
											<gml:posList>35.66870314198145 139.7400642994776 49.634 35.668732070828945 139.74009245530183 49.634 35.668732070828945 139.74009245530183 52.509 35.66870314198145 139.7400642994776 52.509 35.66870314198145 139.7400642994776 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28034864-f080-4229-af45-0ea5f2064b9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28034864-f080-4229-af45-0ea5f2064b9d_0">
											<gml:posList>35.668732070828945 139.74009245530183 49.634 35.66874519716887 139.74007220370316 49.634 35.66874519716887 139.74007220370316 52.509 35.668732070828945 139.74009245530183 52.509 35.668732070828945 139.74009245530183 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_63736c31-8d26-4d8f-aecb-287fc45c3807_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cb7b794b-0ae8-445e-b0f6-ea3e24e515ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66876465283748 139.74004250037305 52.468 35.66877667132814 139.740023343605 52.468 35.6687880098742 139.7400340340229 52.468 35.66877600038703 139.74005317973553 52.468 35.66876465283748 139.74004250037305 52.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f46a6b6-c331-434f-a071-06c583e40d96">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668690944757856 139.7400854557606 49.634 35.668696690871656 139.7400910935982 49.634 35.6686851399378 139.74010876962592 49.634 35.66867939382482 139.74010313178783 49.634 35.668690944757856 139.7400854557606 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d748a51-e229-4b64-bea5-490c1f5d63ce">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668699216545086 139.74009345451114 49.634 35.66870495363622 139.74009908131438 49.634 35.66869341171494 139.74011675733226 49.634 35.66868766561089 139.74011113053905 49.634 35.668699216545086 139.74009345451114 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc73ce31-5125-4ed5-96d4-c58de38c0cda">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668712891709454 139.74010681535103 49.634 35.668701340773325 139.74012449138 49.634 35.66869560367481 139.74011885352917 49.634 35.66870715461013 139.74010117750063 49.634 35.668712891709454 139.74010681535103 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9dc98b66-212b-4935-ba74-d9eff2cffc48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872123564779 139.7401148692522 49.634 35.66870968471051 139.74013254528188 49.634 35.66870394762093 139.74012691847594 49.634 35.66871549854885 139.74010923140068 49.634 35.66872123564779 139.7401148692522 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9faee696-acb0-4e10-8471-e8aeff9486dd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872123564779 139.7401148692522 51.853 35.66870968471051 139.74013254528188 51.853 35.66870968471051 139.74013254528188 49.634 35.66872123564779 139.7401148692522 49.634 35.66872123564779 139.7401148692522 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91fb3658-f958-43f1-b754-c63e125e20e6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872363523976 139.74011737391157 49.634 35.6687120843021 139.74013504994141 49.634 35.6687120843021 139.74013504994141 51.853 35.66872363523976 139.74011737391157 51.853 35.66872363523976 139.74011737391157 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21bec50f-c0b9-49f4-9226-bda5165c86a7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66872363523976 139.74011737391157 49.634 35.668729372338305 139.74012301176424 49.634 35.66871783041356 139.74014068778408 49.634 35.6687120843021 139.74013504994141 49.634 35.66872363523976 139.74011737391157 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cfadf9d6-3a1c-4a6c-9209-ed1ce3c1b9a8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66867490212692 139.74014601767746 49.634 35.66866915602422 139.74014039088343 49.634 35.66868070696277 139.74012271486382 49.634 35.66868645306628 139.74012834165737 49.634 35.66867490212692 139.74014601767746 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e1491076-2ab6-4607-9ffe-1632fd913099">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869006720242 139.74012786247712 49.634 35.66869581330569 139.74013348927173 49.634 35.668684262365595 139.74015116529313 49.634 35.66867851626315 139.74014553849807 49.634 35.66869006720242 139.74012786247712 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4a404f0-32c9-4b3c-8278-741991e1fbd0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668684262365595 139.74015116529313 49.634 35.66869581330569 139.74013348927173 49.634 35.66869581330569 139.74013348927173 51.853 35.668684262365595 139.74015116529313 51.853 35.668684262365595 139.74015116529313 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09648e65-e6b9-4c99-9b12-188fa98c6fbb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66869861871153 139.7401362475178 49.634 35.66868706777105 139.74015392353942 49.634 35.66868706777105 139.74015392353942 51.853 35.66869861871153 139.7401362475178 51.853 35.66869861871153 139.7401362475178 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b577f82d-cf52-49e3-a121-5d55739c2810">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668704355809226 139.7401418853701 49.634 35.66869280486792 139.74015956139215 49.634 35.66868706777105 139.74015392353942 49.634 35.66869861871153 139.7401362475178 49.634 35.668704355809226 139.7401418853701 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-318ec227-1664-4282-ba5d-b60800d4b739">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668706962143574 139.74014364970554 49.634 35.668712699232366 139.7401492765129 49.634 35.66870114828999 139.74016695253576 49.634 35.66869541120201 139.7401613257279 49.634 35.668706962143574 139.74014364970554 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-159fa03a-a64a-4b39-a57d-d0658c84f852">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-159fa03a-a64a-4b39-a57d-d0658c84f852_0">
											<gml:posList>35.66867490212692 139.74014601767746 49.634 35.66867490212692 139.74014601767746 51.853 35.66866915602422 139.74014039088343 51.853 35.66866915602422 139.74014039088343 49.634 35.66867490212692 139.74014601767746 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebbea09e-2019-4a86-9577-47a023efafd7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebbea09e-2019-4a86-9577-47a023efafd7_0">
											<gml:posList>35.66868070696277 139.74012271486382 49.634 35.66866915602422 139.74014039088343 49.634 35.66866915602422 139.74014039088343 51.853 35.66868070696277 139.74012271486382 51.853 35.66868070696277 139.74012271486382 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fc6dc5c8-4ef5-4c32-9e41-010508520195">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fc6dc5c8-4ef5-4c32-9e41-010508520195_0">
											<gml:posList>35.66868070696277 139.74012271486382 51.853 35.66866915602422 139.74014039088343 51.853 35.66867490212692 139.74014601767746 51.853 35.66868645306628 139.74012834165737 51.853 35.66868070696277 139.74012271486382 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff7ab7d9-90c9-4683-a8d2-c76a04d5a40c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff7ab7d9-90c9-4683-a8d2-c76a04d5a40c_0">
											<gml:posList>35.66867490212692 139.74014601767746 49.634 35.66868645306628 139.74012834165737 49.634 35.66868645306628 139.74012834165737 51.853 35.66867490212692 139.74014601767746 51.853 35.66867490212692 139.74014601767746 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6db73207-cccb-491b-b94d-3ac18a1e7565">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6db73207-cccb-491b-b94d-3ac18a1e7565_0">
											<gml:posList>35.66867851626315 139.74014553849807 49.634 35.668684262365595 139.74015116529313 49.634 35.668684262365595 139.74015116529313 51.853 35.66867851626315 139.74014553849807 51.853 35.66867851626315 139.74014553849807 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dc2772bd-ed09-44b7-a200-00abedd5ae80">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dc2772bd-ed09-44b7-a200-00abedd5ae80_0">
											<gml:posList>35.66867939382482 139.74010313178783 49.634 35.6686851399378 139.74010876962592 49.634 35.6686851399378 139.74010876962592 51.853 35.66867939382482 139.74010313178783 51.853 35.66867939382482 139.74010313178783 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9ad7100-4708-47f7-a1d1-971cb44e3d97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9ad7100-4708-47f7-a1d1-971cb44e3d97_0">
											<gml:posList>35.66868070696277 139.74012271486382 49.634 35.66868070696277 139.74012271486382 51.853 35.66868645306628 139.74012834165737 51.853 35.66868645306628 139.74012834165737 49.634 35.66868070696277 139.74012271486382 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6d4bbad-3bc1-4eab-bba9-53204ec1c060">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6d4bbad-3bc1-4eab-bba9-53204ec1c060_0">
											<gml:posList>35.66869006720242 139.74012786247712 49.634 35.66867851626315 139.74014553849807 49.634 35.66867851626315 139.74014553849807 51.853 35.66869006720242 139.74012786247712 51.853 35.66869006720242 139.74012786247712 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0fd5c11-d1b2-4b4f-af05-45094cf103cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0fd5c11-d1b2-4b4f-af05-45094cf103cf_0">
											<gml:posList>35.668690944757856 139.7400854557606 51.853 35.668690944757856 139.7400854557606 49.634 35.66867939382482 139.74010313178783 49.634 35.66867939382482 139.74010313178783 51.853 35.668690944757856 139.7400854557606 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd353db1-d941-4324-acb0-3f11e35eb691">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd353db1-d941-4324-acb0-3f11e35eb691_0">
											<gml:posList>35.66869006720242 139.74012786247712 51.853 35.66867851626315 139.74014553849807 51.853 35.668684262365595 139.74015116529313 51.853 35.66869581330569 139.74013348927173 51.853 35.66869006720242 139.74012786247712 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1931e4bf-28f0-4830-bf43-844d44f5b621">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1931e4bf-28f0-4830-bf43-844d44f5b621_0">
											<gml:posList>35.668690944757856 139.7400854557606 51.853 35.66867939382482 139.74010313178783 51.853 35.6686851399378 139.74010876962592 51.853 35.668696690871656 139.7400910935982 51.853 35.668690944757856 139.7400854557606 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5968ff12-06bc-493c-b131-fd9181b0bf75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5968ff12-06bc-493c-b131-fd9181b0bf75_0">
											<gml:posList>35.66868706777105 139.74015392353942 49.634 35.66869280486792 139.74015956139215 49.634 35.66869280486792 139.74015956139215 51.853 35.66868706777105 139.74015392353942 51.853 35.66868706777105 139.74015392353942 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c6c6542-0c4e-45a7-9d8a-34d6ae88b63d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c6c6542-0c4e-45a7-9d8a-34d6ae88b63d_0">
											<gml:posList>35.66868766561089 139.74011113053905 51.853 35.66868766561089 139.74011113053905 49.634 35.66869341171494 139.74011675733226 49.634 35.66869341171494 139.74011675733226 51.853 35.66868766561089 139.74011113053905 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ef2ea3d-0971-438d-acae-49ffd92e2f79">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ef2ea3d-0971-438d-acae-49ffd92e2f79_0">
											<gml:posList>35.6686851399378 139.74010876962592 49.634 35.668696690871656 139.7400910935982 49.634 35.668696690871656 139.7400910935982 51.853 35.6686851399378 139.74010876962592 51.853 35.6686851399378 139.74010876962592 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec672ba1-0102-4b3b-b920-029725ed4547">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec672ba1-0102-4b3b-b920-029725ed4547_0">
											<gml:posList>35.66869006720242 139.74012786247712 51.853 35.66869581330569 139.74013348927173 51.853 35.66869581330569 139.74013348927173 49.634 35.66869006720242 139.74012786247712 49.634 35.66869006720242 139.74012786247712 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-29c55950-02b4-49d2-8b48-2203de80d8f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-29c55950-02b4-49d2-8b48-2203de80d8f3_0">
											<gml:posList>35.668699216545086 139.74009345451114 51.853 35.668699216545086 139.74009345451114 49.634 35.66868766561089 139.74011113053905 49.634 35.66868766561089 139.74011113053905 51.853 35.668699216545086 139.74009345451114 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20eda351-0b7d-4bdf-964a-119dc992fb25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20eda351-0b7d-4bdf-964a-119dc992fb25_0">
											<gml:posList>35.668690944757856 139.7400854557606 49.634 35.668690944757856 139.7400854557606 51.853 35.668696690871656 139.7400910935982 51.853 35.668696690871656 139.7400910935982 49.634 35.668690944757856 139.7400854557606 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0702152b-3f0f-4944-948f-460b28753eb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0702152b-3f0f-4944-948f-460b28753eb8_0">
											<gml:posList>35.668704355809226 139.7401418853701 51.853 35.66869861871153 139.7401362475178 51.853 35.66868706777105 139.74015392353942 51.853 35.66869280486792 139.74015956139215 51.853 35.668704355809226 139.7401418853701 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de8fc5e2-1e05-45d4-a938-c52b33fb9f2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de8fc5e2-1e05-45d4-a938-c52b33fb9f2e_0">
											<gml:posList>35.668699216545086 139.74009345451114 51.853 35.66868766561089 139.74011113053905 51.853 35.66869341171494 139.74011675733226 51.853 35.66870495363622 139.74009908131438 51.853 35.668699216545086 139.74009345451114 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d202b8b-b61c-4105-9caf-ca057b016245">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7d202b8b-b61c-4105-9caf-ca057b016245_0">
											<gml:posList>35.66869541120201 139.7401613257279 51.853 35.66869541120201 139.7401613257279 49.634 35.66870114828999 139.74016695253576 49.634 35.66870114828999 139.74016695253576 51.853 35.66869541120201 139.7401613257279 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a99121fb-6564-4cd2-932d-42d6971f080b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a99121fb-6564-4cd2-932d-42d6971f080b_0">
											<gml:posList>35.66869560367481 139.74011885352917 49.634 35.668701340773325 139.74012449138 49.634 35.668701340773325 139.74012449138 51.853 35.66869560367481 139.74011885352917 51.853 35.66869560367481 139.74011885352917 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ac7677c4-8351-4fe7-9cfb-7a0701476030">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ac7677c4-8351-4fe7-9cfb-7a0701476030_0">
											<gml:posList>35.668704355809226 139.7401418853701 51.853 35.66869280486792 139.74015956139215 51.853 35.66869280486792 139.74015956139215 49.634 35.668704355809226 139.7401418853701 49.634 35.668704355809226 139.7401418853701 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82ff6693-db4a-4f7a-be9b-d50098cdb264">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82ff6693-db4a-4f7a-be9b-d50098cdb264_0">
											<gml:posList>35.66869341171494 139.74011675733226 49.634 35.66870495363622 139.74009908131438 49.634 35.66870495363622 139.74009908131438 51.853 35.66869341171494 139.74011675733226 51.853 35.66869341171494 139.74011675733226 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7199362f-63ee-404e-b95b-806b97dfb17e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7199362f-63ee-404e-b95b-806b97dfb17e_0">
											<gml:posList>35.668706962143574 139.74014364970554 49.634 35.66869541120201 139.7401613257279 49.634 35.66869541120201 139.7401613257279 51.853 35.668706962143574 139.74014364970554 51.853 35.668706962143574 139.74014364970554 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d823d81-5638-4e00-9e21-67883ce0683e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d823d81-5638-4e00-9e21-67883ce0683e_0">
											<gml:posList>35.66870715461013 139.74010117750063 49.634 35.66869560367481 139.74011885352917 49.634 35.66869560367481 139.74011885352917 51.853 35.66870715461013 139.74010117750063 51.853 35.66870715461013 139.74010117750063 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ed0e2c9-022d-4e4b-89cd-c920295d81ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ed0e2c9-022d-4e4b-89cd-c920295d81ca_0">
											<gml:posList>35.668704355809226 139.7401418853701 49.634 35.66869861871153 139.7401362475178 49.634 35.66869861871153 139.7401362475178 51.853 35.668704355809226 139.7401418853701 51.853 35.668704355809226 139.7401418853701 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f360b0e1-7c03-417a-9385-6258b59f9d93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f360b0e1-7c03-417a-9385-6258b59f9d93_0">
											<gml:posList>35.668699216545086 139.74009345451114 49.634 35.668699216545086 139.74009345451114 51.853 35.66870495363622 139.74009908131438 51.853 35.66870495363622 139.74009908131438 49.634 35.668699216545086 139.74009345451114 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-873b85e5-3bd4-4100-be33-501e82d507cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-873b85e5-3bd4-4100-be33-501e82d507cf_0">
											<gml:posList>35.668706962143574 139.74014364970554 51.853 35.66869541120201 139.7401613257279 51.853 35.66870114828999 139.74016695253576 51.853 35.668712699232366 139.7401492765129 51.853 35.668706962143574 139.74014364970554 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53a8151c-f593-4664-885f-142c65a98dd4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53a8151c-f593-4664-885f-142c65a98dd4_0">
											<gml:posList>35.668712891709454 139.74010681535103 51.853 35.66870715461013 139.74010117750063 51.853 35.66869560367481 139.74011885352917 51.853 35.668701340773325 139.74012449138 51.853 35.668712891709454 139.74010681535103 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffdc0859-5136-4398-adb9-fcf593457631">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffdc0859-5136-4398-adb9-fcf593457631_0">
											<gml:posList>35.66870394762093 139.74012691847594 49.634 35.66870968471051 139.74013254528188 49.634 35.66870968471051 139.74013254528188 51.853 35.66870394762093 139.74012691847594 51.853 35.66870394762093 139.74012691847594 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5aef45c0-2770-4a8c-ad3b-1034602088c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5aef45c0-2770-4a8c-ad3b-1034602088c3_0">
											<gml:posList>35.66870114828999 139.74016695253576 51.853 35.66870114828999 139.74016695253576 49.634 35.668712699232366 139.7401492765129 49.634 35.668712699232366 139.7401492765129 51.853 35.66870114828999 139.74016695253576 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1781e03c-51f1-433f-9351-5c526529e783">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1781e03c-51f1-433f-9351-5c526529e783_0">
											<gml:posList>35.668712891709454 139.74010681535103 51.853 35.668701340773325 139.74012449138 51.853 35.668701340773325 139.74012449138 49.634 35.668712891709454 139.74010681535103 49.634 35.668712891709454 139.74010681535103 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73c44400-35a7-484c-9604-5889bfa98813">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73c44400-35a7-484c-9604-5889bfa98813_0">
											<gml:posList>35.66871549854885 139.74010923140068 49.634 35.66870394762093 139.74012691847594 49.634 35.66870394762093 139.74012691847594 51.853 35.66871549854885 139.74010923140068 51.853 35.66871549854885 139.74010923140068 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbc75a73-2db1-4d96-8539-fd5d01ea67bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bbc75a73-2db1-4d96-8539-fd5d01ea67bb_0">
											<gml:posList>35.668706962143574 139.74014364970554 49.634 35.668706962143574 139.74014364970554 51.853 35.668712699232366 139.7401492765129 51.853 35.668712699232366 139.7401492765129 49.634 35.668706962143574 139.74014364970554 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-657dece7-15d7-491a-9b63-873de631122a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-657dece7-15d7-491a-9b63-873de631122a_0">
											<gml:posList>35.668712891709454 139.74010681535103 49.634 35.66870715461013 139.74010117750063 49.634 35.66870715461013 139.74010117750063 51.853 35.668712891709454 139.74010681535103 51.853 35.668712891709454 139.74010681535103 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-164be270-6fee-4096-80ba-b3a78faa6d60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-164be270-6fee-4096-80ba-b3a78faa6d60_0">
											<gml:posList>35.66872123564779 139.7401148692522 51.853 35.66871549854885 139.74010923140068 51.853 35.66870394762093 139.74012691847594 51.853 35.66870968471051 139.74013254528188 51.853 35.66872123564779 139.7401148692522 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6ced2bd-7636-4fd7-b01b-24ad8114f77b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6ced2bd-7636-4fd7-b01b-24ad8114f77b_0">
											<gml:posList>35.6687120843021 139.74013504994141 49.634 35.66871783041356 139.74014068778408 49.634 35.66871783041356 139.74014068778408 51.853 35.6687120843021 139.74013504994141 51.853 35.6687120843021 139.74013504994141 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07d7d7ec-f921-42ec-ad5e-11a553341af5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-07d7d7ec-f921-42ec-ad5e-11a553341af5_0">
											<gml:posList>35.66872123564779 139.7401148692522 49.634 35.66871549854885 139.74010923140068 49.634 35.66871549854885 139.74010923140068 51.853 35.66872123564779 139.7401148692522 51.853 35.66872123564779 139.7401148692522 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0496d1cf-7cbe-4fd3-a995-b7f340188e2e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0496d1cf-7cbe-4fd3-a995-b7f340188e2e_0">
											<gml:posList>35.66872363523976 139.74011737391157 51.853 35.6687120843021 139.74013504994141 51.853 35.66871783041356 139.74014068778408 51.853 35.668729372338305 139.74012301176424 51.853 35.66872363523976 139.74011737391157 51.853</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b91727e3-3689-4675-b6c7-8787d56fd79d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b91727e3-3689-4675-b6c7-8787d56fd79d_0">
											<gml:posList>35.66871783041356 139.74014068778408 49.634 35.668729372338305 139.74012301176424 49.634 35.668729372338305 139.74012301176424 51.853 35.66871783041356 139.74014068778408 51.853 35.66871783041356 139.74014068778408 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2907577e-1f4b-4f52-84ce-7f1b0d11c590">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2907577e-1f4b-4f52-84ce-7f1b0d11c590_0">
											<gml:posList>35.66872363523976 139.74011737391157 49.634 35.66872363523976 139.74011737391157 51.853 35.668729372338305 139.74012301176424 51.853 35.668729372338305 139.74012301176424 49.634 35.66872363523976 139.74011737391157 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5abfe12e-14c7-4de2-9e78-470aadb814fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5abfe12e-14c7-4de2-9e78-470aadb814fa_0">
											<gml:posList>35.66877600038703 139.74005317973553 52.468 35.66877600038703 139.74005317973553 53.899 35.66876465283748 139.74004250037305 53.899 35.66876465283748 139.74004250037305 52.468 35.66877600038703 139.74005317973553 52.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b3d689d-04b2-4c82-a1c1-0063c7da761a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b3d689d-04b2-4c82-a1c1-0063c7da761a_0">
											<gml:posList>35.66876465283748 139.74004250037305 52.468 35.66876465283748 139.74004250037305 53.899 35.66877667132814 139.740023343605 53.899 35.66877667132814 139.740023343605 52.468 35.66876465283748 139.74004250037305 52.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2633e13-312b-48a9-9301-7cc2680b4bbe">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2633e13-312b-48a9-9301-7cc2680b4bbe_0">
											<gml:posList>35.66876465283748 139.74004250037305 53.899 35.66877600038703 139.74005317973553 53.899 35.6687880098742 139.7400340340229 53.899 35.66877667132814 139.740023343605 53.899 35.66876465283748 139.74004250037305 53.899</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d57cbd9a-b42d-485c-b1aa-8b90b54f82b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d57cbd9a-b42d-485c-b1aa-8b90b54f82b4_0">
											<gml:posList>35.66877600038703 139.74005317973553 52.468 35.6687880098742 139.7400340340229 52.468 35.6687880098742 139.7400340340229 53.899 35.66877600038703 139.74005317973553 53.899 35.66877600038703 139.74005317973553 52.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c02e8104-756f-49ff-a66e-df1dab0e75d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c02e8104-756f-49ff-a66e-df1dab0e75d4_0">
											<gml:posList>35.6687880098742 139.7400340340229 52.468 35.66877667132814 139.740023343605 52.468 35.66877667132814 139.740023343605 53.899 35.6687880098742 139.7400340340229 53.899 35.6687880098742 139.7400340340229 52.468</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0cf269c1-4887-4f6d-bf79-4b4753f9c13f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cf269c1-4887-4f6d-bf79-4b4753f9c13f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cf269c1-4887-4f6d-bf79-4b4753f9c13f">
											<gml:posList>35.668863599435824 139.73997639614453 11.31 35.668687508169995 139.74025717023474 11.31 35.66861633991275 139.74019263365088 11.31 35.66865019075317 139.740139904809 11.31 35.66863891436329 139.74012798821406 11.31 35.66874114065149 139.73996708331964 11.31 35.668775310066046 139.73999983921965 11.31 35.66881696464293 139.73993281856804 11.31 35.668863599435824 139.73997639614453 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-800b69bc-7bd6-454e-9809-b51c0906ddf5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-800b69bc-7bd6-454e-9809-b51c0906ddf5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-800b69bc-7bd6-454e-9809-b51c0906ddf5">
											<gml:posList>35.6686201071629 139.74019199965184 49.972 35.66865228357878 139.74014202321268 49.972 35.66865019075317 139.740139904809 49.972 35.66861633991275 139.74019263365088 49.972 35.6686201071629 139.74019199965184 49.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-05ac1fc0-97bd-4ea5-81e8-893e515a4d66">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05ac1fc0-97bd-4ea5-81e8-893e515a4d66">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05ac1fc0-97bd-4ea5-81e8-893e515a4d66">
											<gml:posList>35.66865019075317 139.740139904809 54.121 35.66865253163733 139.74013643363756 54.121 35.66864395256544 139.7401273748265 54.121 35.66863891436329 139.74012798821406 54.121 35.66865019075317 139.740139904809 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb53f1f1-1ba5-41ee-90a2-3ca18e3f4cb4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb53f1f1-1ba5-41ee-90a2-3ca18e3f4cb4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb53f1f1-1ba5-41ee-90a2-3ca18e3f4cb4">
											<gml:posList>35.668687508169995 139.74025717023474 49.972 35.668686990895495 139.7402526530105 49.972 35.6686201071629 139.74019199965184 49.972 35.66861633991275 139.74019263365088 49.972 35.668687508169995 139.74025717023474 49.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0fbf1f07-bc0b-4a46-90a6-e5795d415cc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0fbf1f07-bc0b-4a46-90a6-e5795d415cc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0fbf1f07-bc0b-4a46-90a6-e5795d415cc1">
											<gml:posList>35.66863891436329 139.74012798821406 54.121 35.66864395256544 139.7401273748265 54.121 35.668708304312204 139.74002611839626 54.121 35.66870765942451 139.74001977872607 54.121 35.66863891436329 139.74012798821406 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26449cb1-cf5e-4996-ae4f-8064ca3ed626">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26449cb1-cf5e-4996-ae4f-8064ca3ed626">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26449cb1-cf5e-4996-ae4f-8064ca3ed626">
											<gml:posList>35.66865019075317 139.740139904809 54.121 35.6687061828902 139.7401966384113 54.121 35.66870560102212 139.74019018820638 54.121 35.66865253163733 139.74013643363756 54.121 35.66865019075317 139.740139904809 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0221933a-8fa0-4d53-b674-0f65c2b39d70">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0221933a-8fa0-4d53-b674-0f65c2b39d70">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0221933a-8fa0-4d53-b674-0f65c2b39d70">
											<gml:posList>35.668686990895495 139.7402526530105 46.955 35.6688177270108 139.74004419494304 46.955 35.66880771445039 139.74003475117968 46.955 35.6687061828902 139.7401966384113 46.955 35.66865228357878 139.74014202321268 46.955 35.6686201071629 139.74019199965184 46.955 35.668686990895495 139.7402526530105 46.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b29f9ffe-00d2-42c5-aff8-dc226fd426a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b29f9ffe-00d2-42c5-aff8-dc226fd426a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b29f9ffe-00d2-42c5-aff8-dc226fd426a6">
											<gml:posList>35.66873358418748 139.74004467945122 54.121 35.66870765942451 139.74001977872607 54.121 35.668708304312204 139.74002611839626 54.121 35.6687341930104 139.7400510081196 54.121 35.66873358418748 139.74004467945122 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6d1b932e-0ba8-47d2-b4bd-94f4627c13d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d1b932e-0ba8-47d2-b4bd-94f4627c13d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d1b932e-0ba8-47d2-b4bd-94f4627c13d3">
											<gml:posList>35.66880417970938 139.74003299897194 49.634 35.66876782772394 139.73999862181907 49.634 35.6687341930104 139.7400510081196 49.634 35.668708304312204 139.74002611839626 49.634 35.66864395256544 139.7401273748265 49.634 35.66865253163733 139.74013643363756 49.634 35.66870560102212 139.74019018820638 49.634 35.66880417970938 139.74003299897194 49.634</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d9b5d654-bf38-4d45-963a-f55f266dfd62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d9b5d654-bf38-4d45-963a-f55f266dfd62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d9b5d654-bf38-4d45-963a-f55f266dfd62">
											<gml:posList>35.66870765942451 139.74001977872607 54.121 35.66873358418748 139.74004467945122 54.121 35.668767326934535 139.73999212733213 54.121 35.66874115865325 139.73996705016057 54.121 35.66870765942451 139.74001977872607 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67108731-f996-440c-b9ef-8152865b26cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67108731-f996-440c-b9ef-8152865b26cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67108731-f996-440c-b9ef-8152865b26cd">
											<gml:posList>35.66873358418748 139.74004467945122 54.121 35.6687341930104 139.7400510081196 54.121 35.66876782772394 139.73999862181907 54.121 35.668767326934535 139.73999212733213 54.121 35.66873358418748 139.74004467945122 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-381d1299-724b-4ce1-a7db-6428be57467d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-381d1299-724b-4ce1-a7db-6428be57467d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-381d1299-724b-4ce1-a7db-6428be57467d">
											<gml:posList>35.668821287166864 139.74004384837355 49.972 35.6688177270108 139.74004419494304 49.972 35.668686990895495 139.7402526530105 49.972 35.668687508169995 139.74025717023474 49.972 35.668821287166864 139.74004384837355 49.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-966ba6f0-cc43-412f-9ebe-6ca689ef207a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-966ba6f0-cc43-412f-9ebe-6ca689ef207a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-966ba6f0-cc43-412f-9ebe-6ca689ef207a">
											<gml:posList>35.668809244883604 139.74003229717738 54.121 35.66880417970938 139.74003299897194 54.121 35.66870560102212 139.74019018820638 54.121 35.6687061828902 139.7401966384113 54.121 35.668809244883604 139.74003229717738 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-95f5c540-628a-40f5-8b9e-7dbf84a98584">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95f5c540-628a-40f5-8b9e-7dbf84a98584">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95f5c540-628a-40f5-8b9e-7dbf84a98584">
											<gml:posList>35.668767326934535 139.73999212733213 54.121 35.66876782772394 139.73999862181907 54.121 35.66880417970938 139.74003299897194 54.121 35.668809244883604 139.74003229717738 54.121 35.668767326934535 139.73999212733213 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a0c98371-0031-43f5-b7c6-f74075f38269">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a0c98371-0031-43f5-b7c6-f74075f38269">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a0c98371-0031-43f5-b7c6-f74075f38269">
											<gml:posList>35.6688177270108 139.74004419494304 49.972 35.668821287166864 139.74004384837355 49.972 35.66880924489216 139.7400323082234 49.972 35.66880771445039 139.74003475117968 49.972 35.6688177270108 139.74004419494304 49.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bcfbcf9e-e92e-4cc3-84b9-258c15f9936c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bcfbcf9e-e92e-4cc3-84b9-258c15f9936c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bcfbcf9e-e92e-4cc3-84b9-258c15f9936c">
											<gml:posList>35.66882127816169 139.74004385943005 41.943 35.668863599435824 139.73997639614453 41.943 35.66881696464293 139.73993281856804 41.943 35.66877532807637 139.73999981710662 41.943 35.66882127816169 139.74004385943005 41.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7386511b-3451-4092-ae7b-48d45047d023">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7386511b-3451-4092-ae7b-48d45047d023">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7386511b-3451-4092-ae7b-48d45047d023">
											<gml:posList>35.6687341930104 139.7400510081196 54.121 35.6687341930104 139.7400510081196 49.634 35.66876782772394 139.73999862181907 49.634 35.66876782772394 139.73999862181907 54.121 35.6687341930104 139.7400510081196 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f7cbeeb-7775-4cd8-a507-c33b32a82724">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f7cbeeb-7775-4cd8-a507-c33b32a82724">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f7cbeeb-7775-4cd8-a507-c33b32a82724">
											<gml:posList>35.66864395256544 139.7401273748265 54.121 35.66864395256544 139.7401273748265 49.634 35.668708304312204 139.74002611839626 49.634 35.668708304312204 139.74002611839626 54.121 35.66864395256544 139.7401273748265 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-59f02846-fdaf-43ab-bdbe-9b55c61ad327">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59f02846-fdaf-43ab-bdbe-9b55c61ad327">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59f02846-fdaf-43ab-bdbe-9b55c61ad327">
											<gml:posList>35.66880417970938 139.74003299897194 54.121 35.66880417970938 139.74003299897194 49.634 35.66870560102212 139.74019018820638 49.634 35.66870560102212 139.74019018820638 54.121 35.66880417970938 139.74003299897194 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5734944-ecc5-4191-9289-7510e898df81">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5734944-ecc5-4191-9289-7510e898df81">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5734944-ecc5-4191-9289-7510e898df81">
											<gml:posList>35.668863599435824 139.73997639614453 11.31 35.66881696464293 139.73993281856804 11.31 35.66881696464293 139.73993281856804 41.943 35.668863599435824 139.73997639614453 41.943 35.668863599435824 139.73997639614453 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4d04adef-9b23-4ff0-865a-ff9cee4f3fec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4d04adef-9b23-4ff0-865a-ff9cee4f3fec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4d04adef-9b23-4ff0-865a-ff9cee4f3fec">
											<gml:posList>35.66881696464293 139.73993281856804 11.31 35.668775310066046 139.73999983921965 11.31 35.66877532807637 139.73999981710662 41.943 35.66881696464293 139.73993281856804 41.943 35.66881696464293 139.73993281856804 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50ce1841-8a52-4624-bc72-2ed769915511">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50ce1841-8a52-4624-bc72-2ed769915511">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50ce1841-8a52-4624-bc72-2ed769915511">
											<gml:posList>35.66874114065149 139.73996708331964 11.31 35.66874115865325 139.73996705016057 54.121 35.66877532807637 139.73999981710662 41.943 35.668775310066046 139.73999983921965 11.31 35.66874114065149 139.73996708331964 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd113c13-6b43-4403-8429-021f38954f8a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd113c13-6b43-4403-8429-021f38954f8a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd113c13-6b43-4403-8429-021f38954f8a">
											<gml:posList>35.668767326934535 139.73999212733213 54.121 35.668809244883604 139.74003229717738 54.121 35.66880924489216 139.7400323082234 49.972 35.66877532807637 139.73999981710662 41.943 35.66874115865325 139.73996705016057 54.121 35.668767326934535 139.73999212733213 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7ff8617-1312-4dd3-843c-d3b05d1ee197">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7ff8617-1312-4dd3-843c-d3b05d1ee197">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7ff8617-1312-4dd3-843c-d3b05d1ee197">
											<gml:posList>35.66876782772394 139.73999862181907 54.121 35.66876782772394 139.73999862181907 49.634 35.66880417970938 139.74003299897194 49.634 35.66880417970938 139.74003299897194 54.121 35.66876782772394 139.73999862181907 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac390529-cdc8-44c1-810e-b4000a82da27">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac390529-cdc8-44c1-810e-b4000a82da27">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac390529-cdc8-44c1-810e-b4000a82da27">
											<gml:posList>35.66880924489216 139.7400323082234 49.972 35.668821287166864 139.74004384837355 49.972 35.66882127816169 139.74004385943005 41.943 35.66877532807637 139.73999981710662 41.943 35.66880924489216 139.7400323082234 49.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c1e03b76-8369-48a1-9c99-8048c6680900">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c1e03b76-8369-48a1-9c99-8048c6680900">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c1e03b76-8369-48a1-9c99-8048c6680900">
											<gml:posList>35.668708304312204 139.74002611839626 54.121 35.668708304312204 139.74002611839626 49.634 35.6687341930104 139.7400510081196 49.634 35.6687341930104 139.7400510081196 54.121 35.668708304312204 139.74002611839626 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e5925ae2-ae1c-4882-836b-b563eaab20ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5925ae2-ae1c-4882-836b-b563eaab20ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5925ae2-ae1c-4882-836b-b563eaab20ce">
											<gml:posList>35.66880771445039 139.74003475117968 49.972 35.66880771445039 139.74003475117968 46.955 35.6688177270108 139.74004419494304 46.955 35.6688177270108 139.74004419494304 49.972 35.66880771445039 139.74003475117968 49.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9604bd0f-7322-4f62-8634-4c113b3fb15c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9604bd0f-7322-4f62-8634-4c113b3fb15c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9604bd0f-7322-4f62-8634-4c113b3fb15c">
											<gml:posList>35.66874114065149 139.73996708331964 11.31 35.66863891436329 139.74012798821406 11.31 35.66863891436329 139.74012798821406 54.121 35.66870765942451 139.74001977872607 54.121 35.66874115865325 139.73996705016057 54.121 35.66874114065149 139.73996708331964 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1234832-6244-46b0-abe0-d31a508a516f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1234832-6244-46b0-abe0-d31a508a516f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1234832-6244-46b0-abe0-d31a508a516f">
											<gml:posList>35.668809244883604 139.74003229717738 54.121 35.6687061828902 139.7401966384113 54.121 35.6687061828902 139.7401966384113 46.955 35.66880771445039 139.74003475117968 46.955 35.66880771445039 139.74003475117968 49.972 35.66880924489216 139.7400323082234 49.972 35.668809244883604 139.74003229717738 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f747457-ec83-4dee-8974-c2cca68af07d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f747457-ec83-4dee-8974-c2cca68af07d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f747457-ec83-4dee-8974-c2cca68af07d">
											<gml:posList>35.668687508169995 139.74025717023474 49.972 35.668687508169995 139.74025717023474 11.31 35.668863599435824 139.73997639614453 11.31 35.668863599435824 139.73997639614453 41.943 35.66882127816169 139.74004385943005 41.943 35.668821287166864 139.74004384837355 49.972 35.668687508169995 139.74025717023474 49.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8999607c-cd13-4680-b37b-e67373db7d90">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8999607c-cd13-4680-b37b-e67373db7d90">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8999607c-cd13-4680-b37b-e67373db7d90">
											<gml:posList>35.66865253163733 139.74013643363756 54.121 35.66865253163733 139.74013643363756 49.634 35.66864395256544 139.7401273748265 49.634 35.66864395256544 139.7401273748265 54.121 35.66865253163733 139.74013643363756 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a053c5b3-f3e4-46ec-b681-26a86c71ee80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a053c5b3-f3e4-46ec-b681-26a86c71ee80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a053c5b3-f3e4-46ec-b681-26a86c71ee80">
											<gml:posList>35.66863891436329 139.74012798821406 54.121 35.66863891436329 139.74012798821406 11.31 35.66865019075317 139.740139904809 11.31 35.66865019075317 139.740139904809 49.972 35.66865019075317 139.740139904809 54.121 35.66863891436329 139.74012798821406 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-111e4731-374d-470a-9211-1d8c873e7f6b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-111e4731-374d-470a-9211-1d8c873e7f6b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-111e4731-374d-470a-9211-1d8c873e7f6b">
											<gml:posList>35.6688177270108 139.74004419494304 49.972 35.6688177270108 139.74004419494304 46.955 35.668686990895495 139.7402526530105 46.955 35.668686990895495 139.7402526530105 49.972 35.6688177270108 139.74004419494304 49.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6540ada6-5fec-4fb9-8119-2fd9b1ed0b77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6540ada6-5fec-4fb9-8119-2fd9b1ed0b77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6540ada6-5fec-4fb9-8119-2fd9b1ed0b77">
											<gml:posList>35.66870560102212 139.74019018820638 54.121 35.66870560102212 139.74019018820638 49.634 35.66865253163733 139.74013643363756 49.634 35.66865253163733 139.74013643363756 54.121 35.66870560102212 139.74019018820638 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-239915e8-8bf9-4080-98f9-2c273e67b1e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-239915e8-8bf9-4080-98f9-2c273e67b1e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-239915e8-8bf9-4080-98f9-2c273e67b1e2">
											<gml:posList>35.66865019075317 139.740139904809 11.31 35.66861633991275 139.74019263365088 11.31 35.66861633991275 139.74019263365088 49.972 35.66865019075317 139.740139904809 49.972 35.66865019075317 139.740139904809 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf6f878c-8f44-4f7b-b039-91cef8838959">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf6f878c-8f44-4f7b-b039-91cef8838959">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf6f878c-8f44-4f7b-b039-91cef8838959">
											<gml:posList>35.6686201071629 139.74019199965184 49.972 35.6686201071629 139.74019199965184 46.955 35.66865228357878 139.74014202321268 46.955 35.66865228357878 139.74014202321268 49.972 35.6686201071629 139.74019199965184 49.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-69304506-b9ef-433d-9c7f-ed635947b909">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69304506-b9ef-433d-9c7f-ed635947b909">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69304506-b9ef-433d-9c7f-ed635947b909">
											<gml:posList>35.66865019075317 139.740139904809 54.121 35.66865019075317 139.740139904809 49.972 35.66865228357878 139.74014202321268 49.972 35.66865228357878 139.74014202321268 46.955 35.6687061828902 139.7401966384113 46.955 35.6687061828902 139.7401966384113 54.121 35.66865019075317 139.740139904809 54.121</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fec6cab0-4a4c-4044-9513-1cf649d5400a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fec6cab0-4a4c-4044-9513-1cf649d5400a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fec6cab0-4a4c-4044-9513-1cf649d5400a">
											<gml:posList>35.668686990895495 139.7402526530105 49.972 35.668686990895495 139.7402526530105 46.955 35.6686201071629 139.74019199965184 46.955 35.6686201071629 139.74019199965184 49.972 35.668686990895495 139.7402526530105 49.972</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c5e745d-ed36-4837-96e9-5009f1f6c1da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c5e745d-ed36-4837-96e9-5009f1f6c1da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c5e745d-ed36-4837-96e9-5009f1f6c1da">
											<gml:posList>35.66861633991275 139.74019263365088 11.31 35.668687508169995 139.74025717023474 11.31 35.668687508169995 139.74025717023474 49.972 35.66861633991275 139.74019263365088 49.972 35.66861633991275 139.74019263365088 11.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-6098</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">318.08955</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.07</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>