<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_63b436c0-ffac-4ce9-b7b2-4188b4efc399">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>29</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103029002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">9</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66697977688288 139.73773971805628 0 35.666963475539355 139.73775674800376 0 35.66695842206568 139.73774946380712 0 35.6669204156068 139.7377891634702 0 35.66697465013175 139.73786730304275 0 35.667064802980896 139.73777319593376 0 35.667060471483055 139.73776701544662 0 35.6670946962023 139.7377324012835 0 35.66708097928772 139.73771220381457 0 35.667046574475016 139.73774703911104 0 35.667040889250714 139.73773876153868 0 35.66709672813223 139.7376804835689 0 35.66704249357502 139.7376024544621 0 35.667026552536804 139.73761915264683 0 35.667001646110776 139.7375832835463 0 35.666925903350915 139.73766224088143 0 35.66697977688288 139.73773971805628 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66697977688288 139.73773971805628 16.965 35.666925903350915 139.73766224088143 16.965 35.667001646110776 139.7375832835463 16.965 35.667026552536804 139.73761915264683 16.965 35.66704249357502 139.7376024544621 16.965 35.66709672813223 139.7376804835689 16.965 35.667040889250714 139.73773876153868 16.965 35.667046574475016 139.73774703911104 16.965 35.66708097928772 139.73771220381457 16.965 35.6670946962023 139.7377324012835 16.965 35.667060471483055 139.73776701544662 16.965 35.667064802980896 139.73777319593376 16.965 35.66697465013175 139.73786730304275 16.965 35.6669204156068 139.7377891634702 16.965 35.66695842206568 139.73774946380712 16.965 35.666963475539355 139.73775674800376 16.965 35.66697977688288 139.73773971805628 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66697977688288 139.73773971805628 16.965 35.666963475539355 139.73775674800376 16.965 35.666963475539355 139.73775674800376 26 35.66697977688288 139.73773971805628 26 35.66697977688288 139.73773971805628 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666963475539355 139.73775674800376 16.965 35.66695842206568 139.73774946380712 16.965 35.66695842206568 139.73774946380712 26 35.666963475539355 139.73775674800376 26 35.666963475539355 139.73775674800376 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66695842206568 139.73774946380712 16.965 35.6669204156068 139.7377891634702 16.965 35.6669204156068 139.7377891634702 26 35.66695842206568 139.73774946380712 26 35.66695842206568 139.73774946380712 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6669204156068 139.7377891634702 16.965 35.66697465013175 139.73786730304275 16.965 35.66697465013175 139.73786730304275 26 35.6669204156068 139.7377891634702 26 35.6669204156068 139.7377891634702 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66697465013175 139.73786730304275 16.965 35.667064802980896 139.73777319593376 16.965 35.667064802980896 139.73777319593376 26 35.66697465013175 139.73786730304275 26 35.66697465013175 139.73786730304275 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667064802980896 139.73777319593376 16.965 35.667060471483055 139.73776701544662 16.965 35.667060471483055 139.73776701544662 26 35.667064802980896 139.73777319593376 26 35.667064802980896 139.73777319593376 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667060471483055 139.73776701544662 16.965 35.6670946962023 139.7377324012835 16.965 35.6670946962023 139.7377324012835 26 35.667060471483055 139.73776701544662 26 35.667060471483055 139.73776701544662 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6670946962023 139.7377324012835 16.965 35.66708097928772 139.73771220381457 16.965 35.66708097928772 139.73771220381457 26 35.6670946962023 139.7377324012835 26 35.6670946962023 139.7377324012835 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66708097928772 139.73771220381457 16.965 35.667046574475016 139.73774703911104 16.965 35.667046574475016 139.73774703911104 26 35.66708097928772 139.73771220381457 26 35.66708097928772 139.73771220381457 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667046574475016 139.73774703911104 16.965 35.667040889250714 139.73773876153868 16.965 35.667040889250714 139.73773876153868 26 35.667046574475016 139.73774703911104 26 35.667046574475016 139.73774703911104 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667040889250714 139.73773876153868 16.965 35.66709672813223 139.7376804835689 16.965 35.66709672813223 139.7376804835689 26 35.667040889250714 139.73773876153868 26 35.667040889250714 139.73773876153868 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66709672813223 139.7376804835689 16.965 35.66704249357502 139.7376024544621 16.965 35.66704249357502 139.7376024544621 26 35.66709672813223 139.7376804835689 26 35.66709672813223 139.7376804835689 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66704249357502 139.7376024544621 16.965 35.667026552536804 139.73761915264683 16.965 35.667026552536804 139.73761915264683 26 35.66704249357502 139.7376024544621 26 35.66704249357502 139.7376024544621 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667026552536804 139.73761915264683 16.965 35.667001646110776 139.7375832835463 16.965 35.667001646110776 139.7375832835463 26 35.667026552536804 139.73761915264683 26 35.667026552536804 139.73761915264683 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667001646110776 139.7375832835463 16.965 35.666925903350915 139.73766224088143 16.965 35.666925903350915 139.73766224088143 26 35.667001646110776 139.7375832835463 26 35.667001646110776 139.7375832835463 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666925903350915 139.73766224088143 16.965 35.66697977688288 139.73773971805628 16.965 35.66697977688288 139.73773971805628 26 35.666925903350915 139.73766224088143 26 35.666925903350915 139.73766224088143 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66697977688288 139.73773971805628 26 35.666963475539355 139.73775674800376 26 35.66695842206568 139.73774946380712 26 35.6669204156068 139.7377891634702 26 35.66697465013175 139.73786730304275 26 35.667064802980896 139.73777319593376 26 35.667060471483055 139.73776701544662 26 35.6670946962023 139.7377324012835 26 35.66708097928772 139.73771220381457 26 35.667046574475016 139.73774703911104 26 35.667040889250714 139.73773876153868 26 35.66709672813223 139.7376804835689 26 35.66704249357502 139.7376024544621 26 35.667026552536804 139.73761915264683 26 35.667001646110776 139.7375832835463 26 35.666925903350915 139.73766224088143 26 35.66697977688288 139.73773971805628 26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-984c1e9c-cccb-4e61-b281-50a9c2ce868c"/>
							<gml:surfaceMember xlink:href="#poly-83ed6ddb-3b88-4c28-ab75-6424ad7ff4c1"/>
							<gml:surfaceMember xlink:href="#poly-2fffd57d-33fa-43f1-a5d1-9798ab7378aa"/>
							<gml:surfaceMember xlink:href="#poly-bc19c0bb-f6ba-4ab8-ae89-4ce8dc114e45"/>
							<gml:surfaceMember xlink:href="#poly-e7d2b828-3f76-4b23-a58f-288cc5fdb7dd"/>
							<gml:surfaceMember xlink:href="#poly-c898be53-91a3-405b-af46-84d02e23c64f"/>
							<gml:surfaceMember xlink:href="#poly-16ccb5ee-248e-4cd4-9502-fdca9e79a314"/>
							<gml:surfaceMember xlink:href="#poly-40ea0473-5224-4420-90f7-aa45d993804b"/>
							<gml:surfaceMember xlink:href="#poly-918acb68-1eee-417a-8ef9-10a14528ad04"/>
							<gml:surfaceMember xlink:href="#poly-e129cf85-b703-4503-9914-e7142c27de8e"/>
							<gml:surfaceMember xlink:href="#poly-429bc80f-e4ac-4021-aa4d-3c2b90d81747"/>
							<gml:surfaceMember xlink:href="#poly-2681d966-2996-4a76-b7cb-4632b95f2899"/>
							<gml:surfaceMember xlink:href="#poly-e94ff7cc-904d-4f51-8e9c-9737fbaaa37c"/>
							<gml:surfaceMember xlink:href="#poly-1a165ec3-5936-464c-b915-47f4c18ee513"/>
							<gml:surfaceMember xlink:href="#poly-a1adaf56-e075-4941-9a5c-fff26b8fcf0d"/>
							<gml:surfaceMember xlink:href="#poly-fe9649b0-9744-4b2b-a6a5-e3acd0537388"/>
							<gml:surfaceMember xlink:href="#poly-60bafed5-dfc2-4d68-b83b-223ac574b37f"/>
							<gml:surfaceMember xlink:href="#poly-99cf592a-33a2-4f1a-b37f-ea3305ed9a11"/>
							<gml:surfaceMember xlink:href="#poly-ead07c95-2ff9-4cd4-9165-5f154861e63a"/>
							<gml:surfaceMember xlink:href="#poly-398e3b64-9da9-467c-a981-721a83b59c04"/>
							<gml:surfaceMember xlink:href="#poly-2ad55d6b-196e-4a15-89dc-c0bb1eeff820"/>
							<gml:surfaceMember xlink:href="#poly-892da8ab-9e14-4f63-a9d1-b9ff5d07161a"/>
							<gml:surfaceMember xlink:href="#poly-6e7cf036-c0a7-4500-9e6f-54997572beb6"/>
							<gml:surfaceMember xlink:href="#poly-f500cd58-344d-4dfc-871a-8e6f980972a9"/>
							<gml:surfaceMember xlink:href="#poly-45aff750-5466-4c4d-b8bc-3efa42e4e907"/>
							<gml:surfaceMember xlink:href="#poly-d7f5fd88-8160-4784-b024-a62509162bb9"/>
							<gml:surfaceMember xlink:href="#poly-4c4a13d3-acc5-4124-9bc3-76d2ffaf3701"/>
							<gml:surfaceMember xlink:href="#poly-6ae66f4d-0907-4843-be78-c5323a963972"/>
							<gml:surfaceMember xlink:href="#poly-7e9e1beb-7610-46f1-8181-c555bdd381d8"/>
							<gml:surfaceMember xlink:href="#poly-7dc04183-6ab9-403c-8187-a2142ac9b1c8"/>
							<gml:surfaceMember xlink:href="#poly-1b663f0f-b492-46ca-9ed3-1cea7e1d48dc"/>
							<gml:surfaceMember xlink:href="#poly-8f2d0b7d-2418-4de0-b4fe-6296cdec06b9"/>
							<gml:surfaceMember xlink:href="#poly-898fb3ec-1a1d-4bc7-baee-2fbfca28bef7"/>
							<gml:surfaceMember xlink:href="#poly-cb597905-9bae-4023-8cb3-1e263a348b75"/>
							<gml:surfaceMember xlink:href="#poly-aac437b1-817d-40f9-b5d0-adb92384d33a"/>
							<gml:surfaceMember xlink:href="#poly-4ca0364c-2a2b-4933-9d16-231ac7f5ad1c"/>
							<gml:surfaceMember xlink:href="#poly-1a699eca-af62-41d9-aed9-91bc13617c63"/>
							<gml:surfaceMember xlink:href="#poly-4a4c79b3-d1c0-418a-9984-5212597288b4"/>
							<gml:surfaceMember xlink:href="#poly-aa90b22a-6414-40a9-9529-912fee761ad3"/>
							<gml:surfaceMember xlink:href="#poly-7a39ca69-5cc3-4ba3-b628-e1552ba4b5f3"/>
							<gml:surfaceMember xlink:href="#poly-7fdbc3e0-3d4d-40c7-b680-768193fc2b49"/>
							<gml:surfaceMember xlink:href="#poly-4149c163-85ac-4729-83d5-34df06d01ed2"/>
							<gml:surfaceMember xlink:href="#poly-83d53b34-a2f3-483d-b890-6ab84e29413f"/>
							<gml:surfaceMember xlink:href="#poly-ca8e34d6-7c6a-4db2-bca6-df53bd1e9a2c"/>
							<gml:surfaceMember xlink:href="#poly-2723a0d7-98d4-4de1-94e2-66e67ef4d824"/>
							<gml:surfaceMember xlink:href="#poly-9cfc3aee-6821-4a97-a4a3-49756bb35c4e"/>
							<gml:surfaceMember xlink:href="#poly-9ef6bfd6-42a0-4c93-b519-0bcf63ead055"/>
							<gml:surfaceMember xlink:href="#poly-8ef52495-af5e-4581-a734-1937f9bbb0a3"/>
							<gml:surfaceMember xlink:href="#poly-7eb79bd4-f000-4188-85e2-525a440eb9fc"/>
							<gml:surfaceMember xlink:href="#poly-25d37148-8ed0-4376-a428-a83d11cb0fec"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-984c1e9c-cccb-4e61-b281-50a9c2ce868c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-984c1e9c-cccb-4e61-b281-50a9c2ce868c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-984c1e9c-cccb-4e61-b281-50a9c2ce868c">
											<gml:posList>35.66702655253681 139.7376191526468 16.965 35.66704249357498 139.7376024544621 16.965 35.66709672813223 139.73768048356888 16.965 35.66704088925072 139.73773876153868 16.965 35.667046574475016 139.73774703911104 16.965 35.66708097928771 139.73771220381454 16.965 35.667094696202284 139.7377324012835 16.965 35.66706047148305 139.73776701544662 16.965 35.667064802980896 139.73777319593376 16.965 35.666974650131756 139.73786730304275 16.965 35.6669204156068 139.7377891634702 16.965 35.66695842206565 139.73774946380712 16.965 35.66696347553935 139.73775674800376 16.965 35.66697977688285 139.73773971805628 16.965 35.66692590335092 139.73766224088143 16.965 35.66700164611077 139.7375832835463 16.965 35.66702655253681 139.7376191526468 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83ed6ddb-3b88-4c28-ab75-6424ad7ff4c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83ed6ddb-3b88-4c28-ab75-6424ad7ff4c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83ed6ddb-3b88-4c28-ab75-6424ad7ff4c1">
											<gml:posList>35.66702655253681 139.7376191526468 26.288 35.66700164611077 139.7375832835463 26.288 35.66700151266145 139.73758549286438 26.288 35.66702558889332 139.73762019210199 26.288 35.66702655253681 139.7376191526468 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2fffd57d-33fa-43f1-a5d1-9798ab7378aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2fffd57d-33fa-43f1-a5d1-9798ab7378aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2fffd57d-33fa-43f1-a5d1-9798ab7378aa">
											<gml:posList>35.66692590335092 139.73766224088143 26.288 35.66692771525049 139.7376624154522 26.288 35.66700151266145 139.73758549286438 26.288 35.66700164611077 139.7375832835463 26.288 35.66692590335092 139.73766224088143 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc19c0bb-f6ba-4ab8-ae89-4ce8dc114e45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc19c0bb-f6ba-4ab8-ae89-4ce8dc114e45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc19c0bb-f6ba-4ab8-ae89-4ce8dc114e45">
											<gml:posList>35.66708273239035 139.73769509177225 22.673 35.66709672813223 139.73768048356888 22.673 35.66704249357498 139.7376024544621 22.673 35.66702655253681 139.7376191526468 22.673 35.66708273239035 139.73769509177225 22.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e7d2b828-3f76-4b23-a58f-288cc5fdb7dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e7d2b828-3f76-4b23-a58f-288cc5fdb7dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e7d2b828-3f76-4b23-a58f-288cc5fdb7dd">
											<gml:posList>35.66702655253681 139.7376191526468 26.288 35.66702558889332 139.73762019210199 26.288 35.66708090248097 139.73769493931346 26.288 35.66708273239035 139.73769509177225 26.288 35.66702655253681 139.7376191526468 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c898be53-91a3-405b-af46-84d02e23c64f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c898be53-91a3-405b-af46-84d02e23c64f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c898be53-91a3-405b-af46-84d02e23c64f">
											<gml:posList>35.66700545676 139.7377734654815 25.985 35.66704005903204 139.7377375585363 25.985 35.66708090248097 139.73769493931346 25.985 35.66702558889332 139.73762019210199 25.985 35.66700151266145 139.73758549286438 25.985 35.66692771525049 139.7376624154522 25.985 35.66698074954112 139.7377386785924 25.985 35.6669976060426 139.73776241799825 25.985 35.66700545676 139.7377734654815 25.985</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-16ccb5ee-248e-4cd4-9502-fdca9e79a314">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16ccb5ee-248e-4cd4-9502-fdca9e79a314">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16ccb5ee-248e-4cd4-9502-fdca9e79a314">
											<gml:posList>35.66697977688285 139.73773971805628 26.288 35.66698074954112 139.7377386785924 26.288 35.66692771525049 139.7376624154522 26.288 35.66692590335092 139.73766224088143 26.288 35.66697977688285 139.73773971805628 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-40ea0473-5224-4420-90f7-aa45d993804b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40ea0473-5224-4420-90f7-aa45d993804b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40ea0473-5224-4420-90f7-aa45d993804b">
											<gml:posList>35.66704088925072 139.73773876153868 26.288 35.66708273239035 139.73769509177225 26.288 35.66708090248097 139.73769493931346 26.288 35.66704005903204 139.7377375585363 26.288 35.66704088925072 139.73773876153868 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-918acb68-1eee-417a-8ef9-10a14528ad04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-918acb68-1eee-417a-8ef9-10a14528ad04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-918acb68-1eee-417a-8ef9-10a14528ad04">
											<gml:posList>35.66708097928771 139.73771220381454 21.311 35.667046574475016 139.73774703911104 21.311 35.66705765709631 139.73776436780844 21.311 35.66705269422928 139.7377803901344 21.311 35.66705488707167 139.73778354662045 21.311 35.667064802980896 139.73777319593376 21.311 35.66706047148305 139.73776701544662 21.311 35.667094696202284 139.7377324012835 21.311 35.66708097928771 139.73771220381454 21.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e129cf85-b703-4503-9914-e7142c27de8e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e129cf85-b703-4503-9914-e7142c27de8e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e129cf85-b703-4503-9914-e7142c27de8e">
											<gml:posList>35.66699664239785 139.7377634574513 26.288 35.6669976060426 139.73776241799825 26.288 35.66698074954112 139.7377386785924 26.288 35.66697977688285 139.73773971805628 26.288 35.66699664239785 139.7377634574513 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-429bc80f-e4ac-4021-aa4d-3c2b90d81747">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-429bc80f-e4ac-4021-aa4d-3c2b90d81747">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-429bc80f-e4ac-4021-aa4d-3c2b90d81747">
											<gml:posList>35.66704088925072 139.73773876153868 26.288 35.66704005903204 139.7377375585363 26.288 35.66700545676 139.7377734654815 26.288 35.66700531429347 139.7377756748101 26.288 35.66704088925072 139.73773876153868 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2681d966-2996-4a76-b7cb-4632b95f2899">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2681d966-2996-4a76-b7cb-4632b95f2899">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2681d966-2996-4a76-b7cb-4632b95f2899">
											<gml:posList>35.666978511360846 139.73778061108155 22.148 35.66699664239785 139.7377634574513 22.148 35.66697977688285 139.73773971805628 22.148 35.66696347553935 139.73775674800376 22.148 35.666978511360846 139.73778061108155 22.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e94ff7cc-904d-4f51-8e9c-9737fbaaa37c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e94ff7cc-904d-4f51-8e9c-9737fbaaa37c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e94ff7cc-904d-4f51-8e9c-9737fbaaa37c">
											<gml:posList>35.66699664239785 139.7377634574513 26.288 35.66700531429347 139.7377756748101 26.288 35.66700545676 139.7377734654815 26.288 35.6669976060426 139.73776241799825 26.288 35.66699664239785 139.7377634574513 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1a165ec3-5936-464c-b915-47f4c18ee513">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a165ec3-5936-464c-b915-47f4c18ee513">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a165ec3-5936-464c-b915-47f4c18ee513">
											<gml:posList>35.66704753795288 139.73779122116278 23.275 35.66705488707167 139.73778354662045 23.275 35.66705269422928 139.7377803901344 23.275 35.66705765709631 139.73776436780844 23.275 35.66705320780585 139.73775741425666 23.275 35.667036312018645 139.73777503035188 23.275 35.66704753795288 139.73779122116278 23.275</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a1adaf56-e075-4941-9a5c-fff26b8fcf0d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a1adaf56-e075-4941-9a5c-fff26b8fcf0d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a1adaf56-e075-4941-9a5c-fff26b8fcf0d">
											<gml:posList>35.6669204156068 139.7377891634702 27.68 35.666974650131756 139.73786730304275 27.68 35.66704753795288 139.73779122116278 27.68 35.66703630300492 139.73777503036263 27.68 35.66705320780585 139.73775741425666 27.68 35.667046574475016 139.73774703911104 27.68 35.66704088925072 139.73773876153868 27.68 35.66700531429347 139.7377756748101 27.68 35.66699664239785 139.7377634574513 27.68 35.666978511360846 139.73778061108155 27.68 35.66696347553935 139.73775674800376 27.68 35.66695842206565 139.73774946380712 27.68 35.6669204156068 139.7377891634702 27.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fe9649b0-9744-4b2b-a6a5-e3acd0537388">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe9649b0-9744-4b2b-a6a5-e3acd0537388">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe9649b0-9744-4b2b-a6a5-e3acd0537388">
											<gml:posList>35.66700164611077 139.7375832835463 26.288 35.66702655253681 139.7376191526468 26.288 35.66702655253681 139.7376191526468 22.673 35.66702655253681 139.7376191526468 16.965 35.66700164611077 139.7375832835463 16.965 35.66700164611077 139.7375832835463 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60bafed5-dfc2-4d68-b83b-223ac574b37f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60bafed5-dfc2-4d68-b83b-223ac574b37f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60bafed5-dfc2-4d68-b83b-223ac574b37f">
											<gml:posList>35.66700151266145 139.73758549286438 26.288 35.66700151266145 139.73758549286438 25.985 35.66702558889332 139.73762019210199 25.985 35.66702558889332 139.73762019210199 26.288 35.66700151266145 139.73758549286438 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-99cf592a-33a2-4f1a-b37f-ea3305ed9a11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99cf592a-33a2-4f1a-b37f-ea3305ed9a11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99cf592a-33a2-4f1a-b37f-ea3305ed9a11">
											<gml:posList>35.66704249357498 139.7376024544621 16.965 35.66702655253681 139.7376191526468 16.965 35.66702655253681 139.7376191526468 22.673 35.66704249357498 139.7376024544621 22.673 35.66704249357498 139.7376024544621 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ead07c95-2ff9-4cd4-9165-5f154861e63a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ead07c95-2ff9-4cd4-9165-5f154861e63a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ead07c95-2ff9-4cd4-9165-5f154861e63a">
											<gml:posList>35.66700164611077 139.7375832835463 16.965 35.66692590335092 139.73766224088143 16.965 35.66692590335092 139.73766224088143 26.288 35.66700164611077 139.7375832835463 26.288 35.66700164611077 139.7375832835463 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-398e3b64-9da9-467c-a981-721a83b59c04">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-398e3b64-9da9-467c-a981-721a83b59c04">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-398e3b64-9da9-467c-a981-721a83b59c04">
											<gml:posList>35.66692771525049 139.7376624154522 26.288 35.66692771525049 139.7376624154522 25.985 35.66700151266145 139.73758549286438 25.985 35.66700151266145 139.73758549286438 26.288 35.66692771525049 139.7376624154522 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ad55d6b-196e-4a15-89dc-c0bb1eeff820">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ad55d6b-196e-4a15-89dc-c0bb1eeff820">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ad55d6b-196e-4a15-89dc-c0bb1eeff820">
											<gml:posList>35.66709672813223 139.73768048356888 16.965 35.66704249357498 139.7376024544621 16.965 35.66704249357498 139.7376024544621 22.673 35.66709672813223 139.73768048356888 22.673 35.66709672813223 139.73768048356888 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-892da8ab-9e14-4f63-a9d1-b9ff5d07161a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-892da8ab-9e14-4f63-a9d1-b9ff5d07161a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-892da8ab-9e14-4f63-a9d1-b9ff5d07161a">
											<gml:posList>35.66702655253681 139.7376191526468 22.673 35.66702655253681 139.7376191526468 26.288 35.66708273239035 139.73769509177225 26.288 35.66708273239035 139.73769509177225 22.673 35.66702655253681 139.7376191526468 22.673</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6e7cf036-c0a7-4500-9e6f-54997572beb6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e7cf036-c0a7-4500-9e6f-54997572beb6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e7cf036-c0a7-4500-9e6f-54997572beb6">
											<gml:posList>35.66702558889332 139.73762019210199 26.288 35.66702558889332 139.73762019210199 25.985 35.66708090248097 139.73769493931346 25.985 35.66708090248097 139.73769493931346 26.288 35.66702558889332 139.73762019210199 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f500cd58-344d-4dfc-871a-8e6f980972a9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f500cd58-344d-4dfc-871a-8e6f980972a9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f500cd58-344d-4dfc-871a-8e6f980972a9">
											<gml:posList>35.66698074954112 139.7377386785924 26.288 35.66698074954112 139.7377386785924 25.985 35.66692771525049 139.7376624154522 25.985 35.66692771525049 139.7376624154522 26.288 35.66698074954112 139.7377386785924 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45aff750-5466-4c4d-b8bc-3efa42e4e907">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45aff750-5466-4c4d-b8bc-3efa42e4e907">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45aff750-5466-4c4d-b8bc-3efa42e4e907">
											<gml:posList>35.66692590335092 139.73766224088143 26.288 35.66692590335092 139.73766224088143 16.965 35.66697977688285 139.73773971805628 16.965 35.66697977688285 139.73773971805628 22.148 35.66697977688285 139.73773971805628 26.288 35.66692590335092 139.73766224088143 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d7f5fd88-8160-4784-b024-a62509162bb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d7f5fd88-8160-4784-b024-a62509162bb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d7f5fd88-8160-4784-b024-a62509162bb9">
											<gml:posList>35.66704088925072 139.73773876153868 16.965 35.66709672813223 139.73768048356888 16.965 35.66709672813223 139.73768048356888 22.673 35.66708273239035 139.73769509177225 22.673 35.66708273239035 139.73769509177225 26.288 35.66704088925072 139.73773876153868 26.288 35.66704088925072 139.73773876153868 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c4a13d3-acc5-4124-9bc3-76d2ffaf3701">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c4a13d3-acc5-4124-9bc3-76d2ffaf3701">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c4a13d3-acc5-4124-9bc3-76d2ffaf3701">
											<gml:posList>35.66708090248097 139.73769493931346 26.288 35.66708090248097 139.73769493931346 25.985 35.66704005903204 139.7377375585363 25.985 35.66704005903204 139.7377375585363 26.288 35.66708090248097 139.73769493931346 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6ae66f4d-0907-4843-be78-c5323a963972">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6ae66f4d-0907-4843-be78-c5323a963972">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6ae66f4d-0907-4843-be78-c5323a963972">
											<gml:posList>35.667094696202284 139.7377324012835 16.965 35.66708097928771 139.73771220381454 16.965 35.66708097928771 139.73771220381454 21.311 35.667094696202284 139.7377324012835 21.311 35.667094696202284 139.7377324012835 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7e9e1beb-7610-46f1-8181-c555bdd381d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7e9e1beb-7610-46f1-8181-c555bdd381d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7e9e1beb-7610-46f1-8181-c555bdd381d8">
											<gml:posList>35.66708097928771 139.73771220381454 16.965 35.667046574475016 139.73774703911104 16.965 35.667046574475016 139.73774703911104 21.311 35.66708097928771 139.73771220381454 21.311 35.66708097928771 139.73771220381454 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7dc04183-6ab9-403c-8187-a2142ac9b1c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dc04183-6ab9-403c-8187-a2142ac9b1c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dc04183-6ab9-403c-8187-a2142ac9b1c8">
											<gml:posList>35.66704088925072 139.73773876153868 26.288 35.66704088925072 139.73773876153868 27.68 35.667046574475016 139.73774703911104 27.68 35.667046574475016 139.73774703911104 21.311 35.667046574475016 139.73774703911104 16.965 35.66704088925072 139.73773876153868 16.965 35.66704088925072 139.73773876153868 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b663f0f-b492-46ca-9ed3-1cea7e1d48dc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b663f0f-b492-46ca-9ed3-1cea7e1d48dc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b663f0f-b492-46ca-9ed3-1cea7e1d48dc">
											<gml:posList>35.66697977688285 139.73773971805628 16.965 35.66696347553935 139.73775674800376 16.965 35.66696347553935 139.73775674800376 22.148 35.66697977688285 139.73773971805628 22.148 35.66697977688285 139.73773971805628 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f2d0b7d-2418-4de0-b4fe-6296cdec06b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f2d0b7d-2418-4de0-b4fe-6296cdec06b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f2d0b7d-2418-4de0-b4fe-6296cdec06b9">
											<gml:posList>35.66706047148305 139.73776701544662 16.965 35.667094696202284 139.7377324012835 16.965 35.667094696202284 139.7377324012835 21.311 35.66706047148305 139.73776701544662 21.311 35.66706047148305 139.73776701544662 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-898fb3ec-1a1d-4bc7-baee-2fbfca28bef7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-898fb3ec-1a1d-4bc7-baee-2fbfca28bef7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-898fb3ec-1a1d-4bc7-baee-2fbfca28bef7">
											<gml:posList>35.6669976060426 139.73776241799825 26.288 35.6669976060426 139.73776241799825 25.985 35.66698074954112 139.7377386785924 25.985 35.66698074954112 139.7377386785924 26.288 35.6669976060426 139.73776241799825 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cb597905-9bae-4023-8cb3-1e263a348b75">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cb597905-9bae-4023-8cb3-1e263a348b75">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cb597905-9bae-4023-8cb3-1e263a348b75">
											<gml:posList>35.66699664239785 139.7377634574513 22.148 35.66699664239785 139.7377634574513 26.288 35.66697977688285 139.73773971805628 26.288 35.66697977688285 139.73773971805628 22.148 35.66699664239785 139.7377634574513 22.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aac437b1-817d-40f9-b5d0-adb92384d33a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aac437b1-817d-40f9-b5d0-adb92384d33a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aac437b1-817d-40f9-b5d0-adb92384d33a">
											<gml:posList>35.66695842206565 139.73774946380712 16.965 35.66695842206565 139.73774946380712 27.68 35.66696347553935 139.73775674800376 27.68 35.66696347553935 139.73775674800376 22.148 35.66696347553935 139.73775674800376 16.965 35.66695842206565 139.73774946380712 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ca0364c-2a2b-4933-9d16-231ac7f5ad1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ca0364c-2a2b-4933-9d16-231ac7f5ad1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ca0364c-2a2b-4933-9d16-231ac7f5ad1c">
											<gml:posList>35.66704005903204 139.7377375585363 26.288 35.66704005903204 139.7377375585363 25.985 35.66700545676 139.7377734654815 25.985 35.66700545676 139.7377734654815 26.288 35.66704005903204 139.7377375585363 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a699eca-af62-41d9-aed9-91bc13617c63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a699eca-af62-41d9-aed9-91bc13617c63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a699eca-af62-41d9-aed9-91bc13617c63">
											<gml:posList>35.667046574475016 139.73774703911104 21.311 35.667046574475016 139.73774703911104 27.68 35.66705320780585 139.73775741425666 27.68 35.66705320780585 139.73775741425666 23.275 35.66705765709631 139.73776436780844 23.275 35.66705765709631 139.73776436780844 21.311 35.667046574475016 139.73774703911104 21.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4a4c79b3-d1c0-418a-9984-5212597288b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4a4c79b3-d1c0-418a-9984-5212597288b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4a4c79b3-d1c0-418a-9984-5212597288b4">
											<gml:posList>35.66704088925072 139.73773876153868 26.288 35.66700531429347 139.7377756748101 26.288 35.66700531429347 139.7377756748101 27.68 35.66704088925072 139.73773876153868 27.68 35.66704088925072 139.73773876153868 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aa90b22a-6414-40a9-9529-912fee761ad3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa90b22a-6414-40a9-9529-912fee761ad3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa90b22a-6414-40a9-9529-912fee761ad3">
											<gml:posList>35.66705320780585 139.73775741425666 27.68 35.66703630300492 139.73777503036263 27.68 35.667036312018645 139.73777503035188 23.275 35.66705320780585 139.73775741425666 23.275 35.66705320780585 139.73775741425666 27.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7a39ca69-5cc3-4ba3-b628-e1552ba4b5f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a39ca69-5cc3-4ba3-b628-e1552ba4b5f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a39ca69-5cc3-4ba3-b628-e1552ba4b5f3">
											<gml:posList>35.66700545676 139.7377734654815 26.288 35.66700545676 139.7377734654815 25.985 35.6669976060426 139.73776241799825 25.985 35.6669976060426 139.73776241799825 26.288 35.66700545676 139.7377734654815 26.288</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7fdbc3e0-3d4d-40c7-b680-768193fc2b49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7fdbc3e0-3d4d-40c7-b680-768193fc2b49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7fdbc3e0-3d4d-40c7-b680-768193fc2b49">
											<gml:posList>35.66696347553935 139.73775674800376 27.68 35.666978511360846 139.73778061108155 27.68 35.666978511360846 139.73778061108155 22.148 35.66696347553935 139.73775674800376 22.148 35.66696347553935 139.73775674800376 27.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4149c163-85ac-4729-83d5-34df06d01ed2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4149c163-85ac-4729-83d5-34df06d01ed2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4149c163-85ac-4729-83d5-34df06d01ed2">
											<gml:posList>35.6669204156068 139.7377891634702 27.68 35.66695842206565 139.73774946380712 27.68 35.66695842206565 139.73774946380712 16.965 35.6669204156068 139.7377891634702 16.965 35.6669204156068 139.7377891634702 27.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-83d53b34-a2f3-483d-b890-6ab84e29413f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83d53b34-a2f3-483d-b890-6ab84e29413f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83d53b34-a2f3-483d-b890-6ab84e29413f">
											<gml:posList>35.66699664239785 139.7377634574513 27.68 35.66700531429347 139.7377756748101 27.68 35.66700531429347 139.7377756748101 26.288 35.66699664239785 139.7377634574513 26.288 35.66699664239785 139.7377634574513 27.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ca8e34d6-7c6a-4db2-bca6-df53bd1e9a2c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ca8e34d6-7c6a-4db2-bca6-df53bd1e9a2c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ca8e34d6-7c6a-4db2-bca6-df53bd1e9a2c">
											<gml:posList>35.667064802980896 139.73777319593376 16.965 35.66706047148305 139.73776701544662 16.965 35.66706047148305 139.73776701544662 21.311 35.667064802980896 139.73777319593376 21.311 35.667064802980896 139.73777319593376 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2723a0d7-98d4-4de1-94e2-66e67ef4d824">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2723a0d7-98d4-4de1-94e2-66e67ef4d824">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2723a0d7-98d4-4de1-94e2-66e67ef4d824">
											<gml:posList>35.666978511360846 139.73778061108155 22.148 35.666978511360846 139.73778061108155 27.68 35.66699664239785 139.7377634574513 27.68 35.66699664239785 139.7377634574513 26.288 35.66699664239785 139.7377634574513 22.148 35.666978511360846 139.73778061108155 22.148</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9cfc3aee-6821-4a97-a4a3-49756bb35c4e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9cfc3aee-6821-4a97-a4a3-49756bb35c4e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9cfc3aee-6821-4a97-a4a3-49756bb35c4e">
											<gml:posList>35.66705765709631 139.73776436780844 21.311 35.66705765709631 139.73776436780844 23.275 35.66705269422928 139.7377803901344 23.275 35.66705269422928 139.7377803901344 21.311 35.66705765709631 139.73776436780844 21.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9ef6bfd6-42a0-4c93-b519-0bcf63ead055">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9ef6bfd6-42a0-4c93-b519-0bcf63ead055">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9ef6bfd6-42a0-4c93-b519-0bcf63ead055">
											<gml:posList>35.66705269422928 139.7377803901344 21.311 35.66705269422928 139.7377803901344 23.275 35.66705488707167 139.73778354662045 23.275 35.66705488707167 139.73778354662045 21.311 35.66705269422928 139.7377803901344 21.311</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ef52495-af5e-4581-a734-1937f9bbb0a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ef52495-af5e-4581-a734-1937f9bbb0a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ef52495-af5e-4581-a734-1937f9bbb0a3">
											<gml:posList>35.66703630300492 139.73777503036263 27.68 35.66704753795288 139.73779122116278 27.68 35.66704753795288 139.73779122116278 23.275 35.667036312018645 139.73777503035188 23.275 35.66703630300492 139.73777503036263 27.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7eb79bd4-f000-4188-85e2-525a440eb9fc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7eb79bd4-f000-4188-85e2-525a440eb9fc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7eb79bd4-f000-4188-85e2-525a440eb9fc">
											<gml:posList>35.66704753795288 139.73779122116278 23.275 35.66704753795288 139.73779122116278 27.68 35.666974650131756 139.73786730304275 27.68 35.666974650131756 139.73786730304275 16.965 35.667064802980896 139.73777319593376 16.965 35.667064802980896 139.73777319593376 21.311 35.66705488707167 139.73778354662045 21.311 35.66705488707167 139.73778354662045 23.275 35.66704753795288 139.73779122116278 23.275</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25d37148-8ed0-4376-a428-a83d11cb0fec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25d37148-8ed0-4376-a428-a83d11cb0fec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25d37148-8ed0-4376-a428-a83d11cb0fec">
											<gml:posList>35.6669204156068 139.7377891634702 16.965 35.666974650131756 139.73786730304275 16.965 35.666974650131756 139.73786730304275 27.68 35.6669204156068 139.7377891634702 27.68 35.6669204156068 139.7377891634702 16.965</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区六本木二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7780</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">275.5222</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">5</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>3</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">2</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">105</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key105.xml">3</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">20</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>