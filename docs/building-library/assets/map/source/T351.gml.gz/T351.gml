<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_65e2477b-2c3b-4dce-9cf7-8fe5906b27b1">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:measuredHeight uom="m">13.1</bldg:measuredHeight>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67084581475069 139.74417018884034 0 35.670825250129674 139.74416437925248 0 35.670774369437055 139.744435026351 0 35.670794943058986 139.7444408359946 0 35.67084581475069 139.74417018884034 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67084581475069 139.74417018884034 7.26 35.670794943058986 139.7444408359946 7.26 35.670774369437055 139.744435026351 7.26 35.670825250129674 139.74416437925248 7.26 35.67084581475069 139.74417018884034 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67084581475069 139.74417018884034 7.26 35.670825250129674 139.74416437925248 7.26 35.670825250129674 139.74416437925248 20.4 35.67084581475069 139.74417018884034 20.4 35.67084581475069 139.74417018884034 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670825250129674 139.74416437925248 7.26 35.670774369437055 139.744435026351 7.26 35.670774369437055 139.744435026351 20.4 35.670825250129674 139.74416437925248 20.4 35.670825250129674 139.74416437925248 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670774369437055 139.744435026351 7.26 35.670794943058986 139.7444408359946 7.26 35.670794943058986 139.7444408359946 20.4 35.670774369437055 139.744435026351 20.4 35.670774369437055 139.744435026351 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670794943058986 139.7444408359946 7.26 35.67084581475069 139.74417018884034 7.26 35.67084581475069 139.74417018884034 20.4 35.670794943058986 139.7444408359946 20.4 35.670794943058986 139.7444408359946 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67084581475069 139.74417018884034 20.4 35.670825250129674 139.74416437925248 20.4 35.670774369437055 139.744435026351 20.4 35.670794943058986 139.7444408359946 20.4 35.67084581475069 139.74417018884034 20.4</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-78c3ea39-df66-42b8-874d-3cf6c0d06b6d"/>
							<gml:surfaceMember xlink:href="#poly-0d05f4c8-a94c-48ce-8fb3-c42c8ed36f68"/>
							<gml:surfaceMember xlink:href="#poly-4be9bcfe-9a54-493f-aed4-adb3cfa850e0"/>
							<gml:surfaceMember xlink:href="#poly-0488371f-d715-4fae-800d-b6996a4d3384"/>
							<gml:surfaceMember xlink:href="#poly-dae8afa9-146e-4b6e-9fe0-c7603d6f15de"/>
							<gml:surfaceMember xlink:href="#poly-4603fc05-c8e3-46bd-a28f-fdad19faa620"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-78c3ea39-df66-42b8-874d-3cf6c0d06b6d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78c3ea39-df66-42b8-874d-3cf6c0d06b6d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78c3ea39-df66-42b8-874d-3cf6c0d06b6d">
											<gml:posList>35.67084581475066 139.74417018884034 7.26 35.670794943058986 139.7444408359946 7.26 35.670774369437055 139.74443502635097 7.26 35.67082525012968 139.7441643792525 7.26 35.67084581475066 139.74417018884034 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0d05f4c8-a94c-48ce-8fb3-c42c8ed36f68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d05f4c8-a94c-48ce-8fb3-c42c8ed36f68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d05f4c8-a94c-48ce-8fb3-c42c8ed36f68">
											<gml:posList>35.670774369437055 139.74443502635097 20.737 35.670794943058986 139.7444408359946 20.737 35.67084581475066 139.74417018884034 20.737 35.67082525012968 139.7441643792525 20.737 35.670774369437055 139.74443502635097 20.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4be9bcfe-9a54-493f-aed4-adb3cfa850e0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4be9bcfe-9a54-493f-aed4-adb3cfa850e0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4be9bcfe-9a54-493f-aed4-adb3cfa850e0">
											<gml:posList>35.670794943058986 139.7444408359946 7.26 35.67084581475066 139.74417018884034 7.26 35.67084581475066 139.74417018884034 20.737 35.670794943058986 139.7444408359946 20.737 35.670794943058986 139.7444408359946 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0488371f-d715-4fae-800d-b6996a4d3384">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0488371f-d715-4fae-800d-b6996a4d3384">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0488371f-d715-4fae-800d-b6996a4d3384">
											<gml:posList>35.67084581475066 139.74417018884034 7.26 35.67082525012968 139.7441643792525 7.26 35.67082525012968 139.7441643792525 20.737 35.67084581475066 139.74417018884034 20.737 35.67084581475066 139.74417018884034 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dae8afa9-146e-4b6e-9fe0-c7603d6f15de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dae8afa9-146e-4b6e-9fe0-c7603d6f15de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dae8afa9-146e-4b6e-9fe0-c7603d6f15de">
											<gml:posList>35.67082525012968 139.7441643792525 7.26 35.670774369437055 139.74443502635097 7.26 35.670774369437055 139.74443502635097 20.737 35.67082525012968 139.7441643792525 20.737 35.67082525012968 139.7441643792525 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4603fc05-c8e3-46bd-a28f-fdad19faa620">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4603fc05-c8e3-46bd-a28f-fdad19faa620">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4603fc05-c8e3-46bd-a28f-fdad19faa620">
											<gml:posList>35.670774369437055 139.74443502635097 7.26 35.670794943058986 139.7444408359946 7.26 35.670794943058986 139.7444408359946 20.737 35.670774369437055 139.74443502635097 20.737 35.670774369437055 139.74443502635097 7.26</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10436</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">215</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.2</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>