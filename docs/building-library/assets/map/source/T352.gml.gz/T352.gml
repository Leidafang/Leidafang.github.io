<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6625cec6-bd40-47e2-a8ac-343770be9ec4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>3</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018003</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">21.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66734737136638 139.74594446247625 0 35.66720889911547 139.74584069428187 0 35.66720621134559 139.74585079309648 0 35.66717286507743 139.7458322504106 0 35.66709482595315 139.7460956234325 0 35.66725930786808 139.74619419420858 0 35.66734737136638 139.74594446247625 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66734737136638 139.74594446247625 7.47 35.66725930786808 139.74619419420858 7.47 35.66709482595315 139.7460956234325 7.47 35.66717286507743 139.7458322504106 7.47 35.66720621134559 139.74585079309648 7.47 35.66720889911547 139.74584069428187 7.47 35.66734737136638 139.74594446247625 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66734737136638 139.74594446247625 7.47 35.66720889911547 139.74584069428187 7.47 35.66720889911547 139.74584069428187 29.2 35.66734737136638 139.74594446247625 29.2 35.66734737136638 139.74594446247625 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66720889911547 139.74584069428187 7.47 35.66720621134559 139.74585079309648 7.47 35.66720621134559 139.74585079309648 29.2 35.66720889911547 139.74584069428187 29.2 35.66720889911547 139.74584069428187 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66720621134559 139.74585079309648 7.47 35.66717286507743 139.7458322504106 7.47 35.66717286507743 139.7458322504106 29.2 35.66720621134559 139.74585079309648 29.2 35.66720621134559 139.74585079309648 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66717286507743 139.7458322504106 7.47 35.66709482595315 139.7460956234325 7.47 35.66709482595315 139.7460956234325 29.2 35.66717286507743 139.7458322504106 29.2 35.66717286507743 139.7458322504106 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66709482595315 139.7460956234325 7.47 35.66725930786808 139.74619419420858 7.47 35.66725930786808 139.74619419420858 29.2 35.66709482595315 139.7460956234325 29.2 35.66709482595315 139.7460956234325 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66725930786808 139.74619419420858 7.47 35.66734737136638 139.74594446247625 7.47 35.66734737136638 139.74594446247625 29.2 35.66725930786808 139.74619419420858 29.2 35.66725930786808 139.74619419420858 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66734737136638 139.74594446247625 29.2 35.66720889911547 139.74584069428187 29.2 35.66720621134559 139.74585079309648 29.2 35.66717286507743 139.7458322504106 29.2 35.66709482595315 139.7460956234325 29.2 35.66725930786808 139.74619419420858 29.2 35.66734737136638 139.74594446247625 29.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-0cdb6252-912a-4168-bfcf-ba7dd6580f5f"/>
							<gml:surfaceMember xlink:href="#poly-ed592c99-d04a-40de-90d8-fd27fd4395be"/>
							<gml:surfaceMember xlink:href="#poly-8bc77de9-c570-4d70-a295-14ef91f37fa8"/>
							<gml:surfaceMember xlink:href="#poly-08aec548-eb76-4b08-9250-cb891186ced4"/>
							<gml:surfaceMember xlink:href="#poly-ec572ee9-15e6-4577-97e0-5c29e7944ace"/>
							<gml:surfaceMember xlink:href="#poly-861aa56d-2188-4056-9a34-9dd3cc4a2ad4"/>
							<gml:surfaceMember xlink:href="#poly-89a84fd4-bbe6-4751-9180-06ed53cc07fb"/>
							<gml:surfaceMember xlink:href="#poly-e5b88da9-1f61-4ae4-9aa3-9d45e5af3732"/>
							<gml:surfaceMember xlink:href="#poly-f340f693-72bf-4ebd-b5d5-1c65be88e298"/>
							<gml:surfaceMember xlink:href="#poly-c793e423-675c-4bfd-90cf-29ad6cac60cf"/>
							<gml:surfaceMember xlink:href="#poly-e147afba-934f-4114-a64f-9fa3ad76e2a1"/>
							<gml:surfaceMember xlink:href="#poly-d1f29866-616a-40d0-b6f1-21952946032f"/>
							<gml:surfaceMember xlink:href="#poly-56b57d78-3517-46ad-8e38-53606022067b"/>
							<gml:surfaceMember xlink:href="#poly-fb30f29d-dcd8-466c-882a-df8a72029eb7"/>
							<gml:surfaceMember xlink:href="#poly-d5bfea36-3083-4144-b625-b19de0f83c80"/>
							<gml:surfaceMember xlink:href="#poly-dda684be-99e1-443a-bb64-7819086745c6"/>
							<gml:surfaceMember xlink:href="#poly-77d6e538-6bfc-4811-9187-e0591a38d3b6"/>
							<gml:surfaceMember xlink:href="#poly-0e571611-8def-477e-8c32-0d4495d37b89"/>
							<gml:surfaceMember xlink:href="#poly-2144640b-5fb4-4f72-b927-b519377d5ada"/>
							<gml:surfaceMember xlink:href="#poly-d86d1e91-61e4-44a1-adff-c5009afd03b3"/>
							<gml:surfaceMember xlink:href="#poly-ad1baa36-9c86-4557-a2ed-2a01a16ac5c6"/>
							<gml:surfaceMember xlink:href="#poly-accf0ed7-ed56-4236-8a83-f393a4db1de1"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6625cec6-bd40-47e2-a8ac-343770be9ec4_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4ed1c62c-3083-4435-89a0-07dc4b5d04ff">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667276252337686 139.74595598346536 30.377 35.667246616531145 139.74603241975305 30.377 35.66722647133988 139.7460206889271 30.377 35.6672561071391 139.74594425265434 30.377 35.667276252337686 139.74595598346536 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dd88a49-2499-404e-ae35-db8e2f5d7291">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dd88a49-2499-404e-ae35-db8e2f5d7291_0">
											<gml:posList>35.66722647133988 139.7460206889271 30.377 35.667246616531145 139.74603241975305 30.377 35.667246616531145 139.74603241975305 32.183 35.66722647133988 139.7460206889271 32.183 35.66722647133988 139.7460206889271 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6f452c8e-0642-40f8-bd8a-61ecdfdfcd03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6f452c8e-0642-40f8-bd8a-61ecdfdfcd03_0">
											<gml:posList>35.66722647133988 139.7460206889271 30.377 35.66722647133988 139.7460206889271 32.183 35.6672561071391 139.74594425265434 32.183 35.6672561071391 139.74594425265434 30.377 35.66722647133988 139.7460206889271 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f96690e5-23ec-46ef-b87c-a3dafb43a653">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f96690e5-23ec-46ef-b87c-a3dafb43a653_0">
											<gml:posList>35.667276252337686 139.74595598346536 32.183 35.6672561071391 139.74594425265434 32.183 35.66722647133988 139.7460206889271 32.183 35.667246616531145 139.74603241975305 32.183 35.667276252337686 139.74595598346536 32.183</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5653afe6-33ab-4148-a33f-b1999f23e254">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5653afe6-33ab-4148-a33f-b1999f23e254_0">
											<gml:posList>35.667246616531145 139.74603241975305 30.377 35.667276252337686 139.74595598346536 30.377 35.667276252337686 139.74595598346536 32.183 35.667246616531145 139.74603241975305 32.183 35.667246616531145 139.74603241975305 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80acdb77-6e95-4fb3-b8b8-11bafbc73843">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80acdb77-6e95-4fb3-b8b8-11bafbc73843_0">
											<gml:posList>35.667276252337686 139.74595598346536 30.377 35.6672561071391 139.74594425265434 30.377 35.6672561071391 139.74594425265434 32.183 35.667276252337686 139.74595598346536 32.183 35.667276252337686 139.74595598346536 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6625cec6-bd40-47e2-a8ac-343770be9ec4_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca863e4f-4bf2-4092-9147-0beb00b3b346">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66720889911548 139.74584069428187 7.47 35.667206211345565 139.74585079309648 7.47 35.66717287409114 139.74583225040072 7.47 35.667177369926335 139.74581706853988 7.47 35.66720889911548 139.74584069428187 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c63dc2d-9cf7-4ea2-8c85-740cd8c660d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c63dc2d-9cf7-4ea2-8c85-740cd8c660d7_0">
											<gml:posList>35.667172865077426 139.74583225041056 25.043 35.667177369926335 139.74581706853988 25.043 35.667177369926335 139.74581706853988 7.47 35.66717287409114 139.74583225040072 7.47 35.667172865077426 139.74583225041056 25.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abf08e4c-508d-42ca-b396-2af61dfd05eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abf08e4c-508d-42ca-b396-2af61dfd05eb_0">
											<gml:posList>35.667172865077426 139.74583225041056 25.043 35.66717734671458 139.74583474187517 25.043 35.66717990158097 139.7458278133588 25.043 35.66718245644695 139.74582088484195 25.043 35.667177369926335 139.74581706853988 25.043 35.667172865077426 139.74583225041056 25.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-864aad87-dead-4942-8f87-1d49f12cb165">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-864aad87-dead-4942-8f87-1d49f12cb165_0">
											<gml:posList>35.66720889911548 139.74584069428187 7.47 35.667177369926335 139.74581706853988 7.47 35.667177369926335 139.74581706853988 25.043 35.66718245644695 139.74582088484195 25.043 35.66720889009372 139.7458406832459 23.933 35.66720889911548 139.74584069428187 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eabe428c-063a-4b20-98cb-f3cf64ba12d8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eabe428c-063a-4b20-98cb-f3cf64ba12d8_0">
											<gml:posList>35.66720755071574 139.74584573264838 23.933 35.66720889009372 139.7458406832459 23.933 35.66718245644695 139.74582088484195 25.043 35.66717990158097 139.7458278133588 25.043 35.66720755071574 139.74584573264838 23.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-632a72af-e29f-42f0-aa10-e396d2bedb94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-632a72af-e29f-42f0-aa10-e396d2bedb94_0">
											<gml:posList>35.66720755071574 139.74584573264838 23.933 35.66717990158097 139.7458278133588 25.043 35.66720755071574 139.74584573264838 29.1 35.66720755071574 139.74584573264838 23.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a8a7871-8353-4463-9ae1-e8f72976f206">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a8a7871-8353-4463-9ae1-e8f72976f206_0">
											<gml:posList>35.66717734671458 139.74583474187517 25.043 35.667206211345565 139.74585079309648 29.1 35.66720755071574 139.74584573264838 29.1 35.66717990158097 139.7458278133588 25.043 35.66717734671458 139.74583474187517 25.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc8827c9-943d-41f4-9f67-43ae8ff278be">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc8827c9-943d-41f4-9f67-43ae8ff278be_0">
											<gml:posList>35.66717734671458 139.74583474187517 25.043 35.667172865077426 139.74583225041056 25.043 35.66717287409114 139.74583225040072 7.47 35.667206211345565 139.74585079309648 7.47 35.667206211345565 139.74585079309648 27.733 35.667206211345565 139.74585079309648 29.1 35.66717734671458 139.74583474187517 25.043</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bcfa8a54-1d8f-4a87-b2c9-4dc103471b56">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bcfa8a54-1d8f-4a87-b2c9-4dc103471b56_0">
											<gml:posList>35.66720889009372 139.7458406832459 23.933 35.66720755071574 139.74584573264838 23.933 35.667206211345565 139.74585079309648 27.733 35.667206211345565 139.74585079309648 7.47 35.66720889911548 139.74584069428187 7.47 35.66720889009372 139.7458406832459 23.933</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a914d793-9367-473d-abc6-8c805c4371b7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a914d793-9367-473d-abc6-8c805c4371b7_0">
											<gml:posList>35.667206211345565 139.74585079309648 27.733 35.66720755071574 139.74584573264838 23.933 35.66720755071574 139.74584573264838 29.1 35.667206211345565 139.74585079309648 29.1 35.667206211345565 139.74585079309648 27.733</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6625cec6-bd40-47e2-a8ac-343770be9ec4_BuildingInstallation_1031">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96c2c827-3e38-465f-8d1a-971a71127956">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66713830342207 139.74605169111564 29.1 35.66713531573042 139.74604597263658 29.1 35.667134176909876 139.74604171019246 29.1 35.66713375942772 139.74603777833758 29.1 35.667145029418656 139.7460043745719 29.1 35.667153839068014 139.7460088274871 29.1 35.667143081761424 139.7460407174212 29.1 35.66715254383278 139.74604990828487 29.1 35.66714995344307 139.7460575879459 29.1 35.66713830342207 139.74605169111564 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27913ba7-ac0b-41bc-8f6b-5afed85c762c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671787214155 139.74606468118802 29.1 35.66718150968338 139.74605641588064 29.1 35.66719411551155 139.74606279769066 29.1 35.66719132725125 139.74607107404492 29.1 35.6671787214155 139.74606468118802 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5cadb9b4-8f7d-4d9e-a01b-7bd3ac740850">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5cadb9b4-8f7d-4d9e-a01b-7bd3ac740850_0">
											<gml:posList>35.667153839068014 139.7460088274871 29.1 35.667145029418656 139.7460043745719 29.1 35.667145029418656 139.7460043745719 31.432 35.667153839068014 139.7460088274871 31.432 35.667153839068014 139.7460088274871 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-df5d3069-4972-4feb-abc1-86df5c724b6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-df5d3069-4972-4feb-abc1-86df5c724b6d_0">
											<gml:posList>35.66713375942772 139.74603777833758 29.1 35.66713375942772 139.74603777833758 31.432 35.667145029418656 139.7460043745719 31.432 35.667145029418656 139.7460043745719 29.1 35.66713375942772 139.74603777833758 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c713f79-192b-48e2-9b5a-80b802372942">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c713f79-192b-48e2-9b5a-80b802372942_0">
											<gml:posList>35.667143081761424 139.7460407174212 29.1 35.667153839068014 139.7460088274871 29.1 35.667153839068014 139.7460088274871 31.432 35.667143081761424 139.7460407174212 31.432 35.667143081761424 139.7460407174212 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74542558-f201-4fba-a875-d1315f4fbe6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74542558-f201-4fba-a875-d1315f4fbe6b_0">
											<gml:posList>35.667145029418656 139.7460043745719 31.432 35.66713375942772 139.74603777833758 31.432 35.667134176909876 139.74604171019246 31.432 35.66713531573042 139.74604597263658 31.432 35.66713830342207 139.74605169111564 31.432 35.66714995344307 139.7460575879459 31.432 35.66715254383278 139.74604990828487 31.432 35.667143081761424 139.7460407174212 31.432 35.667153839068014 139.7460088274871 31.432 35.667145029418656 139.7460043745719 31.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e04dd37c-797c-40f5-a3f2-0e9074090f31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e04dd37c-797c-40f5-a3f2-0e9074090f31_0">
											<gml:posList>35.66713375942772 139.74603777833758 29.1 35.667134176909876 139.74604171019246 29.1 35.667134176909876 139.74604171019246 31.432 35.66713375942772 139.74603777833758 31.432 35.66713375942772 139.74603777833758 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7f03c64-5737-43b5-b816-8728287cdb27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7f03c64-5737-43b5-b816-8728287cdb27_0">
											<gml:posList>35.667134176909876 139.74604171019246 29.1 35.66713531573042 139.74604597263658 29.1 35.66713531573042 139.74604597263658 31.432 35.667134176909876 139.74604171019246 31.432 35.667134176909876 139.74604171019246 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0aaf9038-0ba1-40f0-9e2d-3e81a1a8f0f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0aaf9038-0ba1-40f0-9e2d-3e81a1a8f0f0_0">
											<gml:posList>35.66715254383278 139.74604990828487 29.1 35.667143081761424 139.7460407174212 29.1 35.667143081761424 139.7460407174212 31.432 35.66715254383278 139.74604990828487 31.432 35.66715254383278 139.74604990828487 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abbc0b15-5a7c-4334-b2db-cabc80eef02a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abbc0b15-5a7c-4334-b2db-cabc80eef02a_0">
											<gml:posList>35.66713830342207 139.74605169111564 29.1 35.66713830342207 139.74605169111564 31.432 35.66713531573042 139.74604597263658 31.432 35.66713531573042 139.74604597263658 29.1 35.66713830342207 139.74605169111564 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffa84fb0-6d20-49c2-a11a-b177f3dc4806">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffa84fb0-6d20-49c2-a11a-b177f3dc4806_0">
											<gml:posList>35.66715254383278 139.74604990828487 31.432 35.66714995344307 139.7460575879459 31.432 35.66714995344307 139.7460575879459 29.1 35.66715254383278 139.74604990828487 29.1 35.66715254383278 139.74604990828487 31.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d78ea89-74b5-47dd-bd33-1ae8c57ed522">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d78ea89-74b5-47dd-bd33-1ae8c57ed522_0">
											<gml:posList>35.66713830342207 139.74605169111564 29.1 35.66714995344307 139.7460575879459 29.1 35.66714995344307 139.7460575879459 31.432 35.66713830342207 139.74605169111564 31.432 35.66713830342207 139.74605169111564 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25f02d2f-df2d-4b03-95a1-75dc2987e4d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25f02d2f-df2d-4b03-95a1-75dc2987e4d2_0">
											<gml:posList>35.66719411551155 139.74606279769066 29.1 35.66718150968338 139.74605641588064 29.1 35.66718150968338 139.74605641588064 32.539 35.66719411551155 139.74606279769066 32.539 35.66719411551155 139.74606279769066 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65b33d24-ebee-423e-abba-0a88c185b787">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65b33d24-ebee-423e-abba-0a88c185b787_0">
											<gml:posList>35.66718150968338 139.74605641588064 29.1 35.6671787214155 139.74606468118802 29.1 35.6671787214155 139.74606468118802 32.539 35.66718150968338 139.74605641588064 32.539 35.66718150968338 139.74605641588064 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abbf888a-9ca3-4656-83f0-ee23ffc55e35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-abbf888a-9ca3-4656-83f0-ee23ffc55e35_0">
											<gml:posList>35.66719411551155 139.74606279769066 32.539 35.66718150968338 139.74605641588064 32.539 35.6671787214155 139.74606468118802 32.539 35.66719132725125 139.74607107404492 32.539 35.66719411551155 139.74606279769066 32.539</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33e94a6e-580e-4db3-85a4-814ca484961d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33e94a6e-580e-4db3-85a4-814ca484961d_0">
											<gml:posList>35.66719132725125 139.74607107404492 29.1 35.66719411551155 139.74606279769066 29.1 35.66719411551155 139.74606279769066 32.539 35.66719132725125 139.74607107404492 32.539 35.66719132725125 139.74607107404492 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-945f9087-6f7f-497f-af60-08964b387ba4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-945f9087-6f7f-497f-af60-08964b387ba4_0">
											<gml:posList>35.66719132725125 139.74607107404492 29.1 35.66719132725125 139.74607107404492 32.539 35.6671787214155 139.74606468118802 32.539 35.6671787214155 139.74606468118802 29.1 35.66719132725125 139.74607107404492 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6625cec6-bd40-47e2-a8ac-343770be9ec4_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9c912f3-f5ad-4bf6-bdf5-8e525b061820">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671018102111 139.7460812673291 29.1 35.667099393755365 139.74608019851507 29.1 35.66710585882538 139.7460583870535 29.1 35.66711563286974 139.7460627395106 29.1 35.6671091768127 139.74608455096467 29.1 35.6671018102111 139.7460812673291 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7d2651d-7911-49b2-a039-72117f830581">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66712818530837 139.74598305240744 29.1 35.66714207995954 139.74598923397318 29.1 35.667133151163625 139.74601935458426 29.1 35.66711925651398 139.74601317301398 29.1 35.66712818530837 139.74598305240744 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2770d343-008b-4837-8cc4-f9249deffd1f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667139236133075 139.7459457607489 29.1 35.667145836055845 139.7459234962403 29.1 35.667155880605065 139.7459279698922 29.1 35.66714928067347 139.74595022335743 29.1 35.667139236133075 139.7459457607489 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-325e6ea1-2411-4314-92ad-15d58ba07e22">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715623661608 139.74592171757237 29.1 35.66714950968016 139.74591801351158 29.1 35.66715672442417 139.74589835513996 29.1 35.66716344233894 139.7459020481635 29.1 35.66715623661608 139.74592171757237 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe89b147-32c0-47e2-a454-342f3b42a2c0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716656428007 139.74589402549617 29.1 35.66716012590295 139.7458904868098 29.1 35.66716703468912 139.74587153569914 29.1 35.667173482072506 139.74587506332867 29.1 35.66716656428007 139.74589402549617 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8321f06d-0bf8-4a99-9bc9-673b7d505afe">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6671787214155 139.74606468118802 29.1 35.667187215470015 139.74606897981366 29.1 35.6671835637562 139.74607983078258 29.1 35.66717506068834 139.74607553216578 29.1 35.66714845138456 139.74606205208994 29.1 35.6671549003775 139.7460429358101 29.1 35.66718150967537 139.74605640483483 29.1 35.6671787214155 139.74606468118802 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d5cef0b-01c7-46d9-b39b-ea265fa1521b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66716419710118 139.7458615202382 29.1 35.66718181933798 139.7458372333499 29.1 35.66717341211682 139.74586561923041 29.1 35.66716419710118 139.7458615202382 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d41d0ee-6171-42f9-9045-22b657f16baf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718181933798 139.7458372333499 29.1 35.66716419710118 139.7458615202382 29.1 35.66717287409114 139.74583225040072 29.1 35.66718181933798 139.7458372333499 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f19d68f-88e6-45c3-818c-e354a2bc4fa7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66718507752467 139.74589269085598 29.1 35.66719258839907 139.74589604059523 29.1 35.66718872192713 139.74590903469598 29.1 35.667181211053084 139.7459056849557 29.1 35.66718507752467 139.74589269085598 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72f88ed3-6ce7-4675-9400-c3bea11672a6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667203910598246 139.74598428437034 33.033 35.667203785023 139.74598513503548 33.033 35.66720359633562 139.7459859636777 33.033 35.667203353557845 139.745986781333 33.033 35.66720305666565 139.74598755486397 33.033 35.667202696653305 139.7459882953262 33.033 35.66720229154828 139.7459890027001 33.033 35.66720183232082 139.7459896549038 33.033 35.66720133700638 139.74599026296357 33.033 35.66720079658325 139.7459908158433 33.033 35.66720022005713 139.74599130248743 33.033 35.66719960743603 139.7459917339418 33.033 35.66719896771766 139.74599208810486 33.033 35.66719830091804 139.74599238706836 33.033 35.667197625048615 139.74599260872094 33.033 35.667196931087624 139.7459927420267 33.033 35.66719622807286 139.74599282011317 33.033 35.66719552499399 139.74599280983313 33.033 35.66719482186706 139.74599273327826 33.033 35.667194136711515 139.745992579383 33.033 35.6671934605136 139.7459923481573 33.033 35.66719279328135 139.74599205064692 33.033 35.66719216205595 139.74599168682235 33.033 35.66719154880191 139.7459912456575 33.033 35.66719098057646 139.74599074921449 33.033 35.66719043935213 139.74599019751298 33.033 35.66718994314838 139.7459895794875 33.033 35.667189500994944 139.74598891721993 33.033 35.66718909486437 139.74598821072982 33.033 35.66718875179786 139.7459874599877 33.033 35.667188453775935 139.7459866760591 33.033 35.66718821882608 139.7459858589243 33.033 35.667188037950574 139.74598503068484 33.033 35.667187920155136 139.74598418028498 33.033 35.667187865447794 139.7459833187706 33.033 35.66718786482281 139.74598245719733 33.033 35.66718793631566 139.7459816065913 33.033 35.66718806189089 139.74598075592635 33.033 35.66718824156451 139.7459799272941 33.033 35.66718849335596 139.74597910962908 33.033 35.6671887902481 139.74597833609823 33.033 35.66718915026039 139.74597759563608 33.033 35.66718955536534 139.74597688826222 33.033 35.66719000557901 139.74597623606837 33.033 35.667190509907094 139.7459756279988 33.033 35.66719105033017 139.74597507511902 33.033 35.66719162685623 139.7459745884748 33.033 35.66719223947727 139.7459741570204 33.033 35.66719287919558 139.7459738028572 33.033 35.66719353698143 139.7459735039034 33.033 35.66719422187256 139.74597329328665 33.033 35.66719491582551 139.74597314893495 33.033 35.667195609826535 139.74597307085813 33.033 35.6671963129054 139.74597308113798 33.033 35.66719701603233 139.74597315769267 33.033 35.66719771020165 139.74597331157793 33.033 35.6671983863996 139.7459735428035 33.033 35.667199044618165 139.7459738403236 33.033 35.66719968485735 139.7459742041382 33.033 35.66720028909773 139.74597464531277 33.033 35.66720086633697 139.74597514174593 33.033 35.66720139855565 139.74597570450302 33.033 35.667201894751464 139.74597631148265 33.033 35.66720234591869 139.7459769737405 33.033 35.667202743035595 139.74597768024051 33.033 35.6672030951159 139.74597843097285 33.033 35.66720338412415 139.7459792149114 33.033 35.66720361907405 139.7459800320463 33.033 35.66720379994959 139.74598086028593 33.033 35.667203917745034 139.74598171068595 33.033 35.66720398146613 139.74598257219068 33.033 35.66720397307739 139.74598343377397 33.033 35.667203910598246 139.74598428437034 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cae84742-bc81-4a83-be26-27e849d58b2a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667209033782825 139.74608841881002 29.1 35.66719156564405 139.74613886198728 29.1 35.667187489902915 139.74613674562173 29.1 35.667204958032805 139.74608629140076 29.1 35.667209033782825 139.74608841881002 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1bb29d3-e735-4c94-8a05-b6f45737a25e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66720066301591 139.7461423315288 29.1 35.667196551123936 139.7461400826523 29.1 35.667213975955136 139.7460920696005 29.1 35.66721808783999 139.74609430742922 29.1 35.66720066301591 139.7461423315288 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-410dab42-2573-46a4-b248-74217a5b77f9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66726675355207 139.74592105585228 30.377 35.667288078966074 139.74593197902675 30.377 35.667285065764425 139.74594079688626 30.377 35.66726374035121 139.74592987370983 30.377 35.66726675355207 139.74592105585228 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e3d1156-a465-4590-8c18-cfa6cc5e0779">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e3d1156-a465-4590-8c18-cfa6cc5e0779_0">
											<gml:posList>35.667213975955136 139.7460920696005 29.1 35.667196551123936 139.7461400826523 29.1 35.667196551123936 139.7461400826523 30.344 35.667213975955136 139.7460920696005 30.344 35.667213975955136 139.7460920696005 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-74220e25-e13d-4378-ad7f-24120f7c2f08">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-74220e25-e13d-4378-ad7f-24120f7c2f08_0">
											<gml:posList>35.66717287409114 139.74583225040072 30.377 35.66718181933798 139.7458372333499 29.1 35.66717287409114 139.74583225040072 29.1 35.66717287409114 139.74583225040072 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f45be26e-002e-4a89-ae33-42dd354b56df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f45be26e-002e-4a89-ae33-42dd354b56df_0">
											<gml:posList>35.66718181933798 139.7458372333499 29.1 35.66717287409114 139.74583225040072 30.377 35.66718181933798 139.7458372333499 30.377 35.66718181933798 139.7458372333499 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e87fb2b-6865-4834-a1d0-08f8f5e495b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e87fb2b-6865-4834-a1d0-08f8f5e495b1_0">
											<gml:posList>35.66717287409114 139.74583225040072 29.1 35.66716419710118 139.7458615202382 29.1 35.66716419710118 139.7458615202382 30.377 35.66717287409114 139.74583225040072 30.377 35.66717287409114 139.74583225040072 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8064cdd-ca4d-489e-aca9-df8241b8c923">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8064cdd-ca4d-489e-aca9-df8241b8c923_0">
											<gml:posList>35.66718181933798 139.7458372333499 30.377 35.66717287409114 139.74583225040072 30.377 35.66716419710118 139.7458615202382 30.377 35.66717341211682 139.74586561923041 30.377 35.66718181933798 139.7458372333499 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-755b4c93-a309-4673-92c6-d2983aa6846a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-755b4c93-a309-4673-92c6-d2983aa6846a_0">
											<gml:posList>35.66718181933798 139.7458372333499 29.1 35.66718181933798 139.7458372333499 30.377 35.66717341211682 139.74586561923041 30.377 35.66717341211682 139.74586561923041 29.1 35.66718181933798 139.7458372333499 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c6e3049-ad42-4507-88c0-314052801cfd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c6e3049-ad42-4507-88c0-314052801cfd_0">
											<gml:posList>35.66716419710118 139.7458615202382 29.1 35.66717341211682 139.74586561923041 29.1 35.66717341211682 139.74586561923041 30.377 35.66716419710118 139.7458615202382 30.377 35.66716419710118 139.7458615202382 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e0265b7-711f-4e04-b1d7-9ad19937f47e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4e0265b7-711f-4e04-b1d7-9ad19937f47e_0">
											<gml:posList>35.667173482072506 139.74587506332867 29.1 35.66716703468912 139.74587153569914 29.1 35.66716703468912 139.74587153569914 30.801 35.667173482072506 139.74587506332867 30.801 35.667173482072506 139.74587506332867 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3b95c15-1fa0-4604-9aac-84403e7b98ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3b95c15-1fa0-4604-9aac-84403e7b98ff_0">
											<gml:posList>35.66716703468912 139.74587153569914 29.1 35.66716012590295 139.7458904868098 29.1 35.66716012590295 139.7458904868098 30.801 35.66716703468912 139.74587153569914 30.801 35.66716703468912 139.74587153569914 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-420c7f7e-e305-4839-9791-fc5121f40e22">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-420c7f7e-e305-4839-9791-fc5121f40e22_0">
											<gml:posList>35.66716703468912 139.74587153569914 30.801 35.66716012590295 139.7458904868098 30.801 35.66716656428007 139.74589402549617 30.801 35.667173482072506 139.74587506332867 30.801 35.66716703468912 139.74587153569914 30.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a07b0897-1d54-4716-8c1e-43615fa6150b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a07b0897-1d54-4716-8c1e-43615fa6150b_0">
											<gml:posList>35.66716656428007 139.74589402549617 29.1 35.667173482072506 139.74587506332867 29.1 35.667173482072506 139.74587506332867 30.801 35.66716656428007 139.74589402549617 30.801 35.66716656428007 139.74589402549617 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a0d623b-2997-489e-8d6c-8139416d29e7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a0d623b-2997-489e-8d6c-8139416d29e7_0">
											<gml:posList>35.66716012590295 139.7458904868098 29.1 35.66716656428007 139.74589402549617 29.1 35.66716656428007 139.74589402549617 30.801 35.66716012590295 139.7458904868098 30.801 35.66716012590295 139.7458904868098 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bab4f0e1-c0ce-474c-9d0c-d8801a3b8118">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bab4f0e1-c0ce-474c-9d0c-d8801a3b8118_0">
											<gml:posList>35.66719258839907 139.74589604059523 29.1 35.66718507752467 139.74589269085598 29.1 35.66718507752467 139.74589269085598 30.801 35.66719258839907 139.74589604059523 30.801 35.66719258839907 139.74589604059523 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0557ac1-5c73-480b-b70b-44c197c43867">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0557ac1-5c73-480b-b70b-44c197c43867_0">
											<gml:posList>35.66718507752467 139.74589269085598 29.1 35.667181211053084 139.7459056849557 29.1 35.667181211053084 139.7459056849557 30.801 35.66718507752467 139.74589269085598 30.801 35.66718507752467 139.74589269085598 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a44f0373-d42f-4830-a10b-5cee8dae3c66">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a44f0373-d42f-4830-a10b-5cee8dae3c66_0">
											<gml:posList>35.66716344233894 139.7459020481635 29.1 35.66715672442417 139.74589835513996 29.1 35.66715672442417 139.74589835513996 30.801 35.66716344233894 139.7459020481635 30.801 35.66716344233894 139.7459020481635 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8794a19-8b65-4134-8aeb-470f16b4b12e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8794a19-8b65-4134-8aeb-470f16b4b12e_0">
											<gml:posList>35.66718872192713 139.74590903469598 30.801 35.66719258839907 139.74589604059523 30.801 35.66718507752467 139.74589269085598 30.801 35.667181211053084 139.7459056849557 30.801 35.66718872192713 139.74590903469598 30.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c67bd97-b0f4-4953-bae0-2e721895ae9d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c67bd97-b0f4-4953-bae0-2e721895ae9d_0">
											<gml:posList>35.66718872192713 139.74590903469598 29.1 35.66719258839907 139.74589604059523 29.1 35.66719258839907 139.74589604059523 30.801 35.66718872192713 139.74590903469598 30.801 35.66718872192713 139.74590903469598 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9e791a4-00cf-40ed-838a-a4a650326e93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9e791a4-00cf-40ed-838a-a4a650326e93_0">
											<gml:posList>35.667181211053084 139.7459056849557 29.1 35.66718872192713 139.74590903469598 29.1 35.66718872192713 139.74590903469598 30.801 35.667181211053084 139.7459056849557 30.801 35.667181211053084 139.7459056849557 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5a97215-7eab-49f7-ac19-383fbbb800d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5a97215-7eab-49f7-ac19-383fbbb800d9_0">
											<gml:posList>35.66715672442417 139.74589835513996 29.1 35.66714950968016 139.74591801351158 29.1 35.66714950968016 139.74591801351158 30.801 35.66715672442417 139.74589835513996 30.801 35.66715672442417 139.74589835513996 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1a153393-5e21-46cc-8c52-c38bac724dd8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1a153393-5e21-46cc-8c52-c38bac724dd8_0">
											<gml:posList>35.66715672442417 139.74589835513996 30.801 35.66714950968016 139.74591801351158 30.801 35.66715623661608 139.74592171757237 30.801 35.66716344233894 139.7459020481635 30.801 35.66715672442417 139.74589835513996 30.801</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-de94fed1-cc0c-4ae3-a708-5c36570b44ba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-de94fed1-cc0c-4ae3-a708-5c36570b44ba_0">
											<gml:posList>35.66715623661608 139.74592171757237 29.1 35.66716344233894 139.7459020481635 29.1 35.66716344233894 139.7459020481635 30.801 35.66715623661608 139.74592171757237 30.801 35.66715623661608 139.74592171757237 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c3112bba-9a22-4b33-8cc8-88f851b914d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c3112bba-9a22-4b33-8cc8-88f851b914d0_0">
											<gml:posList>35.66714950968016 139.74591801351158 29.1 35.66715623661608 139.74592171757237 29.1 35.66715623661608 139.74592171757237 30.801 35.66714950968016 139.74591801351158 30.801 35.66714950968016 139.74591801351158 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b2768095-b59d-4e08-ba88-fe4280ea015a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b2768095-b59d-4e08-ba88-fe4280ea015a_0">
											<gml:posList>35.66726675355207 139.74592105585228 30.377 35.66726374035121 139.74592987370983 30.377 35.66726374035121 139.74592987370983 30.719 35.66726675355207 139.74592105585228 30.719 35.66726675355207 139.74592105585228 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-529cc78d-0d98-4c4b-8dda-e0df990a616c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-529cc78d-0d98-4c4b-8dda-e0df990a616c_0">
											<gml:posList>35.667155880605065 139.7459279698922 29.1 35.667145836055845 139.7459234962403 29.1 35.667145836055845 139.7459234962403 30.377 35.667155880605065 139.7459279698922 30.377 35.667155880605065 139.7459279698922 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb8f5d7c-ab27-4bda-a051-00910105bc6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb8f5d7c-ab27-4bda-a051-00910105bc6d_0">
											<gml:posList>35.667288078966074 139.74593197902675 30.377 35.66726675355207 139.74592105585228 30.377 35.66726675355207 139.74592105585228 30.719 35.667288078966074 139.74593197902675 30.719 35.667288078966074 139.74593197902675 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6e1754a-bacf-4ffd-bade-7e5947836699">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6e1754a-bacf-4ffd-bade-7e5947836699_0">
											<gml:posList>35.667285065764425 139.74594079688626 30.719 35.667288078966074 139.74593197902675 30.719 35.66726675355207 139.74592105585228 30.719 35.66726374035121 139.74592987370983 30.719 35.667285065764425 139.74594079688626 30.719</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e0be8928-3710-49f0-8a29-c0257c29c17b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e0be8928-3710-49f0-8a29-c0257c29c17b_0">
											<gml:posList>35.667145836055845 139.7459234962403 29.1 35.667139236133075 139.7459457607489 29.1 35.667139236133075 139.7459457607489 30.377 35.667145836055845 139.7459234962403 30.377 35.667145836055845 139.7459234962403 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dc9781c-f143-4267-a73a-b28a1e150e8e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dc9781c-f143-4267-a73a-b28a1e150e8e_0">
											<gml:posList>35.667285065764425 139.74594079688626 30.377 35.667285065764425 139.74594079688626 30.719 35.66726374035121 139.74592987370983 30.719 35.66726374035121 139.74592987370983 30.377 35.667285065764425 139.74594079688626 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3b102125-e149-4b28-8b6e-2f24a930285f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3b102125-e149-4b28-8b6e-2f24a930285f_0">
											<gml:posList>35.667285065764425 139.74594079688626 30.377 35.667288078966074 139.74593197902675 30.377 35.667288078966074 139.74593197902675 30.719 35.667285065764425 139.74594079688626 30.719 35.667285065764425 139.74594079688626 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17ec18c7-93a8-4bb1-87e9-399970545c48">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17ec18c7-93a8-4bb1-87e9-399970545c48_0">
											<gml:posList>35.667155880605065 139.7459279698922 30.377 35.667145836055845 139.7459234962403 30.377 35.667139236133075 139.7459457607489 30.377 35.66714928067347 139.74595022335743 30.377 35.667155880605065 139.7459279698922 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23f95050-ba03-4f4e-8d83-4cc9060a204e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23f95050-ba03-4f4e-8d83-4cc9060a204e_0">
											<gml:posList>35.66714928067347 139.74595022335743 29.1 35.667155880605065 139.7459279698922 29.1 35.667155880605065 139.7459279698922 30.377 35.66714928067347 139.74595022335743 30.377 35.66714928067347 139.74595022335743 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-33b39a0f-1a4b-44f0-bb55-1bba98b5d1ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-33b39a0f-1a4b-44f0-bb55-1bba98b5d1ed_0">
											<gml:posList>35.667139236133075 139.7459457607489 29.1 35.66714928067347 139.74595022335743 29.1 35.66714928067347 139.74595022335743 30.377 35.667139236133075 139.7459457607489 30.377 35.667139236133075 139.7459457607489 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da0da5d0-1f27-4f09-95a2-d6485def2582">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-da0da5d0-1f27-4f09-95a2-d6485def2582_0">
											<gml:posList>35.6671963129054 139.74597308113798 33.033 35.667195609826535 139.74597307085813 33.033 35.667195609826535 139.74597307085813 34.848 35.6671963129054 139.74597308113798 34.848 35.6671963129054 139.74597308113798 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d90b7327-6175-49fc-82b8-b729f377380f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d90b7327-6175-49fc-82b8-b729f377380f_0">
											<gml:posList>35.667195609826535 139.74597307085813 33.033 35.66719491582551 139.74597314893495 33.033 35.66719491582551 139.74597314893495 34.848 35.667195609826535 139.74597307085813 34.848 35.667195609826535 139.74597307085813 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83aa36d9-f706-41ff-9678-4254183ddb21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83aa36d9-f706-41ff-9678-4254183ddb21_0">
											<gml:posList>35.66719701603233 139.74597315769267 33.033 35.6671963129054 139.74597308113798 33.033 35.6671963129054 139.74597308113798 34.848 35.66719701603233 139.74597315769267 34.848 35.66719701603233 139.74597315769267 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9c5ce7b4-d02c-4c96-aaf4-1b91f116ad6c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9c5ce7b4-d02c-4c96-aaf4-1b91f116ad6c_0">
											<gml:posList>35.66719491582551 139.74597314893495 33.033 35.66719422187256 139.74597329328665 33.033 35.66719422187256 139.74597329328665 34.848 35.66719491582551 139.74597314893495 34.848 35.66719491582551 139.74597314893495 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e13ead04-1368-41db-8917-5b4ad5414a45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e13ead04-1368-41db-8917-5b4ad5414a45_0">
											<gml:posList>35.66719771020165 139.74597331157793 33.033 35.66719701603233 139.74597315769267 33.033 35.66719701603233 139.74597315769267 34.848 35.66719771020165 139.74597331157793 34.848 35.66719771020165 139.74597331157793 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78417cf3-ceae-4d58-ad7a-2c1ab023b286">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78417cf3-ceae-4d58-ad7a-2c1ab023b286_0">
											<gml:posList>35.66719422187256 139.74597329328665 33.033 35.66719353698143 139.7459735039034 33.033 35.66719353698143 139.7459735039034 34.848 35.66719422187256 139.74597329328665 34.848 35.66719422187256 139.74597329328665 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45d34e77-8081-4639-bd43-a5f1a017fdd5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45d34e77-8081-4639-bd43-a5f1a017fdd5_0">
											<gml:posList>35.6671983863996 139.7459735428035 33.033 35.66719771020165 139.74597331157793 33.033 35.66719771020165 139.74597331157793 34.848 35.6671983863996 139.7459735428035 34.848 35.6671983863996 139.7459735428035 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f03de7d5-1939-4e9d-8705-56876c797c9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f03de7d5-1939-4e9d-8705-56876c797c9e_0">
											<gml:posList>35.66719353698143 139.7459735039034 33.033 35.66719287919558 139.7459738028572 33.033 35.66719287919558 139.7459738028572 34.848 35.66719353698143 139.7459735039034 34.848 35.66719353698143 139.7459735039034 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91a09188-0481-4713-b292-cc4b39b504d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91a09188-0481-4713-b292-cc4b39b504d1_0">
											<gml:posList>35.667199044618165 139.7459738403236 33.033 35.6671983863996 139.7459735428035 33.033 35.6671983863996 139.7459735428035 34.848 35.667199044618165 139.7459738403236 34.848 35.667199044618165 139.7459738403236 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-14cd9f65-724c-4b0a-9fbb-9f9c7c077c7c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-14cd9f65-724c-4b0a-9fbb-9f9c7c077c7c_0">
											<gml:posList>35.66719287919558 139.7459738028572 33.033 35.66719223947727 139.7459741570204 33.033 35.66719223947727 139.7459741570204 34.848 35.66719287919558 139.7459738028572 34.848 35.66719287919558 139.7459738028572 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-27e1ab84-4422-42f2-b65c-443efdd3dcc5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-27e1ab84-4422-42f2-b65c-443efdd3dcc5_0">
											<gml:posList>35.66719968485735 139.7459742041382 33.033 35.667199044618165 139.7459738403236 33.033 35.667199044618165 139.7459738403236 34.848 35.66719968485735 139.7459742041382 34.848 35.66719968485735 139.7459742041382 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-695d96c5-1bd2-4825-a21e-a344ec004f44">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-695d96c5-1bd2-4825-a21e-a344ec004f44_0">
											<gml:posList>35.66719223947727 139.7459741570204 33.033 35.66719162685623 139.7459745884748 33.033 35.66719162685623 139.7459745884748 34.848 35.66719223947727 139.7459741570204 34.848 35.66719223947727 139.7459741570204 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49831ca7-b11c-4f13-94ba-2cc22fd91bab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49831ca7-b11c-4f13-94ba-2cc22fd91bab_0">
											<gml:posList>35.66720028909773 139.74597464531277 33.033 35.66719968485735 139.7459742041382 33.033 35.66719968485735 139.7459742041382 34.848 35.66720028909773 139.74597464531277 34.848 35.66720028909773 139.74597464531277 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-25fbe5c4-2826-4591-9efc-3ce4b658df96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-25fbe5c4-2826-4591-9efc-3ce4b658df96_0">
											<gml:posList>35.66719162685623 139.7459745884748 33.033 35.66719105033017 139.74597507511902 33.033 35.66719105033017 139.74597507511902 34.848 35.66719162685623 139.7459745884748 34.848 35.66719162685623 139.7459745884748 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b9836810-7c83-4803-80ec-7b624e5df1b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b9836810-7c83-4803-80ec-7b624e5df1b2_0">
											<gml:posList>35.66720086633697 139.74597514174593 33.033 35.66720028909773 139.74597464531277 33.033 35.66720028909773 139.74597464531277 34.848 35.66720086633697 139.74597514174593 34.848 35.66720086633697 139.74597514174593 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-197342fc-ecff-4520-adb1-fdb05799dbe8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-197342fc-ecff-4520-adb1-fdb05799dbe8_0">
											<gml:posList>35.66719105033017 139.74597507511902 33.033 35.667190509907094 139.7459756279988 33.033 35.667190509907094 139.7459756279988 34.848 35.66719105033017 139.74597507511902 34.848 35.66719105033017 139.74597507511902 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-189e7ca3-d346-4efb-870b-ff361b0bd10c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-189e7ca3-d346-4efb-870b-ff361b0bd10c_0">
											<gml:posList>35.66720139855565 139.74597570450302 33.033 35.66720086633697 139.74597514174593 33.033 35.66720086633697 139.74597514174593 34.848 35.66720139855565 139.74597570450302 34.848 35.66720139855565 139.74597570450302 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13fe9d6f-0f4a-473d-8e25-e9d1fe96a293">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13fe9d6f-0f4a-473d-8e25-e9d1fe96a293_0">
											<gml:posList>35.667190509907094 139.7459756279988 33.033 35.66719000557901 139.74597623606837 33.033 35.66719000557901 139.74597623606837 34.848 35.667190509907094 139.7459756279988 34.848 35.667190509907094 139.7459756279988 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79772d9d-2855-425a-a967-972de5183a35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79772d9d-2855-425a-a967-972de5183a35_0">
											<gml:posList>35.667201894751464 139.74597631148265 33.033 35.66720139855565 139.74597570450302 33.033 35.66720139855565 139.74597570450302 34.848 35.667201894751464 139.74597631148265 34.848 35.667201894751464 139.74597631148265 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af7a2420-1b19-4d57-a63b-229300c3ce1d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af7a2420-1b19-4d57-a63b-229300c3ce1d_0">
											<gml:posList>35.66719000557901 139.74597623606837 33.033 35.66718955536534 139.74597688826222 33.033 35.66718955536534 139.74597688826222 34.848 35.66719000557901 139.74597623606837 34.848 35.66719000557901 139.74597623606837 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6eab9723-dd19-4464-9638-9544c6d2daf2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6eab9723-dd19-4464-9638-9544c6d2daf2_0">
											<gml:posList>35.66720234591869 139.7459769737405 33.033 35.667201894751464 139.74597631148265 33.033 35.667201894751464 139.74597631148265 34.848 35.66720234591869 139.7459769737405 34.848 35.66720234591869 139.7459769737405 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c9df6b2-8fe1-4d20-aea4-0fd4e4675637">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c9df6b2-8fe1-4d20-aea4-0fd4e4675637_0">
											<gml:posList>35.66718955536534 139.74597688826222 33.033 35.66718915026039 139.74597759563608 33.033 35.66718915026039 139.74597759563608 34.848 35.66718955536534 139.74597688826222 34.848 35.66718955536534 139.74597688826222 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16b79824-3a20-43e7-b6f8-14ee1ba0029c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16b79824-3a20-43e7-b6f8-14ee1ba0029c_0">
											<gml:posList>35.667202743035595 139.74597768024051 33.033 35.66720234591869 139.7459769737405 33.033 35.66720234591869 139.7459769737405 34.848 35.667202743035595 139.74597768024051 34.848 35.667202743035595 139.74597768024051 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8b561717-1179-44d3-ae92-2edc640171cf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8b561717-1179-44d3-ae92-2edc640171cf_0">
											<gml:posList>35.66718915026039 139.74597759563608 33.033 35.6671887902481 139.74597833609823 33.033 35.6671887902481 139.74597833609823 34.848 35.66718915026039 139.74597759563608 34.848 35.66718915026039 139.74597759563608 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c4282b54-6f3f-4aef-ad41-5240e82fa9fb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c4282b54-6f3f-4aef-ad41-5240e82fa9fb_0">
											<gml:posList>35.6672030951159 139.74597843097285 33.033 35.667202743035595 139.74597768024051 33.033 35.667202743035595 139.74597768024051 34.848 35.6672030951159 139.74597843097285 34.848 35.6672030951159 139.74597843097285 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-835b800c-3291-4b53-af7b-005995daf19d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-835b800c-3291-4b53-af7b-005995daf19d_0">
											<gml:posList>35.6671887902481 139.74597833609823 33.033 35.66718849335596 139.74597910962908 33.033 35.66718849335596 139.74597910962908 34.848 35.6671887902481 139.74597833609823 34.848 35.6671887902481 139.74597833609823 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ebbdbaab-56ea-4593-9f52-bea364da8227">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ebbdbaab-56ea-4593-9f52-bea364da8227_0">
											<gml:posList>35.66720338412415 139.7459792149114 33.033 35.6672030951159 139.74597843097285 33.033 35.6672030951159 139.74597843097285 34.848 35.66720338412415 139.7459792149114 34.848 35.66720338412415 139.7459792149114 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8bdf816d-0237-4054-969e-d878447a0c06">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8bdf816d-0237-4054-969e-d878447a0c06_0">
											<gml:posList>35.66718849335596 139.74597910962908 33.033 35.66718824156451 139.7459799272941 33.033 35.66718824156451 139.7459799272941 34.848 35.66718849335596 139.74597910962908 34.848 35.66718849335596 139.74597910962908 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-524bbaf8-3d5d-45dc-87b8-e30bf439dd75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-524bbaf8-3d5d-45dc-87b8-e30bf439dd75_0">
											<gml:posList>35.66720361907405 139.7459800320463 33.033 35.66720338412415 139.7459792149114 33.033 35.66720338412415 139.7459792149114 34.848 35.66720361907405 139.7459800320463 34.848 35.66720361907405 139.7459800320463 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca139259-6fdf-4655-b04b-cc79eeb36295">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca139259-6fdf-4655-b04b-cc79eeb36295_0">
											<gml:posList>35.66718824156451 139.7459799272941 33.033 35.66718806189089 139.74598075592635 33.033 35.66718806189089 139.74598075592635 34.848 35.66718824156451 139.7459799272941 34.848 35.66718824156451 139.7459799272941 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ae6d85d-a99b-4d4a-87ad-027364c8a75b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ae6d85d-a99b-4d4a-87ad-027364c8a75b_0">
											<gml:posList>35.66720379994959 139.74598086028593 33.033 35.66720361907405 139.7459800320463 33.033 35.66720361907405 139.7459800320463 34.848 35.66720379994959 139.74598086028593 34.848 35.66720379994959 139.74598086028593 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2380e77-64f7-4e4e-ad8b-84801a5be149">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2380e77-64f7-4e4e-ad8b-84801a5be149_0">
											<gml:posList>35.66718806189089 139.74598075592635 33.033 35.66718793631566 139.7459816065913 33.033 35.66718793631566 139.7459816065913 34.848 35.66718806189089 139.74598075592635 34.848 35.66718806189089 139.74598075592635 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9db2e1ec-146c-46cf-8e5e-b1bee4725821">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9db2e1ec-146c-46cf-8e5e-b1bee4725821_0">
											<gml:posList>35.667203917745034 139.74598171068595 33.033 35.66720379994959 139.74598086028593 33.033 35.66720379994959 139.74598086028593 34.848 35.667203917745034 139.74598171068595 34.848 35.667203917745034 139.74598171068595 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1632157c-2734-4c6d-9786-f915aa16a4e9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1632157c-2734-4c6d-9786-f915aa16a4e9_0">
											<gml:posList>35.66718793631566 139.7459816065913 33.033 35.66718786482281 139.74598245719733 33.033 35.66718786482281 139.74598245719733 34.848 35.66718793631566 139.7459816065913 34.848 35.66718793631566 139.7459816065913 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0926895e-3889-4980-b394-11eb9de60635">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0926895e-3889-4980-b394-11eb9de60635_0">
											<gml:posList>35.66720398146613 139.74598257219068 33.033 35.667203917745034 139.74598171068595 33.033 35.667203917745034 139.74598171068595 34.848 35.66720398146613 139.74598257219068 34.848 35.66720398146613 139.74598257219068 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30ba6cd1-db52-4341-8fa9-42630bce55d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30ba6cd1-db52-4341-8fa9-42630bce55d1_0">
											<gml:posList>35.66718786482281 139.74598245719733 33.033 35.667187865447794 139.7459833187706 33.033 35.667187865447794 139.7459833187706 34.848 35.66718786482281 139.74598245719733 34.848 35.66718786482281 139.74598245719733 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3dff8a43-cb67-48c1-8fd3-d22bc9a48f32">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3dff8a43-cb67-48c1-8fd3-d22bc9a48f32_0">
											<gml:posList>35.66720398146613 139.74598257219068 34.848 35.667203917745034 139.74598171068595 34.848 35.66720379994959 139.74598086028593 34.848 35.66720361907405 139.7459800320463 34.848 35.66720338412415 139.7459792149114 34.848 35.6672030951159 139.74597843097285 34.848 35.667202743035595 139.74597768024051 34.848 35.66720234591869 139.7459769737405 34.848 35.667201894751464 139.74597631148265 34.848 35.66720139855565 139.74597570450302 34.848 35.66720086633697 139.74597514174593 34.848 35.66720028909773 139.74597464531277 34.848 35.66719968485735 139.7459742041382 34.848 35.667199044618165 139.7459738403236 34.848 35.6671983863996 139.7459735428035 34.848 35.66719771020165 139.74597331157793 34.848 35.66719701603233 139.74597315769267 34.848 35.6671963129054 139.74597308113798 34.848 35.667195609826535 139.74597307085813 34.848 35.66719491582551 139.74597314893495 34.848 35.66719422187256 139.74597329328665 34.848 35.66719353698143 139.7459735039034 34.848 35.66719287919558 139.7459738028572 34.848 35.66719223947727 139.7459741570204 34.848 35.66719162685623 139.7459745884748 34.848 35.66719105033017 139.74597507511902 34.848 35.667190509907094 139.7459756279988 34.848 35.66719000557901 139.74597623606837 34.848 35.66718955536534 139.74597688826222 34.848 35.66718915026039 139.74597759563608 34.848 35.6671887902481 139.74597833609823 34.848 35.66718849335596 139.74597910962908 34.848 35.66718824156451 139.7459799272941 34.848 35.66718806189089 139.74598075592635 34.848 35.66718793631566 139.7459816065913 34.848 35.66718786482281 139.74598245719733 34.848 35.667187865447794 139.7459833187706 34.848 35.667187920155136 139.74598418028498 34.848 35.667188037950574 139.74598503068484 34.848 35.66718821882608 139.7459858589243 34.848 35.667188453775935 139.7459866760591 34.848 35.66718875179786 139.7459874599877 34.848 35.66718909486437 139.74598821072982 34.848 35.667189500994944 139.74598891721993 34.848 35.66718994314838 139.7459895794875 34.848 35.66719043935213 139.74599019751298 34.848 35.66719098057646 139.74599074921449 34.848 35.66719154880191 139.7459912456575 34.848 35.66719216205595 139.74599168682235 34.848 35.66719279328135 139.74599205064692 34.848 35.6671934605136 139.7459923481573 34.848 35.667194136711515 139.745992579383 34.848 35.66719482186706 139.74599273327826 34.848 35.66719552499399 139.74599280983313 34.848 35.66719622807286 139.74599282011317 34.848 35.667196931087624 139.7459927420267 34.848 35.667197625048615 139.74599260872094 34.848 35.66719830091804 139.74599238706836 34.848 35.66719896771766 139.74599208810486 34.848 35.66719960743603 139.7459917339418 34.848 35.66720022005713 139.74599130248743 34.848 35.66720079658325 139.7459908158433 34.848 35.66720133700638 139.74599026296357 34.848 35.66720183232082 139.7459896549038 34.848 35.66720229154828 139.7459890027001 34.848 35.667202696653305 139.7459882953262 34.848 35.66720305666565 139.74598755486397 34.848 35.667203353557845 139.745986781333 34.848 35.66720359633562 139.7459859636777 34.848 35.667203785023 139.74598513503548 34.848 35.667203910598246 139.74598428437034 34.848 35.66720397307739 139.74598343377397 34.848 35.66720398146613 139.74598257219068 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7c9ffc1a-c3ad-41b6-8e21-352d656a52d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7c9ffc1a-c3ad-41b6-8e21-352d656a52d5_0">
											<gml:posList>35.66720397307739 139.74598343377397 33.033 35.66720398146613 139.74598257219068 33.033 35.66720398146613 139.74598257219068 34.848 35.66720397307739 139.74598343377397 34.848 35.66720397307739 139.74598343377397 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24397c2c-3d66-49c8-a9a6-e6b32bfd1fc5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24397c2c-3d66-49c8-a9a6-e6b32bfd1fc5_0">
											<gml:posList>35.667187865447794 139.7459833187706 33.033 35.667187920155136 139.74598418028498 33.033 35.667187920155136 139.74598418028498 34.848 35.667187865447794 139.7459833187706 34.848 35.667187865447794 139.7459833187706 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-743f786d-d063-43dc-8c1e-f319ec6c15cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-743f786d-d063-43dc-8c1e-f319ec6c15cd_0">
											<gml:posList>35.667203910598246 139.74598428437034 33.033 35.66720397307739 139.74598343377397 33.033 35.66720397307739 139.74598343377397 34.848 35.667203910598246 139.74598428437034 34.848 35.667203910598246 139.74598428437034 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35780548-3169-41d9-a78d-411ced982648">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35780548-3169-41d9-a78d-411ced982648_0">
											<gml:posList>35.667187920155136 139.74598418028498 33.033 35.667188037950574 139.74598503068484 33.033 35.667188037950574 139.74598503068484 34.848 35.667187920155136 139.74598418028498 34.848 35.667187920155136 139.74598418028498 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5151cf9e-9436-4d03-b89b-75d5e2e9b471">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5151cf9e-9436-4d03-b89b-75d5e2e9b471_0">
											<gml:posList>35.667203785023 139.74598513503548 33.033 35.667203910598246 139.74598428437034 33.033 35.667203910598246 139.74598428437034 34.848 35.667203785023 139.74598513503548 34.848 35.667203785023 139.74598513503548 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79c08f6f-f889-4471-9277-c4a89b4a3810">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79c08f6f-f889-4471-9277-c4a89b4a3810_0">
											<gml:posList>35.667188037950574 139.74598503068484 33.033 35.66718821882608 139.7459858589243 33.033 35.66718821882608 139.7459858589243 34.848 35.667188037950574 139.74598503068484 34.848 35.667188037950574 139.74598503068484 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d008f70-bf97-44c7-b41b-751a00c66fdb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d008f70-bf97-44c7-b41b-751a00c66fdb_0">
											<gml:posList>35.66720359633562 139.7459859636777 33.033 35.667203785023 139.74598513503548 33.033 35.667203785023 139.74598513503548 34.848 35.66720359633562 139.7459859636777 34.848 35.66720359633562 139.7459859636777 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a994b9f8-bcf1-4f7f-aed3-57bcbbf66a3d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a994b9f8-bcf1-4f7f-aed3-57bcbbf66a3d_0">
											<gml:posList>35.66714207995954 139.74598923397318 29.1 35.66712818530837 139.74598305240744 29.1 35.66712818530837 139.74598305240744 30.377 35.66714207995954 139.74598923397318 30.377 35.66714207995954 139.74598923397318 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0b6ff750-eaf9-4a2a-ab88-06de3a5841b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0b6ff750-eaf9-4a2a-ab88-06de3a5841b6_0">
											<gml:posList>35.66718821882608 139.7459858589243 33.033 35.667188453775935 139.7459866760591 33.033 35.667188453775935 139.7459866760591 34.848 35.66718821882608 139.7459858589243 34.848 35.66718821882608 139.7459858589243 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-461c9211-8851-4a9f-b9cc-50a085803c62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-461c9211-8851-4a9f-b9cc-50a085803c62_0">
											<gml:posList>35.667203353557845 139.745986781333 33.033 35.66720359633562 139.7459859636777 33.033 35.66720359633562 139.7459859636777 34.848 35.667203353557845 139.745986781333 34.848 35.667203353557845 139.745986781333 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ffd62a5-8b30-4ab8-9201-d0b789dcd43d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ffd62a5-8b30-4ab8-9201-d0b789dcd43d_0">
											<gml:posList>35.667188453775935 139.7459866760591 33.033 35.66718875179786 139.7459874599877 33.033 35.66718875179786 139.7459874599877 34.848 35.667188453775935 139.7459866760591 34.848 35.667188453775935 139.7459866760591 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62247385-827a-4bc7-8cc5-7175b05a5876">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62247385-827a-4bc7-8cc5-7175b05a5876_0">
											<gml:posList>35.66720305666565 139.74598755486397 33.033 35.667203353557845 139.745986781333 33.033 35.667203353557845 139.745986781333 34.848 35.66720305666565 139.74598755486397 34.848 35.66720305666565 139.74598755486397 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e19d96f9-a3a7-4d6a-979a-70c6da280db2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e19d96f9-a3a7-4d6a-979a-70c6da280db2_0">
											<gml:posList>35.66718875179786 139.7459874599877 33.033 35.66718909486437 139.74598821072982 33.033 35.66718909486437 139.74598821072982 34.848 35.66718875179786 139.7459874599877 34.848 35.66718875179786 139.7459874599877 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f5f298f5-a936-4a57-a65f-874dccd6e4db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f5f298f5-a936-4a57-a65f-874dccd6e4db_0">
											<gml:posList>35.667202696653305 139.7459882953262 33.033 35.66720305666565 139.74598755486397 33.033 35.66720305666565 139.74598755486397 34.848 35.667202696653305 139.7459882953262 34.848 35.667202696653305 139.7459882953262 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77a1eee3-45ba-4991-96d1-549099bff50b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77a1eee3-45ba-4991-96d1-549099bff50b_0">
											<gml:posList>35.66718909486437 139.74598821072982 33.033 35.667189500994944 139.74598891721993 33.033 35.667189500994944 139.74598891721993 34.848 35.66718909486437 139.74598821072982 34.848 35.66718909486437 139.74598821072982 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6327ff66-2edb-4710-9a7a-e3e76f0790ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6327ff66-2edb-4710-9a7a-e3e76f0790ae_0">
											<gml:posList>35.66720229154828 139.7459890027001 33.033 35.667202696653305 139.7459882953262 33.033 35.667202696653305 139.7459882953262 34.848 35.66720229154828 139.7459890027001 34.848 35.66720229154828 139.7459890027001 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b17e61b-8882-4e65-a1fc-631bb70b3089">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b17e61b-8882-4e65-a1fc-631bb70b3089_0">
											<gml:posList>35.667189500994944 139.74598891721993 33.033 35.66718994314838 139.7459895794875 33.033 35.66718994314838 139.7459895794875 34.848 35.667189500994944 139.74598891721993 34.848 35.667189500994944 139.74598891721993 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e866ae8e-a84c-4b54-b763-ec0adcddbdaf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e866ae8e-a84c-4b54-b763-ec0adcddbdaf_0">
											<gml:posList>35.66720183232082 139.7459896549038 33.033 35.66720229154828 139.7459890027001 33.033 35.66720229154828 139.7459890027001 34.848 35.66720183232082 139.7459896549038 34.848 35.66720183232082 139.7459896549038 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fe785efe-1f31-451b-b2af-30bda0c2c069">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fe785efe-1f31-451b-b2af-30bda0c2c069_0">
											<gml:posList>35.66718994314838 139.7459895794875 33.033 35.66719043935213 139.74599019751298 33.033 35.66719043935213 139.74599019751298 34.848 35.66718994314838 139.7459895794875 34.848 35.66718994314838 139.7459895794875 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c562d2c0-6b4c-41d1-9cf8-37f6b4cb2e01">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c562d2c0-6b4c-41d1-9cf8-37f6b4cb2e01_0">
											<gml:posList>35.66720133700638 139.74599026296357 33.033 35.66720183232082 139.7459896549038 33.033 35.66720183232082 139.7459896549038 34.848 35.66720133700638 139.74599026296357 34.848 35.66720133700638 139.74599026296357 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5553e81f-2e4b-44f8-9667-b8c36775b402">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5553e81f-2e4b-44f8-9667-b8c36775b402_0">
											<gml:posList>35.66719043935213 139.74599019751298 33.033 35.66719098057646 139.74599074921449 33.033 35.66719098057646 139.74599074921449 34.848 35.66719043935213 139.74599019751298 34.848 35.66719043935213 139.74599019751298 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85eb777c-8279-4ad5-886a-bc99b2e99c47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85eb777c-8279-4ad5-886a-bc99b2e99c47_0">
											<gml:posList>35.66720079658325 139.7459908158433 33.033 35.66720133700638 139.74599026296357 33.033 35.66720133700638 139.74599026296357 34.848 35.66720079658325 139.7459908158433 34.848 35.66720079658325 139.7459908158433 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06d12b0c-0676-4c3b-80ec-3f8e081b8806">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06d12b0c-0676-4c3b-80ec-3f8e081b8806_0">
											<gml:posList>35.66719154880191 139.7459912456575 33.033 35.66719154880191 139.7459912456575 34.848 35.66719098057646 139.74599074921449 34.848 35.66719098057646 139.74599074921449 33.033 35.66719154880191 139.7459912456575 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf0da95f-1044-44c9-b0e0-78c5a293127b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf0da95f-1044-44c9-b0e0-78c5a293127b_0">
											<gml:posList>35.66720022005713 139.74599130248743 33.033 35.66720079658325 139.7459908158433 33.033 35.66720079658325 139.7459908158433 34.848 35.66720022005713 139.74599130248743 34.848 35.66720022005713 139.74599130248743 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-420f7324-b876-4d62-9107-8762f1a74f98">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-420f7324-b876-4d62-9107-8762f1a74f98_0">
											<gml:posList>35.66719154880191 139.7459912456575 33.033 35.66719216205595 139.74599168682235 33.033 35.66719216205595 139.74599168682235 34.848 35.66719154880191 139.7459912456575 34.848 35.66719154880191 139.7459912456575 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-67248cbf-53cc-41e5-955b-6f172e2bc0cc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-67248cbf-53cc-41e5-955b-6f172e2bc0cc_0">
											<gml:posList>35.66719960743603 139.7459917339418 33.033 35.66720022005713 139.74599130248743 33.033 35.66720022005713 139.74599130248743 34.848 35.66719960743603 139.7459917339418 34.848 35.66719960743603 139.7459917339418 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0749aa29-d242-4e6a-abaa-447c6f490534">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0749aa29-d242-4e6a-abaa-447c6f490534_0">
											<gml:posList>35.66719216205595 139.74599168682235 33.033 35.66719279328135 139.74599205064692 33.033 35.66719279328135 139.74599205064692 34.848 35.66719216205595 139.74599168682235 34.848 35.66719216205595 139.74599168682235 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-005771a6-d478-420a-9870-252511bf9116">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-005771a6-d478-420a-9870-252511bf9116_0">
											<gml:posList>35.66719896771766 139.74599208810486 33.033 35.66719960743603 139.7459917339418 33.033 35.66719960743603 139.7459917339418 34.848 35.66719896771766 139.74599208810486 34.848 35.66719896771766 139.74599208810486 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d034e5b8-df86-48f6-b4d9-a7b178f7b9af">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d034e5b8-df86-48f6-b4d9-a7b178f7b9af_0">
											<gml:posList>35.66719279328135 139.74599205064692 33.033 35.6671934605136 139.7459923481573 33.033 35.6671934605136 139.7459923481573 34.848 35.66719279328135 139.74599205064692 34.848 35.66719279328135 139.74599205064692 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bda61f6b-00da-4aa9-918c-70fce41a7689">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bda61f6b-00da-4aa9-918c-70fce41a7689_0">
											<gml:posList>35.66719830091804 139.74599238706836 33.033 35.66719896771766 139.74599208810486 33.033 35.66719896771766 139.74599208810486 34.848 35.66719830091804 139.74599238706836 34.848 35.66719830091804 139.74599238706836 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2790042d-b2eb-4b2a-a374-dee933df77d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2790042d-b2eb-4b2a-a374-dee933df77d5_0">
											<gml:posList>35.6671934605136 139.7459923481573 33.033 35.667194136711515 139.745992579383 33.033 35.667194136711515 139.745992579383 34.848 35.6671934605136 139.7459923481573 34.848 35.6671934605136 139.7459923481573 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2a968ee3-b98a-4afb-9663-fee954a2ff20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2a968ee3-b98a-4afb-9663-fee954a2ff20_0">
											<gml:posList>35.667197625048615 139.74599260872094 33.033 35.66719830091804 139.74599238706836 33.033 35.66719830091804 139.74599238706836 34.848 35.667197625048615 139.74599260872094 34.848 35.667197625048615 139.74599260872094 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9af7064-a657-45dc-8eb5-c91b4eddb45f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9af7064-a657-45dc-8eb5-c91b4eddb45f_0">
											<gml:posList>35.667194136711515 139.745992579383 33.033 35.66719482186706 139.74599273327826 33.033 35.66719482186706 139.74599273327826 34.848 35.667194136711515 139.745992579383 34.848 35.667194136711515 139.745992579383 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6e0ee4ca-0102-4c7f-ae04-adb1be9fdd3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6e0ee4ca-0102-4c7f-ae04-adb1be9fdd3c_0">
											<gml:posList>35.667196931087624 139.7459927420267 33.033 35.667197625048615 139.74599260872094 33.033 35.667197625048615 139.74599260872094 34.848 35.667196931087624 139.7459927420267 34.848 35.667196931087624 139.7459927420267 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85dfb445-67d4-4b82-a31c-e3bdc3c8a457">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85dfb445-67d4-4b82-a31c-e3bdc3c8a457_0">
											<gml:posList>35.66719482186706 139.74599273327826 33.033 35.66719552499399 139.74599280983313 33.033 35.66719552499399 139.74599280983313 34.848 35.66719482186706 139.74599273327826 34.848 35.66719482186706 139.74599273327826 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c618efa5-2c3b-4c13-b2d0-d6ec838040db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c618efa5-2c3b-4c13-b2d0-d6ec838040db_0">
											<gml:posList>35.66719622807286 139.74599282011317 33.033 35.667196931087624 139.7459927420267 33.033 35.667196931087624 139.7459927420267 34.848 35.66719622807286 139.74599282011317 34.848 35.66719622807286 139.74599282011317 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cf76fe57-f42c-4ab6-9e7e-bedb94341c77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cf76fe57-f42c-4ab6-9e7e-bedb94341c77_0">
											<gml:posList>35.66719552499399 139.74599280983313 33.033 35.66719622807286 139.74599282011317 33.033 35.66719622807286 139.74599282011317 34.848 35.66719552499399 139.74599280983313 34.848 35.66719552499399 139.74599280983313 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-299f7897-8f2a-4816-8c89-38c13a8f0731">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-299f7897-8f2a-4816-8c89-38c13a8f0731_0">
											<gml:posList>35.66712818530837 139.74598305240744 29.1 35.66711925651398 139.74601317301398 29.1 35.66711925651398 139.74601317301398 30.377 35.66712818530837 139.74598305240744 30.377 35.66712818530837 139.74598305240744 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10030045-f2fa-4be7-a8b0-25764f77b353">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10030045-f2fa-4be7-a8b0-25764f77b353_0">
											<gml:posList>35.667133151163625 139.74601935458426 30.377 35.66714207995954 139.74598923397318 30.377 35.66712818530837 139.74598305240744 30.377 35.66711925651398 139.74601317301398 30.377 35.667133151163625 139.74601935458426 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-584fb6b8-7996-4f47-99d8-a9b3c36a11ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-584fb6b8-7996-4f47-99d8-a9b3c36a11ee_0">
											<gml:posList>35.667133151163625 139.74601935458426 29.1 35.66714207995954 139.74598923397318 29.1 35.66714207995954 139.74598923397318 30.377 35.667133151163625 139.74601935458426 30.377 35.667133151163625 139.74601935458426 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-287aaea7-9405-414f-b747-561575069ce0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-287aaea7-9405-414f-b747-561575069ce0_0">
											<gml:posList>35.66711925651398 139.74601317301398 29.1 35.667133151163625 139.74601935458426 29.1 35.667133151163625 139.74601935458426 30.377 35.66711925651398 139.74601317301398 30.377 35.66711925651398 139.74601317301398 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36ae0fbb-9083-46b6-8d7f-84ad08cb8ab6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36ae0fbb-9083-46b6-8d7f-84ad08cb8ab6_0">
											<gml:posList>35.66718150967537 139.74605640483483 29.1 35.6671549003775 139.7460429358101 29.1 35.6671549003775 139.7460429358101 31.432 35.66718150967537 139.74605640483483 31.432 35.66718150967537 139.74605640483483 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-af94043e-a9ee-4a56-83a5-bff342bc6cae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-af94043e-a9ee-4a56-83a5-bff342bc6cae_0">
											<gml:posList>35.6671549003775 139.7460429358101 29.1 35.66714845138456 139.74606205208994 29.1 35.66714845138456 139.74606205208994 31.432 35.6671549003775 139.7460429358101 31.432 35.6671549003775 139.7460429358101 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69069c2e-b0e6-4faa-b8e4-50e7ada6df1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69069c2e-b0e6-4faa-b8e4-50e7ada6df1f_0">
											<gml:posList>35.66711563286974 139.7460627395106 29.1 35.66710585882538 139.7460583870535 29.1 35.66710585882538 139.7460583870535 30.377 35.66711563286974 139.7460627395106 30.377 35.66711563286974 139.7460627395106 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-261112d2-3882-460a-9883-a9e81fea61b6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-261112d2-3882-460a-9883-a9e81fea61b6_0">
											<gml:posList>35.6671787214155 139.74606468118802 29.1 35.66718150967537 139.74605640483483 29.1 35.66718150967537 139.74605640483483 31.432 35.6671787214155 139.74606468118802 31.432 35.6671787214155 139.74606468118802 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f66c232f-75c4-4643-9fd9-1f34c967be7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f66c232f-75c4-4643-9fd9-1f34c967be7f_0">
											<gml:posList>35.6671549003775 139.7460429358101 31.432 35.66714845138456 139.74606205208994 31.432 35.66717506068834 139.74607553216578 31.432 35.6671835637562 139.74607983078258 31.432 35.667187215470015 139.74606897981366 31.432 35.6671787214155 139.74606468118802 31.432 35.66718150967537 139.74605640483483 31.432 35.6671549003775 139.7460429358101 31.432</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e530f23-512f-4b75-a981-18002aeb583f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e530f23-512f-4b75-a981-18002aeb583f_0">
											<gml:posList>35.667187215470015 139.74606897981366 29.1 35.6671787214155 139.74606468118802 29.1 35.6671787214155 139.74606468118802 31.432 35.667187215470015 139.74606897981366 31.432 35.667187215470015 139.74606897981366 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1659dcae-c4b9-4512-8803-128462a0832e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1659dcae-c4b9-4512-8803-128462a0832e_0">
											<gml:posList>35.66714845138456 139.74606205208994 29.1 35.66717506068834 139.74607553216578 29.1 35.66717506068834 139.74607553216578 31.432 35.66714845138456 139.74606205208994 31.432 35.66714845138456 139.74606205208994 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-148dae7e-7115-494e-9881-47ab55446966">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-148dae7e-7115-494e-9881-47ab55446966_0">
											<gml:posList>35.66710585882538 139.7460583870535 29.1 35.667099393755365 139.74608019851507 29.1 35.667099393755365 139.74608019851507 30.377 35.66710585882538 139.7460583870535 30.377 35.66710585882538 139.7460583870535 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3eda887f-9ce8-4980-8a55-0cb5b516a57a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3eda887f-9ce8-4980-8a55-0cb5b516a57a_0">
											<gml:posList>35.66711563286974 139.7460627395106 30.377 35.66710585882538 139.7460583870535 30.377 35.667099393755365 139.74608019851507 30.377 35.6671018102111 139.7460812673291 30.377 35.6671091768127 139.74608455096467 30.377 35.66711563286974 139.7460627395106 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-408597c0-3215-45be-87ad-167a1668bb33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-408597c0-3215-45be-87ad-167a1668bb33_0">
											<gml:posList>35.6671091768127 139.74608455096467 29.1 35.66711563286974 139.7460627395106 29.1 35.66711563286974 139.7460627395106 30.377 35.6671091768127 139.74608455096467 30.377 35.6671091768127 139.74608455096467 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0d2ba93d-6b3e-4f62-871f-90b59d9bfbfd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0d2ba93d-6b3e-4f62-871f-90b59d9bfbfd_0">
											<gml:posList>35.6671835637562 139.74607983078258 29.1 35.667187215470015 139.74606897981366 29.1 35.667187215470015 139.74606897981366 31.432 35.6671835637562 139.74607983078258 31.432 35.6671835637562 139.74607983078258 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5dee799b-35cb-43e8-8c70-7a0122dbd4b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5dee799b-35cb-43e8-8c70-7a0122dbd4b3_0">
											<gml:posList>35.6671835637562 139.74607983078258 29.1 35.6671835637562 139.74607983078258 31.432 35.66717506068834 139.74607553216578 31.432 35.66717506068834 139.74607553216578 29.1 35.6671835637562 139.74607983078258 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bfbed707-da9f-4986-a936-d9c8461da575">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bfbed707-da9f-4986-a936-d9c8461da575_0">
											<gml:posList>35.667099393755365 139.74608019851507 29.1 35.6671018102111 139.7460812673291 29.1 35.6671018102111 139.7460812673291 30.377 35.667099393755365 139.74608019851507 30.377 35.667099393755365 139.74608019851507 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9e5fa68f-bb22-41e5-8335-0487c4501659">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9e5fa68f-bb22-41e5-8335-0487c4501659_0">
											<gml:posList>35.6671018102111 139.7460812673291 30.377 35.6671018102111 139.7460812673291 29.1 35.6671091768127 139.74608455096467 29.1 35.6671091768127 139.74608455096467 30.377 35.6671018102111 139.7460812673291 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb971e2d-61d1-4f97-a4c5-af23846b0923">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb971e2d-61d1-4f97-a4c5-af23846b0923_0">
											<gml:posList>35.667209033782825 139.74608841881002 29.1 35.667204958032805 139.74608629140076 29.1 35.667204958032805 139.74608629140076 30.344 35.667209033782825 139.74608841881002 30.344 35.667209033782825 139.74608841881002 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-89d12762-2076-425a-a28b-3fc5d4a0405b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-89d12762-2076-425a-a28b-3fc5d4a0405b_0">
											<gml:posList>35.66721808783999 139.74609430742922 29.1 35.667213975955136 139.7460920696005 29.1 35.667213975955136 139.7460920696005 30.344 35.66721808783999 139.74609430742922 30.344 35.66721808783999 139.74609430742922 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7369d208-7482-4063-87bb-9a4f89f9df7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7369d208-7482-4063-87bb-9a4f89f9df7f_0">
											<gml:posList>35.667204958032805 139.74608629140076 29.1 35.667187489902915 139.74613674562173 29.1 35.667187489902915 139.74613674562173 30.344 35.667204958032805 139.74608629140076 30.344 35.667204958032805 139.74608629140076 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f7af5cc7-3b6f-48fb-a5d6-966600fc46f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f7af5cc7-3b6f-48fb-a5d6-966600fc46f9_0">
											<gml:posList>35.667209033782825 139.74608841881002 30.344 35.667204958032805 139.74608629140076 30.344 35.667187489902915 139.74613674562173 30.344 35.66719156564405 139.74613886198728 30.344 35.667209033782825 139.74608841881002 30.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e5e07f5-a6d7-4c22-9969-ef3dcee735c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e5e07f5-a6d7-4c22-9969-ef3dcee735c6_0">
											<gml:posList>35.667209033782825 139.74608841881002 29.1 35.667209033782825 139.74608841881002 30.344 35.66719156564405 139.74613886198728 30.344 35.66719156564405 139.74613886198728 29.1 35.667209033782825 139.74608841881002 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-52040afb-16dc-4ced-b846-e501823ab75f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-52040afb-16dc-4ced-b846-e501823ab75f_0">
											<gml:posList>35.66720066301591 139.7461423315288 30.344 35.66721808783999 139.74609430742922 30.344 35.667213975955136 139.7460920696005 30.344 35.667196551123936 139.7461400826523 30.344 35.66720066301591 139.7461423315288 30.344</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8455ed97-e1cb-4576-8959-bcd1b1d81123">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8455ed97-e1cb-4576-8959-bcd1b1d81123_0">
											<gml:posList>35.66721808783999 139.74609430742922 29.1 35.66721808783999 139.74609430742922 30.344 35.66720066301591 139.7461423315288 30.344 35.66720066301591 139.7461423315288 29.1 35.66721808783999 139.74609430742922 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99effcd9-b4c4-40a5-b28d-52f50507ee43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99effcd9-b4c4-40a5-b28d-52f50507ee43_0">
											<gml:posList>35.667187489902915 139.74613674562173 29.1 35.66719156564405 139.74613886198728 29.1 35.66719156564405 139.74613886198728 30.344 35.667187489902915 139.74613674562173 30.344 35.667187489902915 139.74613674562173 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-020bcf33-db1f-4fd3-8d16-f815a9486942">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-020bcf33-db1f-4fd3-8d16-f815a9486942_0">
											<gml:posList>35.667196551123936 139.7461400826523 29.1 35.66720066301591 139.7461423315288 29.1 35.66720066301591 139.7461423315288 30.344 35.667196551123936 139.7461400826523 30.344 35.667196551123936 139.7461400826523 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6625cec6-bd40-47e2-a8ac-343770be9ec4_BuildingInstallation_1061">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-489c967c-3d32-46ee-9f59-fc02ce781c5f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667302070977584 139.74591085518335 29.1 35.667213781501246 139.74615961502454 29.1 35.66709653892174 139.74609611863025 29.1 35.6671018102111 139.7460812673291 29.1 35.66710428978692 139.7460823692119 29.1 35.66709968428905 139.74609552978052 29.1 35.66721183207289 139.74615621503014 29.1 35.66725052079952 139.74604667566743 29.1 35.667214478960204 139.74602745098358 29.1 35.66726320684933 139.74589029708042 29.1 35.667203583814384 139.74585695953195 29.1 35.66720419550419 139.74585524676218 29.1 35.667302070977584 139.74591085518335 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c4517af-9e3d-4234-9ba4-2930aafc21bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c4517af-9e3d-4234-9ba4-2930aafc21bb_0">
											<gml:posList>35.66720419550419 139.74585524676218 29.1 35.667203583814384 139.74585695953195 29.1 35.667203583814384 139.74585695953195 30.377 35.66720419550419 139.74585524676218 30.377 35.66720419550419 139.74585524676218 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72613301-b64b-4023-8d21-55ed24477681">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72613301-b64b-4023-8d21-55ed24477681_0">
											<gml:posList>35.66726320684933 139.74589029708042 29.1 35.66726320684933 139.74589029708042 30.377 35.667203583814384 139.74585695953195 30.377 35.667203583814384 139.74585695953195 29.1 35.66726320684933 139.74589029708042 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60790f07-bd47-43b7-9579-3b5869a50da7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60790f07-bd47-43b7-9579-3b5869a50da7_0">
											<gml:posList>35.66720419550419 139.74585524676218 29.1 35.66720419550419 139.74585524676218 30.377 35.667302070977584 139.74591085518335 30.377 35.667302070977584 139.74591085518335 29.1 35.66720419550419 139.74585524676218 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b4e78eb7-5150-4ae1-b134-b71db4e36938">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b4e78eb7-5150-4ae1-b134-b71db4e36938_0">
											<gml:posList>35.667214478960204 139.74602745098358 29.1 35.667214478960204 139.74602745098358 30.377 35.66726320684933 139.74589029708042 30.377 35.66726320684933 139.74589029708042 29.1 35.667214478960204 139.74602745098358 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8be9b042-fbf7-40ea-8cd3-da2a005aecce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8be9b042-fbf7-40ea-8cd3-da2a005aecce_0">
											<gml:posList>35.667203583814384 139.74585695953195 30.377 35.66726320684933 139.74589029708042 30.377 35.667214478960204 139.74602745098358 30.377 35.66725052079952 139.74604667566743 30.377 35.66721183207289 139.74615621503014 30.377 35.66709968428905 139.74609552978052 30.377 35.66710428978692 139.7460823692119 30.377 35.6671018102111 139.7460812673291 30.377 35.66709653892174 139.74609611863025 30.377 35.667213781501246 139.74615961502454 30.377 35.667302070977584 139.74591085518335 30.377 35.66720419550419 139.74585524676218 30.377 35.667203583814384 139.74585695953195 30.377</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c37e536f-642d-4e7c-993e-8bfbc5440a45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c37e536f-642d-4e7c-993e-8bfbc5440a45_0">
											<gml:posList>35.667302070977584 139.74591085518335 29.1 35.667302070977584 139.74591085518335 30.377 35.667213781501246 139.74615961502454 30.377 35.667213781501246 139.74615961502454 29.1 35.667302070977584 139.74591085518335 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a2faa7b-15f0-40f5-a907-e3b3b0349900">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a2faa7b-15f0-40f5-a907-e3b3b0349900_0">
											<gml:posList>35.667214478960204 139.74602745098358 29.1 35.66725052079952 139.74604667566743 29.1 35.66725052079952 139.74604667566743 30.377 35.667214478960204 139.74602745098358 30.377 35.667214478960204 139.74602745098358 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b2ddeed-1286-4cd3-9037-432c4cdff049">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b2ddeed-1286-4cd3-9037-432c4cdff049_0">
											<gml:posList>35.66710428978692 139.7460823692119 29.1 35.6671018102111 139.7460812673291 29.1 35.6671018102111 139.7460812673291 30.377 35.66710428978692 139.7460823692119 30.377 35.66710428978692 139.7460823692119 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a573c08c-8b6d-4419-92f7-59a0813cb700">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a573c08c-8b6d-4419-92f7-59a0813cb700_0">
											<gml:posList>35.66709653892174 139.74609611863025 29.1 35.66709653892174 139.74609611863025 30.377 35.6671018102111 139.7460812673291 30.377 35.6671018102111 139.7460812673291 29.1 35.66709653892174 139.74609611863025 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e203c48d-7256-41b9-840b-a103bd866aea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e203c48d-7256-41b9-840b-a103bd866aea_0">
											<gml:posList>35.66709968428905 139.74609552978052 29.1 35.66710428978692 139.7460823692119 29.1 35.66710428978692 139.7460823692119 30.377 35.66709968428905 139.74609552978052 30.377 35.66709968428905 139.74609552978052 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0321152-f901-4104-abf6-c14e8efe9703">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0321152-f901-4104-abf6-c14e8efe9703_0">
											<gml:posList>35.66721183207289 139.74615621503014 29.1 35.66721183207289 139.74615621503014 30.377 35.66725052079952 139.74604667566743 30.377 35.66725052079952 139.74604667566743 29.1 35.66721183207289 139.74615621503014 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-306bcf61-1638-48e9-bf50-8f68c0c1ceda">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-306bcf61-1638-48e9-bf50-8f68c0c1ceda_0">
											<gml:posList>35.66721183207289 139.74615621503014 29.1 35.66709968428905 139.74609552978052 29.1 35.66709968428905 139.74609552978052 30.377 35.66721183207289 139.74615621503014 30.377 35.66721183207289 139.74615621503014 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ca397a92-911a-486c-af47-4f115e7d9163">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ca397a92-911a-486c-af47-4f115e7d9163_0">
											<gml:posList>35.66709653892174 139.74609611863025 29.1 35.667213781501246 139.74615961502454 29.1 35.667213781501246 139.74615961502454 30.377 35.66709653892174 139.74609611863025 30.377 35.66709653892174 139.74609611863025 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-0cdb6252-912a-4168-bfcf-ba7dd6580f5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0cdb6252-912a-4168-bfcf-ba7dd6580f5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0cdb6252-912a-4168-bfcf-ba7dd6580f5f">
											<gml:posList>35.66725930786806 139.74619419420858 7.47 35.66709482595313 139.7460956234325 7.47 35.667172865077426 139.74583225041056 7.47 35.667206211345565 139.74585079309648 7.47 35.66720889911548 139.74584069428187 7.47 35.66734737136638 139.74594446247625 7.47 35.66725930786806 139.74619419420858 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ed592c99-d04a-40de-90d8-fd27fd4395be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ed592c99-d04a-40de-90d8-fd27fd4395be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ed592c99-d04a-40de-90d8-fd27fd4395be">
											<gml:posList>35.6671511964768 139.74603152951505 34.848 35.66715600808627 139.7460291494261 34.848 35.66718496270756 139.74594561150386 34.848 35.66718302047517 139.74593971515287 34.848 35.6671511964768 139.74603152951505 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8bc77de9-c570-4d70-a295-14ef91f37fa8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8bc77de9-c570-4d70-a295-14ef91f37fa8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8bc77de9-c570-4d70-a295-14ef91f37fa8">
											<gml:posList>35.66719060136541 139.74605203184015 34.848 35.66718865914625 139.74604614653197 34.848 35.66715600808627 139.7460291494261 34.848 35.6671511964768 139.74603152951505 34.848 35.66719060136541 139.74605203184015 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-08aec548-eb76-4b08-9250-cb891186ced4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08aec548-eb76-4b08-9250-cb891186ced4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08aec548-eb76-4b08-9250-cb891186ced4">
											<gml:posList>35.66718302047517 139.74593971515287 29.1 35.667172865077426 139.74583225041056 29.1 35.66709482595313 139.7460956234325 29.1 35.66725930786806 139.74619419420858 29.1 35.66719060136541 139.74605203184015 29.1 35.6671511964768 139.74603152951505 29.1 35.66718302047517 139.74593971515287 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ec572ee9-15e6-4577-97e0-5c29e7944ace">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec572ee9-15e6-4577-97e0-5c29e7944ace">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec572ee9-15e6-4577-97e0-5c29e7944ace">
											<gml:posList>35.66721761377913 139.74596260858178 33.033 35.66718496270756 139.74594561150386 33.033 35.66715600808627 139.7460291494261 33.033 35.66718865914625 139.74604614653197 33.033 35.66721761377913 139.74596260858178 33.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-861aa56d-2188-4056-9a34-9dd3cc4a2ad4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-861aa56d-2188-4056-9a34-9dd3cc4a2ad4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-861aa56d-2188-4056-9a34-9dd3cc4a2ad4">
											<gml:posList>35.66718302047517 139.74593971515287 34.848 35.66718496270756 139.74594561150386 34.848 35.66721761377913 139.74596260858178 34.848 35.66722241637345 139.74596022849656 34.848 35.66718302047517 139.74593971515287 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-89a84fd4-bbe6-4751-9180-06ed53cc07fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-89a84fd4-bbe6-4751-9180-06ed53cc07fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-89a84fd4-bbe6-4751-9180-06ed53cc07fb">
											<gml:posList>35.66722241637345 139.74596022849656 34.848 35.66721761377913 139.74596260858178 34.848 35.66718865914625 139.74604614653197 34.848 35.66719060136541 139.74605203184015 34.848 35.66722241637345 139.74596022849656 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e5b88da9-1f61-4ae4-9aa3-9d45e5af3732">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e5b88da9-1f61-4ae4-9aa3-9d45e5af3732">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e5b88da9-1f61-4ae4-9aa3-9d45e5af3732">
											<gml:posList>35.667206211345565 139.74585079309648 29.1 35.667172865077426 139.74583225041056 29.1 35.66718302047517 139.74593971515287 29.1 35.66722241637345 139.74596022849656 29.1 35.66719060136541 139.74605203184015 29.1 35.66725930786806 139.74619419420858 29.1 35.66734737136638 139.74594446247625 29.1 35.66720889911548 139.74584069428187 29.1 35.667206211345565 139.74585079309648 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f340f693-72bf-4ebd-b5d5-1c65be88e298">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f340f693-72bf-4ebd-b5d5-1c65be88e298">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f340f693-72bf-4ebd-b5d5-1c65be88e298">
											<gml:posList>35.66709482595313 139.7460956234325 29.1 35.667172865077426 139.74583225041056 29.1 35.667172865077426 139.74583225041056 7.47 35.66709482595313 139.7460956234325 7.47 35.66709482595313 139.7460956234325 29.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c793e423-675c-4bfd-90cf-29ad6cac60cf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c793e423-675c-4bfd-90cf-29ad6cac60cf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c793e423-675c-4bfd-90cf-29ad6cac60cf">
											<gml:posList>35.6671511964768 139.74603152951505 34.848 35.66718302047517 139.74593971515287 34.848 35.66718302047517 139.74593971515287 29.1 35.6671511964768 139.74603152951505 29.1 35.6671511964768 139.74603152951505 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e147afba-934f-4114-a64f-9fa3ad76e2a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e147afba-934f-4114-a64f-9fa3ad76e2a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e147afba-934f-4114-a64f-9fa3ad76e2a1">
											<gml:posList>35.66715600808627 139.7460291494261 34.848 35.66715600808627 139.7460291494261 33.033 35.66718496270756 139.74594561150386 33.033 35.66718496270756 139.74594561150386 34.848 35.66715600808627 139.7460291494261 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d1f29866-616a-40d0-b6f1-21952946032f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1f29866-616a-40d0-b6f1-21952946032f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1f29866-616a-40d0-b6f1-21952946032f">
											<gml:posList>35.66719060136541 139.74605203184015 34.848 35.6671511964768 139.74603152951505 34.848 35.6671511964768 139.74603152951505 29.1 35.66719060136541 139.74605203184015 29.1 35.66719060136541 139.74605203184015 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-56b57d78-3517-46ad-8e38-53606022067b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-56b57d78-3517-46ad-8e38-53606022067b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-56b57d78-3517-46ad-8e38-53606022067b">
											<gml:posList>35.66718865914625 139.74604614653197 34.848 35.66718865914625 139.74604614653197 33.033 35.66715600808627 139.7460291494261 33.033 35.66715600808627 139.7460291494261 34.848 35.66718865914625 139.74604614653197 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb30f29d-dcd8-466c-882a-df8a72029eb7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb30f29d-dcd8-466c-882a-df8a72029eb7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb30f29d-dcd8-466c-882a-df8a72029eb7">
											<gml:posList>35.66709482595313 139.7460956234325 7.47 35.66725930786806 139.74619419420858 7.47 35.66725930786806 139.74619419420858 29.1 35.66709482595313 139.7460956234325 29.1 35.66709482595313 139.7460956234325 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d5bfea36-3083-4144-b625-b19de0f83c80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5bfea36-3083-4144-b625-b19de0f83c80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5bfea36-3083-4144-b625-b19de0f83c80">
											<gml:posList>35.667206211345565 139.74585079309648 7.47 35.667172865077426 139.74583225041056 7.47 35.667172865077426 139.74583225041056 29.1 35.667206211345565 139.74585079309648 29.1 35.667206211345565 139.74585079309648 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dda684be-99e1-443a-bb64-7819086745c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dda684be-99e1-443a-bb64-7819086745c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dda684be-99e1-443a-bb64-7819086745c6">
											<gml:posList>35.66718496270756 139.74594561150386 34.848 35.66718496270756 139.74594561150386 33.033 35.66721761377913 139.74596260858178 33.033 35.66721761377913 139.74596260858178 34.848 35.66718496270756 139.74594561150386 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77d6e538-6bfc-4811-9187-e0591a38d3b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77d6e538-6bfc-4811-9187-e0591a38d3b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77d6e538-6bfc-4811-9187-e0591a38d3b6">
											<gml:posList>35.66718302047517 139.74593971515287 34.848 35.66722241637345 139.74596022849656 34.848 35.66722241637345 139.74596022849656 29.1 35.66718302047517 139.74593971515287 29.1 35.66718302047517 139.74593971515287 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e571611-8def-477e-8c32-0d4495d37b89">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e571611-8def-477e-8c32-0d4495d37b89">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e571611-8def-477e-8c32-0d4495d37b89">
											<gml:posList>35.66721761377913 139.74596260858178 34.848 35.66721761377913 139.74596260858178 33.033 35.66718865914625 139.74604614653197 33.033 35.66718865914625 139.74604614653197 34.848 35.66721761377913 139.74596260858178 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2144640b-5fb4-4f72-b927-b519377d5ada">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2144640b-5fb4-4f72-b927-b519377d5ada">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2144640b-5fb4-4f72-b927-b519377d5ada">
											<gml:posList>35.66722241637345 139.74596022849656 34.848 35.66719060136541 139.74605203184015 34.848 35.66719060136541 139.74605203184015 29.1 35.66722241637345 139.74596022849656 29.1 35.66722241637345 139.74596022849656 34.848</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d86d1e91-61e4-44a1-adff-c5009afd03b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d86d1e91-61e4-44a1-adff-c5009afd03b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d86d1e91-61e4-44a1-adff-c5009afd03b3">
											<gml:posList>35.66720889911548 139.74584069428187 7.47 35.667206211345565 139.74585079309648 7.47 35.667206211345565 139.74585079309648 29.1 35.66720889911548 139.74584069428187 29.1 35.66720889911548 139.74584069428187 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad1baa36-9c86-4557-a2ed-2a01a16ac5c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad1baa36-9c86-4557-a2ed-2a01a16ac5c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad1baa36-9c86-4557-a2ed-2a01a16ac5c6">
											<gml:posList>35.66734737136638 139.74594446247625 7.47 35.66720889911548 139.74584069428187 7.47 35.66720889911548 139.74584069428187 29.1 35.66734737136638 139.74594446247625 29.1 35.66734737136638 139.74594446247625 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-accf0ed7-ed56-4236-8a83-f393a4db1de1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-accf0ed7-ed56-4236-8a83-f393a4db1de1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-accf0ed7-ed56-4236-8a83-f393a4db1de1">
											<gml:posList>35.66725930786806 139.74619419420858 7.47 35.66734737136638 139.74594446247625 7.47 35.66734737136638 139.74594446247625 29.1 35.66725930786806 139.74619419420858 29.1 35.66725930786806 139.74619419420858 7.47</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門三丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-1161</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">540.49205</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>