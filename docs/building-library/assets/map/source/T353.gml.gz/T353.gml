<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6630be0c-c481-403e-b569-2fd083628db1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">7.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>1</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669467047706924 139.74796414716837 0 35.669445910072795 139.7480271326232 0 35.66950393653028 139.74812339322315 0 35.669538401123454 139.74809238320816 0 35.66957670191536 139.74815811126388 0 35.66961165297683 139.74812670305704 0 35.66963628959614 139.74816787904408 0 35.66971727148235 139.74809499877367 0 35.66969344716897 139.74805536836675 0 35.66972209258603 139.74802960032486 0 35.66961479217209 139.74785032492986 0 35.66957855300398 139.7478828392461 0 35.66955175083623 139.7478386279952 0 35.66948129939358 139.74790197538525 0 35.66950037624777 139.74793274064825 0 35.669467047706924 139.74796414716837 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669467047706924 139.74796414716837 6.424 35.66950037624777 139.74793274064825 6.424 35.66948129939358 139.74790197538525 6.424 35.66955175083623 139.7478386279952 6.424 35.66957855300398 139.7478828392461 6.424 35.66961479217209 139.74785032492986 6.424 35.66972209258603 139.74802960032486 6.424 35.66969344716897 139.74805536836675 6.424 35.66971727148235 139.74809499877367 6.424 35.66963628959614 139.74816787904408 6.424 35.66961165297683 139.74812670305704 6.424 35.66957670191536 139.74815811126388 6.424 35.669538401123454 139.74809238320816 6.424 35.66950393653028 139.74812339322315 6.424 35.669445910072795 139.7480271326232 6.424 35.669467047706924 139.74796414716837 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669467047706924 139.74796414716837 6.424 35.669445910072795 139.7480271326232 6.424 35.669445910072795 139.7480271326232 13.48 35.669467047706924 139.74796414716837 13.48 35.669467047706924 139.74796414716837 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669445910072795 139.7480271326232 6.424 35.66950393653028 139.74812339322315 6.424 35.66950393653028 139.74812339322315 13.48 35.669445910072795 139.7480271326232 13.48 35.669445910072795 139.7480271326232 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950393653028 139.74812339322315 6.424 35.669538401123454 139.74809238320816 6.424 35.669538401123454 139.74809238320816 13.48 35.66950393653028 139.74812339322315 13.48 35.66950393653028 139.74812339322315 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669538401123454 139.74809238320816 6.424 35.66957670191536 139.74815811126388 6.424 35.66957670191536 139.74815811126388 13.48 35.669538401123454 139.74809238320816 13.48 35.669538401123454 139.74809238320816 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66957670191536 139.74815811126388 6.424 35.66961165297683 139.74812670305704 6.424 35.66961165297683 139.74812670305704 13.48 35.66957670191536 139.74815811126388 13.48 35.66957670191536 139.74815811126388 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66961165297683 139.74812670305704 6.424 35.66963628959614 139.74816787904408 6.424 35.66963628959614 139.74816787904408 13.48 35.66961165297683 139.74812670305704 13.48 35.66961165297683 139.74812670305704 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66963628959614 139.74816787904408 6.424 35.66971727148235 139.74809499877367 6.424 35.66971727148235 139.74809499877367 13.48 35.66963628959614 139.74816787904408 13.48 35.66963628959614 139.74816787904408 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66971727148235 139.74809499877367 6.424 35.66969344716897 139.74805536836675 6.424 35.66969344716897 139.74805536836675 13.48 35.66971727148235 139.74809499877367 13.48 35.66971727148235 139.74809499877367 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66969344716897 139.74805536836675 6.424 35.66972209258603 139.74802960032486 6.424 35.66972209258603 139.74802960032486 13.48 35.66969344716897 139.74805536836675 13.48 35.66969344716897 139.74805536836675 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66972209258603 139.74802960032486 6.424 35.66961479217209 139.74785032492986 6.424 35.66961479217209 139.74785032492986 13.48 35.66972209258603 139.74802960032486 13.48 35.66972209258603 139.74802960032486 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66961479217209 139.74785032492986 6.424 35.66957855300398 139.7478828392461 6.424 35.66957855300398 139.7478828392461 13.48 35.66961479217209 139.74785032492986 13.48 35.66961479217209 139.74785032492986 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66957855300398 139.7478828392461 6.424 35.66955175083623 139.7478386279952 6.424 35.66955175083623 139.7478386279952 13.48 35.66957855300398 139.7478828392461 13.48 35.66957855300398 139.7478828392461 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66955175083623 139.7478386279952 6.424 35.66948129939358 139.74790197538525 6.424 35.66948129939358 139.74790197538525 13.48 35.66955175083623 139.7478386279952 13.48 35.66955175083623 139.7478386279952 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66948129939358 139.74790197538525 6.424 35.66950037624777 139.74793274064825 6.424 35.66950037624777 139.74793274064825 13.48 35.66948129939358 139.74790197538525 13.48 35.66948129939358 139.74790197538525 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66950037624777 139.74793274064825 6.424 35.669467047706924 139.74796414716837 6.424 35.669467047706924 139.74796414716837 13.48 35.66950037624777 139.74793274064825 13.48 35.66950037624777 139.74793274064825 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669467047706924 139.74796414716837 13.48 35.669445910072795 139.7480271326232 13.48 35.66950393653028 139.74812339322315 13.48 35.669538401123454 139.74809238320816 13.48 35.66957670191536 139.74815811126388 13.48 35.66961165297683 139.74812670305704 13.48 35.66963628959614 139.74816787904408 13.48 35.66971727148235 139.74809499877367 13.48 35.66969344716897 139.74805536836675 13.48 35.66972209258603 139.74802960032486 13.48 35.66961479217209 139.74785032492986 13.48 35.66957855300398 139.7478828392461 13.48 35.66955175083623 139.7478386279952 13.48 35.66948129939358 139.74790197538525 13.48 35.66950037624777 139.74793274064825 13.48 35.669467047706924 139.74796414716837 13.48</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-070a54b3-a1b5-4b5e-b845-7b89b12dfc31"/>
							<gml:surfaceMember xlink:href="#poly-26837a3e-42d5-4658-8250-47338b7a7d7a"/>
							<gml:surfaceMember xlink:href="#poly-982c0716-6b9b-4cef-a66b-4ff735c53deb"/>
							<gml:surfaceMember xlink:href="#poly-2ef2234b-c524-487a-af8e-e1383cb2fd2a"/>
							<gml:surfaceMember xlink:href="#poly-3002ac78-3f3d-445a-bd3a-13c0a64d636b"/>
							<gml:surfaceMember xlink:href="#poly-8d167883-7eb0-4849-895a-292c217f7521"/>
							<gml:surfaceMember xlink:href="#poly-7238d339-6271-4a10-be35-c1f9e9019c1c"/>
							<gml:surfaceMember xlink:href="#poly-850b5eb8-f276-4ee0-bd49-3e77d0c4ae00"/>
							<gml:surfaceMember xlink:href="#poly-22b46c55-0082-419d-a817-e83508ac839a"/>
							<gml:surfaceMember xlink:href="#poly-81039175-74a8-467a-b16a-92473b11f3a0"/>
							<gml:surfaceMember xlink:href="#poly-98a814dc-06ad-4f11-b7d0-85f6c59632e2"/>
							<gml:surfaceMember xlink:href="#poly-aa4b3457-1aaf-4456-a8c8-1abca4646351"/>
							<gml:surfaceMember xlink:href="#poly-6180b1dc-0ca6-4e33-b287-d0a506fe5181"/>
							<gml:surfaceMember xlink:href="#poly-2beaa833-be27-4b25-8f1b-6bb4d1d66d56"/>
							<gml:surfaceMember xlink:href="#poly-8708226c-7f48-4362-8d67-ff3ec44e4ec0"/>
							<gml:surfaceMember xlink:href="#poly-6e1291ca-b73b-44bb-9ee8-08245e76bf19"/>
							<gml:surfaceMember xlink:href="#poly-0c227d2d-c6c2-4610-a89e-2471b67676b9"/>
							<gml:surfaceMember xlink:href="#poly-eefbf0a2-ad74-41b2-b6d3-06dd9b74054f"/>
							<gml:surfaceMember xlink:href="#poly-44255031-4d4e-444d-a390-7626151315b6"/>
							<gml:surfaceMember xlink:href="#poly-b83ca9ed-81f8-4edd-8eb9-4a9b549858cb"/>
							<gml:surfaceMember xlink:href="#poly-12ad0a8f-f7b3-450b-90f5-4ef55584d64b"/>
							<gml:surfaceMember xlink:href="#poly-71dac2f1-7edf-4f7c-90fa-39cd6455cb37"/>
							<gml:surfaceMember xlink:href="#poly-a83f2e10-f922-4e71-9eb3-ceb3daf7c03a"/>
							<gml:surfaceMember xlink:href="#poly-096bcae5-8937-4a9c-9cf8-9558d6bf7347"/>
							<gml:surfaceMember xlink:href="#poly-459121fc-eee5-4ff6-abbf-965d7015757d"/>
							<gml:surfaceMember xlink:href="#poly-38db97d1-7287-41ad-93dd-2874ef188258"/>
							<gml:surfaceMember xlink:href="#poly-dbf1ccca-8d0f-4ed4-b626-8b372e444917"/>
							<gml:surfaceMember xlink:href="#poly-7b0db7ae-b624-4cd4-b521-4e649b836d68"/>
							<gml:surfaceMember xlink:href="#poly-333496d9-123d-48ae-907c-f3681f3021c7"/>
							<gml:surfaceMember xlink:href="#poly-26fe8f4c-84e4-4ab3-8312-ca7d79eca5c9"/>
							<gml:surfaceMember xlink:href="#poly-ccf3d3fc-fd8a-4e86-acb3-0914bc92800c"/>
							<gml:surfaceMember xlink:href="#poly-08c8c010-040b-44c2-85f0-95e9804a3ac2"/>
							<gml:surfaceMember xlink:href="#poly-d254a32b-b0a3-4e91-b108-06cab455c6de"/>
							<gml:surfaceMember xlink:href="#poly-86cd1f4b-ace1-41d5-a26d-c9ee2ddd3f6e"/>
							<gml:surfaceMember xlink:href="#poly-25dccc98-d75a-4d5e-bc66-fd93eed8e90c"/>
							<gml:surfaceMember xlink:href="#poly-2487dc18-7778-4823-9824-726aaf6f8afc"/>
							<gml:surfaceMember xlink:href="#poly-ccd5c291-9ca6-4124-b857-2875ca7b2191"/>
							<gml:surfaceMember xlink:href="#poly-b455755f-5677-4f91-a97d-9c8c59f2ff8c"/>
							<gml:surfaceMember xlink:href="#poly-920d53d3-24ff-467e-a3a5-49609bf56d64"/>
							<gml:surfaceMember xlink:href="#poly-8a087cd4-98fb-429d-95e6-017ab67678a3"/>
							<gml:surfaceMember xlink:href="#poly-7b48b3a3-aa08-4131-b442-990cea0236fb"/>
							<gml:surfaceMember xlink:href="#poly-988a5955-b782-45ab-b57d-e2786f4bf4ac"/>
							<gml:surfaceMember xlink:href="#poly-21ca65be-df7d-4e1a-9fd1-578a133d1905"/>
							<gml:surfaceMember xlink:href="#poly-5a581396-fb87-418d-9153-2cdcc0a08cb9"/>
							<gml:surfaceMember xlink:href="#poly-1a041d6d-7236-4839-a237-0990bf4ff4b7"/>
							<gml:surfaceMember xlink:href="#poly-aea1666a-ba8c-4ce7-a57c-7628cb5590d5"/>
							<gml:surfaceMember xlink:href="#poly-91d62bd0-de52-4d5f-9c16-e97da4d2c269"/>
							<gml:surfaceMember xlink:href="#poly-3cee5feb-4adb-49c1-9084-5b5ccded5b45"/>
							<gml:surfaceMember xlink:href="#poly-d172ceb3-06ee-4b94-9797-222bf0277bb0"/>
							<gml:surfaceMember xlink:href="#poly-442a797c-07d5-46fe-bbe5-384aa90a0ce6"/>
							<gml:surfaceMember xlink:href="#poly-79669dab-1c56-4da6-8eaa-b4b2cc08f081"/>
							<gml:surfaceMember xlink:href="#poly-c80ad45d-2e28-44c8-98bb-81de59bcd0b3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-070a54b3-a1b5-4b5e-b845-7b89b12dfc31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-070a54b3-a1b5-4b5e-b845-7b89b12dfc31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-070a54b3-a1b5-4b5e-b845-7b89b12dfc31">
											<gml:posList>35.66950037624775 139.74793274064825 6.424 35.66948129939354 139.74790197538525 6.424 35.669551750836206 139.7478386279952 6.424 35.669578553003966 139.74788283924607 6.424 35.66961479217208 139.74785032492986 6.424 35.66972209258601 139.74802960032486 6.424 35.669693447168946 139.74805536836672 6.424 35.669717271482334 139.74809499877367 6.424 35.669636289596134 139.74816787904405 6.424 35.669611652976826 139.74812670305707 6.424 35.66957670191534 139.74815811126388 6.424 35.669538401123475 139.74809238320816 6.424 35.66950393653029 139.74812339322315 6.424 35.66944591007277 139.7480271326232 6.424 35.66946704770692 139.74796414716835 6.424 35.66950037624775 139.74793274064825 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26837a3e-42d5-4658-8250-47338b7a7d7a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26837a3e-42d5-4658-8250-47338b7a7d7a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26837a3e-42d5-4658-8250-47338b7a7d7a">
											<gml:posList>35.66952568867338 139.74797350709179 11.799 35.66950039425952 139.7479327185368 11.799 35.66946704770692 139.74796414716835 11.799 35.66944591007277 139.7480271326232 11.799 35.66946397679459 139.74805710365519 11.799 35.66949926094697 139.74802514278727 11.799 35.66948750176293 139.7480049740059 11.799 35.66952568867338 139.74797350709179 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-982c0716-6b9b-4cef-a66b-4ff735c53deb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-982c0716-6b9b-4cef-a66b-4ff735c53deb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-982c0716-6b9b-4cef-a66b-4ff735c53deb">
											<gml:posList>35.66948203774411 139.74804074721052 13.442 35.66946397679459 139.74805710365519 12.138 35.66950393653029 139.74812339322315 12.138 35.66952188945689 139.7481072246845 13.442 35.66948203774411 139.74804074721052 13.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ef2234b-c524-487a-af8e-e1383cb2fd2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ef2234b-c524-487a-af8e-e1383cb2fd2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ef2234b-c524-487a-af8e-e1383cb2fd2a">
											<gml:posList>35.66948203774411 139.74804074721052 13.442 35.66953842814902 139.74809236108715 12.138 35.66949926094697 139.74802514278727 11.799 35.66948203774411 139.74804074721052 13.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3002ac78-3f3d-445a-bd3a-13c0a64d636b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3002ac78-3f3d-445a-bd3a-13c0a64d636b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3002ac78-3f3d-445a-bd3a-13c0a64d636b">
											<gml:posList>35.66948203774411 139.74804074721052 13.442 35.66952188945689 139.7481072246845 13.442 35.66953842814902 139.74809236108715 12.138 35.66948203774411 139.74804074721052 13.442</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d167883-7eb0-4849-895a-292c217f7521">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d167883-7eb0-4849-895a-292c217f7521">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d167883-7eb0-4849-895a-292c217f7521">
											<gml:posList>35.66950251487448 139.74793608535057 18.053 35.66957255189163 139.747873003523 18.053 35.66955173281659 139.74783863906057 14.163 35.669481326419046 139.74790195326415 14.163 35.66950251487448 139.74793608535057 18.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7238d339-6271-4a10-be35-c1f9e9019c1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7238d339-6271-4a10-be35-c1f9e9019c1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7238d339-6271-4a10-be35-c1f9e9019c1c">
											<gml:posList>35.66957255189163 139.747873003523 18.053 35.66950251487448 139.74793608535057 18.053 35.669525697687114 139.7479735070822 14.163 35.66957255189163 139.747873003523 18.053</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-850b5eb8-f276-4ee0-bd49-3e77d0c4ae00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-850b5eb8-f276-4ee0-bd49-3e77d0c4ae00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-850b5eb8-f276-4ee0-bd49-3e77d0c4ae00">
											<gml:posList>35.669600024266245 139.7480107308115 15.951 35.66948750176293 139.7480049740059 11.799 35.66953937570059 139.74809392863227 17.413 35.669600024266245 139.7480107308115 15.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22b46c55-0082-419d-a817-e83508ac839a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22b46c55-0082-419d-a817-e83508ac839a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22b46c55-0082-419d-a817-e83508ac839a">
											<gml:posList>35.669600024266245 139.7480107308115 15.951 35.66952568867338 139.74797350709179 11.799 35.66948750176293 139.7480049740059 11.799 35.669600024266245 139.7480107308115 15.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-81039175-74a8-467a-b16a-92473b11f3a0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81039175-74a8-467a-b16a-92473b11f3a0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81039175-74a8-467a-b16a-92473b11f3a0">
											<gml:posList>35.669525697687114 139.7479735070822 14.163 35.66956019689421 139.74794051969718 14.163 35.66957255189163 139.747873003523 18.053 35.669525697687114 139.7479735070822 14.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-98a814dc-06ad-4f11-b7d0-85f6c59632e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-98a814dc-06ad-4f11-b7d0-85f6c59632e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-98a814dc-06ad-4f11-b7d0-85f6c59632e2">
											<gml:posList>35.66956019689421 139.74794051969718 14.163 35.66952568867338 139.74797350709179 11.799 35.669600024266245 139.7480107308115 15.951 35.66956019689421 139.74794051969718 14.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa4b3457-1aaf-4456-a8c8-1abca4646351">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa4b3457-1aaf-4456-a8c8-1abca4646351">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa4b3457-1aaf-4456-a8c8-1abca4646351">
											<gml:posList>35.66956019689421 139.74794051969718 14.163 35.66959393944843 139.74790825108974 14.163 35.66957255189163 139.747873003523 18.053 35.66956019689421 139.74794051969718 14.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6180b1dc-0ca6-4e33-b287-d0a506fe5181">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6180b1dc-0ca6-4e33-b287-d0a506fe5181">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6180b1dc-0ca6-4e33-b287-d0a506fe5181">
											<gml:posList>35.669625396913496 139.7480474764654 15.666 35.66953937570059 139.74809392863227 17.413 35.66957684625997 139.74815828784892 11.799 35.669625396913496 139.7480474764654 15.666</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2beaa833-be27-4b25-8f1b-6bb4d1d66d56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2beaa833-be27-4b25-8f1b-6bb4d1d66d56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2beaa833-be27-4b25-8f1b-6bb4d1d66d56">
											<gml:posList>35.66956019689421 139.74794051969718 14.163 35.669600024266245 139.7480107308115 15.951 35.66960901788534 139.74793149822506 12.244 35.66956019689421 139.74794051969718 14.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8708226c-7f48-4362-8d67-ff3ec44e4ec0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8708226c-7f48-4362-8d67-ff3ec44e4ec0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8708226c-7f48-4362-8d67-ff3ec44e4ec0">
											<gml:posList>35.66960901788534 139.74793149822506 12.244 35.66959394845433 139.747908240034 11.799 35.66956019689421 139.74794051969718 14.163 35.66960901788534 139.74793149822506 12.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6e1291ca-b73b-44bb-9ee8-08245e76bf19">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6e1291ca-b73b-44bb-9ee8-08245e76bf19">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6e1291ca-b73b-44bb-9ee8-08245e76bf19">
											<gml:posList>35.669593939440595 139.74790824004359 13.658 35.66959480579266 139.74790969721263 13.737 35.66961479217208 139.74785032492986 12.244 35.66957854399808 139.7478828503018 12.244 35.669593939440595 139.74790824004359 13.658</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0c227d2d-c6c2-4610-a89e-2471b67676b9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c227d2d-c6c2-4610-a89e-2471b67676b9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c227d2d-c6c2-4610-a89e-2471b67676b9">
											<gml:posList>35.669625396913496 139.7480474764654 15.666 35.66957684625997 139.74815828784892 11.799 35.66961178833904 139.74812692383628 11.799 35.669625396913496 139.7480474764654 15.666</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-eefbf0a2-ad74-41b2-b6d3-06dd9b74054f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eefbf0a2-ad74-41b2-b6d3-06dd9b74054f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eefbf0a2-ad74-41b2-b6d3-06dd9b74054f">
											<gml:posList>35.669625396913496 139.7480474764654 15.666 35.669683260525886 139.74796473437803 17.428 35.66953937570059 139.74809392863227 17.413 35.669625396913496 139.7480474764654 15.666</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44255031-4d4e-444d-a390-7626151315b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44255031-4d4e-444d-a390-7626151315b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44255031-4d4e-444d-a390-7626151315b6">
											<gml:posList>35.669600024266245 139.7480107308115 15.951 35.66953937570059 139.74809392863227 17.413 35.669683260525886 139.74796473437803 17.428 35.669600024266245 139.7480107308115 15.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b83ca9ed-81f8-4edd-8eb9-4a9b549858cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b83ca9ed-81f8-4edd-8eb9-4a9b549858cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b83ca9ed-81f8-4edd-8eb9-4a9b549858cb">
											<gml:posList>35.66959480579266 139.74790969721263 13.737 35.66963090078753 139.74787723828638 13.737 35.66961479217208 139.74785032492986 12.244 35.66959480579266 139.74790969721263 13.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-12ad0a8f-f7b3-450b-90f5-4ef55584d64b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12ad0a8f-f7b3-450b-90f5-4ef55584d64b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12ad0a8f-f7b3-450b-90f5-4ef55584d64b">
											<gml:posList>35.66960901788534 139.74793149822506 12.244 35.66964435621897 139.74789972497095 12.244 35.66963090078753 139.74787723828638 13.737 35.66959480579266 139.74790969721263 13.737 35.66960901788534 139.74793149822506 12.244</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-71dac2f1-7edf-4f7c-90fa-39cd6455cb37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-71dac2f1-7edf-4f7c-90fa-39cd6455cb37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-71dac2f1-7edf-4f7c-90fa-39cd6455cb37">
											<gml:posList>35.66966665066631 139.74812090060706 15.287 35.669625396913496 139.7480474764654 15.666 35.66961178833904 139.74812692383628 11.799 35.66966665066631 139.74812090060706 15.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a83f2e10-f922-4e71-9eb3-ceb3daf7c03a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a83f2e10-f922-4e71-9eb3-ceb3daf7c03a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a83f2e10-f922-4e71-9eb3-ceb3daf7c03a">
											<gml:posList>35.66961178833904 139.74812692383628 11.799 35.66962824885782 139.7481544444122 11.799 35.66966665066631 139.74812090060706 15.287 35.66961178833904 139.74812692383628 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-096bcae5-8937-4a9c-9cf8-9558d6bf7347">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-096bcae5-8937-4a9c-9cf8-9558d6bf7347">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-096bcae5-8937-4a9c-9cf8-9558d6bf7347">
											<gml:posList>35.669600024266245 139.7480107308115 15.951 35.669683260525886 139.74796473437803 17.428 35.66960901788534 139.74793149822506 12.244 35.669600024266245 139.7480107308115 15.951</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-459121fc-eee5-4ff6-abbf-965d7015757d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-459121fc-eee5-4ff6-abbf-965d7015757d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-459121fc-eee5-4ff6-abbf-965d7015757d">
											<gml:posList>35.669683260525886 139.74796473437803 17.428 35.66964435621897 139.74789972497095 12.244 35.66960901788534 139.74793149822506 12.244 35.669683260525886 139.74796473437803 17.428</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-38db97d1-7287-41ad-93dd-2874ef188258">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38db97d1-7287-41ad-93dd-2874ef188258">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38db97d1-7287-41ad-93dd-2874ef188258">
											<gml:posList>35.669693293755685 139.7480551144681 11.799 35.669625396913496 139.7480474764654 15.666 35.66966665066631 139.74812090060706 15.287 35.669693293755685 139.7480551144681 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dbf1ccca-8d0f-4ed4-b626-8b372e444917">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dbf1ccca-8d0f-4ed4-b626-8b372e444917">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dbf1ccca-8d0f-4ed4-b626-8b372e444917">
											<gml:posList>35.669717271482334 139.74809499877367 11.799 35.66971005199387 139.74808298821802 11.799 35.66962824885782 139.7481544444122 11.799 35.669636289596134 139.74816787904405 11.799 35.669717271482334 139.74809499877367 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b0db7ae-b624-4cd4-b521-4e649b836d68">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b0db7ae-b624-4cd4-b521-4e649b836d68">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b0db7ae-b624-4cd4-b521-4e649b836d68">
											<gml:posList>35.669625396913496 139.7480474764654 15.666 35.669693293755685 139.7480551144681 11.799 35.6697219572158 139.74802936849932 11.799 35.669625396913496 139.7480474764654 15.666</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-333496d9-123d-48ae-907c-f3681f3021c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-333496d9-123d-48ae-907c-f3681f3021c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-333496d9-123d-48ae-907c-f3681f3021c7">
											<gml:posList>35.669625396913496 139.7480474764654 15.666 35.6697219572158 139.74802936849932 11.799 35.669683260525886 139.74796473437803 17.428 35.669625396913496 139.7480474764654 15.666</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-26fe8f4c-84e4-4ab3-8312-ca7d79eca5c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-26fe8f4c-84e4-4ab3-8312-ca7d79eca5c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-26fe8f4c-84e4-4ab3-8312-ca7d79eca5c9">
											<gml:posList>35.66966665066631 139.74812090060706 15.287 35.66971005199387 139.74808298821802 11.799 35.669693293755685 139.7480551144681 11.799 35.66966665066631 139.74812090060706 15.287</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccf3d3fc-fd8a-4e86-acb3-0914bc92800c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccf3d3fc-fd8a-4e86-acb3-0914bc92800c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccf3d3fc-fd8a-4e86-acb3-0914bc92800c">
											<gml:posList>35.66959394845433 139.747908240034 11.799 35.669593939440595 139.74790824004359 13.658 35.66959393944843 139.74790825108974 14.163 35.66959394845433 139.747908240034 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08c8c010-040b-44c2-85f0-95e9804a3ac2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08c8c010-040b-44c2-85f0-95e9804a3ac2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08c8c010-040b-44c2-85f0-95e9804a3ac2">
											<gml:posList>35.669578553003966 139.74788283924607 6.424 35.66957854399808 139.7478828503018 12.244 35.66961479217208 139.74785032492986 12.244 35.66961479217208 139.74785032492986 6.424 35.669578553003966 139.74788283924607 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d254a32b-b0a3-4e91-b108-06cab455c6de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d254a32b-b0a3-4e91-b108-06cab455c6de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d254a32b-b0a3-4e91-b108-06cab455c6de">
											<gml:posList>35.66948129939354 139.74790197538525 6.424 35.669481326419046 139.74790195326415 14.163 35.66955173281659 139.74783863906057 14.163 35.669551750836206 139.7478386279952 6.424 35.66948129939354 139.74790197538525 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-86cd1f4b-ace1-41d5-a26d-c9ee2ddd3f6e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-86cd1f4b-ace1-41d5-a26d-c9ee2ddd3f6e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-86cd1f4b-ace1-41d5-a26d-c9ee2ddd3f6e">
											<gml:posList>35.66959393944843 139.74790825108974 14.163 35.669593939440595 139.74790824004359 13.658 35.66957854399808 139.7478828503018 12.244 35.669578553003966 139.74788283924607 6.424 35.669551750836206 139.7478386279952 6.424 35.66955173281659 139.74783863906057 14.163 35.66957255189163 139.747873003523 18.053 35.66959393944843 139.74790825108974 14.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25dccc98-d75a-4d5e-bc66-fd93eed8e90c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25dccc98-d75a-4d5e-bc66-fd93eed8e90c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25dccc98-d75a-4d5e-bc66-fd93eed8e90c">
											<gml:posList>35.66959480579266 139.74790969721263 13.737 35.669593939440595 139.74790824004359 13.658 35.66959394845433 139.747908240034 11.799 35.66959480579266 139.74790969721263 13.737</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2487dc18-7778-4823-9824-726aaf6f8afc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2487dc18-7778-4823-9824-726aaf6f8afc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2487dc18-7778-4823-9824-726aaf6f8afc">
											<gml:posList>35.66959394845433 139.747908240034 11.799 35.66960901788534 139.74793149822506 12.244 35.66959480579266 139.74790969721263 13.737 35.66959394845433 139.747908240034 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccd5c291-9ca6-4124-b857-2875ca7b2191">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccd5c291-9ca6-4124-b857-2875ca7b2191">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccd5c291-9ca6-4124-b857-2875ca7b2191">
											<gml:posList>35.66959393944843 139.74790825108974 14.163 35.66956019689421 139.74794051969718 14.163 35.66959394845433 139.747908240034 11.799 35.66959393944843 139.74790825108974 14.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b455755f-5677-4f91-a97d-9c8c59f2ff8c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b455755f-5677-4f91-a97d-9c8c59f2ff8c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b455755f-5677-4f91-a97d-9c8c59f2ff8c">
											<gml:posList>35.66950039425952 139.7479327185368 11.799 35.66952568867338 139.74797350709179 11.799 35.669525697687114 139.7479735070822 14.163 35.66950251487448 139.74793608535057 18.053 35.669481326419046 139.74790195326415 14.163 35.66948129939354 139.74790197538525 6.424 35.66950037624775 139.74793274064825 6.424 35.66950039425952 139.7479327185368 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-920d53d3-24ff-467e-a3a5-49609bf56d64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-920d53d3-24ff-467e-a3a5-49609bf56d64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-920d53d3-24ff-467e-a3a5-49609bf56d64">
											<gml:posList>35.66961479217208 139.74785032492986 6.424 35.66961479217208 139.74785032492986 12.244 35.66963090078753 139.74787723828638 13.737 35.66964435621897 139.74789972497095 12.244 35.669683260525886 139.74796473437803 17.428 35.6697219572158 139.74802936849932 11.799 35.66972209258601 139.74802960032486 6.424 35.66961479217208 139.74785032492986 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8a087cd4-98fb-429d-95e6-017ab67678a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8a087cd4-98fb-429d-95e6-017ab67678a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8a087cd4-98fb-429d-95e6-017ab67678a3">
											<gml:posList>35.66950039425952 139.7479327185368 11.799 35.66950037624775 139.74793274064825 6.424 35.66946704770692 139.74796414716835 6.424 35.66946704770692 139.74796414716835 11.799 35.66950039425952 139.7479327185368 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b48b3a3-aa08-4131-b442-990cea0236fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b48b3a3-aa08-4131-b442-990cea0236fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b48b3a3-aa08-4131-b442-990cea0236fb">
											<gml:posList>35.66956019689421 139.74794051969718 14.163 35.669525697687114 139.7479735070822 14.163 35.66952568867338 139.74797350709179 11.799 35.66956019689421 139.74794051969718 14.163</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-988a5955-b782-45ab-b57d-e2786f4bf4ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-988a5955-b782-45ab-b57d-e2786f4bf4ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-988a5955-b782-45ab-b57d-e2786f4bf4ac">
											<gml:posList>35.66946704770692 139.74796414716835 11.799 35.66946704770692 139.74796414716835 6.424 35.66944591007277 139.7480271326232 6.424 35.66944591007277 139.7480271326232 11.799 35.66946704770692 139.74796414716835 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-21ca65be-df7d-4e1a-9fd1-578a133d1905">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-21ca65be-df7d-4e1a-9fd1-578a133d1905">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-21ca65be-df7d-4e1a-9fd1-578a133d1905">
											<gml:posList>35.66946397679459 139.74805710365519 11.799 35.66946397679459 139.74805710365519 12.138 35.66948203774411 139.74804074721052 13.442 35.66949926094697 139.74802514278727 11.799 35.66946397679459 139.74805710365519 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a581396-fb87-418d-9153-2cdcc0a08cb9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a581396-fb87-418d-9153-2cdcc0a08cb9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a581396-fb87-418d-9153-2cdcc0a08cb9">
											<gml:posList>35.669693293755685 139.7480551144681 11.799 35.669693447168946 139.74805536836672 6.424 35.66972209258601 139.74802960032486 6.424 35.6697219572158 139.74802936849932 11.799 35.669693293755685 139.7480551144681 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a041d6d-7236-4839-a237-0990bf4ff4b7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a041d6d-7236-4839-a237-0990bf4ff4b7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a041d6d-7236-4839-a237-0990bf4ff4b7">
											<gml:posList>35.66950393653029 139.74812339322315 6.424 35.66950393653029 139.74812339322315 12.138 35.66946397679459 139.74805710365519 12.138 35.66946397679459 139.74805710365519 11.799 35.66944591007277 139.7480271326232 11.799 35.66944591007277 139.7480271326232 6.424 35.66950393653029 139.74812339322315 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aea1666a-ba8c-4ce7-a57c-7628cb5590d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aea1666a-ba8c-4ce7-a57c-7628cb5590d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aea1666a-ba8c-4ce7-a57c-7628cb5590d5">
											<gml:posList>35.669717271482334 139.74809499877367 6.424 35.669693447168946 139.74805536836672 6.424 35.669693293755685 139.7480551144681 11.799 35.66971005199387 139.74808298821802 11.799 35.669717271482334 139.74809499877367 11.799 35.669717271482334 139.74809499877367 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-91d62bd0-de52-4d5f-9c16-e97da4d2c269">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-91d62bd0-de52-4d5f-9c16-e97da4d2c269">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-91d62bd0-de52-4d5f-9c16-e97da4d2c269">
											<gml:posList>35.66957670191534 139.74815811126388 6.424 35.66957684625997 139.74815828784892 11.799 35.66953937570059 139.74809392863227 17.413 35.66948750176293 139.7480049740059 11.799 35.66949926094697 139.74802514278727 11.799 35.66953842814902 139.74809236108715 12.138 35.669538401123475 139.74809238320816 6.424 35.66957670191534 139.74815811126388 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cee5feb-4adb-49c1-9084-5b5ccded5b45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cee5feb-4adb-49c1-9084-5b5ccded5b45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cee5feb-4adb-49c1-9084-5b5ccded5b45">
											<gml:posList>35.66953842814902 139.74809236108715 12.138 35.66952188945689 139.7481072246845 13.442 35.66950393653029 139.74812339322315 12.138 35.66950393653029 139.74812339322315 6.424 35.669538401123475 139.74809238320816 6.424 35.66953842814902 139.74809236108715 12.138</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d172ceb3-06ee-4b94-9797-222bf0277bb0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d172ceb3-06ee-4b94-9797-222bf0277bb0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d172ceb3-06ee-4b94-9797-222bf0277bb0">
											<gml:posList>35.66971005199387 139.74808298821802 11.799 35.66966665066631 139.74812090060706 15.287 35.66962824885782 139.7481544444122 11.799 35.66971005199387 139.74808298821802 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-442a797c-07d5-46fe-bbe5-384aa90a0ce6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-442a797c-07d5-46fe-bbe5-384aa90a0ce6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-442a797c-07d5-46fe-bbe5-384aa90a0ce6">
											<gml:posList>35.669717271482334 139.74809499877367 11.799 35.669636289596134 139.74816787904405 11.799 35.669636289596134 139.74816787904405 6.424 35.669717271482334 139.74809499877367 6.424 35.669717271482334 139.74809499877367 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-79669dab-1c56-4da6-8eaa-b4b2cc08f081">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-79669dab-1c56-4da6-8eaa-b4b2cc08f081">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-79669dab-1c56-4da6-8eaa-b4b2cc08f081">
											<gml:posList>35.66957684625997 139.74815828784892 11.799 35.66957670191534 139.74815811126388 6.424 35.669611652976826 139.74812670305707 6.424 35.66961178833904 139.74812692383628 11.799 35.66957684625997 139.74815828784892 11.799</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c80ad45d-2e28-44c8-98bb-81de59bcd0b3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c80ad45d-2e28-44c8-98bb-81de59bcd0b3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c80ad45d-2e28-44c8-98bb-81de59bcd0b3">
											<gml:posList>35.669611652976826 139.74812670305707 6.424 35.669636289596134 139.74816787904405 6.424 35.669636289596134 139.74816787904405 11.799 35.66962824885782 139.7481544444122 11.799 35.66961178833904 139.74812692383628 11.799 35.669611652976826 139.74812670305707 6.424</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2091</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">562.14145</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1003</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">22</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>