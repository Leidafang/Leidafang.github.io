<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_663c6a1a-6c65-4718-b9e4-10f29d5720f1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.80</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">33.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>10</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67091257357897 139.73764511207014 0 35.67089644279258 139.73764988124387 0 35.670935268177935 139.73784701200015 0 35.67097203575051 139.73783636372428 0 35.67098560712699 139.7379004163465 0 35.671020392035565 139.73789021230252 0 35.67096455237122 139.7376068296993 0 35.670908319922816 139.7376234663362 0 35.67091257357897 139.73764511207014 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67091257357897 139.73764511207014 12.84 35.670908319922816 139.7376234663362 12.84 35.67096455237122 139.7376068296993 12.84 35.671020392035565 139.73789021230252 12.84 35.67098560712699 139.7379004163465 12.84 35.67097203575051 139.73783636372428 12.84 35.670935268177935 139.73784701200015 12.84 35.67089644279258 139.73764988124387 12.84 35.67091257357897 139.73764511207014 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67091257357897 139.73764511207014 12.84 35.67089644279258 139.73764988124387 12.84 35.67089644279258 139.73764988124387 45.980000000000004 35.67091257357897 139.73764511207014 45.980000000000004 35.67091257357897 139.73764511207014 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67089644279258 139.73764988124387 12.84 35.670935268177935 139.73784701200015 12.84 35.670935268177935 139.73784701200015 45.980000000000004 35.67089644279258 139.73764988124387 45.980000000000004 35.67089644279258 139.73764988124387 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670935268177935 139.73784701200015 12.84 35.67097203575051 139.73783636372428 12.84 35.67097203575051 139.73783636372428 45.980000000000004 35.670935268177935 139.73784701200015 45.980000000000004 35.670935268177935 139.73784701200015 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67097203575051 139.73783636372428 12.84 35.67098560712699 139.7379004163465 12.84 35.67098560712699 139.7379004163465 45.980000000000004 35.67097203575051 139.73783636372428 45.980000000000004 35.67097203575051 139.73783636372428 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67098560712699 139.7379004163465 12.84 35.671020392035565 139.73789021230252 12.84 35.671020392035565 139.73789021230252 45.980000000000004 35.67098560712699 139.7379004163465 45.980000000000004 35.67098560712699 139.7379004163465 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671020392035565 139.73789021230252 12.84 35.67096455237122 139.7376068296993 12.84 35.67096455237122 139.7376068296993 45.980000000000004 35.671020392035565 139.73789021230252 45.980000000000004 35.671020392035565 139.73789021230252 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67096455237122 139.7376068296993 12.84 35.670908319922816 139.7376234663362 12.84 35.670908319922816 139.7376234663362 45.980000000000004 35.67096455237122 139.7376068296993 45.980000000000004 35.67096455237122 139.7376068296993 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670908319922816 139.7376234663362 12.84 35.67091257357897 139.73764511207014 12.84 35.67091257357897 139.73764511207014 45.980000000000004 35.670908319922816 139.7376234663362 45.980000000000004 35.670908319922816 139.7376234663362 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67091257357897 139.73764511207014 45.980000000000004 35.67089644279258 139.73764988124387 45.980000000000004 35.670935268177935 139.73784701200015 45.980000000000004 35.67097203575051 139.73783636372428 45.980000000000004 35.67098560712699 139.7379004163465 45.980000000000004 35.671020392035565 139.73789021230252 45.980000000000004 35.67096455237122 139.7376068296993 45.980000000000004 35.670908319922816 139.7376234663362 45.980000000000004 35.67091257357897 139.73764511207014 45.980000000000004</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-dc0e7db8-0018-4f9f-a600-0c3f435afd50"/>
							<gml:surfaceMember xlink:href="#poly-398a7c37-3825-4170-b93f-5880b8ac24f5"/>
							<gml:surfaceMember xlink:href="#poly-1b1c2d91-36ac-45ab-9483-e3861d5f4d5d"/>
							<gml:surfaceMember xlink:href="#poly-2276edb9-6aa7-42d9-8367-8147b5e2f33c"/>
							<gml:surfaceMember xlink:href="#poly-9784f986-32e2-41dd-873b-e2406400be46"/>
							<gml:surfaceMember xlink:href="#poly-9f3b5176-195a-4ed3-bf7e-5dddf8f6b28b"/>
							<gml:surfaceMember xlink:href="#poly-2c7e7986-d1d1-47ce-a188-a37024e4ddcf"/>
							<gml:surfaceMember xlink:href="#poly-7b3a01ac-2727-4f2d-85e6-1c383e89ab01"/>
							<gml:surfaceMember xlink:href="#poly-5f1e7b3e-8561-496f-9aa5-88455bb25c96"/>
							<gml:surfaceMember xlink:href="#poly-058cdcef-5701-4662-aa23-e42cfacd8c62"/>
							<gml:surfaceMember xlink:href="#poly-c5e9d3c1-5ab7-42fb-b267-6204a51bddb1"/>
							<gml:surfaceMember xlink:href="#poly-1f5d7767-f0c5-4eb8-b489-4681b4161dac"/>
							<gml:surfaceMember xlink:href="#poly-5e688de1-8cd5-4c6c-9d0b-898899f9e889"/>
							<gml:surfaceMember xlink:href="#poly-546e42e2-b3bc-4711-a5d9-2d32017d6c47"/>
							<gml:surfaceMember xlink:href="#poly-7cb202a5-0c78-4c19-adfc-6ad7bdbc3381"/>
							<gml:surfaceMember xlink:href="#poly-cc9113e0-8bbc-459c-9fa7-d25c6508ce00"/>
							<gml:surfaceMember xlink:href="#poly-bfabec29-0901-4c7e-b2c8-93295c294c0c"/>
							<gml:surfaceMember xlink:href="#poly-180db41f-09e0-4842-8ac5-5072e6101551"/>
							<gml:surfaceMember xlink:href="#poly-fd456ec2-d00e-4b46-a32d-9def2fd743b1"/>
							<gml:surfaceMember xlink:href="#poly-1b4dbb1a-7cae-4b24-b9b6-2faab733d0a1"/>
							<gml:surfaceMember xlink:href="#poly-afc989a9-fa76-4dd7-8e8e-4f0a3f6b36a2"/>
							<gml:surfaceMember xlink:href="#poly-07a07eb1-0325-4cf0-9ab1-741a05683c4b"/>
							<gml:surfaceMember xlink:href="#poly-e1027ad5-30e6-44d8-9375-22d221fdb830"/>
							<gml:surfaceMember xlink:href="#poly-41f6a36d-1bd9-4d1d-93b3-cda4c632f15b"/>
							<gml:surfaceMember xlink:href="#poly-55b4c4f4-3b06-4cb9-b410-1327d3874d45"/>
							<gml:surfaceMember xlink:href="#poly-05e69d82-79bd-4e2d-90c4-289e430d9751"/>
							<gml:surfaceMember xlink:href="#poly-8b46dbee-cdc5-48cd-b7b5-6cb421b885e3"/>
							<gml:surfaceMember xlink:href="#poly-951c3c80-fc75-4895-87a5-2282ac5a3b51"/>
							<gml:surfaceMember xlink:href="#poly-c0679f08-b376-483f-97ca-6504bc118ad8"/>
							<gml:surfaceMember xlink:href="#poly-b0264d08-2788-4af0-9eae-03aedea28db1"/>
							<gml:surfaceMember xlink:href="#poly-a22ed2cd-4ed6-409a-912d-0dcddbf925a5"/>
							<gml:surfaceMember xlink:href="#poly-1e9d9e21-90c4-46be-b6d9-b6c6cd490b24"/>
							<gml:surfaceMember xlink:href="#poly-12085b3a-645e-498f-81e2-9d79a4ec3562"/>
							<gml:surfaceMember xlink:href="#poly-ccc52a84-b9ac-4a09-a55b-fe4e5f7901bd"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_663c6a1a-6c65-4718-b9e4-10f29d5720f1_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70ba9c4b-501d-40dc-adaf-9c254768f26d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67091497953377 139.73772364862515 46.32 35.670911974873405 139.73770840826947 46.32 35.67092125683064 139.73770565770823 46.32 35.67092426149134 139.7377208980656 46.32 35.67091497953377 139.73772364862515 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c39d61ce-3813-4f24-b775-106e32502c14">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095651458199 139.7377120225318 46.32 35.67097909767734 139.73770533465415 46.32 35.670983477966914 139.73772755467033 46.32 35.67096088585662 139.73773424255285 46.32 35.67095651458199 139.7377120225318 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-573822bb-82de-44cf-a316-815184954b1c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67095131906446 139.73770747763703 46.32 35.67096231218303 139.73775966952536 46.32 35.67093844080629 139.73776722053614 46.32 35.670927438686014 139.73771503971935 46.32 35.67095131906446 139.73770747763703 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbcef212-91e0-4ef5-8bcf-c7fe6ba06f1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbcef212-91e0-4ef5-8bcf-c7fe6ba06f1f_0">
											<gml:posList>35.67095651458199 139.7377120225318 46.32 35.67096088585662 139.73773424255285 46.32 35.67096088585662 139.73773424255285 47.776 35.67095651458199 139.7377120225318 47.776 35.67095651458199 139.7377120225318 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4b95f927-e465-49cb-982b-0d1ca323171e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4b95f927-e465-49cb-982b-0d1ca323171e_0">
											<gml:posList>35.670911974873405 139.73770840826947 46.32 35.670911974873405 139.73770840826947 47.734 35.67092125683064 139.73770565770823 47.734 35.67092125683064 139.73770565770823 46.32 35.670911974873405 139.73770840826947 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2066e53-93b8-4c4d-b3b2-6cca8f760cee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2066e53-93b8-4c4d-b3b2-6cca8f760cee_0">
											<gml:posList>35.67097909767734 139.73770533465415 46.32 35.67095651458199 139.7377120225318 46.32 35.67095651458199 139.7377120225318 47.776 35.67097909767734 139.73770533465415 47.776 35.67097909767734 139.73770533465415 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c47cb5a7-a728-4755-8b2d-40424a48dab1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c47cb5a7-a728-4755-8b2d-40424a48dab1_0">
											<gml:posList>35.670927438686014 139.73771503971935 48.323 35.67095131906446 139.73770747763703 48.323 35.67095131906446 139.73770747763703 46.32 35.670927438686014 139.73771503971935 46.32 35.670927438686014 139.73771503971935 48.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-22e2e5d0-2b08-4fc3-9b01-373911be413f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-22e2e5d0-2b08-4fc3-9b01-373911be413f_0">
											<gml:posList>35.67095131906446 139.73770747763703 48.323 35.670927438686014 139.73771503971935 48.323 35.6709300361289 139.73771691449858 48.323 35.67094978024457 139.7377106608176 48.323 35.67095131906446 139.73770747763703 48.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea0ce9ec-928c-4344-bc37-d6980bf1e8d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea0ce9ec-928c-4344-bc37-d6980bf1e8d1_0">
											<gml:posList>35.67092426149134 139.7377208980656 46.32 35.67092125683064 139.73770565770823 46.32 35.67092125683064 139.73770565770823 47.734 35.67092426149134 139.7377208980656 47.734 35.67092426149134 139.7377208980656 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c14c8d17-9406-43da-9762-fe07ff39e126">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c14c8d17-9406-43da-9762-fe07ff39e126_0">
											<gml:posList>35.67094978024457 139.7377106608176 48.323 35.6709300361289 139.73771691449858 48.323 35.6709300361289 139.73771691449858 47.874 35.67094978024457 139.7377106608176 47.874 35.67094978024457 139.7377106608176 48.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08c868a5-ca6c-40ba-a785-b3f21b165fa3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08c868a5-ca6c-40ba-a785-b3f21b165fa3_0">
											<gml:posList>35.67092125683064 139.73770565770823 47.734 35.670911974873405 139.73770840826947 47.734 35.67091497953377 139.73772364862515 47.734 35.67092426149134 139.7377208980656 47.734 35.67092125683064 139.73770565770823 47.734</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-15009cbc-cb11-4d29-95e0-4392f5f86399">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-15009cbc-cb11-4d29-95e0-4392f5f86399_0">
											<gml:posList>35.670911974873405 139.73770840826947 46.32 35.67091497953377 139.73772364862515 46.32 35.67091497953377 139.73772364862515 47.734 35.670911974873405 139.73770840826947 47.734 35.670911974873405 139.73770840826947 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-581779e2-f385-45a5-ab4a-c4fba4ac75d6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-581779e2-f385-45a5-ab4a-c4fba4ac75d6_0">
											<gml:posList>35.670983477966914 139.73772755467033 46.32 35.67097909767734 139.73770533465415 46.32 35.67097909767734 139.73770533465415 47.776 35.670983477966914 139.73772755467033 47.776 35.670983477966914 139.73772755467033 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73ad2a0f-02e0-4d7c-b1bd-9ddd47a72c7f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73ad2a0f-02e0-4d7c-b1bd-9ddd47a72c7f_0">
											<gml:posList>35.67095651458199 139.7377120225318 47.776 35.67096088585662 139.73773424255285 47.776 35.670983477966914 139.73772755467033 47.776 35.67097909767734 139.73770533465415 47.776 35.67095651458199 139.7377120225318 47.776</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b498bd86-d271-480e-882c-09d136c21df1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b498bd86-d271-480e-882c-09d136c21df1_0">
											<gml:posList>35.67091497953377 139.73772364862515 46.32 35.67092426149134 139.7377208980656 46.32 35.67092426149134 139.7377208980656 47.734 35.67091497953377 139.73772364862515 47.734 35.67091497953377 139.73772364862515 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f92dbe41-84d5-43f8-ae90-40bd1bbde70d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f92dbe41-84d5-43f8-ae90-40bd1bbde70d_0">
											<gml:posList>35.67096088585662 139.73773424255285 46.32 35.670983477966914 139.73772755467033 46.32 35.670983477966914 139.73772755467033 47.776 35.67096088585662 139.73773424255285 47.776 35.67096088585662 139.73773424255285 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0bb35093-6263-4375-8729-195dd670c6a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0bb35093-6263-4375-8729-195dd670c6a9_0">
											<gml:posList>35.67096231218303 139.73775966952536 48.323 35.67095131906446 139.73770747763703 48.323 35.67094978024457 139.7377106608176 48.323 35.670959714740825 139.73775779474403 48.323 35.67096231218303 139.73775966952536 48.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7595e322-9062-46bc-affc-0ea4295b4ca1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7595e322-9062-46bc-affc-0ea4295b4ca1_0">
											<gml:posList>35.67096231218303 139.73775966952536 46.32 35.67095131906446 139.73770747763703 46.32 35.67095131906446 139.73770747763703 48.323 35.67096231218303 139.73775966952536 48.323 35.67096231218303 139.73775966952536 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95017a6a-d9f9-4a1d-8d80-8f658dc7c201">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95017a6a-d9f9-4a1d-8d80-8f658dc7c201_0">
											<gml:posList>35.670959714740825 139.73775779474403 48.323 35.67094978024457 139.7377106608176 48.323 35.67094978024457 139.7377106608176 47.874 35.670959714740825 139.73775779474403 47.874 35.670959714740825 139.73775779474403 48.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a649b000-dda0-4f61-8dfe-57e0cfbb79a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a649b000-dda0-4f61-8dfe-57e0cfbb79a7_0">
											<gml:posList>35.670939970613944 139.7377640373678 47.874 35.670959714740825 139.73775779474403 47.874 35.67094978024457 139.7377106608176 47.874 35.6709300361289 139.73771691449858 47.874 35.670939970613944 139.7377640373678 47.874</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3df6a429-f8be-4434-ab28-10b5f09083cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3df6a429-f8be-4434-ab28-10b5f09083cb_0">
											<gml:posList>35.6709300361289 139.73771691449858 48.323 35.670939970613944 139.7377640373678 48.323 35.670939970613944 139.7377640373678 47.874 35.6709300361289 139.73771691449858 47.874 35.6709300361289 139.73771691449858 48.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-265909ee-dc61-4657-bc4b-6b4af596f5a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-265909ee-dc61-4657-bc4b-6b4af596f5a0_0">
											<gml:posList>35.670927438686014 139.73771503971935 48.323 35.67093844080629 139.73776722053614 48.323 35.670939970613944 139.7377640373678 48.323 35.6709300361289 139.73771691449858 48.323 35.670927438686014 139.73771503971935 48.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85e0bac8-24b6-4bfc-a4cc-868b3a1a1301">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85e0bac8-24b6-4bfc-a4cc-868b3a1a1301_0">
											<gml:posList>35.670927438686014 139.73771503971935 46.32 35.67093844080629 139.73776722053614 46.32 35.67093844080629 139.73776722053614 48.323 35.670927438686014 139.73771503971935 48.323 35.670927438686014 139.73771503971935 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86e4e5f1-63f5-4333-988e-43f70c3c377b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-86e4e5f1-63f5-4333-988e-43f70c3c377b_0">
											<gml:posList>35.670939970613944 139.7377640373678 48.323 35.670959714740825 139.73775779474403 48.323 35.670959714740825 139.73775779474403 47.874 35.670939970613944 139.7377640373678 47.874 35.670939970613944 139.7377640373678 48.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00c6f0f8-6c66-4b7d-8dd4-294153f487e6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00c6f0f8-6c66-4b7d-8dd4-294153f487e6_0">
											<gml:posList>35.67093844080629 139.73776722053614 48.323 35.67096231218303 139.73775966952536 48.323 35.670959714740825 139.73775779474403 48.323 35.670939970613944 139.7377640373678 48.323 35.67093844080629 139.73776722053614 48.323</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c20a634-1bae-4497-976c-8f7eb6acbe78">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c20a634-1bae-4497-976c-8f7eb6acbe78_0">
											<gml:posList>35.67093844080629 139.73776722053614 46.32 35.67096231218303 139.73775966952536 46.32 35.67096231218303 139.73775966952536 48.323 35.67093844080629 139.73776722053614 48.323 35.67093844080629 139.73776722053614 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-dc0e7db8-0018-4f9f-a600-0c3f435afd50">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dc0e7db8-0018-4f9f-a600-0c3f435afd50">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dc0e7db8-0018-4f9f-a600-0c3f435afd50">
											<gml:posList>35.670972035750495 139.73783636372428 12.84 35.670935268177935 139.73784701200015 12.84 35.67089644279257 139.73764988124387 12.84 35.67091257357895 139.73764511207014 12.84 35.6709083199228 139.7376234663362 12.84 35.6709645523712 139.73760682969927 12.84 35.67102039203556 139.7378902123025 12.84 35.670985607126966 139.7379004163465 12.84 35.670972035750495 139.73783636372428 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-398a7c37-3825-4170-b93f-5880b8ac24f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-398a7c37-3825-4170-b93f-5880b8ac24f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-398a7c37-3825-4170-b93f-5880b8ac24f5">
											<gml:posList>35.670968172471 139.73762520648705 44.407 35.6709645523712 139.73760682969927 44.407 35.6709083199228 139.7376234663362 44.407 35.67091257357895 139.73764511207014 44.407 35.670968172471 139.73762520648705 44.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1b1c2d91-36ac-45ab-9483-e3861d5f4d5d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b1c2d91-36ac-45ab-9483-e3861d5f4d5d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b1c2d91-36ac-45ab-9483-e3861d5f4d5d">
											<gml:posList>35.67091257357895 139.73764511207014 46.936 35.670913559655965 139.73764961779696 46.936 35.670965400889386 139.73763105330931 46.936 35.670968172471 139.73762520648705 46.936 35.67091257357895 139.73764511207014 46.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2276edb9-6aa7-42d9-8367-8147b5e2f33c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2276edb9-6aa7-42d9-8367-8147b5e2f33c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2276edb9-6aa7-42d9-8367-8147b5e2f33c">
											<gml:posList>35.67091257357895 139.73764511207014 46.936 35.67089644279257 139.73764988124387 46.936 35.6709010515427 139.73765332219895 46.936 35.670913559655965 139.73764961779696 46.936 35.67091257357895 139.73764511207014 46.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9784f986-32e2-41dd-873b-e2406400be46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9784f986-32e2-41dd-873b-e2406400be46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9784f986-32e2-41dd-873b-e2406400be46">
											<gml:posList>35.670968172471 139.73762520648705 46.936 35.670965400889386 139.73763105330931 46.936 35.67099706753384 139.73779173981762 46.936 35.67100166726614 139.73779518079593 46.936 35.670968172471 139.73762520648705 46.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9f3b5176-195a-4ed3-bf7e-5dddf8f6b28b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9f3b5176-195a-4ed3-bf7e-5dddf8f6b28b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9f3b5176-195a-4ed3-bf7e-5dddf8f6b28b">
											<gml:posList>35.670932093792274 139.7378109605426 46.32 35.67099706753384 139.73779173981762 46.32 35.670965400889386 139.73763105330931 46.32 35.670913559655965 139.73764961779696 46.32 35.6709010515427 139.73765332219895 46.32 35.670932093792274 139.7378109605426 46.32</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c7e7986-d1d1-47ce-a188-a37024e4ddcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c7e7986-d1d1-47ce-a188-a37024e4ddcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c7e7986-d1d1-47ce-a188-a37024e4ddcf">
											<gml:posList>35.67092927696654 139.73781659752933 46.936 35.670932093792274 139.7378109605426 46.936 35.6709010515427 139.73765332219895 46.936 35.67089644279257 139.73764988124387 46.936 35.67092927696654 139.73781659752933 46.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b3a01ac-2727-4f2d-85e6-1c383e89ab01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b3a01ac-2727-4f2d-85e6-1c383e89ab01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b3a01ac-2727-4f2d-85e6-1c383e89ab01">
											<gml:posList>35.67100166726614 139.73779518079593 46.936 35.67099706753384 139.73779173981762 46.936 35.670932093792274 139.7378109605426 46.936 35.67092927696654 139.73781659752933 46.936 35.67100166726614 139.73779518079593 46.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5f1e7b3e-8561-496f-9aa5-88455bb25c96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5f1e7b3e-8561-496f-9aa5-88455bb25c96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5f1e7b3e-8561-496f-9aa5-88455bb25c96">
											<gml:posList>35.67092927696654 139.73781659752933 44.662 35.670935268177935 139.73784701200015 44.662 35.67093735606754 139.73784285609122 44.662 35.670932016498114 139.73781578788316 44.662 35.67092927696654 139.73781659752933 44.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-058cdcef-5701-4662-aa23-e42cfacd8c62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-058cdcef-5701-4662-aa23-e42cfacd8c62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-058cdcef-5701-4662-aa23-e42cfacd8c62">
											<gml:posList>35.670972035750495 139.73783636372428 44.662 35.670974078579874 139.7378322189132 44.662 35.67093735606754 139.73784285609122 44.662 35.670935268177935 139.73784701200015 44.662 35.670972035750495 139.73783636372428 44.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c5e9d3c1-5ab7-42fb-b267-6204a51bddb1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c5e9d3c1-5ab7-42fb-b267-6204a51bddb1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c5e9d3c1-5ab7-42fb-b267-6204a51bddb1">
											<gml:posList>35.67100166726614 139.73779518079593 44.662 35.67099891872102 139.73779599045426 44.662 35.671016991822604 139.73788764255139 44.662 35.67102039203556 139.7378902123025 44.662 35.67100166726614 139.73779518079593 44.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1f5d7767-f0c5-4eb8-b489-4681b4161dac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f5d7767-f0c5-4eb8-b489-4681b4161dac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f5d7767-f0c5-4eb8-b489-4681b4161dac">
											<gml:posList>35.670974078579874 139.7378322189132 44.235 35.67098764092731 139.7378962494544 44.235 35.671016991822604 139.73788764255139 44.235 35.67099891872102 139.73779599045426 44.235 35.670932016498114 139.73781578788316 44.235 35.67093735606754 139.73784285609122 44.235 35.670974078579874 139.7378322189132 44.235</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-5e688de1-8cd5-4c6c-9d0b-898899f9e889">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e688de1-8cd5-4c6c-9d0b-898899f9e889">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e688de1-8cd5-4c6c-9d0b-898899f9e889">
											<gml:posList>35.670972035750495 139.73783636372428 44.662 35.670985607126966 139.7379004163465 44.662 35.67098764092731 139.7378962494544 44.662 35.670974078579874 139.7378322189132 44.662 35.670972035750495 139.73783636372428 44.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-546e42e2-b3bc-4711-a5d9-2d32017d6c47">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-546e42e2-b3bc-4711-a5d9-2d32017d6c47">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-546e42e2-b3bc-4711-a5d9-2d32017d6c47">
											<gml:posList>35.67102039203556 139.7378902123025 44.662 35.671016991822604 139.73788764255139 44.662 35.67098764092731 139.7378962494544 44.662 35.670985607126966 139.7379004163465 44.662 35.67102039203556 139.7378902123025 44.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7cb202a5-0c78-4c19-adfc-6ad7bdbc3381">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7cb202a5-0c78-4c19-adfc-6ad7bdbc3381">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7cb202a5-0c78-4c19-adfc-6ad7bdbc3381">
											<gml:posList>35.67098764092731 139.7378962494544 44.662 35.67098764092731 139.7378962494544 44.235 35.670974078579874 139.7378322189132 44.235 35.670974078579874 139.7378322189132 44.662 35.67098764092731 139.7378962494544 44.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cc9113e0-8bbc-459c-9fa7-d25c6508ce00">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cc9113e0-8bbc-459c-9fa7-d25c6508ce00">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cc9113e0-8bbc-459c-9fa7-d25c6508ce00">
											<gml:posList>35.67089644279257 139.73764988124387 46.936 35.67091257357895 139.73764511207014 46.936 35.67091257357895 139.73764511207014 44.407 35.67091257357895 139.73764511207014 12.84 35.67089644279257 139.73764988124387 12.84 35.67089644279257 139.73764988124387 46.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bfabec29-0901-4c7e-b2c8-93295c294c0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bfabec29-0901-4c7e-b2c8-93295c294c0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bfabec29-0901-4c7e-b2c8-93295c294c0c">
											<gml:posList>35.6709010515427 139.73765332219895 46.936 35.6709010515427 139.73765332219895 46.32 35.670913559655965 139.73764961779696 46.32 35.670913559655965 139.73764961779696 46.936 35.6709010515427 139.73765332219895 46.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-180db41f-09e0-4842-8ac5-5072e6101551">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-180db41f-09e0-4842-8ac5-5072e6101551">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-180db41f-09e0-4842-8ac5-5072e6101551">
											<gml:posList>35.6709083199228 139.7376234663362 12.84 35.67091257357895 139.73764511207014 12.84 35.67091257357895 139.73764511207014 44.407 35.6709083199228 139.7376234663362 44.407 35.6709083199228 139.7376234663362 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd456ec2-d00e-4b46-a32d-9def2fd743b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd456ec2-d00e-4b46-a32d-9def2fd743b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd456ec2-d00e-4b46-a32d-9def2fd743b1">
											<gml:posList>35.67092927696654 139.73781659752933 44.662 35.67092927696654 139.73781659752933 46.936 35.67089644279257 139.73764988124387 46.936 35.67089644279257 139.73764988124387 12.84 35.670935268177935 139.73784701200015 12.84 35.670935268177935 139.73784701200015 44.662 35.67092927696654 139.73781659752933 44.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b4dbb1a-7cae-4b24-b9b6-2faab733d0a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b4dbb1a-7cae-4b24-b9b6-2faab733d0a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b4dbb1a-7cae-4b24-b9b6-2faab733d0a1">
											<gml:posList>35.670932093792274 139.7378109605426 46.936 35.670932093792274 139.7378109605426 46.32 35.6709010515427 139.73765332219895 46.32 35.6709010515427 139.73765332219895 46.936 35.670932093792274 139.7378109605426 46.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-afc989a9-fa76-4dd7-8e8e-4f0a3f6b36a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-afc989a9-fa76-4dd7-8e8e-4f0a3f6b36a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-afc989a9-fa76-4dd7-8e8e-4f0a3f6b36a2">
											<gml:posList>35.67093735606754 139.73784285609122 44.662 35.67093735606754 139.73784285609122 44.235 35.670932016498114 139.73781578788316 44.235 35.670932016498114 139.73781578788316 44.662 35.67093735606754 139.73784285609122 44.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07a07eb1-0325-4cf0-9ab1-741a05683c4b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07a07eb1-0325-4cf0-9ab1-741a05683c4b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07a07eb1-0325-4cf0-9ab1-741a05683c4b">
											<gml:posList>35.6709645523712 139.73760682969927 12.84 35.6709083199228 139.7376234663362 12.84 35.6709083199228 139.7376234663362 44.407 35.6709645523712 139.73760682969927 44.407 35.6709645523712 139.73760682969927 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e1027ad5-30e6-44d8-9375-22d221fdb830">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e1027ad5-30e6-44d8-9375-22d221fdb830">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e1027ad5-30e6-44d8-9375-22d221fdb830">
											<gml:posList>35.670913559655965 139.73764961779696 46.936 35.670913559655965 139.73764961779696 46.32 35.670965400889386 139.73763105330931 46.32 35.670965400889386 139.73763105330931 46.936 35.670913559655965 139.73764961779696 46.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41f6a36d-1bd9-4d1d-93b3-cda4c632f15b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41f6a36d-1bd9-4d1d-93b3-cda4c632f15b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41f6a36d-1bd9-4d1d-93b3-cda4c632f15b">
											<gml:posList>35.67091257357895 139.73764511207014 46.936 35.670968172471 139.73762520648705 46.936 35.670968172471 139.73762520648705 44.407 35.67091257357895 139.73764511207014 44.407 35.67091257357895 139.73764511207014 46.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-55b4c4f4-3b06-4cb9-b410-1327d3874d45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-55b4c4f4-3b06-4cb9-b410-1327d3874d45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-55b4c4f4-3b06-4cb9-b410-1327d3874d45">
											<gml:posList>35.670935268177935 139.73784701200015 12.84 35.670972035750495 139.73783636372428 12.84 35.670972035750495 139.73783636372428 44.662 35.670935268177935 139.73784701200015 44.662 35.670935268177935 139.73784701200015 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-05e69d82-79bd-4e2d-90c4-289e430d9751">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-05e69d82-79bd-4e2d-90c4-289e430d9751">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-05e69d82-79bd-4e2d-90c4-289e430d9751">
											<gml:posList>35.670974078579874 139.7378322189132 44.662 35.670974078579874 139.7378322189132 44.235 35.67093735606754 139.73784285609122 44.235 35.67093735606754 139.73784285609122 44.662 35.670974078579874 139.7378322189132 44.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b46dbee-cdc5-48cd-b7b5-6cb421b885e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b46dbee-cdc5-48cd-b7b5-6cb421b885e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b46dbee-cdc5-48cd-b7b5-6cb421b885e3">
											<gml:posList>35.67099706753384 139.73779173981762 46.936 35.67099706753384 139.73779173981762 46.32 35.670932093792274 139.7378109605426 46.32 35.670932093792274 139.7378109605426 46.936 35.67099706753384 139.73779173981762 46.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-951c3c80-fc75-4895-87a5-2282ac5a3b51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-951c3c80-fc75-4895-87a5-2282ac5a3b51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-951c3c80-fc75-4895-87a5-2282ac5a3b51">
											<gml:posList>35.670932016498114 139.73781578788316 44.662 35.670932016498114 139.73781578788316 44.235 35.67099891872102 139.73779599045426 44.235 35.67099891872102 139.73779599045426 44.662 35.67100166726614 139.73779518079593 44.662 35.67100166726614 139.73779518079593 46.936 35.67092927696654 139.73781659752933 46.936 35.67092927696654 139.73781659752933 44.662 35.670932016498114 139.73781578788316 44.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0679f08-b376-483f-97ca-6504bc118ad8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0679f08-b376-483f-97ca-6504bc118ad8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0679f08-b376-483f-97ca-6504bc118ad8">
											<gml:posList>35.670972035750495 139.73783636372428 12.84 35.670985607126966 139.7379004163465 12.84 35.670985607126966 139.7379004163465 44.662 35.670972035750495 139.73783636372428 44.662 35.670972035750495 139.73783636372428 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b0264d08-2788-4af0-9eae-03aedea28db1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b0264d08-2788-4af0-9eae-03aedea28db1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b0264d08-2788-4af0-9eae-03aedea28db1">
											<gml:posList>35.670965400889386 139.73763105330931 46.936 35.670965400889386 139.73763105330931 46.32 35.67099706753384 139.73779173981762 46.32 35.67099706753384 139.73779173981762 46.936 35.670965400889386 139.73763105330931 46.936</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a22ed2cd-4ed6-409a-912d-0dcddbf925a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a22ed2cd-4ed6-409a-912d-0dcddbf925a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a22ed2cd-4ed6-409a-912d-0dcddbf925a5">
											<gml:posList>35.670968172471 139.73762520648705 44.407 35.670968172471 139.73762520648705 46.936 35.67100166726614 139.73779518079593 46.936 35.67100166726614 139.73779518079593 44.662 35.67102039203556 139.7378902123025 44.662 35.67102039203556 139.7378902123025 12.84 35.6709645523712 139.73760682969927 12.84 35.6709645523712 139.73760682969927 44.407 35.670968172471 139.73762520648705 44.407</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1e9d9e21-90c4-46be-b6d9-b6c6cd490b24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1e9d9e21-90c4-46be-b6d9-b6c6cd490b24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1e9d9e21-90c4-46be-b6d9-b6c6cd490b24">
											<gml:posList>35.671016991822604 139.73788764255139 44.662 35.671016991822604 139.73788764255139 44.235 35.67098764092731 139.7378962494544 44.235 35.67098764092731 139.7378962494544 44.662 35.671016991822604 139.73788764255139 44.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12085b3a-645e-498f-81e2-9d79a4ec3562">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12085b3a-645e-498f-81e2-9d79a4ec3562">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12085b3a-645e-498f-81e2-9d79a4ec3562">
											<gml:posList>35.670985607126966 139.7379004163465 12.84 35.67102039203556 139.7378902123025 12.84 35.67102039203556 139.7378902123025 44.662 35.670985607126966 139.7379004163465 44.662 35.670985607126966 139.7379004163465 12.84</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ccc52a84-b9ac-4a09-a55b-fe4e5f7901bd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ccc52a84-b9ac-4a09-a55b-fe4e5f7901bd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ccc52a84-b9ac-4a09-a55b-fe4e5f7901bd">
											<gml:posList>35.67099891872102 139.73779599045426 44.662 35.67099891872102 139.73779599045426 44.235 35.671016991822604 139.73788764255139 44.235 35.671016991822604 139.73788764255139 44.662 35.67099891872102 139.73779599045426 44.662</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10354</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">188.8066</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>