<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_672e277b-676a-4e15-8203-f35dca0dee64">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">422</bldg:usage>
			<bldg:measuredHeight uom="m">16.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>3</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667084020129145 139.74173994262682 0 35.66709094658326 139.7417213777603 0 35.667004918885326 139.74167320592224 0 35.66699970151617 139.74168712958635 0 35.66697932174725 139.74167566525566 0 35.666977702555094 139.74167997496488 0 35.666969316172754 139.74167523486082 0 35.666943139676135 139.74174551598117 0 35.6669524278486 139.74175080735046 0 35.66691428722053 139.7418529139376 0 35.66687451972622 139.7418306468366 0 35.66684600418158 139.74190700566518 0 35.66704384969507 139.74201790083833 0 35.667124808541786 139.74180086891383 0 35.66714211327389 139.74181056947657 0 35.66715381628711 139.74177918600427 0 35.667084020129145 139.74173994262682 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667084020129145 139.74173994262682 24.66 35.66715381628711 139.74177918600427 24.66 35.66714211327389 139.74181056947657 24.66 35.667124808541786 139.74180086891383 24.66 35.66704384969507 139.74201790083833 24.66 35.66684600418158 139.74190700566518 24.66 35.66687451972622 139.7418306468366 24.66 35.66691428722053 139.7418529139376 24.66 35.6669524278486 139.74175080735046 24.66 35.666943139676135 139.74174551598117 24.66 35.666969316172754 139.74167523486082 24.66 35.666977702555094 139.74167997496488 24.66 35.66697932174725 139.74167566525566 24.66 35.66699970151617 139.74168712958635 24.66 35.667004918885326 139.74167320592224 24.66 35.66709094658326 139.7417213777603 24.66 35.667084020129145 139.74173994262682 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667084020129145 139.74173994262682 24.66 35.66709094658326 139.7417213777603 24.66 35.66709094658326 139.7417213777603 40.82 35.667084020129145 139.74173994262682 40.82 35.667084020129145 139.74173994262682 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66709094658326 139.7417213777603 24.66 35.667004918885326 139.74167320592224 24.66 35.667004918885326 139.74167320592224 40.82 35.66709094658326 139.7417213777603 40.82 35.66709094658326 139.7417213777603 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667004918885326 139.74167320592224 24.66 35.66699970151617 139.74168712958635 24.66 35.66699970151617 139.74168712958635 40.82 35.667004918885326 139.74167320592224 40.82 35.667004918885326 139.74167320592224 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66699970151617 139.74168712958635 24.66 35.66697932174725 139.74167566525566 24.66 35.66697932174725 139.74167566525566 40.82 35.66699970151617 139.74168712958635 40.82 35.66699970151617 139.74168712958635 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66697932174725 139.74167566525566 24.66 35.666977702555094 139.74167997496488 24.66 35.666977702555094 139.74167997496488 40.82 35.66697932174725 139.74167566525566 40.82 35.66697932174725 139.74167566525566 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666977702555094 139.74167997496488 24.66 35.666969316172754 139.74167523486082 24.66 35.666969316172754 139.74167523486082 40.82 35.666977702555094 139.74167997496488 40.82 35.666977702555094 139.74167997496488 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666969316172754 139.74167523486082 24.66 35.666943139676135 139.74174551598117 24.66 35.666943139676135 139.74174551598117 40.82 35.666969316172754 139.74167523486082 40.82 35.666969316172754 139.74167523486082 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.666943139676135 139.74174551598117 24.66 35.6669524278486 139.74175080735046 24.66 35.6669524278486 139.74175080735046 40.82 35.666943139676135 139.74174551598117 40.82 35.666943139676135 139.74174551598117 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6669524278486 139.74175080735046 24.66 35.66691428722053 139.7418529139376 24.66 35.66691428722053 139.7418529139376 40.82 35.6669524278486 139.74175080735046 40.82 35.6669524278486 139.74175080735046 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66691428722053 139.7418529139376 24.66 35.66687451972622 139.7418306468366 24.66 35.66687451972622 139.7418306468366 40.82 35.66691428722053 139.7418529139376 40.82 35.66691428722053 139.7418529139376 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66687451972622 139.7418306468366 24.66 35.66684600418158 139.74190700566518 24.66 35.66684600418158 139.74190700566518 40.82 35.66687451972622 139.7418306468366 40.82 35.66687451972622 139.7418306468366 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66684600418158 139.74190700566518 24.66 35.66704384969507 139.74201790083833 24.66 35.66704384969507 139.74201790083833 40.82 35.66684600418158 139.74190700566518 40.82 35.66684600418158 139.74190700566518 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66704384969507 139.74201790083833 24.66 35.667124808541786 139.74180086891383 24.66 35.667124808541786 139.74180086891383 40.82 35.66704384969507 139.74201790083833 40.82 35.66704384969507 139.74201790083833 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667124808541786 139.74180086891383 24.66 35.66714211327389 139.74181056947657 24.66 35.66714211327389 139.74181056947657 40.82 35.667124808541786 139.74180086891383 40.82 35.667124808541786 139.74180086891383 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66714211327389 139.74181056947657 24.66 35.66715381628711 139.74177918600427 24.66 35.66715381628711 139.74177918600427 40.82 35.66714211327389 139.74181056947657 40.82 35.66714211327389 139.74181056947657 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66715381628711 139.74177918600427 24.66 35.667084020129145 139.74173994262682 24.66 35.667084020129145 139.74173994262682 40.82 35.66715381628711 139.74177918600427 40.82 35.66715381628711 139.74177918600427 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667084020129145 139.74173994262682 40.82 35.66709094658326 139.7417213777603 40.82 35.667004918885326 139.74167320592224 40.82 35.66699970151617 139.74168712958635 40.82 35.66697932174725 139.74167566525566 40.82 35.666977702555094 139.74167997496488 40.82 35.666969316172754 139.74167523486082 40.82 35.666943139676135 139.74174551598117 40.82 35.6669524278486 139.74175080735046 40.82 35.66691428722053 139.7418529139376 40.82 35.66687451972622 139.7418306468366 40.82 35.66684600418158 139.74190700566518 40.82 35.66704384969507 139.74201790083833 40.82 35.667124808541786 139.74180086891383 40.82 35.66714211327389 139.74181056947657 40.82 35.66715381628711 139.74177918600427 40.82 35.667084020129145 139.74173994262682 40.82</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-bdb5a8d6-f16b-4582-bfe6-f7976061675c"/>
							<gml:surfaceMember xlink:href="#poly-359067cb-df11-4635-8dd7-a8c416d07da1"/>
							<gml:surfaceMember xlink:href="#poly-fb9f093d-4c0d-41fc-91f4-f8e30c242b01"/>
							<gml:surfaceMember xlink:href="#poly-7d21caf1-8b2b-4f4b-bced-3890aa1b4a9e"/>
							<gml:surfaceMember xlink:href="#poly-aa605d92-6787-4e13-912a-881b3ded44ce"/>
							<gml:surfaceMember xlink:href="#poly-766754cd-545f-4ef7-9c31-12339b74f0f2"/>
							<gml:surfaceMember xlink:href="#poly-bdedfd80-b369-49cc-95c9-dd1c01237db6"/>
							<gml:surfaceMember xlink:href="#poly-11f425d1-50f3-4493-b474-4894a6c8cfc1"/>
							<gml:surfaceMember xlink:href="#poly-f3d435be-52de-43f1-a198-26bff64cbefd"/>
							<gml:surfaceMember xlink:href="#poly-fe83d504-42d8-4bde-ab5f-73cdb2b13f11"/>
							<gml:surfaceMember xlink:href="#poly-b1fee0af-f46f-43c0-b48e-80465d5e999b"/>
							<gml:surfaceMember xlink:href="#poly-78f31e02-7bcf-4f92-8290-5d86f54906f3"/>
							<gml:surfaceMember xlink:href="#poly-954fc0d3-4545-49dc-ae9f-77f8da4beb62"/>
							<gml:surfaceMember xlink:href="#poly-9fba8b9c-4be9-42e1-8770-ee32ee2989f2"/>
							<gml:surfaceMember xlink:href="#poly-703b3051-5e52-4852-9df9-34741c7638bb"/>
							<gml:surfaceMember xlink:href="#poly-d0a51cec-92f2-45f5-90cd-4c699310443f"/>
							<gml:surfaceMember xlink:href="#poly-2d563caa-cb78-48f8-9302-4d64e9fd4393"/>
							<gml:surfaceMember xlink:href="#poly-87b38a12-ceac-4840-b36b-6d349d66fe94"/>
							<gml:surfaceMember xlink:href="#poly-bd76d0c0-109d-4349-ae48-0df5647c2a33"/>
							<gml:surfaceMember xlink:href="#poly-25aff224-0dc6-485e-a330-f897c7d8eb79"/>
							<gml:surfaceMember xlink:href="#poly-0b3f498a-5f8c-4b9a-9849-15f4ced9807b"/>
							<gml:surfaceMember xlink:href="#poly-4f0f22a9-b490-4e66-9bfd-ea32c6205b77"/>
							<gml:surfaceMember xlink:href="#poly-567b1da2-06f1-4551-98b2-ce7a1d594945"/>
							<gml:surfaceMember xlink:href="#poly-364623d0-aa4a-4366-915b-db9fd132190f"/>
							<gml:surfaceMember xlink:href="#poly-aee45a73-b3a0-46a8-959c-fedcdb5d1687"/>
							<gml:surfaceMember xlink:href="#poly-87c3ec54-3d6c-4fb6-bc5e-aad6b665ff13"/>
							<gml:surfaceMember xlink:href="#poly-cf8ffdd3-37c4-47bf-ab30-fadb122882b4"/>
							<gml:surfaceMember xlink:href="#poly-aeab23cd-3a01-4ad8-91f0-97571dd89f82"/>
							<gml:surfaceMember xlink:href="#poly-f76c2651-8aee-4003-840a-cb6b81f13fab"/>
							<gml:surfaceMember xlink:href="#poly-eda5bd38-a2a1-462e-9cb4-1203d4e8272d"/>
							<gml:surfaceMember xlink:href="#poly-77b667ea-058e-4aba-8460-528f4f075fc7"/>
							<gml:surfaceMember xlink:href="#poly-980cefc9-113b-467b-9288-c6458729d4a5"/>
							<gml:surfaceMember xlink:href="#poly-f7358cab-5a3e-4d23-a9ff-5d90839aa377"/>
							<gml:surfaceMember xlink:href="#poly-a43f971d-5945-45f1-8372-f64bb18afa52"/>
							<gml:surfaceMember xlink:href="#poly-fed08f2f-9836-47df-995f-1b8c6d6b412e"/>
							<gml:surfaceMember xlink:href="#poly-14e6915d-c7a3-4aef-bc30-2637f4c34e5e"/>
							<gml:surfaceMember xlink:href="#poly-7ef42d14-e045-472a-a9cc-8286ed6cd5e3"/>
							<gml:surfaceMember xlink:href="#poly-4c15c6cc-41eb-43a5-bb19-ccb9cbb79c73"/>
							<gml:surfaceMember xlink:href="#poly-b62cab69-b7fb-446c-9c4d-d9e43c42da40"/>
							<gml:surfaceMember xlink:href="#poly-efcdf4f1-9123-48cd-b6c9-09d825d03ba5"/>
							<gml:surfaceMember xlink:href="#poly-b217a605-d344-4929-9021-a61ec3d4ee01"/>
							<gml:surfaceMember xlink:href="#poly-8ec466a3-7650-4db0-bc57-aad162f41443"/>
							<gml:surfaceMember xlink:href="#poly-754ee28a-a737-48d8-81df-a8307309380d"/>
							<gml:surfaceMember xlink:href="#poly-3e4377c6-4ad5-4bc8-9e59-710d95123d02"/>
							<gml:surfaceMember xlink:href="#poly-5d027750-7e13-4812-bb48-c2db27b02d3a"/>
							<gml:surfaceMember xlink:href="#poly-12dca480-2dba-4c4f-af8e-3db857322e5f"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_672e277b-676a-4e15-8203-f35dca0dee64_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea9a8e5d-f8cb-4e17-8d93-0c56b5c2c88d">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66705743935617 139.7419188376576 34.541 35.6670628771162 139.74192210101606 34.541 35.66706127570793 139.74192610142208 34.541 35.66707314318194 139.7419332124377 34.541 35.66706809673342 139.74194672720722 34.541 35.66705664407612 139.74193985872492 34.541 35.66705375615196 139.7419470859705 34.541 35.66706537113139 139.74195405368084 34.541 35.66705813879471 139.74197343625923 34.541 35.667043971766375 139.74196493608835 34.541 35.66704008521083 139.74197466082038 34.541 35.66701872195044 139.74196184994426 34.541 35.667047052367515 139.74189092571547 34.541 35.66706442975597 139.74190135522844 34.541 35.66705743935617 139.7419188376576 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f33b839c-4118-4ee6-8dd6-9034bc09b4de">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66706809673342 139.74194672720722 35.3 35.667073134168206 139.74193321244795 35.3 35.6670748295204 139.74193422672954 35.3 35.66706978307178 139.7419477414993 35.3 35.66706809673342 139.74194672720722 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aafc3bfc-8ee5-40c8-acde-f6b2e0c4c2bd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66709649800395 139.74186229382633 34.541 35.66708718736966 139.74188675986147 34.541 35.6670643276367 139.7418737077005 34.541 35.66707362925465 139.7418492416811 34.541 35.66709649800395 139.74186229382633 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eea48601-5fb7-4372-ba2f-d862b876625f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667091117853886 139.7417806493621 34.541 35.66710220169287 139.74175292277505 34.541 35.66710406839141 139.74175404731557 34.541 35.667151041024724 139.74178045944163 34.541 35.6671410831315 139.74180717958765 34.541 35.667123769385384 139.74179747903602 34.541 35.6671229957749 139.74179954548578 34.541 35.667091117853886 139.7417806493621 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4955dac-c71a-4630-9fc4-2a29c9bd8003">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66710307436954 139.7417507457542 35.3 35.667153699159044 139.7417792524129 35.3 35.66714200484049 139.7418102161343 35.3 35.66712483540663 139.7418006369211 35.3 35.6671229957749 139.74179954548578 35.3 35.667123769385384 139.74179747903602 35.3 35.6671410831315 139.74180717958765 35.3 35.667151041024724 139.74178045944163 35.3 35.66710406839141 139.74175404731557 35.3 35.66710220169287 139.74175292277505 35.3 35.66710307436954 139.7417507457542 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c40b4eb-09ba-49b8-8b49-a1c2f270bfe4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66702508552086 139.7419735622842 34.541 35.667026708528255 139.7419742673661 34.541 35.66702817859557 139.7419753592252 34.541 35.66702942358785 139.74197680480628 34.541 35.66703039838614 139.74197853788604 34.541 35.66703105786313 139.7419804811952 34.541 35.66703137491059 139.74198254639828 34.541 35.667031331434046 139.74198464514947 34.541 35.66703093638016 139.74198668907218 34.541 35.66703019869565 139.7419885897898 34.541 35.667029163390495 139.74199026993045 34.541 35.66702785743889 139.741991641097 34.541 35.667026352908756 139.7419926479784 34.541 35.667024703848945 139.74199324632988 34.541 35.667023000380006 139.74199341395723 34.541 35.66702129658431 139.74199315079886 34.541 35.667019673577016 139.74199244571662 34.541 35.66701821252358 139.74199135384703 34.541 35.66701695851774 139.74198990827617 34.541 35.66701598371962 139.74198817519658 34.541 35.667015324242755 139.74198623188772 34.541 35.66701500719534 139.74198416668506 34.541 35.66701505067189 139.74198206793426 34.541 35.667015445725696 139.74198002401195 34.541 35.667016183410084 139.74197812329461 34.541 35.66701721871506 139.74197644315407 34.541 35.667018524666496 139.74197507198747 34.541 35.6670200291965 139.74197406510584 34.541 35.66702167825621 139.741973466754 34.541 35.66702339073884 139.74197329911595 34.541 35.66702508552086 139.7419735622842 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91513e5f-1322-4adf-a155-3cf0a00538d2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66703019869565 139.7419885897898 34.541 35.66703093638016 139.74198668907218 34.541 35.66703093638016 139.74198668907218 35.902 35.66703019869565 139.7419885897898 35.902 35.66703019869565 139.7419885897898 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2e767b8-2902-405b-b56c-b24f565423d4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667031331434046 139.74198464514947 34.541 35.667031331434046 139.74198464514947 35.902 35.66703093638016 139.74198668907218 35.902 35.66703093638016 139.74198668907218 34.541 35.667031331434046 139.74198464514947 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e55d6b01-9d2b-4a7d-aa74-ef374286a464">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66703098346814 139.74198935105593 34.541 35.66703098346814 139.74198935105593 35.902 35.66703162197651 139.74198741731388 35.902 35.66703162197651 139.74198741731388 34.541 35.66703098346814 139.74198935105593 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53b80866-c952-4170-b0b1-0907220fec30">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66703162197651 139.74198741731388 34.541 35.66703162197651 139.74198741731388 35.902 35.66703257611617 139.74198568203659 35.902 35.66703257611617 139.74198568203659 34.541 35.66703162197651 139.74198741731388 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea5143ff-4432-4359-93e4-5a0c19b6fc68">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66704469018966 139.74198517117551 34.541 35.66704574604435 139.74198681579696 34.541 35.66704648659449 139.7419886927394 34.541 35.66704690276768 139.7419907246926 34.541 35.66704695843362 139.74199281228547 34.541 35.667046662547364 139.74199487818717 34.541 35.667046024038875 139.7419968119295 34.541 35.66704506989906 139.74199854720695 34.541 35.66704384512955 139.7419999956018 34.541 35.66704239475711 139.74200110183372 34.541 35.66704079084968 139.74200181059172 34.541 35.66703910550036 139.7420020997021 34.541 35.66703740179683 139.74200195804715 34.541 35.6670357608543 139.7420013744888 34.541 35.66703425481608 139.74200039312805 34.541 35.66703294681177 139.74199905807626 34.541 35.6670318999626 139.74199740239888 34.541 35.66703115039888 139.74199552546696 34.541 35.667030743239486 139.74199349350388 34.541 35.667030678559826 139.7419914059217 34.541 35.66703098346814 139.74198935105593 34.541 35.66703162197651 139.74198741731388 34.541 35.66703257611617 139.74198568203659 34.541 35.66703380087713 139.74198422259596 34.541 35.667035251249416 139.74198311636383 34.541 35.66703685515673 139.74198240760552 34.541 35.667038540506006 139.74198211849475 34.541 35.66704024420956 139.74198226014926 34.541 35.66704188515219 139.74198284370726 34.541 35.667043391190546 139.74198382506773 34.541 35.66704469018966 139.74198517117551 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2ececf6-6406-47b4-a1c6-cd32ca6790b6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66705813879471 139.74197343625923 35.3 35.66706537113139 139.74195405368084 35.3 35.66706705746969 139.74195506797304 35.3 35.66705982513284 139.74197445055174 35.3 35.66705813879471 139.74197343625923 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99697ed1-3f14-4bf3-a4ba-530a14071ede">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99697ed1-3f14-4bf3-a4ba-530a14071ede_0">
											<gml:posList>35.667029163390495 139.74199026993045 34.541 35.66703019869565 139.7419885897898 34.541 35.66703019869565 139.7419885897898 35.902 35.667029163390495 139.74199026993045 35.902 35.667029163390495 139.74199026993045 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80b6bb4b-79b8-4be8-9168-31aadbcb0adf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80b6bb4b-79b8-4be8-9168-31aadbcb0adf_0">
											<gml:posList>35.667030678559826 139.7419914059217 34.541 35.667030678559826 139.7419914059217 35.902 35.66703098346814 139.74198935105593 35.902 35.66703098346814 139.74198935105593 34.541 35.667030678559826 139.7419914059217 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e327e484-1e23-4a7a-b4e5-f65457644271">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e327e484-1e23-4a7a-b4e5-f65457644271_0">
											<gml:posList>35.667031331434046 139.74198464514947 34.541 35.66703137491059 139.74198254639828 34.541 35.66703137491059 139.74198254639828 35.902 35.667031331434046 139.74198464514947 35.902 35.667031331434046 139.74198464514947 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-73eb53c2-c4fc-4c51-9384-58e9036a9475">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-73eb53c2-c4fc-4c51-9384-58e9036a9475_0">
											<gml:posList>35.66703257611617 139.74198568203659 34.541 35.66703257611617 139.74198568203659 35.902 35.66703380087713 139.74198422259596 35.902 35.66703380087713 139.74198422259596 34.541 35.66703257611617 139.74198568203659 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d827d81b-4c19-4446-9dff-c1d94d7ad91b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d827d81b-4c19-4446-9dff-c1d94d7ad91b_0">
											<gml:posList>35.66710406839141 139.74175404731557 34.541 35.66710220169287 139.74175292277505 34.541 35.66710220169287 139.74175292277505 35.3 35.66710406839141 139.74175404731557 35.3 35.66710406839141 139.74175404731557 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f74f9d9-5ef9-432a-828e-73a656c06145">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f74f9d9-5ef9-432a-828e-73a656c06145_0">
											<gml:posList>35.66710307436954 139.7417507457542 35.3 35.66710307436954 139.7417507457542 37.2 35.667153699159044 139.7417792524129 37.2 35.667153699159044 139.7417792524129 35.3 35.66710307436954 139.7417507457542 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e18f74cc-6fa3-414f-9ede-c28eec24a02f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e18f74cc-6fa3-414f-9ede-c28eec24a02f_0">
											<gml:posList>35.66710220169287 139.74175292277505 35.3 35.66710220169287 139.74175292277505 34.541 35.667091117853886 139.7417806493621 34.541 35.667091117853886 139.7417806493621 37.2 35.66710307436954 139.7417507457542 37.2 35.66710307436954 139.7417507457542 35.3 35.66710220169287 139.74175292277505 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea6f49c5-3ee1-4106-87fa-aff55c99d337">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea6f49c5-3ee1-4106-87fa-aff55c99d337_0">
											<gml:posList>35.667151041024724 139.74178045944163 35.3 35.667151041024724 139.74178045944163 34.541 35.66710406839141 139.74175404731557 34.541 35.66710406839141 139.74175404731557 35.3 35.667151041024724 139.74178045944163 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ec36c6f7-a8d5-47c1-8850-2b3e8b9c1e9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ec36c6f7-a8d5-47c1-8850-2b3e8b9c1e9f_0">
											<gml:posList>35.66712483540663 139.7418006369211 37.2 35.66714200484049 139.7418102161343 37.2 35.667153699159044 139.7417792524129 37.2 35.66710307436954 139.7417507457542 37.2 35.667091117853886 139.7417806493621 37.2 35.66712483540663 139.7418006369211 37.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-70a9fff0-b92f-422b-beab-5e6859d8d485">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-70a9fff0-b92f-422b-beab-5e6859d8d485_0">
											<gml:posList>35.6671229957749 139.74179954548578 35.3 35.66712483540663 139.7418006369211 35.3 35.66712483540663 139.7418006369211 37.2 35.667091117853886 139.7417806493621 37.2 35.667091117853886 139.7417806493621 34.541 35.6671229957749 139.74179954548578 34.541 35.6671229957749 139.74179954548578 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c43deb0-5aac-41b2-ab58-78f169583d03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c43deb0-5aac-41b2-ab58-78f169583d03_0">
											<gml:posList>35.6671410831315 139.74180717958765 35.3 35.6671410831315 139.74180717958765 34.541 35.667151041024724 139.74178045944163 34.541 35.667151041024724 139.74178045944163 35.3 35.6671410831315 139.74180717958765 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a58b834d-0235-47ed-a341-d3eb44e25907">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a58b834d-0235-47ed-a341-d3eb44e25907_0">
											<gml:posList>35.667153699159044 139.7417792524129 37.2 35.66714200484049 139.7418102161343 37.2 35.66714200484049 139.7418102161343 35.3 35.667153699159044 139.7417792524129 35.3 35.667153699159044 139.7417792524129 37.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea408d7e-efa1-45fc-b3bd-89e2d0fb23ce">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea408d7e-efa1-45fc-b3bd-89e2d0fb23ce_0">
											<gml:posList>35.667123769385384 139.74179747903602 35.3 35.6671229957749 139.74179954548578 35.3 35.6671229957749 139.74179954548578 34.541 35.667123769385384 139.74179747903602 34.541 35.667123769385384 139.74179747903602 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-664d15fd-645c-4694-bad7-3d4fc0f6e644">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-664d15fd-645c-4694-bad7-3d4fc0f6e644_0">
											<gml:posList>35.667123769385384 139.74179747903602 34.541 35.6671410831315 139.74180717958765 34.541 35.6671410831315 139.74180717958765 35.3 35.667123769385384 139.74179747903602 35.3 35.667123769385384 139.74179747903602 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e092457d-36b8-497b-8d6c-6126db460088">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e092457d-36b8-497b-8d6c-6126db460088_0">
											<gml:posList>35.66714200484049 139.7418102161343 37.2 35.66712483540663 139.7418006369211 37.2 35.66712483540663 139.7418006369211 35.3 35.66714200484049 139.7418102161343 35.3 35.66714200484049 139.7418102161343 37.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-233360f1-672d-401b-9ca9-2b388b97d5f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-233360f1-672d-401b-9ca9-2b388b97d5f2_0">
											<gml:posList>35.66707362925465 139.7418492416811 34.541 35.66707362925465 139.7418492416811 35.902 35.66709649800395 139.74186229382633 35.902 35.66709649800395 139.74186229382633 34.541 35.66707362925465 139.7418492416811 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0bbd1e4-9917-40ce-ac6a-d97d3467c0d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0bbd1e4-9917-40ce-ac6a-d97d3467c0d0_0">
											<gml:posList>35.66707362925465 139.7418492416811 34.541 35.6670643276367 139.7418737077005 34.541 35.6670643276367 139.7418737077005 35.902 35.66707362925465 139.7418492416811 35.902 35.66707362925465 139.7418492416811 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46ae2e32-d1d9-4d15-b5b2-5e7573d02cc8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46ae2e32-d1d9-4d15-b5b2-5e7573d02cc8_0">
											<gml:posList>35.6670643276367 139.7418737077005 35.902 35.66708718736966 139.74188675986147 35.902 35.66709649800395 139.74186229382633 35.902 35.66707362925465 139.7418492416811 35.902 35.6670643276367 139.7418737077005 35.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4dc9ec6-e426-4fc1-84ee-db1feca9786b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4dc9ec6-e426-4fc1-84ee-db1feca9786b_0">
											<gml:posList>35.66708718736966 139.74188675986147 34.541 35.66709649800395 139.74186229382633 34.541 35.66709649800395 139.74186229382633 35.902 35.66708718736966 139.74188675986147 35.902 35.66708718736966 139.74188675986147 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1f4270de-8b37-4f1d-ab53-ceb9052eee92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1f4270de-8b37-4f1d-ab53-ceb9052eee92_0">
											<gml:posList>35.6670643276367 139.7418737077005 34.541 35.66708718736966 139.74188675986147 34.541 35.66708718736966 139.74188675986147 35.902 35.6670643276367 139.7418737077005 35.902 35.6670643276367 139.7418737077005 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-083fa6ec-e81a-4d10-9f9c-c12c63139a97">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-083fa6ec-e81a-4d10-9f9c-c12c63139a97_0">
											<gml:posList>35.667047052367515 139.74189092571547 35.902 35.66706442975597 139.74190135522844 35.902 35.66706442975597 139.74190135522844 34.541 35.667047052367515 139.74189092571547 34.541 35.667047052367515 139.74189092571547 35.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cd437dff-ba88-45ff-b51c-917909fc9b58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cd437dff-ba88-45ff-b51c-917909fc9b58_0">
											<gml:posList>35.66706442975597 139.74190135522844 34.541 35.66706442975597 139.74190135522844 35.902 35.66705743935617 139.7419188376576 35.902 35.66705743935617 139.7419188376576 34.541 35.66706442975597 139.74190135522844 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4d775c3-fb5e-49ba-b813-ea6f424dd5bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4d775c3-fb5e-49ba-b813-ea6f424dd5bc_0">
											<gml:posList>35.66705743935617 139.7419188376576 34.541 35.66705743935617 139.7419188376576 35.902 35.6670628771162 139.74192210101606 35.902 35.6670628771162 139.74192210101606 34.541 35.66705743935617 139.7419188376576 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-03f537c5-0427-465f-89b8-23d988c178df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-03f537c5-0427-465f-89b8-23d988c178df_0">
											<gml:posList>35.6670628771162 139.74192210101606 35.902 35.66706127570793 139.74192610142208 35.902 35.66706127570793 139.74192610142208 34.541 35.6670628771162 139.74192210101606 34.541 35.6670628771162 139.74192210101606 35.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c043c8a8-057c-4be9-a0a6-d050d30ca896">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c043c8a8-057c-4be9-a0a6-d050d30ca896_0">
											<gml:posList>35.66701872195044 139.74196184994426 34.541 35.66701872195044 139.74196184994426 35.902 35.667047052367515 139.74189092571547 35.902 35.667047052367515 139.74189092571547 34.541 35.66701872195044 139.74196184994426 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7222bd4c-1e0c-4ca0-864a-84a0c243c6fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7222bd4c-1e0c-4ca0-864a-84a0c243c6fd_0">
											<gml:posList>35.66706127570793 139.74192610142208 34.541 35.66706127570793 139.74192610142208 35.902 35.6670748295204 139.74193422672954 35.902 35.6670748295204 139.74193422672954 35.3 35.667073134168206 139.74193321244795 35.3 35.66707314318194 139.7419332124377 34.541 35.66706127570793 139.74192610142208 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb4c9d79-3ebc-4933-a5e0-78f7134996d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-eb4c9d79-3ebc-4933-a5e0-78f7134996d1_0">
											<gml:posList>35.667047052367515 139.74189092571547 35.902 35.66701872195044 139.74196184994426 35.902 35.66704008521083 139.74197466082038 35.902 35.667043971766375 139.74196493608835 35.902 35.66705982513284 139.74197445055174 35.902 35.66706705746969 139.74195506797304 35.902 35.66705375615196 139.7419470859705 35.902 35.66705664407612 139.74193985872492 35.902 35.66706978307178 139.7419477414993 35.902 35.6670748295204 139.74193422672954 35.902 35.66706127570793 139.74192610142208 35.902 35.6670628771162 139.74192210101606 35.902 35.66705743935617 139.7419188376576 35.902 35.66706442975597 139.74190135522844 35.902 35.667047052367515 139.74189092571547 35.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-06e2d778-761a-40fd-9ae3-04bd38bea480">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-06e2d778-761a-40fd-9ae3-04bd38bea480_0">
											<gml:posList>35.66706809673342 139.74194672720722 35.3 35.66706809673342 139.74194672720722 34.541 35.66707314318194 139.7419332124377 34.541 35.667073134168206 139.74193321244795 35.3 35.66706809673342 139.74194672720722 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69fa2b71-6441-4c61-9885-d524da9a6107">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69fa2b71-6441-4c61-9885-d524da9a6107_0">
											<gml:posList>35.6670748295204 139.74193422672954 35.3 35.6670748295204 139.74193422672954 35.902 35.66706978307178 139.7419477414993 35.902 35.66706978307178 139.7419477414993 35.3 35.6670748295204 139.74193422672954 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c776a023-91f8-4690-b54a-93e2e64a0bc4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c776a023-91f8-4690-b54a-93e2e64a0bc4_0">
											<gml:posList>35.66705664407612 139.74193985872492 34.541 35.66705664407612 139.74193985872492 35.902 35.66705375615196 139.7419470859705 35.902 35.66705375615196 139.7419470859705 34.541 35.66705664407612 139.74193985872492 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35e1129a-4d18-4198-84d4-dcd4659d4635">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35e1129a-4d18-4198-84d4-dcd4659d4635_0">
											<gml:posList>35.66706809673342 139.74194672720722 35.3 35.66706978307178 139.7419477414993 35.3 35.66706978307178 139.7419477414993 35.902 35.66705664407612 139.74193985872492 35.902 35.66705664407612 139.74193985872492 34.541 35.66706809673342 139.74194672720722 34.541 35.66706809673342 139.74194672720722 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f14bec7a-ea3e-418c-9d70-9510787e314e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f14bec7a-ea3e-418c-9d70-9510787e314e_0">
											<gml:posList>35.66705375615196 139.7419470859705 34.541 35.66705375615196 139.7419470859705 35.902 35.66706705746969 139.74195506797304 35.902 35.66706705746969 139.74195506797304 35.3 35.66706537113139 139.74195405368084 35.3 35.66706537113139 139.74195405368084 34.541 35.66705375615196 139.7419470859705 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d6faafda-211f-4b19-a33e-6965018eb56e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d6faafda-211f-4b19-a33e-6965018eb56e_0">
											<gml:posList>35.66706537113139 139.74195405368084 34.541 35.66706537113139 139.74195405368084 35.3 35.66705813879471 139.74197343625923 35.3 35.66705813879471 139.74197343625923 34.541 35.66706537113139 139.74195405368084 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a62c04ac-8eb0-4dd5-87ba-e777baa15243">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a62c04ac-8eb0-4dd5-87ba-e777baa15243_0">
											<gml:posList>35.66706705746969 139.74195506797304 35.3 35.66706705746969 139.74195506797304 35.902 35.66705982513284 139.74197445055174 35.902 35.66705982513284 139.74197445055174 35.3 35.66706705746969 139.74195506797304 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-422877be-2b68-409e-994e-4ec8db67f615">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-422877be-2b68-409e-994e-4ec8db67f615_0">
											<gml:posList>35.66704008521083 139.74197466082038 34.541 35.66704008521083 139.74197466082038 35.902 35.66701872195044 139.74196184994426 35.902 35.66701872195044 139.74196184994426 34.541 35.66704008521083 139.74197466082038 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1625d05-5fb1-4270-b6a3-37dd61531f53">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1625d05-5fb1-4270-b6a3-37dd61531f53_0">
											<gml:posList>35.66705813879471 139.74197343625923 35.3 35.66705982513284 139.74197445055174 35.3 35.66705982513284 139.74197445055174 35.902 35.667043971766375 139.74196493608835 35.902 35.667043971766375 139.74196493608835 34.541 35.66705813879471 139.74197343625923 34.541 35.66705813879471 139.74197343625923 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96aa6b51-2038-4bcb-a0fa-a2aee849389e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96aa6b51-2038-4bcb-a0fa-a2aee849389e_0">
											<gml:posList>35.667043971766375 139.74196493608835 34.541 35.667043971766375 139.74196493608835 35.902 35.66704008521083 139.74197466082038 35.902 35.66704008521083 139.74197466082038 34.541 35.667043971766375 139.74196493608835 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53af0d40-497b-4865-ac89-6ec2b4783b38">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53af0d40-497b-4865-ac89-6ec2b4783b38_0">
											<gml:posList>35.66702167825621 139.741973466754 34.541 35.66702167825621 139.741973466754 35.902 35.66702339073884 139.74197329911595 35.902 35.66702339073884 139.74197329911595 34.541 35.66702167825621 139.741973466754 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6c888d6-4a71-408f-9806-bd4dc2083d60">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6c888d6-4a71-408f-9806-bd4dc2083d60_0">
											<gml:posList>35.66702339073884 139.74197329911595 34.541 35.66702339073884 139.74197329911595 35.902 35.66702508552086 139.7419735622842 35.902 35.66702508552086 139.7419735622842 34.541 35.66702339073884 139.74197329911595 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bd758d3d-c322-4632-b9a3-ed9cf2ae0cf4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bd758d3d-c322-4632-b9a3-ed9cf2ae0cf4_0">
											<gml:posList>35.66702167825621 139.741973466754 34.541 35.6670200291965 139.74197406510584 34.541 35.6670200291965 139.74197406510584 35.902 35.66702167825621 139.741973466754 35.902 35.66702167825621 139.741973466754 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d76a346-2f6d-464e-b75c-0901caeba475">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d76a346-2f6d-464e-b75c-0901caeba475_0">
											<gml:posList>35.667026708528255 139.7419742673661 34.541 35.66702508552086 139.7419735622842 34.541 35.66702508552086 139.7419735622842 35.902 35.667026708528255 139.7419742673661 35.902 35.667026708528255 139.7419742673661 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12ad4039-e8eb-4ba6-9b7a-981bf60e2404">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-12ad4039-e8eb-4ba6-9b7a-981bf60e2404_0">
											<gml:posList>35.6670200291965 139.74197406510584 34.541 35.667018524666496 139.74197507198747 34.541 35.667018524666496 139.74197507198747 35.902 35.6670200291965 139.74197406510584 35.902 35.6670200291965 139.74197406510584 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6da00e20-80c0-4d8f-bab1-01f8f944f644">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6da00e20-80c0-4d8f-bab1-01f8f944f644_0">
											<gml:posList>35.66702817859557 139.7419753592252 34.541 35.667026708528255 139.7419742673661 34.541 35.667026708528255 139.7419742673661 35.902 35.66702817859557 139.7419753592252 35.902 35.66702817859557 139.7419753592252 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7b8877f-3b27-4448-a4c6-2689f6220c27">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7b8877f-3b27-4448-a4c6-2689f6220c27_0">
											<gml:posList>35.667018524666496 139.74197507198747 34.541 35.66701721871506 139.74197644315407 34.541 35.66701721871506 139.74197644315407 35.902 35.667018524666496 139.74197507198747 35.902 35.667018524666496 139.74197507198747 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7942e6f7-7809-4ba3-95ec-1301423dafcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7942e6f7-7809-4ba3-95ec-1301423dafcb_0">
											<gml:posList>35.66702942358785 139.74197680480628 34.541 35.66702817859557 139.7419753592252 34.541 35.66702817859557 139.7419753592252 35.902 35.66702942358785 139.74197680480628 35.902 35.66702942358785 139.74197680480628 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b62168c5-7e46-4cc0-9410-daf27905f242">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b62168c5-7e46-4cc0-9410-daf27905f242_0">
											<gml:posList>35.66701721871506 139.74197644315407 34.541 35.667016183410084 139.74197812329461 34.541 35.667016183410084 139.74197812329461 35.902 35.66701721871506 139.74197644315407 35.902 35.66701721871506 139.74197644315407 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d894eba4-4090-48df-a365-d013f8dccf68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d894eba4-4090-48df-a365-d013f8dccf68_0">
											<gml:posList>35.66703039838614 139.74197853788604 34.541 35.66702942358785 139.74197680480628 34.541 35.66702942358785 139.74197680480628 35.902 35.66703039838614 139.74197853788604 35.902 35.66703039838614 139.74197853788604 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f6de2fe-95d7-4627-bc54-209aaaa59b0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f6de2fe-95d7-4627-bc54-209aaaa59b0d_0">
											<gml:posList>35.667016183410084 139.74197812329461 34.541 35.667015445725696 139.74198002401195 34.541 35.667015445725696 139.74198002401195 35.902 35.667016183410084 139.74197812329461 35.902 35.667016183410084 139.74197812329461 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6a4d0086-7f2a-46ac-a187-58f3e4a6235d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6a4d0086-7f2a-46ac-a187-58f3e4a6235d_0">
											<gml:posList>35.66703105786313 139.7419804811952 34.541 35.66703039838614 139.74197853788604 34.541 35.66703039838614 139.74197853788604 35.902 35.66703105786313 139.7419804811952 35.902 35.66703105786313 139.7419804811952 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2002dab0-5e0c-443e-b83d-888ad0db0fa3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2002dab0-5e0c-443e-b83d-888ad0db0fa3_0">
											<gml:posList>35.667015445725696 139.74198002401195 34.541 35.66701505067189 139.74198206793426 34.541 35.66701505067189 139.74198206793426 35.902 35.667015445725696 139.74198002401195 35.902 35.667015445725696 139.74198002401195 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-831ef00c-3072-45be-80ab-c0f36efb4d20">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-831ef00c-3072-45be-80ab-c0f36efb4d20_0">
											<gml:posList>35.66703137491059 139.74198254639828 34.541 35.66703105786313 139.7419804811952 34.541 35.66703105786313 139.7419804811952 35.902 35.66703137491059 139.74198254639828 35.902 35.66703137491059 139.74198254639828 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc92d670-a4be-4911-a167-57a9b674457f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc92d670-a4be-4911-a167-57a9b674457f_0">
											<gml:posList>35.667038540506006 139.74198211849475 35.902 35.66704024420956 139.74198226014926 35.902 35.66704024420956 139.74198226014926 34.541 35.667038540506006 139.74198211849475 34.541 35.667038540506006 139.74198211849475 35.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-831e4ace-affc-47d3-904a-26663e907fed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-831e4ace-affc-47d3-904a-26663e907fed_0">
											<gml:posList>35.66703685515673 139.74198240760552 34.541 35.66703685515673 139.74198240760552 35.902 35.667038540506006 139.74198211849475 35.902 35.667038540506006 139.74198211849475 34.541 35.66703685515673 139.74198240760552 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d49a144-96d5-4a42-b334-5d4c050f2d35">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d49a144-96d5-4a42-b334-5d4c050f2d35_0">
											<gml:posList>35.66704024420956 139.74198226014926 34.541 35.66704024420956 139.74198226014926 35.902 35.66704188515219 139.74198284370726 35.902 35.66704188515219 139.74198284370726 34.541 35.66704024420956 139.74198226014926 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1620f75c-8285-48c0-97c7-81c2755be1c4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1620f75c-8285-48c0-97c7-81c2755be1c4_0">
											<gml:posList>35.667035251249416 139.74198311636383 34.541 35.667035251249416 139.74198311636383 35.902 35.66703685515673 139.74198240760552 35.902 35.66703685515673 139.74198240760552 34.541 35.667035251249416 139.74198311636383 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-059033db-8464-4ea0-b60d-b9aac0ff86d2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-059033db-8464-4ea0-b60d-b9aac0ff86d2_0">
											<gml:posList>35.66701505067189 139.74198206793426 34.541 35.66701500719534 139.74198416668506 34.541 35.66701500719534 139.74198416668506 35.902 35.66701505067189 139.74198206793426 35.902 35.66701505067189 139.74198206793426 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55dc00fd-5b24-4695-8217-59d908b46368">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55dc00fd-5b24-4695-8217-59d908b46368_0">
											<gml:posList>35.66704188515219 139.74198284370726 34.541 35.66704188515219 139.74198284370726 35.902 35.667043391190546 139.74198382506773 35.902 35.667043391190546 139.74198382506773 34.541 35.66704188515219 139.74198284370726 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77c1f876-8cb1-4cdd-8742-8a74dd285514">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77c1f876-8cb1-4cdd-8742-8a74dd285514_0">
											<gml:posList>35.66702167825621 139.741973466754 35.902 35.6670200291965 139.74197406510584 35.902 35.667018524666496 139.74197507198747 35.902 35.66701721871506 139.74197644315407 35.902 35.667016183410084 139.74197812329461 35.902 35.667015445725696 139.74198002401195 35.902 35.66701505067189 139.74198206793426 35.902 35.66701500719534 139.74198416668506 35.902 35.667015324242755 139.74198623188772 35.902 35.66701598371962 139.74198817519658 35.902 35.66701695851774 139.74198990827617 35.902 35.66701821252358 139.74199135384703 35.902 35.667019673577016 139.74199244571662 35.902 35.66702129658431 139.74199315079886 35.902 35.667023000380006 139.74199341395723 35.902 35.667024703848945 139.74199324632988 35.902 35.667026352908756 139.7419926479784 35.902 35.66702785743889 139.741991641097 35.902 35.667029163390495 139.74199026993045 35.902 35.66703019869565 139.7419885897898 35.902 35.66703093638016 139.74198668907218 35.902 35.667031331434046 139.74198464514947 35.902 35.66703137491059 139.74198254639828 35.902 35.66703105786313 139.7419804811952 35.902 35.66703039838614 139.74197853788604 35.902 35.66702942358785 139.74197680480628 35.902 35.66702817859557 139.7419753592252 35.902 35.667026708528255 139.7419742673661 35.902 35.66702508552086 139.7419735622842 35.902 35.66702339073884 139.74197329911595 35.902 35.66702167825621 139.741973466754 35.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0f19483-9925-4a7e-b4f6-da36dcb7b661">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0f19483-9925-4a7e-b4f6-da36dcb7b661_0">
											<gml:posList>35.66703380087713 139.74198422259596 34.541 35.66703380087713 139.74198422259596 35.902 35.667035251249416 139.74198311636383 35.902 35.667035251249416 139.74198311636383 34.541 35.66703380087713 139.74198422259596 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20909ddf-4c37-49ba-89f2-2075500228e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20909ddf-4c37-49ba-89f2-2075500228e2_0">
											<gml:posList>35.667043391190546 139.74198382506773 34.541 35.667043391190546 139.74198382506773 35.902 35.66704469018966 139.74198517117551 35.902 35.66704469018966 139.74198517117551 34.541 35.667043391190546 139.74198382506773 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23dac0f4-fbfe-4c25-af84-8bac00a09336">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23dac0f4-fbfe-4c25-af84-8bac00a09336_0">
											<gml:posList>35.667015324242755 139.74198623188772 34.541 35.667015324242755 139.74198623188772 35.902 35.66701500719534 139.74198416668506 35.902 35.66701500719534 139.74198416668506 34.541 35.667015324242755 139.74198623188772 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f57c0e7-d7ac-4631-b23d-631510689e85">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f57c0e7-d7ac-4631-b23d-631510689e85_0">
											<gml:posList>35.66704469018966 139.74198517117551 34.541 35.66704469018966 139.74198517117551 35.902 35.66704574604435 139.74198681579696 35.902 35.66704574604435 139.74198681579696 34.541 35.66704469018966 139.74198517117551 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d216a65-80b3-473b-adb7-94eaa47ae7eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d216a65-80b3-473b-adb7-94eaa47ae7eb_0">
											<gml:posList>35.66701598371962 139.74198817519658 34.541 35.66701598371962 139.74198817519658 35.902 35.667015324242755 139.74198623188772 35.902 35.667015324242755 139.74198623188772 34.541 35.66701598371962 139.74198817519658 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3b17177-7056-4265-9419-b5da761215fc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3b17177-7056-4265-9419-b5da761215fc_0">
											<gml:posList>35.66704574604435 139.74198681579696 34.541 35.66704574604435 139.74198681579696 35.902 35.66704648659449 139.7419886927394 35.902 35.66704648659449 139.7419886927394 34.541 35.66704574604435 139.74198681579696 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-23464171-9a50-40dc-ac6f-b5e2a4c989ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-23464171-9a50-40dc-ac6f-b5e2a4c989ab_0">
											<gml:posList>35.66701598371962 139.74198817519658 34.541 35.66701695851774 139.74198990827617 34.541 35.66701695851774 139.74198990827617 35.902 35.66701598371962 139.74198817519658 35.902 35.66701598371962 139.74198817519658 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-079f2dd1-bb72-4981-a31a-192443ab4dd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-079f2dd1-bb72-4981-a31a-192443ab4dd1_0">
											<gml:posList>35.66704648659449 139.7419886927394 35.902 35.66704690276768 139.7419907246926 35.902 35.66704690276768 139.7419907246926 34.541 35.66704648659449 139.7419886927394 34.541 35.66704648659449 139.7419886927394 35.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-944b0d74-e36c-42d3-84f1-488b196a7235">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-944b0d74-e36c-42d3-84f1-488b196a7235_0">
											<gml:posList>35.66701695851774 139.74198990827617 34.541 35.66701821252358 139.74199135384703 34.541 35.66701821252358 139.74199135384703 35.902 35.66701695851774 139.74198990827617 35.902 35.66701695851774 139.74198990827617 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2726f2a8-86cf-4c0a-9184-bd74f6612c8d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2726f2a8-86cf-4c0a-9184-bd74f6612c8d_0">
											<gml:posList>35.667029163390495 139.74199026993045 34.541 35.667029163390495 139.74199026993045 35.902 35.66702785743889 139.741991641097 35.902 35.66702785743889 139.741991641097 34.541 35.667029163390495 139.74199026993045 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63efc06d-f82d-49a6-a4df-f8c48b5844ef">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63efc06d-f82d-49a6-a4df-f8c48b5844ef_0">
											<gml:posList>35.66704690276768 139.7419907246926 35.902 35.66704695843362 139.74199281228547 35.902 35.66704695843362 139.74199281228547 34.541 35.66704690276768 139.7419907246926 34.541 35.66704690276768 139.7419907246926 35.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2bf378d0-42d2-40a1-86a9-3cc8ebe9c90c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2bf378d0-42d2-40a1-86a9-3cc8ebe9c90c_0">
											<gml:posList>35.66701821252358 139.74199135384703 34.541 35.667019673577016 139.74199244571662 34.541 35.667019673577016 139.74199244571662 35.902 35.66701821252358 139.74199135384703 35.902 35.66701821252358 139.74199135384703 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cbdaa842-ee11-48b6-b75d-2ad42705ea54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cbdaa842-ee11-48b6-b75d-2ad42705ea54_0">
											<gml:posList>35.66704188515219 139.74198284370726 35.902 35.66704024420956 139.74198226014926 35.902 35.667038540506006 139.74198211849475 35.902 35.66703685515673 139.74198240760552 35.902 35.667035251249416 139.74198311636383 35.902 35.66703380087713 139.74198422259596 35.902 35.66703257611617 139.74198568203659 35.902 35.66703162197651 139.74198741731388 35.902 35.66703098346814 139.74198935105593 35.902 35.667030678559826 139.7419914059217 35.902 35.667030743239486 139.74199349350388 35.902 35.66703115039888 139.74199552546696 35.902 35.6670318999626 139.74199740239888 35.902 35.66703294681177 139.74199905807626 35.902 35.66703425481608 139.74200039312805 35.902 35.6670357608543 139.7420013744888 35.902 35.66703740179683 139.74200195804715 35.902 35.66703910550036 139.7420020997021 35.902 35.66704079084968 139.74200181059172 35.902 35.66704239475711 139.74200110183372 35.902 35.66704384512955 139.7419999956018 35.902 35.66704506989906 139.74199854720695 35.902 35.667046024038875 139.7419968119295 35.902 35.667046662547364 139.74199487818717 35.902 35.66704695843362 139.74199281228547 35.902 35.66704690276768 139.7419907246926 35.902 35.66704648659449 139.7419886927394 35.902 35.66704574604435 139.74198681579696 35.902 35.66704469018966 139.74198517117551 35.902 35.667043391190546 139.74198382506773 35.902 35.66704188515219 139.74198284370726 35.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-13b43961-afb0-4776-92b0-8a69fadcc487">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-13b43961-afb0-4776-92b0-8a69fadcc487_0">
											<gml:posList>35.667026352908756 139.7419926479784 34.541 35.66702785743889 139.741991641097 34.541 35.66702785743889 139.741991641097 35.902 35.667026352908756 139.7419926479784 35.902 35.667026352908756 139.7419926479784 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-31758a1c-cf82-4732-b176-576dbb80289e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-31758a1c-cf82-4732-b176-576dbb80289e_0">
											<gml:posList>35.667030743239486 139.74199349350388 34.541 35.667030743239486 139.74199349350388 35.902 35.667030678559826 139.7419914059217 35.902 35.667030678559826 139.7419914059217 34.541 35.667030743239486 139.74199349350388 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-686efb7f-ebb4-43c1-ba73-38f22b1ad63e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-686efb7f-ebb4-43c1-ba73-38f22b1ad63e_0">
											<gml:posList>35.667019673577016 139.74199244571662 34.541 35.66702129658431 139.74199315079886 34.541 35.66702129658431 139.74199315079886 35.902 35.667019673577016 139.74199244571662 35.902 35.667019673577016 139.74199244571662 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-687d3153-6d49-4d6c-befa-94aefab4fbcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-687d3153-6d49-4d6c-befa-94aefab4fbcc_0">
											<gml:posList>35.667026352908756 139.7419926479784 34.541 35.667026352908756 139.7419926479784 35.902 35.667024703848945 139.74199324632988 35.902 35.667024703848945 139.74199324632988 34.541 35.667026352908756 139.7419926479784 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c93cbff-dae3-461a-8126-394781a65bab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c93cbff-dae3-461a-8126-394781a65bab_0">
											<gml:posList>35.66702129658431 139.74199315079886 34.541 35.667023000380006 139.74199341395723 34.541 35.667023000380006 139.74199341395723 35.902 35.66702129658431 139.74199315079886 35.902 35.66702129658431 139.74199315079886 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-daba855d-8987-4b59-9ff3-5886fbc9d586">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-daba855d-8987-4b59-9ff3-5886fbc9d586_0">
											<gml:posList>35.667023000380006 139.74199341395723 34.541 35.667024703848945 139.74199324632988 34.541 35.667024703848945 139.74199324632988 35.902 35.667023000380006 139.74199341395723 35.902 35.667023000380006 139.74199341395723 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99f5c08c-ff50-445a-9493-81396d9498ee">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99f5c08c-ff50-445a-9493-81396d9498ee_0">
											<gml:posList>35.66704695843362 139.74199281228547 34.541 35.66704695843362 139.74199281228547 35.902 35.667046662547364 139.74199487818717 35.902 35.667046662547364 139.74199487818717 34.541 35.66704695843362 139.74199281228547 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3cca4654-db7c-4530-92da-5e624cfba569">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3cca4654-db7c-4530-92da-5e624cfba569_0">
											<gml:posList>35.66703115039888 139.74199552546696 34.541 35.66703115039888 139.74199552546696 35.902 35.667030743239486 139.74199349350388 35.902 35.667030743239486 139.74199349350388 34.541 35.66703115039888 139.74199552546696 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-834ce254-fb50-46dd-80d3-e5ec75dda2b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-834ce254-fb50-46dd-80d3-e5ec75dda2b2_0">
											<gml:posList>35.667046662547364 139.74199487818717 34.541 35.667046662547364 139.74199487818717 35.902 35.667046024038875 139.7419968119295 35.902 35.667046024038875 139.7419968119295 34.541 35.667046662547364 139.74199487818717 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5286680b-99f1-4e96-84bb-79bb61428558">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5286680b-99f1-4e96-84bb-79bb61428558_0">
											<gml:posList>35.6670318999626 139.74199740239888 34.541 35.6670318999626 139.74199740239888 35.902 35.66703115039888 139.74199552546696 35.902 35.66703115039888 139.74199552546696 34.541 35.6670318999626 139.74199740239888 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18832bc4-88b7-4c90-8bfa-13c6b3c72f92">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18832bc4-88b7-4c90-8bfa-13c6b3c72f92_0">
											<gml:posList>35.667046024038875 139.7419968119295 34.541 35.667046024038875 139.7419968119295 35.902 35.66704506989906 139.74199854720695 35.902 35.66704506989906 139.74199854720695 34.541 35.667046024038875 139.7419968119295 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53f41d8e-2e98-446c-864d-ac2fef80301d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53f41d8e-2e98-446c-864d-ac2fef80301d_0">
											<gml:posList>35.66703294681177 139.74199905807626 34.541 35.66703294681177 139.74199905807626 35.902 35.6670318999626 139.74199740239888 35.902 35.6670318999626 139.74199740239888 34.541 35.66703294681177 139.74199905807626 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-388878f0-b185-4164-8b53-364b5fc9b241">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-388878f0-b185-4164-8b53-364b5fc9b241_0">
											<gml:posList>35.66704506989906 139.74199854720695 34.541 35.66704506989906 139.74199854720695 35.902 35.66704384512955 139.7419999956018 35.902 35.66704384512955 139.7419999956018 34.541 35.66704506989906 139.74199854720695 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ea317aa-ba6d-4a1c-8ab9-f17017a19f29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ea317aa-ba6d-4a1c-8ab9-f17017a19f29_0">
											<gml:posList>35.66703425481608 139.74200039312805 34.541 35.66703425481608 139.74200039312805 35.902 35.66703294681177 139.74199905807626 35.902 35.66703294681177 139.74199905807626 34.541 35.66703425481608 139.74200039312805 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ab751c9-cc94-40bd-a4af-70cf3ecc2f45">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ab751c9-cc94-40bd-a4af-70cf3ecc2f45_0">
											<gml:posList>35.66704384512955 139.7419999956018 35.902 35.66704239475711 139.74200110183372 35.902 35.66704239475711 139.74200110183372 34.541 35.66704384512955 139.7419999956018 34.541 35.66704384512955 139.7419999956018 35.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c152fa6f-71e1-41eb-8093-cd929bc5db74">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c152fa6f-71e1-41eb-8093-cd929bc5db74_0">
											<gml:posList>35.6670357608543 139.7420013744888 34.541 35.6670357608543 139.7420013744888 35.902 35.66703425481608 139.74200039312805 35.902 35.66703425481608 139.74200039312805 34.541 35.6670357608543 139.7420013744888 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d67e00a5-688b-43c8-a942-4498d61f1d3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d67e00a5-688b-43c8-a942-4498d61f1d3c_0">
											<gml:posList>35.66704239475711 139.74200110183372 34.541 35.66704239475711 139.74200110183372 35.902 35.66704079084968 139.74200181059172 35.902 35.66704079084968 139.74200181059172 34.541 35.66704239475711 139.74200110183372 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-80b8a741-7f55-417c-a958-62329eb00efa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-80b8a741-7f55-417c-a958-62329eb00efa_0">
											<gml:posList>35.66703740179683 139.74200195804715 34.541 35.66703740179683 139.74200195804715 35.902 35.6670357608543 139.7420013744888 35.902 35.6670357608543 139.7420013744888 34.541 35.66703740179683 139.74200195804715 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65a58ce9-4dd1-43d2-9cd0-4bd992cd4061">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65a58ce9-4dd1-43d2-9cd0-4bd992cd4061_0">
											<gml:posList>35.66704079084968 139.74200181059172 34.541 35.66704079084968 139.74200181059172 35.902 35.66703910550036 139.7420020997021 35.902 35.66703910550036 139.7420020997021 34.541 35.66704079084968 139.74200181059172 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f6e04d9-61be-4ec3-b22d-d12abba9f66a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f6e04d9-61be-4ec3-b22d-d12abba9f66a_0">
											<gml:posList>35.66703910550036 139.7420020997021 34.541 35.66703910550036 139.7420020997021 35.902 35.66703740179683 139.74200195804715 35.902 35.66703740179683 139.74200195804715 34.541 35.66703910550036 139.7420020997021 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-bdb5a8d6-f16b-4582-bfe6-f7976061675c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdb5a8d6-f16b-4582-bfe6-f7976061675c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdb5a8d6-f16b-4582-bfe6-f7976061675c">
											<gml:posList>35.66684600418157 139.74190700566518 24.66 35.66687451972621 139.7418306468366 24.66 35.66691428722052 139.7418529139376 24.66 35.666952427848585 139.74175080735046 24.66 35.6669431396761 139.74174551598117 24.66 35.66696931617272 139.74167523486082 24.66 35.66697770255508 139.74167997496485 24.66 35.66697932174724 139.74167566525563 24.66 35.666999701516126 139.74168712958635 24.66 35.6670049188853 139.74167320592224 24.66 35.66709094658327 139.7417213777603 24.66 35.66708402012914 139.74173994262682 24.66 35.667153816287126 139.74177918600427 24.66 35.667142113273876 139.74181056947657 24.66 35.667124808541764 139.7418008689138 24.66 35.66704384969507 139.74201790083833 24.66 35.66684600418157 139.74190700566518 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-359067cb-df11-4635-8dd7-a8c416d07da1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-359067cb-df11-4635-8dd7-a8c416d07da1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-359067cb-df11-4635-8dd7-a8c416d07da1">
											<gml:posList>35.66697932174724 139.74167566525563 40.5 35.66697770255508 139.74167997496485 40.5 35.666952427848585 139.74175080735046 40.5 35.66697932174724 139.74167566525563 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb9f093d-4c0d-41fc-91f4-f8e30c242b01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb9f093d-4c0d-41fc-91f4-f8e30c242b01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb9f093d-4c0d-41fc-91f4-f8e30c242b01">
											<gml:posList>35.66687451972621 139.7418306468366 33.2 35.66684600418157 139.74190700566518 33.2 35.666885798736715 139.7419293169485 33.2 35.66691428722052 139.7418529139376 33.2 35.66687451972621 139.7418306468366 33.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7d21caf1-8b2b-4f4b-bced-3890aa1b4a9e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d21caf1-8b2b-4f4b-bced-3890aa1b4a9e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d21caf1-8b2b-4f4b-bced-3890aa1b4a9e">
											<gml:posList>35.66690018240392 139.7418907286885 35.3 35.666885798736715 139.7419293169485 35.3 35.666888574009214 139.74192805456624 35.3 35.666902112222495 139.7418918862948 35.3 35.66690018240392 139.7418907286885 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa605d92-6787-4e13-912a-881b3ded44ce">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa605d92-6787-4e13-912a-881b3ded44ce">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa605d92-6787-4e13-912a-881b3ded44ce">
											<gml:posList>35.66697770255508 139.74167997496485 40.5 35.66696931617272 139.74167523486082 40.5 35.6669431396761 139.74174551598117 40.5 35.666952427848585 139.74175080735046 40.5 35.66697770255508 139.74167997496485 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-766754cd-545f-4ef7-9c31-12339b74f0f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-766754cd-545f-4ef7-9c31-12339b74f0f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-766754cd-545f-4ef7-9c31-12339b74f0f2">
											<gml:posList>35.666885798736715 139.7419293169485 35.3 35.66704384969507 139.74201790083833 35.3 35.66704281955013 139.74201449990508 35.3 35.666888574009214 139.74192805456624 35.3 35.666885798736715 139.7419293169485 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bdedfd80-b369-49cc-95c9-dd1c01237db6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bdedfd80-b369-49cc-95c9-dd1c01237db6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bdedfd80-b369-49cc-95c9-dd1c01237db6">
											<gml:posList>35.66701872195044 139.74196184994426 34.541 35.666902112222495 139.7418918862948 34.541 35.666888574009214 139.74192805456624 34.541 35.66704281955013 139.74201449990508 34.541 35.66701872195044 139.74196184994426 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-11f425d1-50f3-4493-b474-4894a6c8cfc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-11f425d1-50f3-4493-b474-4894a6c8cfc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-11f425d1-50f3-4493-b474-4894a6c8cfc1">
											<gml:posList>35.666952427848585 139.74175080735046 40.5 35.66690018240392 139.7418907286885 40.5 35.66704491793337 139.7417154435232 49.245 35.666952427848585 139.74175080735046 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f3d435be-52de-43f1-a198-26bff64cbefd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3d435be-52de-43f1-a198-26bff64cbefd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3d435be-52de-43f1-a198-26bff64cbefd">
											<gml:posList>35.66690018240392 139.7418907286885 40.5 35.66695944767163 139.7419262837724 49.245 35.66704491793337 139.7417154435232 49.245 35.66690018240392 139.7418907286885 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe83d504-42d8-4bde-ab5f-73cdb2b13f11">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe83d504-42d8-4bde-ab5f-73cdb2b13f11">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe83d504-42d8-4bde-ab5f-73cdb2b13f11">
											<gml:posList>35.66697932174724 139.74167566525563 40.5 35.666952427848585 139.74175080735046 40.5 35.66704491793337 139.7417154435232 49.245 35.66697932174724 139.74167566525563 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1fee0af-f46f-43c0-b48e-80465d5e999b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1fee0af-f46f-43c0-b48e-80465d5e999b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1fee0af-f46f-43c0-b48e-80465d5e999b">
											<gml:posList>35.66704491793337 139.7417154435232 49.245 35.66695944767163 139.7419262837724 49.245 35.66701872195044 139.74196184994426 40.5 35.66704491793337 139.7417154435232 49.245</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-78f31e02-7bcf-4f92-8290-5d86f54906f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78f31e02-7bcf-4f92-8290-5d86f54906f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78f31e02-7bcf-4f92-8290-5d86f54906f3">
											<gml:posList>35.666999701516126 139.74168712958635 40.5 35.66708402012914 139.74173994262682 40.5 35.66709094658327 139.7417213777603 40.5 35.6670049188853 139.74167320592224 40.5 35.666999701516126 139.74168712958635 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-954fc0d3-4545-49dc-ae9f-77f8da4beb62">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-954fc0d3-4545-49dc-ae9f-77f8da4beb62">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-954fc0d3-4545-49dc-ae9f-77f8da4beb62">
											<gml:posList>35.667103092338195 139.741750668413 40.5 35.66704491793337 139.7417154435232 49.245 35.66701872195044 139.74196184994426 40.5 35.667103092338195 139.741750668413 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9fba8b9c-4be9-42e1-8770-ee32ee2989f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9fba8b9c-4be9-42e1-8770-ee32ee2989f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9fba8b9c-4be9-42e1-8770-ee32ee2989f2">
											<gml:posList>35.66710219267914 139.74175292278534 34.541 35.66701872195044 139.74196184994426 34.541 35.66704281955013 139.74201449990508 34.541 35.667123769385384 139.74179747903602 34.541 35.66710219267914 139.74175292278534 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-703b3051-5e52-4852-9df9-34741c7638bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-703b3051-5e52-4852-9df9-34741c7638bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-703b3051-5e52-4852-9df9-34741c7638bb">
											<gml:posList>35.66704281955013 139.74201449990508 35.3 35.66704384969507 139.74201790083833 35.3 35.667124808541764 139.7418008689138 35.3 35.667123769385384 139.74179747903602 35.3 35.66704281955013 139.74201449990508 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d0a51cec-92f2-45f5-90cd-4c699310443f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d0a51cec-92f2-45f5-90cd-4c699310443f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d0a51cec-92f2-45f5-90cd-4c699310443f">
											<gml:posList>35.667123769385384 139.74179747903602 34.541 35.6671410831315 139.74180717958765 34.541 35.667151041024724 139.74178045944163 34.541 35.66710219267914 139.74175292278534 34.541 35.667123769385384 139.74179747903602 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d563caa-cb78-48f8-9302-4d64e9fd4393">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d563caa-cb78-48f8-9302-4d64e9fd4393">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d563caa-cb78-48f8-9302-4d64e9fd4393">
											<gml:posList>35.667151041024724 139.74178045944163 35.3 35.667153816287126 139.74177918600427 35.3 35.667103092338195 139.741750668413 35.3 35.66710219267914 139.74175292278534 35.3 35.667151041024724 139.74178045944163 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-87b38a12-ceac-4840-b36b-6d349d66fe94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87b38a12-ceac-4840-b36b-6d349d66fe94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87b38a12-ceac-4840-b36b-6d349d66fe94">
											<gml:posList>35.6671410831315 139.74180717958765 35.3 35.667123769385384 139.74179747903602 35.3 35.667124808541764 139.7418008689138 35.3 35.667142113273876 139.74181056947657 35.3 35.6671410831315 139.74180717958765 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd76d0c0-109d-4349-ae48-0df5647c2a33">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd76d0c0-109d-4349-ae48-0df5647c2a33">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd76d0c0-109d-4349-ae48-0df5647c2a33">
											<gml:posList>35.667142113273876 139.74181056947657 35.3 35.667153816287126 139.74177918600427 35.3 35.667151041024724 139.74178045944163 35.3 35.6671410831315 139.74180717958765 35.3 35.667142113273876 139.74181056947657 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25aff224-0dc6-485e-a330-f897c7d8eb79">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25aff224-0dc6-485e-a330-f897c7d8eb79">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25aff224-0dc6-485e-a330-f897c7d8eb79">
											<gml:posList>35.666999701516126 139.74168712958635 40.5 35.66704491793337 139.7417154435232 49.245 35.66708402012914 139.74173994262682 40.5 35.666999701516126 139.74168712958635 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0b3f498a-5f8c-4b9a-9849-15f4ced9807b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0b3f498a-5f8c-4b9a-9849-15f4ced9807b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0b3f498a-5f8c-4b9a-9849-15f4ced9807b">
											<gml:posList>35.66709094658327 139.7417213777603 40.5 35.66709094658327 139.7417213777603 24.66 35.6670049188853 139.74167320592224 24.66 35.6670049188853 139.74167320592224 40.5 35.66709094658327 139.7417213777603 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4f0f22a9-b490-4e66-9bfd-ea32c6205b77">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4f0f22a9-b490-4e66-9bfd-ea32c6205b77">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4f0f22a9-b490-4e66-9bfd-ea32c6205b77">
											<gml:posList>35.667103092338195 139.741750668413 40.5 35.66708402012914 139.74173994262682 40.5 35.66704491793337 139.7417154435232 49.245 35.667103092338195 139.741750668413 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-567b1da2-06f1-4551-98b2-ce7a1d594945">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-567b1da2-06f1-4551-98b2-ce7a1d594945">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-567b1da2-06f1-4551-98b2-ce7a1d594945">
											<gml:posList>35.66697770255508 139.74167997496485 40.5 35.66697770255508 139.74167997496485 24.66 35.66696931617272 139.74167523486082 24.66 35.66696931617272 139.74167523486082 40.5 35.66697770255508 139.74167997496485 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-364623d0-aa4a-4366-915b-db9fd132190f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-364623d0-aa4a-4366-915b-db9fd132190f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-364623d0-aa4a-4366-915b-db9fd132190f">
											<gml:posList>35.66697932174724 139.74167566525563 40.5 35.66697932174724 139.74167566525563 24.66 35.66697770255508 139.74167997496485 24.66 35.66697770255508 139.74167997496485 40.5 35.66697932174724 139.74167566525563 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aee45a73-b3a0-46a8-959c-fedcdb5d1687">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aee45a73-b3a0-46a8-959c-fedcdb5d1687">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aee45a73-b3a0-46a8-959c-fedcdb5d1687">
											<gml:posList>35.6670049188853 139.74167320592224 40.5 35.6670049188853 139.74167320592224 24.66 35.666999701516126 139.74168712958635 24.66 35.666999701516126 139.74168712958635 40.5 35.6670049188853 139.74167320592224 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87c3ec54-3d6c-4fb6-bc5e-aad6b665ff13">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87c3ec54-3d6c-4fb6-bc5e-aad6b665ff13">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87c3ec54-3d6c-4fb6-bc5e-aad6b665ff13">
											<gml:posList>35.666999701516126 139.74168712958635 40.5 35.666999701516126 139.74168712958635 24.66 35.66697932174724 139.74167566525563 24.66 35.66697932174724 139.74167566525563 40.5 35.666999701516126 139.74168712958635 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf8ffdd3-37c4-47bf-ab30-fadb122882b4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf8ffdd3-37c4-47bf-ab30-fadb122882b4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf8ffdd3-37c4-47bf-ab30-fadb122882b4">
											<gml:posList>35.66704491793337 139.7417154435232 49.245 35.666999701516126 139.74168712958635 40.5 35.66697932174724 139.74167566525563 40.5 35.66704491793337 139.7417154435232 49.245</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-aeab23cd-3a01-4ad8-91f0-97571dd89f82">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aeab23cd-3a01-4ad8-91f0-97571dd89f82">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aeab23cd-3a01-4ad8-91f0-97571dd89f82">
											<gml:posList>35.66696931617272 139.74167523486082 40.5 35.66696931617272 139.74167523486082 24.66 35.6669431396761 139.74174551598117 24.66 35.6669431396761 139.74174551598117 40.5 35.66696931617272 139.74167523486082 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f76c2651-8aee-4003-840a-cb6b81f13fab">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f76c2651-8aee-4003-840a-cb6b81f13fab">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f76c2651-8aee-4003-840a-cb6b81f13fab">
											<gml:posList>35.66708402012914 139.74173994262682 40.5 35.66708402012914 139.74173994262682 24.66 35.66709094658327 139.7417213777603 24.66 35.66709094658327 139.7417213777603 40.5 35.66708402012914 139.74173994262682 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-eda5bd38-a2a1-462e-9cb4-1203d4e8272d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-eda5bd38-a2a1-462e-9cb4-1203d4e8272d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-eda5bd38-a2a1-462e-9cb4-1203d4e8272d">
											<gml:posList>35.6669431396761 139.74174551598117 40.5 35.6669431396761 139.74174551598117 24.66 35.666952427848585 139.74175080735046 24.66 35.666952427848585 139.74175080735046 40.5 35.6669431396761 139.74174551598117 40.5</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-77b667ea-058e-4aba-8460-528f4f075fc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-77b667ea-058e-4aba-8460-528f4f075fc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-77b667ea-058e-4aba-8460-528f4f075fc7">
											<gml:posList>35.66708402012914 139.74173994262682 24.66 35.66708402012914 139.74173994262682 40.5 35.667103092338195 139.741750668413 40.5 35.667103092338195 139.741750668413 35.3 35.667153816287126 139.74177918600427 35.3 35.667153816287126 139.74177918600427 24.66 35.66708402012914 139.74173994262682 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-980cefc9-113b-467b-9288-c6458729d4a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-980cefc9-113b-467b-9288-c6458729d4a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-980cefc9-113b-467b-9288-c6458729d4a5">
											<gml:posList>35.667151041024724 139.74178045944163 35.3 35.66710219267914 139.74175292278534 35.3 35.66710219267914 139.74175292278534 34.541 35.667151041024724 139.74178045944163 34.541 35.667151041024724 139.74178045944163 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f7358cab-5a3e-4d23-a9ff-5d90839aa377">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f7358cab-5a3e-4d23-a9ff-5d90839aa377">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f7358cab-5a3e-4d23-a9ff-5d90839aa377">
											<gml:posList>35.6671410831315 139.74180717958765 35.3 35.667151041024724 139.74178045944163 35.3 35.667151041024724 139.74178045944163 34.541 35.6671410831315 139.74180717958765 34.541 35.6671410831315 139.74180717958765 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a43f971d-5945-45f1-8372-f64bb18afa52">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a43f971d-5945-45f1-8372-f64bb18afa52">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a43f971d-5945-45f1-8372-f64bb18afa52">
											<gml:posList>35.667142113273876 139.74181056947657 35.3 35.667142113273876 139.74181056947657 24.66 35.667153816287126 139.74177918600427 24.66 35.667153816287126 139.74177918600427 35.3 35.667142113273876 139.74181056947657 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fed08f2f-9836-47df-995f-1b8c6d6b412e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fed08f2f-9836-47df-995f-1b8c6d6b412e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fed08f2f-9836-47df-995f-1b8c6d6b412e">
											<gml:posList>35.667123769385384 139.74179747903602 35.3 35.6671410831315 139.74180717958765 35.3 35.6671410831315 139.74180717958765 34.541 35.667123769385384 139.74179747903602 34.541 35.667123769385384 139.74179747903602 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-14e6915d-c7a3-4aef-bc30-2637f4c34e5e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-14e6915d-c7a3-4aef-bc30-2637f4c34e5e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-14e6915d-c7a3-4aef-bc30-2637f4c34e5e">
											<gml:posList>35.667124808541764 139.7418008689138 35.3 35.667124808541764 139.7418008689138 24.66 35.667142113273876 139.74181056947657 24.66 35.667142113273876 139.74181056947657 35.3 35.667124808541764 139.7418008689138 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7ef42d14-e045-472a-a9cc-8286ed6cd5e3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ef42d14-e045-472a-a9cc-8286ed6cd5e3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ef42d14-e045-472a-a9cc-8286ed6cd5e3">
											<gml:posList>35.66691428722052 139.7418529139376 33.2 35.666885798736715 139.7419293169485 33.2 35.666885798736715 139.7419293169485 35.3 35.66690018240392 139.7418907286885 35.3 35.66690018240392 139.7418907286885 40.5 35.666952427848585 139.74175080735046 40.5 35.666952427848585 139.74175080735046 24.66 35.66691428722052 139.7418529139376 24.66 35.66691428722052 139.7418529139376 33.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4c15c6cc-41eb-43a5-bb19-ccb9cbb79c73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4c15c6cc-41eb-43a5-bb19-ccb9cbb79c73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4c15c6cc-41eb-43a5-bb19-ccb9cbb79c73">
											<gml:posList>35.66691428722052 139.7418529139376 33.2 35.66691428722052 139.7418529139376 24.66 35.66687451972621 139.7418306468366 24.66 35.66687451972621 139.7418306468366 33.2 35.66691428722052 139.7418529139376 33.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b62cab69-b7fb-446c-9c4d-d9e43c42da40">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b62cab69-b7fb-446c-9c4d-d9e43c42da40">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b62cab69-b7fb-446c-9c4d-d9e43c42da40">
											<gml:posList>35.66701872195044 139.74196184994426 34.541 35.66710219267914 139.74175292278534 34.541 35.66710219267914 139.74175292278534 35.3 35.667103092338195 139.741750668413 35.3 35.667103092338195 139.741750668413 40.5 35.66701872195044 139.74196184994426 40.5 35.66701872195044 139.74196184994426 34.541</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-efcdf4f1-9123-48cd-b6c9-09d825d03ba5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-efcdf4f1-9123-48cd-b6c9-09d825d03ba5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-efcdf4f1-9123-48cd-b6c9-09d825d03ba5">
											<gml:posList>35.66687451972621 139.7418306468366 33.2 35.66687451972621 139.7418306468366 24.66 35.66684600418157 139.74190700566518 24.66 35.66684600418157 139.74190700566518 33.2 35.66687451972621 139.7418306468366 33.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b217a605-d344-4929-9021-a61ec3d4ee01">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b217a605-d344-4929-9021-a61ec3d4ee01">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b217a605-d344-4929-9021-a61ec3d4ee01">
											<gml:posList>35.66704281955013 139.74201449990508 35.3 35.667123769385384 139.74179747903602 35.3 35.667123769385384 139.74179747903602 34.541 35.66704281955013 139.74201449990508 34.541 35.66704281955013 139.74201449990508 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ec466a3-7650-4db0-bc57-aad162f41443">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ec466a3-7650-4db0-bc57-aad162f41443">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ec466a3-7650-4db0-bc57-aad162f41443">
											<gml:posList>35.66704384969507 139.74201790083833 35.3 35.66704384969507 139.74201790083833 24.66 35.667124808541764 139.7418008689138 24.66 35.667124808541764 139.7418008689138 35.3 35.66704384969507 139.74201790083833 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-754ee28a-a737-48d8-81df-a8307309380d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-754ee28a-a737-48d8-81df-a8307309380d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-754ee28a-a737-48d8-81df-a8307309380d">
											<gml:posList>35.666902112222495 139.7418918862948 35.3 35.666888574009214 139.74192805456624 35.3 35.666888574009214 139.74192805456624 34.541 35.666902112222495 139.7418918862948 34.541 35.666902112222495 139.7418918862948 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3e4377c6-4ad5-4bc8-9e59-710d95123d02">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3e4377c6-4ad5-4bc8-9e59-710d95123d02">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3e4377c6-4ad5-4bc8-9e59-710d95123d02">
											<gml:posList>35.666902112222495 139.7418918862948 35.3 35.666902112222495 139.7418918862948 34.541 35.66701872195044 139.74196184994426 34.541 35.66701872195044 139.74196184994426 40.5 35.66695944767163 139.7419262837724 49.245 35.66690018240392 139.7418907286885 40.5 35.66690018240392 139.7418907286885 35.3 35.666902112222495 139.7418918862948 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5d027750-7e13-4812-bb48-c2db27b02d3a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5d027750-7e13-4812-bb48-c2db27b02d3a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5d027750-7e13-4812-bb48-c2db27b02d3a">
											<gml:posList>35.66704384969507 139.74201790083833 24.66 35.66704384969507 139.74201790083833 35.3 35.666885798736715 139.7419293169485 35.3 35.666885798736715 139.7419293169485 33.2 35.66684600418157 139.74190700566518 33.2 35.66684600418157 139.74190700566518 24.66 35.66704384969507 139.74201790083833 24.66</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-12dca480-2dba-4c4f-af8e-3db857322e5f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-12dca480-2dba-4c4f-af8e-3db857322e5f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-12dca480-2dba-4c4f-af8e-3db857322e5f">
											<gml:posList>35.666888574009214 139.74192805456624 35.3 35.66704281955013 139.74201449990508 35.3 35.66704281955013 139.74201449990508 34.541 35.666888574009214 139.74192805456624 34.541 35.666888574009214 139.74192805456624 35.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-9443</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">368.56496</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">214</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1123</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.09</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>