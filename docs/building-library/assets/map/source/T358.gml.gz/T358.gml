<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6789a6f4-1deb-432b-91d3-cbe27a4c3fd2">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">16.6</bldg:measuredHeight>
			<bldg:storeysAboveGround>4</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67125729669256 139.73814808418499 0 35.67121649490702 139.7379586873043 0 35.671056001788614 139.73801097282043 0 35.671066487402726 139.73805987360828 0 35.67104928454423 139.73806537304088 0 35.671062393443954 139.7381260682215 0 35.67105067860229 139.7381298710313 0 35.67106788566999 139.73820952795006 0 35.67125729669256 139.73814808418499 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67125729669256 139.73814808418499 15.09 35.67106788566999 139.73820952795006 15.09 35.67105067860229 139.7381298710313 15.09 35.671062393443954 139.7381260682215 15.09 35.67104928454423 139.73806537304088 15.09 35.671066487402726 139.73805987360828 15.09 35.671056001788614 139.73801097282043 15.09 35.67121649490702 139.7379586873043 15.09 35.67125729669256 139.73814808418499 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67125729669256 139.73814808418499 15.09 35.67121649490702 139.7379586873043 15.09 35.67121649490702 139.7379586873043 31.68 35.67125729669256 139.73814808418499 31.68 35.67125729669256 139.73814808418499 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67121649490702 139.7379586873043 15.09 35.671056001788614 139.73801097282043 15.09 35.671056001788614 139.73801097282043 31.68 35.67121649490702 139.7379586873043 31.68 35.67121649490702 139.7379586873043 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671056001788614 139.73801097282043 15.09 35.671066487402726 139.73805987360828 15.09 35.671066487402726 139.73805987360828 31.68 35.671056001788614 139.73801097282043 31.68 35.671056001788614 139.73801097282043 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671066487402726 139.73805987360828 15.09 35.67104928454423 139.73806537304088 15.09 35.67104928454423 139.73806537304088 31.68 35.671066487402726 139.73805987360828 31.68 35.671066487402726 139.73805987360828 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67104928454423 139.73806537304088 15.09 35.671062393443954 139.7381260682215 15.09 35.671062393443954 139.7381260682215 31.68 35.67104928454423 139.73806537304088 31.68 35.67104928454423 139.73806537304088 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671062393443954 139.7381260682215 15.09 35.67105067860229 139.7381298710313 15.09 35.67105067860229 139.7381298710313 31.68 35.671062393443954 139.7381260682215 31.68 35.671062393443954 139.7381260682215 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67105067860229 139.7381298710313 15.09 35.67106788566999 139.73820952795006 15.09 35.67106788566999 139.73820952795006 31.68 35.67105067860229 139.7381298710313 31.68 35.67105067860229 139.7381298710313 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67106788566999 139.73820952795006 15.09 35.67125729669256 139.73814808418499 15.09 35.67125729669256 139.73814808418499 31.68 35.67106788566999 139.73820952795006 31.68 35.67106788566999 139.73820952795006 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67125729669256 139.73814808418499 31.68 35.67121649490702 139.7379586873043 31.68 35.671056001788614 139.73801097282043 31.68 35.671066487402726 139.73805987360828 31.68 35.67104928454423 139.73806537304088 31.68 35.671062393443954 139.7381260682215 31.68 35.67105067860229 139.7381298710313 31.68 35.67106788566999 139.73820952795006 31.68 35.67125729669256 139.73814808418499 31.68</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8c477538-69a5-49a0-81cf-3d28c902b896"/>
							<gml:surfaceMember xlink:href="#poly-80d7776c-a089-4d5e-b93e-e7e693fcbd8b"/>
							<gml:surfaceMember xlink:href="#poly-a5bbd8df-22f1-4b04-8ed2-71a822c8def5"/>
							<gml:surfaceMember xlink:href="#poly-8d976153-6e32-4829-a1e5-c8f41cecad58"/>
							<gml:surfaceMember xlink:href="#poly-4211d549-26f1-4241-954c-5f281884f59e"/>
							<gml:surfaceMember xlink:href="#poly-03ad15d3-563c-4ff0-ab20-a7e22203978b"/>
							<gml:surfaceMember xlink:href="#poly-942ee9b7-c6ca-4a75-a799-20659cbc165c"/>
							<gml:surfaceMember xlink:href="#poly-3eeaba53-7c27-4dbc-926e-230172968b25"/>
							<gml:surfaceMember xlink:href="#poly-4e59092a-3cc6-477b-ae9e-e47efec1cffa"/>
							<gml:surfaceMember xlink:href="#poly-7f7a3eb8-0ed9-439d-8aa4-ef08bbfbe072"/>
							<gml:surfaceMember xlink:href="#poly-cac4893d-7b36-4679-bbbd-d8b40698fb96"/>
							<gml:surfaceMember xlink:href="#poly-231eb01a-b96e-40de-acfb-36470f8c4dd1"/>
							<gml:surfaceMember xlink:href="#poly-577c03d3-5f85-4e36-8ab7-bf25386b056b"/>
							<gml:surfaceMember xlink:href="#poly-99b2bb85-317a-4c42-b937-b21227be2d71"/>
							<gml:surfaceMember xlink:href="#poly-c39fba0a-63f6-426d-9093-cab9b12bf36a"/>
							<gml:surfaceMember xlink:href="#poly-fcc88b96-028d-4600-8520-a51ded5baa55"/>
							<gml:surfaceMember xlink:href="#poly-9d595315-ebef-4038-8159-b9b2b60a3844"/>
							<gml:surfaceMember xlink:href="#poly-f9dc8dc3-02b8-4257-af98-001a378df181"/>
							<gml:surfaceMember xlink:href="#poly-265ae2d6-c54e-4038-a8d8-282b94f6607e"/>
							<gml:surfaceMember xlink:href="#poly-f9cfb79e-3fb9-42ee-92ba-6c1eca7b4691"/>
							<gml:surfaceMember xlink:href="#poly-d58f8808-eb94-49e9-9965-6ac9bd86159f"/>
							<gml:surfaceMember xlink:href="#poly-1225f4dd-e0ee-42c5-bd60-7aa6a3b73dec"/>
							<gml:surfaceMember xlink:href="#poly-f3bd5cbb-0690-41ae-94c0-5bcf4e7d8c37"/>
							<gml:surfaceMember xlink:href="#poly-c181c802-50d5-40db-8501-7cb8bd952a3b"/>
							<gml:surfaceMember xlink:href="#poly-e637c577-5ced-4e70-843b-fb86daa8d2ba"/>
							<gml:surfaceMember xlink:href="#poly-545aa474-7abd-4c51-bc0d-bf44d8b3e98d"/>
							<gml:surfaceMember xlink:href="#poly-0f263271-a20a-4671-879a-28013df99ae2"/>
							<gml:surfaceMember xlink:href="#poly-a2dc1518-65dc-47d5-84c2-709ff11e1886"/>
							<gml:surfaceMember xlink:href="#poly-8b5694c7-3419-4d8a-ae28-be94887983e4"/>
							<gml:surfaceMember xlink:href="#poly-840476b5-bae5-4bad-9e7d-ae25152da5da"/>
							<gml:surfaceMember xlink:href="#poly-2147f356-f551-4d91-bb55-3f32b83c1171"/>
							<gml:surfaceMember xlink:href="#poly-87755fe7-4258-44f6-8673-a5d1c9662693"/>
							<gml:surfaceMember xlink:href="#poly-b3e61e6c-69ad-4fa6-a69c-bda137aee240"/>
							<gml:surfaceMember xlink:href="#poly-1442ba95-93ab-44d4-aa8f-d81d1c364914"/>
							<gml:surfaceMember xlink:href="#poly-ffb91402-cf45-4bc3-ad45-b54d3ce722b1"/>
							<gml:surfaceMember xlink:href="#poly-c2c06908-8c82-46a1-b281-9d05766642c6"/>
							<gml:surfaceMember xlink:href="#poly-5844b4ee-7cfe-4170-aa03-f5007e8abbfd"/>
							<gml:surfaceMember xlink:href="#poly-472dcf69-8d75-471f-bae2-a2b72f8c2e86"/>
							<gml:surfaceMember xlink:href="#poly-ab78aaa1-71f3-425f-baaa-68d19f1cbc7f"/>
							<gml:surfaceMember xlink:href="#poly-5cafb2f9-8798-4747-83b7-ee48536dde45"/>
							<gml:surfaceMember xlink:href="#poly-e541fce0-7242-43a7-872e-47a53c2ddef1"/>
							<gml:surfaceMember xlink:href="#poly-7821b273-b782-429c-86dd-700af35e9738"/>
							<gml:surfaceMember xlink:href="#poly-03ba3eee-9daf-4e1a-a4d1-f7146bcfa81b"/>
							<gml:surfaceMember xlink:href="#poly-28f267d1-7c4b-4f39-9347-cfefd3392f54"/>
							<gml:surfaceMember xlink:href="#poly-5a66347f-fbd5-4008-9bdd-71e3b00c7432"/>
							<gml:surfaceMember xlink:href="#poly-6eae645e-ad40-441c-9cf3-f6488ced1f56"/>
							<gml:surfaceMember xlink:href="#poly-ff95e249-32c0-4372-addd-56c01a6e9178"/>
							<gml:surfaceMember xlink:href="#poly-7081e880-095c-4c13-8847-e9020f0ba49c"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6789a6f4-1deb-432b-91d3-cbe27a4c3fd2_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a15d8b16-f0d6-4d49-99e5-530088d95bcc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671147888088775 139.73801140484653 31.351 35.67120422814128 139.73799399505745 31.351 35.671225048820936 139.73809519928474 31.351 35.671178053711245 139.73810972585267 31.351 35.67116384756076 139.7380407139768 31.351 35.671154520632506 139.7380435971175 31.351 35.671147888088775 139.73801140484653 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77640652-d306-4a14-b729-754afc5c6853">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77640652-d306-4a14-b729-754afc5c6853_0">
											<gml:posList>35.671147888088775 139.73801140484653 31.351 35.671147888088775 139.73801140484653 34.347 35.67120422814128 139.73799399505745 34.347 35.67120422814128 139.73799399505745 31.351 35.671147888088775 139.73801140484653 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d23f021d-0da1-49ae-802e-1ae260cc9d52">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d23f021d-0da1-49ae-802e-1ae260cc9d52_0">
											<gml:posList>35.671154520632506 139.7380435971175 31.351 35.671154520632506 139.7380435971175 34.347 35.671147888088775 139.73801140484653 34.347 35.671147888088775 139.73801140484653 31.351 35.671154520632506 139.7380435971175 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fd20249-19bb-4273-b9c4-11e1383e8d8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fd20249-19bb-4273-b9c4-11e1383e8d8a_0">
											<gml:posList>35.67116384756076 139.7380407139768 31.351 35.67116384756076 139.7380407139768 34.347 35.671154520632506 139.7380435971175 34.347 35.671154520632506 139.7380435971175 31.351 35.67116384756076 139.7380407139768 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d046f22e-d594-4b1a-a67b-fc7cbc0cd2c9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d046f22e-d594-4b1a-a67b-fc7cbc0cd2c9_0">
											<gml:posList>35.67120422814128 139.73799399505745 31.351 35.67120422814128 139.73799399505745 34.347 35.671225048820936 139.73809519928474 34.347 35.671225048820936 139.73809519928474 31.351 35.67120422814128 139.73799399505745 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6d6d0242-d8d8-45af-84d1-136b41597378">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6d6d0242-d8d8-45af-84d1-136b41597378_0">
											<gml:posList>35.67116384756076 139.7380407139768 34.347 35.671178053711245 139.73810972585267 34.347 35.671225048820936 139.73809519928474 34.347 35.67120422814128 139.73799399505745 34.347 35.671147888088775 139.73801140484653 34.347 35.671154520632506 139.7380435971175 34.347 35.67116384756076 139.7380407139768 34.347</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-640c9891-1247-4673-90f4-f0b8735dc4dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-640c9891-1247-4673-90f4-f0b8735dc4dc_0">
											<gml:posList>35.671178053711245 139.73810972585267 31.351 35.671178053711245 139.73810972585267 34.347 35.67116384756076 139.7380407139768 34.347 35.67116384756076 139.7380407139768 31.351 35.671178053711245 139.73810972585267 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-301ef093-56db-433f-9512-ab5fc1a10df9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-301ef093-56db-433f-9512-ab5fc1a10df9_0">
											<gml:posList>35.671225048820936 139.73809519928474 31.351 35.671225048820936 139.73809519928474 34.347 35.671178053711245 139.73810972585267 34.347 35.671178053711245 139.73810972585267 31.351 35.671225048820936 139.73809519928474 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6789a6f4-1deb-432b-91d3-cbe27a4c3fd2_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4e539093-f64d-450c-9742-60a4ee67e287">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67107742486128 139.73803051044524 35.656 35.67106963878109 139.73803276211027 35.656 35.67106743037522 139.73802132071268 35.656 35.671075216446454 139.73801905800025 35.656 35.67107742486128 139.73803051044524 35.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-771436dc-015c-415e-8ee7-355218952567">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671072598419194 139.73804811302517 35.656 35.67107037187369 139.73803652804568 35.656 35.671078148940225 139.73803427639172 35.656 35.67108037548594 139.73804586137226 35.656 35.671072598419194 139.73804811302517 35.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-51fd442d-79d7-4ce8-81e6-6634b2f5baa9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67120404401646 139.73812583373464 31.351 35.67120714948648 139.73814323913098 31.351 35.67118509755708 139.73814914198164 31.351 35.671182001101634 139.73813173657913 31.351 35.67120404401646 139.73812583373464 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-728216b2-e88f-4ec1-bfb9-918bc079d709">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67116031647189 139.73814617783643 31.351 35.67115755665034 139.73813272663884 31.351 35.671164630709484 139.73813055315105 31.351 35.671167390522534 139.7381439933034 31.351 35.67116031647189 139.73814617783643 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9fce2492-82c0-4202-a6db-46f598705a82">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671152742053664 139.73815393033138 31.351 35.67114465871928 139.73815643640583 31.351 35.671140840285176 139.7381379161863 31.351 35.67114892361917 139.7381354101101 31.351 35.671152742053664 139.73815393033138 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-877a8538-731a-4454-9798-b09d783196fd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67114465871928 139.73815643640583 31.351 35.671152742053664 139.73815393033138 31.351 35.671152742053664 139.73815393033138 33.606 35.67114465871928 139.73815643640583 33.606 35.67114465871928 139.73815643640583 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-670c520f-9952-407f-a37d-ae308600dec7">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67115333020697 139.7381567906419 31.351 35.67114524687252 139.73815929671608 31.351 35.67114524687252 139.73815929671608 33.606 35.67115333020697 139.7381567906419 33.606 35.67115333020697 139.7381567906419 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f134345-3969-4970-89fb-1b4eccdffe40">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67116806014012 139.73814728432598 31.351 35.6711720596242 139.73816678746414 31.351 35.67116498557314 139.73816897199526 31.351 35.671160995094404 139.73814945780168 31.351 35.67116806014012 139.73814728432598 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0af9a792-62a4-4822-b579-56eb5e4c19c6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671148196668895 139.73817362034987 31.351 35.67114524687252 139.73815929671608 31.351 35.67115333020697 139.7381567906419 31.351 35.67115628000363 139.73817111427707 31.351 35.671148196668895 139.73817362034987 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ca54621-3fb5-40c5-908b-17fec4b5fbb4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67111187546749 139.7381788442022 32.949 35.67111999529374 139.73817689040578 33.151 35.671121689187004 139.73818742662414 33.137 35.67111356034685 139.7381893804302 32.935 35.67111187546749 139.7381788442022 32.949</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72320044-cfc7-42be-8e07-4c682a81a390">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72320044-cfc7-42be-8e07-4c682a81a390_0">
											<gml:posList>35.671078148940225 139.73803427639172 35.656 35.67107037187369 139.73803652804568 35.656 35.67107037187369 139.73803652804568 37.644 35.671078148940225 139.73803427639172 37.644 35.671078148940225 139.73803427639172 35.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f08a5fb5-2088-45dc-955f-c7f4a29a8eed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f08a5fb5-2088-45dc-955f-c7f4a29a8eed_0">
											<gml:posList>35.67116806014012 139.73814728432598 31.351 35.671160995094404 139.73814945780168 31.351 35.671160995094404 139.73814945780168 33.691 35.67116806014012 139.73814728432598 33.691 35.67116806014012 139.73814728432598 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a270407-7dfe-4a0a-a4ef-b5ace860ed43">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a270407-7dfe-4a0a-a4ef-b5ace860ed43_0">
											<gml:posList>35.671075216446454 139.73801905800025 35.656 35.67106743037522 139.73802132071268 35.656 35.67106743037522 139.73802132071268 37.644 35.671075216446454 139.73801905800025 37.644 35.671075216446454 139.73801905800025 35.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a2520591-dc47-4bc6-8cb4-7560cad1c952">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a2520591-dc47-4bc6-8cb4-7560cad1c952_0">
											<gml:posList>35.67107742486128 139.73803051044524 35.656 35.671075216446454 139.73801905800025 35.656 35.671075216446454 139.73801905800025 37.644 35.67107742486128 139.73803051044524 37.644 35.67107742486128 139.73803051044524 35.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ffdf6cba-c63c-406e-83dd-2f3f15cb6873">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ffdf6cba-c63c-406e-83dd-2f3f15cb6873_0">
											<gml:posList>35.67106743037522 139.73802132071268 37.644 35.67106963878109 139.73803276211027 37.644 35.67107742486128 139.73803051044524 37.644 35.671075216446454 139.73801905800025 37.644 35.67106743037522 139.73802132071268 37.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-099d1fd0-79e5-499f-9732-5f984a770fd1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-099d1fd0-79e5-499f-9732-5f984a770fd1_0">
											<gml:posList>35.67106963878109 139.73803276211027 35.656 35.67106963878109 139.73803276211027 37.644 35.67106743037522 139.73802132071268 37.644 35.67106743037522 139.73802132071268 35.656 35.67106963878109 139.73803276211027 35.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-04e80edd-9e46-4abf-bb47-bfec3e7944a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-04e80edd-9e46-4abf-bb47-bfec3e7944a1_0">
											<gml:posList>35.67106963878109 139.73803276211027 35.656 35.67107742486128 139.73803051044524 35.656 35.67107742486128 139.73803051044524 37.644 35.67106963878109 139.73803276211027 37.644 35.67106963878109 139.73803276211027 35.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dac35a69-3d69-4735-a149-304d262e1c8c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dac35a69-3d69-4735-a149-304d262e1c8c_0">
											<gml:posList>35.67108037548594 139.73804586137226 35.656 35.671078148940225 139.73803427639172 35.656 35.671078148940225 139.73803427639172 37.644 35.67108037548594 139.73804586137226 37.644 35.67108037548594 139.73804586137226 35.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-28276f5f-51fc-4478-a788-caa3657a11c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-28276f5f-51fc-4478-a788-caa3657a11c7_0">
											<gml:posList>35.671072598419194 139.73804811302517 37.644 35.67108037548594 139.73804586137226 37.644 35.671078148940225 139.73803427639172 37.644 35.67107037187369 139.73803652804568 37.644 35.671072598419194 139.73804811302517 37.644</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2dbd8aa3-c3f9-4ad7-ae2a-e00908114cb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2dbd8aa3-c3f9-4ad7-ae2a-e00908114cb0_0">
											<gml:posList>35.67107037187369 139.73803652804568 35.656 35.671072598419194 139.73804811302517 35.656 35.671072598419194 139.73804811302517 37.644 35.67107037187369 139.73803652804568 37.644 35.67107037187369 139.73803652804568 35.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6da33585-ba84-4c34-8c9f-179fe2475d3a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6da33585-ba84-4c34-8c9f-179fe2475d3a_0">
											<gml:posList>35.671072598419194 139.73804811302517 35.656 35.67108037548594 139.73804586137226 35.656 35.67108037548594 139.73804586137226 37.644 35.671072598419194 139.73804811302517 37.644 35.671072598419194 139.73804811302517 35.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5acbceec-e28c-4ee1-a45f-06fdc4582ea9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5acbceec-e28c-4ee1-a45f-06fdc4582ea9_0">
											<gml:posList>35.67114892361917 139.7381354101101 31.351 35.671140840285176 139.7381379161863 31.351 35.671140840285176 139.7381379161863 33.606 35.67114892361917 139.7381354101101 33.606 35.67114892361917 139.7381354101101 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a7ccf44b-9df6-4ebe-b047-673e75339b72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a7ccf44b-9df6-4ebe-b047-673e75339b72_0">
											<gml:posList>35.671152742053664 139.73815393033138 31.351 35.67114892361917 139.7381354101101 31.351 35.67114892361917 139.7381354101101 33.606 35.671152742053664 139.73815393033138 33.606 35.671152742053664 139.73815393033138 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a908e60d-3baf-4005-af21-d9cac9e6d52a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a908e60d-3baf-4005-af21-d9cac9e6d52a_0">
											<gml:posList>35.671140840285176 139.7381379161863 33.606 35.67114465871928 139.73815643640583 33.606 35.671152742053664 139.73815393033138 33.606 35.67114892361917 139.7381354101101 33.606 35.671140840285176 139.7381379161863 33.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0db235b9-8f7e-4f0c-ad75-5fe91147a004">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0db235b9-8f7e-4f0c-ad75-5fe91147a004_0">
											<gml:posList>35.671140840285176 139.7381379161863 31.351 35.67114465871928 139.73815643640583 31.351 35.67114465871928 139.73815643640583 33.606 35.671140840285176 139.7381379161863 33.606 35.671140840285176 139.7381379161863 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d8c79ce3-09c3-4b27-8fc0-4eee6e15545f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d8c79ce3-09c3-4b27-8fc0-4eee6e15545f_0">
											<gml:posList>35.67115333020697 139.7381567906419 31.351 35.67115333020697 139.7381567906419 33.606 35.67115628000363 139.73817111427707 33.606 35.67115628000363 139.73817111427707 31.351 35.67115333020697 139.7381567906419 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d4189a57-f4f3-46cb-b11a-2eaf457a7290">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d4189a57-f4f3-46cb-b11a-2eaf457a7290_0">
											<gml:posList>35.671148196668895 139.73817362034987 33.606 35.67115628000363 139.73817111427707 33.606 35.67115333020697 139.7381567906419 33.606 35.67114524687252 139.73815929671608 33.606 35.671148196668895 139.73817362034987 33.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b61e50dd-78e0-401d-ba53-afd5fc0107d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b61e50dd-78e0-401d-ba53-afd5fc0107d0_0">
											<gml:posList>35.67114524687252 139.73815929671608 31.351 35.671148196668895 139.73817362034987 31.351 35.671148196668895 139.73817362034987 33.606 35.67114524687252 139.73815929671608 33.606 35.67114524687252 139.73815929671608 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b99e2bd-4736-4c86-83eb-71dbc3ddb1ad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b99e2bd-4736-4c86-83eb-71dbc3ddb1ad_0">
											<gml:posList>35.671148196668895 139.73817362034987 31.351 35.67115628000363 139.73817111427707 31.351 35.67115628000363 139.73817111427707 33.606 35.671148196668895 139.73817362034987 33.606 35.671148196668895 139.73817362034987 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-339e0357-5682-452b-966e-e61b090bdebf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-339e0357-5682-452b-966e-e61b090bdebf_0">
											<gml:posList>35.67111999529374 139.73817689040578 33.151 35.67111187546749 139.7381788442022 32.949 35.67111187546749 139.7381788442022 35.208 35.67111999529374 139.73817689040578 35.208 35.67111999529374 139.73817689040578 33.151</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d25926f-29c2-4fa8-8dce-aca74df3ea55">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d25926f-29c2-4fa8-8dce-aca74df3ea55_0">
											<gml:posList>35.67111999529374 139.73817689040578 33.151 35.67111999529374 139.73817689040578 35.208 35.671121689187004 139.73818742662414 35.208 35.671121689187004 139.73818742662414 33.137 35.67111999529374 139.73817689040578 33.151</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b07ebf9-f07f-47fb-a95f-c5b7b8ef2a61">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b07ebf9-f07f-47fb-a95f-c5b7b8ef2a61_0">
											<gml:posList>35.67111356034685 139.7381893804302 35.208 35.671121689187004 139.73818742662414 35.208 35.67111999529374 139.73817689040578 35.208 35.67111187546749 139.7381788442022 35.208 35.67111356034685 139.7381893804302 35.208</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db4ef4ff-f53f-4d82-a09f-8487d3138e7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db4ef4ff-f53f-4d82-a09f-8487d3138e7e_0">
											<gml:posList>35.67111187546749 139.7381788442022 32.949 35.67111356034685 139.7381893804302 32.935 35.67111356034685 139.7381893804302 35.208 35.67111187546749 139.7381788442022 35.208 35.67111187546749 139.7381788442022 32.949</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96ee2955-1a76-4944-b02b-309555b3e8a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96ee2955-1a76-4944-b02b-309555b3e8a9_0">
											<gml:posList>35.671121689187004 139.73818742662414 33.137 35.671121689187004 139.73818742662414 35.208 35.67111356034685 139.7381893804302 35.208 35.67111356034685 139.7381893804302 32.935 35.671121689187004 139.73818742662414 33.137</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-17c9a8a3-298e-441d-b3bf-52fbc9bf857d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-17c9a8a3-298e-441d-b3bf-52fbc9bf857d_0">
											<gml:posList>35.67115755665034 139.73813272663884 31.351 35.67116031647189 139.73814617783643 31.351 35.67116031647189 139.73814617783643 33.691 35.67115755665034 139.73813272663884 33.691 35.67115755665034 139.73813272663884 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42fce64d-ded4-4041-813f-85d34999c23a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42fce64d-ded4-4041-813f-85d34999c23a_0">
											<gml:posList>35.671164630709484 139.73813055315105 31.351 35.67115755665034 139.73813272663884 31.351 35.67115755665034 139.73813272663884 33.691 35.671164630709484 139.73813055315105 33.691 35.671164630709484 139.73813055315105 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3372f15-4acd-41bb-808c-1ec90b7cdea2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3372f15-4acd-41bb-808c-1ec90b7cdea2_0">
											<gml:posList>35.67116031647189 139.73814617783643 33.691 35.671167390522534 139.7381439933034 33.691 35.671164630709484 139.73813055315105 33.691 35.67115755665034 139.73813272663884 33.691 35.67116031647189 139.73814617783643 33.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b874d9eb-fc8b-4ab5-9fbe-facf2059dcbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b874d9eb-fc8b-4ab5-9fbe-facf2059dcbf_0">
											<gml:posList>35.671160995094404 139.73814945780168 31.351 35.67116498557314 139.73816897199526 31.351 35.67116498557314 139.73816897199526 33.691 35.671160995094404 139.73814945780168 33.691 35.671160995094404 139.73814945780168 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c72352ac-3bf0-4d9d-8151-cea8097ace0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c72352ac-3bf0-4d9d-8151-cea8097ace0f_0">
											<gml:posList>35.67116031647189 139.73814617783643 31.351 35.671167390522534 139.7381439933034 31.351 35.671167390522534 139.7381439933034 33.691 35.67116031647189 139.73814617783643 33.691 35.67116031647189 139.73814617783643 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7079530b-5cde-4ab9-8419-3662cc2bf923">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7079530b-5cde-4ab9-8419-3662cc2bf923_0">
											<gml:posList>35.671164630709484 139.73813055315105 31.351 35.671164630709484 139.73813055315105 33.691 35.671167390522534 139.7381439933034 33.691 35.671167390522534 139.7381439933034 31.351 35.671164630709484 139.73813055315105 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-71fa97cf-59a1-4859-a0aa-6fa6973f2ef3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-71fa97cf-59a1-4859-a0aa-6fa6973f2ef3_0">
											<gml:posList>35.67116498557314 139.73816897199526 33.691 35.6711720596242 139.73816678746414 33.691 35.67116806014012 139.73814728432598 33.691 35.671160995094404 139.73814945780168 33.691 35.67116498557314 139.73816897199526 33.691</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c56fcb6f-5244-4018-ae2e-de87651c28a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c56fcb6f-5244-4018-ae2e-de87651c28a1_0">
											<gml:posList>35.67116498557314 139.73816897199526 31.351 35.6711720596242 139.73816678746414 31.351 35.6711720596242 139.73816678746414 33.691 35.67116498557314 139.73816897199526 33.691 35.67116498557314 139.73816897199526 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18341bcf-b3b7-437c-a787-c34c6c70bdf0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18341bcf-b3b7-437c-a787-c34c6c70bdf0_0">
											<gml:posList>35.6711720596242 139.73816678746414 31.351 35.67116806014012 139.73814728432598 31.351 35.67116806014012 139.73814728432598 33.691 35.6711720596242 139.73816678746414 33.691 35.6711720596242 139.73816678746414 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7608fe2-c434-460f-b361-f2ac8e10560f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d7608fe2-c434-460f-b361-f2ac8e10560f_0">
											<gml:posList>35.671182001101634 139.73813173657913 31.351 35.67118509755708 139.73814914198164 31.351 35.67118509755708 139.73814914198164 34.229 35.671182001101634 139.73813173657913 34.229 35.671182001101634 139.73813173657913 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2beefe2c-9463-41d9-a6f9-554b5b8e2fe4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2beefe2c-9463-41d9-a6f9-554b5b8e2fe4_0">
											<gml:posList>35.67120404401646 139.73812583373464 31.351 35.671182001101634 139.73813173657913 31.351 35.671182001101634 139.73813173657913 34.229 35.67120404401646 139.73812583373464 34.229 35.67120404401646 139.73812583373464 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41496f66-ffd3-4a3e-b92a-de761d355de1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41496f66-ffd3-4a3e-b92a-de761d355de1_0">
											<gml:posList>35.67118509755708 139.73814914198164 34.229 35.67120714948648 139.73814323913098 34.229 35.67120404401646 139.73812583373464 34.229 35.671182001101634 139.73813173657913 34.229 35.67118509755708 139.73814914198164 34.229</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-908bb8aa-ad3e-43ac-a31b-166cce2e46c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-908bb8aa-ad3e-43ac-a31b-166cce2e46c2_0">
											<gml:posList>35.67118509755708 139.73814914198164 31.351 35.67120714948648 139.73814323913098 31.351 35.67120714948648 139.73814323913098 34.229 35.67118509755708 139.73814914198164 34.229 35.67118509755708 139.73814914198164 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-186fca72-5925-43be-b51b-bdc31b17b0a2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-186fca72-5925-43be-b51b-bdc31b17b0a2_0">
											<gml:posList>35.67120714948648 139.73814323913098 31.351 35.67120404401646 139.73812583373464 31.351 35.67120404401646 139.73812583373464 34.229 35.67120714948648 139.73814323913098 34.229 35.67120714948648 139.73814323913098 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6789a6f4-1deb-432b-91d3-cbe27a4c3fd2_BuildingInstallation_1060">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ee01e357-1d3a-4a16-b66b-5b5b745f8193">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671061710500794 139.73803756565147 15.09 35.67103565843328 139.73804593661055 15.09 35.67102995881535 139.73801944319388 15.09 35.671056010802346 139.7380109728097 15.09 35.671061710500794 139.73803756565147 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-902df64e-566d-4504-a6c0-1a6316819c50">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-902df64e-566d-4504-a6c0-1a6316819c50_0">
											<gml:posList>35.67102995881535 139.73801944319388 15.09 35.67103565843328 139.73804593661055 15.09 35.67103565843328 139.73804593661055 32.049 35.67102995881535 139.73801944319388 32.049 35.67102995881535 139.73801944319388 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f3680d99-8cd5-4375-9d70-98743fb4ae3f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f3680d99-8cd5-4375-9d70-98743fb4ae3f_0">
											<gml:posList>35.671056010802346 139.7380109728097 15.09 35.67102995881535 139.73801944319388 15.09 35.67102995881535 139.73801944319388 32.049 35.671056010802346 139.7380109728097 32.049 35.671056010802346 139.7380109728097 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e2507853-65c8-4659-bb19-9aeee5b74eb4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e2507853-65c8-4659-bb19-9aeee5b74eb4_0">
											<gml:posList>35.67102995881535 139.73801944319388 32.049 35.67103565843328 139.73804593661055 32.049 35.671061710500794 139.73803756565147 32.049 35.671056010802346 139.7380109728097 32.049 35.67102995881535 139.73801944319388 32.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-77650478-ff75-42d3-b9f4-6e5e6dadad40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-77650478-ff75-42d3-b9f4-6e5e6dadad40_0">
											<gml:posList>35.67103565843328 139.73804593661055 32.049 35.67103565843328 139.73804593661055 15.09 35.671061710500794 139.73803756565147 15.09 35.671061710500794 139.73803756565147 32.049 35.67103565843328 139.73804593661055 32.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90af8e26-6217-4911-bd30-2c9d6e73b2bc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90af8e26-6217-4911-bd30-2c9d6e73b2bc_0">
											<gml:posList>35.671061710500794 139.73803756565147 32.049 35.671061710500794 139.73803756565147 15.09 35.671056010802346 139.7380109728097 15.09 35.671056010802346 139.7380109728097 32.049 35.671061710500794 139.73803756565147 32.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8c477538-69a5-49a0-81cf-3d28c902b896">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c477538-69a5-49a0-81cf-3d28c902b896">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c477538-69a5-49a0-81cf-3d28c902b896">
											<gml:posList>35.671062393443954 139.7381260682215 15.09 35.67104928454422 139.73806537304088 15.09 35.67106648740272 139.73805987360828 15.09 35.67105600178863 139.73801097282043 15.09 35.67121649490702 139.7379586873043 15.09 35.671257296692545 139.73814808418499 15.09 35.67106788566998 139.73820952795006 15.09 35.671050678602285 139.7381298710313 15.09 35.671062393443954 139.7381260682215 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-80d7776c-a089-4d5e-b93e-e7e693fcbd8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-80d7776c-a089-4d5e-b93e-e7e693fcbd8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-80d7776c-a089-4d5e-b93e-e7e693fcbd8b">
											<gml:posList>35.67105109393029 139.73807376611813 32.049 35.67106826068184 139.73806820045198 32.049 35.67106648740272 139.73805987360828 32.049 35.67104928454422 139.73806537304088 32.049 35.67105109393029 139.73807376611813 32.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5bbd8df-22f1-4b04-8ed2-71a822c8def5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5bbd8df-22f1-4b04-8ed2-71a822c8def5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5bbd8df-22f1-4b04-8ed2-71a822c8def5">
											<gml:posList>35.67106826068184 139.73806820045198 35.952 35.67107056437522 139.73806337045787 35.952 35.671060748200034 139.738017528711 35.952 35.67105681597915 139.73801470551953 35.952 35.67106826068184 139.73806820045198 35.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8d976153-6e32-4829-a1e5-c8f41cecad58">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d976153-6e32-4829-a1e5-c8f41cecad58">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d976153-6e32-4829-a1e5-c8f41cecad58">
											<gml:posList>35.671050678602285 139.7381298710313 30.477 35.67106788566998 139.73820952795006 30.477 35.67107959150914 139.73820573620813 30.477 35.671062393443954 139.7381260682215 30.477 35.671050678602285 139.7381298710313 30.477</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4211d549-26f1-4241-954c-5f281884f59e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4211d549-26f1-4241-954c-5f281884f59e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4211d549-26f1-4241-954c-5f281884f59e">
											<gml:posList>35.67106826068184 139.73806820045198 32.467 35.67105109393029 139.73807376611813 32.049 35.67107959150914 139.73820573620813 32.049 35.67106826068184 139.73806820045198 32.467</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03ad15d3-563c-4ff0-ab20-a7e22203978b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03ad15d3-563c-4ff0-ab20-a7e22203978b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03ad15d3-563c-4ff0-ab20-a7e22203978b">
											<gml:posList>35.67111593119587 139.7380528887855 35.952 35.671111998967106 139.73805005454403 35.952 35.67107056437522 139.73806337045787 35.952 35.67106826068184 139.73806820045198 35.952 35.67111593119587 139.7380528887855 35.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-942ee9b7-c6ca-4a75-a799-20659cbc165c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-942ee9b7-c6ca-4a75-a799-20659cbc165c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-942ee9b7-c6ca-4a75-a799-20659cbc165c">
											<gml:posList>35.67106826068184 139.73806820045198 32.467 35.67107959150914 139.73820573620813 32.049 35.671115940209596 139.73805288877477 33.593 35.67106826068184 139.73806820045198 32.467</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3eeaba53-7c27-4dbc-926e-230172968b25">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3eeaba53-7c27-4dbc-926e-230172968b25">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3eeaba53-7c27-4dbc-926e-230172968b25">
											<gml:posList>35.671115940209596 139.73805288877477 33.593 35.67107959150914 139.73820573620813 32.049 35.67114852893193 139.73818345122044 33.791 35.671115940209596 139.73805288877477 33.593</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e59092a-3cc6-477b-ae9e-e47efec1cffa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e59092a-3cc6-477b-ae9e-e47efec1cffa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e59092a-3cc6-477b-ae9e-e47efec1cffa">
											<gml:posList>35.67114852893193 139.73818345122044 33.791 35.671120283713 139.7380514807251 33.791 35.671115940209596 139.73805288877477 33.593 35.67114852893193 139.73818345122044 33.791</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7f7a3eb8-0ed9-439d-8aa4-ef08bbfbe072">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f7a3eb8-0ed9-439d-8aa4-ef08bbfbe072">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f7a3eb8-0ed9-439d-8aa4-ef08bbfbe072">
											<gml:posList>35.67117573712382 139.7381096512795 29.421 35.67116283583746 139.73804934239195 29.421 35.671122599765 139.73806227026782 29.421 35.67113550104494 139.7381225791272 29.421 35.67117573712382 139.7381096512795 29.421</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cac4893d-7b36-4679-bbbd-d8b40698fb96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cac4893d-7b36-4679-bbbd-d8b40698fb96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cac4893d-7b36-4679-bbbd-d8b40698fb96">
											<gml:posList>35.67121307540632 139.73796590465426 31.351 35.67110921896978 139.73799974167974 31.351 35.671122599765 139.73806227026782 31.351 35.67116283583746 139.73804934239195 31.351 35.67117573712382 139.7381096512795 31.351 35.67113550104494 139.7381225791272 31.351 35.67114727136336 139.73817755395402 31.351 35.67125141642832 139.73814389354206 31.351 35.67121307540632 139.73796590465426 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-231eb01a-b96e-40de-acfb-36470f8c4dd1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-231eb01a-b96e-40de-acfb-36470f8c4dd1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-231eb01a-b96e-40de-acfb-36470f8c4dd1">
											<gml:posList>35.67114852893193 139.73818345122044 31.955 35.671257296692545 139.73814808418499 31.955 35.67125141642832 139.73814389354206 31.955 35.67114727136336 139.73817755395402 31.955 35.67114852893193 139.73818345122044 31.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-577c03d3-5f85-4e36-8ab7-bf25386b056b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-577c03d3-5f85-4e36-8ab7-bf25386b056b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-577c03d3-5f85-4e36-8ab7-bf25386b056b">
											<gml:posList>35.67121649490702 139.7379586873043 31.955 35.67121307540632 139.73796590465426 31.955 35.67125141642832 139.73814389354206 31.955 35.671257296692545 139.73814808418499 31.955 35.67121649490702 139.7379586873043 31.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-99b2bb85-317a-4c42-b937-b21227be2d71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-99b2bb85-317a-4c42-b937-b21227be2d71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-99b2bb85-317a-4c42-b937-b21227be2d71">
											<gml:posList>35.67110799761329 139.73799405425686 31.955 35.67110921896978 139.73799974167974 31.955 35.67121307540632 139.73796590465426 31.955 35.67121649490702 139.7379586873043 31.955 35.67110799761329 139.73799405425686 31.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c39fba0a-63f6-426d-9093-cab9b12bf36a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c39fba0a-63f6-426d-9093-cab9b12bf36a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c39fba0a-63f6-426d-9093-cab9b12bf36a">
											<gml:posList>35.67105681597915 139.73801470551953 35.952 35.671060748200034 139.738017528711 35.952 35.67110228191158 139.73800417951816 35.952 35.6711045946161 139.73799934950947 35.952 35.67105681597915 139.73801470551953 35.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fcc88b96-028d-4600-8520-a51ded5baa55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fcc88b96-028d-4600-8520-a51ded5baa55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fcc88b96-028d-4600-8520-a51ded5baa55">
											<gml:posList>35.67110799761329 139.73799405425686 32.049 35.67105600178863 139.73801097282043 32.049 35.67105681597915 139.73801470551953 32.049 35.6711045946161 139.73799934950947 32.049 35.67111593119587 139.7380528887855 32.049 35.671120283713 139.7380514807251 32.049 35.67110799761329 139.73799405425686 32.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9d595315-ebef-4038-8159-b9b2b60a3844">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d595315-ebef-4038-8159-b9b2b60a3844">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d595315-ebef-4038-8159-b9b2b60a3844">
											<gml:posList>35.6711045946161 139.73799934950947 35.952 35.67110228191158 139.73800417951816 35.952 35.671111998967106 139.73805005454403 35.952 35.67111593119587 139.7380528887855 35.952 35.6711045946161 139.73799934950947 35.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f9dc8dc3-02b8-4257-af98-001a378df181">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9dc8dc3-02b8-4257-af98-001a378df181">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9dc8dc3-02b8-4257-af98-001a378df181">
											<gml:posList>35.671111998967106 139.73805005454403 35.656 35.67110228191158 139.73800417951816 35.656 35.671060748200034 139.738017528711 35.656 35.67107056437522 139.73806337045787 35.656 35.671111998967106 139.73805005454403 35.656</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-265ae2d6-c54e-4038-a8d8-282b94f6607e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-265ae2d6-c54e-4038-a8d8-282b94f6607e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-265ae2d6-c54e-4038-a8d8-282b94f6607e">
											<gml:posList>35.67105600178863 139.73801097282043 15.09 35.67105681597915 139.73801470551953 32.049 35.67105600178863 139.73801097282043 32.049 35.67105600178863 139.73801097282043 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f9cfb79e-3fb9-42ee-92ba-6c1eca7b4691">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f9cfb79e-3fb9-42ee-92ba-6c1eca7b4691">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f9cfb79e-3fb9-42ee-92ba-6c1eca7b4691">
											<gml:posList>35.671050678602285 139.7381298710313 15.09 35.671050678602285 139.7381298710313 30.477 35.671062393443954 139.7381260682215 30.477 35.671062393443954 139.7381260682215 15.09 35.671050678602285 139.7381298710313 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d58f8808-eb94-49e9-9965-6ac9bd86159f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d58f8808-eb94-49e9-9965-6ac9bd86159f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d58f8808-eb94-49e9-9965-6ac9bd86159f">
											<gml:posList>35.67106648740272 139.73805987360828 32.049 35.67106648740272 139.73805987360828 15.09 35.67104928454422 139.73806537304088 15.09 35.67104928454422 139.73806537304088 32.049 35.67106648740272 139.73805987360828 32.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1225f4dd-e0ee-42c5-bd60-7aa6a3b73dec">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1225f4dd-e0ee-42c5-bd60-7aa6a3b73dec">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1225f4dd-e0ee-42c5-bd60-7aa6a3b73dec">
											<gml:posList>35.671050678602285 139.7381298710313 15.09 35.67106788566998 139.73820952795006 15.09 35.67106788566998 139.73820952795006 30.477 35.671050678602285 139.7381298710313 30.477 35.671050678602285 139.7381298710313 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3bd5cbb-0690-41ae-94c0-5bcf4e7d8c37">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3bd5cbb-0690-41ae-94c0-5bcf4e7d8c37">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3bd5cbb-0690-41ae-94c0-5bcf4e7d8c37">
											<gml:posList>35.67105109393029 139.73807376611813 32.049 35.67106826068184 139.73806820045198 32.467 35.67106826068184 139.73806820045198 32.049 35.67105109393029 139.73807376611813 32.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c181c802-50d5-40db-8501-7cb8bd952a3b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c181c802-50d5-40db-8501-7cb8bd952a3b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c181c802-50d5-40db-8501-7cb8bd952a3b">
											<gml:posList>35.67105600178863 139.73801097282043 15.09 35.67106648740272 139.73805987360828 15.09 35.67106648740272 139.73805987360828 32.049 35.67105600178863 139.73801097282043 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e637c577-5ced-4e70-843b-fb86daa8d2ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e637c577-5ced-4e70-843b-fb86daa8d2ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e637c577-5ced-4e70-843b-fb86daa8d2ba">
											<gml:posList>35.67106826068184 139.73806820045198 35.952 35.67105681597915 139.73801470551953 32.049 35.67105600178863 139.73801097282043 15.09 35.67106648740272 139.73805987360828 32.049 35.67106826068184 139.73806820045198 35.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-545aa474-7abd-4c51-bc0d-bf44d8b3e98d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-545aa474-7abd-4c51-bc0d-bf44d8b3e98d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-545aa474-7abd-4c51-bc0d-bf44d8b3e98d">
											<gml:posList>35.67106826068184 139.73806820045198 35.952 35.67105681597915 139.73801470551953 35.952 35.67105681597915 139.73801470551953 32.049 35.67106826068184 139.73806820045198 35.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0f263271-a20a-4671-879a-28013df99ae2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0f263271-a20a-4671-879a-28013df99ae2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0f263271-a20a-4671-879a-28013df99ae2">
											<gml:posList>35.671062393443954 139.7381260682215 30.477 35.67107959150914 139.73820573620813 30.477 35.67107959150914 139.73820573620813 32.049 35.67105109393029 139.73807376611813 32.049 35.67104928454422 139.73806537304088 32.049 35.67104928454422 139.73806537304088 15.09 35.671062393443954 139.7381260682215 15.09 35.671062393443954 139.7381260682215 30.477</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a2dc1518-65dc-47d5-84c2-709ff11e1886">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a2dc1518-65dc-47d5-84c2-709ff11e1886">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a2dc1518-65dc-47d5-84c2-709ff11e1886">
											<gml:posList>35.67107056437522 139.73806337045787 35.952 35.67107056437522 139.73806337045787 35.656 35.671060748200034 139.738017528711 35.656 35.671060748200034 139.738017528711 35.952 35.67107056437522 139.73806337045787 35.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b5694c7-3419-4d8a-ae28-be94887983e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b5694c7-3419-4d8a-ae28-be94887983e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b5694c7-3419-4d8a-ae28-be94887983e4">
											<gml:posList>35.67106648740272 139.73805987360828 32.049 35.67106826068184 139.73806820045198 32.049 35.67106826068184 139.73806820045198 32.467 35.67106826068184 139.73806820045198 35.952 35.67106648740272 139.73805987360828 32.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-840476b5-bae5-4bad-9e7d-ae25152da5da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-840476b5-bae5-4bad-9e7d-ae25152da5da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-840476b5-bae5-4bad-9e7d-ae25152da5da">
											<gml:posList>35.67105681597915 139.73801470551953 35.952 35.6711045946161 139.73799934950947 35.952 35.6711045946161 139.73799934950947 32.049 35.67105681597915 139.73801470551953 32.049 35.67105681597915 139.73801470551953 35.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2147f356-f551-4d91-bb55-3f32b83c1171">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2147f356-f551-4d91-bb55-3f32b83c1171">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2147f356-f551-4d91-bb55-3f32b83c1171">
											<gml:posList>35.671060748200034 139.738017528711 35.952 35.671060748200034 139.738017528711 35.656 35.67110228191158 139.73800417951816 35.656 35.67110228191158 139.73800417951816 35.952 35.671060748200034 139.738017528711 35.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-87755fe7-4258-44f6-8673-a5d1c9662693">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-87755fe7-4258-44f6-8673-a5d1c9662693">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-87755fe7-4258-44f6-8673-a5d1c9662693">
											<gml:posList>35.671111998967106 139.73805005454403 35.952 35.671111998967106 139.73805005454403 35.656 35.67107056437522 139.73806337045787 35.656 35.67107056437522 139.73806337045787 35.952 35.671111998967106 139.73805005454403 35.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3e61e6c-69ad-4fa6-a69c-bda137aee240">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3e61e6c-69ad-4fa6-a69c-bda137aee240">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3e61e6c-69ad-4fa6-a69c-bda137aee240">
											<gml:posList>35.67106826068184 139.73806820045198 35.952 35.67106826068184 139.73806820045198 32.467 35.671115940209596 139.73805288877477 33.593 35.67111593119587 139.7380528887855 35.952 35.67106826068184 139.73806820045198 35.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1442ba95-93ab-44d4-aa8f-d81d1c364914">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1442ba95-93ab-44d4-aa8f-d81d1c364914">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1442ba95-93ab-44d4-aa8f-d81d1c364914">
											<gml:posList>35.67110228191158 139.73800417951816 35.952 35.67110228191158 139.73800417951816 35.656 35.671111998967106 139.73805005454403 35.656 35.671111998967106 139.73805005454403 35.952 35.67110228191158 139.73800417951816 35.952</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ffb91402-cf45-4bc3-ad45-b54d3ce722b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ffb91402-cf45-4bc3-ad45-b54d3ce722b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ffb91402-cf45-4bc3-ad45-b54d3ce722b1">
											<gml:posList>35.6711045946161 139.73799934950947 32.049 35.6711045946161 139.73799934950947 35.952 35.67111593119587 139.7380528887855 35.952 35.671115940209596 139.73805288877477 33.593 35.67111593119587 139.7380528887855 32.049 35.6711045946161 139.73799934950947 32.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c2c06908-8c82-46a1-b281-9d05766642c6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2c06908-8c82-46a1-b281-9d05766642c6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2c06908-8c82-46a1-b281-9d05766642c6">
											<gml:posList>35.67110921896978 139.73799974167974 31.955 35.67110799761329 139.73799405425686 31.955 35.67110799761329 139.73799405425686 32.049 35.671120283713 139.7380514807251 32.049 35.671120283713 139.7380514807251 33.791 35.671122599765 139.73806227026782 31.351 35.67110921896978 139.73799974167974 31.351 35.67110921896978 139.73799974167974 31.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5844b4ee-7cfe-4170-aa03-f5007e8abbfd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5844b4ee-7cfe-4170-aa03-f5007e8abbfd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5844b4ee-7cfe-4170-aa03-f5007e8abbfd">
											<gml:posList>35.671120283713 139.7380514807251 32.049 35.67111593119587 139.7380528887855 32.049 35.671115940209596 139.73805288877477 33.593 35.671120283713 139.7380514807251 33.791 35.671120283713 139.7380514807251 32.049</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-472dcf69-8d75-471f-bae2-a2b72f8c2e86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-472dcf69-8d75-471f-bae2-a2b72f8c2e86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-472dcf69-8d75-471f-bae2-a2b72f8c2e86">
											<gml:posList>35.67113550104494 139.7381225791272 31.351 35.67113550104494 139.7381225791272 29.421 35.671122599765 139.73806227026782 29.421 35.671122599765 139.73806227026782 31.351 35.671120283713 139.7380514807251 33.791 35.67114852893193 139.73818345122044 33.791 35.67113550104494 139.7381225791272 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab78aaa1-71f3-425f-baaa-68d19f1cbc7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab78aaa1-71f3-425f-baaa-68d19f1cbc7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab78aaa1-71f3-425f-baaa-68d19f1cbc7f">
											<gml:posList>35.67121649490702 139.7379586873043 15.09 35.67105600178863 139.73801097282043 15.09 35.67105600178863 139.73801097282043 32.049 35.67110799761329 139.73799405425686 32.049 35.67110799761329 139.73799405425686 31.955 35.67121649490702 139.7379586873043 31.955 35.67121649490702 139.7379586873043 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cafb2f9-8798-4747-83b7-ee48536dde45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cafb2f9-8798-4747-83b7-ee48536dde45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cafb2f9-8798-4747-83b7-ee48536dde45">
											<gml:posList>35.67114727136336 139.73817755395402 31.955 35.67114727136336 139.73817755395402 31.351 35.67113550104494 139.7381225791272 31.351 35.67114852893193 139.73818345122044 33.791 35.67114852893193 139.73818345122044 31.955 35.67114727136336 139.73817755395402 31.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e541fce0-7242-43a7-872e-47a53c2ddef1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e541fce0-7242-43a7-872e-47a53c2ddef1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e541fce0-7242-43a7-872e-47a53c2ddef1">
											<gml:posList>35.671122599765 139.73806227026782 31.351 35.671122599765 139.73806227026782 29.421 35.67116283583746 139.73804934239195 29.421 35.67116283583746 139.73804934239195 31.351 35.671122599765 139.73806227026782 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7821b273-b782-429c-86dd-700af35e9738">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7821b273-b782-429c-86dd-700af35e9738">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7821b273-b782-429c-86dd-700af35e9738">
											<gml:posList>35.67117573712382 139.7381096512795 31.351 35.67117573712382 139.7381096512795 29.421 35.67113550104494 139.7381225791272 29.421 35.67113550104494 139.7381225791272 31.351 35.67117573712382 139.7381096512795 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03ba3eee-9daf-4e1a-a4d1-f7146bcfa81b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03ba3eee-9daf-4e1a-a4d1-f7146bcfa81b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03ba3eee-9daf-4e1a-a4d1-f7146bcfa81b">
											<gml:posList>35.67110921896978 139.73799974167974 31.955 35.67110921896978 139.73799974167974 31.351 35.67121307540632 139.73796590465426 31.351 35.67121307540632 139.73796590465426 31.955 35.67110921896978 139.73799974167974 31.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28f267d1-7c4b-4f39-9347-cfefd3392f54">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28f267d1-7c4b-4f39-9347-cfefd3392f54">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28f267d1-7c4b-4f39-9347-cfefd3392f54">
											<gml:posList>35.67106788566998 139.73820952795006 15.09 35.671257296692545 139.73814808418499 15.09 35.671257296692545 139.73814808418499 31.955 35.67114852893193 139.73818345122044 31.955 35.67114852893193 139.73818345122044 33.791 35.67107959150914 139.73820573620813 32.049 35.67107959150914 139.73820573620813 30.477 35.67106788566998 139.73820952795006 30.477 35.67106788566998 139.73820952795006 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5a66347f-fbd5-4008-9bdd-71e3b00c7432">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5a66347f-fbd5-4008-9bdd-71e3b00c7432">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5a66347f-fbd5-4008-9bdd-71e3b00c7432">
											<gml:posList>35.67116283583746 139.73804934239195 31.351 35.67116283583746 139.73804934239195 29.421 35.67117573712382 139.7381096512795 29.421 35.67117573712382 139.7381096512795 31.351 35.67116283583746 139.73804934239195 31.351</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6eae645e-ad40-441c-9cf3-f6488ced1f56">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6eae645e-ad40-441c-9cf3-f6488ced1f56">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6eae645e-ad40-441c-9cf3-f6488ced1f56">
											<gml:posList>35.67125141642832 139.73814389354206 31.955 35.67125141642832 139.73814389354206 31.351 35.67114727136336 139.73817755395402 31.351 35.67114727136336 139.73817755395402 31.955 35.67125141642832 139.73814389354206 31.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff95e249-32c0-4372-addd-56c01a6e9178">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff95e249-32c0-4372-addd-56c01a6e9178">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff95e249-32c0-4372-addd-56c01a6e9178">
											<gml:posList>35.67121307540632 139.73796590465426 31.955 35.67121307540632 139.73796590465426 31.351 35.67125141642832 139.73814389354206 31.351 35.67125141642832 139.73814389354206 31.955 35.67121307540632 139.73796590465426 31.955</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7081e880-095c-4c13-8847-e9020f0ba49c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7081e880-095c-4c13-8847-e9020f0ba49c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7081e880-095c-4c13-8847-e9020f0ba49c">
											<gml:posList>35.671257296692545 139.73814808418499 15.09 35.67121649490702 139.7379586873043 15.09 35.67121649490702 139.7379586873043 31.955 35.671257296692545 139.73814808418499 31.955 35.671257296692545 139.73814808418499 15.09</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-8853</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">221.0823</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>