<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_686239bf-dfb1-4a31-83a1-6d0c4a57581d">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>0.90</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="再開発等促進区を定める地区計画">
				<gen:value>赤坂一丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">11.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.669694651457085 139.74359766489718 0 35.669718143593904 139.7436008199017 0 35.66971854586939 139.74359633470706 0 35.669817941195795 139.7436096445749 0 35.66982258949647 139.74355753452838 0 35.6698264153676 139.74351461582185 0 35.66970352789168 139.74349815109474 0 35.669694651457085 139.74359766489718 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669694651457085 139.74359766489718 9.228 35.66970352789168 139.74349815109474 9.228 35.6698264153676 139.74351461582185 9.228 35.66982258949647 139.74355753452838 9.228 35.669817941195795 139.7436096445749 9.228 35.66971854586939 139.74359633470706 9.228 35.669718143593904 139.7436008199017 9.228 35.669694651457085 139.74359766489718 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669694651457085 139.74359766489718 9.228 35.669718143593904 139.7436008199017 9.228 35.669718143593904 139.7436008199017 20.38 35.669694651457085 139.74359766489718 20.38 35.669694651457085 139.74359766489718 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669718143593904 139.7436008199017 9.228 35.66971854586939 139.74359633470706 9.228 35.66971854586939 139.74359633470706 20.38 35.669718143593904 139.7436008199017 20.38 35.669718143593904 139.7436008199017 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66971854586939 139.74359633470706 9.228 35.669817941195795 139.7436096445749 9.228 35.669817941195795 139.7436096445749 20.38 35.66971854586939 139.74359633470706 20.38 35.66971854586939 139.74359633470706 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669817941195795 139.7436096445749 9.228 35.66982258949647 139.74355753452838 9.228 35.66982258949647 139.74355753452838 20.38 35.669817941195795 139.7436096445749 20.38 35.669817941195795 139.7436096445749 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66982258949647 139.74355753452838 9.228 35.6698264153676 139.74351461582185 9.228 35.6698264153676 139.74351461582185 20.38 35.66982258949647 139.74355753452838 20.38 35.66982258949647 139.74355753452838 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698264153676 139.74351461582185 9.228 35.66970352789168 139.74349815109474 9.228 35.66970352789168 139.74349815109474 20.38 35.6698264153676 139.74351461582185 20.38 35.6698264153676 139.74351461582185 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66970352789168 139.74349815109474 9.228 35.669694651457085 139.74359766489718 9.228 35.669694651457085 139.74359766489718 20.38 35.66970352789168 139.74349815109474 20.38 35.66970352789168 139.74349815109474 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669694651457085 139.74359766489718 20.38 35.669718143593904 139.7436008199017 20.38 35.66971854586939 139.74359633470706 20.38 35.669817941195795 139.7436096445749 20.38 35.66982258949647 139.74355753452838 20.38 35.6698264153676 139.74351461582185 20.38 35.66970352789168 139.74349815109474 20.38 35.669694651457085 139.74359766489718 20.38</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-69c97a38-6588-410a-9411-18b2c0ee0d9d"/>
							<gml:surfaceMember xlink:href="#poly-fb2f47fb-0ec8-48d5-a96d-b87673c29687"/>
							<gml:surfaceMember xlink:href="#poly-b65c70a8-7aa5-4dad-91f0-330660579a7e"/>
							<gml:surfaceMember xlink:href="#poly-b7448d09-e6ee-4de5-ba17-3c31845047f8"/>
							<gml:surfaceMember xlink:href="#poly-0ba1233f-4103-40b3-b475-6e25f520eedb"/>
							<gml:surfaceMember xlink:href="#poly-dfe0ccbf-36a1-4afd-9b72-ce4939a632d0"/>
							<gml:surfaceMember xlink:href="#poly-d3de8fa4-2572-4d8d-9ac6-e31e2b5729c3"/>
							<gml:surfaceMember xlink:href="#poly-53527c54-9c0a-48e0-bb27-b050d1dc2f57"/>
							<gml:surfaceMember xlink:href="#poly-83b046ec-7e18-415b-8c62-b246cef49349"/>
							<gml:surfaceMember xlink:href="#poly-717f6cc6-68cc-42e6-b6b8-63d96eb2c5e4"/>
							<gml:surfaceMember xlink:href="#poly-713b5c10-90d1-4e53-8c1f-8afda7e40519"/>
							<gml:surfaceMember xlink:href="#poly-e20cd3db-78c5-4b4c-a290-600eef657d03"/>
							<gml:surfaceMember xlink:href="#poly-315ef379-750b-434e-a74a-0e1cae87e63e"/>
							<gml:surfaceMember xlink:href="#poly-384e2093-7018-41f8-ab12-f5b25403780f"/>
							<gml:surfaceMember xlink:href="#poly-8f4f0424-0ce7-44cd-9596-09bc20074604"/>
							<gml:surfaceMember xlink:href="#poly-1b3baba5-ae18-4ef1-b655-8478780e3d15"/>
							<gml:surfaceMember xlink:href="#poly-d031cb4e-a573-4114-8c65-816b08e1c45b"/>
							<gml:surfaceMember xlink:href="#poly-18c68e2e-2a2e-472c-9b01-c74eb3fc2115"/>
							<gml:surfaceMember xlink:href="#poly-15704622-4a41-4d78-a0c8-5c51c6bdf601"/>
							<gml:surfaceMember xlink:href="#poly-9d6b7d89-7287-4001-b202-7ddc502b9397"/>
							<gml:surfaceMember xlink:href="#poly-cfb1f98e-dc70-4bfd-9f3b-f012482d727d"/>
							<gml:surfaceMember xlink:href="#poly-833387e3-e11e-47c2-924c-5036a1ece53b"/>
							<gml:surfaceMember xlink:href="#poly-a64ce1d7-7a83-4fe7-b930-40be7ba4b9be"/>
							<gml:surfaceMember xlink:href="#poly-3150df12-d347-40f4-89ba-be89ebe27bba"/>
							<gml:surfaceMember xlink:href="#poly-3650633d-eeee-48d4-858e-c32125f6a798"/>
							<gml:surfaceMember xlink:href="#poly-4ef4e45f-bac1-48ee-a8ac-463f924e0d8b"/>
							<gml:surfaceMember xlink:href="#poly-f39340a7-52ee-40ba-9571-d28ada0a564e"/>
							<gml:surfaceMember xlink:href="#poly-28858e48-4695-4bb0-9fe3-1f74422a2ca3"/>
							<gml:surfaceMember xlink:href="#poly-9b10850d-dbf1-44e8-a635-3e40ba7ad715"/>
							<gml:surfaceMember xlink:href="#poly-66e1c3b7-1fdf-44d9-a570-5927c7125a14"/>
							<gml:surfaceMember xlink:href="#poly-f2d16b87-a65f-4590-b598-32af09669bbc"/>
							<gml:surfaceMember xlink:href="#poly-a969e838-9a82-4d08-a743-5c5f7d4c37da"/>
							<gml:surfaceMember xlink:href="#poly-bb7d7db2-f84c-4a82-9529-6239a4e4d11b"/>
							<gml:surfaceMember xlink:href="#poly-00f3f7da-d2bf-40e1-94cf-6b67dc4b8495"/>
							<gml:surfaceMember xlink:href="#poly-0c59f6aa-9cc0-4d0a-bc9c-7cb881049c49"/>
							<gml:surfaceMember xlink:href="#poly-8d86b36c-df4d-4213-8ddd-481f121efcc1"/>
							<gml:surfaceMember xlink:href="#poly-7d7eeb48-82b6-4681-b138-0984cc7c0337"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_686239bf-dfb1-4a31-83a1-6d0c4a57581d_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f13606fb-e70d-4ec0-a551-62637347ddba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f13606fb-e70d-4ec0-a551-62637347ddba_0">
											<gml:posList>35.66973184422844 139.74351587056427 21.149 35.66973030966912 139.74353705883777 22.259 35.66973184422844 139.74351587056427 22.259 35.66973184422844 139.74351587056427 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24063323-34ae-4c20-a98d-8ccd3f19abbb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24063323-34ae-4c20-a98d-8ccd3f19abbb_0">
											<gml:posList>35.66973184422844 139.74351587056427 21.149 35.66973030966912 139.74353705883777 21.149 35.66973030966912 139.74353705883777 22.259 35.66973184422844 139.74351587056427 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5fed9de3-7906-4f0f-a02e-a014a5fdb7bb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5fed9de3-7906-4f0f-a02e-a014a5fdb7bb_0">
											<gml:posList>35.66975450448244 139.74353968282264 21.149 35.66973030966912 139.74353705883777 22.259 35.66973030966912 139.74353705883777 21.149 35.66975450448244 139.74353968282264 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1219a5f-09c1-497e-9ad8-9ae969a0e9c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1219a5f-09c1-497e-9ad8-9ae969a0e9c5_0">
											<gml:posList>35.66975450448244 139.74353968282264 21.149 35.66975450448244 139.74353968282264 22.259 35.66973030966912 139.74353705883777 22.259 35.66975450448244 139.74353968282264 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5893fa82-cc33-4fd6-9971-ab3ddc10633b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5893fa82-cc33-4fd6-9971-ab3ddc10633b_0">
											<gml:posList>35.66975450448244 139.74353968282264 22.259 35.66975603905045 139.74351850558895 22.259 35.66973184422844 139.74351587056427 22.259 35.66975450448244 139.74353968282264 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99bc161b-8d1f-4456-988a-cea74aa9e40b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99bc161b-8d1f-4456-988a-cea74aa9e40b_0">
											<gml:posList>35.66973030966912 139.74353705883777 22.259 35.66975450448244 139.74353968282264 22.259 35.66973184422844 139.74351587056427 22.259 35.66973030966912 139.74353705883777 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4418456c-f920-4b0e-88e0-040de1046d15">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4418456c-f920-4b0e-88e0-040de1046d15_0">
											<gml:posList>35.66975603905045 139.74351850558895 21.149 35.66973184422844 139.74351587056427 22.259 35.66975603905045 139.74351850558895 22.259 35.66975603905045 139.74351850558895 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d85722d8-2c2f-4d2a-8efb-ba503997b62d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d85722d8-2c2f-4d2a-8efb-ba503997b62d_0">
											<gml:posList>35.66975603905045 139.74351850558895 21.149 35.66973184422844 139.74351587056427 21.149 35.66973184422844 139.74351587056427 22.259 35.66975603905045 139.74351850558895 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d2d5778e-4bd7-4a6a-a733-9bc53bb31555">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d2d5778e-4bd7-4a6a-a733-9bc53bb31555_0">
											<gml:posList>35.66975603905045 139.74351850558895 21.149 35.66975450448244 139.74353968282264 22.259 35.66975450448244 139.74353968282264 21.149 35.66975603905045 139.74351850558895 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1380c7d2-010e-4867-92bf-e1372feb50a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1380c7d2-010e-4867-92bf-e1372feb50a3_0">
											<gml:posList>35.66975603905045 139.74351850558895 21.149 35.66975603905045 139.74351850558895 22.259 35.66975450448244 139.74353968282264 22.259 35.66975603905045 139.74351850558895 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0d1f7c9-6f94-40ec-ae7b-4782cb7622c1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0d1f7c9-6f94-40ec-ae7b-4782cb7622c1_0">
											<gml:posList>35.66976014039392 139.74351863354883 21.149 35.669758128049075 139.7435397450416 22.259 35.66976014039392 139.74351863354883 22.259 35.66976014039392 139.74351863354883 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0d4dc8c-4e4e-4c8f-845b-340c27fc685c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0d4dc8c-4e4e-4c8f-845b-340c27fc685c_0">
											<gml:posList>35.66976014039392 139.74351863354883 21.149 35.669758128049075 139.7435397450416 21.149 35.669758128049075 139.7435397450416 22.259 35.66976014039392 139.74351863354883 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c046595-4fd8-4fda-968c-4e38ed71aedd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c046595-4fd8-4fda-968c-4e38ed71aedd_0">
											<gml:posList>35.669794448248915 139.7435449402551 21.149 35.669758128049075 139.7435397450416 22.259 35.669758128049075 139.7435397450416 21.149 35.669794448248915 139.7435449402551 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c1ba9748-d7b7-4d88-9230-96ac67db6cb9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c1ba9748-d7b7-4d88-9230-96ac67db6cb9_0">
											<gml:posList>35.669794448248915 139.7435449402551 21.149 35.669794448248915 139.7435449402551 22.259 35.669758128049075 139.7435397450416 22.259 35.669794448248915 139.7435449402551 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1f76792-a7f3-42c0-8f8f-e264488ee7de">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1f76792-a7f3-42c0-8f8f-e264488ee7de_0">
											<gml:posList>35.669758128049075 139.7435397450416 22.259 35.66979646060288 139.74352383979908 22.259 35.66976014039392 139.74351863354883 22.259 35.669758128049075 139.7435397450416 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-24951236-9a5f-4dc0-9498-d45750bc699a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-24951236-9a5f-4dc0-9498-d45750bc699a_0">
											<gml:posList>35.669758128049075 139.7435397450416 22.259 35.669794448248915 139.7435449402551 22.259 35.66979646060288 139.74352383979908 22.259 35.669758128049075 139.7435397450416 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-945a589b-b11e-48a4-8195-0309dbf6c123">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-945a589b-b11e-48a4-8195-0309dbf6c123_0">
											<gml:posList>35.66976014039392 139.74351863354883 21.149 35.66979646060288 139.74352383979908 22.259 35.66979646060288 139.74352383979908 21.149 35.66976014039392 139.74351863354883 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-519c3a7c-1b03-47ac-87dc-5eab06de3d63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-519c3a7c-1b03-47ac-87dc-5eab06de3d63_0">
											<gml:posList>35.66976014039392 139.74351863354883 21.149 35.66976014039392 139.74351863354883 22.259 35.66979646060288 139.74352383979908 22.259 35.66976014039392 139.74351863354883 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f30114b-3ad1-4af2-9b35-e2e29c6b23e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f30114b-3ad1-4af2-9b35-e2e29c6b23e2_0">
											<gml:posList>35.669794448248915 139.7435449402551 21.149 35.66979646060288 139.74352383979908 22.259 35.669794448248915 139.7435449402551 22.259 35.669794448248915 139.7435449402551 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c88bf82e-a271-452a-bc74-4c8f2f9935d9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c88bf82e-a271-452a-bc74-4c8f2f9935d9_0">
											<gml:posList>35.669794448248915 139.7435449402551 21.149 35.66979646060288 139.74352383979908 21.149 35.66979646060288 139.74352383979908 22.259 35.669794448248915 139.7435449402551 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bdf08f6-cbba-47e2-946b-bfac22b7d6eb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bdf08f6-cbba-47e2-946b-bfac22b7d6eb_0">
											<gml:posList>35.66980802360965 139.74354585293202 21.149 35.66980978461754 139.74352614457277 22.259 35.66980978461754 139.74352614457277 21.149 35.66980802360965 139.74354585293202 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2214b50b-c4c7-422c-9cfc-457a5cdab73c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2214b50b-c4c7-422c-9cfc-457a5cdab73c_0">
											<gml:posList>35.66980802360965 139.74354585293202 21.149 35.66980802360965 139.74354585293202 22.259 35.66980978461754 139.74352614457277 22.259 35.66980802360965 139.74354585293202 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6ea4d8e-73fb-4830-853b-80e0de01f689">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6ea4d8e-73fb-4830-853b-80e0de01f689_0">
											<gml:posList>35.66980978461754 139.74352614457277 22.259 35.66982321325065 139.7435478684198 22.259 35.66982497425887 139.74352816005688 22.259 35.66980978461754 139.74352614457277 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-82aad85f-e01f-4e03-86c6-ba1900291e9f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-82aad85f-e01f-4e03-86c6-ba1900291e9f_0">
											<gml:posList>35.66980978461754 139.74352614457277 22.259 35.66980802360965 139.74354585293202 22.259 35.66982321325065 139.7435478684198 22.259 35.66980978461754 139.74352614457277 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4b2f621-2de7-48da-a5e9-dc1402ddd588">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4b2f621-2de7-48da-a5e9-dc1402ddd588_0">
											<gml:posList>35.66982429816363 139.7435280724447 22.259 35.6698225371472 139.74354776976128 21.149 35.66982429816363 139.7435280724447 21.149 35.66982429816363 139.7435280724447 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e9de0aae-7b28-437f-8cf7-4b8bff2bb00f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e9de0aae-7b28-437f-8cf7-4b8bff2bb00f_0">
											<gml:posList>35.66982429816363 139.7435280724447 22.259 35.6698225371472 139.74354776976128 22.259 35.6698225371472 139.74354776976128 21.149 35.66982429816363 139.7435280724447 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55b2d69f-df94-4e8d-8923-6f34898dc40d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55b2d69f-df94-4e8d-8923-6f34898dc40d_0">
											<gml:posList>35.6698225371472 139.74354776976128 21.149 35.6698225371472 139.74354776976128 22.259 35.66980802360965 139.74354585293202 21.149 35.6698225371472 139.74354776976128 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e4b1dca3-f744-4a00-b708-b875a92bd22f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e4b1dca3-f744-4a00-b708-b875a92bd22f_0">
											<gml:posList>35.66980802360965 139.74354585293202 21.149 35.6698225371472 139.74354776976128 22.259 35.66980802360965 139.74354585293202 22.259 35.66980802360965 139.74354585293202 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-166bb20e-6e79-405d-8172-554a90934e1e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-166bb20e-6e79-405d-8172-554a90934e1e_0">
											<gml:posList>35.6698225371472 139.74354776976128 22.259 35.66982321325065 139.7435478684198 22.259 35.66980802360965 139.74354585293202 22.259 35.6698225371472 139.74354776976128 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-768592f4-0e36-4014-8907-9455e5b87449">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-768592f4-0e36-4014-8907-9455e5b87449_0">
											<gml:posList>35.66982497425887 139.74352816005688 22.259 35.66982429816363 139.7435280724447 22.259 35.66980978461754 139.74352614457277 22.259 35.66982497425887 139.74352816005688 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bc940a6-ec56-4651-b55d-a4bf7e0e0b1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7bc940a6-ec56-4651-b55d-a4bf7e0e0b1a_0">
											<gml:posList>35.66980978461754 139.74352614457277 22.259 35.66982429816363 139.7435280724447 21.149 35.66980978461754 139.74352614457277 21.149 35.66980978461754 139.74352614457277 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fec0c14-a5ea-4491-abb9-9c73d1bbd295">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1fec0c14-a5ea-4491-abb9-9c73d1bbd295_0">
											<gml:posList>35.66980978461754 139.74352614457277 22.259 35.66982429816363 139.7435280724447 22.259 35.66982429816363 139.7435280724447 21.149 35.66980978461754 139.74352614457277 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-773a67ef-ba29-4618-a0e2-163e4ecb372e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66973184422844 139.74351587056427 21.149 35.66975603905045 139.74351850558895 21.149 35.66975450448244 139.74353968282264 21.149 35.66973184422844 139.74351587056427 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ca383aa-6f36-4abe-9211-84dd7c8412bd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66973030966912 139.74353705883777 21.149 35.66973184422844 139.74351587056427 21.149 35.66975450448244 139.74353968282264 21.149 35.66973030966912 139.74353705883777 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60371f1a-6ce3-44c2-9272-2dfc772a05b8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66979646060288 139.74352383979908 21.149 35.669758128049075 139.7435397450416 21.149 35.66976014039392 139.74351863354883 21.149 35.66979646060288 139.74352383979908 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b4bd650-a7f5-4deb-b849-a1e6029bfd9a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66979646060288 139.74352383979908 21.149 35.669794448248915 139.7435449402551 21.149 35.669758128049075 139.7435397450416 21.149 35.66979646060288 139.74352383979908 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07e6181a-e407-411f-8f61-ec58f3206f0e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698225371472 139.74354776976128 21.149 35.66980978461754 139.74352614457277 21.149 35.66982429816363 139.7435280724447 21.149 35.6698225371472 139.74354776976128 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91c1f3f8-fc9e-457d-9af6-c1be17cc55ba">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6698225371472 139.74354776976128 21.149 35.66980802360965 139.74354585293202 21.149 35.66980978461754 139.74352614457277 21.149 35.6698225371472 139.74354776976128 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b51b73cf-2804-4ca3-b600-573f0291c43e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66982497425887 139.74352816005688 22.259 35.66982321325065 139.7435478684198 22.259 35.6698225371472 139.74354776976128 22.259 35.66982497425887 139.74352816005688 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a502a5f-5a4f-468a-82e0-61afc8f409eb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66982429816363 139.7435280724447 22.259 35.66982497425887 139.74352816005688 22.259 35.6698225371472 139.74354776976128 22.259 35.66982429816363 139.7435280724447 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-69c97a38-6588-410a-9411-18b2c0ee0d9d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69c97a38-6588-410a-9411-18b2c0ee0d9d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69c97a38-6588-410a-9411-18b2c0ee0d9d">
											<gml:posList>35.66971814359386 139.7436008199017 9.228 35.669694651457085 139.74359766489718 9.228 35.66970352789165 139.74349815109477 9.228 35.66982641536759 139.74351461582182 9.228 35.66982258949647 139.74355753452835 9.228 35.66981794119579 139.7436096445749 9.228 35.66971854586936 139.74359633470706 9.228 35.66971814359386 139.7436008199017 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fb2f47fb-0ec8-48d5-a96d-b87673c29687">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb2f47fb-0ec8-48d5-a96d-b87673c29687">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb2f47fb-0ec8-48d5-a96d-b87673c29687">
											<gml:posList>35.669694651457085 139.74359766489718 16.6 35.66971814359386 139.7436008199017 16.6 35.66972319416445 139.74354422472436 16.6 35.66971797490499 139.74354381081477 16.6 35.66972182759827 139.74350060493316 16.6 35.66970352789165 139.74349815109477 16.6 35.669694651457085 139.74359766489718 16.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b65c70a8-7aa5-4dad-91f0-330660579a7e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b65c70a8-7aa5-4dad-91f0-330660579a7e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b65c70a8-7aa5-4dad-91f0-330660579a7e">
											<gml:posList>35.66971797490499 139.74354381081477 22.259 35.66971900168707 139.7435427602789 22.259 35.669722648778404 139.74350185223022 22.259 35.66972182759827 139.74350060493316 22.259 35.66971797490499 139.74354381081477 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b7448d09-e6ee-4de5-ba17-3c31845047f8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b7448d09-e6ee-4de5-ba17-3c31845047f8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b7448d09-e6ee-4de5-ba17-3c31845047f8">
											<gml:posList>35.66972319416445 139.74354422472436 22.259 35.66972328346977 139.74354310896126 22.259 35.66971900168707 139.7435427602789 22.259 35.66971797490499 139.74354381081477 22.259 35.66972319416445 139.74354422472436 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ba1233f-4103-40b3-b475-6e25f520eedb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ba1233f-4103-40b3-b475-6e25f520eedb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ba1233f-4103-40b3-b475-6e25f520eedb">
											<gml:posList>35.66972152723064 139.7435934041355 14.087 35.66981554983439 139.74360599096468 14.087 35.669819608136116 139.7435604651049 14.087 35.66981990313485 139.7435571730122 14.087 35.66972319416445 139.74354422472436 14.087 35.66971884086908 139.7435930426186 14.087 35.66972152723064 139.7435934041355 14.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-dfe0ccbf-36a1-4afd-9b72-ce4939a632d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dfe0ccbf-36a1-4afd-9b72-ce4939a632d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dfe0ccbf-36a1-4afd-9b72-ce4939a632d0">
											<gml:posList>35.66972328346977 139.74354310896126 21.149 35.669821777338896 139.74355629826525 21.149 35.66982540658026 139.74351562215458 21.149 35.669722648778404 139.74350185223022 21.149 35.66971900168707 139.7435427602789 21.149 35.66972328346977 139.74354310896126 21.149</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d3de8fa4-2572-4d8d-9ac6-e31e2b5729c3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d3de8fa4-2572-4d8d-9ac6-e31e2b5729c3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d3de8fa4-2572-4d8d-9ac6-e31e2b5729c3">
											<gml:posList>35.66972319416445 139.74354422472436 22.259 35.66982258949647 139.74355753452835 22.259 35.669821777338896 139.74355629826525 22.259 35.66972328346977 139.74354310896126 22.259 35.66972319416445 139.74354422472436 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-53527c54-9c0a-48e0-bb27-b050d1dc2f57">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53527c54-9c0a-48e0-bb27-b050d1dc2f57">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53527c54-9c0a-48e0-bb27-b050d1dc2f57">
											<gml:posList>35.66972182759827 139.74350060493316 22.259 35.669722648778404 139.74350185223022 22.259 35.66982540658026 139.74351562215458 22.259 35.66982641536759 139.74351461582182 22.259 35.66972182759827 139.74350060493316 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-83b046ec-7e18-415b-8c62-b246cef49349">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-83b046ec-7e18-415b-8c62-b246cef49349">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-83b046ec-7e18-415b-8c62-b246cef49349">
											<gml:posList>35.66982258949647 139.74355753452835 15.087 35.66981990313485 139.7435571730122 15.087 35.669819608136116 139.7435604651049 15.087 35.66982258949647 139.74355753452835 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-717f6cc6-68cc-42e6-b6b8-63d96eb2c5e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-717f6cc6-68cc-42e6-b6b8-63d96eb2c5e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-717f6cc6-68cc-42e6-b6b8-63d96eb2c5e4">
											<gml:posList>35.66982641536759 139.74351461582182 22.259 35.66982540658026 139.74351562215458 22.259 35.669821777338896 139.74355629826525 22.259 35.66982258949647 139.74355753452835 22.259 35.66982641536759 139.74351461582182 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-713b5c10-90d1-4e53-8c1f-8afda7e40519">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-713b5c10-90d1-4e53-8c1f-8afda7e40519">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-713b5c10-90d1-4e53-8c1f-8afda7e40519">
											<gml:posList>35.66971884086908 139.7435930426186 15.087 35.66971854586936 139.74359633470706 15.087 35.66972152723064 139.7435934041355 15.087 35.66971884086908 139.7435930426186 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e20cd3db-78c5-4b4c-a290-600eef657d03">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e20cd3db-78c5-4b4c-a290-600eef657d03">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e20cd3db-78c5-4b4c-a290-600eef657d03">
											<gml:posList>35.66971854586936 139.74359633470706 15.087 35.66981794119579 139.7436096445749 15.087 35.66981554983439 139.74360599096468 15.087 35.66972152723064 139.7435934041355 15.087 35.66971854586936 139.74359633470706 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-315ef379-750b-434e-a74a-0e1cae87e63e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-315ef379-750b-434e-a74a-0e1cae87e63e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-315ef379-750b-434e-a74a-0e1cae87e63e">
											<gml:posList>35.66981794119579 139.7436096445749 15.087 35.66982258949647 139.74355753452835 15.087 35.669819608136116 139.7435604651049 15.087 35.66981554983439 139.74360599096468 15.087 35.66981794119579 139.7436096445749 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-384e2093-7018-41f8-ab12-f5b25403780f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-384e2093-7018-41f8-ab12-f5b25403780f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-384e2093-7018-41f8-ab12-f5b25403780f">
											<gml:posList>35.66982641536759 139.74351461582182 22.259 35.66982641536759 139.74351461582182 9.228 35.66970352789165 139.74349815109477 9.228 35.66970352789165 139.74349815109477 16.6 35.66972182759827 139.74350060493316 16.6 35.66972182759827 139.74350060493316 22.259 35.66982641536759 139.74351461582182 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8f4f0424-0ce7-44cd-9596-09bc20074604">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8f4f0424-0ce7-44cd-9596-09bc20074604">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8f4f0424-0ce7-44cd-9596-09bc20074604">
											<gml:posList>35.669722648778404 139.74350185223022 22.259 35.669722648778404 139.74350185223022 21.149 35.66982540658026 139.74351562215458 21.149 35.66982540658026 139.74351562215458 22.259 35.669722648778404 139.74350185223022 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1b3baba5-ae18-4ef1-b655-8478780e3d15">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1b3baba5-ae18-4ef1-b655-8478780e3d15">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1b3baba5-ae18-4ef1-b655-8478780e3d15">
											<gml:posList>35.66971797490499 139.74354381081477 16.6 35.66971797490499 139.74354381081477 22.259 35.66972182759827 139.74350060493316 22.259 35.66972182759827 139.74350060493316 16.6 35.66971797490499 139.74354381081477 16.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d031cb4e-a573-4114-8c65-816b08e1c45b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d031cb4e-a573-4114-8c65-816b08e1c45b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d031cb4e-a573-4114-8c65-816b08e1c45b">
											<gml:posList>35.66971900168707 139.7435427602789 22.259 35.66971900168707 139.7435427602789 21.149 35.669722648778404 139.74350185223022 21.149 35.669722648778404 139.74350185223022 22.259 35.66971900168707 139.7435427602789 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-18c68e2e-2a2e-472c-9b01-c74eb3fc2115">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-18c68e2e-2a2e-472c-9b01-c74eb3fc2115">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-18c68e2e-2a2e-472c-9b01-c74eb3fc2115">
											<gml:posList>35.66982540658026 139.74351562215458 22.259 35.66982540658026 139.74351562215458 21.149 35.669821777338896 139.74355629826525 21.149 35.669821777338896 139.74355629826525 22.259 35.66982540658026 139.74351562215458 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-15704622-4a41-4d78-a0c8-5c51c6bdf601">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15704622-4a41-4d78-a0c8-5c51c6bdf601">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15704622-4a41-4d78-a0c8-5c51c6bdf601">
											<gml:posList>35.66982641536759 139.74351461582182 22.259 35.66982258949647 139.74355753452835 22.259 35.66982258949647 139.74355753452835 15.087 35.66982258949647 139.74355753452835 9.228 35.66982641536759 139.74351461582182 9.228 35.66982641536759 139.74351461582182 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d6b7d89-7287-4001-b202-7ddc502b9397">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d6b7d89-7287-4001-b202-7ddc502b9397">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d6b7d89-7287-4001-b202-7ddc502b9397">
											<gml:posList>35.66972328346977 139.74354310896126 22.259 35.66972328346977 139.74354310896126 21.149 35.66971900168707 139.7435427602789 21.149 35.66971900168707 139.7435427602789 22.259 35.66972328346977 139.74354310896126 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfb1f98e-dc70-4bfd-9f3b-f012482d727d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfb1f98e-dc70-4bfd-9f3b-f012482d727d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfb1f98e-dc70-4bfd-9f3b-f012482d727d">
											<gml:posList>35.66971797490499 139.74354381081477 22.259 35.66971797490499 139.74354381081477 16.6 35.66972319416445 139.74354422472436 16.6 35.66971797490499 139.74354381081477 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-833387e3-e11e-47c2-924c-5036a1ece53b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-833387e3-e11e-47c2-924c-5036a1ece53b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-833387e3-e11e-47c2-924c-5036a1ece53b">
											<gml:posList>35.66972319416445 139.74354422472436 22.259 35.66971797490499 139.74354381081477 22.259 35.66972319416445 139.74354422472436 16.6 35.66972319416445 139.74354422472436 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a64ce1d7-7a83-4fe7-b930-40be7ba4b9be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a64ce1d7-7a83-4fe7-b930-40be7ba4b9be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a64ce1d7-7a83-4fe7-b930-40be7ba4b9be">
											<gml:posList>35.66970352789165 139.74349815109477 9.228 35.669694651457085 139.74359766489718 9.228 35.669694651457085 139.74359766489718 16.6 35.66970352789165 139.74349815109477 16.6 35.66970352789165 139.74349815109477 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3150df12-d347-40f4-89ba-be89ebe27bba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3150df12-d347-40f4-89ba-be89ebe27bba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3150df12-d347-40f4-89ba-be89ebe27bba">
											<gml:posList>35.669821777338896 139.74355629826525 22.259 35.669821777338896 139.74355629826525 21.149 35.66972328346977 139.74354310896126 21.149 35.66972328346977 139.74354310896126 22.259 35.669821777338896 139.74355629826525 22.259</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3650633d-eeee-48d4-858e-c32125f6a798">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3650633d-eeee-48d4-858e-c32125f6a798">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3650633d-eeee-48d4-858e-c32125f6a798">
											<gml:posList>35.66972319416445 139.74354422472436 16.6 35.66972319416445 139.74354422472436 14.087 35.66981990313485 139.7435571730122 14.087 35.66972319416445 139.74354422472436 16.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4ef4e45f-bac1-48ee-a8ac-463f924e0d8b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ef4e45f-bac1-48ee-a8ac-463f924e0d8b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ef4e45f-bac1-48ee-a8ac-463f924e0d8b">
											<gml:posList>35.66981990313485 139.7435571730122 15.087 35.66972319416445 139.74354422472436 16.6 35.66981990313485 139.7435571730122 14.087 35.66981990313485 139.7435571730122 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f39340a7-52ee-40ba-9571-d28ada0a564e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f39340a7-52ee-40ba-9571-d28ada0a564e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f39340a7-52ee-40ba-9571-d28ada0a564e">
											<gml:posList>35.66981990313485 139.7435571730122 15.087 35.66972319416445 139.74354422472436 22.259 35.66972319416445 139.74354422472436 16.6 35.66981990313485 139.7435571730122 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-28858e48-4695-4bb0-9fe3-1f74422a2ca3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-28858e48-4695-4bb0-9fe3-1f74422a2ca3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-28858e48-4695-4bb0-9fe3-1f74422a2ca3">
											<gml:posList>35.66981990313485 139.7435571730122 15.087 35.66982258949647 139.74355753452835 22.259 35.66972319416445 139.74354422472436 22.259 35.66981990313485 139.7435571730122 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9b10850d-dbf1-44e8-a635-3e40ba7ad715">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9b10850d-dbf1-44e8-a635-3e40ba7ad715">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9b10850d-dbf1-44e8-a635-3e40ba7ad715">
											<gml:posList>35.66981990313485 139.7435571730122 15.087 35.66982258949647 139.74355753452835 15.087 35.66982258949647 139.74355753452835 22.259 35.66981990313485 139.7435571730122 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-66e1c3b7-1fdf-44d9-a570-5927c7125a14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-66e1c3b7-1fdf-44d9-a570-5927c7125a14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-66e1c3b7-1fdf-44d9-a570-5927c7125a14">
											<gml:posList>35.669819608136116 139.7435604651049 15.087 35.66981990313485 139.7435571730122 15.087 35.66981990313485 139.7435571730122 14.087 35.669819608136116 139.7435604651049 14.087 35.669819608136116 139.7435604651049 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f2d16b87-a65f-4590-b598-32af09669bbc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f2d16b87-a65f-4590-b598-32af09669bbc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f2d16b87-a65f-4590-b598-32af09669bbc">
											<gml:posList>35.66971884086908 139.7435930426186 15.087 35.66971884086908 139.7435930426186 14.087 35.66972319416445 139.74354422472436 14.087 35.66972319416445 139.74354422472436 16.6 35.66971814359386 139.7436008199017 16.6 35.66971814359386 139.7436008199017 9.228 35.66971854586936 139.74359633470706 9.228 35.66971854586936 139.74359633470706 15.087 35.66971884086908 139.7435930426186 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a969e838-9a82-4d08-a743-5c5f7d4c37da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a969e838-9a82-4d08-a743-5c5f7d4c37da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a969e838-9a82-4d08-a743-5c5f7d4c37da">
											<gml:posList>35.66981554983439 139.74360599096468 15.087 35.669819608136116 139.7435604651049 15.087 35.669819608136116 139.7435604651049 14.087 35.66981554983439 139.74360599096468 14.087 35.66981554983439 139.74360599096468 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb7d7db2-f84c-4a82-9529-6239a4e4d11b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb7d7db2-f84c-4a82-9529-6239a4e4d11b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb7d7db2-f84c-4a82-9529-6239a4e4d11b">
											<gml:posList>35.66982258949647 139.74355753452835 9.228 35.66982258949647 139.74355753452835 15.087 35.66981794119579 139.7436096445749 15.087 35.66981794119579 139.7436096445749 9.228 35.66982258949647 139.74355753452835 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00f3f7da-d2bf-40e1-94cf-6b67dc4b8495">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00f3f7da-d2bf-40e1-94cf-6b67dc4b8495">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00f3f7da-d2bf-40e1-94cf-6b67dc4b8495">
											<gml:posList>35.66971884086908 139.7435930426186 15.087 35.66972152723064 139.7435934041355 15.087 35.66972152723064 139.7435934041355 14.087 35.66971884086908 139.7435930426186 14.087 35.66971884086908 139.7435930426186 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c59f6aa-9cc0-4d0a-bc9c-7cb881049c49">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c59f6aa-9cc0-4d0a-bc9c-7cb881049c49">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c59f6aa-9cc0-4d0a-bc9c-7cb881049c49">
											<gml:posList>35.669694651457085 139.74359766489718 9.228 35.66971814359386 139.7436008199017 9.228 35.66971814359386 139.7436008199017 16.6 35.669694651457085 139.74359766489718 16.6 35.669694651457085 139.74359766489718 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8d86b36c-df4d-4213-8ddd-481f121efcc1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d86b36c-df4d-4213-8ddd-481f121efcc1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d86b36c-df4d-4213-8ddd-481f121efcc1">
											<gml:posList>35.66972152723064 139.7435934041355 15.087 35.66981554983439 139.74360599096468 15.087 35.66981554983439 139.74360599096468 14.087 35.66972152723064 139.7435934041355 14.087 35.66972152723064 139.7435934041355 15.087</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d7eeb48-82b6-4681-b138-0984cc7c0337">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d7eeb48-82b6-4681-b138-0984cc7c0337">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d7eeb48-82b6-4681-b138-0984cc7c0337">
											<gml:posList>35.66971854586936 139.74359633470706 9.228 35.66981794119579 139.7436096445749 9.228 35.66981794119579 139.7436096445749 15.087 35.66971854586936 139.74359633470706 15.087 35.66971854586936 139.74359633470706 9.228</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4953</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">249.52921</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">2</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>