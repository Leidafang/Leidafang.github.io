<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_688af926-dc31-4320-8208-9718f40755c4">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">25.2</bldg:measuredHeight>
			<bldg:storeysAboveGround>9</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67177111070174 139.74001928423274 0 35.67167178363295 139.7399201034142 0 35.67166413096795 139.7399317110887 0 35.67165005859516 139.73991758804692 0 35.67159495895556 139.74000061091203 0 35.671708349220005 139.7401138154098 0 35.67177111070174 139.74001928423274 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67177111070174 139.74001928423274 9.23 35.671708349220005 139.7401138154098 9.23 35.67159495895556 139.74000061091203 9.23 35.67165005859516 139.73991758804692 9.23 35.67166413096795 139.7399317110887 9.23 35.67167178363295 139.7399201034142 9.23 35.67177111070174 139.74001928423274 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67177111070174 139.74001928423274 9.23 35.67167178363295 139.7399201034142 9.23 35.67167178363295 139.7399201034142 34.43 35.67177111070174 139.74001928423274 34.43 35.67177111070174 139.74001928423274 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67167178363295 139.7399201034142 9.23 35.67166413096795 139.7399317110887 9.23 35.67166413096795 139.7399317110887 34.43 35.67167178363295 139.7399201034142 34.43 35.67167178363295 139.7399201034142 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67166413096795 139.7399317110887 9.23 35.67165005859516 139.73991758804692 9.23 35.67165005859516 139.73991758804692 34.43 35.67166413096795 139.7399317110887 34.43 35.67166413096795 139.7399317110887 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67165005859516 139.73991758804692 9.23 35.67159495895556 139.74000061091203 9.23 35.67159495895556 139.74000061091203 34.43 35.67165005859516 139.73991758804692 34.43 35.67165005859516 139.73991758804692 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67159495895556 139.74000061091203 9.23 35.671708349220005 139.7401138154098 9.23 35.671708349220005 139.7401138154098 34.43 35.67159495895556 139.74000061091203 34.43 35.67159495895556 139.74000061091203 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671708349220005 139.7401138154098 9.23 35.67177111070174 139.74001928423274 9.23 35.67177111070174 139.74001928423274 34.43 35.671708349220005 139.7401138154098 34.43 35.671708349220005 139.7401138154098 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67177111070174 139.74001928423274 34.43 35.67167178363295 139.7399201034142 34.43 35.67166413096795 139.7399317110887 34.43 35.67165005859516 139.73991758804692 34.43 35.67159495895556 139.74000061091203 34.43 35.671708349220005 139.7401138154098 34.43 35.67177111070174 139.74001928423274 34.43</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-8d1ec925-7814-4cf3-a3be-5dc7eaa55894"/>
							<gml:surfaceMember xlink:href="#poly-7b7027a8-a8bc-429a-be69-4d95c3ba81d7"/>
							<gml:surfaceMember xlink:href="#poly-ee6d9d4e-21b6-49c3-a147-b3a8d95f1a59"/>
							<gml:surfaceMember xlink:href="#poly-bca13c24-e689-471b-ad99-adccf6f9748e"/>
							<gml:surfaceMember xlink:href="#poly-e9912f4e-2bea-44f3-927f-e49a5cf654fa"/>
							<gml:surfaceMember xlink:href="#poly-702ef7b8-5994-42c8-b458-1181f781f530"/>
							<gml:surfaceMember xlink:href="#poly-59c6e4c1-490a-44eb-891c-7721ba5861b0"/>
							<gml:surfaceMember xlink:href="#poly-e28e4ba9-8a30-4dd6-bcd4-ac75dae98d10"/>
							<gml:surfaceMember xlink:href="#poly-1cba873e-7fd0-4657-850d-87ca842b46fb"/>
							<gml:surfaceMember xlink:href="#poly-41120ed3-82c9-4d69-8179-346638f9a608"/>
							<gml:surfaceMember xlink:href="#poly-926bb28f-c776-4394-9e88-fdfd91b5a2b8"/>
							<gml:surfaceMember xlink:href="#poly-c2d4ed05-041b-4078-8531-610ae8c99207"/>
							<gml:surfaceMember xlink:href="#poly-8b218228-97cd-4b64-ae9a-21600f58c3f3"/>
							<gml:surfaceMember xlink:href="#poly-44570e09-78a9-4880-b478-9dae1e3330a1"/>
							<gml:surfaceMember xlink:href="#poly-f1077f7c-f084-4a61-afbd-3674db7e63ca"/>
							<gml:surfaceMember xlink:href="#poly-8c6a8335-6245-4e2c-8641-561b510657f0"/>
							<gml:surfaceMember xlink:href="#poly-f4e0d777-eb39-48cf-9285-4e549940f3c7"/>
							<gml:surfaceMember xlink:href="#poly-22083be1-7f85-4362-98a6-f939b1cfdcd3"/>
							<gml:surfaceMember xlink:href="#poly-b917406d-98ca-4864-ace1-75c7e6a1b316"/>
							<gml:surfaceMember xlink:href="#poly-2c02130a-fe08-43ae-91b1-06e3f9f41c4a"/>
							<gml:surfaceMember xlink:href="#poly-bd629ebf-f4bb-4f87-b9dd-00d9349b0a5c"/>
							<gml:surfaceMember xlink:href="#poly-10a11a16-f600-4f8b-ba05-22ed88b5a5ca"/>
							<gml:surfaceMember xlink:href="#poly-5e1cbab1-9856-4554-b826-644098d77888"/>
							<gml:surfaceMember xlink:href="#poly-a684fbd9-ae99-48bd-8269-a195b757942b"/>
							<gml:surfaceMember xlink:href="#poly-2020f8a9-6cc8-4822-89b0-904dc8237059"/>
							<gml:surfaceMember xlink:href="#poly-b39fb7b9-cc48-4b97-a5bf-ac85441cc406"/>
							<gml:surfaceMember xlink:href="#poly-b09b5c29-26e6-43d3-986d-c30680f19d92"/>
							<gml:surfaceMember xlink:href="#poly-b2b68085-783d-4d7d-9048-4901e9b1e303"/>
							<gml:surfaceMember xlink:href="#poly-c7b1ddf1-e397-43f7-85a0-46d03fd98150"/>
							<gml:surfaceMember xlink:href="#poly-ce059a0e-df41-48bf-9aa0-d7153a35a3ee"/>
							<gml:surfaceMember xlink:href="#poly-6d1bc6e0-b47b-4291-8d47-e7559818cac1"/>
							<gml:surfaceMember xlink:href="#poly-9d8e205a-6479-4f59-ac93-693f2d9ae58f"/>
							<gml:surfaceMember xlink:href="#poly-093d9176-ebd8-421d-8038-9fa2ced6e515"/>
							<gml:surfaceMember xlink:href="#poly-ef246cea-00d7-4ef2-84bc-10936171ed24"/>
							<gml:surfaceMember xlink:href="#poly-16b88fd3-c4fc-423f-b0c1-12a542ff03be"/>
							<gml:surfaceMember xlink:href="#poly-8253e2ab-c975-4499-93f7-f83a7ddfa6d3"/>
							<gml:surfaceMember xlink:href="#poly-8100fbc9-f4ef-4708-b24d-ac991c2d3998"/>
							<gml:surfaceMember xlink:href="#poly-f5e50da7-1c1f-442c-897e-3409d69411f9"/>
							<gml:surfaceMember xlink:href="#poly-95e48bb0-546a-47a1-9f11-38abe3431bcf"/>
							<gml:surfaceMember xlink:href="#poly-7df2f91d-7131-498c-857f-e9fc17058138"/>
							<gml:surfaceMember xlink:href="#poly-adfcdf1f-3d6c-4796-bfd5-8936e3075a8f"/>
							<gml:surfaceMember xlink:href="#poly-a32c6f5a-b5f7-485c-b5bf-27957dc31737"/>
							<gml:surfaceMember xlink:href="#poly-f98510ca-3b62-4282-ad27-17f8a386cf09"/>
							<gml:surfaceMember xlink:href="#poly-38b06134-40af-4704-b020-4e6d9d32cc46"/>
							<gml:surfaceMember xlink:href="#poly-3b9cf859-0dbd-4d79-a69b-43449df04f1e"/>
							<gml:surfaceMember xlink:href="#poly-53238810-72fc-4055-89cc-728ab47386bf"/>
							<gml:surfaceMember xlink:href="#poly-d8a1e53b-7a18-4dde-bb79-2ac8ec2cb5bb"/>
							<gml:surfaceMember xlink:href="#poly-ad1d7d3c-928e-465d-9eb3-febaacf7bfa0"/>
							<gml:surfaceMember xlink:href="#poly-e6eec944-d069-4dda-9934-95484be92979"/>
							<gml:surfaceMember xlink:href="#poly-3cb8ee6c-82ff-42ba-8d25-137d8ca54e21"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_688af926-dc31-4320-8208-9718f40755c4_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c4e3587-7b85-43c2-8405-3785f7fddf70">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67171724019644 139.73997864078797 38.588 35.67173142977459 139.73999280790164 38.588 35.67171535899965 139.7400169741369 38.588 35.6717011694243 139.7400028070218 38.588 35.67171724019644 139.73997864078797 38.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-09343171-1f82-43e8-b4c2-24c9a1a069e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-09343171-1f82-43e8-b4c2-24c9a1a069e1_0">
											<gml:posList>35.67171724019644 139.73997864078797 38.588 35.67171724019644 139.73997864078797 39.624 35.67173142977459 139.73999280790164 39.624 35.67173142977459 139.73999280790164 38.588 35.67171724019644 139.73997864078797 38.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30659c43-8ea7-4039-ac62-ee24bdf3944b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30659c43-8ea7-4039-ac62-ee24bdf3944b_0">
											<gml:posList>35.6717011694243 139.7400028070218 38.588 35.6717011694243 139.7400028070218 39.624 35.67171724019644 139.73997864078797 39.624 35.67171724019644 139.73997864078797 38.588 35.6717011694243 139.7400028070218 38.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-238dc618-ff8b-4ff5-920c-1259b3860794">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-238dc618-ff8b-4ff5-920c-1259b3860794_0">
											<gml:posList>35.67171724019644 139.73997864078797 39.624 35.6717011694243 139.7400028070218 39.624 35.67171535899965 139.7400169741369 39.624 35.67173142977459 139.73999280790164 39.624 35.67171724019644 139.73997864078797 39.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8aeae96c-eec5-4350-a0d6-1baedbe809c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8aeae96c-eec5-4350-a0d6-1baedbe809c5_0">
											<gml:posList>35.67173142977459 139.73999280790164 38.588 35.67173142977459 139.73999280790164 39.624 35.67171535899965 139.7400169741369 39.624 35.67171535899965 139.7400169741369 38.588 35.67173142977459 139.73999280790164 38.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7ea7d71e-46c7-4ee8-8053-6438500b0fdd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7ea7d71e-46c7-4ee8-8053-6438500b0fdd_0">
											<gml:posList>35.67171535899965 139.7400169741369 39.624 35.6717011694243 139.7400028070218 39.624 35.6717011694243 139.7400028070218 38.588 35.67171535899965 139.7400169741369 38.588 35.67171535899965 139.7400169741369 39.624</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_688af926-dc31-4320-8208-9718f40755c4_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da66f290-4534-4495-a9f3-1b1166d3e5f2">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.671680595395536 139.74005490388353 38.588 35.67167352315313 139.74004783134527 38.588 35.67167824985351 139.74004072298575 38.588 35.67168533110149 139.7400477844669 38.588 35.671680595395536 139.74005490388353 38.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-da68470b-85bc-444b-a39f-0eef7915740e">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67170201670369 139.7400958723053 41.674 35.67168708744787 139.7400809769739 41.674 35.67169413699507 139.7400703862844 41.674 35.67170905723847 139.74008528162562 41.674 35.67170201670369 139.7400958723053 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c766961-ee09-4293-a10e-fc34017f2c0f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c766961-ee09-4293-a10e-fc34017f2c0f_0">
											<gml:posList>35.67168533110149 139.7400477844669 38.588 35.67167824985351 139.74004072298575 38.588 35.67167824985351 139.74004072298575 39.594 35.67168533110149 139.7400477844669 39.594 35.67168533110149 139.7400477844669 38.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2073e7aa-d5aa-4de4-a5ff-cb1ca497525d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2073e7aa-d5aa-4de4-a5ff-cb1ca497525d_0">
											<gml:posList>35.67167824985351 139.74004072298575 38.588 35.67167352315313 139.74004783134527 38.588 35.67167352315313 139.74004783134527 39.594 35.67167824985351 139.74004072298575 39.594 35.67167824985351 139.74004072298575 38.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7b7a96ae-af83-4b30-9237-2ff5844fa668">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7b7a96ae-af83-4b30-9237-2ff5844fa668_0">
											<gml:posList>35.67167824985351 139.74004072298575 39.594 35.67167352315313 139.74004783134527 39.594 35.671680595395536 139.74005490388353 39.594 35.67168533110149 139.7400477844669 39.594 35.67167824985351 139.74004072298575 39.594</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7de1b8be-1164-47d9-99e7-d00f387e07ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7de1b8be-1164-47d9-99e7-d00f387e07ac_0">
											<gml:posList>35.671680595395536 139.74005490388353 38.588 35.67168533110149 139.7400477844669 38.588 35.67168533110149 139.7400477844669 39.594 35.671680595395536 139.74005490388353 39.594 35.671680595395536 139.74005490388353 38.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c69dcf6a-fa31-42fb-b00a-32964cd802d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c69dcf6a-fa31-42fb-b00a-32964cd802d1_0">
											<gml:posList>35.67167352315313 139.74004783134527 38.588 35.671680595395536 139.74005490388353 38.588 35.671680595395536 139.74005490388353 39.594 35.67167352315313 139.74004783134527 39.594 35.67167352315313 139.74004783134527 38.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d271bef7-b4a3-4791-ae48-b05eb8a53b62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d271bef7-b4a3-4791-ae48-b05eb8a53b62_0">
											<gml:posList>35.67169413699507 139.7400703862844 41.674 35.67168708744787 139.7400809769739 41.674 35.67168708744787 139.7400809769739 43.392 35.67169413699507 139.7400703862844 43.392 35.67169413699507 139.7400703862844 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b3c2bca-7c31-4c83-999b-230130772ff6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b3c2bca-7c31-4c83-999b-230130772ff6_0">
											<gml:posList>35.67169413699507 139.7400703862844 41.674 35.67169413699507 139.7400703862844 43.392 35.67170905723847 139.74008528162562 43.392 35.67170905723847 139.74008528162562 41.674 35.67169413699507 139.7400703862844 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-686d0108-f997-44c1-9882-9ad0ddd20d73">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-686d0108-f997-44c1-9882-9ad0ddd20d73_0">
											<gml:posList>35.67170201670369 139.7400958723053 43.392 35.67170905723847 139.74008528162562 43.392 35.67169413699507 139.7400703862844 43.392 35.67168708744787 139.7400809769739 43.392 35.67170201670369 139.7400958723053 43.392</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40c52ef6-949c-4959-824b-d1b9d912a1f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40c52ef6-949c-4959-824b-d1b9d912a1f8_0">
											<gml:posList>35.67168708744787 139.7400809769739 41.674 35.67170201670369 139.7400958723053 41.674 35.67170201670369 139.7400958723053 43.392 35.67168708744787 139.7400809769739 43.392 35.67168708744787 139.7400809769739 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-565406b3-cafb-4298-9279-567bb076f47a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-565406b3-cafb-4298-9279-567bb076f47a_0">
											<gml:posList>35.67170905723847 139.74008528162562 41.674 35.67170905723847 139.74008528162562 43.392 35.67170201670369 139.7400958723053 43.392 35.67170201670369 139.7400958723053 41.674 35.67170905723847 139.74008528162562 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-8d1ec925-7814-4cf3-a3be-5dc7eaa55894">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8d1ec925-7814-4cf3-a3be-5dc7eaa55894">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8d1ec925-7814-4cf3-a3be-5dc7eaa55894">
											<gml:posList>35.67170834921998 139.7401138154098 9.23 35.67159495895552 139.74000061091203 9.23 35.67165005859515 139.73991758804692 9.23 35.67166413096795 139.7399317110887 9.23 35.67167178363292 139.73992010341422 9.23 35.67177111070173 139.74001928423274 9.23 35.67170834921998 139.7401138154098 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b7027a8-a8bc-429a-be69-4d95c3ba81d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b7027a8-a8bc-429a-be69-4d95c3ba81d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b7027a8-a8bc-429a-be69-4d95c3ba81d7">
											<gml:posList>35.67160024949586 139.7399999419675 26.331 35.67159495895552 139.74000061091203 26.331 35.67162256232631 139.7400281727617 26.331 35.67162493917518 139.74002459095195 26.331 35.67160024949586 139.7399999419675 26.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ee6d9d4e-21b6-49c3-a147-b3a8d95f1a59">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ee6d9d4e-21b6-49c3-a147-b3a8d95f1a59">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ee6d9d4e-21b6-49c3-a147-b3a8d95f1a59">
											<gml:posList>35.67159495895552 139.74000061091203 26.331 35.67160024949586 139.7399999419675 26.331 35.67165059545214 139.73992409377126 26.331 35.67165005859515 139.73991758804692 26.331 35.67159495895552 139.74000061091203 26.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bca13c24-e689-471b-ad99-adccf6f9748e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bca13c24-e689-471b-ad99-adccf6f9748e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bca13c24-e689-471b-ad99-adccf6f9748e">
											<gml:posList>35.67160024949586 139.7399999419675 25.902 35.67162493917518 139.74002459095195 25.902 35.67168301002594 139.73993726754642 25.902 35.67167232950351 139.73992660912984 25.902 35.671664676846476 139.7399382278502 25.902 35.67165059545214 139.73992409377126 25.902 35.67160024949586 139.7399999419675 25.902</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e9912f4e-2bea-44f3-927f-e49a5cf654fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e9912f4e-2bea-44f3-927f-e49a5cf654fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e9912f4e-2bea-44f3-927f-e49a5cf654fa">
											<gml:posList>35.67166413096795 139.7399317110887 26.331 35.67165005859515 139.73991758804692 26.331 35.67165059545214 139.73992409377126 26.331 35.671664676846476 139.7399382278502 26.331 35.67166413096795 139.7399317110887 26.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-702ef7b8-5994-42c8-b458-1181f781f530">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-702ef7b8-5994-42c8-b458-1181f781f530">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-702ef7b8-5994-42c8-b458-1181f781f530">
											<gml:posList>35.67165656734061 139.74005819053744 39.125 35.671653070350715 139.74005862541685 39.125 35.67167324966712 139.74007877273505 39.125 35.671674816223714 139.74007640697522 39.125 35.67165656734061 139.74005819053744 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-59c6e4c1-490a-44eb-891c-7721ba5861b0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-59c6e4c1-490a-44eb-891c-7721ba5861b0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-59c6e4c1-490a-44eb-891c-7721ba5861b0">
											<gml:posList>35.67166413096795 139.7399317110887 26.331 35.671664676846476 139.7399382278502 26.331 35.67167232950351 139.73992660912984 26.331 35.67167178363292 139.73992010341422 26.331 35.67166413096795 139.7399317110887 26.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e28e4ba9-8a30-4dd6-bcd4-ac75dae98d10">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e28e4ba9-8a30-4dd6-bcd4-ac75dae98d10">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e28e4ba9-8a30-4dd6-bcd4-ac75dae98d10">
											<gml:posList>35.67171588590631 139.73996413838472 39.125 35.67168538687207 139.73993368573124 31.495 35.67162256232631 139.7400281727617 31.495 35.671653070350715 139.74005862541685 39.125 35.67171588590631 139.73996413838472 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1cba873e-7fd0-4657-850d-87ca842b46fb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1cba873e-7fd0-4657-850d-87ca842b46fb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1cba873e-7fd0-4657-850d-87ca842b46fb">
											<gml:posList>35.67167232950351 139.73992660912984 26.331 35.67168301002594 139.73993726754642 26.331 35.67168538687207 139.73993368573124 26.331 35.67167178363292 139.73992010341422 26.331 35.67167232950351 139.73992660912984 26.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-41120ed3-82c9-4d69-8179-346638f9a608">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41120ed3-82c9-4d69-8179-346638f9a608">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41120ed3-82c9-4d69-8179-346638f9a608">
											<gml:posList>35.671653070350715 139.74005862541685 39.125 35.67165656734061 139.74005819053744 39.125 35.67171624076479 139.7399684239915 39.125 35.67171588590631 139.73996413838472 39.125 35.671653070350715 139.74005862541685 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-926bb28f-c776-4394-9e88-fdfd91b5a2b8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-926bb28f-c776-4394-9e88-fdfd91b5a2b8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-926bb28f-c776-4394-9e88-fdfd91b5a2b8">
											<gml:posList>35.67167324966712 139.74007877273505 41.854 35.671677305447886 139.74007825988141 41.854 35.671700812907936 139.74004290601894 41.854 35.671700394416845 139.74003792456085 41.854 35.67167324966712 139.74007877273505 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c2d4ed05-041b-4078-8531-610ae8c99207">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c2d4ed05-041b-4078-8531-610ae8c99207">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c2d4ed05-041b-4078-8531-610ae8c99207">
											<gml:posList>35.67170834921998 139.7401138154098 41.854 35.671707930740396 139.74010884499734 41.854 35.671677305447886 139.74007825988141 41.854 35.67167324966712 139.74007877273505 41.854 35.67170834921998 139.7401138154098 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8b218228-97cd-4b64-ae9a-21600f58c3f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b218228-97cd-4b64-ae9a-21600f58c3f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b218228-97cd-4b64-ae9a-21600f58c3f3">
											<gml:posList>35.671700394416845 139.74003792456085 38.588 35.67172363174954 139.74006111714667 38.588 35.671728700544186 139.7400534560632 38.588 35.67172446081795 139.74004923020775 38.588 35.67175312645317 139.7400052540821 38.588 35.67171624076479 139.7399684239915 38.588 35.67165656734061 139.74005819053744 38.588 35.671674816223714 139.74007640697522 38.588 35.671700394416845 139.74003792456085 38.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-44570e09-78a9-4880-b478-9dae1e3330a1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-44570e09-78a9-4880-b478-9dae1e3330a1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-44570e09-78a9-4880-b478-9dae1e3330a1">
											<gml:posList>35.671707930740396 139.74010884499734 41.674 35.67173806454729 139.7400634642954 41.674 35.67173066757191 139.74005608282863 41.674 35.671724041234505 139.7400661096632 41.674 35.671700812907936 139.74004290601894 41.674 35.671677305447886 139.74007825988141 41.674 35.671707930740396 139.74010884499734 41.674</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1077f7c-f084-4a61-afbd-3674db7e63ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1077f7c-f084-4a61-afbd-3674db7e63ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1077f7c-f084-4a61-afbd-3674db7e63ca">
											<gml:posList>35.67172363174954 139.74006111714667 41.854 35.671700394416845 139.74003792456085 41.854 35.671700812907936 139.74004290601894 41.854 35.671724041234505 139.7400661096632 41.854 35.67172363174954 139.74006111714667 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8c6a8335-6245-4e2c-8641-561b510657f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8c6a8335-6245-4e2c-8641-561b510657f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8c6a8335-6245-4e2c-8641-561b510657f0">
											<gml:posList>35.67174212933311 139.7400629403836 41.854 35.67173806454729 139.7400634642954 41.854 35.671707930740396 139.74010884499734 41.854 35.67170834921998 139.7401138154098 41.854 35.67174212933311 139.7400629403836 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f4e0d777-eb39-48cf-9285-4e549940f3c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f4e0d777-eb39-48cf-9285-4e549940f3c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f4e0d777-eb39-48cf-9285-4e549940f3c7">
											<gml:posList>35.67172363174954 139.74006111714667 41.854 35.671724041234505 139.7400661096632 41.854 35.67173066757191 139.74005608282863 41.854 35.67173025809509 139.74005110135815 41.854 35.67172363174954 139.74006111714667 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-22083be1-7f85-4362-98a6-f939b1cfdcd3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22083be1-7f85-4362-98a6-f939b1cfdcd3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22083be1-7f85-4362-98a6-f939b1cfdcd3">
											<gml:posList>35.671728700544186 139.7400534560632 39.125 35.67173025809509 139.74005110135815 39.125 35.67172793074949 139.74004877326612 39.125 35.67172446081795 139.74004923020775 39.125 35.671728700544186 139.7400534560632 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b917406d-98ca-4864-ace1-75c7e6a1b316">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b917406d-98ca-4864-ace1-75c7e6a1b316">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b917406d-98ca-4864-ace1-75c7e6a1b316">
											<gml:posList>35.67173025809509 139.74005110135815 41.854 35.67173066757191 139.74005608282863 41.854 35.67173806454729 139.7400634642954 41.854 35.67174212933311 139.7400629403836 41.854 35.67173025809509 139.74005110135815 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2c02130a-fe08-43ae-91b1-06e3f9f41c4a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c02130a-fe08-43ae-91b1-06e3f9f41c4a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c02130a-fe08-43ae-91b1-06e3f9f41c4a">
											<gml:posList>35.67171588590631 139.73996413838472 39.125 35.67171624076479 139.7399684239915 39.125 35.67175312645317 139.7400052540821 39.125 35.67175659637597 139.740004786092 39.125 35.67171588590631 139.73996413838472 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bd629ebf-f4bb-4f87-b9dd-00d9349b0a5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd629ebf-f4bb-4f87-b9dd-00d9349b0a5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd629ebf-f4bb-4f87-b9dd-00d9349b0a5c">
											<gml:posList>35.67172793074949 139.74004877326612 39.125 35.67175659637597 139.740004786092 39.125 35.67175312645317 139.7400052540821 39.125 35.67172446081795 139.74004923020775 39.125 35.67172793074949 139.74004877326612 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-10a11a16-f600-4f8b-ba05-22ed88b5a5ca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-10a11a16-f600-4f8b-ba05-22ed88b5a5ca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-10a11a16-f600-4f8b-ba05-22ed88b5a5ca">
											<gml:posList>35.67172793074949 139.74004877326612 23.018 35.67174212933311 139.7400629403836 23.018 35.67177111070173 139.74001928423274 23.018 35.67175659637597 139.740004786092 23.018 35.67172793074949 139.74004877326612 23.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e1cbab1-9856-4554-b826-644098d77888">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e1cbab1-9856-4554-b826-644098d77888">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e1cbab1-9856-4554-b826-644098d77888">
											<gml:posList>35.671700812907936 139.74004290601894 41.854 35.671700812907936 139.74004290601894 41.674 35.671724041234505 139.7400661096632 41.674 35.671724041234505 139.7400661096632 41.854 35.671700812907936 139.74004290601894 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a684fbd9-ae99-48bd-8269-a195b757942b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a684fbd9-ae99-48bd-8269-a195b757942b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a684fbd9-ae99-48bd-8269-a195b757942b">
											<gml:posList>35.671724041234505 139.7400661096632 41.854 35.671724041234505 139.7400661096632 41.674 35.67173066757191 139.74005608282863 41.674 35.67173066757191 139.74005608282863 41.854 35.671724041234505 139.7400661096632 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2020f8a9-6cc8-4822-89b0-904dc8237059">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2020f8a9-6cc8-4822-89b0-904dc8237059">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2020f8a9-6cc8-4822-89b0-904dc8237059">
											<gml:posList>35.67166413096795 139.7399317110887 9.23 35.67165005859515 139.73991758804692 9.23 35.67165005859515 139.73991758804692 26.331 35.67166413096795 139.7399317110887 26.331 35.67166413096795 139.7399317110887 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b39fb7b9-cc48-4b97-a5bf-ac85441cc406">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b39fb7b9-cc48-4b97-a5bf-ac85441cc406">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b39fb7b9-cc48-4b97-a5bf-ac85441cc406">
											<gml:posList>35.67167178363292 139.73992010341422 9.23 35.67166413096795 139.7399317110887 9.23 35.67166413096795 139.7399317110887 26.331 35.67167178363292 139.73992010341422 26.331 35.67167178363292 139.73992010341422 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b09b5c29-26e6-43d3-986d-c30680f19d92">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b09b5c29-26e6-43d3-986d-c30680f19d92">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b09b5c29-26e6-43d3-986d-c30680f19d92">
											<gml:posList>35.67165059545214 139.73992409377126 26.331 35.67165059545214 139.73992409377126 25.902 35.671664676846476 139.7399382278502 25.902 35.671664676846476 139.7399382278502 26.331 35.67165059545214 139.73992409377126 26.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b2b68085-783d-4d7d-9048-4901e9b1e303">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b2b68085-783d-4d7d-9048-4901e9b1e303">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b2b68085-783d-4d7d-9048-4901e9b1e303">
											<gml:posList>35.67167232950351 139.73992660912984 26.331 35.67167232950351 139.73992660912984 25.902 35.67168301002594 139.73993726754642 25.902 35.67168301002594 139.73993726754642 26.331 35.67167232950351 139.73992660912984 26.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7b1ddf1-e397-43f7-85a0-46d03fd98150">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7b1ddf1-e397-43f7-85a0-46d03fd98150">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7b1ddf1-e397-43f7-85a0-46d03fd98150">
											<gml:posList>35.671664676846476 139.7399382278502 26.331 35.671664676846476 139.7399382278502 25.902 35.67167232950351 139.73992660912984 25.902 35.67167232950351 139.73992660912984 26.331 35.671664676846476 139.7399382278502 26.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ce059a0e-df41-48bf-9aa0-d7153a35a3ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce059a0e-df41-48bf-9aa0-d7153a35a3ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce059a0e-df41-48bf-9aa0-d7153a35a3ee">
											<gml:posList>35.67165005859515 139.73991758804692 9.23 35.67159495895552 139.74000061091203 9.23 35.67159495895552 139.74000061091203 26.331 35.67165005859515 139.73991758804692 26.331 35.67165005859515 139.73991758804692 9.23</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6d1bc6e0-b47b-4291-8d47-e7559818cac1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6d1bc6e0-b47b-4291-8d47-e7559818cac1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6d1bc6e0-b47b-4291-8d47-e7559818cac1">
											<gml:posList>35.67160024949586 139.7399999419675 26.331 35.67160024949586 139.7399999419675 25.902 35.67165059545214 139.73992409377126 25.902 35.67165059545214 139.73992409377126 26.331 35.67160024949586 139.7399999419675 26.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9d8e205a-6479-4f59-ac93-693f2d9ae58f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9d8e205a-6479-4f59-ac93-693f2d9ae58f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9d8e205a-6479-4f59-ac93-693f2d9ae58f">
											<gml:posList>35.67171588590631 139.73996413838472 39.125 35.67175659637597 139.740004786092 39.125 35.67175659637597 139.740004786092 23.018 35.67177111070173 139.74001928423274 23.018 35.67177111070173 139.74001928423274 9.23 35.67167178363292 139.73992010341422 9.23 35.67167178363292 139.73992010341422 26.331 35.67168538687207 139.73993368573124 26.331 35.67168538687207 139.73993368573124 31.495 35.67171588590631 139.73996413838472 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-093d9176-ebd8-421d-8038-9fa2ced6e515">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-093d9176-ebd8-421d-8038-9fa2ced6e515">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-093d9176-ebd8-421d-8038-9fa2ced6e515">
											<gml:posList>35.67162256232631 139.7400281727617 31.495 35.67168538687207 139.73993368573124 31.495 35.67168538687207 139.73993368573124 26.331 35.67168301002594 139.73993726754642 26.331 35.67168301002594 139.73993726754642 25.902 35.67162493917518 139.74002459095195 25.902 35.67162493917518 139.74002459095195 26.331 35.67162256232631 139.7400281727617 26.331 35.67162256232631 139.7400281727617 31.495</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef246cea-00d7-4ef2-84bc-10936171ed24">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef246cea-00d7-4ef2-84bc-10936171ed24">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef246cea-00d7-4ef2-84bc-10936171ed24">
											<gml:posList>35.67171624076479 139.7399684239915 39.125 35.67171624076479 139.7399684239915 38.588 35.67175312645317 139.7400052540821 38.588 35.67175312645317 139.7400052540821 39.125 35.67171624076479 139.7399684239915 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16b88fd3-c4fc-423f-b0c1-12a542ff03be">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16b88fd3-c4fc-423f-b0c1-12a542ff03be">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16b88fd3-c4fc-423f-b0c1-12a542ff03be">
											<gml:posList>35.67162493917518 139.74002459095195 26.331 35.67162493917518 139.74002459095195 25.902 35.67160024949586 139.7399999419675 25.902 35.67160024949586 139.7399999419675 26.331 35.67162493917518 139.74002459095195 26.331</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8253e2ab-c975-4499-93f7-f83a7ddfa6d3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8253e2ab-c975-4499-93f7-f83a7ddfa6d3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8253e2ab-c975-4499-93f7-f83a7ddfa6d3">
											<gml:posList>35.67165656734061 139.74005819053744 39.125 35.67165656734061 139.74005819053744 38.588 35.67171624076479 139.7399684239915 38.588 35.67171624076479 139.7399684239915 39.125 35.67165656734061 139.74005819053744 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8100fbc9-f4ef-4708-b24d-ac991c2d3998">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8100fbc9-f4ef-4708-b24d-ac991c2d3998">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8100fbc9-f4ef-4708-b24d-ac991c2d3998">
											<gml:posList>35.67175659637597 139.740004786092 23.018 35.67175659637597 139.740004786092 39.125 35.67172793074949 139.74004877326612 39.125 35.67172793074949 139.74004877326612 23.018 35.67175659637597 139.740004786092 23.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f5e50da7-1c1f-442c-897e-3409d69411f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f5e50da7-1c1f-442c-897e-3409d69411f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f5e50da7-1c1f-442c-897e-3409d69411f9">
											<gml:posList>35.67175312645317 139.7400052540821 39.125 35.67175312645317 139.7400052540821 38.588 35.67172446081795 139.74004923020775 38.588 35.67172446081795 139.74004923020775 39.125 35.67175312645317 139.7400052540821 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-95e48bb0-546a-47a1-9f11-38abe3431bcf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-95e48bb0-546a-47a1-9f11-38abe3431bcf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-95e48bb0-546a-47a1-9f11-38abe3431bcf">
											<gml:posList>35.671700394416845 139.74003792456085 41.854 35.67172363174954 139.74006111714667 41.854 35.67172363174954 139.74006111714667 38.588 35.671700394416845 139.74003792456085 38.588 35.671700394416845 139.74003792456085 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7df2f91d-7131-498c-857f-e9fc17058138">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7df2f91d-7131-498c-857f-e9fc17058138">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7df2f91d-7131-498c-857f-e9fc17058138">
											<gml:posList>35.67172446081795 139.74004923020775 39.125 35.67172446081795 139.74004923020775 38.588 35.671728700544186 139.7400534560632 38.588 35.671728700544186 139.7400534560632 39.125 35.67172446081795 139.74004923020775 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-adfcdf1f-3d6c-4796-bfd5-8936e3075a8f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-adfcdf1f-3d6c-4796-bfd5-8936e3075a8f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-adfcdf1f-3d6c-4796-bfd5-8936e3075a8f">
											<gml:posList>35.67173025809509 139.74005110135815 39.125 35.67173025809509 139.74005110135815 41.854 35.67174212933311 139.7400629403836 41.854 35.67174212933311 139.7400629403836 23.018 35.67172793074949 139.74004877326612 23.018 35.67172793074949 139.74004877326612 39.125 35.67173025809509 139.74005110135815 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a32c6f5a-b5f7-485c-b5bf-27957dc31737">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a32c6f5a-b5f7-485c-b5bf-27957dc31737">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a32c6f5a-b5f7-485c-b5bf-27957dc31737">
											<gml:posList>35.67172363174954 139.74006111714667 38.588 35.67172363174954 139.74006111714667 41.854 35.67173025809509 139.74005110135815 41.854 35.67173025809509 139.74005110135815 39.125 35.671728700544186 139.7400534560632 39.125 35.671728700544186 139.7400534560632 38.588 35.67172363174954 139.74006111714667 38.588</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f98510ca-3b62-4282-ad27-17f8a386cf09">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f98510ca-3b62-4282-ad27-17f8a386cf09">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f98510ca-3b62-4282-ad27-17f8a386cf09">
											<gml:posList>35.67167324966712 139.74007877273505 39.125 35.671653070350715 139.74005862541685 39.125 35.67162256232631 139.7400281727617 31.495 35.67162256232631 139.7400281727617 26.331 35.67159495895552 139.74000061091203 26.331 35.67159495895552 139.74000061091203 9.23 35.67170834921998 139.7401138154098 9.23 35.67170834921998 139.7401138154098 41.854 35.67167324966712 139.74007877273505 41.854 35.67167324966712 139.74007877273505 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38b06134-40af-4704-b020-4e6d9d32cc46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38b06134-40af-4704-b020-4e6d9d32cc46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38b06134-40af-4704-b020-4e6d9d32cc46">
											<gml:posList>35.671674816223714 139.74007640697522 39.125 35.67167324966712 139.74007877273505 39.125 35.67167324966712 139.74007877273505 41.854 35.671700394416845 139.74003792456085 41.854 35.671700394416845 139.74003792456085 38.588 35.671674816223714 139.74007640697522 38.588 35.671674816223714 139.74007640697522 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3b9cf859-0dbd-4d79-a69b-43449df04f1e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3b9cf859-0dbd-4d79-a69b-43449df04f1e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3b9cf859-0dbd-4d79-a69b-43449df04f1e">
											<gml:posList>35.67173066757191 139.74005608282863 41.854 35.67173066757191 139.74005608282863 41.674 35.67173806454729 139.7400634642954 41.674 35.67173806454729 139.7400634642954 41.854 35.67173066757191 139.74005608282863 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53238810-72fc-4055-89cc-728ab47386bf">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53238810-72fc-4055-89cc-728ab47386bf">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53238810-72fc-4055-89cc-728ab47386bf">
											<gml:posList>35.671677305447886 139.74007825988141 41.854 35.671677305447886 139.74007825988141 41.674 35.671700812907936 139.74004290601894 41.674 35.671700812907936 139.74004290601894 41.854 35.671677305447886 139.74007825988141 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d8a1e53b-7a18-4dde-bb79-2ac8ec2cb5bb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8a1e53b-7a18-4dde-bb79-2ac8ec2cb5bb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8a1e53b-7a18-4dde-bb79-2ac8ec2cb5bb">
											<gml:posList>35.67174212933311 139.7400629403836 23.018 35.67174212933311 139.7400629403836 41.854 35.67170834921998 139.7401138154098 41.854 35.67170834921998 139.7401138154098 9.23 35.67177111070173 139.74001928423274 9.23 35.67177111070173 139.74001928423274 23.018 35.67174212933311 139.7400629403836 23.018</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ad1d7d3c-928e-465d-9eb3-febaacf7bfa0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ad1d7d3c-928e-465d-9eb3-febaacf7bfa0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ad1d7d3c-928e-465d-9eb3-febaacf7bfa0">
											<gml:posList>35.671674816223714 139.74007640697522 39.125 35.671674816223714 139.74007640697522 38.588 35.67165656734061 139.74005819053744 38.588 35.67165656734061 139.74005819053744 39.125 35.671674816223714 139.74007640697522 39.125</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e6eec944-d069-4dda-9934-95484be92979">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e6eec944-d069-4dda-9934-95484be92979">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e6eec944-d069-4dda-9934-95484be92979">
											<gml:posList>35.67173806454729 139.7400634642954 41.854 35.67173806454729 139.7400634642954 41.674 35.671707930740396 139.74010884499734 41.674 35.671707930740396 139.74010884499734 41.854 35.67173806454729 139.7400634642954 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3cb8ee6c-82ff-42ba-8d25-137d8ca54e21">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3cb8ee6c-82ff-42ba-8d25-137d8ca54e21">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3cb8ee6c-82ff-42ba-8d25-137d8ca54e21">
											<gml:posList>35.671707930740396 139.74010884499734 41.854 35.671707930740396 139.74010884499734 41.674 35.671677305447886 139.74007825988141 41.674 35.671677305447886 139.74007825988141 41.854 35.671707930740396 139.74010884499734 41.854</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4831</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">165.29535</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>