<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_68be6f74-7b55-4bdd-b23b-252669e5a822">
			<core:creationDate>2024-03-15</core:creationDate>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.673147525244225 139.74645239473907 0 35.67316481916142 139.74644764803386 0 35.6731821040646 139.74644290133634 0 35.67317408622979 139.74639902170588 0 35.67315680132033 139.74640375736575 0 35.673139516418594 139.7464085040702 0 35.673147525244225 139.74645239473907 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673147525244225 139.74645239473907 11.93 35.673139516418594 139.7464085040702 11.93 35.67315680132033 139.74640375736575 11.93 35.67317408622979 139.74639902170588 11.93 35.6731821040646 139.74644290133634 11.93 35.67316481916142 139.74644764803386 11.93 35.673147525244225 139.74645239473907 11.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673147525244225 139.74645239473907 11.93 35.67316481916142 139.74644764803386 11.93 35.67316481916142 139.74644764803386 14.93 35.673147525244225 139.74645239473907 14.93 35.673147525244225 139.74645239473907 11.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67316481916142 139.74644764803386 11.93 35.6731821040646 139.74644290133634 11.93 35.6731821040646 139.74644290133634 14.93 35.67316481916142 139.74644764803386 14.93 35.67316481916142 139.74644764803386 11.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6731821040646 139.74644290133634 11.93 35.67317408622979 139.74639902170588 11.93 35.67317408622979 139.74639902170588 14.93 35.6731821040646 139.74644290133634 14.93 35.6731821040646 139.74644290133634 11.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67317408622979 139.74639902170588 11.93 35.67315680132033 139.74640375736575 11.93 35.67315680132033 139.74640375736575 14.93 35.67317408622979 139.74639902170588 14.93 35.67317408622979 139.74639902170588 11.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67315680132033 139.74640375736575 11.93 35.673139516418594 139.7464085040702 11.93 35.673139516418594 139.7464085040702 14.93 35.67315680132033 139.74640375736575 14.93 35.67315680132033 139.74640375736575 11.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673139516418594 139.7464085040702 11.93 35.673147525244225 139.74645239473907 11.93 35.673147525244225 139.74645239473907 14.93 35.673139516418594 139.7464085040702 14.93 35.673139516418594 139.7464085040702 11.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.673147525244225 139.74645239473907 14.93 35.67316481916142 139.74644764803386 14.93 35.6731821040646 139.74644290133634 14.93 35.67317408622979 139.74639902170588 14.93 35.67315680132033 139.74640375736575 14.93 35.673139516418594 139.7464085040702 14.93 35.673147525244225 139.74645239473907 14.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-996e6ea3-a81d-4463-879d-046731d057c4"/>
							<gml:surfaceMember xlink:href="#poly-beed5c43-8238-4c8d-9257-9dba10680fe6"/>
							<gml:surfaceMember xlink:href="#poly-945326a6-0038-4c5d-bc9c-9eec3015987b"/>
							<gml:surfaceMember xlink:href="#poly-60318819-68c8-4bc0-a7f2-dd1372595864"/>
							<gml:surfaceMember xlink:href="#poly-bf541a90-57af-4c09-a7b6-af16d3d537d4"/>
							<gml:surfaceMember xlink:href="#poly-755d9991-58f9-43a6-9906-ca8cc57ca810"/>
							<gml:surfaceMember xlink:href="#poly-08061e20-6edf-4e2d-bb5d-84c09993f463"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-996e6ea3-a81d-4463-879d-046731d057c4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-996e6ea3-a81d-4463-879d-046731d057c4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-996e6ea3-a81d-4463-879d-046731d057c4">
											<gml:posList>35.673182104064594 139.74644290133634 11.93 35.67314752524421 139.7464523947391 11.93 35.67313950740486 139.74640850407997 11.93 35.673174095243496 139.74639902169608 11.93 35.673182104064594 139.74644290133634 11.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-beed5c43-8238-4c8d-9257-9dba10680fe6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-beed5c43-8238-4c8d-9257-9dba10680fe6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-beed5c43-8238-4c8d-9257-9dba10680fe6">
											<gml:posList>35.673164819161386 139.74644764803384 13.993 35.673182104064594 139.74644290133634 13.643 35.673174095243496 139.74639902169608 13.643 35.67315680132031 139.74640375736573 13.993 35.673164819161386 139.74644764803384 13.993</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-945326a6-0038-4c5d-bc9c-9eec3015987b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-945326a6-0038-4c5d-bc9c-9eec3015987b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-945326a6-0038-4c5d-bc9c-9eec3015987b">
											<gml:posList>35.67313950740486 139.74640850407997 13.643 35.67314752524421 139.7464523947391 13.643 35.673164819161386 139.74644764803384 13.993 35.67315680132031 139.74640375736573 13.993 35.67313950740486 139.74640850407997 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-60318819-68c8-4bc0-a7f2-dd1372595864">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60318819-68c8-4bc0-a7f2-dd1372595864">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60318819-68c8-4bc0-a7f2-dd1372595864">
											<gml:posList>35.67313950740486 139.74640850407997 11.93 35.67313950740486 139.74640850407997 13.643 35.67315680132031 139.74640375736573 13.993 35.673174095243496 139.74639902169608 13.643 35.673174095243496 139.74639902169608 11.93 35.67313950740486 139.74640850407997 11.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bf541a90-57af-4c09-a7b6-af16d3d537d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bf541a90-57af-4c09-a7b6-af16d3d537d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bf541a90-57af-4c09-a7b6-af16d3d537d4">
											<gml:posList>35.673182104064594 139.74644290133634 13.643 35.673182104064594 139.74644290133634 11.93 35.673174095243496 139.74639902169608 11.93 35.673174095243496 139.74639902169608 13.643 35.673182104064594 139.74644290133634 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-755d9991-58f9-43a6-9906-ca8cc57ca810">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-755d9991-58f9-43a6-9906-ca8cc57ca810">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-755d9991-58f9-43a6-9906-ca8cc57ca810">
											<gml:posList>35.67313950740486 139.74640850407997 13.643 35.67313950740486 139.74640850407997 11.93 35.67314752524421 139.7464523947391 11.93 35.67314752524421 139.7464523947391 13.643 35.67313950740486 139.74640850407997 13.643</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-08061e20-6edf-4e2d-bb5d-84c09993f463">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-08061e20-6edf-4e2d-bb5d-84c09993f463">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-08061e20-6edf-4e2d-bb5d-84c09993f463">
											<gml:posList>35.673182104064594 139.74644290133634 11.93 35.673182104064594 139.74644290133634 13.643 35.673164819161386 139.74644764803384 13.993 35.67314752524421 139.7464523947391 13.643 35.67314752524421 139.7464523947391 11.93 35.673182104064594 139.74644290133634 11.93</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13101-bldg-4533</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13101</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">224</uro:landUseType>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>5</uro:specifiedFloorAreaRate>
					<uro:surveyYear>0001</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.05</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">0</uro:lod1HeightType>
					<uro:lodType>2.0</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>