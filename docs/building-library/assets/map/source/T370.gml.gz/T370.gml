<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_69fe83a2-7325-4b22-8fd7-78ad9bf95967">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">17.7</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.672988969588026 139.73797789868522 0 35.67290351621277 139.7380193367277 0 35.67292185855611 139.7380755421623 0 35.67300668160229 139.73803487818296 0 35.672988969588026 139.73797789868522 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672988969588026 139.73797789868522 8.53 35.67300668160229 139.73803487818296 8.53 35.67292185855611 139.7380755421623 8.53 35.67290351621277 139.7380193367277 8.53 35.672988969588026 139.73797789868522 8.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672988969588026 139.73797789868522 8.53 35.67290351621277 139.7380193367277 8.53 35.67290351621277 139.7380193367277 26.260000000000005 35.672988969588026 139.73797789868522 26.260000000000005 35.672988969588026 139.73797789868522 8.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67290351621277 139.7380193367277 8.53 35.67292185855611 139.7380755421623 8.53 35.67292185855611 139.7380755421623 26.260000000000005 35.67290351621277 139.7380193367277 26.260000000000005 35.67290351621277 139.7380193367277 8.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67292185855611 139.7380755421623 8.53 35.67300668160229 139.73803487818296 8.53 35.67300668160229 139.73803487818296 26.260000000000005 35.67292185855611 139.7380755421623 26.260000000000005 35.67292185855611 139.7380755421623 8.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67300668160229 139.73803487818296 8.53 35.672988969588026 139.73797789868522 8.53 35.672988969588026 139.73797789868522 26.260000000000005 35.67300668160229 139.73803487818296 26.260000000000005 35.67300668160229 139.73803487818296 8.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672988969588026 139.73797789868522 26.260000000000005 35.67290351621277 139.7380193367277 26.260000000000005 35.67292185855611 139.7380755421623 26.260000000000005 35.67300668160229 139.73803487818296 26.260000000000005 35.672988969588026 139.73797789868522 26.260000000000005</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-4eda7755-c576-4058-bda0-8ab78169e41c"/>
							<gml:surfaceMember xlink:href="#poly-9a18056c-e237-4e74-8dd3-368024a25d5c"/>
							<gml:surfaceMember xlink:href="#poly-6cefc845-f3ce-454a-9e5d-3c42300f46fa"/>
							<gml:surfaceMember xlink:href="#poly-ff01603c-28a0-4742-95c7-b1a08c76fc94"/>
							<gml:surfaceMember xlink:href="#poly-4cd7c626-c876-4f91-9e62-6e277487c444"/>
							<gml:surfaceMember xlink:href="#poly-06ed9ae6-cf9f-4c95-803e-52adbb472865"/>
							<gml:surfaceMember xlink:href="#poly-c9c02012-92fd-40c9-a2e3-9fb7952109f2"/>
							<gml:surfaceMember xlink:href="#poly-0ed227d8-c7f6-4be2-b211-e5653716973b"/>
							<gml:surfaceMember xlink:href="#poly-c244b19f-1b9d-480c-8665-d24422cf28de"/>
							<gml:surfaceMember xlink:href="#poly-f447f22b-07c8-4f80-9549-6061cba0346c"/>
							<gml:surfaceMember xlink:href="#poly-531b9f8a-9ddf-4190-b522-d791f6dab224"/>
							<gml:surfaceMember xlink:href="#poly-2dc9b965-5cd9-46c0-99f8-749a897bbd3f"/>
							<gml:surfaceMember xlink:href="#poly-535762f5-396b-4d49-b2d3-fbf0efe181f3"/>
							<gml:surfaceMember xlink:href="#poly-2dcf442f-0ec3-47a4-8a93-fd5ca7f5425e"/>
							<gml:surfaceMember xlink:href="#poly-22975bec-1368-4958-8811-48489cdb8058"/>
							<gml:surfaceMember xlink:href="#poly-c0783010-dbf7-4936-9da5-ef61e30a261d"/>
							<gml:surfaceMember xlink:href="#poly-d553df54-23a8-4cb7-aa96-36cb88524387"/>
							<gml:surfaceMember xlink:href="#poly-2d1f889d-93c8-446c-868e-b7db6e9a16cc"/>
							<gml:surfaceMember xlink:href="#poly-9de22fd2-4771-4c65-a28c-eb5d1255b3c9"/>
							<gml:surfaceMember xlink:href="#poly-8b301771-04ec-40f3-86de-68b0ec4af0c8"/>
							<gml:surfaceMember xlink:href="#poly-f15dbc84-6494-4ef4-bfe0-ddf4e30cc75e"/>
							<gml:surfaceMember xlink:href="#poly-faaa9c16-24b3-4ed5-b5ad-775d2f80b10e"/>
							<gml:surfaceMember xlink:href="#poly-50d2cf20-c43c-4685-89d0-dff38dd22ba6"/>
							<gml:surfaceMember xlink:href="#poly-5cc39610-c5c5-4399-afd5-a436594ef26c"/>
							<gml:surfaceMember xlink:href="#poly-b3fa634f-6b16-4d9b-b9d5-079fd2c114e6"/>
							<gml:surfaceMember xlink:href="#poly-b786f796-4884-45fa-a029-80669a2b9329"/>
							<gml:surfaceMember xlink:href="#poly-0a8a6808-aad7-4da8-b98b-4a2c305cf684"/>
							<gml:surfaceMember xlink:href="#poly-6a2b14e3-4d21-4656-9813-34e552a60335"/>
							<gml:surfaceMember xlink:href="#poly-5e19e5eb-1904-46d2-92ab-5e95ec9e140e"/>
							<gml:surfaceMember xlink:href="#poly-ac715b43-defd-4ba1-8766-d323b1f54f86"/>
							<gml:surfaceMember xlink:href="#poly-25cf4083-a5d7-485b-915f-ddd79b50e41e"/>
							<gml:surfaceMember xlink:href="#poly-d652a385-32d9-4539-819b-c000573ecd31"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_69fe83a2-7325-4b22-8fd7-78ad9bf95967_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-866921fa-a382-4f24-89a6-7c9f1c00ac24">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.672968364353835 139.7380122339821 26.977 35.672974056794544 139.73802965877482 26.977 35.672960370254906 139.7380363692935 26.977 35.67295467781515 139.73801894450327 26.977 35.672968364353835 139.7380122339821 26.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6ffeb560-1fce-4d4d-91e1-451900f1f20e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6ffeb560-1fce-4d4d-91e1-451900f1f20e_0">
											<gml:posList>35.672960370254906 139.7380363692935 26.977 35.672960370254906 139.7380363692935 28.568 35.67295467781515 139.73801894450327 28.568 35.67295467781515 139.73801894450327 26.977 35.672960370254906 139.7380363692935 26.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-45cc8fe5-9684-45bc-9a7a-939d8f6a18b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-45cc8fe5-9684-45bc-9a7a-939d8f6a18b1_0">
											<gml:posList>35.67295467781515 139.73801894450327 26.977 35.67295467781515 139.73801894450327 28.568 35.672968364353835 139.7380122339821 28.568 35.672968364353835 139.7380122339821 26.977 35.67295467781515 139.73801894450327 26.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e6cd3b7e-af58-4fd9-9c1c-46034a718dcc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e6cd3b7e-af58-4fd9-9c1c-46034a718dcc_0">
											<gml:posList>35.672968364353835 139.7380122339821 28.568 35.67295467781515 139.73801894450327 28.568 35.672960370254906 139.7380363692935 28.568 35.672974056794544 139.73802965877482 28.568 35.672968364353835 139.7380122339821 28.568</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a41ad663-90a4-49ba-bbb0-b460315561f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a41ad663-90a4-49ba-bbb0-b460315561f0_0">
											<gml:posList>35.672974056794544 139.73802965877482 26.977 35.672974056794544 139.73802965877482 28.568 35.672960370254906 139.7380363692935 28.568 35.672960370254906 139.7380363692935 26.977 35.672974056794544 139.73802965877482 26.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78c23535-d8ea-49d0-bb23-6a77e5b93f0d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78c23535-d8ea-49d0-bb23-6a77e5b93f0d_0">
											<gml:posList>35.672968364353835 139.7380122339821 26.977 35.672968364353835 139.7380122339821 28.568 35.672974056794544 139.73802965877482 28.568 35.672974056794544 139.73802965877482 26.977 35.672968364353835 139.7380122339821 26.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-4eda7755-c576-4058-bda0-8ab78169e41c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4eda7755-c576-4058-bda0-8ab78169e41c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4eda7755-c576-4058-bda0-8ab78169e41c">
											<gml:posList>35.672988969588005 139.73797789868522 8.53 35.67300668160225 139.73803487818296 8.53 35.67292185855611 139.7380755421623 8.53 35.672903516212756 139.7380193367277 8.53 35.672988969588005 139.73797789868522 8.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9a18056c-e237-4e74-8dd3-368024a25d5c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9a18056c-e237-4e74-8dd3-368024a25d5c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9a18056c-e237-4e74-8dd3-368024a25d5c">
											<gml:posList>35.672921000172934 139.73807291408923 28.948 35.67292272690898 139.73806798524964 28.948 35.67290753800999 139.7380214528948 28.948 35.672903516212756 139.7380193367277 28.948 35.672921000172934 139.73807291408923 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6cefc845-f3ce-454a-9e5d-3c42300f46fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cefc845-f3ce-454a-9e5d-3c42300f46fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cefc845-f3ce-454a-9e5d-3c42300f46fa">
											<gml:posList>35.67292272690898 139.73806798524964 28.606 35.67295804713651 139.73805082102658 28.606 35.672952887810915 139.73803504154753 28.606 35.672936507192 139.73804304771926 28.606 35.67292654064887 139.7380122174303 28.606 35.67290753800999 139.7380214528948 28.606 35.67292272690898 139.73806798524964 28.606</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ff01603c-28a0-4742-95c7-b1a08c76fc94">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff01603c-28a0-4742-95c7-b1a08c76fc94">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff01603c-28a0-4742-95c7-b1a08c76fc94">
											<gml:posList>35.6729620689419 139.73805294824328 28.948 35.67295804713651 139.73805082102658 28.948 35.67292272690898 139.73806798524964 28.948 35.672921000172934 139.73807291408923 28.948 35.6729620689419 139.73805294824328 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4cd7c626-c876-4f91-9e62-6e277487c444">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4cd7c626-c876-4f91-9e62-6e277487c444">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4cd7c626-c876-4f91-9e62-6e277487c444">
											<gml:posList>35.67292185855611 139.7380755421623 27.336 35.67296448356942 139.73805161977972 27.336 35.6729620689419 139.73805294824328 27.336 35.672921000172934 139.73807291408923 27.336 35.67292185855611 139.7380755421623 27.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06ed9ae6-cf9f-4c95-803e-52adbb472865">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06ed9ae6-cf9f-4c95-803e-52adbb472865">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06ed9ae6-cf9f-4c95-803e-52adbb472865">
											<gml:posList>35.672954614545404 139.73803011270516 28.948 35.672952887810915 139.73803504154753 28.948 35.67295804713651 139.73805082102658 28.948 35.6729620689419 139.73805294824328 28.948 35.672954614545404 139.73803011270516 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c9c02012-92fd-40c9-a2e3-9fb7952109f2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9c02012-92fd-40c9-a2e3-9fb7952109f2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9c02012-92fd-40c9-a2e3-9fb7952109f2">
											<gml:posList>35.67300668160225 139.73803487818296 27.336 35.67300326393427 139.7380330264133 27.336 35.67296448356942 139.73805161977972 27.336 35.67292185855611 139.7380755421623 27.336 35.67300668160225 139.73803487818296 27.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ed227d8-c7f6-4be2-b211-e5653716973b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ed227d8-c7f6-4be2-b211-e5653716973b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ed227d8-c7f6-4be2-b211-e5653716973b">
											<gml:posList>35.672988969588005 139.73797789868522 27.336 35.67292826739118 139.73800729963568 27.336 35.67292924326019 139.73801031419995 27.336 35.67293170306079 139.73800911824128 27.336 35.67298744059762 139.73798212031207 27.336 35.672988969588005 139.73797789868522 27.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c244b19f-1b9d-480c-8665-d24422cf28de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c244b19f-1b9d-480c-8665-d24422cf28de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c244b19f-1b9d-480c-8665-d24422cf28de">
											<gml:posList>35.672988969588005 139.73797789868522 27.336 35.67298744059762 139.73798212031207 27.336 35.67300326393427 139.7380330264133 27.336 35.67300668160225 139.73803487818296 27.336 35.672988969588005 139.73797789868522 27.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f447f22b-07c8-4f80-9549-6061cba0346c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f447f22b-07c8-4f80-9549-6061cba0346c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f447f22b-07c8-4f80-9549-6061cba0346c">
											<gml:posList>35.672903516212756 139.7380193367277 28.948 35.67290753800999 139.7380214528948 28.948 35.67292654064887 139.7380122174303 28.948 35.67292826739118 139.73800729963568 28.948 35.672903516212756 139.7380193367277 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-531b9f8a-9ddf-4190-b522-d791f6dab224">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-531b9f8a-9ddf-4190-b522-d791f6dab224">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-531b9f8a-9ddf-4190-b522-d791f6dab224">
											<gml:posList>35.67296448356942 139.73805161977972 26.977 35.67300326393427 139.7380330264133 26.977 35.67298744059762 139.73798212031207 26.977 35.67293170306079 139.73800911824128 26.977 35.67292924326019 139.73801031419995 26.977 35.67293824294928 139.73803812991397 26.977 35.672954614545404 139.73803011270516 26.977 35.6729620689419 139.73805294824328 26.977 35.67296448356942 139.73805161977972 26.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2dc9b965-5cd9-46c0-99f8-749a897bbd3f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dc9b965-5cd9-46c0-99f8-749a897bbd3f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dc9b965-5cd9-46c0-99f8-749a897bbd3f">
											<gml:posList>35.67293824294928 139.73803812991397 28.948 35.67292826739118 139.73800729963568 28.948 35.67292654064887 139.7380122174303 28.948 35.672936507192 139.73804304771926 28.948 35.67293824294928 139.73803812991397 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-535762f5-396b-4d49-b2d3-fbf0efe181f3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-535762f5-396b-4d49-b2d3-fbf0efe181f3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-535762f5-396b-4d49-b2d3-fbf0efe181f3">
											<gml:posList>35.67293824294928 139.73803812991397 28.948 35.672936507192 139.73804304771926 28.948 35.672952887810915 139.73803504154753 28.948 35.672954614545404 139.73803011270516 28.948 35.67293824294928 139.73803812991397 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2dcf442f-0ec3-47a4-8a93-fd5ca7f5425e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2dcf442f-0ec3-47a4-8a93-fd5ca7f5425e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2dcf442f-0ec3-47a4-8a93-fd5ca7f5425e">
											<gml:posList>35.672921000172934 139.73807291408923 27.336 35.672921000172934 139.73807291408923 28.948 35.672903516212756 139.7380193367277 28.948 35.672903516212756 139.7380193367277 8.53 35.67292185855611 139.7380755421623 8.53 35.67292185855611 139.7380755421623 27.336 35.672921000172934 139.73807291408923 27.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-22975bec-1368-4958-8811-48489cdb8058">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-22975bec-1368-4958-8811-48489cdb8058">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-22975bec-1368-4958-8811-48489cdb8058">
											<gml:posList>35.67292272690898 139.73806798524964 28.948 35.67292272690898 139.73806798524964 28.606 35.67290753800999 139.7380214528948 28.606 35.67290753800999 139.7380214528948 28.948 35.67292272690898 139.73806798524964 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0783010-dbf7-4936-9da5-ef61e30a261d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0783010-dbf7-4936-9da5-ef61e30a261d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0783010-dbf7-4936-9da5-ef61e30a261d">
											<gml:posList>35.67290753800999 139.7380214528948 28.948 35.67290753800999 139.7380214528948 28.606 35.67292654064887 139.7380122174303 28.606 35.67292654064887 139.7380122174303 28.948 35.67290753800999 139.7380214528948 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d553df54-23a8-4cb7-aa96-36cb88524387">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d553df54-23a8-4cb7-aa96-36cb88524387">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d553df54-23a8-4cb7-aa96-36cb88524387">
											<gml:posList>35.67292924326019 139.73801031419995 27.336 35.67292924326019 139.73801031419995 26.977 35.67293170306079 139.73800911824128 26.977 35.67293170306079 139.73800911824128 27.336 35.67292924326019 139.73801031419995 27.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d1f889d-93c8-446c-868e-b7db6e9a16cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d1f889d-93c8-446c-868e-b7db6e9a16cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d1f889d-93c8-446c-868e-b7db6e9a16cc">
											<gml:posList>35.67292654064887 139.7380122174303 28.948 35.67292654064887 139.7380122174303 28.606 35.672936507192 139.73804304771926 28.606 35.672936507192 139.73804304771926 28.948 35.67292654064887 139.7380122174303 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9de22fd2-4771-4c65-a28c-eb5d1255b3c9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9de22fd2-4771-4c65-a28c-eb5d1255b3c9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9de22fd2-4771-4c65-a28c-eb5d1255b3c9">
											<gml:posList>35.67292924326019 139.73801031419995 27.336 35.67292826739118 139.73800729963568 27.336 35.67292826739118 139.73800729963568 28.948 35.67293824294928 139.73803812991397 28.948 35.67293824294928 139.73803812991397 26.977 35.67292924326019 139.73801031419995 26.977 35.67292924326019 139.73801031419995 27.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8b301771-04ec-40f3-86de-68b0ec4af0c8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8b301771-04ec-40f3-86de-68b0ec4af0c8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8b301771-04ec-40f3-86de-68b0ec4af0c8">
											<gml:posList>35.67295804713651 139.73805082102658 28.948 35.67295804713651 139.73805082102658 28.606 35.67292272690898 139.73806798524964 28.606 35.67292272690898 139.73806798524964 28.948 35.67295804713651 139.73805082102658 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f15dbc84-6494-4ef4-bfe0-ddf4e30cc75e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f15dbc84-6494-4ef4-bfe0-ddf4e30cc75e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f15dbc84-6494-4ef4-bfe0-ddf4e30cc75e">
											<gml:posList>35.6729620689419 139.73805294824328 27.336 35.6729620689419 139.73805294824328 28.948 35.672921000172934 139.73807291408923 28.948 35.672921000172934 139.73807291408923 27.336 35.6729620689419 139.73805294824328 27.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-faaa9c16-24b3-4ed5-b5ad-775d2f80b10e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-faaa9c16-24b3-4ed5-b5ad-775d2f80b10e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-faaa9c16-24b3-4ed5-b5ad-775d2f80b10e">
											<gml:posList>35.672936507192 139.73804304771926 28.948 35.672936507192 139.73804304771926 28.606 35.672952887810915 139.73803504154753 28.606 35.672952887810915 139.73803504154753 28.948 35.672936507192 139.73804304771926 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-50d2cf20-c43c-4685-89d0-dff38dd22ba6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-50d2cf20-c43c-4685-89d0-dff38dd22ba6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-50d2cf20-c43c-4685-89d0-dff38dd22ba6">
											<gml:posList>35.672903516212756 139.7380193367277 8.53 35.672903516212756 139.7380193367277 28.948 35.67292826739118 139.73800729963568 28.948 35.67292826739118 139.73800729963568 27.336 35.672988969588005 139.73797789868522 27.336 35.672988969588005 139.73797789868522 8.53 35.672903516212756 139.7380193367277 8.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5cc39610-c5c5-4399-afd5-a436594ef26c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5cc39610-c5c5-4399-afd5-a436594ef26c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5cc39610-c5c5-4399-afd5-a436594ef26c">
											<gml:posList>35.67293824294928 139.73803812991397 28.948 35.672954614545404 139.73803011270516 28.948 35.672954614545404 139.73803011270516 26.977 35.67293824294928 139.73803812991397 26.977 35.67293824294928 139.73803812991397 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b3fa634f-6b16-4d9b-b9d5-079fd2c114e6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b3fa634f-6b16-4d9b-b9d5-079fd2c114e6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b3fa634f-6b16-4d9b-b9d5-079fd2c114e6">
											<gml:posList>35.672952887810915 139.73803504154753 28.948 35.672952887810915 139.73803504154753 28.606 35.67295804713651 139.73805082102658 28.606 35.67295804713651 139.73805082102658 28.948 35.672952887810915 139.73803504154753 28.948</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b786f796-4884-45fa-a029-80669a2b9329">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b786f796-4884-45fa-a029-80669a2b9329">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b786f796-4884-45fa-a029-80669a2b9329">
											<gml:posList>35.672954614545404 139.73803011270516 26.977 35.672954614545404 139.73803011270516 28.948 35.6729620689419 139.73805294824328 28.948 35.6729620689419 139.73805294824328 27.336 35.6729620689419 139.73805294824328 26.977 35.672954614545404 139.73803011270516 26.977</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0a8a6808-aad7-4da8-b98b-4a2c305cf684">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0a8a6808-aad7-4da8-b98b-4a2c305cf684">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0a8a6808-aad7-4da8-b98b-4a2c305cf684">
											<gml:posList>35.67293170306079 139.73800911824128 27.336 35.67293170306079 139.73800911824128 26.977 35.67298744059762 139.73798212031207 26.977 35.67298744059762 139.73798212031207 27.336 35.67293170306079 139.73800911824128 27.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6a2b14e3-4d21-4656-9813-34e552a60335">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6a2b14e3-4d21-4656-9813-34e552a60335">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6a2b14e3-4d21-4656-9813-34e552a60335">
											<gml:posList>35.67296448356942 139.73805161977972 27.336 35.67296448356942 139.73805161977972 26.977 35.6729620689419 139.73805294824328 26.977 35.6729620689419 139.73805294824328 27.336 35.67296448356942 139.73805161977972 27.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5e19e5eb-1904-46d2-92ab-5e95ec9e140e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5e19e5eb-1904-46d2-92ab-5e95ec9e140e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5e19e5eb-1904-46d2-92ab-5e95ec9e140e">
											<gml:posList>35.67292185855611 139.7380755421623 8.53 35.67300668160225 139.73803487818296 8.53 35.67300668160225 139.73803487818296 27.336 35.67292185855611 139.7380755421623 27.336 35.67292185855611 139.7380755421623 8.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ac715b43-defd-4ba1-8766-d323b1f54f86">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac715b43-defd-4ba1-8766-d323b1f54f86">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac715b43-defd-4ba1-8766-d323b1f54f86">
											<gml:posList>35.67300326393427 139.7380330264133 27.336 35.67300326393427 139.7380330264133 26.977 35.67296448356942 139.73805161977972 26.977 35.67296448356942 139.73805161977972 27.336 35.67300326393427 139.7380330264133 27.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-25cf4083-a5d7-485b-915f-ddd79b50e41e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-25cf4083-a5d7-485b-915f-ddd79b50e41e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-25cf4083-a5d7-485b-915f-ddd79b50e41e">
											<gml:posList>35.67298744059762 139.73798212031207 27.336 35.67298744059762 139.73798212031207 26.977 35.67300326393427 139.7380330264133 26.977 35.67300326393427 139.7380330264133 27.336 35.67298744059762 139.73798212031207 27.336</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d652a385-32d9-4539-819b-c000573ecd31">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d652a385-32d9-4539-819b-c000573ecd31">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d652a385-32d9-4539-819b-c000573ecd31">
											<gml:posList>35.67300668160225 139.73803487818296 8.53 35.672988969588005 139.73797789868522 8.53 35.672988969588005 139.73797789868522 27.336 35.67300668160225 139.73803487818296 27.336 35.67300668160225 139.73803487818296 8.53</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-7653</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">49.40425</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>6</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.19</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>