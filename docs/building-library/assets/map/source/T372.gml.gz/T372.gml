<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6aeced1a-019a-460b-8495-e522cf042786">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">21.3</bldg:measuredHeight>
			<bldg:storeysAboveGround>7</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.67061693865991 139.74160290946472 0 35.67064794552909 139.7416024321378 0 35.67069170642747 139.7415422901851 0 35.67069426000502 139.7414630852704 0 35.67062097810373 139.74146272738844 0 35.67061693865991 139.74160290946472 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061693865991 139.74160290946472 8.77 35.67062097810373 139.74146272738844 8.77 35.67069426000502 139.7414630852704 8.77 35.67069170642747 139.7415422901851 8.77 35.67064794552909 139.7416024321378 8.77 35.67061693865991 139.74160290946472 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061693865991 139.74160290946472 8.77 35.67064794552909 139.7416024321378 8.77 35.67064794552909 139.7416024321378 30.1 35.67061693865991 139.74160290946472 30.1 35.67061693865991 139.74160290946472 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67064794552909 139.7416024321378 8.77 35.67069170642747 139.7415422901851 8.77 35.67069170642747 139.7415422901851 30.1 35.67064794552909 139.7416024321378 30.1 35.67064794552909 139.7416024321378 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67069170642747 139.7415422901851 8.77 35.67069426000502 139.7414630852704 8.77 35.67069426000502 139.7414630852704 30.1 35.67069170642747 139.7415422901851 30.1 35.67069170642747 139.7415422901851 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67069426000502 139.7414630852704 8.77 35.67062097810373 139.74146272738844 8.77 35.67062097810373 139.74146272738844 30.1 35.67069426000502 139.7414630852704 30.1 35.67069426000502 139.7414630852704 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67062097810373 139.74146272738844 8.77 35.67061693865991 139.74160290946472 8.77 35.67061693865991 139.74160290946472 30.1 35.67062097810373 139.74146272738844 30.1 35.67062097810373 139.74146272738844 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67061693865991 139.74160290946472 30.1 35.67064794552909 139.7416024321378 30.1 35.67069170642747 139.7415422901851 30.1 35.67069426000502 139.7414630852704 30.1 35.67062097810373 139.74146272738844 30.1 35.67061693865991 139.74160290946472 30.1</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-ac871eda-6ead-4620-91e3-3b5eabaedada"/>
							<gml:surfaceMember xlink:href="#poly-7b860626-7855-47e5-b63d-4a6efb4934d2"/>
							<gml:surfaceMember xlink:href="#poly-8355704b-8185-4dbc-b4d5-4ac426391da8"/>
							<gml:surfaceMember xlink:href="#poly-67b60e18-e78a-4bb5-8b59-7018aca487cc"/>
							<gml:surfaceMember xlink:href="#poly-d55b1c00-43f5-4755-b3ac-9b638dd41a45"/>
							<gml:surfaceMember xlink:href="#poly-fa505f92-dd33-4b38-aee8-cf24a6ad0010"/>
							<gml:surfaceMember xlink:href="#poly-ce17f94e-e625-4211-b27c-e5806c9d23c7"/>
							<gml:surfaceMember xlink:href="#poly-2d4c0a6c-507c-4bc7-85c8-bbf39c1d6723"/>
							<gml:surfaceMember xlink:href="#poly-ea7aa900-e6fe-44d3-9702-5c70101c4b38"/>
							<gml:surfaceMember xlink:href="#poly-574abbeb-c8d3-4eea-991f-07bf3d54a8c1"/>
							<gml:surfaceMember xlink:href="#poly-6dbcf530-d7c8-493a-b8d6-1da69a4430f9"/>
							<gml:surfaceMember xlink:href="#poly-ea52fda9-0940-4a5a-bbfa-a14aee449d45"/>
							<gml:surfaceMember xlink:href="#poly-9aec5d78-afb7-43b4-9cec-ba4108ec2f73"/>
							<gml:surfaceMember xlink:href="#poly-fed7aa4e-6cf4-448e-ab58-68eec1dbde55"/>
							<gml:surfaceMember xlink:href="#poly-9356b4be-ff74-4c2d-a775-18335d94beeb"/>
							<gml:surfaceMember xlink:href="#poly-d4cdd42c-38fc-45f5-9f2a-4d5b16c884c5"/>
							<gml:surfaceMember xlink:href="#poly-0e178159-2758-4e69-b92b-d0abb2ac4574"/>
							<gml:surfaceMember xlink:href="#poly-cbe8a392-086b-43f9-a28c-80d8acd2503b"/>
							<gml:surfaceMember xlink:href="#poly-53db9519-b3a5-4745-80dc-b56a156d38dd"/>
							<gml:surfaceMember xlink:href="#poly-a25ab1df-9839-4c04-8786-5bb57aa926e4"/>
							<gml:surfaceMember xlink:href="#poly-764ab13b-d5e2-484c-901a-702edb6cb929"/>
							<gml:surfaceMember xlink:href="#poly-81281f14-d467-48cb-b840-74ecc1adcbc6"/>
							<gml:surfaceMember xlink:href="#poly-b6e55483-cf1a-4ed5-9d90-44a16086353d"/>
							<gml:surfaceMember xlink:href="#poly-c0aa4847-cd57-4aa1-8312-d28859bde356"/>
							<gml:surfaceMember xlink:href="#poly-8ed687b5-e469-4ec7-8614-a0c0df38a985"/>
							<gml:surfaceMember xlink:href="#poly-a096ac6d-628b-4e34-95bf-761238e630fa"/>
							<gml:surfaceMember xlink:href="#poly-00e852f3-56ad-4420-9b27-ab5a118e75ac"/>
							<gml:surfaceMember xlink:href="#poly-2c02c377-950e-4bcf-8c8d-6b019c918e2d"/>
							<gml:surfaceMember xlink:href="#poly-82dc3e47-0e01-46aa-a6a8-508190477815"/>
							<gml:surfaceMember xlink:href="#poly-4b8b4c76-63b5-4089-af94-d2d5bb21f673"/>
							<gml:surfaceMember xlink:href="#poly-e29747ab-3294-4f2a-8a87-0b02d356cbc7"/>
							<gml:surfaceMember xlink:href="#poly-c918fb28-1eec-480e-9dcb-62f016e33554"/>
							<gml:surfaceMember xlink:href="#poly-03339040-8016-4685-a2e3-54324c7de6a5"/>
							<gml:surfaceMember xlink:href="#poly-402c9e37-0d06-42b0-8374-97aa63524386"/>
							<gml:surfaceMember xlink:href="#poly-d97983e7-b820-4ff9-a386-0f6ce3a66cc4"/>
							<gml:surfaceMember xlink:href="#poly-a90f2dd2-857d-4cb7-8c02-c089e5cbefe6"/>
							<gml:surfaceMember xlink:href="#poly-a96be540-2f62-4716-a1b3-a8a57f674163"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6aeced1a-019a-460b-8495-e522cf042786_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7bd5a14a-a920-4ea8-bf72-bc96703c2b36">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670669281258604 139.7414844884815 30.485 35.67068773304792 139.74148538418652 30.485 35.67068586625943 139.74154324685318 30.485 35.670667414470515 139.74154235113485 30.485 35.670669281258604 139.7414844884815 30.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-314e4060-c777-4421-8c09-946aa15eeea9">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.67065866124127 139.74151752907835 30.485 35.670658055228714 139.7415384293678 30.485 35.67063332073187 139.74153735305708 30.485 35.670633917738954 139.74151646383064 30.485 35.67065866124127 139.74151752907835 30.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d8a515f-c04d-4a3d-9935-75dae6b984c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d8a515f-c04d-4a3d-9935-75dae6b984c6_0">
											<gml:posList>35.67068773304792 139.74148538418652 30.485 35.670669281258604 139.7414844884815 30.485 35.670669281258604 139.7414844884815 32.39 35.67068773304792 139.74148538418652 32.39 35.67068773304792 139.74148538418652 30.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a45a11e9-a121-49c9-8c27-79d070f99e3c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a45a11e9-a121-49c9-8c27-79d070f99e3c_0">
											<gml:posList>35.670667414470515 139.74154235113485 30.485 35.670667414470515 139.74154235113485 32.39 35.670669281258604 139.7414844884815 32.39 35.670669281258604 139.7414844884815 30.485 35.670667414470515 139.74154235113485 30.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9234340a-a263-46b2-850e-483f9a860cad">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9234340a-a263-46b2-850e-483f9a860cad_0">
											<gml:posList>35.670669281258604 139.7414844884815 32.39 35.670667414470515 139.74154235113485 32.39 35.67068586625943 139.74154324685318 32.39 35.67068773304792 139.74148538418652 32.39 35.670669281258604 139.7414844884815 32.39</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5bdc2f55-a213-4f6d-8e6d-4f9977498fd6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5bdc2f55-a213-4f6d-8e6d-4f9977498fd6_0">
											<gml:posList>35.67068586625943 139.74154324685318 30.485 35.67068773304792 139.74148538418652 30.485 35.67068773304792 139.74148538418652 32.39 35.67068586625943 139.74154324685318 32.39 35.67068586625943 139.74154324685318 30.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aece652e-706b-4aca-a9c1-69a9b5e612c5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aece652e-706b-4aca-a9c1-69a9b5e612c5_0">
											<gml:posList>35.67065866124127 139.74151752907835 30.485 35.670633917738954 139.74151646383064 30.485 35.670633917738954 139.74151646383064 33.114 35.67065866124127 139.74151752907835 33.114 35.67065866124127 139.74151752907835 30.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3d27e0c1-c2f8-495c-855d-25f5c8e3c2aa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3d27e0c1-c2f8-495c-855d-25f5c8e3c2aa_0">
											<gml:posList>35.67063332073187 139.74153735305708 33.114 35.670633917738954 139.74151646383064 33.114 35.670633917738954 139.74151646383064 30.485 35.67063332073187 139.74153735305708 30.485 35.67063332073187 139.74153735305708 33.114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6aa5881e-ba0d-4b63-bbf9-2024dcc48b21">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6aa5881e-ba0d-4b63-bbf9-2024dcc48b21_0">
											<gml:posList>35.67063332073187 139.74153735305708 33.114 35.670658055228714 139.7415384293678 33.114 35.67065866124127 139.74151752907835 33.114 35.670633917738954 139.74151646383064 33.114 35.67063332073187 139.74153735305708 33.114</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f9d3a00-0ba1-4c07-9161-5478ebc46e76">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f9d3a00-0ba1-4c07-9161-5478ebc46e76_0">
											<gml:posList>35.670658055228714 139.7415384293678 30.485 35.67065866124127 139.74151752907835 30.485 35.67065866124127 139.74151752907835 33.114 35.670658055228714 139.7415384293678 33.114 35.670658055228714 139.7415384293678 30.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3498fd28-e2c9-4f36-bfd4-c15cd12ffba8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3498fd28-e2c9-4f36-bfd4-c15cd12ffba8_0">
											<gml:posList>35.67063332073187 139.74153735305708 30.485 35.670658055228714 139.7415384293678 30.485 35.670658055228714 139.7415384293678 33.114 35.67063332073187 139.74153735305708 33.114 35.67063332073187 139.74153735305708 30.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-50f47c62-e2b7-476e-b5fe-fb5383851f9b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-50f47c62-e2b7-476e-b5fe-fb5383851f9b_0">
											<gml:posList>35.67068586625943 139.74154324685318 30.485 35.67068586625943 139.74154324685318 32.39 35.670667414470515 139.74154235113485 32.39 35.670667414470515 139.74154235113485 30.485 35.67068586625943 139.74154324685318 30.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6aeced1a-019a-460b-8495-e522cf042786_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-eb5046b8-b1f8-4522-abc7-ea46c74f0f84">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.670646218083036 139.74157112891075 35.075 35.67063411224112 139.74157060149741 35.075 35.67063452507651 139.74155641758267 35.075 35.67064663091848 139.74155694499385 35.075 35.670646218083036 139.74157112891075 35.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d3feb4bf-50fc-460a-8d9e-d0c4a57846b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d3feb4bf-50fc-460a-8d9e-d0c4a57846b3_0">
											<gml:posList>35.67063452507651 139.74155641758267 35.075 35.67063452507651 139.74155641758267 37.073 35.67064663091848 139.74155694499385 37.073 35.67064663091848 139.74155694499385 35.075 35.67063452507651 139.74155641758267 35.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-862c8a7b-6f60-4d84-b065-4d30b0cf4d58">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-862c8a7b-6f60-4d84-b065-4d30b0cf4d58_0">
											<gml:posList>35.67063411224112 139.74157060149741 35.075 35.67063411224112 139.74157060149741 37.073 35.67063452507651 139.74155641758267 37.073 35.67063452507651 139.74155641758267 35.075 35.67063411224112 139.74157060149741 35.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5a2b473-82ad-4db7-ace7-3c9cc8fd7399">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5a2b473-82ad-4db7-ace7-3c9cc8fd7399_0">
											<gml:posList>35.67063452507651 139.74155641758267 37.073 35.67063411224112 139.74157060149741 37.073 35.670646218083036 139.74157112891075 37.073 35.67064663091848 139.74155694499385 37.073 35.67063452507651 139.74155641758267 37.073</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a3d0bf8f-2610-467f-8cf1-c0f506904e6b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a3d0bf8f-2610-467f-8cf1-c0f506904e6b_0">
											<gml:posList>35.67064663091848 139.74155694499385 35.075 35.67064663091848 139.74155694499385 37.073 35.670646218083036 139.74157112891075 37.073 35.670646218083036 139.74157112891075 35.075 35.67064663091848 139.74155694499385 35.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-61d2ec83-6827-46cd-be61-3b0caf64e4c3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-61d2ec83-6827-46cd-be61-3b0caf64e4c3_0">
											<gml:posList>35.670646218083036 139.74157112891075 35.075 35.670646218083036 139.74157112891075 37.073 35.67063411224112 139.74157060149741 37.073 35.67063411224112 139.74157060149741 35.075 35.670646218083036 139.74157112891075 35.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-ac871eda-6ead-4620-91e3-3b5eabaedada">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ac871eda-6ead-4620-91e3-3b5eabaedada">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ac871eda-6ead-4620-91e3-3b5eabaedada">
											<gml:posList>35.6706169386599 139.7416029094647 8.77 35.670620978103706 139.74146272738847 8.77 35.67069426000502 139.74146308527037 8.77 35.670691706427455 139.74154229018507 8.77 35.67064794552906 139.7416024321378 8.77 35.6706169386599 139.7416029094647 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7b860626-7855-47e5-b63d-4a6efb4934d2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b860626-7855-47e5-b63d-4a6efb4934d2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b860626-7855-47e5-b63d-4a6efb4934d2">
											<gml:posList>35.670620978103706 139.74146272738847 30.819 35.6706169386599 139.7416029094647 30.819 35.670621015152754 139.74154676754108 30.819 35.67062347733205 139.74146590585713 30.819 35.670620978103706 139.74146272738847 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8355704b-8185-4dbc-b4d5-4ac426391da8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8355704b-8185-4dbc-b4d5-4ac426391da8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8355704b-8185-4dbc-b4d5-4ac426391da8">
											<gml:posList>35.6706169386599 139.7416029094647 30.819 35.670618525058245 139.7416028855571 30.819 35.67061920134004 139.74157955501363 30.819 35.67062239229885 139.74157968391745 30.819 35.67062333187314 139.74154701895364 30.819 35.670621015152754 139.74154676754108 30.819 35.6706169386599 139.7416029094647 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-67b60e18-e78a-4bb5-8b59-7018aca487cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-67b60e18-e78a-4bb5-8b59-7018aca487cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-67b60e18-e78a-4bb5-8b59-7018aca487cc">
											<gml:posList>35.67062239229885 139.74157968391745 35.322 35.67061920134004 139.74157955501363 35.322 35.67062159235856 139.74158267837825 35.322 35.67062478331737 139.74158280728216 35.322 35.67062239229885 139.74157968391745 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d55b1c00-43f5-4755-b3ac-9b638dd41a45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d55b1c00-43f5-4755-b3ac-9b638dd41a45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d55b1c00-43f5-4755-b3ac-9b638dd41a45">
											<gml:posList>35.67061920134004 139.74157955501363 35.322 35.670618525058245 139.7416028855571 35.322 35.67062109163819 139.74159982279758 35.322 35.67062159235856 139.74158267837825 35.322 35.67061920134004 139.74157955501363 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fa505f92-dd33-4b38-aee8-cf24a6ad0010">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fa505f92-dd33-4b38-aee8-cf24a6ad0010">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fa505f92-dd33-4b38-aee8-cf24a6ad0010">
											<gml:posList>35.670620978103706 139.74146272738847 30.819 35.67062347733205 139.74146590585713 30.819 35.670691558298614 139.7414662476086 30.819 35.67069426000502 139.74146308527037 30.819 35.670620978103706 139.74146272738847 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce17f94e-e625-4211-b27c-e5806c9d23c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce17f94e-e625-4211-b27c-e5806c9d23c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce17f94e-e625-4211-b27c-e5806c9d23c7">
											<gml:posList>35.670691706427455 139.74154229018507 30.819 35.67069426000502 139.74146308527037 30.819 35.670691558298614 139.7414662476086 30.819 35.6706891455703 139.74154103383844 30.819 35.670691706427455 139.74154229018507 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2d4c0a6c-507c-4bc7-85c8-bbf39c1d6723">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d4c0a6c-507c-4bc7-85c8-bbf39c1d6723">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d4c0a6c-507c-4bc7-85c8-bbf39c1d6723">
											<gml:posList>35.670621015152754 139.74154676754108 30.485 35.67062333187314 139.74154701895364 30.485 35.670657684331864 139.74154850401607 30.485 35.67065660425789 139.74158605161816 30.485 35.6706891455703 139.74154103383844 30.485 35.670691558298614 139.7414662476086 30.485 35.67062347733205 139.74146590585713 30.485 35.670621015152754 139.74154676754108 30.485</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea7aa900-e6fe-44d3-9702-5c70101c4b38">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea7aa900-e6fe-44d3-9702-5c70101c4b38">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea7aa900-e6fe-44d3-9702-5c70101c4b38">
											<gml:posList>35.67062333187314 139.74154701895364 35.322 35.67062572290934 139.74155016441 35.322 35.670655126665935 139.74155143421285 35.322 35.670657684331864 139.74154850401607 35.322 35.67062333187314 139.74154701895364 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-574abbeb-c8d3-4eea-991f-07bf3d54a8c1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-574abbeb-c8d3-4eea-991f-07bf3d54a8c1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-574abbeb-c8d3-4eea-991f-07bf3d54a8c1">
											<gml:posList>35.67062239229885 139.74157968391745 35.322 35.67062478331737 139.74158280728216 35.322 35.67062572290934 139.74155016441 35.322 35.67062333187314 139.74154701895364 35.322 35.67062239229885 139.74157968391745 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6dbcf530-d7c8-493a-b8d6-1da69a4430f9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dbcf530-d7c8-493a-b8d6-1da69a4430f9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dbcf530-d7c8-493a-b8d6-1da69a4430f9">
											<gml:posList>35.67065660425789 139.74158605161816 30.819 35.670656472603774 139.7415907133064 30.819 35.670691706427455 139.74154229018507 30.819 35.6706891455703 139.74154103383844 30.819 35.67065660425789 139.74158605161816 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ea52fda9-0940-4a5a-bbfa-a14aee449d45">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ea52fda9-0940-4a5a-bbfa-a14aee449d45">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ea52fda9-0940-4a5a-bbfa-a14aee449d45">
											<gml:posList>35.670656472603774 139.7415907133064 35.322 35.670657684331864 139.74154850401607 35.322 35.670655126665935 139.74155143421285 35.322 35.67065403798131 139.74158951204586 35.322 35.670656472603774 139.7415907133064 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9aec5d78-afb7-43b4-9cec-ba4108ec2f73">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9aec5d78-afb7-43b4-9cec-ba4108ec2f73">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9aec5d78-afb7-43b4-9cec-ba4108ec2f73">
											<gml:posList>35.670655126665935 139.74155143421285 35.075 35.67062572290934 139.74155016441 35.075 35.67062478331737 139.74158280728216 35.075 35.67062159235856 139.74158267837825 35.075 35.67062109163819 139.74159982279758 35.075 35.670646825530106 139.7415994177803 35.075 35.67065403798131 139.74158951204586 35.075 35.670655126665935 139.74155143421285 35.075</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fed7aa4e-6cf4-448e-ab58-68eec1dbde55">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fed7aa4e-6cf4-448e-ab58-68eec1dbde55">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fed7aa4e-6cf4-448e-ab58-68eec1dbde55">
											<gml:posList>35.670656472603774 139.7415907133064 35.322 35.67065403798131 139.74158951204586 35.322 35.670646825530106 139.7415994177803 35.322 35.67064794552906 139.7416024321378 35.322 35.670656472603774 139.7415907133064 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9356b4be-ff74-4c2d-a775-18335d94beeb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9356b4be-ff74-4c2d-a775-18335d94beeb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9356b4be-ff74-4c2d-a775-18335d94beeb">
											<gml:posList>35.67064794552906 139.7416024321378 35.322 35.670646825530106 139.7415994177803 35.322 35.67062109163819 139.74159982279758 35.322 35.670618525058245 139.7416028855571 35.322 35.67064794552906 139.7416024321378 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d4cdd42c-38fc-45f5-9f2a-4d5b16c884c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d4cdd42c-38fc-45f5-9f2a-4d5b16c884c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d4cdd42c-38fc-45f5-9f2a-4d5b16c884c5">
											<gml:posList>35.670618525058245 139.7416028855571 30.819 35.670618525058245 139.7416028855571 35.322 35.67061920134004 139.74157955501363 35.322 35.67061920134004 139.74157955501363 30.819 35.670618525058245 139.7416028855571 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0e178159-2758-4e69-b92b-d0abb2ac4574">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0e178159-2758-4e69-b92b-d0abb2ac4574">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0e178159-2758-4e69-b92b-d0abb2ac4574">
											<gml:posList>35.670620978103706 139.74146272738847 8.77 35.6706169386599 139.7416029094647 8.77 35.6706169386599 139.7416029094647 30.819 35.670620978103706 139.74146272738847 30.819 35.670620978103706 139.74146272738847 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cbe8a392-086b-43f9-a28c-80d8acd2503b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cbe8a392-086b-43f9-a28c-80d8acd2503b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cbe8a392-086b-43f9-a28c-80d8acd2503b">
											<gml:posList>35.67061920134004 139.74157955501363 30.819 35.67061920134004 139.74157955501363 35.322 35.67062239229885 139.74157968391745 35.322 35.67062239229885 139.74157968391745 30.819 35.67061920134004 139.74157955501363 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-53db9519-b3a5-4745-80dc-b56a156d38dd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-53db9519-b3a5-4745-80dc-b56a156d38dd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-53db9519-b3a5-4745-80dc-b56a156d38dd">
											<gml:posList>35.67062109163819 139.74159982279758 35.322 35.67062109163819 139.74159982279758 35.075 35.67062159235856 139.74158267837825 35.075 35.67062159235856 139.74158267837825 35.322 35.67062109163819 139.74159982279758 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a25ab1df-9839-4c04-8786-5bb57aa926e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a25ab1df-9839-4c04-8786-5bb57aa926e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a25ab1df-9839-4c04-8786-5bb57aa926e4">
											<gml:posList>35.67062333187314 139.74154701895364 30.819 35.67062333187314 139.74154701895364 30.485 35.670621015152754 139.74154676754108 30.485 35.670621015152754 139.74154676754108 30.819 35.67062333187314 139.74154701895364 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-764ab13b-d5e2-484c-901a-702edb6cb929">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-764ab13b-d5e2-484c-901a-702edb6cb929">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-764ab13b-d5e2-484c-901a-702edb6cb929">
											<gml:posList>35.670621015152754 139.74154676754108 30.819 35.670621015152754 139.74154676754108 30.485 35.67062347733205 139.74146590585713 30.485 35.67062347733205 139.74146590585713 30.819 35.670621015152754 139.74154676754108 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-81281f14-d467-48cb-b840-74ecc1adcbc6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-81281f14-d467-48cb-b840-74ecc1adcbc6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-81281f14-d467-48cb-b840-74ecc1adcbc6">
											<gml:posList>35.67062239229885 139.74157968391745 30.819 35.67062239229885 139.74157968391745 35.322 35.67062333187314 139.74154701895364 35.322 35.67062333187314 139.74154701895364 30.819 35.67062239229885 139.74157968391745 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b6e55483-cf1a-4ed5-9d90-44a16086353d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b6e55483-cf1a-4ed5-9d90-44a16086353d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b6e55483-cf1a-4ed5-9d90-44a16086353d">
											<gml:posList>35.67062159235856 139.74158267837825 35.322 35.67062159235856 139.74158267837825 35.075 35.67062478331737 139.74158280728216 35.075 35.67062478331737 139.74158280728216 35.322 35.67062159235856 139.74158267837825 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c0aa4847-cd57-4aa1-8312-d28859bde356">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c0aa4847-cd57-4aa1-8312-d28859bde356">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c0aa4847-cd57-4aa1-8312-d28859bde356">
											<gml:posList>35.67062478331737 139.74158280728216 35.322 35.67062478331737 139.74158280728216 35.075 35.67062572290934 139.74155016441 35.075 35.67062572290934 139.74155016441 35.322 35.67062478331737 139.74158280728216 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8ed687b5-e469-4ec7-8614-a0c0df38a985">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8ed687b5-e469-4ec7-8614-a0c0df38a985">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8ed687b5-e469-4ec7-8614-a0c0df38a985">
											<gml:posList>35.67064794552906 139.7416024321378 8.77 35.67064794552906 139.7416024321378 35.322 35.670618525058245 139.7416028855571 35.322 35.670618525058245 139.7416028855571 30.819 35.6706169386599 139.7416029094647 30.819 35.6706169386599 139.7416029094647 8.77 35.67064794552906 139.7416024321378 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a096ac6d-628b-4e34-95bf-761238e630fa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a096ac6d-628b-4e34-95bf-761238e630fa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a096ac6d-628b-4e34-95bf-761238e630fa">
											<gml:posList>35.670646825530106 139.7415994177803 35.322 35.670646825530106 139.7415994177803 35.075 35.67062109163819 139.74159982279758 35.075 35.67062109163819 139.74159982279758 35.322 35.670646825530106 139.7415994177803 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-00e852f3-56ad-4420-9b27-ab5a118e75ac">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-00e852f3-56ad-4420-9b27-ab5a118e75ac">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-00e852f3-56ad-4420-9b27-ab5a118e75ac">
											<gml:posList>35.67062572290934 139.74155016441 35.322 35.67062572290934 139.74155016441 35.075 35.670655126665935 139.74155143421285 35.075 35.670655126665935 139.74155143421285 35.322 35.67062572290934 139.74155016441 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2c02c377-950e-4bcf-8c8d-6b019c918e2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2c02c377-950e-4bcf-8c8d-6b019c918e2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2c02c377-950e-4bcf-8c8d-6b019c918e2d">
											<gml:posList>35.670657684331864 139.74154850401607 35.322 35.670657684331864 139.74154850401607 30.485 35.67062333187314 139.74154701895364 30.485 35.67062333187314 139.74154701895364 30.819 35.67062333187314 139.74154701895364 35.322 35.670657684331864 139.74154850401607 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-82dc3e47-0e01-46aa-a6a8-508190477815">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-82dc3e47-0e01-46aa-a6a8-508190477815">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-82dc3e47-0e01-46aa-a6a8-508190477815">
											<gml:posList>35.67065403798131 139.74158951204586 35.322 35.67065403798131 139.74158951204586 35.075 35.670646825530106 139.7415994177803 35.075 35.670646825530106 139.7415994177803 35.322 35.67065403798131 139.74158951204586 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-4b8b4c76-63b5-4089-af94-d2d5bb21f673">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4b8b4c76-63b5-4089-af94-d2d5bb21f673">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4b8b4c76-63b5-4089-af94-d2d5bb21f673">
											<gml:posList>35.670655126665935 139.74155143421285 35.322 35.670655126665935 139.74155143421285 35.075 35.67065403798131 139.74158951204586 35.075 35.67065403798131 139.74158951204586 35.322 35.670655126665935 139.74155143421285 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e29747ab-3294-4f2a-8a87-0b02d356cbc7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e29747ab-3294-4f2a-8a87-0b02d356cbc7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e29747ab-3294-4f2a-8a87-0b02d356cbc7">
											<gml:posList>35.670656472603774 139.7415907133064 35.322 35.670656472603774 139.7415907133064 30.819 35.67065660425789 139.74158605161816 30.819 35.67065660425789 139.74158605161816 30.485 35.670657684331864 139.74154850401607 30.485 35.670657684331864 139.74154850401607 35.322 35.670656472603774 139.7415907133064 35.322</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c918fb28-1eec-480e-9dcb-62f016e33554">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c918fb28-1eec-480e-9dcb-62f016e33554">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c918fb28-1eec-480e-9dcb-62f016e33554">
											<gml:posList>35.67062347733205 139.74146590585713 30.819 35.67062347733205 139.74146590585713 30.485 35.670691558298614 139.7414662476086 30.485 35.670691558298614 139.7414662476086 30.819 35.67062347733205 139.74146590585713 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-03339040-8016-4685-a2e3-54324c7de6a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03339040-8016-4685-a2e3-54324c7de6a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03339040-8016-4685-a2e3-54324c7de6a5">
											<gml:posList>35.67069426000502 139.74146308527037 8.77 35.670620978103706 139.74146272738847 8.77 35.670620978103706 139.74146272738847 30.819 35.67069426000502 139.74146308527037 30.819 35.67069426000502 139.74146308527037 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-402c9e37-0d06-42b0-8374-97aa63524386">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-402c9e37-0d06-42b0-8374-97aa63524386">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-402c9e37-0d06-42b0-8374-97aa63524386">
											<gml:posList>35.67064794552906 139.7416024321378 8.77 35.670691706427455 139.74154229018507 8.77 35.670691706427455 139.74154229018507 30.819 35.670656472603774 139.7415907133064 30.819 35.670656472603774 139.7415907133064 35.322 35.67064794552906 139.7416024321378 35.322 35.67064794552906 139.7416024321378 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d97983e7-b820-4ff9-a386-0f6ce3a66cc4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d97983e7-b820-4ff9-a386-0f6ce3a66cc4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d97983e7-b820-4ff9-a386-0f6ce3a66cc4">
											<gml:posList>35.6706891455703 139.74154103383844 30.819 35.6706891455703 139.74154103383844 30.485 35.67065660425789 139.74158605161816 30.485 35.67065660425789 139.74158605161816 30.819 35.6706891455703 139.74154103383844 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a90f2dd2-857d-4cb7-8c02-c089e5cbefe6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a90f2dd2-857d-4cb7-8c02-c089e5cbefe6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a90f2dd2-857d-4cb7-8c02-c089e5cbefe6">
											<gml:posList>35.670691558298614 139.7414662476086 30.819 35.670691558298614 139.7414662476086 30.485 35.6706891455703 139.74154103383844 30.485 35.6706891455703 139.74154103383844 30.819 35.670691558298614 139.7414662476086 30.819</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a96be540-2f62-4716-a1b3-a8a57f674163">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a96be540-2f62-4716-a1b3-a8a57f674163">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a96be540-2f62-4716-a1b3-a8a57f674163">
											<gml:posList>35.670691706427455 139.74154229018507 8.77 35.67069426000502 139.74146308527037 8.77 35.67069426000502 139.74146308527037 30.819 35.670691706427455 139.74154229018507 30.819 35.670691706427455 139.74154229018507 8.77</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-3635</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">89.81455</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.01</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>