<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6aee51ae-aecf-4d7f-bfaa-2328896a90b1">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">412</bldg:usage>
			<bldg:measuredHeight uom="m">11.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.667857137968035 139.7389511818307 0 35.668004754020544 139.73902932373608 0 35.66802355091338 139.738975949765 0 35.667904069345695 139.73891268679463 0 35.667869908969635 139.73891482574328 0 35.667857137968035 139.7389511818307 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667857137968035 139.7389511818307 12.959 35.667869908969635 139.73891482574328 12.959 35.667904069345695 139.73891268679463 12.959 35.66802355091338 139.738975949765 12.959 35.668004754020544 139.73902932373608 12.959 35.667857137968035 139.7389511818307 12.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667857137968035 139.7389511818307 12.959 35.668004754020544 139.73902932373608 12.959 35.668004754020544 139.73902932373608 24.31 35.667857137968035 139.7389511818307 24.31 35.667857137968035 139.7389511818307 12.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668004754020544 139.73902932373608 12.959 35.66802355091338 139.738975949765 12.959 35.66802355091338 139.738975949765 24.31 35.668004754020544 139.73902932373608 24.31 35.668004754020544 139.73902932373608 12.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66802355091338 139.738975949765 12.959 35.667904069345695 139.73891268679463 12.959 35.667904069345695 139.73891268679463 24.31 35.66802355091338 139.738975949765 24.31 35.66802355091338 139.738975949765 12.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667904069345695 139.73891268679463 12.959 35.667869908969635 139.73891482574328 12.959 35.667869908969635 139.73891482574328 24.31 35.667904069345695 139.73891268679463 24.31 35.667904069345695 139.73891268679463 12.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667869908969635 139.73891482574328 12.959 35.667857137968035 139.7389511818307 12.959 35.667857137968035 139.7389511818307 24.31 35.667869908969635 139.73891482574328 24.31 35.667869908969635 139.73891482574328 12.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667857137968035 139.7389511818307 24.31 35.668004754020544 139.73902932373608 24.31 35.66802355091338 139.738975949765 24.31 35.667904069345695 139.73891268679463 24.31 35.667869908969635 139.73891482574328 24.31 35.667857137968035 139.7389511818307 24.31</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-5ab06c6d-3bd5-4c3e-a558-35534e589990"/>
							<gml:surfaceMember xlink:href="#poly-3a965188-c818-4349-b18f-a156b3e80df9"/>
							<gml:surfaceMember xlink:href="#poly-8594e0b3-7d02-4a6e-b515-a66a0a8c404f"/>
							<gml:surfaceMember xlink:href="#poly-7ce20309-0af6-4374-b9fa-7ec55b440601"/>
							<gml:surfaceMember xlink:href="#poly-1d1bbe19-cf5f-48be-bb5a-4739789917d0"/>
							<gml:surfaceMember xlink:href="#poly-668c6d23-148e-4625-acc1-efd9907f17e7"/>
							<gml:surfaceMember xlink:href="#poly-bad577f8-99cc-4fdb-88d4-45e09b9a9146"/>
							<gml:surfaceMember xlink:href="#poly-4e57d424-3122-423b-917e-525797d25ab6"/>
							<gml:surfaceMember xlink:href="#poly-f89a3632-e2b6-45b6-9cbe-f29df46a8c64"/>
							<gml:surfaceMember xlink:href="#poly-722c2496-efbc-4e6d-bffa-941402cc0678"/>
							<gml:surfaceMember xlink:href="#poly-2499e3e0-6f15-4770-8fef-bcd8f0cb0092"/>
							<gml:surfaceMember xlink:href="#poly-c560ab3f-d79d-4eb6-9af7-e60bd7658e0a"/>
							<gml:surfaceMember xlink:href="#poly-cae37fdc-10d3-45c0-9457-4ab772b7dbfb"/>
							<gml:surfaceMember xlink:href="#poly-15ac4b57-b491-4318-b4db-586950d87753"/>
							<gml:surfaceMember xlink:href="#poly-417c1164-9756-46fa-98ad-182cafc19a2a"/>
							<gml:surfaceMember xlink:href="#poly-7a7124c3-a5ed-4d7d-be75-11810c0a1e51"/>
							<gml:surfaceMember xlink:href="#poly-e115d218-988a-4676-ab23-08bf13a489f6"/>
							<gml:surfaceMember xlink:href="#poly-6b8fc75c-e647-4813-add1-9f37b811c90b"/>
							<gml:surfaceMember xlink:href="#poly-0ed6eca7-d24b-4ef2-a00f-e44748436d9b"/>
							<gml:surfaceMember xlink:href="#poly-d932009b-f96f-44b1-96a8-d4c27e95be32"/>
							<gml:surfaceMember xlink:href="#poly-36e97325-80b7-4d30-8c4d-83f75bec5d1f"/>
							<gml:surfaceMember xlink:href="#poly-aa7ec8b3-8980-49b4-ad4b-298036183c96"/>
							<gml:surfaceMember xlink:href="#poly-06e0a861-a748-444f-8fa2-42e21ca89898"/>
							<gml:surfaceMember xlink:href="#poly-f8fce694-9941-4a1e-9d4b-628054bfff83"/>
							<gml:surfaceMember xlink:href="#poly-dd46800e-9b9e-4d5e-8fcf-9bbfd6462183"/>
							<gml:surfaceMember xlink:href="#poly-9163e698-d931-403b-8c2d-888d7e3e1523"/>
							<gml:surfaceMember xlink:href="#poly-265f9d0b-a91b-4bb7-9381-937e978f99c7"/>
							<gml:surfaceMember xlink:href="#poly-0c4d1b38-8876-4a01-8324-969e75878cea"/>
							<gml:surfaceMember xlink:href="#poly-d100597c-0c51-4dc0-93a9-17fcab38f417"/>
							<gml:surfaceMember xlink:href="#poly-ff456819-5d4f-46f4-9adb-3bbb50888a7f"/>
							<gml:surfaceMember xlink:href="#poly-34b604ce-bc5d-4000-9666-6603813432bc"/>
							<gml:surfaceMember xlink:href="#poly-ef6a9458-5d0e-407a-86ac-a9e1871b669c"/>
							<gml:surfaceMember xlink:href="#poly-a322c903-bbae-4850-bd6e-9391dc290409"/>
							<gml:surfaceMember xlink:href="#poly-318da24c-4263-4314-949e-140953e7e0b6"/>
							<gml:surfaceMember xlink:href="#poly-6dbd165f-ae8b-4854-adf4-952cecd711f1"/>
							<gml:surfaceMember xlink:href="#poly-6eb06889-2396-4a36-9b90-ead2eaa0ff34"/>
							<gml:surfaceMember xlink:href="#poly-f679fcc2-61d1-45ff-98a4-e87867a60e61"/>
							<gml:surfaceMember xlink:href="#poly-6887804c-b160-4c0e-86a4-2cc35ea580d4"/>
							<gml:surfaceMember xlink:href="#poly-ec581363-2a7a-47d0-b5fb-52bf32300206"/>
							<gml:surfaceMember xlink:href="#poly-39d432c4-67d6-46e3-83a0-71bce94f5537"/>
							<gml:surfaceMember xlink:href="#poly-6844d9fc-2a8f-47c2-87c6-64627cdad330"/>
							<gml:surfaceMember xlink:href="#poly-1988bb83-c501-4016-bd64-c9afeec866de"/>
							<gml:surfaceMember xlink:href="#poly-48dc7276-e199-40ec-9b8e-656ea1845e63"/>
							<gml:surfaceMember xlink:href="#poly-e39820c0-3aa9-4a22-9b7f-c5ad194e5cf3"/>
							<gml:surfaceMember xlink:href="#poly-45f8f280-fee6-4ffa-b2bb-720e88b8e4c7"/>
							<gml:surfaceMember xlink:href="#poly-3a0cb637-38d8-4a2b-97b8-52adb498d1c5"/>
							<gml:surfaceMember xlink:href="#poly-f57af27b-ba68-4023-add4-ec9124d5ecd0"/>
							<gml:surfaceMember xlink:href="#poly-856420ee-8258-4c2c-9a7a-8989515cb5d1"/>
							<gml:surfaceMember xlink:href="#poly-78612b13-25b5-40cd-9ede-1eacddbacc0c"/>
							<gml:surfaceMember xlink:href="#poly-36e04759-1b23-41a5-930d-f1f16541ea78"/>
							<gml:surfaceMember xlink:href="#poly-bb91db81-0760-4962-a876-9ac5283798db"/>
							<gml:surfaceMember xlink:href="#poly-74b200d3-7011-4e8b-b320-bc47bc3de25c"/>
							<gml:surfaceMember xlink:href="#poly-f3913981-5c82-445a-bffa-5a83ffc07d22"/>
							<gml:surfaceMember xlink:href="#poly-be644fca-794d-4390-b06d-68b35972cd07"/>
							<gml:surfaceMember xlink:href="#poly-e060f744-63ed-42ef-80d5-e8c391ef2304"/>
							<gml:surfaceMember xlink:href="#poly-88699a27-5cf7-448b-aa7a-ede7fbec8fc5"/>
							<gml:surfaceMember xlink:href="#poly-7dc3da0c-9df8-45bc-977d-339e93c76696"/>
							<gml:surfaceMember xlink:href="#poly-8de15721-06c8-40a9-a713-550be19386f1"/>
							<gml:surfaceMember xlink:href="#poly-c8464467-0c0f-41ab-b08f-47bf1a06ea0c"/>
							<gml:surfaceMember xlink:href="#poly-e4a7685b-3caa-4003-b96c-6cc88f988ce5"/>
							<gml:surfaceMember xlink:href="#poly-1020c612-0fd9-4454-bc6b-a2d9a125109b"/>
							<gml:surfaceMember xlink:href="#poly-c9fc46ad-b711-45e9-b416-5e6acd0a5435"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-5ab06c6d-3bd5-4c3e-a558-35534e589990">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5ab06c6d-3bd5-4c3e-a558-35534e589990">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5ab06c6d-3bd5-4c3e-a558-35534e589990">
											<gml:posList>35.667857137968014 139.7389511818307 12.959 35.667869908969614 139.73891482574325 12.959 35.66790406934567 139.73891268679463 12.959 35.66802355091339 139.738975949765 12.959 35.66800475402053 139.73902932373608 12.959 35.667857137968014 139.7389511818307 12.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3a965188-c818-4349-b18f-a156b3e80df9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a965188-c818-4349-b18f-a156b3e80df9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a965188-c818-4349-b18f-a156b3e80df9">
											<gml:posList>35.667869908969614 139.73891482574325 25.337 35.667857137968014 139.7389511818307 25.337 35.667858931015544 139.73895030709318 25.337 35.66787082963418 139.73891643736255 25.337 35.667869908969614 139.73891482574325 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-8594e0b3-7d02-4a6e-b515-a66a0a8c404f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8594e0b3-7d02-4a6e-b515-a66a0a8c404f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8594e0b3-7d02-4a6e-b515-a66a0a8c404f">
											<gml:posList>35.667858931015544 139.73895030709318 25.337 35.667857137968014 139.7389511818307 25.337 35.66789774365715 139.73897267357427 25.337 35.66789828327755 139.73897113755675 25.337 35.667858931015544 139.73895030709318 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7ce20309-0af6-4374-b9fa-7ec55b440601">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ce20309-0af6-4374-b9fa-7ec55b440601">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ce20309-0af6-4374-b9fa-7ec55b440601">
											<gml:posList>35.66790406934567 139.73891268679463 25.337 35.667869908969614 139.73891482574325 25.337 35.66787082963418 139.73891643736255 25.337 35.667903818286504 139.73891437711575 25.337 35.66790406934567 139.73891268679463 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1d1bbe19-cf5f-48be-bb5a-4739789917d0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1d1bbe19-cf5f-48be-bb5a-4739789917d0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1d1bbe19-cf5f-48be-bb5a-4739789917d0">
											<gml:posList>35.66792791079431 139.73898183932647 26.983 35.66790046876551 139.73896494927095 26.983 35.66789774365715 139.73897267357427 25.337 35.66792791079431 139.73898183932647 26.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-668c6d23-148e-4625-acc1-efd9907f17e7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-668c6d23-148e-4625-acc1-efd9907f17e7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-668c6d23-148e-4625-acc1-efd9907f17e7">
											<gml:posList>35.66789774365715 139.73897267357427 25.337 35.66792588719773 139.7389875745407 25.337 35.66792791079431 139.73898183932647 26.983 35.66789774365715 139.73897267357427 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bad577f8-99cc-4fdb-88d4-45e09b9a9146">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bad577f8-99cc-4fdb-88d4-45e09b9a9146">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bad577f8-99cc-4fdb-88d4-45e09b9a9146">
											<gml:posList>35.66790046876551 139.73896494927095 26.983 35.66792791079431 139.73898183932647 26.983 35.66793757308139 139.73895827804972 26.983 35.66791983450269 139.73894735242044 26.983 35.66790385146847 139.73895670503495 26.983 35.66790046876551 139.73896494927095 26.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e57d424-3122-423b-917e-525797d25ab6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e57d424-3122-423b-917e-525797d25ab6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e57d424-3122-423b-917e-525797d25ab6">
											<gml:posList>35.66793757308139 139.73895827804972 25.097 35.6679264358234 139.73898602746618 25.097 35.667940205512075 139.7389933236656 25.097 35.66795725317182 139.7389507436575 25.097 35.66796756980041 139.73895701664657 25.097 35.66796900921753 139.7389534692098 25.097 35.667985773741805 139.73896366696215 25.097 35.667987527522776 139.73895869422975 25.097 35.667903818286504 139.73891437711575 25.097 35.66787082963418 139.73891643736255 25.097 35.667858931015544 139.73895030709318 25.097 35.66789828327755 139.73897113755675 25.097 35.66790385146847 139.73895670503495 25.097 35.66791983450269 139.73894735242044 25.097 35.66793757308139 139.73895827804972 25.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f89a3632-e2b6-45b6-9cbe-f29df46a8c64">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f89a3632-e2b6-45b6-9cbe-f29df46a8c64">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f89a3632-e2b6-45b6-9cbe-f29df46a8c64">
											<gml:posList>35.6679264358234 139.73898602746618 25.337 35.66792588719773 139.7389875745407 25.337 35.667939656877664 139.7389948596944 25.337 35.667940205512075 139.7389933236656 25.337 35.6679264358234 139.73898602746618 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-722c2496-efbc-4e6d-bffa-941402cc0678">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-722c2496-efbc-4e6d-bffa-941402cc0678">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-722c2496-efbc-4e6d-bffa-941402cc0678">
											<gml:posList>35.667987527522776 139.73895869422975 25.337 35.667988067142986 139.7389571582104 25.337 35.66790406934567 139.73891268679463 25.337 35.667903818286504 139.73891437711575 25.337 35.667987527522776 139.73895869422975 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2499e3e0-6f15-4770-8fef-bcd8f0cb0092">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2499e3e0-6f15-4770-8fef-bcd8f0cb0092">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2499e3e0-6f15-4770-8fef-bcd8f0cb0092">
											<gml:posList>35.66794150959458 139.73898961070105 27.519 35.667943518997745 139.73898876884664 27.519 35.66795793113192 139.73895320610092 27.519 35.66795725317182 139.7389507436575 27.519 35.66794150959458 139.73898961070105 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c560ab3f-d79d-4eb6-9af7-e60bd7658e0a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c560ab3f-d79d-4eb6-9af7-e60bd7658e0a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c560ab3f-d79d-4eb6-9af7-e60bd7658e0a">
											<gml:posList>35.66794150959458 139.73898961070105 27.519 35.667939656877664 139.7389948596944 25.337 35.667966745368126 139.73900919857513 25.337 35.66794150959458 139.73898961070105 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-cae37fdc-10d3-45c0-9457-4ab772b7dbfb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cae37fdc-10d3-45c0-9457-4ab772b7dbfb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cae37fdc-10d3-45c0-9457-4ab772b7dbfb">
											<gml:posList>35.667966745368126 139.73900919857513 25.337 35.667968590741914 139.73900608145294 27.519 35.66794150959458 139.73898961070105 27.519 35.667966745368126 139.73900919857513 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-15ac4b57-b491-4318-b4db-586950d87753">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-15ac4b57-b491-4318-b4db-586950d87753">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-15ac4b57-b491-4318-b4db-586950d87753">
											<gml:posList>35.667968590741914 139.73900608145294 27.519 35.66796790376917 139.73900361901937 27.519 35.667943518997745 139.73898876884664 27.519 35.66794150959458 139.73898961070105 27.519 35.667968590741914 139.73900608145294 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-417c1164-9756-46fa-98ad-182cafc19a2a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-417c1164-9756-46fa-98ad-182cafc19a2a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-417c1164-9756-46fa-98ad-182cafc19a2a">
											<gml:posList>35.66796756980041 139.73895701664657 27.519 35.66795725317182 139.7389507436575 27.519 35.66795793113192 139.73895320610092 27.519 35.66796823875531 139.73895949014687 27.519 35.66796756980041 139.73895701664657 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7a7124c3-a5ed-4d7d-be75-11810c0a1e51">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7a7124c3-a5ed-4d7d-be75-11810c0a1e51">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7a7124c3-a5ed-4d7d-be75-11810c0a1e51">
											<gml:posList>35.66796790376917 139.73900361901937 27.07 35.6679837553251 139.73896450882822 27.07 35.66796967817252 139.7389559427101 27.07 35.66796823875531 139.73895949014687 27.07 35.66795793113192 139.73895320610092 27.07 35.667943518997745 139.73898876884664 27.07 35.66796790376917 139.73900361901937 27.07</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-e115d218-988a-4676-ab23-08bf13a489f6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e115d218-988a-4676-ab23-08bf13a489f6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e115d218-988a-4676-ab23-08bf13a489f6">
											<gml:posList>35.66796756980041 139.73895701664657 27.519 35.66796823875531 139.73895949014687 27.519 35.66796967817252 139.7389559427101 27.519 35.66796900921753 139.7389534692098 27.519 35.66796756980041 139.73895701664657 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-6b8fc75c-e647-4813-add1-9f37b811c90b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6b8fc75c-e647-4813-add1-9f37b811c90b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6b8fc75c-e647-4813-add1-9f37b811c90b">
											<gml:posList>35.667985773741805 139.73896366696215 27.519 35.6679837553251 139.73896450882822 27.519 35.66796790376917 139.73900361901937 27.519 35.667968590741914 139.73900608145294 27.519 35.667985773741805 139.73896366696215 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0ed6eca7-d24b-4ef2-a00f-e44748436d9b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0ed6eca7-d24b-4ef2-a00f-e44748436d9b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0ed6eca7-d24b-4ef2-a00f-e44748436d9b">
											<gml:posList>35.66796900921753 139.7389534692098 27.519 35.66796967817252 139.7389559427101 27.519 35.6679837553251 139.73896450882822 27.519 35.667985773741805 139.73896366696215 27.519 35.66796900921753 139.7389534692098 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d932009b-f96f-44b1-96a8-d4c27e95be32">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d932009b-f96f-44b1-96a8-d4c27e95be32">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d932009b-f96f-44b1-96a8-d4c27e95be32">
											<gml:posList>35.66796816688914 139.7390058168493 22.301 35.667966745368126 139.73900919857513 22.301 35.66800475402053 139.73902932373608 22.301 35.66800597717957 139.73902586492076 22.301 35.66796816688914 139.7390058168493 22.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-36e97325-80b7-4d30-8c4d-83f75bec5d1f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36e97325-80b7-4d30-8c4d-83f75bec5d1f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36e97325-80b7-4d30-8c4d-83f75bec5d1f">
											<gml:posList>35.66796816688914 139.7390058168493 22.301 35.66800597717957 139.73902586492076 22.301 35.66801759707725 139.7389928680959 27.232 35.66796816688914 139.7390058168493 22.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-aa7ec8b3-8980-49b4-ad4b-298036183c96">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-aa7ec8b3-8980-49b4-ad4b-298036183c96">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-aa7ec8b3-8980-49b4-ad4b-298036183c96">
											<gml:posList>35.66801759707725 139.7389928680959 27.232 35.66798301186024 139.7389704745049 27.232 35.66796816688914 139.7390058168493 22.301 35.66801759707725 139.7389928680959 27.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-06e0a861-a748-444f-8fa2-42e21ca89898">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-06e0a861-a748-444f-8fa2-42e21ca89898">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-06e0a861-a748-444f-8fa2-42e21ca89898">
											<gml:posList>35.66801759707725 139.7389928680959 27.232 35.6680235599098 139.73897592766255 27.232 35.66798807615671 139.7389571581998 27.232 35.667985773741805 139.73896366696215 27.232 35.66798301186024 139.7389704745049 27.232 35.66801759707725 139.7389928680959 27.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f8fce694-9941-4a1e-9d4b-628054bfff83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f8fce694-9941-4a1e-9d4b-628054bfff83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f8fce694-9941-4a1e-9d4b-628054bfff83">
											<gml:posList>35.667903818286504 139.73891437711575 25.337 35.667903818286504 139.73891437711575 25.097 35.667987527522776 139.73895869422975 25.097 35.667987527522776 139.73895869422975 25.337 35.667903818286504 139.73891437711575 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-dd46800e-9b9e-4d5e-8fcf-9bbfd6462183">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-dd46800e-9b9e-4d5e-8fcf-9bbfd6462183">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-dd46800e-9b9e-4d5e-8fcf-9bbfd6462183">
											<gml:posList>35.667869908969614 139.73891482574325 12.959 35.667857137968014 139.7389511818307 12.959 35.667857137968014 139.7389511818307 25.337 35.667869908969614 139.73891482574325 25.337 35.667869908969614 139.73891482574325 12.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-9163e698-d931-403b-8c2d-888d7e3e1523">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9163e698-d931-403b-8c2d-888d7e3e1523">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9163e698-d931-403b-8c2d-888d7e3e1523">
											<gml:posList>35.667858931015544 139.73895030709318 25.337 35.667858931015544 139.73895030709318 25.097 35.66787082963418 139.73891643736255 25.097 35.66787082963418 139.73891643736255 25.337 35.667858931015544 139.73895030709318 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-265f9d0b-a91b-4bb7-9381-937e978f99c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-265f9d0b-a91b-4bb7-9381-937e978f99c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-265f9d0b-a91b-4bb7-9381-937e978f99c7">
											<gml:posList>35.66789828327755 139.73897113755675 25.337 35.66789828327755 139.73897113755675 25.097 35.667858931015544 139.73895030709318 25.097 35.667858931015544 139.73895030709318 25.337 35.66789828327755 139.73897113755675 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0c4d1b38-8876-4a01-8324-969e75878cea">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0c4d1b38-8876-4a01-8324-969e75878cea">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0c4d1b38-8876-4a01-8324-969e75878cea">
											<gml:posList>35.66790406934567 139.73891268679463 12.959 35.667869908969614 139.73891482574325 12.959 35.667869908969614 139.73891482574325 25.337 35.66790406934567 139.73891268679463 25.337 35.66790406934567 139.73891268679463 12.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d100597c-0c51-4dc0-93a9-17fcab38f417">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d100597c-0c51-4dc0-93a9-17fcab38f417">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d100597c-0c51-4dc0-93a9-17fcab38f417">
											<gml:posList>35.66787082963418 139.73891643736255 25.337 35.66787082963418 139.73891643736255 25.097 35.667903818286504 139.73891437711575 25.097 35.667903818286504 139.73891437711575 25.337 35.66787082963418 139.73891643736255 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ff456819-5d4f-46f4-9adb-3bbb50888a7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ff456819-5d4f-46f4-9adb-3bbb50888a7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ff456819-5d4f-46f4-9adb-3bbb50888a7f">
											<gml:posList>35.66789828327755 139.73897113755675 25.337 35.66789774365715 139.73897267357427 25.337 35.66790046876551 139.73896494927095 26.983 35.66789828327755 139.73897113755675 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-34b604ce-bc5d-4000-9666-6603813432bc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-34b604ce-bc5d-4000-9666-6603813432bc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-34b604ce-bc5d-4000-9666-6603813432bc">
											<gml:posList>35.66789828327755 139.73897113755675 25.337 35.66790046876551 139.73896494927095 26.983 35.66789828327755 139.73897113755675 25.097 35.66789828327755 139.73897113755675 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ef6a9458-5d0e-407a-86ac-a9e1871b669c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ef6a9458-5d0e-407a-86ac-a9e1871b669c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ef6a9458-5d0e-407a-86ac-a9e1871b669c">
											<gml:posList>35.66790046876551 139.73896494927095 26.983 35.66790385146847 139.73895670503495 26.983 35.66789828327755 139.73897113755675 25.097 35.66790046876551 139.73896494927095 26.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a322c903-bbae-4850-bd6e-9391dc290409">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a322c903-bbae-4850-bd6e-9391dc290409">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a322c903-bbae-4850-bd6e-9391dc290409">
											<gml:posList>35.66790385146847 139.73895670503495 26.983 35.66790385146847 139.73895670503495 25.097 35.66789828327755 139.73897113755675 25.097 35.66790385146847 139.73895670503495 26.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-318da24c-4263-4314-949e-140953e7e0b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-318da24c-4263-4314-949e-140953e7e0b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-318da24c-4263-4314-949e-140953e7e0b6">
											<gml:posList>35.66790385146847 139.73895670503495 26.983 35.66791983450269 139.73894735242044 26.983 35.66791983450269 139.73894735242044 25.097 35.66790385146847 139.73895670503495 25.097 35.66790385146847 139.73895670503495 26.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6dbd165f-ae8b-4854-adf4-952cecd711f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6dbd165f-ae8b-4854-adf4-952cecd711f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6dbd165f-ae8b-4854-adf4-952cecd711f1">
											<gml:posList>35.66791983450269 139.73894735242044 25.097 35.66791983450269 139.73894735242044 26.983 35.66793757308139 139.73895827804972 26.983 35.66793757308139 139.73895827804972 25.337 35.66793757308139 139.73895827804972 25.097 35.66791983450269 139.73894735242044 25.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6eb06889-2396-4a36-9b90-ead2eaa0ff34">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6eb06889-2396-4a36-9b90-ead2eaa0ff34">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6eb06889-2396-4a36-9b90-ead2eaa0ff34">
											<gml:posList>35.66789774365715 139.73897267357427 25.337 35.667857137968014 139.7389511818307 25.337 35.667857137968014 139.7389511818307 12.959 35.66800475402053 139.73902932373608 12.959 35.66800475402053 139.73902932373608 22.301 35.667966745368126 139.73900919857513 22.301 35.667966745368126 139.73900919857513 25.337 35.667939656877664 139.7389948596944 25.337 35.66792588719773 139.7389875745407 25.337 35.66789774365715 139.73897267357427 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f679fcc2-61d1-45ff-98a4-e87867a60e61">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f679fcc2-61d1-45ff-98a4-e87867a60e61">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f679fcc2-61d1-45ff-98a4-e87867a60e61">
											<gml:posList>35.66793757308139 139.73895827804972 26.983 35.66792588719773 139.7389875745407 25.337 35.6679264358234 139.73898602746618 25.337 35.66793757308139 139.73895827804972 26.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6887804c-b160-4c0e-86a4-2cc35ea580d4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6887804c-b160-4c0e-86a4-2cc35ea580d4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6887804c-b160-4c0e-86a4-2cc35ea580d4">
											<gml:posList>35.66793757308139 139.73895827804972 26.983 35.66792791079431 139.73898183932647 26.983 35.66792588719773 139.7389875745407 25.337 35.66793757308139 139.73895827804972 26.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ec581363-2a7a-47d0-b5fb-52bf32300206">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ec581363-2a7a-47d0-b5fb-52bf32300206">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ec581363-2a7a-47d0-b5fb-52bf32300206">
											<gml:posList>35.6679264358234 139.73898602746618 25.337 35.6679264358234 139.73898602746618 25.097 35.66793757308139 139.73895827804972 25.097 35.66793757308139 139.73895827804972 25.337 35.6679264358234 139.73898602746618 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39d432c4-67d6-46e3-83a0-71bce94f5537">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39d432c4-67d6-46e3-83a0-71bce94f5537">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39d432c4-67d6-46e3-83a0-71bce94f5537">
											<gml:posList>35.66793757308139 139.73895827804972 26.983 35.6679264358234 139.73898602746618 25.337 35.66793757308139 139.73895827804972 25.337 35.66793757308139 139.73895827804972 26.983</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6844d9fc-2a8f-47c2-87c6-64627cdad330">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6844d9fc-2a8f-47c2-87c6-64627cdad330">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6844d9fc-2a8f-47c2-87c6-64627cdad330">
											<gml:posList>35.667940205512075 139.7389933236656 25.337 35.667940205512075 139.7389933236656 25.097 35.6679264358234 139.73898602746618 25.097 35.6679264358234 139.73898602746618 25.337 35.667940205512075 139.7389933236656 25.337</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1988bb83-c501-4016-bd64-c9afeec866de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1988bb83-c501-4016-bd64-c9afeec866de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1988bb83-c501-4016-bd64-c9afeec866de">
											<gml:posList>35.66795725317182 139.7389507436575 27.519 35.667940205512075 139.7389933236656 25.337 35.667939656877664 139.7389948596944 25.337 35.66795725317182 139.7389507436575 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-48dc7276-e199-40ec-9b8e-656ea1845e63">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-48dc7276-e199-40ec-9b8e-656ea1845e63">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-48dc7276-e199-40ec-9b8e-656ea1845e63">
											<gml:posList>35.66795725317182 139.7389507436575 27.519 35.667939656877664 139.7389948596944 25.337 35.66794150959458 139.73898961070105 27.519 35.66795725317182 139.7389507436575 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e39820c0-3aa9-4a22-9b7f-c5ad194e5cf3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e39820c0-3aa9-4a22-9b7f-c5ad194e5cf3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e39820c0-3aa9-4a22-9b7f-c5ad194e5cf3">
											<gml:posList>35.66795725317182 139.7389507436575 27.519 35.66795725317182 139.7389507436575 25.097 35.667940205512075 139.7389933236656 25.097 35.66795725317182 139.7389507436575 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45f8f280-fee6-4ffa-b2bb-720e88b8e4c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45f8f280-fee6-4ffa-b2bb-720e88b8e4c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45f8f280-fee6-4ffa-b2bb-720e88b8e4c7">
											<gml:posList>35.66795725317182 139.7389507436575 27.519 35.667940205512075 139.7389933236656 25.097 35.667940205512075 139.7389933236656 25.337 35.66795725317182 139.7389507436575 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3a0cb637-38d8-4a2b-97b8-52adb498d1c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3a0cb637-38d8-4a2b-97b8-52adb498d1c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3a0cb637-38d8-4a2b-97b8-52adb498d1c5">
											<gml:posList>35.667943518997745 139.73898876884664 27.519 35.667943518997745 139.73898876884664 27.07 35.66795793113192 139.73895320610092 27.07 35.66795793113192 139.73895320610092 27.519 35.667943518997745 139.73898876884664 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f57af27b-ba68-4023-add4-ec9124d5ecd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f57af27b-ba68-4023-add4-ec9124d5ecd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f57af27b-ba68-4023-add4-ec9124d5ecd0">
											<gml:posList>35.66796790376917 139.73900361901937 27.519 35.66796790376917 139.73900361901937 27.07 35.667943518997745 139.73898876884664 27.07 35.667943518997745 139.73898876884664 27.519 35.66796790376917 139.73900361901937 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-856420ee-8258-4c2c-9a7a-8989515cb5d1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-856420ee-8258-4c2c-9a7a-8989515cb5d1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-856420ee-8258-4c2c-9a7a-8989515cb5d1">
											<gml:posList>35.66795725317182 139.7389507436575 27.519 35.66796756980041 139.73895701664657 27.519 35.66796756980041 139.73895701664657 25.097 35.66795725317182 139.7389507436575 25.097 35.66795725317182 139.7389507436575 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-78612b13-25b5-40cd-9ede-1eacddbacc0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-78612b13-25b5-40cd-9ede-1eacddbacc0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-78612b13-25b5-40cd-9ede-1eacddbacc0c">
											<gml:posList>35.66795793113192 139.73895320610092 27.519 35.66795793113192 139.73895320610092 27.07 35.66796823875531 139.73895949014687 27.07 35.66796823875531 139.73895949014687 27.519 35.66795793113192 139.73895320610092 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-36e04759-1b23-41a5-930d-f1f16541ea78">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-36e04759-1b23-41a5-930d-f1f16541ea78">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-36e04759-1b23-41a5-930d-f1f16541ea78">
											<gml:posList>35.66802355091339 139.738975949765 12.959 35.66790406934567 139.73891268679463 12.959 35.66790406934567 139.73891268679463 25.337 35.667988067142986 139.7389571582104 25.337 35.66798807615671 139.7389571581998 27.232 35.6680235599098 139.73897592766255 27.232 35.66802355091339 139.738975949765 12.959</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bb91db81-0760-4962-a876-9ac5283798db">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bb91db81-0760-4962-a876-9ac5283798db">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bb91db81-0760-4962-a876-9ac5283798db">
											<gml:posList>35.667968590741914 139.73900608145294 27.519 35.667966745368126 139.73900919857513 25.337 35.667966745368126 139.73900919857513 22.301 35.667968590741914 139.73900608145294 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-74b200d3-7011-4e8b-b320-bc47bc3de25c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-74b200d3-7011-4e8b-b320-bc47bc3de25c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-74b200d3-7011-4e8b-b320-bc47bc3de25c">
											<gml:posList>35.66796756980041 139.73895701664657 27.519 35.66796900921753 139.7389534692098 27.519 35.66796900921753 139.7389534692098 25.097 35.66796756980041 139.73895701664657 25.097 35.66796756980041 139.73895701664657 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f3913981-5c82-445a-bffa-5a83ffc07d22">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f3913981-5c82-445a-bffa-5a83ffc07d22">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f3913981-5c82-445a-bffa-5a83ffc07d22">
											<gml:posList>35.66796823875531 139.73895949014687 27.519 35.66796823875531 139.73895949014687 27.07 35.66796967817252 139.7389559427101 27.07 35.66796967817252 139.7389559427101 27.519 35.66796823875531 139.73895949014687 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-be644fca-794d-4390-b06d-68b35972cd07">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-be644fca-794d-4390-b06d-68b35972cd07">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-be644fca-794d-4390-b06d-68b35972cd07">
											<gml:posList>35.667968590741914 139.73900608145294 27.519 35.667966745368126 139.73900919857513 22.301 35.66798301186024 139.7389704745049 27.232 35.667968590741914 139.73900608145294 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e060f744-63ed-42ef-80d5-e8c391ef2304">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e060f744-63ed-42ef-80d5-e8c391ef2304">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e060f744-63ed-42ef-80d5-e8c391ef2304">
											<gml:posList>35.667966745368126 139.73900919857513 22.301 35.66796816688914 139.7390058168493 22.301 35.66798301186024 139.7389704745049 27.232 35.667966745368126 139.73900919857513 22.301</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-88699a27-5cf7-448b-aa7a-ede7fbec8fc5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88699a27-5cf7-448b-aa7a-ede7fbec8fc5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88699a27-5cf7-448b-aa7a-ede7fbec8fc5">
											<gml:posList>35.6679837553251 139.73896450882822 27.519 35.6679837553251 139.73896450882822 27.07 35.66796790376917 139.73900361901937 27.07 35.66796790376917 139.73900361901937 27.519 35.6679837553251 139.73896450882822 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7dc3da0c-9df8-45bc-977d-339e93c76696">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7dc3da0c-9df8-45bc-977d-339e93c76696">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7dc3da0c-9df8-45bc-977d-339e93c76696">
											<gml:posList>35.66796967817252 139.7389559427101 27.519 35.66796967817252 139.7389559427101 27.07 35.6679837553251 139.73896450882822 27.07 35.6679837553251 139.73896450882822 27.519 35.66796967817252 139.7389559427101 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8de15721-06c8-40a9-a713-550be19386f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8de15721-06c8-40a9-a713-550be19386f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8de15721-06c8-40a9-a713-550be19386f1">
											<gml:posList>35.667968590741914 139.73900608145294 27.519 35.66798301186024 139.7389704745049 27.232 35.667985773741805 139.73896366696215 27.519 35.667968590741914 139.73900608145294 27.519</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c8464467-0c0f-41ab-b08f-47bf1a06ea0c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8464467-0c0f-41ab-b08f-47bf1a06ea0c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8464467-0c0f-41ab-b08f-47bf1a06ea0c">
											<gml:posList>35.66796900921753 139.7389534692098 25.097 35.66796900921753 139.7389534692098 27.519 35.667985773741805 139.73896366696215 27.519 35.667985773741805 139.73896366696215 27.232 35.667985773741805 139.73896366696215 25.097 35.66796900921753 139.7389534692098 25.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e4a7685b-3caa-4003-b96c-6cc88f988ce5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e4a7685b-3caa-4003-b96c-6cc88f988ce5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e4a7685b-3caa-4003-b96c-6cc88f988ce5">
											<gml:posList>35.66798301186024 139.7389704745049 27.232 35.667985773741805 139.73896366696215 27.232 35.667985773741805 139.73896366696215 27.519 35.66798301186024 139.7389704745049 27.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1020c612-0fd9-4454-bc6b-a2d9a125109b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1020c612-0fd9-4454-bc6b-a2d9a125109b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1020c612-0fd9-4454-bc6b-a2d9a125109b">
											<gml:posList>35.667985773741805 139.73896366696215 25.097 35.667985773741805 139.73896366696215 27.232 35.66798807615671 139.7389571581998 27.232 35.667988067142986 139.7389571582104 25.337 35.667987527522776 139.73895869422975 25.337 35.667987527522776 139.73895869422975 25.097 35.667985773741805 139.73896366696215 25.097</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9fc46ad-b711-45e9-b416-5e6acd0a5435">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9fc46ad-b711-45e9-b416-5e6acd0a5435">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9fc46ad-b711-45e9-b416-5e6acd0a5435">
											<gml:posList>35.6680235599098 139.73897592766255 27.232 35.66801759707725 139.7389928680959 27.232 35.66800597717957 139.73902586492076 22.301 35.66800475402053 139.73902932373608 22.301 35.66800475402053 139.73902932373608 12.959 35.66802355091339 139.738975949765 12.959 35.6680235599098 139.73897592766255 27.232</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-4262</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">91.04995</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">211</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1320</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">1</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>