<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6af7df7c-f589-4715-9281-f871a4608884">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>18</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103018002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3001</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">402</bldg:usage>
			<bldg:measuredHeight uom="m">6.4</bldg:measuredHeight>
			<bldg:storeysAboveGround>2</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.6688562861437 139.74797683764086 0 35.66884423499195 139.7480152907187 0 35.6689223199226 139.74805199100962 0 35.668934371085854 139.7480135378997 0 35.6688562861437 139.74797683764086 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688562861437 139.74797683764086 5.76 35.668934371085854 139.7480135378997 5.76 35.6689223199226 139.74805199100962 5.76 35.66884423499195 139.7480152907187 5.76 35.6688562861437 139.74797683764086 5.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688562861437 139.74797683764086 5.76 35.66884423499195 139.7480152907187 5.76 35.66884423499195 139.7480152907187 12.2 35.6688562861437 139.74797683764086 12.2 35.6688562861437 139.74797683764086 5.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884423499195 139.7480152907187 5.76 35.6689223199226 139.74805199100962 5.76 35.6689223199226 139.74805199100962 12.2 35.66884423499195 139.7480152907187 12.2 35.66884423499195 139.7480152907187 5.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689223199226 139.74805199100962 5.76 35.668934371085854 139.7480135378997 5.76 35.668934371085854 139.7480135378997 12.2 35.6689223199226 139.74805199100962 12.2 35.6689223199226 139.74805199100962 5.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668934371085854 139.7480135378997 5.76 35.6688562861437 139.74797683764086 5.76 35.6688562861437 139.74797683764086 12.2 35.668934371085854 139.7480135378997 12.2 35.668934371085854 139.7480135378997 5.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688562861437 139.74797683764086 12.2 35.66884423499195 139.7480152907187 12.2 35.6689223199226 139.74805199100962 12.2 35.668934371085854 139.7480135378997 12.2 35.6688562861437 139.74797683764086 12.2</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-de367176-57f2-4f03-9d26-bb82a366c2b1"/>
							<gml:surfaceMember xlink:href="#poly-b1001c6b-b571-43a7-9bf9-6f0d9531e347"/>
							<gml:surfaceMember xlink:href="#poly-1868add5-63cb-49de-88d0-5ab07e68fc14"/>
							<gml:surfaceMember xlink:href="#poly-fe9f59bd-f711-4213-baeb-6b749d7b2a7f"/>
							<gml:surfaceMember xlink:href="#poly-7abd81fb-2bb5-4761-b9b4-41391c4aa323"/>
							<gml:surfaceMember xlink:href="#poly-b8f08ebc-cf5c-4bdf-80e6-3dae6af07d46"/>
							<gml:surfaceMember xlink:href="#poly-3113c065-41cd-4e1a-b739-08306320f8aa"/>
							<gml:surfaceMember xlink:href="#poly-b8052b14-d785-4f95-8f4d-ab2df27d05aa"/>
							<gml:surfaceMember xlink:href="#poly-2303866c-1257-4071-bb3f-e336f4ffbd30"/>
							<gml:surfaceMember xlink:href="#poly-5265bb84-a5fd-46c8-84a5-897daee39d7c"/>
							<gml:surfaceMember xlink:href="#poly-30445b8b-b3c5-4041-a07e-f6f7ba0a34e2"/>
							<gml:surfaceMember xlink:href="#poly-b759c860-d96c-439a-99a7-9a6ff2f0e4da"/>
							<gml:surfaceMember xlink:href="#poly-b193f377-a7dc-4570-a081-44bcb6421dd0"/>
							<gml:surfaceMember xlink:href="#poly-2d36d874-4d66-4d79-92c8-4ac93ddef3ee"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6af7df7c-f589-4715-9281-f871a4608884_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79f02c2e-18b2-4e81-a5bc-55b21795ddd8">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6688573879559 139.7479798520397 14.3 35.66884669479237 139.74801395152943 14.3 35.66885730749422 139.7480189440976 14.3 35.66885673192264 139.7480207894004 14.3 35.66884463146289 139.74801510251405 14.3 35.668856412555094 139.74797714679568 14.3 35.668868494989155 139.74798283369634 14.3 35.66886789245526 139.74798478948892 14.3 35.6688573879559 139.7479798520397 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b44a0dda-81b5-4afa-847b-723596353362">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66884669479237 139.74801395152943 13.905 35.6688573879559 139.7479798520397 13.905 35.66886789245526 139.74798478948892 13.905 35.66885730749422 139.7480189440976 13.905 35.66884669479237 139.74801395152943 13.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1ccf8b24-109c-4b20-9efd-6c98285c9365">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1ccf8b24-109c-4b20-9efd-6c98285c9365_0">
											<gml:posList>35.668856412555094 139.74797714679568 14.3 35.668856412555094 139.74797714679568 14.723 35.668868494989155 139.74798283369634 14.723 35.668868494989155 139.74798283369634 14.3 35.668856412555094 139.74797714679568 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba92f08f-c9fe-466d-bb40-d5124f53b198">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba92f08f-c9fe-466d-bb40-d5124f53b198_0">
											<gml:posList>35.6688573879559 139.7479798520397 14.3 35.66886789245526 139.74798478948892 14.3 35.66886789245526 139.74798478948892 13.905 35.6688573879559 139.7479798520397 13.905 35.6688573879559 139.7479798520397 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-88a07fa5-07b0-45d0-8b89-396fb153e1b5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-88a07fa5-07b0-45d0-8b89-396fb153e1b5_0">
											<gml:posList>35.66884463146289 139.74801510251405 14.3 35.66884463146289 139.74801510251405 14.723 35.668856412555094 139.74797714679568 14.723 35.668856412555094 139.74797714679568 14.3 35.66884463146289 139.74801510251405 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1c1e333-5221-44e1-95c7-ece96445c25a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b1c1e333-5221-44e1-95c7-ece96445c25a_0">
											<gml:posList>35.6688573879559 139.7479798520397 13.905 35.66884669479237 139.74801395152943 13.905 35.66884669479237 139.74801395152943 14.3 35.6688573879559 139.7479798520397 14.3 35.6688573879559 139.7479798520397 13.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-53cd78ee-15dd-4203-bed3-db546160e442">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-53cd78ee-15dd-4203-bed3-db546160e442_0">
											<gml:posList>35.66884463146289 139.74801510251405 14.723 35.66885673192264 139.7480207894004 14.723 35.668868494989155 139.74798283369634 14.723 35.668856412555094 139.74797714679568 14.723 35.66884463146289 139.74801510251405 14.723</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4522073-de96-440d-abc2-c5f3e4ffc186">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a4522073-de96-440d-abc2-c5f3e4ffc186_0">
											<gml:posList>35.66885730749422 139.7480189440976 14.3 35.66885730749422 139.7480189440976 13.905 35.66886789245526 139.74798478948892 13.905 35.66886789245526 139.74798478948892 14.3 35.668868494989155 139.74798283369634 14.3 35.668868494989155 139.74798283369634 14.723 35.66885673192264 139.7480207894004 14.723 35.66885673192264 139.7480207894004 14.3 35.66885730749422 139.7480189440976 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9ae802da-5b9e-4357-a982-bce8492a2049">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9ae802da-5b9e-4357-a982-bce8492a2049_0">
											<gml:posList>35.66885730749422 139.7480189440976 13.905 35.66885730749422 139.7480189440976 14.3 35.66884669479237 139.74801395152943 14.3 35.66884669479237 139.74801395152943 13.905 35.66885730749422 139.7480189440976 13.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-974bb795-7b0f-4963-8205-0a2613969328">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-974bb795-7b0f-4963-8205-0a2613969328_0">
											<gml:posList>35.66885673192264 139.7480207894004 14.3 35.66885673192264 139.7480207894004 14.723 35.66884463146289 139.74801510251405 14.723 35.66884463146289 139.74801510251405 14.3 35.66885673192264 139.7480207894004 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-de367176-57f2-4f03-9d26-bb82a366c2b1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de367176-57f2-4f03-9d26-bb82a366c2b1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de367176-57f2-4f03-9d26-bb82a366c2b1">
											<gml:posList>35.66885628614368 139.74797683764086 5.76 35.66893437108583 139.7480135378997 5.76 35.668922319922586 139.7480519910096 5.76 35.66884423499195 139.7480152907187 5.76 35.66885628614368 139.74797683764086 5.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b1001c6b-b571-43a7-9bf9-6f0d9531e347">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b1001c6b-b571-43a7-9bf9-6f0d9531e347">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b1001c6b-b571-43a7-9bf9-6f0d9531e347">
											<gml:posList>35.66884423499195 139.7480152907187 14.3 35.66884669479237 139.74801395152943 14.3 35.6688573879559 139.7479798520397 14.3 35.66885628614368 139.74797683764086 14.3 35.66884423499195 139.7480152907187 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1868add5-63cb-49de-88d0-5ab07e68fc14">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1868add5-63cb-49de-88d0-5ab07e68fc14">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1868add5-63cb-49de-88d0-5ab07e68fc14">
											<gml:posList>35.668922319922586 139.7480519910096 14.3 35.66892122712591 139.74804897659772 14.3 35.66884669479237 139.74801395152943 14.3 35.66884423499195 139.7480152907187 14.3 35.668922319922586 139.7480519910096 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-fe9f59bd-f711-4213-baeb-6b749d7b2a7f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fe9f59bd-f711-4213-baeb-6b749d7b2a7f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fe9f59bd-f711-4213-baeb-6b749d7b2a7f">
											<gml:posList>35.66893190227173 139.74801487710008 13.905 35.6688573879559 139.7479798520397 13.905 35.66884669479237 139.74801395152943 13.905 35.66892122712591 139.74804897659772 13.905 35.66893190227173 139.74801487710008 13.905</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7abd81fb-2bb5-4761-b9b4-41391c4aa323">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7abd81fb-2bb5-4761-b9b4-41391c4aa323">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7abd81fb-2bb5-4761-b9b4-41391c4aa323">
											<gml:posList>35.66885628614368 139.74797683764086 14.3 35.6688573879559 139.7479798520397 14.3 35.66893190227173 139.74801487710008 14.3 35.66893437108583 139.7480135378997 14.3 35.66885628614368 139.74797683764086 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-b8f08ebc-cf5c-4bdf-80e6-3dae6af07d46">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8f08ebc-cf5c-4bdf-80e6-3dae6af07d46">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8f08ebc-cf5c-4bdf-80e6-3dae6af07d46">
											<gml:posList>35.66893437108583 139.7480135378997 14.3 35.66893190227173 139.74801487710008 14.3 35.66892122712591 139.74804897659772 14.3 35.668922319922586 139.7480519910096 14.3 35.66893437108583 139.7480135378997 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-3113c065-41cd-4e1a-b739-08306320f8aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3113c065-41cd-4e1a-b739-08306320f8aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3113c065-41cd-4e1a-b739-08306320f8aa">
											<gml:posList>35.66892122712591 139.74804897659772 14.3 35.66892122712591 139.74804897659772 13.905 35.66884669479237 139.74801395152943 13.905 35.66884669479237 139.74801395152943 14.3 35.66892122712591 139.74804897659772 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b8052b14-d785-4f95-8f4d-ab2df27d05aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b8052b14-d785-4f95-8f4d-ab2df27d05aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b8052b14-d785-4f95-8f4d-ab2df27d05aa">
											<gml:posList>35.6688573879559 139.7479798520397 14.3 35.6688573879559 139.7479798520397 13.905 35.66893190227173 139.74801487710008 13.905 35.66893190227173 139.74801487710008 14.3 35.6688573879559 139.7479798520397 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2303866c-1257-4071-bb3f-e336f4ffbd30">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2303866c-1257-4071-bb3f-e336f4ffbd30">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2303866c-1257-4071-bb3f-e336f4ffbd30">
											<gml:posList>35.66893437108583 139.7480135378997 5.76 35.66885628614368 139.74797683764086 5.76 35.66885628614368 139.74797683764086 14.3 35.66893437108583 139.7480135378997 14.3 35.66893437108583 139.7480135378997 5.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5265bb84-a5fd-46c8-84a5-897daee39d7c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5265bb84-a5fd-46c8-84a5-897daee39d7c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5265bb84-a5fd-46c8-84a5-897daee39d7c">
											<gml:posList>35.66885628614368 139.74797683764086 5.76 35.66884423499195 139.7480152907187 5.76 35.66884423499195 139.7480152907187 14.3 35.66885628614368 139.74797683764086 14.3 35.66885628614368 139.74797683764086 5.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-30445b8b-b3c5-4041-a07e-f6f7ba0a34e2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-30445b8b-b3c5-4041-a07e-f6f7ba0a34e2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-30445b8b-b3c5-4041-a07e-f6f7ba0a34e2">
											<gml:posList>35.66884669479237 139.74801395152943 14.3 35.66884669479237 139.74801395152943 13.905 35.6688573879559 139.7479798520397 13.905 35.6688573879559 139.7479798520397 14.3 35.66884669479237 139.74801395152943 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b759c860-d96c-439a-99a7-9a6ff2f0e4da">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b759c860-d96c-439a-99a7-9a6ff2f0e4da">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b759c860-d96c-439a-99a7-9a6ff2f0e4da">
											<gml:posList>35.66893190227173 139.74801487710008 14.3 35.66893190227173 139.74801487710008 13.905 35.66892122712591 139.74804897659772 13.905 35.66892122712591 139.74804897659772 14.3 35.66893190227173 139.74801487710008 14.3</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-b193f377-a7dc-4570-a081-44bcb6421dd0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-b193f377-a7dc-4570-a081-44bcb6421dd0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-b193f377-a7dc-4570-a081-44bcb6421dd0">
											<gml:posList>35.668922319922586 139.7480519910096 5.76 35.66893437108583 139.7480135378997 5.76 35.66893437108583 139.7480135378997 14.3 35.668922319922586 139.7480519910096 14.3 35.668922319922586 139.7480519910096 5.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2d36d874-4d66-4d79-92c8-4ac93ddef3ee">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2d36d874-4d66-4d79-92c8-4ac93ddef3ee">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2d36d874-4d66-4d79-92c8-4ac93ddef3ee">
											<gml:posList>35.66884423499195 139.7480152907187 5.76 35.668922319922586 139.7480519910096 5.76 35.668922319922586 139.7480519910096 14.3 35.66884423499195 139.7480152907187 14.3 35.66884423499195 139.7480152907187 5.76</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区虎ノ門二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2559</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">26.94087</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1221</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.08</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>