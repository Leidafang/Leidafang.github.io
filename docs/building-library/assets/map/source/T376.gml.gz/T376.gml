<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6b43ea77-6f69-4fcb-bd81-16680f0c4df5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001001</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>1</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66739530832681 139.74128921468275 0 35.66742217404074 139.74130726590394 0 35.66742363177432 139.74130400570456 0 35.66751202978217 139.74136339727616 0 35.66753453471784 139.74131311276682 0 35.667537420604575 139.74131506457363 0 35.66755423854752 139.74127747826938 0 35.66755043279558 139.74127491999675 0 35.66757350457031 139.74122334242023 0 35.6674846645935 139.74116365322755 0 35.66748595134977 139.7411607687788 0 35.667460447388926 139.74114363283292 0 35.66739530832681 139.74128921468275 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66739530832681 139.74128921468275 24.02 35.667460447388926 139.74114363283292 24.02 35.66748595134977 139.7411607687788 24.02 35.6674846645935 139.74116365322755 24.02 35.66757350457031 139.74122334242023 24.02 35.66755043279558 139.74127491999675 24.02 35.66755423854752 139.74127747826938 24.02 35.667537420604575 139.74131506457363 24.02 35.66753453471784 139.74131311276682 24.02 35.66751202978217 139.74136339727616 24.02 35.66742363177432 139.74130400570456 24.02 35.66742217404074 139.74130726590394 24.02 35.66739530832681 139.74128921468275 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66739530832681 139.74128921468275 24.02 35.66742217404074 139.74130726590394 24.02 35.66742217404074 139.74130726590394 38.94 35.66739530832681 139.74128921468275 38.94 35.66739530832681 139.74128921468275 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66742217404074 139.74130726590394 24.02 35.66742363177432 139.74130400570456 24.02 35.66742363177432 139.74130400570456 38.94 35.66742217404074 139.74130726590394 38.94 35.66742217404074 139.74130726590394 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66742363177432 139.74130400570456 24.02 35.66751202978217 139.74136339727616 24.02 35.66751202978217 139.74136339727616 38.94 35.66742363177432 139.74130400570456 38.94 35.66742363177432 139.74130400570456 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66751202978217 139.74136339727616 24.02 35.66753453471784 139.74131311276682 24.02 35.66753453471784 139.74131311276682 38.94 35.66751202978217 139.74136339727616 38.94 35.66751202978217 139.74136339727616 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66753453471784 139.74131311276682 24.02 35.667537420604575 139.74131506457363 24.02 35.667537420604575 139.74131506457363 38.94 35.66753453471784 139.74131311276682 38.94 35.66753453471784 139.74131311276682 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667537420604575 139.74131506457363 24.02 35.66755423854752 139.74127747826938 24.02 35.66755423854752 139.74127747826938 38.94 35.667537420604575 139.74131506457363 38.94 35.667537420604575 139.74131506457363 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66755423854752 139.74127747826938 24.02 35.66755043279558 139.74127491999675 24.02 35.66755043279558 139.74127491999675 38.94 35.66755423854752 139.74127747826938 38.94 35.66755423854752 139.74127747826938 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66755043279558 139.74127491999675 24.02 35.66757350457031 139.74122334242023 24.02 35.66757350457031 139.74122334242023 38.94 35.66755043279558 139.74127491999675 38.94 35.66755043279558 139.74127491999675 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66757350457031 139.74122334242023 24.02 35.6674846645935 139.74116365322755 24.02 35.6674846645935 139.74116365322755 38.94 35.66757350457031 139.74122334242023 38.94 35.66757350457031 139.74122334242023 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6674846645935 139.74116365322755 24.02 35.66748595134977 139.7411607687788 24.02 35.66748595134977 139.7411607687788 38.94 35.6674846645935 139.74116365322755 38.94 35.6674846645935 139.74116365322755 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66748595134977 139.7411607687788 24.02 35.667460447388926 139.74114363283292 24.02 35.667460447388926 139.74114363283292 38.94 35.66748595134977 139.7411607687788 38.94 35.66748595134977 139.7411607687788 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667460447388926 139.74114363283292 24.02 35.66739530832681 139.74128921468275 24.02 35.66739530832681 139.74128921468275 38.94 35.667460447388926 139.74114363283292 38.94 35.667460447388926 139.74114363283292 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66739530832681 139.74128921468275 38.94 35.66742217404074 139.74130726590394 38.94 35.66742363177432 139.74130400570456 38.94 35.66751202978217 139.74136339727616 38.94 35.66753453471784 139.74131311276682 38.94 35.667537420604575 139.74131506457363 38.94 35.66755423854752 139.74127747826938 38.94 35.66755043279558 139.74127491999675 38.94 35.66757350457031 139.74122334242023 38.94 35.6674846645935 139.74116365322755 38.94 35.66748595134977 139.7411607687788 38.94 35.667460447388926 139.74114363283292 38.94 35.66739530832681 139.74128921468275 38.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-d5ba8cd8-356d-44a3-b42e-1e5d19e57df2"/>
							<gml:surfaceMember xlink:href="#poly-63166e0a-2044-4d1b-98fc-344bef7ff866"/>
							<gml:surfaceMember xlink:href="#poly-94fa3195-339f-48e0-8f46-21b95bd8e653"/>
							<gml:surfaceMember xlink:href="#poly-f70082e4-e98d-4188-a27c-e602056b9665"/>
							<gml:surfaceMember xlink:href="#poly-3fcba2ac-91d6-4538-a47c-dd0c406a2504"/>
							<gml:surfaceMember xlink:href="#poly-db4ab971-3a4f-4e87-851f-9cb3dce9e19f"/>
							<gml:surfaceMember xlink:href="#poly-a06f0c31-924a-4825-91f9-0f1980cbc3af"/>
							<gml:surfaceMember xlink:href="#poly-ce8285d7-b50f-4909-a5d0-c3eca568a372"/>
							<gml:surfaceMember xlink:href="#poly-bc35499d-479c-4738-b8e9-f395ce3c5704"/>
							<gml:surfaceMember xlink:href="#poly-285dc6e2-a451-4534-8e67-a430937d375a"/>
							<gml:surfaceMember xlink:href="#poly-60a4bbda-83c0-4d6f-b2aa-a5a45b86a29b"/>
							<gml:surfaceMember xlink:href="#poly-f1b3e123-0617-404e-9dba-859a3d61348e"/>
							<gml:surfaceMember xlink:href="#poly-d8e12e6f-9a62-43d1-a438-8c1721799a1c"/>
							<gml:surfaceMember xlink:href="#poly-acf44d2f-4723-4832-9840-e3a6f3a9e919"/>
							<gml:surfaceMember xlink:href="#poly-94638c98-b7c4-4f12-8af9-2cfff81e80f0"/>
							<gml:surfaceMember xlink:href="#poly-e64a48fe-ebf7-4d7c-a82f-bc25db4b191e"/>
							<gml:surfaceMember xlink:href="#poly-1724d48b-ffa8-4bec-b1b0-5d0ba75c4547"/>
							<gml:surfaceMember xlink:href="#poly-cf078faa-ef1c-43f4-b1cd-bdba3b45c52a"/>
							<gml:surfaceMember xlink:href="#poly-16e5a07f-91b6-4ea0-b478-866d7d88d1cc"/>
							<gml:surfaceMember xlink:href="#poly-d51ae157-d179-4d82-a70e-123a2e086add"/>
							<gml:surfaceMember xlink:href="#poly-de1e522c-db37-4e8f-94eb-4aa65e5f782b"/>
							<gml:surfaceMember xlink:href="#poly-29ee989b-3fa9-432e-a890-393a185a3968"/>
							<gml:surfaceMember xlink:href="#poly-6227dc2c-ab4e-4ccd-b033-63a501af1c80"/>
							<gml:surfaceMember xlink:href="#poly-bd23b916-f753-4cf4-9696-b2fe855b36a2"/>
							<gml:surfaceMember xlink:href="#poly-f6b471c9-ad68-4e5d-ab63-c1eedf91e71b"/>
							<gml:surfaceMember xlink:href="#poly-a79d1fc2-10fb-4a4c-9c3e-37d475c306d8"/>
							<gml:surfaceMember xlink:href="#poly-bba90cce-d794-4358-a22c-c9f193fe6926"/>
							<gml:surfaceMember xlink:href="#poly-0d0fb31d-b00d-4830-8a11-c35ed0f15e1a"/>
							<gml:surfaceMember xlink:href="#poly-7d0ba44d-5020-4ae3-916a-d215de0150f1"/>
							<gml:surfaceMember xlink:href="#poly-f45d57b9-7d0c-4d64-ab70-ef189fdbd748"/>
							<gml:surfaceMember xlink:href="#poly-fb5cd0c6-000b-478b-b424-36a74ecfe91e"/>
							<gml:surfaceMember xlink:href="#poly-1c79e11f-2965-43b7-9b9e-8ef44ddca7f4"/>
							<gml:surfaceMember xlink:href="#poly-40695288-fb11-4fb8-8c94-0ab02300c7d7"/>
							<gml:surfaceMember xlink:href="#poly-76570f80-913d-43e0-814e-bf506f770144"/>
							<gml:surfaceMember xlink:href="#poly-2ef6eacd-7eeb-4a59-afc8-873f1b8967e4"/>
							<gml:surfaceMember xlink:href="#poly-538d4eff-e7ea-4d72-8ab3-7b93e24a4f71"/>
							<gml:surfaceMember xlink:href="#poly-163dcb94-3d5b-4ce4-a16b-38d637aa88cb"/>
							<gml:surfaceMember xlink:href="#poly-f483d942-96cc-4679-a906-3635b33c67aa"/>
							<gml:surfaceMember xlink:href="#poly-5dffe8d9-0242-479a-b365-886ac79762f5"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6b43ea77-6f69-4fcb-bd81-16680f0c4df5_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4341bbd6-a58a-4c0e-824c-fbce35fd58cb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4341bbd6-a58a-4c0e-824c-fbce35fd58cb_0">
											<gml:posList>35.66742237165209 139.74123562228078 37.8 35.667446865547355 139.7412520856105 39.145 35.66742008099105 139.74123408953832 39.145 35.66742237165209 139.74123562228078 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ff8e387-283f-4135-9bdf-db38366f6c68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ff8e387-283f-4135-9bdf-db38366f6c68_0">
											<gml:posList>35.66742008099105 139.74123408953832 39.145 35.66742008099105 139.74123408953832 37.8 35.66742237165209 139.74123562228078 37.8 35.66742008099105 139.74123408953832 39.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8fc2adf-6998-4ace-b0c1-45fec8249e4d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8fc2adf-6998-4ace-b0c1-45fec8249e4d_0">
											<gml:posList>35.667446865547355 139.7412520856105 36.8 35.667446865547355 139.7412520856105 39.145 35.66742237165209 139.74123562228078 37.8 35.667446865547355 139.7412520856105 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-95dbd65e-aa24-4ac6-8edf-f831e8a2c53d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-95dbd65e-aa24-4ac6-8edf-f831e8a2c53d_0">
											<gml:posList>35.66742237165209 139.74123562228078 36.8 35.667446865547355 139.7412520856105 36.8 35.66742237165209 139.74123562228078 37.8 35.66742237165209 139.74123562228078 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a983d764-244c-4e34-a6b0-62857af5582f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a983d764-244c-4e34-a6b0-62857af5582f_0">
											<gml:posList>35.66742008099105 139.74123408953832 37.8 35.66745361803637 139.7411594031216 39.145 35.66745361803637 139.7411594031216 37.8 35.66742008099105 139.74123408953832 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f876800-a81d-4390-9841-d845cac27d57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f876800-a81d-4390-9841-d845cac27d57_0">
											<gml:posList>35.66742008099105 139.74123408953832 37.8 35.66742008099105 139.74123408953832 39.145 35.66745361803637 139.7411594031216 39.145 35.66742008099105 139.74123408953832 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f6401c37-4a8a-4559-aa83-998d4b4f52f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f6401c37-4a8a-4559-aa83-998d4b4f52f3_0">
											<gml:posList>35.66745466671477 139.74116343365375 37.8 35.66742237165209 139.74123562228078 36.8 35.66742237165209 139.74123562228078 37.8 35.66745466671477 139.74116343365375 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7415c9e0-6958-442f-9e4b-b0da1fca15dc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7415c9e0-6958-442f-9e4b-b0da1fca15dc_0">
											<gml:posList>35.66745466671477 139.74116343365375 37.8 35.66745466671477 139.74116343365375 36.8 35.66742237165209 139.74123562228078 36.8 35.66745466671477 139.74116343365375 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c27368d3-2831-419d-a722-7e3966ec56b2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c27368d3-2831-419d-a722-7e3966ec56b2_0">
											<gml:posList>35.667447668182966 139.74125262593574 36.8 35.667446865547355 139.7412520856105 39.145 35.667446865547355 139.7412520856105 36.8 35.667447668182966 139.74125262593574 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b97dc959-51f2-459e-a55f-8ae43aab2334">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b97dc959-51f2-459e-a55f-8ae43aab2334_0">
											<gml:posList>35.667447668182966 139.74125262593574 36.8 35.667447668182966 139.74125262593574 39.145 35.667446865547355 139.7412520856105 39.145 35.667447668182966 139.74125262593574 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-387ec925-f2b5-4418-ab55-8bf6fff0e67a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-387ec925-f2b5-4418-ab55-8bf6fff0e67a_0">
											<gml:posList>35.66745058364698 139.74124610553278 36.8 35.667447668182966 139.74125262593574 39.145 35.667447668182966 139.74125262593574 36.8 35.66745058364698 139.74124610553278 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-470205c8-b4ea-4f40-9a98-d9b637689569">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-470205c8-b4ea-4f40-9a98-d9b637689569_0">
											<gml:posList>35.66745058364698 139.74124610553278 36.8 35.66745058364698 139.74124610553278 39.145 35.667447668182966 139.74125262593574 39.145 35.66745058364698 139.74124610553278 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6e9a3ed-267f-45d6-9998-89e7193061f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6e9a3ed-267f-45d6-9998-89e7193061f8_0">
											<gml:posList>35.66748017067284 139.7411805696047 37.8 35.66745466671477 139.74116343365375 36.8 35.66745466671477 139.74116343365375 37.8 35.66748017067284 139.7411805696047 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-34f05056-6d19-4bdd-ac63-466fc231b609">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-34f05056-6d19-4bdd-ac63-466fc231b609_0">
											<gml:posList>35.66748017067284 139.7411805696047 37.8 35.66748017067284 139.7411805696047 36.8 35.66745466671477 139.74116343365375 36.8 35.66748017067284 139.7411805696047 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7df4753c-bbcd-46a1-803d-68c273ca8a6d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7df4753c-bbcd-46a1-803d-68c273ca8a6d_0">
											<gml:posList>35.667481322477215 139.74117801668731 36.8 35.66748017067284 139.7411805696047 37.8 35.667481322477215 139.74117801668731 37.8 35.667481322477215 139.74117801668731 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-83cfc108-ab65-406d-a376-b7f6d32f274e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-83cfc108-ab65-406d-a376-b7f6d32f274e_0">
											<gml:posList>35.667481322477215 139.74117801668731 36.8 35.66748017067284 139.7411805696047 36.8 35.66748017067284 139.7411805696047 37.8 35.667481322477215 139.74117801668731 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-40572936-b838-4bb7-bb2c-b8f828c92440">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-40572936-b838-4bb7-bb2c-b8f828c92440_0">
											<gml:posList>35.66751666123496 139.74129051134653 36.8 35.66745058364698 139.74124610553278 39.145 35.66745058364698 139.74124610553278 36.8 35.66751666123496 139.74129051134653 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-65538511-aa55-4e4d-bdc5-f59b048206f0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-65538511-aa55-4e4d-bdc5-f59b048206f0_0">
											<gml:posList>35.66751666123496 139.74129051134653 36.8 35.66751666123496 139.74129051134653 39.145 35.66745058364698 139.74124610553278 39.145 35.66751666123496 139.74129051134653 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3c3b18f2-3a80-47a5-b7a9-ab77b0cf65ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3c3b18f2-3a80-47a5-b7a9-ab77b0cf65ab_0">
											<gml:posList>35.66745361803637 139.7411594031216 37.8 35.66745361803637 139.7411594031216 39.145 35.667481322477215 139.74117801668731 37.8 35.66745361803637 139.7411594031216 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7f9f0f36-faa3-46a5-a31a-dc90cb454ece">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7f9f0f36-faa3-46a5-a31a-dc90cb454ece_0">
											<gml:posList>35.66745361803637 139.7411594031216 39.145 35.66755655358545 139.74122837671715 39.145 35.667481322477215 139.74117801668731 37.8 35.66745361803637 139.7411594031216 39.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08c0b956-5a68-4437-a807-8cdb7a10bea1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08c0b956-5a68-4437-a807-8cdb7a10bea1_0">
											<gml:posList>35.667481322477215 139.74117801668731 37.8 35.66755655358545 139.74122837671715 36.8 35.667481322477215 139.74117801668731 36.8 35.667481322477215 139.74117801668731 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-69ba6165-616c-4b1d-9706-eeeb0a694c37">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-69ba6165-616c-4b1d-9706-eeeb0a694c37_0">
											<gml:posList>35.667481322477215 139.74117801668731 37.8 35.66755655358545 139.74122837671715 39.145 35.66755655358545 139.74122837671715 36.8 35.667481322477215 139.74117801668731 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-427863de-3109-41db-aadd-d1ea27091d47">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-427863de-3109-41db-aadd-d1ea27091d47_0">
											<gml:posList>35.66752006261476 139.74128290788673 36.8 35.66751666123496 139.74129051134653 39.145 35.66751666123496 139.74129051134653 36.8 35.66752006261476 139.74128290788673 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6396de8f-20c8-4bea-9d58-ec5cc1741b77">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6396de8f-20c8-4bea-9d58-ec5cc1741b77_0">
											<gml:posList>35.66752006261476 139.74128290788673 36.8 35.66752006261476 139.74128290788673 39.145 35.66751666123496 139.74129051134653 39.145 35.66752006261476 139.74128290788673 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1c29dd3b-604d-45e1-8709-572ed65d07ac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1c29dd3b-604d-45e1-8709-572ed65d07ac_0">
											<gml:posList>35.66752966717365 139.74128935869317 36.8 35.66752006261476 139.74128290788673 39.145 35.66752006261476 139.74128290788673 36.8 35.66752966717365 139.74128935869317 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3ac2d41c-da1d-49b8-ae2c-cb2632c8da8b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3ac2d41c-da1d-49b8-ae2c-cb2632c8da8b_0">
											<gml:posList>35.66752966717365 139.74128935869317 36.8 35.66752966717365 139.74128935869317 39.145 35.66752006261476 139.74128290788673 39.145 35.66752966717365 139.74128935869317 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c51de0e1-b18d-45c5-b851-7e32695ee71b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c51de0e1-b18d-45c5-b851-7e32695ee71b_0">
											<gml:posList>35.66755655358545 139.74122837671715 36.8 35.66752966717365 139.74128935869317 39.145 35.66752966717365 139.74128935869317 36.8 35.66755655358545 139.74122837671715 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-05d1192d-7e45-4d7b-ac68-09f913552940">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-05d1192d-7e45-4d7b-ac68-09f913552940_0">
											<gml:posList>35.66755655358545 139.74122837671715 36.8 35.66755655358545 139.74122837671715 39.145 35.66752966717365 139.74128935869317 39.145 35.66755655358545 139.74122837671715 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1566686a-657a-4231-9039-b02deab8dea1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1566686a-657a-4231-9039-b02deab8dea1_0">
											<gml:posList>35.66745058364698 139.74124610553278 39.145 35.66742008099105 139.74123408953832 39.145 35.667446865547355 139.7412520856105 39.145 35.66745058364698 139.74124610553278 39.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-978fc167-8bdb-49e7-9fca-73b17c17a101">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-978fc167-8bdb-49e7-9fca-73b17c17a101_0">
											<gml:posList>35.667446865547355 139.7412520856105 39.145 35.667447668182966 139.74125262593574 39.145 35.66745058364698 139.74124610553278 39.145 35.667446865547355 139.7412520856105 39.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b126e060-b2e3-4207-839f-b2976b95c491">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b126e060-b2e3-4207-839f-b2976b95c491_0">
											<gml:posList>35.66745361803637 139.7411594031216 39.145 35.66742008099105 139.74123408953832 39.145 35.66745058364698 139.74124610553278 39.145 35.66745361803637 139.7411594031216 39.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ffdbf25-fbc9-4d95-8195-cbc99758c333">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8ffdbf25-fbc9-4d95-8195-cbc99758c333_0">
											<gml:posList>35.66751666123496 139.74129051134653 39.145 35.66752006261476 139.74128290788673 39.145 35.66745058364698 139.74124610553278 39.145 35.66751666123496 139.74129051134653 39.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5989bbcd-c540-4da7-be0e-5a1f0d20ff72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5989bbcd-c540-4da7-be0e-5a1f0d20ff72_0">
											<gml:posList>35.66755655358545 139.74122837671715 39.145 35.66745361803637 139.7411594031216 39.145 35.66745058364698 139.74124610553278 39.145 35.66755655358545 139.74122837671715 39.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1b35e4be-341b-439a-90da-9e3334b10d03">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1b35e4be-341b-439a-90da-9e3334b10d03_0">
											<gml:posList>35.66752966717365 139.74128935869317 39.145 35.66755655358545 139.74122837671715 39.145 35.66752006261476 139.74128290788673 39.145 35.66752966717365 139.74128935869317 39.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9b5562b4-ad28-47e2-a391-ddda3e580eb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9b5562b4-ad28-47e2-a391-ddda3e580eb0_0">
											<gml:posList>35.66752006261476 139.74128290788673 39.145 35.66755655358545 139.74122837671715 39.145 35.66745058364698 139.74124610553278 39.145 35.66752006261476 139.74128290788673 39.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-abe92523-4da8-4b38-adb8-7cb446f9c214">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667481322477215 139.74117801668731 37.8 35.66745466671477 139.74116343365375 37.8 35.66745361803637 139.7411594031216 37.8 35.667481322477215 139.74117801668731 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a4b9d0cf-0666-46fa-b43a-de616dac73d4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66745361803637 139.7411594031216 37.8 35.66745466671477 139.74116343365375 37.8 35.66742008099105 139.74123408953832 37.8 35.66745361803637 139.7411594031216 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f8fe538-cd43-421a-b5f2-ef8c3c109f0b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667481322477215 139.74117801668731 37.8 35.66748017067284 139.7411805696047 37.8 35.66745466671477 139.74116343365375 37.8 35.667481322477215 139.74117801668731 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78be8a21-c342-415f-8a28-ece55126f6cb">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66742008099105 139.74123408953832 37.8 35.66745466671477 139.74116343365375 37.8 35.66742237165209 139.74123562228078 37.8 35.66742008099105 139.74123408953832 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99ea75c5-f12b-4a32-80f7-97ef0b0403fd">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66752006261476 139.74128290788673 36.8 35.66751666123496 139.74129051134653 36.8 35.66745058364698 139.74124610553278 36.8 35.66752006261476 139.74128290788673 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-754ee57a-ad7c-49f3-bc18-5471a0003166">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66752966717365 139.74128935869317 36.8 35.66752006261476 139.74128290788673 36.8 35.66755655358545 139.74122837671715 36.8 35.66752966717365 139.74128935869317 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-11d3d491-6025-44e4-8ed5-ea841ef78d08">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667447668182966 139.74125262593574 36.8 35.667446865547355 139.7412520856105 36.8 35.66745058364698 139.74124610553278 36.8 35.667447668182966 139.74125262593574 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-198485f3-1ff0-4c14-82ad-2a0715a1848b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66748017067284 139.7411805696047 36.8 35.667481322477215 139.74117801668731 36.8 35.66755655358545 139.74122837671715 36.8 35.66748017067284 139.7411805696047 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a510637-1c32-4ea0-b6d0-934d6bb0d122">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66742237165209 139.74123562228078 36.8 35.66745466671477 139.74116343365375 36.8 35.66745058364698 139.74124610553278 36.8 35.66742237165209 139.74123562228078 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7d947e3a-43c3-46b8-86ab-9d78c6f4b78a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.667446865547355 139.7412520856105 36.8 35.66742237165209 139.74123562228078 36.8 35.66745058364698 139.74124610553278 36.8 35.667446865547355 139.7412520856105 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf0f2510-9492-4b2b-bd57-38a7b70e7383">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66745466671477 139.74116343365375 36.8 35.66748017067284 139.7411805696047 36.8 35.66745058364698 139.74124610553278 36.8 35.66745466671477 139.74116343365375 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3e17a0ea-2947-4930-8262-37a79b3ae278">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66745058364698 139.74124610553278 36.8 35.66748017067284 139.7411805696047 36.8 35.66752006261476 139.74128290788673 36.8 35.66745058364698 139.74124610553278 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8623d9fa-2ce7-471c-8c08-d3f58efd33e4">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66748017067284 139.7411805696047 36.8 35.66755655358545 139.74122837671715 36.8 35.66752006261476 139.74128290788673 36.8 35.66748017067284 139.7411805696047 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-d5ba8cd8-356d-44a3-b42e-1e5d19e57df2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d5ba8cd8-356d-44a3-b42e-1e5d19e57df2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d5ba8cd8-356d-44a3-b42e-1e5d19e57df2">
											<gml:posList>35.66755043279555 139.74127491999675 24.02 35.6675542385475 139.74127747826938 24.02 35.667537420604575 139.74131506457363 24.02 35.667534534717824 139.74131311276682 24.02 35.66751202978217 139.74136339727616 24.02 35.667423631774284 139.74130400570456 24.02 35.66742217404074 139.74130726590394 24.02 35.6673953083268 139.74128921468275 24.02 35.66746044738891 139.74114363283292 24.02 35.667485951349775 139.7411607687788 24.02 35.66748466459349 139.74116365322752 24.02 35.6675735045703 139.74122334242023 24.02 35.66755043279555 139.74127491999675 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-63166e0a-2044-4d1b-98fc-344bef7ff866">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-63166e0a-2044-4d1b-98fc-344bef7ff866">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-63166e0a-2044-4d1b-98fc-344bef7ff866">
											<gml:posList>35.667485951349775 139.7411607687788 27.6 35.66746044738891 139.74114363283292 27.6 35.6674535996538 139.74115893921677 27.6 35.667479103612514 139.74117607516604 27.6 35.66748466459349 139.74116365322752 27.6 35.667485951349775 139.7411607687788 27.6</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-94fa3195-339f-48e0-8f46-21b95bd8e653">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94fa3195-339f-48e0-8f46-21b95bd8e653">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94fa3195-339f-48e0-8f46-21b95bd8e653">
											<gml:posList>35.667479103612514 139.74117607516604 37.8 35.6674535996538 139.74115893921677 37.8 35.66745466671477 139.74116343365375 37.8 35.66748017067284 139.7411805696047 37.8 35.667479103612514 139.74117607516604 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f70082e4-e98d-4188-a27c-e602056b9665">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f70082e4-e98d-4188-a27c-e602056b9665">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f70082e4-e98d-4188-a27c-e602056b9665">
											<gml:posList>35.66748466459349 139.74116365322752 37.8 35.667479103612514 139.74117607516604 37.8 35.66748017067284 139.7411805696047 37.8 35.66748573165428 139.74116814766631 37.8 35.66748466459349 139.74116365322752 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3fcba2ac-91d6-4538-a47c-dd0c406a2504">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3fcba2ac-91d6-4538-a47c-dd0c406a2504">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3fcba2ac-91d6-4538-a47c-dd0c406a2504">
											<gml:posList>35.6675735045703 139.74122334242023 37.8 35.66748466459349 139.74116365322752 37.8 35.66748573165428 139.74116814766631 37.8 35.66756983698038 139.74122465004615 37.8 35.6675735045703 139.74122334242023 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-db4ab971-3a4f-4e87-851f-9cb3dce9e19f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-db4ab971-3a4f-4e87-851f-9cb3dce9e19f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-db4ab971-3a4f-4e87-851f-9cb3dce9e19f">
											<gml:posList>35.6674535996538 139.74115893921677 37.8 35.66741999982527 139.74123403440228 37.8 35.66742237165209 139.74123562228078 37.8 35.66745466671477 139.74116343365375 37.8 35.6674535996538 139.74115893921677 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a06f0c31-924a-4825-91f9-0f1980cbc3af">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a06f0c31-924a-4825-91f9-0f1980cbc3af">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a06f0c31-924a-4825-91f9-0f1980cbc3af">
											<gml:posList>35.66755043279555 139.74127491999675 37.8 35.6675735045703 139.74122334242023 37.8 35.66756983698038 139.74122465004615 37.8 35.667546765205046 139.74127622761992 37.8 35.66755043279555 139.74127491999675 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-ce8285d7-b50f-4909-a5d0-c3eca568a372">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ce8285d7-b50f-4909-a5d0-c3eca568a372">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ce8285d7-b50f-4909-a5d0-c3eca568a372">
											<gml:posList>35.66748017067284 139.7411805696047 36.8 35.66745466671477 139.74116343365375 36.8 35.66742237165209 139.74123562228078 36.8 35.667446865547355 139.7412520856105 36.8 35.667424936544506 139.7413010991479 36.8 35.66751096272866 139.74135890283327 36.8 35.66753346765401 139.74130860727746 36.8 35.66753635354082 139.74131055908407 36.8 35.667550570956976 139.74127878589252 36.8 35.667546765205046 139.74127622761992 36.8 35.66756983698038 139.74122465004615 36.8 35.66748574066801 139.74116814765594 36.8 35.66748017067284 139.7411805696047 36.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-bc35499d-479c-4738-b8e9-f395ce3c5704">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bc35499d-479c-4738-b8e9-f395ce3c5704">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bc35499d-479c-4738-b8e9-f395ce3c5704">
											<gml:posList>35.66742217404074 139.74130726590394 43.7 35.667446865547355 139.7412520856105 43.7 35.66741999982527 139.74123403440228 43.7 35.6673953083268 139.74128921468275 43.7 35.66742217404074 139.74130726590394 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-285dc6e2-a451-4534-8e67-a430937d375a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-285dc6e2-a451-4534-8e67-a430937d375a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-285dc6e2-a451-4534-8e67-a430937d375a">
											<gml:posList>35.6675542385475 139.74127747826938 37.8 35.66755043279555 139.74127491999675 37.8 35.667546765205046 139.74127622761992 37.8 35.667550570956976 139.74127878589252 37.8 35.6675542385475 139.74127747826938 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-60a4bbda-83c0-4d6f-b2aa-a5a45b86a29b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-60a4bbda-83c0-4d6f-b2aa-a5a45b86a29b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-60a4bbda-83c0-4d6f-b2aa-a5a45b86a29b">
											<gml:posList>35.667537420604575 139.74131506457363 37.8 35.6675542385475 139.74127747826938 37.8 35.667550570956976 139.74127878589252 37.8 35.66753635354082 139.74131055908407 37.8 35.667537420604575 139.74131506457363 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-f1b3e123-0617-404e-9dba-859a3d61348e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f1b3e123-0617-404e-9dba-859a3d61348e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f1b3e123-0617-404e-9dba-859a3d61348e">
											<gml:posList>35.667423631774284 139.74130400570456 37.8 35.66751202978217 139.74136339727616 37.8 35.66751096272866 139.74135890283327 37.8 35.667424936544506 139.7413010991479 37.8 35.667423631774284 139.74130400570456 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d8e12e6f-9a62-43d1-a438-8c1721799a1c">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d8e12e6f-9a62-43d1-a438-8c1721799a1c">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d8e12e6f-9a62-43d1-a438-8c1721799a1c">
											<gml:posList>35.66751202978217 139.74136339727616 37.8 35.667534534717824 139.74131311276682 37.8 35.66753346765401 139.74130860727746 37.8 35.66751096272866 139.74135890283327 37.8 35.66751202978217 139.74136339727616 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-acf44d2f-4723-4832-9840-e3a6f3a9e919">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-acf44d2f-4723-4832-9840-e3a6f3a9e919">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-acf44d2f-4723-4832-9840-e3a6f3a9e919">
											<gml:posList>35.667534534717824 139.74131311276682 37.8 35.667537420604575 139.74131506457363 37.8 35.66753635354082 139.74131055908407 37.8 35.66753346765401 139.74130860727746 37.8 35.667534534717824 139.74131311276682 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-94638c98-b7c4-4f12-8af9-2cfff81e80f0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-94638c98-b7c4-4f12-8af9-2cfff81e80f0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-94638c98-b7c4-4f12-8af9-2cfff81e80f0">
											<gml:posList>35.667485951349775 139.7411607687788 24.02 35.66746044738891 139.74114363283292 24.02 35.66746044738891 139.74114363283292 27.6 35.667485951349775 139.7411607687788 27.6 35.667485951349775 139.7411607687788 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-e64a48fe-ebf7-4d7c-a82f-bc25db4b191e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-e64a48fe-ebf7-4d7c-a82f-bc25db4b191e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-e64a48fe-ebf7-4d7c-a82f-bc25db4b191e">
											<gml:posList>35.66748466459349 139.74116365322752 24.02 35.667485951349775 139.7411607687788 24.02 35.667485951349775 139.7411607687788 27.6 35.66748466459349 139.74116365322752 27.6 35.66748466459349 139.74116365322752 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1724d48b-ffa8-4bec-b1b0-5d0ba75c4547">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1724d48b-ffa8-4bec-b1b0-5d0ba75c4547">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1724d48b-ffa8-4bec-b1b0-5d0ba75c4547">
											<gml:posList>35.6674535996538 139.74115893921677 37.8 35.667479103612514 139.74117607516604 37.8 35.667479103612514 139.74117607516604 27.6 35.6674535996538 139.74115893921677 27.6 35.6674535996538 139.74115893921677 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cf078faa-ef1c-43f4-b1cd-bdba3b45c52a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cf078faa-ef1c-43f4-b1cd-bdba3b45c52a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cf078faa-ef1c-43f4-b1cd-bdba3b45c52a">
											<gml:posList>35.667479103612514 139.74117607516604 37.8 35.66748466459349 139.74116365322752 37.8 35.66748466459349 139.74116365322752 27.6 35.667479103612514 139.74117607516604 27.6 35.667479103612514 139.74117607516604 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16e5a07f-91b6-4ea0-b478-866d7d88d1cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16e5a07f-91b6-4ea0-b478-866d7d88d1cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16e5a07f-91b6-4ea0-b478-866d7d88d1cc">
											<gml:posList>35.66748017067284 139.7411805696047 37.8 35.66745466671477 139.74116343365375 37.8 35.66745466671477 139.74116343365375 36.8 35.66748017067284 139.7411805696047 36.8 35.66748017067284 139.7411805696047 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-d51ae157-d179-4d82-a70e-123a2e086add">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d51ae157-d179-4d82-a70e-123a2e086add">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d51ae157-d179-4d82-a70e-123a2e086add">
											<gml:posList>35.66748573165428 139.74116814766631 37.8 35.66748017067284 139.7411805696047 37.8 35.66748017067284 139.7411805696047 36.8 35.66748574066801 139.74116814765594 36.8 35.66748573165428 139.74116814766631 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-de1e522c-db37-4e8f-94eb-4aa65e5f782b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-de1e522c-db37-4e8f-94eb-4aa65e5f782b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-de1e522c-db37-4e8f-94eb-4aa65e5f782b">
											<gml:posList>35.6675735045703 139.74122334242023 24.02 35.66748466459349 139.74116365322752 24.02 35.66748466459349 139.74116365322752 27.6 35.66748466459349 139.74116365322752 37.8 35.6675735045703 139.74122334242023 37.8 35.6675735045703 139.74122334242023 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-29ee989b-3fa9-432e-a890-393a185a3968">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-29ee989b-3fa9-432e-a890-393a185a3968">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-29ee989b-3fa9-432e-a890-393a185a3968">
											<gml:posList>35.66756983698038 139.74122465004615 37.8 35.66748573165428 139.74116814766631 37.8 35.66748574066801 139.74116814765594 36.8 35.66756983698038 139.74122465004615 36.8 35.66756983698038 139.74122465004615 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6227dc2c-ab4e-4ccd-b033-63a501af1c80">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6227dc2c-ab4e-4ccd-b033-63a501af1c80">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6227dc2c-ab4e-4ccd-b033-63a501af1c80">
											<gml:posList>35.66745466671477 139.74116343365375 37.8 35.66742237165209 139.74123562228078 37.8 35.66742237165209 139.74123562228078 36.8 35.66745466671477 139.74116343365375 36.8 35.66745466671477 139.74116343365375 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bd23b916-f753-4cf4-9696-b2fe855b36a2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bd23b916-f753-4cf4-9696-b2fe855b36a2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bd23b916-f753-4cf4-9696-b2fe855b36a2">
											<gml:posList>35.66746044738891 139.74114363283292 24.02 35.6673953083268 139.74128921468275 24.02 35.6673953083268 139.74128921468275 43.7 35.66741999982527 139.74123403440228 43.7 35.66741999982527 139.74123403440228 37.8 35.6674535996538 139.74115893921677 37.8 35.6674535996538 139.74115893921677 27.6 35.66746044738891 139.74114363283292 27.6 35.66746044738891 139.74114363283292 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6b471c9-ad68-4e5d-ab63-c1eedf91e71b">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6b471c9-ad68-4e5d-ab63-c1eedf91e71b">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6b471c9-ad68-4e5d-ab63-c1eedf91e71b">
											<gml:posList>35.66742237165209 139.74123562228078 37.8 35.66741999982527 139.74123403440228 37.8 35.66741999982527 139.74123403440228 43.7 35.667446865547355 139.7412520856105 43.7 35.667446865547355 139.7412520856105 36.8 35.66742237165209 139.74123562228078 36.8 35.66742237165209 139.74123562228078 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-a79d1fc2-10fb-4a4c-9c3e-37d475c306d8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a79d1fc2-10fb-4a4c-9c3e-37d475c306d8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a79d1fc2-10fb-4a4c-9c3e-37d475c306d8">
											<gml:posList>35.66755043279555 139.74127491999675 24.02 35.6675735045703 139.74122334242023 24.02 35.6675735045703 139.74122334242023 37.8 35.66755043279555 139.74127491999675 37.8 35.66755043279555 139.74127491999675 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-bba90cce-d794-4358-a22c-c9f193fe6926">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-bba90cce-d794-4358-a22c-c9f193fe6926">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-bba90cce-d794-4358-a22c-c9f193fe6926">
											<gml:posList>35.667546765205046 139.74127622761992 37.8 35.66756983698038 139.74122465004615 37.8 35.66756983698038 139.74122465004615 36.8 35.667546765205046 139.74127622761992 36.8 35.667546765205046 139.74127622761992 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0d0fb31d-b00d-4830-8a11-c35ed0f15e1a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0d0fb31d-b00d-4830-8a11-c35ed0f15e1a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0d0fb31d-b00d-4830-8a11-c35ed0f15e1a">
											<gml:posList>35.6675542385475 139.74127747826938 24.02 35.66755043279555 139.74127491999675 24.02 35.66755043279555 139.74127491999675 37.8 35.6675542385475 139.74127747826938 37.8 35.6675542385475 139.74127747826938 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7d0ba44d-5020-4ae3-916a-d215de0150f1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7d0ba44d-5020-4ae3-916a-d215de0150f1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7d0ba44d-5020-4ae3-916a-d215de0150f1">
											<gml:posList>35.667550570956976 139.74127878589252 37.8 35.667546765205046 139.74127622761992 37.8 35.667546765205046 139.74127622761992 36.8 35.667550570956976 139.74127878589252 36.8 35.667550570956976 139.74127878589252 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f45d57b9-7d0c-4d64-ab70-ef189fdbd748">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f45d57b9-7d0c-4d64-ab70-ef189fdbd748">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f45d57b9-7d0c-4d64-ab70-ef189fdbd748">
											<gml:posList>35.667424936544506 139.7413010991479 37.8 35.667424936544506 139.7413010991479 36.8 35.667446865547355 139.7412520856105 36.8 35.667446865547355 139.7412520856105 43.7 35.66742217404074 139.74130726590394 43.7 35.66742217404074 139.74130726590394 24.02 35.667423631774284 139.74130400570456 24.02 35.667423631774284 139.74130400570456 37.8 35.667424936544506 139.7413010991479 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fb5cd0c6-000b-478b-b424-36a74ecfe91e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fb5cd0c6-000b-478b-b424-36a74ecfe91e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fb5cd0c6-000b-478b-b424-36a74ecfe91e">
											<gml:posList>35.66753635354082 139.74131055908407 37.8 35.667550570956976 139.74127878589252 37.8 35.667550570956976 139.74127878589252 36.8 35.66753635354082 139.74131055908407 36.8 35.66753635354082 139.74131055908407 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1c79e11f-2965-43b7-9b9e-8ef44ddca7f4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1c79e11f-2965-43b7-9b9e-8ef44ddca7f4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1c79e11f-2965-43b7-9b9e-8ef44ddca7f4">
											<gml:posList>35.667537420604575 139.74131506457363 24.02 35.6675542385475 139.74127747826938 24.02 35.6675542385475 139.74127747826938 37.8 35.667537420604575 139.74131506457363 37.8 35.667537420604575 139.74131506457363 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-40695288-fb11-4fb8-8c94-0ab02300c7d7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-40695288-fb11-4fb8-8c94-0ab02300c7d7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-40695288-fb11-4fb8-8c94-0ab02300c7d7">
											<gml:posList>35.6673953083268 139.74128921468275 43.7 35.6673953083268 139.74128921468275 24.02 35.66742217404074 139.74130726590394 24.02 35.66742217404074 139.74130726590394 43.7 35.6673953083268 139.74128921468275 43.7</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-76570f80-913d-43e0-814e-bf506f770144">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76570f80-913d-43e0-814e-bf506f770144">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76570f80-913d-43e0-814e-bf506f770144">
											<gml:posList>35.66753346765401 139.74130860727746 37.8 35.66753635354082 139.74131055908407 37.8 35.66753635354082 139.74131055908407 36.8 35.66753346765401 139.74130860727746 36.8 35.66753346765401 139.74130860727746 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-2ef6eacd-7eeb-4a59-afc8-873f1b8967e4">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ef6eacd-7eeb-4a59-afc8-873f1b8967e4">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ef6eacd-7eeb-4a59-afc8-873f1b8967e4">
											<gml:posList>35.667534534717824 139.74131311276682 24.02 35.667537420604575 139.74131506457363 24.02 35.667537420604575 139.74131506457363 37.8 35.667534534717824 139.74131311276682 37.8 35.667534534717824 139.74131311276682 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-538d4eff-e7ea-4d72-8ab3-7b93e24a4f71">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-538d4eff-e7ea-4d72-8ab3-7b93e24a4f71">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-538d4eff-e7ea-4d72-8ab3-7b93e24a4f71">
											<gml:posList>35.667424936544506 139.7413010991479 37.8 35.66751096272866 139.74135890283327 37.8 35.66751096272866 139.74135890283327 36.8 35.667424936544506 139.7413010991479 36.8 35.667424936544506 139.7413010991479 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-163dcb94-3d5b-4ce4-a16b-38d637aa88cb">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-163dcb94-3d5b-4ce4-a16b-38d637aa88cb">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-163dcb94-3d5b-4ce4-a16b-38d637aa88cb">
											<gml:posList>35.667423631774284 139.74130400570456 24.02 35.66751202978217 139.74136339727616 24.02 35.66751202978217 139.74136339727616 37.8 35.667423631774284 139.74130400570456 37.8 35.667423631774284 139.74130400570456 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f483d942-96cc-4679-a906-3635b33c67aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f483d942-96cc-4679-a906-3635b33c67aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f483d942-96cc-4679-a906-3635b33c67aa">
											<gml:posList>35.66751096272866 139.74135890283327 37.8 35.66753346765401 139.74130860727746 37.8 35.66753346765401 139.74130860727746 36.8 35.66751096272866 139.74135890283327 36.8 35.66751096272866 139.74135890283327 37.8</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-5dffe8d9-0242-479a-b365-886ac79762f5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-5dffe8d9-0242-479a-b365-886ac79762f5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-5dffe8d9-0242-479a-b365-886ac79762f5">
											<gml:posList>35.66751202978217 139.74136339727616 24.02 35.667534534717824 139.74131311276682 24.02 35.667534534717824 139.74131311276682 37.8 35.66751202978217 139.74136339727616 37.8 35.66751202978217 139.74136339727616 24.02</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂一丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-10217</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">199.7465</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">6</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.6</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>