<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6d1c872c-88fc-488a-bf90-4dac3f962eb5">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">14.1</bldg:measuredHeight>
			<bldg:storeysAboveGround>5</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>0</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66828563568443 139.73858748594301 0 35.66826970024799 139.73861147452408 0 35.66826239339547 139.73860419281718 0 35.668230702611794 139.73865194881736 0 35.66833570466623 139.738756540698 0 35.668383331033155 139.73868490654507 0 35.66828563568443 139.73858748594301 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66828563568443 139.73858748594301 14.78 35.668383331033155 139.73868490654507 14.78 35.66833570466623 139.738756540698 14.78 35.668230702611794 139.73865194881736 14.78 35.66826239339547 139.73860419281718 14.78 35.66826970024799 139.73861147452408 14.78 35.66828563568443 139.73858748594301 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66828563568443 139.73858748594301 14.78 35.66826970024799 139.73861147452408 14.78 35.66826970024799 139.73861147452408 28.9 35.66828563568443 139.73858748594301 28.9 35.66828563568443 139.73858748594301 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66826970024799 139.73861147452408 14.78 35.66826239339547 139.73860419281718 14.78 35.66826239339547 139.73860419281718 28.9 35.66826970024799 139.73861147452408 28.9 35.66826970024799 139.73861147452408 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66826239339547 139.73860419281718 14.78 35.668230702611794 139.73865194881736 14.78 35.668230702611794 139.73865194881736 28.9 35.66826239339547 139.73860419281718 28.9 35.66826239339547 139.73860419281718 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668230702611794 139.73865194881736 14.78 35.66833570466623 139.738756540698 14.78 35.66833570466623 139.738756540698 28.9 35.668230702611794 139.73865194881736 28.9 35.668230702611794 139.73865194881736 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66833570466623 139.738756540698 14.78 35.668383331033155 139.73868490654507 14.78 35.668383331033155 139.73868490654507 28.9 35.66833570466623 139.738756540698 28.9 35.66833570466623 139.738756540698 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668383331033155 139.73868490654507 14.78 35.66828563568443 139.73858748594301 14.78 35.66828563568443 139.73858748594301 28.9 35.668383331033155 139.73868490654507 28.9 35.668383331033155 139.73868490654507 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66828563568443 139.73858748594301 28.9 35.66826970024799 139.73861147452408 28.9 35.66826239339547 139.73860419281718 28.9 35.668230702611794 139.73865194881736 28.9 35.66833570466623 139.738756540698 28.9 35.668383331033155 139.73868490654507 28.9 35.66828563568443 139.73858748594301 28.9</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-3d1c62f0-a9cc-4679-ade0-d7ae5f09469a"/>
							<gml:surfaceMember xlink:href="#poly-c6fb5bf7-2cbd-409a-ab3d-1aff615f47de"/>
							<gml:surfaceMember xlink:href="#poly-d1fdc368-4c5b-4968-89fd-b0c1b4758ba1"/>
							<gml:surfaceMember xlink:href="#poly-0eecc146-0ed9-4113-8ece-d5eef8326c16"/>
							<gml:surfaceMember xlink:href="#poly-69ed4c68-0192-49cd-b497-e0fc5dee9546"/>
							<gml:surfaceMember xlink:href="#poly-76c6a6c7-06f8-44f6-bb03-e7a0f1a7e417"/>
							<gml:surfaceMember xlink:href="#poly-88953feb-8949-49e1-bedb-9fcbddd548cc"/>
							<gml:surfaceMember xlink:href="#poly-03996efa-efde-41d5-8305-7146b1dd0397"/>
							<gml:surfaceMember xlink:href="#poly-4e6f9fdd-da93-4dff-8521-26befacd0cb3"/>
							<gml:surfaceMember xlink:href="#poly-3428e6d5-891c-4076-9907-ac2425cf8655"/>
							<gml:surfaceMember xlink:href="#poly-c8fc083d-f150-4895-b315-88913fb36271"/>
							<gml:surfaceMember xlink:href="#poly-710d7969-21db-42fd-9955-40f3e8306d74"/>
							<gml:surfaceMember xlink:href="#poly-45878df8-8533-4eb2-a324-6ba6587dd20d"/>
							<gml:surfaceMember xlink:href="#poly-fd0883ae-1142-49a8-9930-83162c8d36c2"/>
							<gml:surfaceMember xlink:href="#poly-16ee215d-8435-442e-b2ca-52699ee81af8"/>
							<gml:surfaceMember xlink:href="#poly-cca284e4-0bac-46b1-9909-971fe05001a5"/>
							<gml:surfaceMember xlink:href="#poly-1a944e23-3f78-4c0c-81e5-e361bbfe13d5"/>
							<gml:surfaceMember xlink:href="#poly-38848c1f-0301-459a-b299-8b8ab8a93468"/>
							<gml:surfaceMember xlink:href="#poly-ab4a0032-5f2a-4cf4-9d4a-e64d923417ba"/>
							<gml:surfaceMember xlink:href="#poly-0456afc8-d787-4d71-bdd8-25bfc2f17b06"/>
							<gml:surfaceMember xlink:href="#poly-1f6fd11b-c0a9-4bc7-a039-4ba100d2b8a3"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6d1c872c-88fc-488a-bf90-4dac3f962eb5_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-adf7e1d4-cdf7-4770-a73e-c7fe0444723a">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668296591816585 139.73866190075785 29.022 35.66830676546244 139.73864679994605 29.022 35.66831937669919 139.73865956524727 29.022 35.66830921205679 139.73867465500322 29.022 35.668296591816585 139.73866190075785 29.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a46003b8-575a-4bac-9cb9-47fc720496ed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a46003b8-575a-4bac-9cb9-47fc720496ed_0">
											<gml:posList>35.66830676546244 139.73864679994605 29.022 35.66830676546244 139.73864679994605 32.474 35.66831937669919 139.73865956524727 32.474 35.66831937669919 139.73865956524727 29.022 35.66830676546244 139.73864679994605 29.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a9cfbadd-8c0d-4f4a-b251-86b4f01749f2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a9cfbadd-8c0d-4f4a-b251-86b4f01749f2_0">
											<gml:posList>35.668296591816585 139.73866190075785 32.474 35.66830676546244 139.73864679994605 32.474 35.66830676546244 139.73864679994605 29.022 35.668296591816585 139.73866190075785 29.022 35.668296591816585 139.73866190075785 32.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f56f9991-4c84-4d60-8b41-f724c98db9b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f56f9991-4c84-4d60-8b41-f724c98db9b4_0">
											<gml:posList>35.66831937669919 139.73865956524727 32.474 35.66830676546244 139.73864679994605 32.474 35.668296591816585 139.73866190075785 32.474 35.66830921205679 139.73867465500322 32.474 35.66831937669919 139.73865956524727 32.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7801ae17-5a7b-4992-9b2a-50564d092c62">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7801ae17-5a7b-4992-9b2a-50564d092c62_0">
											<gml:posList>35.66831937669919 139.73865956524727 29.022 35.66831937669919 139.73865956524727 32.474 35.66830921205679 139.73867465500322 32.474 35.66830921205679 139.73867465500322 29.022 35.66831937669919 139.73865956524727 29.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-72e374bf-61c8-4375-bf75-472f0b3744b1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-72e374bf-61c8-4375-bf75-472f0b3744b1_0">
											<gml:posList>35.66830921205679 139.73867465500322 32.474 35.668296591816585 139.73866190075785 32.474 35.668296591816585 139.73866190075785 29.022 35.66830921205679 139.73867465500322 29.022 35.66830921205679 139.73867465500322 32.474</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-3d1c62f0-a9cc-4679-ade0-d7ae5f09469a">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3d1c62f0-a9cc-4679-ade0-d7ae5f09469a">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3d1c62f0-a9cc-4679-ade0-d7ae5f09469a">
											<gml:posList>35.66823070261179 139.73865194881736 14.78 35.66826239339546 139.73860419281718 14.78 35.66826970024799 139.73861147452408 14.78 35.668285635684406 139.738587485943 14.78 35.66838333103315 139.73868490654507 14.78 35.66833570466622 139.738756540698 14.78 35.66823070261179 139.73865194881736 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c6fb5bf7-2cbd-409a-ab3d-1aff615f47de">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c6fb5bf7-2cbd-409a-ab3d-1aff615f47de">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c6fb5bf7-2cbd-409a-ab3d-1aff615f47de">
											<gml:posList>35.66825292083815 139.7386740807902 29.419 35.66826239339546 139.73860419281718 24.886 35.66823070261179 139.73865194881736 24.886 35.66825292083815 139.7386740807902 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-d1fdc368-4c5b-4968-89fd-b0c1b4758ba1">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-d1fdc368-4c5b-4968-89fd-b0c1b4758ba1">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-d1fdc368-4c5b-4968-89fd-b0c1b4758ba1">
											<gml:posList>35.66825292083815 139.7386740807902 29.419 35.66826970024799 139.73861147452408 26.095 35.66826239339546 139.73860419281718 24.886 35.66825292083815 139.7386740807902 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-0eecc146-0ed9-4113-8ece-d5eef8326c16">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0eecc146-0ed9-4113-8ece-d5eef8326c16">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0eecc146-0ed9-4113-8ece-d5eef8326c16">
											<gml:posList>35.66825292083815 139.7386740807902 29.419 35.668285635684406 139.738587485943 26.095 35.66826970024799 139.73861147452408 26.095 35.66825292083815 139.7386740807902 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-69ed4c68-0192-49cd-b497-e0fc5dee9546">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-69ed4c68-0192-49cd-b497-e0fc5dee9546">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-69ed4c68-0192-49cd-b497-e0fc5dee9546">
											<gml:posList>35.66825292083815 139.7386740807902 29.419 35.6683005470872 139.73860235829477 29.419 35.668285635684406 139.738587485943 26.095 35.66825292083815 139.7386740807902 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-76c6a6c7-06f8-44f6-bb03-e7a0f1a7e417">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-76c6a6c7-06f8-44f6-bb03-e7a0f1a7e417">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-76c6a6c7-06f8-44f6-bb03-e7a0f1a7e417">
											<gml:posList>35.66825292083815 139.7386740807902 29.419 35.66825624657287 139.73867365711735 29.419 35.66830088379283 139.73860642281497 29.419 35.6683005470872 139.73860235829477 29.419 35.66825292083815 139.7386740807902 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-88953feb-8949-49e1-bedb-9fcbddd548cc">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-88953feb-8949-49e1-bedb-9fcbddd548cc">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-88953feb-8949-49e1-bedb-9fcbddd548cc">
											<gml:posList>35.66831697750906 139.73873789508892 29.419 35.66831663179415 139.738733830578 29.419 35.66825624657287 139.73867365711735 29.419 35.66825292083815 139.7386740807902 29.419 35.66831697750906 139.73873789508892 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-03996efa-efde-41d5-8305-7146b1dd0397">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-03996efa-efde-41d5-8305-7146b1dd0397">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-03996efa-efde-41d5-8305-7146b1dd0397">
											<gml:posList>35.66836122397861 139.73866659631153 29.022 35.66830088379283 139.73860642281497 29.022 35.66825624657287 139.73867365711735 29.022 35.66831663179415 139.738733830578 29.022 35.66836122397861 139.73866659631153 29.022</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4e6f9fdd-da93-4dff-8521-26befacd0cb3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4e6f9fdd-da93-4dff-8521-26befacd0cb3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4e6f9fdd-da93-4dff-8521-26befacd0cb3">
											<gml:posList>35.6683005470872 139.73860235829477 29.419 35.66830088379283 139.73860642281497 29.419 35.66836122397861 139.73866659631153 29.419 35.66836454971324 139.73866617263778 29.419 35.6683005470872 139.73860235829477 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-3428e6d5-891c-4076-9907-ac2425cf8655">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-3428e6d5-891c-4076-9907-ac2425cf8655">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-3428e6d5-891c-4076-9907-ac2425cf8655">
											<gml:posList>35.66836454971324 139.73866617263778 29.419 35.66836122397861 139.73866659631153 29.419 35.66831663179415 139.738733830578 29.419 35.66831697750906 139.73873789508892 29.419 35.66836454971324 139.73866617263778 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-c8fc083d-f150-4895-b315-88913fb36271">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c8fc083d-f150-4895-b315-88913fb36271">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c8fc083d-f150-4895-b315-88913fb36271">
											<gml:posList>35.66831697750906 139.73873789508892 29.419 35.66833570466622 139.738756540698 26.219 35.66838333103315 139.73868490654507 26.219 35.66836454971324 139.73866617263778 29.419 35.66831697750906 139.73873789508892 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-710d7969-21db-42fd-9955-40f3e8306d74">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-710d7969-21db-42fd-9955-40f3e8306d74">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-710d7969-21db-42fd-9955-40f3e8306d74">
											<gml:posList>35.66830088379283 139.73860642281497 29.419 35.66830088379283 139.73860642281497 29.022 35.66836122397861 139.73866659631153 29.022 35.66836122397861 139.73866659631153 29.419 35.66830088379283 139.73860642281497 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-45878df8-8533-4eb2-a324-6ba6587dd20d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-45878df8-8533-4eb2-a324-6ba6587dd20d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-45878df8-8533-4eb2-a324-6ba6587dd20d">
											<gml:posList>35.66831663179415 139.738733830578 29.419 35.66831663179415 139.738733830578 29.022 35.66825624657287 139.73867365711735 29.022 35.66825624657287 139.73867365711735 29.419 35.66831663179415 139.738733830578 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-fd0883ae-1142-49a8-9930-83162c8d36c2">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-fd0883ae-1142-49a8-9930-83162c8d36c2">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-fd0883ae-1142-49a8-9930-83162c8d36c2">
											<gml:posList>35.66826239339546 139.73860419281718 14.78 35.66823070261179 139.73865194881736 14.78 35.66823070261179 139.73865194881736 24.886 35.66826239339546 139.73860419281718 24.886 35.66826239339546 139.73860419281718 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-16ee215d-8435-442e-b2ca-52699ee81af8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-16ee215d-8435-442e-b2ca-52699ee81af8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-16ee215d-8435-442e-b2ca-52699ee81af8">
											<gml:posList>35.66826970024799 139.73861147452408 14.78 35.66826239339546 139.73860419281718 14.78 35.66826239339546 139.73860419281718 24.886 35.66826970024799 139.73861147452408 26.095 35.66826970024799 139.73861147452408 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cca284e4-0bac-46b1-9909-971fe05001a5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cca284e4-0bac-46b1-9909-971fe05001a5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cca284e4-0bac-46b1-9909-971fe05001a5">
											<gml:posList>35.668285635684406 139.738587485943 14.78 35.66826970024799 139.73861147452408 14.78 35.66826970024799 139.73861147452408 26.095 35.668285635684406 139.738587485943 26.095 35.668285635684406 139.738587485943 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1a944e23-3f78-4c0c-81e5-e361bbfe13d5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1a944e23-3f78-4c0c-81e5-e361bbfe13d5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1a944e23-3f78-4c0c-81e5-e361bbfe13d5">
											<gml:posList>35.66825624657287 139.73867365711735 29.419 35.66825624657287 139.73867365711735 29.022 35.66830088379283 139.73860642281497 29.022 35.66830088379283 139.73860642281497 29.419 35.66825624657287 139.73867365711735 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-38848c1f-0301-459a-b299-8b8ab8a93468">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-38848c1f-0301-459a-b299-8b8ab8a93468">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-38848c1f-0301-459a-b299-8b8ab8a93468">
											<gml:posList>35.66833570466622 139.738756540698 26.219 35.66831697750906 139.73873789508892 29.419 35.66825292083815 139.7386740807902 29.419 35.66823070261179 139.73865194881736 24.886 35.66823070261179 139.73865194881736 14.78 35.66833570466622 139.738756540698 14.78 35.66833570466622 139.738756540698 26.219</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-ab4a0032-5f2a-4cf4-9d4a-e64d923417ba">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-ab4a0032-5f2a-4cf4-9d4a-e64d923417ba">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-ab4a0032-5f2a-4cf4-9d4a-e64d923417ba">
											<gml:posList>35.668285635684406 139.738587485943 14.78 35.668285635684406 139.738587485943 26.095 35.6683005470872 139.73860235829477 29.419 35.66836454971324 139.73866617263778 29.419 35.66838333103315 139.73868490654507 26.219 35.66838333103315 139.73868490654507 14.78 35.668285635684406 139.738587485943 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-0456afc8-d787-4d71-bdd8-25bfc2f17b06">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-0456afc8-d787-4d71-bdd8-25bfc2f17b06">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-0456afc8-d787-4d71-bdd8-25bfc2f17b06">
											<gml:posList>35.66836122397861 139.73866659631153 29.419 35.66836122397861 139.73866659631153 29.022 35.66831663179415 139.738733830578 29.022 35.66831663179415 139.738733830578 29.419 35.66836122397861 139.73866659631153 29.419</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-1f6fd11b-c0a9-4bc7-a039-4ba100d2b8a3">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1f6fd11b-c0a9-4bc7-a039-4ba100d2b8a3">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1f6fd11b-c0a9-4bc7-a039-4ba100d2b8a3">
											<gml:posList>35.66833570466622 139.738756540698 14.78 35.66838333103315 139.73868490654507 14.78 35.66838333103315 139.73868490654507 26.219 35.66833570466622 139.738756540698 26.219 35.66833570466622 139.738756540698 14.78</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-2444</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">122.7414</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>4</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingLandSlideRiskAttribute>
					<uro:description codeSpace="../../codelists/LandSlideRiskAttribute_description.xml">1</uro:description>
					<uro:areaType codeSpace="../../codelists/LandSlideRiskAttribute_areaType.xml">2</uro:areaType>
				</uro:BuildingLandSlideRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>