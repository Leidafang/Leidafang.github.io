<?xml version='1.0' encoding='utf-8'?>
<core:CityModel xmlns:brid="http://www.opengis.net/citygml/bridge/2.0" xmlns:tran="http://www.opengis.net/citygml/transportation/2.0" xmlns:frn="http://www.opengis.net/citygml/cityfurniture/2.0" xmlns:wtr="http://www.opengis.net/citygml/waterbody/2.0" xmlns:sch="http://www.ascc.net/xml/schematron" xmlns:veg="http://www.opengis.net/citygml/vegetation/2.0" xmlns:tun="http://www.opengis.net/citygml/tunnel/2.0" xmlns:xlink="http://www.w3.org/1999/xlink" xmlns:tex="http://www.opengis.net/citygml/texturedsurface/2.0" xmlns:urf="https://www.geospatial.jp/iur/urf/3.0" xmlns:gml="http://www.opengis.net/gml" xmlns:app="http://www.opengis.net/citygml/appearance/2.0" xmlns:gen="http://www.opengis.net/citygml/generics/2.0" xmlns:dem="http://www.opengis.net/citygml/relief/2.0" xmlns:luse="http://www.opengis.net/citygml/landuse/2.0" xmlns:uro="https://www.geospatial.jp/iur/uro/3.0" xmlns:xAL="urn:oasis:names:tc:ciq:xsdschema:xAL:2.0" xmlns:bldg="http://www.opengis.net/citygml/building/2.0" xmlns:smil20="http://www.w3.org/2001/SMIL20/" xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance" xmlns:smil20lang="http://www.w3.org/2001/SMIL20/Language" xmlns:pbase="http://www.opengis.net/citygml/profiles/base/2.0" xmlns:core="http://www.opengis.net/citygml/2.0" xmlns:grp="http://www.opengis.net/citygml/cityobjectgroup/2.0"><!--Single-building subset of the cited PLATEAU source. Original coordinates and attributes retained. Referenced textures and complete code lists remain with the original dataset.--><core:cityObjectMember><bldg:Building gml:id="bldg_6d3015ba-5c73-4349-9597-a481907435c9">
			<core:creationDate>2024-03-15</core:creationDate>
			<gen:stringAttribute name="延べ面積換算係数">
				<gen:value>1.00</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="大字・町コード">
				<gen:value>1</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="町・丁目コード">
				<gen:value>2</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="13+区市町村コード+大字・町コード+町・丁目コード">
				<gen:value>13103001002</gen:value>
			</gen:stringAttribute>
			<gen:stringAttribute name="地区計画">
				<gen:value>赤坂二丁目地区</gen:value>
			</gen:stringAttribute>
			<bldg:class codeSpace="../../codelists/Building_class.xml">3002</bldg:class>
			<bldg:usage codeSpace="../../codelists/Building_usage.xml">401</bldg:usage>
			<bldg:measuredHeight uom="m">84.9</bldg:measuredHeight>
			<bldg:storeysAboveGround>8</bldg:storeysAboveGround>
			<bldg:storeysBelowGround>3</bldg:storeysBelowGround>
			<bldg:lod0RoofEdge>
				<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:surfaceMember>
						<gml:Polygon>
							<gml:exterior>
								<gml:LinearRing>
									<gml:posList>35.66929232685282 139.74037024307714 0 35.66899953682411 139.74010602918338 0 35.668866034890755 139.74032809956674 0 35.6691588245243 139.7405924242945 0 35.66929232685282 139.74037024307714 0</gml:posList>
								</gml:LinearRing>
							</gml:exterior>
						</gml:Polygon>
					</gml:surfaceMember>
				</gml:MultiSurface>
			</bldg:lod0RoofEdge>
			<bldg:lod1Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929232685282 139.74037024307714 10.94 35.6691588245243 139.7405924242945 10.94 35.668866034890755 139.74032809956674 10.94 35.66899953682411 139.74010602918338 10.94 35.66929232685282 139.74037024307714 10.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929232685282 139.74037024307714 10.94 35.66899953682411 139.74010602918338 10.94 35.66899953682411 139.74010602918338 46.62 35.66929232685282 139.74037024307714 46.62 35.66929232685282 139.74037024307714 10.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66899953682411 139.74010602918338 10.94 35.668866034890755 139.74032809956674 10.94 35.668866034890755 139.74032809956674 46.62 35.66899953682411 139.74010602918338 46.62 35.66899953682411 139.74010602918338 10.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.668866034890755 139.74032809956674 10.94 35.6691588245243 139.7405924242945 10.94 35.6691588245243 139.7405924242945 46.62 35.668866034890755 139.74032809956674 46.62 35.668866034890755 139.74032809956674 10.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691588245243 139.7405924242945 10.94 35.66929232685282 139.74037024307714 10.94 35.66929232685282 139.74037024307714 46.62 35.6691588245243 139.7405924242945 46.62 35.6691588245243 139.7405924242945 10.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon>
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66929232685282 139.74037024307714 46.62 35.66899953682411 139.74010602918338 46.62 35.668866034890755 139.74032809956674 46.62 35.6691588245243 139.7405924242945 46.62 35.66929232685282 139.74037024307714 46.62</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod1Solid>
			<bldg:lod2Solid>
				<gml:Solid srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
					<gml:exterior>
						<gml:CompositeSurface>
							<gml:surfaceMember xlink:href="#poly-6cbd7c3a-9c28-4d40-b623-e28e5d1eeb29"/>
							<gml:surfaceMember xlink:href="#poly-1300c09f-aeeb-4b84-b8e4-0ae269f607a6"/>
							<gml:surfaceMember xlink:href="#poly-33602318-1f3f-484d-bdb3-09bd4dc6e370"/>
							<gml:surfaceMember xlink:href="#poly-19cf9279-394a-4a3c-a5fe-6ae980e12739"/>
							<gml:surfaceMember xlink:href="#poly-7ba9ca4d-6418-4d0f-99f1-9d850241e153"/>
							<gml:surfaceMember xlink:href="#poly-4ca39808-2bd6-4908-84d1-60e47d2602c5"/>
							<gml:surfaceMember xlink:href="#poly-a5c4cf12-6f7c-4d19-9824-3564aa40490f"/>
							<gml:surfaceMember xlink:href="#poly-744cdf66-cefd-4732-8d00-af9c26f8ed83"/>
							<gml:surfaceMember xlink:href="#poly-9db25cd2-be77-4d0e-bba4-3000d41504c7"/>
							<gml:surfaceMember xlink:href="#poly-2ae9cf95-555b-43db-9308-a697980135b6"/>
							<gml:surfaceMember xlink:href="#poly-41eb2f7d-0b5c-48d3-bb4b-ec718fda79e9"/>
							<gml:surfaceMember xlink:href="#poly-584eae48-a2ab-4fc4-b601-cdd9175519c5"/>
							<gml:surfaceMember xlink:href="#poly-905776bb-cc5b-4323-9dae-448dbdd52780"/>
							<gml:surfaceMember xlink:href="#poly-896af834-7a75-4713-8c26-34c5c2d3f776"/>
							<gml:surfaceMember xlink:href="#poly-8806d426-ad98-4442-842d-fbe7cd811ec8"/>
							<gml:surfaceMember xlink:href="#poly-7f7c049a-c234-4d37-9aed-1fd9f6c8e5cd"/>
							<gml:surfaceMember xlink:href="#poly-611cead0-2189-43d3-9d96-c0ae976a0d65"/>
							<gml:surfaceMember xlink:href="#poly-6497c07b-81e9-45a7-8897-35f4e5fb5b39"/>
							<gml:surfaceMember xlink:href="#poly-c7e79b60-b506-446b-acc6-eed853e8cdca"/>
							<gml:surfaceMember xlink:href="#poly-39a20dae-174d-4b66-841e-d84184de021e"/>
							<gml:surfaceMember xlink:href="#poly-cfc59c1c-43a1-45d3-96f0-63ba82c85c2d"/>
							<gml:surfaceMember xlink:href="#poly-7b2981a9-1f1e-4e66-97fc-666d0fc0474d"/>
							<gml:surfaceMember xlink:href="#poly-07abb19c-be9e-4073-8e4c-25297ebd00aa"/>
							<gml:surfaceMember xlink:href="#poly-c9aa9691-195c-4835-9bc7-51eb7869a368"/>
							<gml:surfaceMember xlink:href="#poly-908bd9a4-6062-427f-a6c4-62cf42718006"/>
							<gml:surfaceMember xlink:href="#poly-576b1c5d-6e7e-4791-8678-817825bfb148"/>
							<gml:surfaceMember xlink:href="#poly-f6167f48-160e-4bfb-9430-a7c47680ddc0"/>
						</gml:CompositeSurface>
					</gml:exterior>
				</gml:Solid>
			</bldg:lod2Solid>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6d3015ba-5c73-4349-9597-a481907435c9_BuildingInstallation_1070">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c8bca0b-364d-48c4-b778-aba4030ff0fa">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66899670406986 139.74014945457353 46.753 35.66900713742684 139.74013193442696 46.753 35.66901414594694 139.74013820044885 46.753 35.669003703575356 139.74015572060662 46.753 35.66899670406986 139.74014945457353 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bbfc8543-724f-4ca8-abe7-1de79baa0460">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66902925567269 139.74015334914543 46.753 35.66904304764923 139.7401662459795 46.753 35.66901288010756 139.74021469596212 46.753 35.66899908813613 139.74020179912452 46.753 35.66902925567269 139.74015334914543 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aa733cfa-64ae-40dc-88e6-8ecf349efb1f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6689808110024 139.7401936573103 46.753 35.66897540815854 139.74018898005434 46.753 35.66898215940297 139.74017727442694 46.753 35.66898756224728 139.74018195168247 46.753 35.6689808110024 139.7401936573103 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b1388f75-8ad4-42db-a10f-cfef4e159ecc">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691962801197 139.74032821357778 47.177 35.66920861309412 139.74030770876047 47.177 35.669218039023754 139.74031622541324 47.177 35.66920570605643 139.74033674127776 47.177 35.6691962801197 139.74032821357778 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9344f5b9-76be-4e00-a3ed-ef63555a3c5f">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891932204832 139.7403371397094 46.753 35.66890972511491 139.7403289546659 46.753 35.668914432894056 139.74032066466214 46.753 35.66892402982802 139.74032884970515 46.753 35.66891932204832 139.7403371397094 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00e4ee17-6b64-409d-9942-eef01a7f0eb0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66891932204832 139.7403371397094 46.753 35.66892402982802 139.74032884970515 46.753 35.66892402982802 139.74032884970515 48.033 35.66891932204832 139.7403371397094 48.033 35.66891932204832 139.7403371397094 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd1cd4c0-4146-47b3-b37d-ce4df95c2606">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66892635690469 139.74033083529656 46.753 35.66892164912486 139.74033912530095 46.753 35.66892164912486 139.74033912530095 48.033 35.66892635690469 139.74033083529656 48.033 35.66892635690469 139.74033083529656 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1164a7e0-cb9e-4942-8234-3e4c2f74314b">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669046549822845 139.74038245779573 46.145 35.66903945980819 139.74037569477107 46.145 35.66903367550404 139.74036727332262 46.145 35.669029440570576 139.74035756873434 46.145 35.66902694461135 139.74034698949063 46.145 35.66902629614911 139.74033599940012 46.145 35.66902753162258 139.74032509549303 46.145 35.6690305882941 139.74031474177653 46.145 35.6690353313078 139.7403053912954 46.145 35.66904156267779 139.7402974529838 46.145 35.66904900325195 139.74029128063998 46.145 35.66905732874134 139.74028713974627 46.145 35.669066169711485 139.7402851964231 46.145 35.669075147671414 139.74028556157114 46.145 35.669083875005335 139.74028820250277 46.145 35.66909195502388 139.74029300921816 46.145 35.66909905405684 139.74029977222946 46.145 35.66910483836565 139.74030819367988 46.145 35.669109073311574 139.74031790932077 46.145 35.66911156927334 139.7403284885744 46.145 35.669112208714026 139.7403394676409 46.145 35.669110982253 139.7403503715488 46.145 35.669107925587014 139.74036073632044 46.145 35.66910318256906 139.74037008680673 46.145 35.66909695118584 139.74037801407277 46.145 35.66908951061581 139.74038419745833 46.145 35.66908118512312 139.74038833834362 46.145 35.669072335129066 139.74039027062022 46.145 35.66906335716943 139.74038990546043 46.145 35.66905463885142 139.74038726450797 46.145 35.669046549822845 139.74038245779573 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4eae5906-4260-413e-ba97-d92b93888f34">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893116488285 139.74034724416467 46.753 35.66892164912486 139.74033912530095 46.753 35.66892635690469 139.74033083529656 46.753 35.668935872663226 139.74033895415977 46.753 35.66893116488285 139.74034724416467 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-acf6b5df-0f04-4eac-af8c-579c115e5175">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919941415552 139.7403480045479 47.177 35.669181184910634 139.74037852395443 47.177 35.6691715605896 139.74036988602123 47.177 35.669189789832345 139.74033936661644 47.177 35.66919941415552 139.7403480045479 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-606661cf-83d5-4d2e-90fd-36a79b78efa5">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66921368951724 139.74035658185767 47.177 35.66919355162006 139.74039003069564 47.177 35.66918864471789 139.74038558480717 47.177 35.669208782613836 139.74035213597014 47.177 35.66921368951724 139.74035658185767 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0a204c1-6112-411b-b25c-a1d50c55dd7c">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66925206246944 139.74037019034546 49.017 35.66924262819483 139.74038588674958 49.017 35.66922981075623 139.74037432529403 49.017 35.66923924502083 139.74035861784495 49.017 35.66925206246944 139.74037019034546 49.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b5c2d19c-df1c-4347-8d2d-a2175d1d8009">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669147956931134 139.7404092043287 47.177 35.66916560064998 139.74037914955647 47.177 35.66917542328935 139.74038780935243 47.177 35.66915777956837 139.74041786412644 47.177 35.669147956931134 139.7404092043287 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5d303f2f-cbd2-4503-b767-b7d9af77d059">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66924279323625 139.74040118541052 49.017 35.66924948184827 139.74039005423185 49.017 35.66925786143831 139.7403976111003 49.017 35.66925117283412 139.7404087533256 49.017 35.66924279323625 139.74040118541052 49.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8ed0f86e-9c6b-44e2-bc89-490d41218531">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66919265084208 139.7404024806898 47.177 35.669173610399255 139.7404330672978 47.177 35.669164527016385 139.74042457233128 47.177 35.66918356746561 139.74039399677082 47.177 35.66919265084208 139.7404024806898 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7eb66aa4-b5ad-4e61-9a5d-52f9621670a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66915130517797 139.74042626665758 47.177 35.66914418354579 139.74043693438557 47.177 35.669140593305286 139.74043333752024 47.177 35.669147723950886 139.740422669782 47.177 35.66915130517797 139.74042626665758 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b38e0c32-b1d6-40d9-a871-a367c282ea55">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669215092544725 139.7404226138101 47.177 35.6691963953767 139.74045418312684 47.177 35.66918749271293 139.7404462623431 47.177 35.6692061898789 139.74041469302801 47.177 35.669215092544725 139.7404226138101 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bb9a5bae-528f-4b33-b1d2-4636842be3cf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66916872323285 139.74044251736936 47.177 35.66915547232631 139.74046495628485 47.177 35.669145252781846 139.74045589928213 47.177 35.66915851269193 139.74043344931147 47.177 35.66916872323285 139.74044251736936 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-12e7c97b-9d27-4276-9af8-7959a2a4dd76">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66923117601482 139.7404381480836 46.145 35.669239871303766 139.74044599178822 46.145 35.669229878645396 139.74046230740947 46.145 35.66922130963484 139.74045457401874 46.145 35.66923117601482 139.7404381480836 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1864fd74-b729-4745-8220-5eb72b724cb0">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669234505906296 139.74046647747628 46.943 35.669229878645396 139.74046230740947 46.943 35.669239871303766 139.74044599178822 46.943 35.669244372287864 139.74045005153988 46.943 35.669234505906296 139.74046647747628 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46261ef3-7211-4329-86cd-367af6f6f927">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669124479920484 139.74044913000105 47.177 35.66913379793967 139.74045798921526 47.177 35.669120887984405 139.74047839524377 47.177 35.66911625152273 139.74047398217894 47.177 35.66912248144696 139.74046415499336 47.177 35.669117790868334 139.7404596978076 47.177 35.669124479920484 139.74044913000105 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-86977c5a-285c-4d96-9c6d-35bbaaacf285">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6691917967586 139.74046377646482 47.177 35.66917625828698 139.74048871444936 47.177 35.66917178425161 139.74048453316075 47.177 35.66918229928317 139.7404676646444 47.177 35.66917704950451 139.740462755213 47.177 35.66918208194859 139.7404546746891 47.177 35.6691917967586 139.74046377646482 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5291891d-d8ae-4f16-9b5b-8e389411b3d3">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66913114694879 139.740480128645 47.177 35.669140211818046 139.7404646204852 47.177 35.66915460748472 139.74047726263143 47.177 35.669145551627594 139.7404927707822 47.177 35.66913114694879 139.740480128645 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21827ff1-168d-4f7c-99e3-aa0f68368750">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669156722204285 139.7404960937674 47.177 35.66916411325691 139.74048413333827 47.177 35.669168199404034 139.74048792846236 47.177 35.66916080835104 139.74049988889175 47.177 35.669156722204285 139.7404960937674 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4c343cb3-3ef0-4d04-83d9-76cd7930b493">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66912782283413 139.7405294311804 47.177 35.66910017704518 139.74050517284158 47.177 35.669112572592454 139.74048395000807 47.177 35.66914021839413 139.74050821938934 47.177 35.66912782283413 139.7405294311804 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d7e4c2b3-bf9c-4c8f-997b-5a32960fad31">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907954138047 139.7405126749284 47.177 35.66908573488684 139.740502372811 47.177 35.66909410544782 139.74050991864013 47.177 35.66908791194932 139.74052023180408 47.177 35.66907954138047 139.7405126749284 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1fdccd78-8e2d-4b10-a526-2f18813d9dd6">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908791194932 139.74052023180408 47.177 35.66909410544782 139.74050991864013 47.177 35.66909410544782 139.74050991864013 48.605 35.66908791194932 139.74052023180408 48.605 35.66908791194932 139.74052023180408 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ae84e96c-6d57-4a9d-b1a2-c84b6491a072">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.6690959996498 139.74051162859007 47.177 35.66908980615116 139.74052194175417 47.177 35.66908980615116 139.74052194175417 48.605 35.6690959996498 139.74051162859007 48.605 35.6690959996498 139.74051162859007 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-07598e44-7049-46f5-852e-385d69348571">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66908980615116 139.74052194175417 47.177 35.6690959996498 139.74051162859007 47.177 35.66910436119645 139.74051917443157 47.177 35.66909816769717 139.74052948759618 47.177 35.66908980615116 139.74052194175417 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c7cd9caf-e75c-4519-bbf5-26b250ffc4d1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c7cd9caf-e75c-4519-bbf5-26b250ffc4d1_0">
											<gml:posList>35.668914432894056 139.74032066466214 46.753 35.66890972511491 139.7403289546659 46.753 35.66890972511491 139.7403289546659 48.033 35.668914432894056 139.74032066466214 48.033 35.668914432894056 139.74032066466214 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-39e6f5ef-a98a-4cf7-9b78-27cd94db630b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-39e6f5ef-a98a-4cf7-9b78-27cd94db630b_0">
											<gml:posList>35.66890972511491 139.7403289546659 46.753 35.66891932204832 139.7403371397094 46.753 35.66891932204832 139.7403371397094 48.033 35.66890972511491 139.7403289546659 48.033 35.66890972511491 139.7403289546659 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-26fd618c-3eee-48d9-910d-e17d7b1744a1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-26fd618c-3eee-48d9-910d-e17d7b1744a1_0">
											<gml:posList>35.66891932204832 139.7403371397094 48.033 35.66892402982802 139.74032884970515 48.033 35.668914432894056 139.74032066466214 48.033 35.66890972511491 139.7403289546659 48.033 35.66891932204832 139.7403371397094 48.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7601e1a0-6ef9-4888-923f-ef8cd307ec33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7601e1a0-6ef9-4888-923f-ef8cd307ec33_0">
											<gml:posList>35.66892402982802 139.74032884970515 46.753 35.668914432894056 139.74032066466214 46.753 35.668914432894056 139.74032066466214 48.033 35.66892402982802 139.74032884970515 48.033 35.66892402982802 139.74032884970515 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccc60500-da89-4f10-a544-77304432b015">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccc60500-da89-4f10-a544-77304432b015_0">
											<gml:posList>35.66892164912486 139.74033912530095 46.753 35.66893116488285 139.74034724416467 46.753 35.66893116488285 139.74034724416467 48.033 35.66892164912486 139.74033912530095 48.033 35.66892164912486 139.74033912530095 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-123bb5da-f48a-44dd-9c12-f206ddb244bf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-123bb5da-f48a-44dd-9c12-f206ddb244bf_0">
											<gml:posList>35.66893116488285 139.74034724416467 48.033 35.668935872663226 139.74033895415977 48.033 35.66892635690469 139.74033083529656 48.033 35.66892164912486 139.74033912530095 48.033 35.66893116488285 139.74034724416467 48.033</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ba313418-93a6-4f2b-83d5-af4894c903d0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ba313418-93a6-4f2b-83d5-af4894c903d0_0">
											<gml:posList>35.668935872663226 139.74033895415977 46.753 35.66892635690469 139.74033083529656 46.753 35.66892635690469 139.74033083529656 48.033 35.668935872663226 139.74033895415977 48.033 35.668935872663226 139.74033895415977 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c3c740b-7762-405e-82ba-5bc3006c0390">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c3c740b-7762-405e-82ba-5bc3006c0390_0">
											<gml:posList>35.66893116488285 139.74034724416467 46.753 35.668935872663226 139.74033895415977 46.753 35.668935872663226 139.74033895415977 48.033 35.66893116488285 139.74034724416467 48.033 35.66893116488285 139.74034724416467 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9f7b7165-7bf3-4794-9abf-f2c01399df88">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9f7b7165-7bf3-4794-9abf-f2c01399df88_0">
											<gml:posList>35.66897540815854 139.74018898005434 46.753 35.6689808110024 139.7401936573103 46.753 35.6689808110024 139.7401936573103 48.171 35.66897540815854 139.74018898005434 48.171 35.66897540815854 139.74018898005434 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4076993b-23d9-42b9-b445-d6a72edb8eea">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4076993b-23d9-42b9-b445-d6a72edb8eea_0">
											<gml:posList>35.66898215940297 139.74017727442694 46.753 35.66897540815854 139.74018898005434 46.753 35.66897540815854 139.74018898005434 48.171 35.66898215940297 139.74017727442694 48.171 35.66898215940297 139.74017727442694 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-10e968f5-a3f3-49a2-a212-29924335da40">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-10e968f5-a3f3-49a2-a212-29924335da40_0">
											<gml:posList>35.66898215940297 139.74017727442694 48.171 35.66897540815854 139.74018898005434 48.171 35.6689808110024 139.7401936573103 48.171 35.66898756224728 139.74018195168247 48.171 35.66898215940297 139.74017727442694 48.171</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a0cf4b69-5bbc-4cea-bc3c-eb4fc843e39a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a0cf4b69-5bbc-4cea-bc3c-eb4fc843e39a_0">
											<gml:posList>35.66898756224728 139.74018195168247 46.753 35.66898756224728 139.74018195168247 48.171 35.6689808110024 139.7401936573103 48.171 35.6689808110024 139.7401936573103 46.753 35.66898756224728 139.74018195168247 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-46f78f1b-0571-449b-8325-0da9501d1bbf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-46f78f1b-0571-449b-8325-0da9501d1bbf_0">
											<gml:posList>35.66898756224728 139.74018195168247 46.753 35.66898215940297 139.74017727442694 46.753 35.66898215940297 139.74017727442694 48.171 35.66898756224728 139.74018195168247 48.171 35.66898756224728 139.74018195168247 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0880ad81-4608-4869-83cc-daf165aedaf7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0880ad81-4608-4869-83cc-daf165aedaf7_0">
											<gml:posList>35.66899670406986 139.74014945457353 46.753 35.669003703575356 139.74015572060662 46.753 35.669003703575356 139.74015572060662 48.36 35.66899670406986 139.74014945457353 48.36 35.66899670406986 139.74014945457353 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-936ea459-ac0e-4c84-8b80-4842f3d7f9db">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-936ea459-ac0e-4c84-8b80-4842f3d7f9db_0">
											<gml:posList>35.66900713742684 139.74013193442696 46.753 35.66899670406986 139.74014945457353 46.753 35.66899670406986 139.74014945457353 48.36 35.66900713742684 139.74013193442696 48.36 35.66900713742684 139.74013193442696 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4dfc1c9a-f875-4521-acbb-45f931641ef3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4dfc1c9a-f875-4521-acbb-45f931641ef3_0">
											<gml:posList>35.66899670406986 139.74014945457353 48.36 35.669003703575356 139.74015572060662 48.36 35.66901414594694 139.74013820044885 48.36 35.66900713742684 139.74013193442696 48.36 35.66899670406986 139.74014945457353 48.36</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-01f9635b-0ff3-4827-a72b-9e460dcd81a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-01f9635b-0ff3-4827-a72b-9e460dcd81a7_0">
											<gml:posList>35.66899908813613 139.74020179912452 46.753 35.66901288010756 139.74021469596212 46.753 35.66901288010756 139.74021469596212 48.632 35.66899908813613 139.74020179912452 48.632 35.66899908813613 139.74020179912452 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fa1005ef-4a49-4606-b818-63699301e3a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fa1005ef-4a49-4606-b818-63699301e3a0_0">
											<gml:posList>35.669003703575356 139.74015572060662 46.753 35.66901414594694 139.74013820044885 46.753 35.66901414594694 139.74013820044885 48.36 35.669003703575356 139.74015572060662 48.36 35.669003703575356 139.74015572060662 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6796c32a-158c-4263-952a-ea70c4071343">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6796c32a-158c-4263-952a-ea70c4071343_0">
											<gml:posList>35.66901414594694 139.74013820044885 46.753 35.66900713742684 139.74013193442696 46.753 35.66900713742684 139.74013193442696 48.36 35.66901414594694 139.74013820044885 48.36 35.66901414594694 139.74013820044885 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9556faf1-dea6-4554-849a-594309a024b9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9556faf1-dea6-4554-849a-594309a024b9_0">
											<gml:posList>35.66899908813613 139.74020179912452 46.753 35.66899908813613 139.74020179912452 48.632 35.66902925567269 139.74015334914543 48.632 35.66902925567269 139.74015334914543 46.753 35.66899908813613 139.74020179912452 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2fef4844-74bb-4f97-a5f6-9881697ea2e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2fef4844-74bb-4f97-a5f6-9881697ea2e8_0">
											<gml:posList>35.66902925567269 139.74015334914543 48.632 35.66899908813613 139.74020179912452 48.632 35.66901288010756 139.74021469596212 48.632 35.66904304764923 139.7401662459795 48.632 35.66902925567269 139.74015334914543 48.632</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a8ad37ec-0354-4db5-a98a-96f97350fcb8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a8ad37ec-0354-4db5-a98a-96f97350fcb8_0">
											<gml:posList>35.66902629614911 139.74033599940012 46.145 35.66902694461135 139.74034698949063 46.145 35.66902694461135 139.74034698949063 106.781 35.66902629614911 139.74033599940012 106.781 35.66902629614911 139.74033599940012 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ca0f57c-254f-4e07-bbc4-6c77f2e8ffa2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ca0f57c-254f-4e07-bbc4-6c77f2e8ffa2_0">
											<gml:posList>35.66902753162258 139.74032509549303 46.145 35.66902629614911 139.74033599940012 46.145 35.66902629614911 139.74033599940012 106.781 35.66902753162258 139.74032509549303 106.781 35.66902753162258 139.74032509549303 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00bd1815-811b-42b5-9e24-bb827cbedc90">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00bd1815-811b-42b5-9e24-bb827cbedc90_0">
											<gml:posList>35.66901288010756 139.74021469596212 46.753 35.66904304764923 139.7401662459795 46.753 35.66904304764923 139.7401662459795 48.632 35.66901288010756 139.74021469596212 48.632 35.66901288010756 139.74021469596212 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-90d3e067-f8d7-4c34-b8d1-7e108ea2f1d7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-90d3e067-f8d7-4c34-b8d1-7e108ea2f1d7_0">
											<gml:posList>35.669029440570576 139.74035756873434 106.781 35.66902694461135 139.74034698949063 106.781 35.66902694461135 139.74034698949063 46.145 35.669029440570576 139.74035756873434 46.145 35.669029440570576 139.74035756873434 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-379efb71-6442-40a0-b96d-6f7081abad63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-379efb71-6442-40a0-b96d-6f7081abad63_0">
											<gml:posList>35.6690305882941 139.74031474177653 46.145 35.66902753162258 139.74032509549303 46.145 35.66902753162258 139.74032509549303 106.781 35.6690305882941 139.74031474177653 106.781 35.6690305882941 139.74031474177653 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-664a81a5-27f2-4b58-85d3-06ddae7911a9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-664a81a5-27f2-4b58-85d3-06ddae7911a9_0">
											<gml:posList>35.66903367550404 139.74036727332262 106.781 35.669029440570576 139.74035756873434 106.781 35.669029440570576 139.74035756873434 46.145 35.66903367550404 139.74036727332262 46.145 35.66903367550404 139.74036727332262 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5a775518-776f-458f-9026-fdeb20121563">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5a775518-776f-458f-9026-fdeb20121563_0">
											<gml:posList>35.6690353313078 139.7403053912954 46.145 35.6690305882941 139.74031474177653 46.145 35.6690305882941 139.74031474177653 106.781 35.6690353313078 139.7403053912954 106.781 35.6690353313078 139.7403053912954 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4137e265-a12e-4c47-83ce-8ca1e92d2f86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4137e265-a12e-4c47-83ce-8ca1e92d2f86_0">
											<gml:posList>35.66904304764923 139.7401662459795 46.753 35.66902925567269 139.74015334914543 46.753 35.66902925567269 139.74015334914543 48.632 35.66904304764923 139.7401662459795 48.632 35.66904304764923 139.7401662459795 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ad78d178-c6ea-4fa0-b563-6a0fe387be29">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ad78d178-c6ea-4fa0-b563-6a0fe387be29_0">
											<gml:posList>35.66903945980819 139.74037569477107 106.781 35.66903367550404 139.74036727332262 106.781 35.66903367550404 139.74036727332262 46.145 35.66903945980819 139.74037569477107 46.145 35.66903945980819 139.74037569477107 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-137f4823-cc1a-4c10-acc4-636a10401ab1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-137f4823-cc1a-4c10-acc4-636a10401ab1_0">
											<gml:posList>35.66904156267779 139.7402974529838 46.145 35.6690353313078 139.7403053912954 46.145 35.6690353313078 139.7403053912954 106.781 35.66904156267779 139.7402974529838 106.781 35.66904156267779 139.7402974529838 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-868538ec-abc5-47b1-a984-f41582f066b3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-868538ec-abc5-47b1-a984-f41582f066b3_0">
											<gml:posList>35.669046549822845 139.74038245779573 106.781 35.66903945980819 139.74037569477107 106.781 35.66903945980819 139.74037569477107 46.145 35.669046549822845 139.74038245779573 46.145 35.669046549822845 139.74038245779573 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-63c39608-a8b8-4cde-9493-670dad8cde96">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-63c39608-a8b8-4cde-9493-670dad8cde96_0">
											<gml:posList>35.66904900325195 139.74029128063998 46.145 35.66904156267779 139.7402974529838 46.145 35.66904156267779 139.7402974529838 106.781 35.66904900325195 139.74029128063998 106.781 35.66904900325195 139.74029128063998 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-490e6da0-cf05-4373-ad13-7c80bea74a72">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-490e6da0-cf05-4373-ad13-7c80bea74a72_0">
											<gml:posList>35.669046549822845 139.74038245779573 46.145 35.66905463885142 139.74038726450797 46.145 35.66905463885142 139.74038726450797 106.781 35.669046549822845 139.74038245779573 106.781 35.669046549822845 139.74038245779573 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e71d33f-7bd6-4024-99f6-d97136636711">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e71d33f-7bd6-4024-99f6-d97136636711_0">
											<gml:posList>35.66905732874134 139.74028713974627 46.145 35.66904900325195 139.74029128063998 46.145 35.66904900325195 139.74029128063998 106.781 35.66905732874134 139.74028713974627 106.781 35.66905732874134 139.74028713974627 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-55a774cc-9465-4a3a-bd52-85444bbf0cb5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-55a774cc-9465-4a3a-bd52-85444bbf0cb5_0">
											<gml:posList>35.66906335716943 139.74038990546043 106.781 35.66905463885142 139.74038726450797 106.781 35.66905463885142 139.74038726450797 46.145 35.66906335716943 139.74038990546043 46.145 35.66906335716943 139.74038990546043 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96374e24-5d29-4e19-968b-50a5887442c6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96374e24-5d29-4e19-968b-50a5887442c6_0">
											<gml:posList>35.669066169711485 139.7402851964231 46.145 35.66905732874134 139.74028713974627 46.145 35.66905732874134 139.74028713974627 106.781 35.669066169711485 139.7402851964231 106.781 35.669066169711485 139.7402851964231 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cb24c73-19b5-4b31-8f16-f51994168a34">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cb24c73-19b5-4b31-8f16-f51994168a34_0">
											<gml:posList>35.669072335129066 139.74039027062022 106.781 35.66906335716943 139.74038990546043 106.781 35.66906335716943 139.74038990546043 46.145 35.669072335129066 139.74039027062022 46.145 35.669072335129066 139.74039027062022 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c0104ae8-89fd-480a-b77e-94a8d5747531">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c0104ae8-89fd-480a-b77e-94a8d5747531_0">
											<gml:posList>35.66906335716943 139.74038990546043 106.781 35.669072335129066 139.74039027062022 106.781 35.66908118512312 139.74038833834362 106.781 35.66908951061581 139.74038419745833 106.781 35.66909695118584 139.74037801407277 106.781 35.66910318256906 139.74037008680673 106.781 35.669107925587014 139.74036073632044 106.781 35.669110982253 139.7403503715488 106.781 35.669112208714026 139.7403394676409 106.781 35.66911156927334 139.7403284885744 106.781 35.669109073311574 139.74031790932077 106.781 35.66910483836565 139.74030819367988 106.781 35.66909905405684 139.74029977222946 106.781 35.66909195502388 139.74029300921816 106.781 35.669083875005335 139.74028820250277 106.781 35.669075147671414 139.74028556157114 106.781 35.669066169711485 139.7402851964231 106.781 35.66905732874134 139.74028713974627 106.781 35.66904900325195 139.74029128063998 106.781 35.66904156267779 139.7402974529838 106.781 35.6690353313078 139.7403053912954 106.781 35.6690305882941 139.74031474177653 106.781 35.66902753162258 139.74032509549303 106.781 35.66902629614911 139.74033599940012 106.781 35.66902694461135 139.74034698949063 106.781 35.669029440570576 139.74035756873434 106.781 35.66903367550404 139.74036727332262 106.781 35.66903945980819 139.74037569477107 106.781 35.669046549822845 139.74038245779573 106.781 35.66905463885142 139.74038726450797 106.781 35.66906335716943 139.74038990546043 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4a11b3fa-a255-4e06-a959-c881075fee33">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4a11b3fa-a255-4e06-a959-c881075fee33_0">
											<gml:posList>35.669075147671414 139.74028556157114 46.145 35.669066169711485 139.7402851964231 46.145 35.669066169711485 139.7402851964231 106.781 35.669075147671414 139.74028556157114 106.781 35.669075147671414 139.74028556157114 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4794bb19-5ae3-4c90-926f-1e2985b6f268">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4794bb19-5ae3-4c90-926f-1e2985b6f268_0">
											<gml:posList>35.669072335129066 139.74039027062022 106.781 35.669072335129066 139.74039027062022 46.145 35.66908118512312 139.74038833834362 46.145 35.66908118512312 139.74038833834362 106.781 35.669072335129066 139.74039027062022 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d36d311c-9692-440b-93a6-9e32bc5ee654">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d36d311c-9692-440b-93a6-9e32bc5ee654_0">
											<gml:posList>35.669083875005335 139.74028820250277 46.145 35.669075147671414 139.74028556157114 46.145 35.669075147671414 139.74028556157114 106.781 35.669083875005335 139.74028820250277 106.781 35.669083875005335 139.74028820250277 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-66b4194b-e571-4bb9-8ed1-d8ce0e93aea9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-66b4194b-e571-4bb9-8ed1-d8ce0e93aea9_0">
											<gml:posList>35.66908573488684 139.740502372811 47.177 35.66907954138047 139.7405126749284 47.177 35.66907954138047 139.7405126749284 48.605 35.66908573488684 139.740502372811 48.605 35.66908573488684 139.740502372811 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d171f8ab-a707-473a-a172-793543f54a57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d171f8ab-a707-473a-a172-793543f54a57_0">
											<gml:posList>35.66908791194932 139.74052023180408 47.177 35.66908791194932 139.74052023180408 48.605 35.66907954138047 139.7405126749284 48.605 35.66907954138047 139.7405126749284 47.177 35.66908791194932 139.74052023180408 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2d4aacbf-0978-4fd7-86bc-70e9d8a28af1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2d4aacbf-0978-4fd7-86bc-70e9d8a28af1_0">
											<gml:posList>35.66908951061581 139.74038419745833 106.781 35.66908118512312 139.74038833834362 106.781 35.66908118512312 139.74038833834362 46.145 35.66908951061581 139.74038419745833 46.145 35.66908951061581 139.74038419745833 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1a20066-3b02-4946-aba7-f29266f8dcba">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1a20066-3b02-4946-aba7-f29266f8dcba_0">
											<gml:posList>35.66909410544782 139.74050991864013 48.605 35.66908573488684 139.740502372811 48.605 35.66907954138047 139.7405126749284 48.605 35.66908791194932 139.74052023180408 48.605 35.66909410544782 139.74050991864013 48.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-024d284d-118a-4b0c-a61c-32d1489f75a0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-024d284d-118a-4b0c-a61c-32d1489f75a0_0">
											<gml:posList>35.66909195502388 139.74029300921816 46.145 35.669083875005335 139.74028820250277 46.145 35.669083875005335 139.74028820250277 106.781 35.66909195502388 139.74029300921816 106.781 35.66909195502388 139.74029300921816 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ea85e66c-81b2-4fe0-b92e-4f13e962c1c2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ea85e66c-81b2-4fe0-b92e-4f13e962c1c2_0">
											<gml:posList>35.66909410544782 139.74050991864013 47.177 35.66908573488684 139.740502372811 47.177 35.66908573488684 139.740502372811 48.605 35.66909410544782 139.74050991864013 48.605 35.66909410544782 139.74050991864013 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7626b9f7-185e-4652-ad4d-35b6499b124e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7626b9f7-185e-4652-ad4d-35b6499b124e_0">
											<gml:posList>35.66909695118584 139.74037801407277 46.145 35.66909695118584 139.74037801407277 106.781 35.66908951061581 139.74038419745833 106.781 35.66908951061581 139.74038419745833 46.145 35.66909695118584 139.74037801407277 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bca3a9e-f8e5-439e-8ac1-7b94ae801bcb">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bca3a9e-f8e5-439e-8ac1-7b94ae801bcb_0">
											<gml:posList>35.66908980615116 139.74052194175417 47.177 35.66909816769717 139.74052948759618 47.177 35.66909816769717 139.74052948759618 48.605 35.66908980615116 139.74052194175417 48.605 35.66908980615116 139.74052194175417 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a057faa-6301-4756-b974-c8bc6e92f5a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a057faa-6301-4756-b974-c8bc6e92f5a6_0">
											<gml:posList>35.66909195502388 139.74029300921816 46.145 35.66909195502388 139.74029300921816 106.781 35.66909905405684 139.74029977222946 106.781 35.66909905405684 139.74029977222946 46.145 35.66909195502388 139.74029300921816 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e1b22f9-6f35-4033-84f1-98b44f269c54">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e1b22f9-6f35-4033-84f1-98b44f269c54_0">
											<gml:posList>35.66910436119645 139.74051917443157 48.605 35.6690959996498 139.74051162859007 48.605 35.66908980615116 139.74052194175417 48.605 35.66909816769717 139.74052948759618 48.605 35.66910436119645 139.74051917443157 48.605</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a39619d4-94e9-4950-b20b-a33bab140b63">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a39619d4-94e9-4950-b20b-a33bab140b63_0">
											<gml:posList>35.66910318256906 139.74037008680673 106.781 35.66909695118584 139.74037801407277 106.781 35.66909695118584 139.74037801407277 46.145 35.66910318256906 139.74037008680673 46.145 35.66910318256906 139.74037008680673 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-91adf116-a8e4-4814-88a6-d028d2d3a67e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-91adf116-a8e4-4814-88a6-d028d2d3a67e_0">
											<gml:posList>35.66910436119645 139.74051917443157 47.177 35.6690959996498 139.74051162859007 47.177 35.6690959996498 139.74051162859007 48.605 35.66910436119645 139.74051917443157 48.605 35.66910436119645 139.74051917443157 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-41a9ef24-e360-48b6-bd40-60b6551f6c5b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-41a9ef24-e360-48b6-bd40-60b6551f6c5b_0">
											<gml:posList>35.66910436119645 139.74051917443157 47.177 35.66910436119645 139.74051917443157 48.605 35.66909816769717 139.74052948759618 48.605 35.66909816769717 139.74052948759618 47.177 35.66910436119645 139.74051917443157 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-21569124-1bb6-4c26-a028-c4416f56d2ff">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-21569124-1bb6-4c26-a028-c4416f56d2ff_0">
											<gml:posList>35.66909905405684 139.74029977222946 106.781 35.66910483836565 139.74030819367988 106.781 35.66910483836565 139.74030819367988 46.145 35.66909905405684 139.74029977222946 46.145 35.66909905405684 139.74029977222946 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-79498f95-86f0-4336-9c35-9af0cd334cc7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-79498f95-86f0-4336-9c35-9af0cd334cc7_0">
											<gml:posList>35.669107925587014 139.74036073632044 106.781 35.66910318256906 139.74037008680673 106.781 35.66910318256906 139.74037008680673 46.145 35.669107925587014 139.74036073632044 46.145 35.669107925587014 139.74036073632044 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-20845317-31f3-47f1-baed-fd5f4bbdee31">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-20845317-31f3-47f1-baed-fd5f4bbdee31_0">
											<gml:posList>35.669112572592454 139.74048395000807 47.177 35.66910017704518 139.74050517284158 47.177 35.66910017704518 139.74050517284158 49.609 35.669112572592454 139.74048395000807 49.609 35.669112572592454 139.74048395000807 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5e1882f3-eabb-41a6-9e78-89e89c5b3668">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5e1882f3-eabb-41a6-9e78-89e89c5b3668_0">
											<gml:posList>35.66910483836565 139.74030819367988 106.781 35.669109073311574 139.74031790932077 106.781 35.669109073311574 139.74031790932077 46.145 35.66910483836565 139.74030819367988 46.145 35.66910483836565 139.74030819367988 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2c6ed522-2f28-4948-b54e-e9c8c329d14f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2c6ed522-2f28-4948-b54e-e9c8c329d14f_0">
											<gml:posList>35.669110982253 139.7403503715488 106.781 35.669107925587014 139.74036073632044 106.781 35.669107925587014 139.74036073632044 46.145 35.669110982253 139.7403503715488 46.145 35.669110982253 139.7403503715488 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ccf4c2d2-33a8-476e-b5c8-a5bbd245d397">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ccf4c2d2-33a8-476e-b5c8-a5bbd245d397_0">
											<gml:posList>35.669109073311574 139.74031790932077 106.781 35.66911156927334 139.7403284885744 106.781 35.66911156927334 139.7403284885744 46.145 35.669109073311574 139.74031790932077 46.145 35.669109073311574 139.74031790932077 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a1b8e7a-03f4-43af-a2bf-16a1f4d8e060">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a1b8e7a-03f4-43af-a2bf-16a1f4d8e060_0">
											<gml:posList>35.669112208714026 139.7403394676409 106.781 35.669110982253 139.7403503715488 106.781 35.669110982253 139.7403503715488 46.145 35.669112208714026 139.7403394676409 46.145 35.669112208714026 139.7403394676409 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-35ee7d47-950a-42d3-b852-a48a198feb5d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-35ee7d47-950a-42d3-b852-a48a198feb5d_0">
											<gml:posList>35.66911156927334 139.7403284885744 106.781 35.669112208714026 139.7403394676409 106.781 35.669112208714026 139.7403394676409 46.145 35.66911156927334 139.7403284885744 46.145 35.66911156927334 139.7403284885744 106.781</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-00e64d68-8e16-40bc-a7a8-c83822c3c962">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-00e64d68-8e16-40bc-a7a8-c83822c3c962_0">
											<gml:posList>35.66912782283413 139.7405294311804 47.177 35.66912782283413 139.7405294311804 49.609 35.66910017704518 139.74050517284158 49.609 35.66910017704518 139.74050517284158 47.177 35.66912782283413 139.7405294311804 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d0eafa34-907b-460a-a6bd-7f0cf0a298c8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d0eafa34-907b-460a-a6bd-7f0cf0a298c8_0">
											<gml:posList>35.66911625152273 139.74047398217894 47.177 35.669120887984405 139.74047839524377 47.177 35.669120887984405 139.74047839524377 48.803 35.66911625152273 139.74047398217894 48.803 35.66911625152273 139.74047398217894 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3a36c767-730d-4239-9f87-c5d4d0c6969c">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3a36c767-730d-4239-9f87-c5d4d0c6969c_0">
											<gml:posList>35.66912248144696 139.74046415499336 47.177 35.66911625152273 139.74047398217894 47.177 35.66911625152273 139.74047398217894 48.803 35.66912248144696 139.74046415499336 48.803 35.66912248144696 139.74046415499336 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-62123b0e-85a9-4be8-8c34-471072b59879">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-62123b0e-85a9-4be8-8c34-471072b59879_0">
											<gml:posList>35.669117790868334 139.7404596978076 47.177 35.66912248144696 139.74046415499336 47.177 35.66912248144696 139.74046415499336 48.803 35.669117790868334 139.7404596978076 48.803 35.669117790868334 139.7404596978076 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9d642450-a19d-4e0f-a702-dcb27c39ca93">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9d642450-a19d-4e0f-a702-dcb27c39ca93_0">
											<gml:posList>35.669112572592454 139.74048395000807 49.609 35.66910017704518 139.74050517284158 49.609 35.66912782283413 139.7405294311804 49.609 35.66914021839413 139.74050821938934 49.609 35.669112572592454 139.74048395000807 49.609</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d1958eb1-1406-4451-8be0-76745f0fcedd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d1958eb1-1406-4451-8be0-76745f0fcedd_0">
											<gml:posList>35.669124479920484 139.74044913000105 47.177 35.669117790868334 139.7404596978076 47.177 35.669117790868334 139.7404596978076 48.803 35.669124479920484 139.74044913000105 48.803 35.669124479920484 139.74044913000105 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7651a2c3-7a63-41c0-b19c-3ee6e9edfba5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7651a2c3-7a63-41c0-b19c-3ee6e9edfba5_0">
											<gml:posList>35.66912248144696 139.74046415499336 48.803 35.66911625152273 139.74047398217894 48.803 35.669120887984405 139.74047839524377 48.803 35.66913379793967 139.74045798921526 48.803 35.669124479920484 139.74044913000105 48.803 35.669117790868334 139.7404596978076 48.803 35.66912248144696 139.74046415499336 48.803</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a04e8790-03d5-400d-afe4-9c4a0529239f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a04e8790-03d5-400d-afe4-9c4a0529239f_0">
											<gml:posList>35.66914021839413 139.74050821938934 47.177 35.669112572592454 139.74048395000807 47.177 35.669112572592454 139.74048395000807 49.609 35.66914021839413 139.74050821938934 49.609 35.66914021839413 139.74050821938934 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aee1f58b-ba70-463c-94ce-e6dccf03d027">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aee1f58b-ba70-463c-94ce-e6dccf03d027_0">
											<gml:posList>35.669120887984405 139.74047839524377 47.177 35.66913379793967 139.74045798921526 47.177 35.66913379793967 139.74045798921526 48.803 35.669120887984405 139.74047839524377 48.803 35.669120887984405 139.74047839524377 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cc1ee215-b29f-4ab6-8223-57fdfc2094a6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cc1ee215-b29f-4ab6-8223-57fdfc2094a6_0">
											<gml:posList>35.66913379793967 139.74045798921526 47.177 35.669124479920484 139.74044913000105 47.177 35.669124479920484 139.74044913000105 48.803 35.66913379793967 139.74045798921526 48.803 35.66913379793967 139.74045798921526 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1afda882-c8a4-483c-aacc-80e00fdaaeca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1afda882-c8a4-483c-aacc-80e00fdaaeca_0">
											<gml:posList>35.66912782283413 139.7405294311804 47.177 35.66914021839413 139.74050821938934 47.177 35.66914021839413 139.74050821938934 49.609 35.66912782283413 139.7405294311804 49.609 35.66912782283413 139.7405294311804 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-1d3c63a8-34d7-4a78-bec1-a01369796a1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-1d3c63a8-34d7-4a78-bec1-a01369796a1a_0">
											<gml:posList>35.669140211818046 139.7404646204852 47.177 35.66913114694879 139.740480128645 47.177 35.66913114694879 139.740480128645 48.629 35.669140211818046 139.7404646204852 48.629 35.669140211818046 139.7404646204852 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ddc90554-e43d-439a-b7db-0c6e0595873d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ddc90554-e43d-439a-b7db-0c6e0595873d_0">
											<gml:posList>35.66913114694879 139.740480128645 47.177 35.669145551627594 139.7404927707822 47.177 35.669145551627594 139.7404927707822 48.629 35.66913114694879 139.740480128645 48.629 35.66913114694879 139.740480128645 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d840421-61ed-442c-aee9-afda3670f5ae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d840421-61ed-442c-aee9-afda3670f5ae_0">
											<gml:posList>35.669140593305286 139.74043333752024 47.177 35.66914418354579 139.74043693438557 47.177 35.66914418354579 139.74043693438557 48.808 35.669140593305286 139.74043333752024 48.808 35.669140593305286 139.74043333752024 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0900e8e8-06bd-497a-a583-9bcfaedebd75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0900e8e8-06bd-497a-a583-9bcfaedebd75_0">
											<gml:posList>35.66915460748472 139.74047726263143 48.629 35.669140211818046 139.7404646204852 48.629 35.66913114694879 139.740480128645 48.629 35.669145551627594 139.7404927707822 48.629 35.66915460748472 139.74047726263143 48.629</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08cc4392-9f9b-4f5d-91ec-61a5fd1d53f1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08cc4392-9f9b-4f5d-91ec-61a5fd1d53f1_0">
											<gml:posList>35.669147723950886 139.740422669782 47.177 35.669140593305286 139.74043333752024 47.177 35.669140593305286 139.74043333752024 48.808 35.669147723950886 139.740422669782 48.808 35.669147723950886 139.740422669782 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4029bd9d-05f9-4d96-8ae4-b98fed8ff9a5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4029bd9d-05f9-4d96-8ae4-b98fed8ff9a5_0">
											<gml:posList>35.669140593305286 139.74043333752024 48.808 35.66914418354579 139.74043693438557 48.808 35.66915130517797 139.74042626665758 48.808 35.669147723950886 139.740422669782 48.808 35.669140593305286 139.74043333752024 48.808</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-78008943-4776-493d-aedc-a660db4007d4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-78008943-4776-493d-aedc-a660db4007d4_0">
											<gml:posList>35.66915460748472 139.74047726263143 47.177 35.669140211818046 139.7404646204852 47.177 35.669140211818046 139.7404646204852 48.629 35.66915460748472 139.74047726263143 48.629 35.66915460748472 139.74047726263143 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-3f97200c-c8bb-4197-a8a5-8dc195c27394">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-3f97200c-c8bb-4197-a8a5-8dc195c27394_0">
											<gml:posList>35.66914418354579 139.74043693438557 47.177 35.66915130517797 139.74042626665758 47.177 35.66915130517797 139.74042626665758 48.808 35.66914418354579 139.74043693438557 48.808 35.66914418354579 139.74043693438557 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb2f8993-391f-4bb9-9bec-b369c96a4b4a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb2f8993-391f-4bb9-9bec-b369c96a4b4a_0">
											<gml:posList>35.66915130517797 139.74042626665758 47.177 35.669147723950886 139.740422669782 47.177 35.669147723950886 139.740422669782 48.808 35.66915130517797 139.74042626665758 48.808 35.66915130517797 139.74042626665758 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-60650b03-8f97-4869-973d-24a6e2e19fae">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-60650b03-8f97-4869-973d-24a6e2e19fae_0">
											<gml:posList>35.669145551627594 139.7404927707822 47.177 35.66915460748472 139.74047726263143 47.177 35.66915460748472 139.74047726263143 48.629 35.669145551627594 139.7404927707822 48.629 35.669145551627594 139.7404927707822 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-950cbc43-ab41-47e1-a1a3-2fcfc2cbef23">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-950cbc43-ab41-47e1-a1a3-2fcfc2cbef23_0">
											<gml:posList>35.669145252781846 139.74045589928213 47.177 35.66915547232631 139.74046495628485 47.177 35.66915547232631 139.74046495628485 48.368 35.669145252781846 139.74045589928213 48.368 35.669145252781846 139.74045589928213 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-42a72fcb-f89f-4fd1-b24a-7007bcbcc3e1">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-42a72fcb-f89f-4fd1-b24a-7007bcbcc3e1_0">
											<gml:posList>35.66915851269193 139.74043344931147 47.177 35.669145252781846 139.74045589928213 47.177 35.669145252781846 139.74045589928213 48.368 35.66915851269193 139.74043344931147 48.368 35.66915851269193 139.74043344931147 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2ccd94b3-acee-4252-a360-2d2a24762e91">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2ccd94b3-acee-4252-a360-2d2a24762e91_0">
											<gml:posList>35.669147956931134 139.7404092043287 47.177 35.66915777956837 139.74041786412644 47.177 35.66915777956837 139.74041786412644 48.808 35.669147956931134 139.7404092043287 48.808 35.669147956931134 139.7404092043287 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-cedffedc-d184-4384-8596-2e7032d07dca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-cedffedc-d184-4384-8596-2e7032d07dca_0">
											<gml:posList>35.66916560064998 139.74037914955647 47.177 35.669147956931134 139.7404092043287 47.177 35.669147956931134 139.7404092043287 48.808 35.66916560064998 139.74037914955647 48.808 35.66916560064998 139.74037914955647 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b3ff9b0-d863-4a9f-ad64-266eb51f680d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b3ff9b0-d863-4a9f-ad64-266eb51f680d_0">
											<gml:posList>35.66916872323285 139.74044251736936 48.368 35.66915851269193 139.74043344931147 48.368 35.669145252781846 139.74045589928213 48.368 35.66915547232631 139.74046495628485 48.368 35.66916872323285 139.74044251736936 48.368</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-18f7e2fb-b472-47cd-bc71-53e1de7d1a8a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-18f7e2fb-b472-47cd-bc71-53e1de7d1a8a_0">
											<gml:posList>35.669156722204285 139.7404960937674 47.177 35.66916080835104 139.74049988889175 47.177 35.66916080835104 139.74049988889175 48.881 35.669156722204285 139.7404960937674 48.881 35.669156722204285 139.7404960937674 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f21e4280-488d-4d3e-a0da-6b2c8bff3d7a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f21e4280-488d-4d3e-a0da-6b2c8bff3d7a_0">
											<gml:posList>35.669156722204285 139.7404960937674 47.177 35.669156722204285 139.7404960937674 48.881 35.66916411325691 139.74048413333827 48.881 35.66916411325691 139.74048413333827 47.177 35.669156722204285 139.7404960937674 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-193a1bc6-80ff-4ba1-9bda-30f7d7f2ae25">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-193a1bc6-80ff-4ba1-9bda-30f7d7f2ae25_0">
											<gml:posList>35.66917542328935 139.74038780935243 48.808 35.66916560064998 139.74037914955647 48.808 35.669147956931134 139.7404092043287 48.808 35.66915777956837 139.74041786412644 48.808 35.66917542328935 139.74038780935243 48.808</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a66324a8-6328-4cc7-8070-f30d3490a254">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a66324a8-6328-4cc7-8070-f30d3490a254_0">
											<gml:posList>35.66915547232631 139.74046495628485 47.177 35.66916872323285 139.74044251736936 47.177 35.66916872323285 139.74044251736936 48.368 35.66915547232631 139.74046495628485 48.368 35.66915547232631 139.74046495628485 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-009e0cdd-2b8a-46a4-a9ad-7a8459133efc">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-009e0cdd-2b8a-46a4-a9ad-7a8459133efc_0">
											<gml:posList>35.669156722204285 139.7404960937674 48.881 35.66916080835104 139.74049988889175 48.881 35.669168199404034 139.74048792846236 48.881 35.66916411325691 139.74048413333827 48.881 35.669156722204285 139.7404960937674 48.881</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99ba6297-e7d9-4925-b910-7a513e12c3f3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99ba6297-e7d9-4925-b910-7a513e12c3f3_0">
											<gml:posList>35.66916872323285 139.74044251736936 47.177 35.66915851269193 139.74043344931147 47.177 35.66915851269193 139.74043344931147 48.368 35.66916872323285 139.74044251736936 48.368 35.66916872323285 139.74044251736936 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fad8e47f-c3b0-4f18-977c-53d1bb5143ab">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fad8e47f-c3b0-4f18-977c-53d1bb5143ab_0">
											<gml:posList>35.66916080835104 139.74049988889175 47.177 35.669168199404034 139.74048792846236 47.177 35.669168199404034 139.74048792846236 48.881 35.66916080835104 139.74049988889175 48.881 35.66916080835104 139.74049988889175 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f500d39d-5d1e-4e7f-b579-46e18d74b48d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f500d39d-5d1e-4e7f-b579-46e18d74b48d_0">
											<gml:posList>35.669168199404034 139.74048792846236 47.177 35.66916411325691 139.74048413333827 47.177 35.66916411325691 139.74048413333827 48.881 35.669168199404034 139.74048792846236 48.881 35.669168199404034 139.74048792846236 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-49acc283-4c63-4403-b595-3b4a124fe133">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-49acc283-4c63-4403-b595-3b4a124fe133_0">
											<gml:posList>35.66915777956837 139.74041786412644 47.177 35.66917542328935 139.74038780935243 47.177 35.66917542328935 139.74038780935243 48.808 35.66915777956837 139.74041786412644 48.808 35.66915777956837 139.74041786412644 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f7a8f2e-ebf8-4356-bac2-5b401e4dda02">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f7a8f2e-ebf8-4356-bac2-5b401e4dda02_0">
											<gml:posList>35.669164527016385 139.74042457233128 47.177 35.669173610399255 139.7404330672978 47.177 35.669173610399255 139.7404330672978 48.581 35.669164527016385 139.74042457233128 48.581 35.669164527016385 139.74042457233128 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0563b7bd-7141-47d0-95b3-e3cdc15c10a3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0563b7bd-7141-47d0-95b3-e3cdc15c10a3_0">
											<gml:posList>35.66917542328935 139.74038780935243 47.177 35.66916560064998 139.74037914955647 47.177 35.66916560064998 139.74037914955647 48.808 35.66917542328935 139.74038780935243 48.808 35.66917542328935 139.74038780935243 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bf565cb6-3736-44c4-8a42-f17505633094">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bf565cb6-3736-44c4-8a42-f17505633094_0">
											<gml:posList>35.66917178425161 139.74048453316075 47.177 35.66917625828698 139.74048871444936 47.177 35.66917625828698 139.74048871444936 48.838 35.66917178425161 139.74048453316075 48.838 35.66917178425161 139.74048453316075 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c6e1deb9-e7ed-45c3-bd02-e7dcfbd4d5fd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c6e1deb9-e7ed-45c3-bd02-e7dcfbd4d5fd_0">
											<gml:posList>35.66918356746561 139.74039399677082 47.177 35.669164527016385 139.74042457233128 47.177 35.669164527016385 139.74042457233128 48.581 35.66918356746561 139.74039399677082 48.581 35.66918356746561 139.74039399677082 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d6f646b-c5da-44e5-bd0a-dbe9fc6d4d59">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d6f646b-c5da-44e5-bd0a-dbe9fc6d4d59_0">
											<gml:posList>35.6691715605896 139.74036988602123 47.177 35.669181184910634 139.74037852395443 47.177 35.669181184910634 139.74037852395443 48.743 35.6691715605896 139.74036988602123 48.743 35.6691715605896 139.74036988602123 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cd861cc-fc63-4df3-b6c1-86def04411df">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cd861cc-fc63-4df3-b6c1-86def04411df_0">
											<gml:posList>35.66918229928317 139.7404676646444 47.177 35.66917178425161 139.74048453316075 47.177 35.66917178425161 139.74048453316075 48.838 35.66918229928317 139.7404676646444 48.838 35.66918229928317 139.7404676646444 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f44f5157-342b-443c-8c64-b41b09dbe55f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f44f5157-342b-443c-8c64-b41b09dbe55f_0">
											<gml:posList>35.669164527016385 139.74042457233128 48.581 35.669173610399255 139.7404330672978 48.581 35.66919265084208 139.7404024806898 48.581 35.66918356746561 139.74039399677082 48.581 35.669164527016385 139.74042457233128 48.581</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ce882f1d-90d6-46d0-b6f0-09be30fcb1a7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ce882f1d-90d6-46d0-b6f0-09be30fcb1a7_0">
											<gml:posList>35.66917704950451 139.740462755213 47.177 35.66917704950451 139.740462755213 48.838 35.66918208194859 139.7404546746891 48.838 35.66918208194859 139.7404546746891 47.177 35.66917704950451 139.740462755213 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-733ea713-da27-4a8e-b719-d5004276c26d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-733ea713-da27-4a8e-b719-d5004276c26d_0">
											<gml:posList>35.66917704950451 139.740462755213 47.177 35.66918229928317 139.7404676646444 47.177 35.66918229928317 139.7404676646444 48.838 35.66917704950451 139.740462755213 48.838 35.66917704950451 139.740462755213 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7e78d30e-f8c4-4357-bf9b-00d81b3afc9e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7e78d30e-f8c4-4357-bf9b-00d81b3afc9e_0">
											<gml:posList>35.669189789832345 139.74033936661644 47.177 35.6691715605896 139.74036988602123 47.177 35.6691715605896 139.74036988602123 48.743 35.669189789832345 139.74033936661644 48.743 35.669189789832345 139.74033936661644 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-16529c56-e777-437a-9dd5-d4d6556e54d5">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-16529c56-e777-437a-9dd5-d4d6556e54d5_0">
											<gml:posList>35.66917704950451 139.740462755213 48.838 35.66918229928317 139.7404676646444 48.838 35.66917178425161 139.74048453316075 48.838 35.66917625828698 139.74048871444936 48.838 35.6691917967586 139.74046377646482 48.838 35.66918208194859 139.7404546746891 48.838 35.66917704950451 139.740462755213 48.838</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ff8c4a4c-bbec-4069-a51d-c19df433511e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ff8c4a4c-bbec-4069-a51d-c19df433511e_0">
											<gml:posList>35.669173610399255 139.7404330672978 47.177 35.66919265084208 139.7404024806898 47.177 35.66919265084208 139.7404024806898 48.581 35.669173610399255 139.7404330672978 48.581 35.669173610399255 139.7404330672978 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2f064192-b0db-415e-a252-944307e1a561">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2f064192-b0db-415e-a252-944307e1a561_0">
											<gml:posList>35.6691917967586 139.74046377646482 47.177 35.6691917967586 139.74046377646482 48.838 35.66917625828698 139.74048871444936 48.838 35.66917625828698 139.74048871444936 47.177 35.6691917967586 139.74046377646482 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5ce8b932-a256-4652-bbea-e2e1939a844a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5ce8b932-a256-4652-bbea-e2e1939a844a_0">
											<gml:posList>35.66919941415552 139.7403480045479 48.743 35.669189789832345 139.74033936661644 48.743 35.6691715605896 139.74036988602123 48.743 35.669181184910634 139.74037852395443 48.743 35.66919941415552 139.7403480045479 48.743</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-ed1dd4d3-69d4-430c-a824-1615432fe17b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-ed1dd4d3-69d4-430c-a824-1615432fe17b_0">
											<gml:posList>35.6691917967586 139.74046377646482 47.177 35.66918208194859 139.7404546746891 47.177 35.66918208194859 139.7404546746891 48.838 35.6691917967586 139.74046377646482 48.838 35.6691917967586 139.74046377646482 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-851bb5c4-3d1d-4e1a-bdea-5a233b02a50a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-851bb5c4-3d1d-4e1a-bdea-5a233b02a50a_0">
											<gml:posList>35.66918356746561 139.74039399677082 47.177 35.66918356746561 139.74039399677082 48.581 35.66919265084208 139.7404024806898 48.581 35.66919265084208 139.7404024806898 47.177 35.66918356746561 139.74039399677082 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-069729da-2b87-4304-ac8f-dda205d44eac">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-069729da-2b87-4304-ac8f-dda205d44eac_0">
											<gml:posList>35.669181184910634 139.74037852395443 47.177 35.66919941415552 139.7403480045479 47.177 35.66919941415552 139.7403480045479 48.743 35.669181184910634 139.74037852395443 48.743 35.669181184910634 139.74037852395443 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5c813a14-79f0-410c-bdf2-a9d159063ae9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-5c813a14-79f0-410c-bdf2-a9d159063ae9_0">
											<gml:posList>35.66918864471789 139.74038558480717 47.177 35.66919355162006 139.74039003069564 47.177 35.66919355162006 139.74039003069564 48.614 35.66918864471789 139.74038558480717 48.614 35.66918864471789 139.74038558480717 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d822b0e7-69f0-4625-a041-065d50d95805">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d822b0e7-69f0-4625-a041-065d50d95805_0">
											<gml:posList>35.66918749271293 139.7404462623431 47.177 35.6691963953767 139.74045418312684 47.177 35.6691963953767 139.74045418312684 48.646 35.66918749271293 139.7404462623431 48.646 35.66918749271293 139.7404462623431 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6c77a4bd-5e56-406e-aa31-10396bd7fcdf">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6c77a4bd-5e56-406e-aa31-10396bd7fcdf_0">
											<gml:posList>35.669189789832345 139.74033936661644 47.177 35.669189789832345 139.74033936661644 48.743 35.66919941415552 139.7403480045479 48.743 35.66919941415552 139.7403480045479 47.177 35.669189789832345 139.74033936661644 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-94230c68-9145-42cc-a0dc-ca38e6c9b111">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-94230c68-9145-42cc-a0dc-ca38e6c9b111_0">
											<gml:posList>35.6692061898789 139.74041469302801 47.177 35.66918749271293 139.7404462623431 47.177 35.66918749271293 139.7404462623431 48.646 35.6692061898789 139.74041469302801 48.646 35.6692061898789 139.74041469302801 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f44a5ea1-c18b-482b-a4eb-f939ce9ec469">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f44a5ea1-c18b-482b-a4eb-f939ce9ec469_0">
											<gml:posList>35.66918864471789 139.74038558480717 47.177 35.66918864471789 139.74038558480717 48.614 35.669208782613836 139.74035213597014 48.614 35.669208782613836 139.74035213597014 47.177 35.66918864471789 139.74038558480717 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6bcaa67c-ba7d-44f9-833b-1da57dcc2b09">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6bcaa67c-ba7d-44f9-833b-1da57dcc2b09_0">
											<gml:posList>35.6691962801197 139.74032821357778 47.177 35.66920570605643 139.74033674127776 47.177 35.66920570605643 139.74033674127776 48.914 35.6691962801197 139.74032821357778 48.914 35.6691962801197 139.74032821357778 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-92506a12-96b4-4f0b-aaee-d6866c45a606">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-92506a12-96b4-4f0b-aaee-d6866c45a606_0">
											<gml:posList>35.66918864471789 139.74038558480717 48.614 35.66919355162006 139.74039003069564 48.614 35.66921368951724 139.74035658185767 48.614 35.669208782613836 139.74035213597014 48.614 35.66918864471789 139.74038558480717 48.614</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-601c9a2c-a793-4227-91f0-a399e0f9418f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-601c9a2c-a793-4227-91f0-a399e0f9418f_0">
											<gml:posList>35.66918749271293 139.7404462623431 48.646 35.6691963953767 139.74045418312684 48.646 35.669215092544725 139.7404226138101 48.646 35.6692061898789 139.74041469302801 48.646 35.66918749271293 139.7404462623431 48.646</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fccbc2bd-75e6-4b23-bb4b-33e40721872b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fccbc2bd-75e6-4b23-bb4b-33e40721872b_0">
											<gml:posList>35.6691962801197 139.74032821357778 47.177 35.6691962801197 139.74032821357778 48.914 35.66920861309412 139.74030770876047 48.914 35.66920861309412 139.74030770876047 47.177 35.6691962801197 139.74032821357778 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-96fb5cbc-574e-4520-80cf-2760e852e55d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-96fb5cbc-574e-4520-80cf-2760e852e55d_0">
											<gml:posList>35.66919355162006 139.74039003069564 47.177 35.66921368951724 139.74035658185767 47.177 35.66921368951724 139.74035658185767 48.614 35.66919355162006 139.74039003069564 48.614 35.66919355162006 139.74039003069564 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0f54b2bd-0d72-431e-9b3c-f6f09ab7ceed">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0f54b2bd-0d72-431e-9b3c-f6f09ab7ceed_0">
											<gml:posList>35.6691963953767 139.74045418312684 47.177 35.669215092544725 139.7404226138101 47.177 35.669215092544725 139.7404226138101 48.646 35.6691963953767 139.74045418312684 48.646 35.6691963953767 139.74045418312684 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-6b00400f-bb07-40c4-9ec4-f494e49585e2">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-6b00400f-bb07-40c4-9ec4-f494e49585e2_0">
											<gml:posList>35.6691962801197 139.74032821357778 48.914 35.66920570605643 139.74033674127776 48.914 35.669218039023754 139.74031622541324 48.914 35.66920861309412 139.74030770876047 48.914 35.6691962801197 139.74032821357778 48.914</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-916ea593-3492-4cef-8760-4a9f251db1fa">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-916ea593-3492-4cef-8760-4a9f251db1fa_0">
											<gml:posList>35.669215092544725 139.7404226138101 47.177 35.6692061898789 139.74041469302801 47.177 35.6692061898789 139.74041469302801 48.646 35.669215092544725 139.7404226138101 48.646 35.669215092544725 139.7404226138101 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-08f221a3-cba7-406a-8ebb-8f18fb2bf6c0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-08f221a3-cba7-406a-8ebb-8f18fb2bf6c0_0">
											<gml:posList>35.66921368951724 139.74035658185767 47.177 35.669208782613836 139.74035213597014 47.177 35.669208782613836 139.74035213597014 48.614 35.66921368951724 139.74035658185767 48.614 35.66921368951724 139.74035658185767 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8de695b6-6f62-49be-b3a7-e54e72f212f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8de695b6-6f62-49be-b3a7-e54e72f212f8_0">
											<gml:posList>35.66920570605643 139.74033674127776 47.177 35.669218039023754 139.74031622541324 47.177 35.669218039023754 139.74031622541324 48.914 35.66920570605643 139.74033674127776 48.914 35.66920570605643 139.74033674127776 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d357edb6-9142-4cf7-a365-b63de3024a7e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d357edb6-9142-4cf7-a365-b63de3024a7e_0">
											<gml:posList>35.669218039023754 139.74031622541324 47.177 35.66920861309412 139.74030770876047 47.177 35.66920861309412 139.74030770876047 48.914 35.669218039023754 139.74031622541324 48.914 35.669218039023754 139.74031622541324 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-dd6a8a9e-de0d-4135-897c-b141cac0ecb0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-dd6a8a9e-de0d-4135-897c-b141cac0ecb0_0">
											<gml:posList>35.66923117601482 139.7404381480836 46.145 35.66922130963484 139.74045457401874 46.145 35.66922130963484 139.74045457401874 48.497 35.66923117601482 139.7404381480836 48.497 35.66923117601482 139.7404381480836 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d681efb0-118e-4440-b49a-dcc1296b98f8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d681efb0-118e-4440-b49a-dcc1296b98f8_0">
											<gml:posList>35.669229878645396 139.74046230740947 46.943 35.669234505906296 139.74046647747628 46.943 35.669234505906296 139.74046647747628 48.497 35.66922130963484 139.74045457401874 48.497 35.66922130963484 139.74045457401874 46.145 35.669229878645396 139.74046230740947 46.145 35.669229878645396 139.74046230740947 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-2b8c47c4-29eb-4ecb-ad8f-762f2ac9212d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-2b8c47c4-29eb-4ecb-ad8f-762f2ac9212d_0">
											<gml:posList>35.66923117601482 139.7404381480836 48.497 35.66922130963484 139.74045457401874 48.497 35.669234505906296 139.74046647747628 48.497 35.669244372287864 139.74045005153988 48.497 35.66923117601482 139.7404381480836 48.497</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8f5175ef-edf0-434c-86e9-8631acf4d184">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8f5175ef-edf0-434c-86e9-8631acf4d184_0">
											<gml:posList>35.66923924502083 139.74035861784495 49.017 35.66922981075623 139.74037432529403 49.017 35.66922981075623 139.74037432529403 51.384 35.66923924502083 139.74035861784495 51.384 35.66923924502083 139.74035861784495 49.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b192bbfa-1c03-44d8-b344-0b242a78c439">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b192bbfa-1c03-44d8-b344-0b242a78c439_0">
											<gml:posList>35.669229878645396 139.74046230740947 46.943 35.669229878645396 139.74046230740947 46.145 35.669239871303766 139.74044599178822 46.145 35.669239871303766 139.74044599178822 46.943 35.669229878645396 139.74046230740947 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c9edbb6f-bdc1-44e2-a924-285fe94baeb7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c9edbb6f-bdc1-44e2-a924-285fe94baeb7_0">
											<gml:posList>35.66922981075623 139.74037432529403 49.017 35.66924262819483 139.74038588674958 49.017 35.66924262819483 139.74038588674958 51.384 35.66922981075623 139.74037432529403 51.384 35.66922981075623 139.74037432529403 49.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e8ec3bc1-d8ff-445e-b955-2d382727e9cd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e8ec3bc1-d8ff-445e-b955-2d382727e9cd_0">
											<gml:posList>35.66923117601482 139.7404381480836 46.145 35.66923117601482 139.7404381480836 48.497 35.669244372287864 139.74045005153988 48.497 35.669244372287864 139.74045005153988 46.943 35.669239871303766 139.74044599178822 46.943 35.669239871303766 139.74044599178822 46.145 35.66923117601482 139.7404381480836 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b64da3fe-6692-46d8-bfe3-22c9185a3f57">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b64da3fe-6692-46d8-bfe3-22c9185a3f57_0">
											<gml:posList>35.669234505906296 139.74046647747628 46.943 35.669244372287864 139.74045005153988 46.943 35.669244372287864 139.74045005153988 48.497 35.669234505906296 139.74046647747628 48.497 35.669234505906296 139.74046647747628 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f18dc7ee-5902-48a5-9ee2-7bd2cc610f68">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f18dc7ee-5902-48a5-9ee2-7bd2cc610f68_0">
											<gml:posList>35.66922981075623 139.74037432529403 51.384 35.66924262819483 139.74038588674958 51.384 35.66925206246944 139.74037019034546 51.384 35.66923924502083 139.74035861784495 51.384 35.66922981075623 139.74037432529403 51.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-85325bb6-ebdb-480c-99f3-2c2bc5095945">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-85325bb6-ebdb-480c-99f3-2c2bc5095945_0">
											<gml:posList>35.66925206246944 139.74037019034546 49.017 35.66923924502083 139.74035861784495 49.017 35.66923924502083 139.74035861784495 51.384 35.66925206246944 139.74037019034546 51.384 35.66925206246944 139.74037019034546 49.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-d210067e-501a-4186-87ce-15d5547f70b4">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-d210067e-501a-4186-87ce-15d5547f70b4_0">
											<gml:posList>35.66924279323625 139.74040118541052 51.384 35.66924948184827 139.74039005423185 51.384 35.66924948184827 139.74039005423185 49.017 35.66924279323625 139.74040118541052 49.017 35.66924279323625 139.74040118541052 51.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37ffe752-a20b-4dae-862f-8be24d332356">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-37ffe752-a20b-4dae-862f-8be24d332356_0">
											<gml:posList>35.66924279323625 139.74040118541052 49.017 35.66925117283412 139.7404087533256 49.017 35.66925117283412 139.7404087533256 51.384 35.66924279323625 139.74040118541052 51.384 35.66924279323625 139.74040118541052 49.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0c87d5c6-ec21-455a-8bf5-f069c33fe03d">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0c87d5c6-ec21-455a-8bf5-f069c33fe03d_0">
											<gml:posList>35.66924262819483 139.74038588674958 49.017 35.66925206246944 139.74037019034546 49.017 35.66925206246944 139.74037019034546 51.384 35.66924262819483 139.74038588674958 51.384 35.66924262819483 139.74038588674958 49.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c232997c-4339-45d9-9eaa-c4e219984f12">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c232997c-4339-45d9-9eaa-c4e219984f12_0">
											<gml:posList>35.66924279323625 139.74040118541052 51.384 35.66925117283412 139.7404087533256 51.384 35.66925786143831 139.7403976111003 51.384 35.66924948184827 139.74039005423185 51.384 35.66924279323625 139.74040118541052 51.384</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8a3d88f7-25cd-44ec-8229-6024057e77c7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8a3d88f7-25cd-44ec-8229-6024057e77c7_0">
											<gml:posList>35.66925786143831 139.7403976111003 49.017 35.66924948184827 139.74039005423185 49.017 35.66924948184827 139.74039005423185 51.384 35.66925786143831 139.7403976111003 51.384 35.66925786143831 139.7403976111003 49.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-36f1316c-2db4-411f-a934-e7ee87b98c1a">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-36f1316c-2db4-411f-a934-e7ee87b98c1a_0">
											<gml:posList>35.66925117283412 139.7404087533256 49.017 35.66925786143831 139.7403976111003 49.017 35.66925786143831 139.7403976111003 51.384 35.66925117283412 139.7404087533256 51.384 35.66925117283412 139.7404087533256 49.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:outerBuildingInstallation>
				<bldg:BuildingInstallation gml:id="bldg_6d3015ba-5c73-4349-9597-a481907435c9_BuildingInstallation_1041">
					<bldg:lod2Geometry>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30599146-b803-4ff2-a589-af36900426cf">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66893990473816 139.7402727504398 46.145 35.66897985678592 139.74020691369853 46.145 35.668962339770005 139.7401909503888 46.145 35.66900469535912 139.74012113420918 46.145 35.66905844573169 139.74016964132554 46.145 35.66896618152441 139.7403216871469 46.145 35.66897511140847 139.74032982878472 46.145 35.66894128085916 139.7403855954038 46.145 35.66887563315123 139.74032633211115 46.145 35.66891918560441 139.74025387468134 46.145 35.66893990473816 139.7402727504398 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-5f4c864c-c141-4207-afff-f9bf82c602a1">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669204290519275 139.7403012407624 46.943 35.66920638802022 139.74029774776184 46.943 35.66923921186623 139.7403273574141 46.943 35.669237105359244 139.74033086147182 46.943 35.669204290519275 139.7403012407624 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-985837ef-d04e-4b61-8599-91f4c2f4fd48">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.66907893528962 139.74050985887956 46.145 35.669204290519275 139.7403012407624 46.145 35.669237105359244 139.74033086147182 46.145 35.669197801901326 139.7403962668134 46.145 35.66922916448565 139.74042456371 46.145 35.66918346943356 139.74050061378924 46.145 35.66917017393777 139.7404886110337 46.145 35.66912981714948 139.74055578483612 46.145 35.66907893528962 139.74050985887956 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-37a66c46-b019-4bdf-975b-eff59d4add91">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669218093028775 139.74047963029804 46.145 35.66915739105658 139.74058035257502 46.145 35.66914704510739 139.7405710085053 46.145 35.6692077470804 139.74047029728035 46.145 35.669218093028775 139.74047963029804 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bead3770-5a0a-472b-81e5-1960f3288f61">
									<gml:exterior>
										<gml:LinearRing>
											<gml:posList>35.669076711752105 139.74051356189045 46.943 35.66907893528962 139.74050985887956 46.943 35.66912981714948 139.74055578483612 46.943 35.669127593602056 139.74055947680202 46.943 35.669076711752105 139.74051356189045 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-c863d615-4b4f-433f-9795-025c052fdbb6">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-c863d615-4b4f-433f-9795-025c052fdbb6_0">
											<gml:posList>35.66914704510739 139.7405710085053 46.943 35.66920774707189 139.74047028623426 46.943 35.6692077470804 139.74047029728035 46.145 35.66914704510739 139.7405710085053 46.145 35.66914704510739 139.7405710085053 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f2eb5cd1-07fa-41e4-b05a-7a5bb6610c1f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f2eb5cd1-07fa-41e4-b05a-7a5bb6610c1f_0">
											<gml:posList>35.66900469535912 139.74012113420918 46.753 35.66905844573169 139.74016964132554 46.753 35.66905844573169 139.74016964132554 46.145 35.66900469535912 139.74012113420918 46.145 35.66900469535912 139.74012113420918 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b414e98b-a5ea-47fe-8334-4c5859215ec7">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b414e98b-a5ea-47fe-8334-4c5859215ec7_0">
											<gml:posList>35.668962339770005 139.7401909503888 46.145 35.668962339770005 139.7401909503888 46.753 35.66900469535912 139.74012113420918 46.753 35.66900469535912 139.74012113420918 46.145 35.668962339770005 139.7401909503888 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8e013d14-80d3-4beb-80f9-214bd230731f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8e013d14-80d3-4beb-80f9-214bd230731f_0">
											<gml:posList>35.66897985678592 139.74020691369853 46.145 35.66897985678592 139.74020691369853 46.753 35.668962339770005 139.7401909503888 46.753 35.668962339770005 139.7401909503888 46.145 35.66897985678592 139.74020691369853 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0cd4b8aa-bbcc-4508-a26a-7e520460be82">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0cd4b8aa-bbcc-4508-a26a-7e520460be82_0">
											<gml:posList>35.66893990473816 139.7402727504398 46.753 35.66897985678592 139.74020691369853 46.753 35.66897985678592 139.74020691369853 46.145 35.66893990473816 139.7402727504398 46.145 35.66893990473816 139.7402727504398 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-efcf8474-dc0f-4f7a-b9f5-420de64c18b0">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-efcf8474-dc0f-4f7a-b9f5-420de64c18b0_0">
											<gml:posList>35.66905844573169 139.74016964132554 46.145 35.66905844573169 139.74016964132554 46.753 35.66896618152441 139.7403216871469 46.753 35.66896618152441 139.7403216871469 46.145 35.66905844573169 139.74016964132554 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-b6632077-bd9e-4f99-b0f7-8d1cb5aa2c94">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-b6632077-bd9e-4f99-b0f7-8d1cb5aa2c94_0">
											<gml:posList>35.66887563315123 139.74032633211115 46.753 35.66894128085916 139.7403855954038 46.753 35.66897511140847 139.74032982878472 46.753 35.66896618152441 139.7403216871469 46.753 35.66905844573169 139.74016964132554 46.753 35.66900469535912 139.74012113420918 46.753 35.668962339770005 139.7401909503888 46.753 35.66897985678592 139.74020691369853 46.753 35.66893990473816 139.7402727504398 46.753 35.66891918560441 139.74025387468134 46.753 35.66887563315123 139.74032633211115 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9a99ea0e-b33c-4750-87fa-2a4c44c69657">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9a99ea0e-b33c-4750-87fa-2a4c44c69657_0">
											<gml:posList>35.66893990473816 139.7402727504398 46.753 35.66893990473816 139.7402727504398 46.145 35.66891918560441 139.74025387468134 46.145 35.66891918560441 139.74025387468134 46.753 35.66893990473816 139.7402727504398 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-db37319b-a443-4b93-af79-df2a48077669">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-db37319b-a443-4b93-af79-df2a48077669_0">
											<gml:posList>35.66891918560441 139.74025387468134 46.145 35.66887563315123 139.74032633211115 46.145 35.66887563315123 139.74032633211115 46.753 35.66891918560441 139.74025387468134 46.753 35.66891918560441 139.74025387468134 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-beb76a7d-569f-4bc5-a762-1eceeeb8b908">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-beb76a7d-569f-4bc5-a762-1eceeeb8b908_0">
											<gml:posList>35.66920638802022 139.74029774776184 46.943 35.66920638802022 139.74029774776184 47.177 35.66923921186623 139.7403273574141 47.177 35.66923921186623 139.7403273574141 46.943 35.66920638802022 139.74029774776184 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8dff1da1-2986-4cfa-a35e-a513a274965e">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8dff1da1-2986-4cfa-a35e-a513a274965e_0">
											<gml:posList>35.669204290519275 139.7403012407624 46.145 35.669204290519275 139.7403012407624 46.943 35.669237105359244 139.74033086147182 46.943 35.669237105359244 139.74033086147182 46.145 35.669204290519275 139.7403012407624 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-aaa84d67-8822-455b-a39f-75de9bf17e86">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-aaa84d67-8822-455b-a39f-75de9bf17e86_0">
											<gml:posList>35.66896618152441 139.7403216871469 46.145 35.66896618152441 139.7403216871469 46.753 35.66897511140847 139.74032982878472 46.753 35.66897511140847 139.74032982878472 46.145 35.66896618152441 139.7403216871469 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-4d947755-1164-40e6-9420-4854d0a87941">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-4d947755-1164-40e6-9420-4854d0a87941_0">
											<gml:posList>35.66887563315123 139.74032633211115 46.145 35.66894128085916 139.7403855954038 46.145 35.66894128085916 139.7403855954038 46.753 35.66887563315123 139.74032633211115 46.753 35.66887563315123 139.74032633211115 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-30e66f9b-c1b9-4260-98ec-330f7ef9c42f">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-30e66f9b-c1b9-4260-98ec-330f7ef9c42f_0">
											<gml:posList>35.66897511140847 139.74032982878472 46.753 35.66894128085916 139.7403855954038 46.753 35.66894128085916 139.7403855954038 46.145 35.66897511140847 139.74032982878472 46.145 35.66897511140847 139.74032982878472 46.753</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-0e63aaac-49f5-4d90-a701-5160b134c0ca">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-0e63aaac-49f5-4d90-a701-5160b134c0ca_0">
											<gml:posList>35.669237105359244 139.74033086147182 46.943 35.66923921186623 139.7403273574141 46.943 35.66923921186623 139.7403273574141 47.177 35.669197801901326 139.7403962668134 47.177 35.669197801901326 139.7403962668134 46.145 35.669237105359244 139.74033086147182 46.145 35.669237105359244 139.74033086147182 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-712c566f-e7f3-45ec-abb7-5ec944c05981">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-712c566f-e7f3-45ec-abb7-5ec944c05981_0">
											<gml:posList>35.669204290519275 139.7403012407624 46.943 35.669204290519275 139.7403012407624 46.145 35.66907893528962 139.74050985887956 46.145 35.66907893528962 139.74050985887956 46.943 35.669076711752105 139.74051356189045 46.943 35.669076711752105 139.74051356189045 47.177 35.66920638802022 139.74029774776184 47.177 35.66920638802022 139.74029774776184 46.943 35.669204290519275 139.7403012407624 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-358ab2ce-6d34-4cae-b89a-1509723bf963">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-358ab2ce-6d34-4cae-b89a-1509723bf963_0">
											<gml:posList>35.669197801901326 139.7403962668134 46.145 35.669197801901326 139.7403962668134 47.177 35.66922916448565 139.74042456371 47.177 35.66922916448565 139.74042456371 46.145 35.669197801901326 139.7403962668134 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-f069e7e3-039c-457d-bac6-bb5aa142efb3">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-f069e7e3-039c-457d-bac6-bb5aa142efb3_0">
											<gml:posList>35.66917017393777 139.7404886110337 47.177 35.66918346943356 139.74050061378924 47.177 35.66922916448565 139.74042456371 47.177 35.669197801901326 139.7403962668134 47.177 35.66923921186623 139.7403273574141 47.177 35.66920638802022 139.74029774776184 47.177 35.669076711752105 139.74051356189045 47.177 35.669127593602056 139.74055947680202 47.177 35.66917017393777 139.7404886110337 47.177</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-9129c7bc-8743-4d37-97ef-bc7d8db9cebd">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-9129c7bc-8743-4d37-97ef-bc7d8db9cebd_0">
											<gml:posList>35.66922916448565 139.74042456371 46.145 35.66922916448565 139.74042456371 47.177 35.66918346943356 139.74050061378924 47.177 35.66918346943356 139.74050061378924 46.145 35.66922916448565 139.74042456371 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-8d57fc09-1664-4246-ad37-9c5e8dff50f9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-8d57fc09-1664-4246-ad37-9c5e8dff50f9_0">
											<gml:posList>35.66920774707189 139.74047028623426 46.943 35.669218093028775 139.74047963029804 46.943 35.669218093028775 139.74047963029804 46.145 35.6692077470804 139.74047029728035 46.145 35.66920774707189 139.74047028623426 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-fb147914-3b6a-4032-8194-847573892f13">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-fb147914-3b6a-4032-8194-847573892f13_0">
											<gml:posList>35.66918346943356 139.74050061378924 46.145 35.66918346943356 139.74050061378924 47.177 35.66917017393777 139.7404886110337 47.177 35.66917017393777 139.7404886110337 46.145 35.66918346943356 139.74050061378924 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-99701ce2-8c3a-46ad-b875-313d1b664584">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-99701ce2-8c3a-46ad-b875-313d1b664584_0">
											<gml:posList>35.66912981714948 139.74055578483612 46.943 35.66912981714948 139.74055578483612 46.145 35.66917017393777 139.7404886110337 46.145 35.66917017393777 139.7404886110337 47.177 35.669127593602056 139.74055947680202 47.177 35.669127593602056 139.74055947680202 46.943 35.66912981714948 139.74055578483612 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-7744a2b7-07c8-466e-8063-76ba217ef1e8">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-7744a2b7-07c8-466e-8063-76ba217ef1e8_0">
											<gml:posList>35.66915739105658 139.74058035257502 46.943 35.669218093028775 139.74047963029804 46.943 35.66920774707189 139.74047028623426 46.943 35.66914704510739 139.7405710085053 46.943 35.66915739105658 139.74058035257502 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1af7c39-2c7e-421c-96e7-de78b0dea79b">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1af7c39-2c7e-421c-96e7-de78b0dea79b_0">
											<gml:posList>35.669218093028775 139.74047963029804 46.943 35.66915739105658 139.74058035257502 46.943 35.66915739105658 139.74058035257502 46.145 35.669218093028775 139.74047963029804 46.145 35.669218093028775 139.74047963029804 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-e5029503-d280-4ccf-b6d9-7aca97118865">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-e5029503-d280-4ccf-b6d9-7aca97118865_0">
											<gml:posList>35.66907893528962 139.74050985887956 46.943 35.66907893528962 139.74050985887956 46.145 35.66912981714948 139.74055578483612 46.145 35.66912981714948 139.74055578483612 46.943 35.66907893528962 139.74050985887956 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-a1302491-192c-4b1e-9661-07fa3cd8fa75">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-a1302491-192c-4b1e-9661-07fa3cd8fa75_0">
											<gml:posList>35.669127593602056 139.74055947680202 46.943 35.669127593602056 139.74055947680202 47.177 35.669076711752105 139.74051356189045 47.177 35.669076711752105 139.74051356189045 46.943 35.669127593602056 139.74055947680202 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
							<gml:surfaceMember>
								<gml:Polygon gml:id="fme-gen-bc0f7338-dcf7-4bee-9b49-84686478afc9">
									<gml:exterior>
										<gml:LinearRing gml:id="fme-gen-bc0f7338-dcf7-4bee-9b49-84686478afc9_0">
											<gml:posList>35.66915739105658 139.74058035257502 46.943 35.66914704510739 139.7405710085053 46.943 35.66914704510739 139.7405710085053 46.145 35.66915739105658 139.74058035257502 46.145 35.66915739105658 139.74058035257502 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2Geometry>
				</bldg:BuildingInstallation>
			</bldg:outerBuildingInstallation>
			<bldg:boundedBy>
				<bldg:GroundSurface gml:id="surface-6cbd7c3a-9c28-4d40-b623-e28e5d1eeb29">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6cbd7c3a-9c28-4d40-b623-e28e5d1eeb29">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6cbd7c3a-9c28-4d40-b623-e28e5d1eeb29">
											<gml:posList>35.6692923268528 139.74037024307714 10.94 35.6691588245243 139.74059242429448 10.94 35.66886603489074 139.74032809956674 10.94 35.668999536824096 139.74010602918338 10.94 35.6692923268528 139.74037024307714 10.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:GroundSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-1300c09f-aeeb-4b84-b8e4-0ae269f607a6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-1300c09f-aeeb-4b84-b8e4-0ae269f607a6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-1300c09f-aeeb-4b84-b8e4-0ae269f607a6">
											<gml:posList>35.66886603489074 139.74032809956674 46.943 35.66887563315123 139.74032633211115 46.943 35.66900099714112 139.74011779154938 46.943 35.668999536824096 139.74010602918338 46.943 35.66886603489074 139.74032809956674 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-33602318-1f3f-484d-bdb3-09bd4dc6e370">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-33602318-1f3f-484d-bdb3-09bd4dc6e370">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-33602318-1f3f-484d-bdb3-09bd4dc6e370">
											<gml:posList>35.66924450753478 139.74043841983678 46.943 35.669157382289605 139.74058067292182 46.943 35.6691588245243 139.74059242429448 46.943 35.6692923268528 139.74037024307714 46.943 35.668999536824096 139.74010602918338 46.943 35.66900099714112 139.74011779154938 46.943 35.66928381100674 139.74037300343156 46.943 35.66928149745566 139.7403768612056 46.943 35.66924450753478 139.74043841983678 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-19cf9279-394a-4a3c-a5fe-6ae980e12739">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-19cf9279-394a-4a3c-a5fe-6ae980e12739">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-19cf9279-394a-4a3c-a5fe-6ae980e12739">
											<gml:posList>35.669157382289605 139.74058067292182 46.145 35.66924450753478 139.74043841983678 46.145 35.669197801901326 139.7403962668134 46.145 35.669234791800974 139.74033470819873 46.145 35.66928149745566 139.7403768612056 46.145 35.66928381100674 139.74037300343156 46.145 35.66900099714112 139.74011779154938 46.145 35.66887563315123 139.74032633211115 46.145 35.669157382289605 139.74058067292182 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-7ba9ca4d-6418-4d0f-99f1-9d850241e153">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7ba9ca4d-6418-4d0f-99f1-9d850241e153">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7ba9ca4d-6418-4d0f-99f1-9d850241e153">
											<gml:posList>35.669234791800974 139.74033470819873 49.678 35.66923565345358 139.74034163310512 49.678 35.66927585566579 139.7403779060804 49.678 35.66928149745566 139.7403768612056 49.678 35.669234791800974 139.74033470819873 49.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-4ca39808-2bd6-4908-84d1-60e47d2602c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-4ca39808-2bd6-4908-84d1-60e47d2602c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-4ca39808-2bd6-4908-84d1-60e47d2602c5">
											<gml:posList>35.669197801901326 139.7403962668134 49.678 35.66920345269663 139.74039521088434 49.678 35.66923565345358 139.74034163310512 49.678 35.669234791800974 139.74033470819873 49.678 35.669197801901326 139.7403962668134 49.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-a5c4cf12-6f7c-4d19-9824-3564aa40490f">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-a5c4cf12-6f7c-4d19-9824-3564aa40490f">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-a5c4cf12-6f7c-4d19-9824-3564aa40490f">
											<gml:posList>35.66927585566579 139.7403779060804 49.017 35.66923565345358 139.74034163310512 49.017 35.66920345269663 139.74039521088434 49.017 35.66924365490996 139.74043150596418 49.017 35.66927585566579 139.7403779060804 49.017</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-744cdf66-cefd-4732-8d00-af9c26f8ed83">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-744cdf66-cefd-4732-8d00-af9c26f8ed83">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-744cdf66-cefd-4732-8d00-af9c26f8ed83">
											<gml:posList>35.66928149745566 139.7403768612056 49.678 35.66927585566579 139.7403779060804 49.678 35.66924365490996 139.74043150596418 49.678 35.66924450753478 139.74043841983678 49.678 35.66928149745566 139.7403768612056 49.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-9db25cd2-be77-4d0e-bba4-3000d41504c7">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-9db25cd2-be77-4d0e-bba4-3000d41504c7">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-9db25cd2-be77-4d0e-bba4-3000d41504c7">
											<gml:posList>35.66924450753478 139.74043841983678 49.678 35.66924365490996 139.74043150596418 49.678 35.66920345269663 139.74039521088434 49.678 35.669197801901326 139.7403962668134 49.678 35.66924450753478 139.74043841983678 49.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:RoofSurface gml:id="surface-2ae9cf95-555b-43db-9308-a697980135b6">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-2ae9cf95-555b-43db-9308-a697980135b6">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-2ae9cf95-555b-43db-9308-a697980135b6">
											<gml:posList>35.6691588245243 139.74059242429448 46.943 35.669157382289605 139.74058067292182 46.943 35.66887563315123 139.74032633211115 46.943 35.66886603489074 139.74032809956674 46.943 35.6691588245243 139.74059242429448 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:RoofSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-41eb2f7d-0b5c-48d3-bb4b-ec718fda79e9">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-41eb2f7d-0b5c-48d3-bb4b-ec718fda79e9">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-41eb2f7d-0b5c-48d3-bb4b-ec718fda79e9">
											<gml:posList>35.66900099714112 139.74011779154938 46.943 35.66900099714112 139.74011779154938 46.145 35.66928381100674 139.74037300343156 46.145 35.66928381100674 139.74037300343156 46.943 35.66900099714112 139.74011779154938 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-584eae48-a2ab-4fc4-b601-cdd9175519c5">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-584eae48-a2ab-4fc4-b601-cdd9175519c5">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-584eae48-a2ab-4fc4-b601-cdd9175519c5">
											<gml:posList>35.669157382289605 139.74058067292182 46.943 35.669157382289605 139.74058067292182 46.145 35.66887563315123 139.74032633211115 46.145 35.66887563315123 139.74032633211115 46.943 35.669157382289605 139.74058067292182 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-905776bb-cc5b-4323-9dae-448dbdd52780">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-905776bb-cc5b-4323-9dae-448dbdd52780">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-905776bb-cc5b-4323-9dae-448dbdd52780">
											<gml:posList>35.668999536824096 139.74010602918338 10.94 35.66886603489074 139.74032809956674 10.94 35.66886603489074 139.74032809956674 46.943 35.668999536824096 139.74010602918338 46.943 35.668999536824096 139.74010602918338 10.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-896af834-7a75-4713-8c26-34c5c2d3f776">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-896af834-7a75-4713-8c26-34c5c2d3f776">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-896af834-7a75-4713-8c26-34c5c2d3f776">
											<gml:posList>35.66887563315123 139.74032633211115 46.943 35.66887563315123 139.74032633211115 46.145 35.66900099714112 139.74011779154938 46.145 35.66900099714112 139.74011779154938 46.943 35.66887563315123 139.74032633211115 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-8806d426-ad98-4442-842d-fbe7cd811ec8">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-8806d426-ad98-4442-842d-fbe7cd811ec8">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-8806d426-ad98-4442-842d-fbe7cd811ec8">
											<gml:posList>35.6692923268528 139.74037024307714 10.94 35.668999536824096 139.74010602918338 10.94 35.668999536824096 139.74010602918338 46.943 35.6692923268528 139.74037024307714 46.943 35.6692923268528 139.74037024307714 10.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7f7c049a-c234-4d37-9aed-1fd9f6c8e5cd">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7f7c049a-c234-4d37-9aed-1fd9f6c8e5cd">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7f7c049a-c234-4d37-9aed-1fd9f6c8e5cd">
											<gml:posList>35.669234791800974 139.74033470819873 46.145 35.669234791800974 139.74033470819873 49.678 35.66928149745566 139.7403768612056 49.678 35.66928149745566 139.7403768612056 46.943 35.66928149745566 139.7403768612056 46.145 35.669234791800974 139.74033470819873 46.145</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-611cead0-2189-43d3-9d96-c0ae976a0d65">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-611cead0-2189-43d3-9d96-c0ae976a0d65">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-611cead0-2189-43d3-9d96-c0ae976a0d65">
											<gml:posList>35.66923565345358 139.74034163310512 49.678 35.66923565345358 139.74034163310512 49.017 35.66927585566579 139.7403779060804 49.017 35.66927585566579 139.7403779060804 49.678 35.66923565345358 139.74034163310512 49.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-6497c07b-81e9-45a7-8897-35f4e5fb5b39">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-6497c07b-81e9-45a7-8897-35f4e5fb5b39">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-6497c07b-81e9-45a7-8897-35f4e5fb5b39">
											<gml:posList>35.669197801901326 139.7403962668134 49.678 35.669234791800974 139.74033470819873 49.678 35.669234791800974 139.74033470819873 46.145 35.669197801901326 139.7403962668134 46.145 35.669197801901326 139.7403962668134 49.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c7e79b60-b506-446b-acc6-eed853e8cdca">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c7e79b60-b506-446b-acc6-eed853e8cdca">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c7e79b60-b506-446b-acc6-eed853e8cdca">
											<gml:posList>35.66920345269663 139.74039521088434 49.678 35.66920345269663 139.74039521088434 49.017 35.66923565345358 139.74034163310512 49.017 35.66923565345358 139.74034163310512 49.678 35.66920345269663 139.74039521088434 49.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-39a20dae-174d-4b66-841e-d84184de021e">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-39a20dae-174d-4b66-841e-d84184de021e">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-39a20dae-174d-4b66-841e-d84184de021e">
											<gml:posList>35.66928381100674 139.74037300343156 46.943 35.66928381100674 139.74037300343156 46.145 35.66928149745566 139.7403768612056 46.145 35.66928149745566 139.7403768612056 46.943 35.66928381100674 139.74037300343156 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-cfc59c1c-43a1-45d3-96f0-63ba82c85c2d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-cfc59c1c-43a1-45d3-96f0-63ba82c85c2d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-cfc59c1c-43a1-45d3-96f0-63ba82c85c2d">
											<gml:posList>35.66927585566579 139.7403779060804 49.678 35.66927585566579 139.7403779060804 49.017 35.66924365490996 139.74043150596418 49.017 35.66924365490996 139.74043150596418 49.678 35.66927585566579 139.7403779060804 49.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-7b2981a9-1f1e-4e66-97fc-666d0fc0474d">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-7b2981a9-1f1e-4e66-97fc-666d0fc0474d">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-7b2981a9-1f1e-4e66-97fc-666d0fc0474d">
											<gml:posList>35.66928149745566 139.7403768612056 49.678 35.66924450753478 139.74043841983678 49.678 35.66924450753478 139.74043841983678 46.943 35.66928149745566 139.7403768612056 46.943 35.66928149745566 139.7403768612056 49.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-07abb19c-be9e-4073-8e4c-25297ebd00aa">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-07abb19c-be9e-4073-8e4c-25297ebd00aa">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-07abb19c-be9e-4073-8e4c-25297ebd00aa">
											<gml:posList>35.66924365490996 139.74043150596418 49.678 35.66924365490996 139.74043150596418 49.017 35.66920345269663 139.74039521088434 49.017 35.66920345269663 139.74039521088434 49.678 35.66924365490996 139.74043150596418 49.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-c9aa9691-195c-4835-9bc7-51eb7869a368">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-c9aa9691-195c-4835-9bc7-51eb7869a368">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-c9aa9691-195c-4835-9bc7-51eb7869a368">
											<gml:posList>35.669197801901326 139.7403962668134 49.678 35.669197801901326 139.7403962668134 46.145 35.66924450753478 139.74043841983678 46.145 35.66924450753478 139.74043841983678 46.943 35.66924450753478 139.74043841983678 49.678 35.669197801901326 139.7403962668134 49.678</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-908bd9a4-6062-427f-a6c4-62cf42718006">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-908bd9a4-6062-427f-a6c4-62cf42718006">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-908bd9a4-6062-427f-a6c4-62cf42718006">
											<gml:posList>35.66886603489074 139.74032809956674 10.94 35.6691588245243 139.74059242429448 10.94 35.6691588245243 139.74059242429448 46.943 35.66886603489074 139.74032809956674 46.943 35.66886603489074 139.74032809956674 10.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-576b1c5d-6e7e-4791-8678-817825bfb148">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-576b1c5d-6e7e-4791-8678-817825bfb148">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-576b1c5d-6e7e-4791-8678-817825bfb148">
											<gml:posList>35.6691588245243 139.74059242429448 10.94 35.6692923268528 139.74037024307714 10.94 35.6692923268528 139.74037024307714 46.943 35.6691588245243 139.74059242429448 46.943 35.6691588245243 139.74059242429448 10.94</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:boundedBy>
				<bldg:WallSurface gml:id="surface-f6167f48-160e-4bfb-9430-a7c47680ddc0">
					<bldg:lod2MultiSurface>
						<gml:MultiSurface srsName="http://www.opengis.net/def/crs/EPSG/0/6697" srsDimension="3">
							<gml:surfaceMember>
								<gml:Polygon gml:id="poly-f6167f48-160e-4bfb-9430-a7c47680ddc0">
									<gml:exterior>
										<gml:LinearRing gml:id="linr-f6167f48-160e-4bfb-9430-a7c47680ddc0">
											<gml:posList>35.66924450753478 139.74043841983678 46.943 35.66924450753478 139.74043841983678 46.145 35.669157382289605 139.74058067292182 46.145 35.669157382289605 139.74058067292182 46.943 35.66924450753478 139.74043841983678 46.943</gml:posList>
										</gml:LinearRing>
									</gml:exterior>
								</gml:Polygon>
							</gml:surfaceMember>
						</gml:MultiSurface>
					</bldg:lod2MultiSurface>
				</bldg:WallSurface>
			</bldg:boundedBy>
			<bldg:address>
				<core:Address>
					<core:xalAddress>
						<xAL:AddressDetails>
							<xAL:Country>
								<xAL:CountryName>日本</xAL:CountryName>
								<xAL:Locality>
									<xAL:LocalityName Type="Town">東京都港区赤坂二丁目</xAL:LocalityName>
								</xAL:Locality>
							</xAL:Country>
						</xAL:AddressDetails>
					</core:xalAddress>
				</core:Address>
			</bldg:address>
			<uro:buildingIDAttribute>
				<uro:BuildingIDAttribute>
					<uro:buildingID>13103-bldg-11473</uro:buildingID>
					<uro:prefecture codeSpace="../../codelists/Common_localPublicAuthorities.xml">13</uro:prefecture>
					<uro:city codeSpace="../../codelists/Common_localPublicAuthorities.xml">13103</uro:city>
				</uro:BuildingIDAttribute>
			</uro:buildingIDAttribute>
			<uro:buildingDetailAttribute>
				<uro:BuildingDetailAttribute>
					<uro:buildingRoofEdgeArea uom="m2">1007.53635</uro:buildingRoofEdgeArea>
					<uro:fireproofStructureType codeSpace="../../codelists/BuildingDetailAttribute_fireproofStructureType.xml">1001</uro:fireproofStructureType>
					<uro:urbanPlanType codeSpace="../../codelists/Common_urbanPlanType.xml">21</uro:urbanPlanType>
					<uro:areaClassificationType codeSpace="../../codelists/Common_areaClassificationType.xml">22</uro:areaClassificationType>
					<uro:districtsAndZonesType codeSpace="../../codelists/Common_districtsAndZonesType.xml">10</uro:districtsAndZonesType>
					<uro:landUseType codeSpace="../../codelists/Common_landUseType.xml">212</uro:landUseType>
					<uro:detailedUsage codeSpace="../../codelists/BuildingDetailAttribute_detailedUsage.xml">1210</uro:detailedUsage>
					<uro:specifiedBuildingCoverageRate>0.8</uro:specifiedBuildingCoverageRate>
					<uro:specifiedFloorAreaRate>7</uro:specifiedFloorAreaRate>
					<uro:surveyYear>2021</uro:surveyYear>
				</uro:BuildingDetailAttribute>
			</uro:buildingDetailAttribute>
			<uro:buildingDisasterRiskAttribute>
				<uro:BuildingRiverFloodingRiskAttribute>
					<uro:description codeSpace="../../codelists/RiverFloodingRiskAttribute_description.xml">10</uro:description>
					<uro:rank codeSpace="../../codelists/RiverFloodingRiskAttribute_rank.xml">1</uro:rank>
					<uro:depth uom="m">0.03</uro:depth>
					<uro:adminType codeSpace="../../codelists/RiverFloodingRiskAttribute_adminType.xml">2</uro:adminType>
					<uro:scale codeSpace="../../codelists/RiverFloodingRiskAttribute_scale.xml">2</uro:scale>
				</uro:BuildingRiverFloodingRiskAttribute>
			</uro:buildingDisasterRiskAttribute>
			<uro:buildingDataQualityAttribute>
				<uro:BuildingDataQualityAttribute>
					<uro:srcScale codeSpace="../../codelists/BuildingDataQualityAttribute_srcScale.xml">1</uro:srcScale>
					<uro:geometrySrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_geometrySrcDesc.xml">5</uro:geometrySrcDesc>
					<uro:thematicSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_thematicSrcDesc.xml">1</uro:thematicSrcDesc>
					<uro:appearanceSrcDesc codeSpace="../../codelists/BuildingDataQualityAttribute_appearanceSrcDesc.xml">1</uro:appearanceSrcDesc>
					<uro:lod1HeightType codeSpace="../../codelists/BuildingDataQualityAttribute_lod1HeightType.xml">2</uro:lod1HeightType>
					<uro:lodType>2.2</uro:lodType>
				</uro:BuildingDataQualityAttribute>
			</uro:buildingDataQualityAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">100</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key100.xml">11</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">101</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key101.xml">1</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">102</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key102.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">103</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key103.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">104</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key104.xml">0</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
			<uro:keyValuePairAttribute>
				<uro:KeyValuePairAttribute>
					<uro:key codeSpace="../../codelists/KeyValuePairAttribute_key.xml">106</uro:key>
					<uro:codeValue codeSpace="../../codelists/KeyValuePairAttribute_key106.xml">10</uro:codeValue>
				</uro:KeyValuePairAttribute>
			</uro:keyValuePairAttribute>
		</bldg:Building>
	</core:cityObjectMember></core:CityModel>